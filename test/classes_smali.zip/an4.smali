.class public final Lan4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:J

.field public static final c:J

.field public static final d:J

.field public static final e:J

.field public static final f:J

.field public static final g:J

.field public static final h:J

.field public static final synthetic i:I


# instance fields
.field public final a:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-wide v0, 0xff000000L

    invoke-static {v0, v1}, Lor5;->g(J)J

    move-result-wide v0

    sput-wide v0, Lan4;->b:J

    const-wide v0, 0xff444444L

    invoke-static {v0, v1}, Lor5;->g(J)J

    const-wide v0, 0xff888888L

    invoke-static {v0, v1}, Lor5;->g(J)J

    const-wide v0, 0xffccccccL

    invoke-static {v0, v1}, Lor5;->g(J)J

    move-result-wide v0

    sput-wide v0, Lan4;->c:J

    const-wide v0, 0xffffffffL

    invoke-static {v0, v1}, Lor5;->g(J)J

    move-result-wide v0

    sput-wide v0, Lan4;->d:J

    const-wide v0, 0xffff0000L

    invoke-static {v0, v1}, Lor5;->g(J)J

    move-result-wide v0

    sput-wide v0, Lan4;->e:J

    const-wide v0, 0xff00ff00L

    invoke-static {v0, v1}, Lor5;->g(J)J

    const-wide v0, 0xff0000ffL

    invoke-static {v0, v1}, Lor5;->g(J)J

    move-result-wide v0

    sput-wide v0, Lan4;->f:J

    const-wide v0, 0xffffff00L

    invoke-static {v0, v1}, Lor5;->g(J)J

    const-wide v0, 0xff00ffffL

    invoke-static {v0, v1}, Lor5;->g(J)J

    const-wide v0, 0xffff00ffL

    invoke-static {v0, v1}, Lor5;->g(J)J

    const/4 v0, 0x0

    invoke-static {v0}, Lor5;->e(I)J

    move-result-wide v0

    sput-wide v0, Lan4;->g:J

    const/4 v0, 0x0

    sget-object v1, Lqn4;->u:Lqhf;

    invoke-static {v0, v0, v0, v0, v1}, Lor5;->d(FFFFLon4;)J

    move-result-wide v0

    sput-wide v0, Lan4;->h:J

    return-void
.end method

.method public synthetic constructor <init>(J)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lan4;->a:J

    return-void
.end method

.method public static final a(JLon4;)J
    .registers 7

    invoke-static {p0, p1}, Lan4;->f(J)Lon4;

    move-result-object v0

    iget v1, v0, Lon4;->c:I

    iget v2, p2, Lon4;->c:I

    or-int v3, v1, v2

    if-gez v3, :cond_11

    invoke-static {v0, p2}, Lin6;->n(Lon4;Lon4;)Ltz4;

    move-result-object p2

    goto :goto_26

    :cond_11
    sget-object v3, Lv15;->a:Llcc;

    shl-int/lit8 v2, v2, 0x6

    or-int/2addr v1, v2

    invoke-virtual {v3, v1}, Loj9;->b(I)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_23

    invoke-static {v0, p2}, Lin6;->n(Lon4;Lon4;)Ltz4;

    move-result-object v2

    invoke-virtual {v3, v1, v2}, Llcc;->i(ILjava/lang/Object;)V

    :cond_23
    move-object p2, v2

    check-cast p2, Ltz4;

    :goto_26
    invoke-virtual {p2, p0, p1}, Ltz4;->a(J)J

    move-result-wide p0

    return-wide p0
.end method

.method public static b(FJ)J
    .registers 6

    invoke-static {p1, p2}, Lan4;->h(J)F

    move-result v0

    invoke-static {p1, p2}, Lan4;->g(J)F

    move-result v1

    invoke-static {p1, p2}, Lan4;->e(J)F

    move-result v2

    invoke-static {p1, p2}, Lan4;->f(J)Lon4;

    move-result-object p1

    invoke-static {v0, v1, v2, p0, p1}, Lor5;->d(FFFFLon4;)J

    move-result-wide p0

    return-wide p0
.end method

.method public static final c(JJ)Z
    .registers 4

    cmp-long p0, p0, p2

    if-nez p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public static final d(J)F
    .registers 6

    const-wide/16 v0, 0x3f

    and-long/2addr v0, p0

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_18

    const/16 v0, 0x38

    ushr-long/2addr p0, v0

    const-wide/16 v0, 0xff

    and-long/2addr p0, v0

    invoke-static {p0, p1}, Lzxh;->k0(J)D

    move-result-wide p0

    double-to-float p0, p0

    const/high16 p1, 0x437f0000  # 255.0f

    :goto_16
    div-float/2addr p0, p1

    return p0

    :cond_18
    const/4 v0, 0x6

    ushr-long/2addr p0, v0

    const-wide/16 v0, 0x3ff

    and-long/2addr p0, v0

    invoke-static {p0, p1}, Lzxh;->k0(J)D

    move-result-wide p0

    double-to-float p0, p0

    const p1, 0x447fc000  # 1023.0f

    goto :goto_16
.end method

.method public static final e(J)F
    .registers 7

    const-wide/16 v0, 0x3f

    and-long/2addr v0, p0

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_18

    const/16 v0, 0x20

    ushr-long/2addr p0, v0

    const-wide/16 v0, 0xff

    and-long/2addr p0, v0

    invoke-static {p0, p1}, Lzxh;->k0(J)D

    move-result-wide p0

    double-to-float p0, p0

    const/high16 p1, 0x437f0000  # 255.0f

    div-float/2addr p0, p1

    return p0

    :cond_18
    const/16 v0, 0x10

    ushr-long/2addr p0, v0

    const-wide/32 v1, 0xffff

    and-long/2addr p0, v1

    long-to-int p0, p0

    int-to-short p0, p0

    const p1, 0xffff

    and-int/2addr p1, p0

    const v1, 0x8000

    and-int/2addr v1, p0

    ushr-int/lit8 p1, p1, 0xa

    const/16 v2, 0x1f

    and-int/2addr p1, v2

    and-int/lit16 p0, p0, 0x3ff

    if-nez p1, :cond_48

    if-eqz p0, :cond_45

    const/high16 p1, 0x3f000000  # 0.5f

    add-int/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    invoke-static {}, Lpy7;->a()F

    move-result p1

    sub-float/2addr p0, p1

    if-nez v1, :cond_43

    return p0

    :cond_43
    neg-float p0, p0

    return p0

    :cond_45
    const/4 p0, 0x0

    move p1, p0

    goto :goto_5a

    :cond_48
    shl-int/lit8 p0, p0, 0xd

    if-ne p1, v2, :cond_57

    const/16 p1, 0xff

    if-eqz p0, :cond_53

    const/high16 v2, 0x400000

    or-int/2addr p0, v2

    :cond_53
    :goto_53
    move v4, p1

    move p1, p0

    move p0, v4

    goto :goto_5a

    :cond_57
    add-int/lit8 p1, p1, 0x70

    goto :goto_53

    :goto_5a
    shl-int/lit8 v0, v1, 0x10

    shl-int/lit8 p0, p0, 0x17

    or-int/2addr p0, v0

    or-int/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    return p0
.end method

.method public static final f(J)Lon4;
    .registers 4

    sget-object v0, Lqn4;->a:[F

    const-wide/16 v0, 0x3f

    and-long/2addr p0, v0

    long-to-int p0, p0

    sget-object p1, Lqn4;->y:[Lon4;

    aget-object p0, p1, p0

    return-object p0
.end method

.method public static final g(J)F
    .registers 7

    const-wide/16 v0, 0x3f

    and-long/2addr v0, p0

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_18

    const/16 v0, 0x28

    ushr-long/2addr p0, v0

    const-wide/16 v0, 0xff

    and-long/2addr p0, v0

    invoke-static {p0, p1}, Lzxh;->k0(J)D

    move-result-wide p0

    double-to-float p0, p0

    const/high16 p1, 0x437f0000  # 255.0f

    div-float/2addr p0, p1

    return p0

    :cond_18
    const/16 v0, 0x20

    ushr-long/2addr p0, v0

    const-wide/32 v0, 0xffff

    and-long/2addr p0, v0

    long-to-int p0, p0

    int-to-short p0, p0

    const p1, 0xffff

    and-int/2addr p1, p0

    const v0, 0x8000

    and-int/2addr v0, p0

    ushr-int/lit8 p1, p1, 0xa

    const/16 v1, 0x1f

    and-int/2addr p1, v1

    and-int/lit16 p0, p0, 0x3ff

    if-nez p1, :cond_48

    if-eqz p0, :cond_45

    const/high16 p1, 0x3f000000  # 0.5f

    add-int/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    invoke-static {}, Lpy7;->a()F

    move-result p1

    sub-float/2addr p0, p1

    if-nez v0, :cond_43

    return p0

    :cond_43
    neg-float p0, p0

    return p0

    :cond_45
    const/4 p0, 0x0

    move p1, p0

    goto :goto_5a

    :cond_48
    shl-int/lit8 p0, p0, 0xd

    if-ne p1, v1, :cond_57

    const/16 p1, 0xff

    if-eqz p0, :cond_53

    const/high16 v1, 0x400000

    or-int/2addr p0, v1

    :cond_53
    :goto_53
    move v4, p1

    move p1, p0

    move p0, v4

    goto :goto_5a

    :cond_57
    add-int/lit8 p1, p1, 0x70

    goto :goto_53

    :goto_5a
    shl-int/lit8 v0, v0, 0x10

    shl-int/lit8 p0, p0, 0x17

    or-int/2addr p0, v0

    or-int/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    return p0
.end method

.method public static final h(J)F
    .registers 7

    const-wide/16 v0, 0x3f

    and-long/2addr v0, p0

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/16 v1, 0x30

    if-nez v0, :cond_18

    ushr-long/2addr p0, v1

    const-wide/16 v0, 0xff

    and-long/2addr p0, v0

    invoke-static {p0, p1}, Lzxh;->k0(J)D

    move-result-wide p0

    double-to-float p0, p0

    const/high16 p1, 0x437f0000  # 255.0f

    div-float/2addr p0, p1

    return p0

    :cond_18
    ushr-long/2addr p0, v1

    const-wide/32 v0, 0xffff

    and-long/2addr p0, v0

    long-to-int p0, p0

    int-to-short p0, p0

    const p1, 0xffff

    and-int/2addr p1, p0

    const v0, 0x8000

    and-int/2addr v0, p0

    ushr-int/lit8 p1, p1, 0xa

    const/16 v1, 0x1f

    and-int/2addr p1, v1

    and-int/lit16 p0, p0, 0x3ff

    if-nez p1, :cond_46

    if-eqz p0, :cond_43

    const/high16 p1, 0x3f000000  # 0.5f

    add-int/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    invoke-static {}, Lpy7;->a()F

    move-result p1

    sub-float/2addr p0, p1

    if-nez v0, :cond_41

    return p0

    :cond_41
    neg-float p0, p0

    return p0

    :cond_43
    const/4 p0, 0x0

    move p1, p0

    goto :goto_58

    :cond_46
    shl-int/lit8 p0, p0, 0xd

    if-ne p1, v1, :cond_55

    const/16 p1, 0xff

    if-eqz p0, :cond_51

    const/high16 v1, 0x400000

    or-int/2addr p0, v1

    :cond_51
    :goto_51
    move v4, p1

    move p1, p0

    move p0, v4

    goto :goto_58

    :cond_55
    add-int/lit8 p1, p1, 0x70

    goto :goto_51

    :goto_58
    shl-int/lit8 v0, v0, 0x10

    shl-int/lit8 p0, p0, 0x17

    or-int/2addr p0, v0

    or-int/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    return p0
.end method

.method public static i(J)Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Color("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p0, p1}, Lan4;->h(J)F

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0, p1}, Lan4;->g(J)F

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0, p1}, Lan4;->e(J)F

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0, p1}, Lan4;->d(J)F

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0, p1}, Lan4;->f(J)Lon4;

    move-result-object p0

    iget-object p0, p0, Lon4;->a:Ljava/lang/String;

    const/16 p1, 0x29

    invoke-static {v0, p0, p1}, Lkec;->x(Ljava/lang/StringBuilder;Ljava/lang/String;C)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Lan4;

    if-nez v0, :cond_5

    goto :goto_f

    :cond_5
    check-cast p1, Lan4;

    iget-wide v0, p1, Lan4;->a:J

    iget-wide p0, p0, Lan4;->a:J

    cmp-long p0, p0, v0

    if-eqz p0, :cond_11

    :goto_f
    const/4 p0, 0x0

    return p0

    :cond_11
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 3

    iget-wide v0, p0, Lan4;->a:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget-wide v0, p0, Lan4;->a:J

    invoke-static {v0, v1}, Lan4;->i(J)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
