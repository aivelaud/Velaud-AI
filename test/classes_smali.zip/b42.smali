.class public final Lb42;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lb42;->a:I

    iput-object p2, p0, Lb42;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 13

    iget v0, p0, Lb42;->a:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_21e

    iget-object p0, p0, Lb42;->b:Ljava/lang/Object;

    move-object v3, p0

    check-cast v3, Lcqk;

    const-string p0, "package.name"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    iget-object p1, v3, Lcqk;->a:Lahj;

    if-nez p0, :cond_2e

    const-string p0, "package.name"

    invoke-virtual {p2, p0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p2, "ListenerRegistryBroadcastReceiver received broadcast for third party app: %s"

    invoke-virtual {p1, p2, p0}, Lahj;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_93

    :cond_2e
    const/4 p0, 0x0

    new-array p0, p0, [Ljava/lang/Object;

    const-string v0, "List of extras in received intent:"

    invoke-virtual {p1, v0, p0}, Lahj;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p0

    invoke-virtual {p0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_42
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_62

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iget-object v0, v3, Lcqk;->a:Lahj;

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    filled-new-array {p1, v1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v1, "Key: %s; value: %s"

    invoke-virtual {v0, v1, p1}, Lahj;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_42

    :cond_62
    iget-object p0, v3, Lcqk;->a:Lahj;

    invoke-static {p2, p0}, Lcom/google/android/play/core/install/zza;->d(Landroid/content/Intent;Lahj;)Lcom/google/android/play/core/install/zza;

    move-result-object p0

    iget-object p1, v3, Lcqk;->a:Lahj;

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p2

    const-string v0, "ListenerRegistryBroadcastReceiver.onReceive: %s"

    invoke-virtual {p1, v0, p2}, Lahj;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    monitor-enter v3

    :try_start_74
    new-instance p1, Ljava/util/HashSet;

    iget-object p2, v3, Lcqk;->d:Ljava/util/HashSet;

    invoke-direct {p1, p2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {p1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_92

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ls8f;

    invoke-virtual {p2, p0}, Ls8f;->a(Lcom/google/android/play/core/install/zza;)V
    :try_end_8e
    .catchall {:try_start_74 .. :try_end_8e} :catchall_8f

    goto :goto_7f

    :catchall_8f
    move-exception v0

    move-object p0, v0

    goto :goto_94

    :cond_92
    monitor-exit v3

    :goto_93
    return-void

    :goto_94
    :try_start_94
    monitor-exit v3
    :try_end_95
    .catchall {:try_start_94 .. :try_end_95} :catchall_8f

    throw p0

    :pswitch_96  #0x3
    if-eqz p2, :cond_9d

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    goto :goto_9e

    :cond_9d
    move-object p1, v2

    :goto_9e
    const-string p2, "android.media.AUDIO_BECOMING_NOISY"

    invoke-static {p1, p2}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_c4

    iget-object p1, p0, Lb42;->b:Ljava/lang/Object;

    check-cast p1, Lcom/anthropic/claude/bell/tts/i;

    iget-object p1, p1, Lcom/anthropic/claude/bell/tts/i;->q:Lmxh;

    if-eqz p1, :cond_b3

    sget-object p2, Lcom/anthropic/claude/analytics/events/ReadAloudEvents$ReadAloudInterruptReason;->ROUTE_CHANGE:Lcom/anthropic/claude/analytics/events/ReadAloudEvents$ReadAloudInterruptReason;

    invoke-virtual {p1, p2}, Lmxh;->o(Lcom/anthropic/claude/analytics/events/ReadAloudEvents$ReadAloudInterruptReason;)V

    :cond_b3
    invoke-static {}, Lvi9;->f()Lt65;

    move-result-object p1

    new-instance p2, Llf3;

    iget-object p0, p0, Lb42;->b:Ljava/lang/Object;

    check-cast p0, Lcom/anthropic/claude/bell/tts/i;

    invoke-direct {p2, p0, v2, v1}, Llf3;-><init>(Lcom/anthropic/claude/bell/tts/i;La75;I)V

    const/4 p0, 0x3

    invoke-static {p1, v2, v2, p2, p0}, Lao9;->S(Lua5;Lla5;Lxa5;Lq98;I)Lpfh;

    :cond_c4
    return-void

    :pswitch_c5  #0x2
    iget-object v0, p0, Lb42;->b:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Lrj6;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string v0, "android.intent.action.DOWNLOAD_COMPLETE"

    invoke-static {p1, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_dd

    goto :goto_104

    :cond_dd
    const-string p1, "extra_download_id"

    const-wide/16 v5, -0x1

    invoke-virtual {p2, p1, v5, v6}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v5

    iget-object p1, v4, Lrj6;->c:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_f2

    goto :goto_104

    :cond_f2
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object v7

    iget-object p0, v4, Lrj6;->d:Lt65;

    sget-object p1, Lxa5;->G:Lxa5;

    new-instance v3, Lqj6;

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v3 .. v9}, Lqj6;-><init>(Ljava/lang/Object;JLjava/lang/Object;La75;I)V

    invoke-static {p0, v2, p1, v3, v1}, Lao9;->S(Lua5;Lla5;Lxa5;Lq98;I)Lpfh;

    :goto_104
    return-void

    :pswitch_105  #0x1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lb42;->b:Ljava/lang/Object;

    check-cast p1, Lfy5;

    iget-object p1, p1, Lfy5;->G:Landroid/os/PowerManager;

    if-eqz p1, :cond_11b

    invoke-virtual {p1}, Landroid/os/PowerManager;->isPowerSaveMode()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    :cond_11b
    if-eqz v2, :cond_123

    iget-object p0, p0, Lb42;->b:Ljava/lang/Object;

    check-cast p0, Lfy5;

    iput-object v2, p0, Lfy5;->L:Ljava/lang/Boolean;

    :cond_123
    return-void

    :pswitch_124  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lb42;->b:Ljava/lang/Object;

    check-cast p0, Lul1;

    iget p1, p0, Lul1;->g:I

    packed-switch p1, :pswitch_data_22a

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_13b

    goto/16 :goto_21c

    :cond_13b
    invoke-static {}, Lyta;->c()Lyta;

    move-result-object p1

    sget v0, Lmkh;->a:I

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_21c

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    const v0, -0x46671f94

    if-eq p2, v0, :cond_16e

    const v0, -0x2b8fb65c

    if-eq p2, v0, :cond_15d

    goto/16 :goto_21c

    :cond_15d
    const-string p2, "android.intent.action.DEVICE_STORAGE_OK"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_167

    goto/16 :goto_21c

    :cond_167
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    goto/16 :goto_21c

    :cond_16e
    const-string p2, "android.intent.action.DEVICE_STORAGE_LOW"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_178

    goto/16 :goto_21c

    :cond_178
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    goto/16 :goto_21c

    :pswitch_17f  #0x1
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_187

    goto/16 :goto_21c

    :cond_187
    invoke-static {}, Lyta;->c()Lyta;

    move-result-object p1

    sget-object v0, Lxl1;->a:Ljava/lang/String;

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_21c

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    const v0, -0x7606c095  # -6.0004207E-33f

    if-eq p2, v0, :cond_1ba

    const v0, 0x1d398bfd

    if-eq p2, v0, :cond_1a9

    goto/16 :goto_21c

    :cond_1a9
    const-string p2, "android.intent.action.BATTERY_LOW"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1b3

    goto/16 :goto_21c

    :cond_1b3
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    goto/16 :goto_21c

    :cond_1ba
    const-string p2, "android.intent.action.BATTERY_OKAY"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1c3

    goto :goto_21c

    :cond_1c3
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    goto :goto_21c

    :pswitch_1c9  #0x0
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_1d0

    goto :goto_21c

    :cond_1d0
    invoke-static {}, Lyta;->c()Lyta;

    move-result-object p2

    sget-object v0, Lvl1;->a:Ljava/lang/String;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    sparse-switch p2, :sswitch_data_232

    goto :goto_21c

    :sswitch_1e1
    const-string p2, "android.intent.action.ACTION_POWER_CONNECTED"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1ea

    goto :goto_21c

    :cond_1ea
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    goto :goto_21c

    :sswitch_1f0
    const-string p2, "android.os.action.CHARGING"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1f9

    goto :goto_21c

    :cond_1f9
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    goto :goto_21c

    :sswitch_1ff
    const-string p2, "android.os.action.DISCHARGING"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_208

    goto :goto_21c

    :cond_208
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    goto :goto_21c

    :sswitch_20e
    const-string p2, "android.intent.action.ACTION_POWER_DISCONNECTED"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_217

    goto :goto_21c

    :cond_217
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Le35;->b(Ljava/lang/Object;)V

    :cond_21c
    :goto_21c
    return-void

    nop

    :pswitch_data_21e
    .packed-switch 0x0
        :pswitch_124  #00000000
        :pswitch_105  #00000001
        :pswitch_c5  #00000002
        :pswitch_96  #00000003
    .end packed-switch

    :pswitch_data_22a
    .packed-switch 0x0
        :pswitch_1c9  #00000000
        :pswitch_17f  #00000001
    .end packed-switch

    :sswitch_data_232
    .sparse-switch
        -0x7073f927 -> :sswitch_20e
        -0x3465cce -> :sswitch_1ff
        0x388694fe -> :sswitch_1f0
        0x3cbf870b -> :sswitch_1e1
    .end sparse-switch
.end method
