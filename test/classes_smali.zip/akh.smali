.class public final Lakh;
.super Lsyi;
.source "SourceFile"


# instance fields
.field public final l:I

.field public final m:Lca;

.field public final n:J


# direct methods
.method public constructor <init>(ILca;J)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lakh;->l:I

    iput-object p2, p0, Lakh;->m:Lca;

    iput-wide p3, p0, Lakh;->n:J

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_3

    goto :goto_22

    :cond_3
    instance-of v0, p1, Lakh;

    if-nez v0, :cond_8

    goto :goto_20

    :cond_8
    check-cast p1, Lakh;

    iget v0, p0, Lakh;->l:I

    iget v1, p1, Lakh;->l:I

    if-eq v0, v1, :cond_11

    goto :goto_20

    :cond_11
    iget-object v0, p0, Lakh;->m:Lca;

    iget-object v1, p1, Lakh;->m:Lca;

    if-eq v0, v1, :cond_18

    goto :goto_20

    :cond_18
    iget-wide v0, p0, Lakh;->n:J

    iget-wide p0, p1, Lakh;->n:J

    cmp-long p0, v0, p0

    if-eqz p0, :cond_22

    :goto_20
    const/4 p0, 0x0

    return p0

    :cond_22
    :goto_22
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 5

    iget v0, p0, Lakh;->l:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lakh;->m:Lca;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-wide v2, p0, Lakh;->n:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Action(frustrationCount="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lakh;->l:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", type="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lakh;->m:Lca;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", eventEndTimestampInNanos="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    iget-wide v2, p0, Lakh;->n:J

    invoke-static {v2, v3, v1, v0}, Lkec;->s(JLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
