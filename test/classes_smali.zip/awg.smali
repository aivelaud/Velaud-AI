.class public final Lawg;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbwg;


# static fields
.field public static final b:Lawg;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lawg;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lawg;->b:Lawg;

    return-void
.end method


# virtual methods
.method public final a(JJ)J
    .registers 5

    return-wide p1
.end method
