.class public abstract Lagc;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/high16 v2, 0x41400000  # 12.0f

    invoke-static {v2, v0, v1}, Lik5;->h(FFI)Ld6d;

    return-void
.end method

.method public static a(JJJJLzu4;I)Ldz5;
    .registers 31

    move-object/from16 v0, p8

    move/from16 v1, p9

    and-int/lit8 v2, v1, 0x1

    if-eqz v2, :cond_10

    sget-object v2, Lz6k;->h:Lln4;

    invoke-static {v2, v0}, Lmn4;->d(Lln4;Lzu4;)J

    move-result-wide v2

    move-wide v13, v2

    goto :goto_12

    :cond_10
    move-wide/from16 v13, p0

    :goto_12
    and-int/lit8 v2, v1, 0x2

    if-eqz v2, :cond_1a

    sget-wide v2, Lan4;->g:J

    move-wide v15, v2

    goto :goto_1c

    :cond_1a
    move-wide/from16 v15, p2

    :goto_1c
    sget-object v2, Lz6k;->g:Lln4;

    invoke-static {v2, v0}, Lmn4;->d(Lln4;Lzu4;)J

    move-result-wide v5

    and-int/lit8 v2, v1, 0x8

    if-eqz v2, :cond_2e

    sget-object v2, Lz6k;->n:Lln4;

    invoke-static {v2, v0}, Lmn4;->d(Lln4;Lzu4;)J

    move-result-wide v2

    move-wide v7, v2

    goto :goto_30

    :cond_2e
    move-wide/from16 v7, p4

    :goto_30
    sget-object v2, Lz6k;->k:Lln4;

    invoke-static {v2, v0}, Lmn4;->d(Lln4;Lzu4;)J

    move-result-wide v9

    sget-object v2, Lz6k;->o:Lln4;

    invoke-static {v2, v0}, Lmn4;->d(Lln4;Lzu4;)J

    move-result-wide v11

    and-int/lit16 v0, v1, 0x80

    if-eqz v0, :cond_43

    move-wide/from16 v19, v11

    goto :goto_45

    :cond_43
    move-wide/from16 v19, p6

    :goto_45
    new-instance v4, Ldz5;

    move-wide/from16 v17, v9

    invoke-direct/range {v4 .. v20}, Ldz5;-><init>(JJJJJJJJ)V

    return-object v4
.end method
