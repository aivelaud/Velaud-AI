.class public final synthetic Lb43;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lc98;


# direct methods
.method public synthetic constructor <init>(ILc98;)V
    .registers 3

    iput p1, p0, Lb43;->E:I

    iput-object p2, p0, Lb43;->F:Lc98;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    iget v0, p0, Lb43;->E:I

    iget-object p0, p0, Lb43;->F:Lc98;

    packed-switch v0, :pswitch_data_86

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_11  #0x5
    check-cast p1, Lc7h;

    invoke-interface {p0, p1}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lx6h;

    sget-object p1, Le7h;->c:Ljava/lang/Object;

    monitor-enter p1

    :try_start_1c
    sget-object v0, Le7h;->d:Lc7h;

    invoke-virtual {p0}, Lx6h;->g()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lc7h;->i(J)Lc7h;

    move-result-object v0

    sput-object v0, Le7h;->d:Lc7h;
    :try_end_28
    .catchall {:try_start_1c .. :try_end_28} :catchall_2a

    monitor-exit p1

    return-object p0

    :catchall_2a
    move-exception p0

    monitor-exit p1

    throw p0

    :pswitch_2d  #0x4
    check-cast p1, Lbq6;

    new-instance v0, Lcp6;

    invoke-direct {v0, p1, p0}, Lcp6;-><init>(Lbq6;Lc98;)V

    return-object v0

    :pswitch_35  #0x3
    check-cast p1, Lkp3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Lkp3;->a:Lro3;

    iget-object v0, v0, Lro3;->a:Ljava/lang/Object;

    instance-of v0, v0, Lfvg;

    if-eqz v0, :cond_44

    const/4 p0, 0x0

    goto :goto_4a

    :cond_44
    invoke-interface {p0, p1}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ltud;

    :goto_4a
    return-object p0

    :pswitch_4b  #0x2
    check-cast p1, Lc7a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Lc7a;->k()J

    move-result-wide v0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    long-to-int p1, v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lz2j;->a:Lz2j;

    return-object p0

    :pswitch_65  #0x1
    check-cast p1, Lc7a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {p0, p1}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lz2j;->a:Lz2j;

    return-object p0

    :pswitch_72  #0x0
    check-cast p1, Lg38;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lg38;->b()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-interface {p0, p1}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lz2j;->a:Lz2j;

    return-object p0

    nop

    :pswitch_data_86
    .packed-switch 0x0
        :pswitch_72  #00000000
        :pswitch_65  #00000001
        :pswitch_4b  #00000002
        :pswitch_35  #00000003
        :pswitch_2d  #00000004
        :pswitch_11  #00000005
    .end packed-switch
.end method
