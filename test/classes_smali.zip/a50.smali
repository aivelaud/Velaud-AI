.class public final La50;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public b:I

.field public c:Landroid/graphics/Shader;

.field public d:Lcx1;

.field public e:Lycd;


# direct methods
.method public constructor <init>(Landroid/graphics/Paint;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La50;->a:Landroid/graphics/Paint;

    const/4 p1, 0x3

    iput p1, p0, La50;->b:I

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 3

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0}, Landroid/graphics/Paint;->getStrokeCap()Landroid/graphics/Paint$Cap;

    move-result-object p0

    if-nez p0, :cond_a

    const/4 p0, -0x1

    goto :goto_12

    :cond_a
    sget-object v0, Lb50;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    :goto_12
    const/4 v0, 0x1

    if-eq p0, v0, :cond_1e

    const/4 v1, 0x2

    if-eq p0, v1, :cond_1d

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1c

    goto :goto_1e

    :cond_1c
    return v1

    :cond_1d
    return v0

    :cond_1e
    :goto_1e
    const/4 p0, 0x0

    return p0
.end method

.method public final b()I
    .registers 3

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0}, Landroid/graphics/Paint;->getStrokeJoin()Landroid/graphics/Paint$Join;

    move-result-object p0

    if-nez p0, :cond_a

    const/4 p0, -0x1

    goto :goto_12

    :cond_a
    sget-object v0, Lb50;->b:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    :goto_12
    const/4 v0, 0x1

    if-eq p0, v0, :cond_1e

    const/4 v1, 0x2

    if-eq p0, v1, :cond_1d

    const/4 v1, 0x3

    if-eq p0, v1, :cond_1c

    goto :goto_1e

    :cond_1c
    return v0

    :cond_1d
    return v1

    :cond_1e
    :goto_1e
    const/4 p0, 0x0

    return p0
.end method

.method public final c(F)V
    .registers 4

    const/high16 v0, 0x437f0000  # 255.0f

    mul-float/2addr p1, v0

    float-to-double v0, p1

    invoke-static {v0, v1}, Ljava/lang/Math;->rint(D)D

    move-result-wide v0

    double-to-float p1, v0

    float-to-int p1, p1

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public final d(I)V
    .registers 4

    iget v0, p0, La50;->b:I

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput p1, p0, La50;->b:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    if-lt v0, v1, :cond_17

    invoke-static {p1}, Letf;->i0(I)Landroid/graphics/BlendMode;

    move-result-object p1

    invoke-static {p0, p1}, Ll9k;->b(Landroid/graphics/Paint;Landroid/graphics/BlendMode;)V

    return-void

    :cond_17
    new-instance v0, Landroid/graphics/PorterDuffXfermode;

    invoke-static {p1}, Letf;->o0(I)Landroid/graphics/PorterDuff$Mode;

    move-result-object p1

    invoke-direct {v0, p1}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v0}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    return-void
.end method

.method public final e(J)V
    .registers 3

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-static {p1, p2}, Lor5;->Y(J)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setColor(I)V

    return-void
.end method

.method public final f(Lcx1;)V
    .registers 2

    iput-object p1, p0, La50;->d:Lcx1;

    if-eqz p1, :cond_7

    iget-object p1, p1, Lcx1;->a:Landroid/graphics/ColorFilter;

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    return-void
.end method

.method public final g(I)V
    .registers 3

    const/4 v0, 0x1

    if-nez p1, :cond_5

    move p1, v0

    goto :goto_6

    :cond_5
    const/4 p1, 0x0

    :goto_6
    xor-int/2addr p1, v0

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    return-void
.end method

.method public final h(Lycd;)V
    .registers 4

    move-object v0, p1

    check-cast v0, Li50;

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Li50;->a()Landroid/graphics/PathEffect;

    move-result-object v0

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    iget-object v1, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    iput-object p1, p0, La50;->e:Lycd;

    return-void
.end method

.method public final i(Landroid/graphics/Shader;)V
    .registers 2

    iput-object p1, p0, La50;->c:Landroid/graphics/Shader;

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    return-void
.end method

.method public final j(I)V
    .registers 3

    const/4 v0, 0x2

    if-ne p1, v0, :cond_6

    sget-object p1, Landroid/graphics/Paint$Cap;->SQUARE:Landroid/graphics/Paint$Cap;

    goto :goto_13

    :cond_6
    const/4 v0, 0x1

    if-ne p1, v0, :cond_c

    sget-object p1, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    goto :goto_13

    :cond_c
    if-nez p1, :cond_11

    sget-object p1, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    goto :goto_13

    :cond_11
    sget-object p1, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    :goto_13
    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    return-void
.end method

.method public final k(I)V
    .registers 3

    if-nez p1, :cond_5

    sget-object p1, Landroid/graphics/Paint$Join;->MITER:Landroid/graphics/Paint$Join;

    goto :goto_13

    :cond_5
    const/4 v0, 0x2

    if-ne p1, v0, :cond_b

    sget-object p1, Landroid/graphics/Paint$Join;->BEVEL:Landroid/graphics/Paint$Join;

    goto :goto_13

    :cond_b
    const/4 v0, 0x1

    if-ne p1, v0, :cond_11

    sget-object p1, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    goto :goto_13

    :cond_11
    sget-object p1, Landroid/graphics/Paint$Join;->MITER:Landroid/graphics/Paint$Join;

    :goto_13
    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    return-void
.end method

.method public final l(F)V
    .registers 2

    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    return-void
.end method

.method public final m(I)V
    .registers 3

    const/4 v0, 0x1

    if-ne p1, v0, :cond_6

    sget-object p1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    goto :goto_8

    :cond_6
    sget-object p1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    :goto_8
    iget-object p0, p0, La50;->a:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    return-void
.end method
