.class public final Lavf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lzuf;


# instance fields
.field public final E:Lc98;

.field public final F:Lrdc;

.field public G:Lrdc;


# direct methods
.method public constructor <init>(Ljava/util/Map;Lc98;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lavf;->E:Lc98;

    if-eqz p1, :cond_37

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_e

    goto :goto_37

    :cond_e
    new-instance p2, Lrdc;

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v0

    invoke-direct {p2, v0}, Lrdc;-><init>(I)V

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_38

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p2, v1, v0}, Lrdc;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1f

    :cond_37
    :goto_37
    const/4 p2, 0x0

    :cond_38
    iput-object p2, p0, Lavf;->F:Lrdc;

    return-void
.end method


# virtual methods
.method public final b(La98;Ljava/lang/String;)Lyuf;
    .registers 6

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x0

    :goto_5
    if-ge v1, v0, :cond_3b

    invoke-virtual {p2, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Lor5;->K(C)Z

    move-result v2

    if-nez v2, :cond_38

    iget-object v0, p0, Lavf;->G:Lrdc;

    if-nez v0, :cond_1e

    sget-object v0, Lowf;->a:[J

    new-instance v0, Lrdc;

    invoke-direct {v0}, Lrdc;-><init>()V

    iput-object v0, p0, Lavf;->G:Lrdc;

    :cond_1e
    invoke-virtual {v0, p2}, Lrdc;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-nez p0, :cond_2c

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, p2, p0}, Lrdc;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2c
    check-cast p0, Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance p0, Lmlc;

    const/4 v1, 0x5

    invoke-direct {p0, v1, v0, p2, p1}, Lmlc;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0

    :cond_38
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_3b
    const-string p0, "Registered key is empty or blank"

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final d(Ljava/lang/Object;)Z
    .registers 2

    iget-object p0, p0, Lavf;->E:Lc98;

    invoke-interface {p0, p1}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final e()Ljava/util/Map;
    .registers 28

    move-object/from16 v0, p0

    iget-object v1, v0, Lavf;->F:Lrdc;

    if-nez v1, :cond_d

    iget-object v2, v0, Lavf;->G:Lrdc;

    if-nez v2, :cond_d

    sget-object v0, Law6;->E:Law6;

    return-object v0

    :cond_d
    const/4 v2, 0x0

    if-eqz v1, :cond_13

    iget v3, v1, Lrdc;->e:I

    goto :goto_14

    :cond_13
    move v3, v2

    :goto_14
    iget-object v4, v0, Lavf;->G:Lrdc;

    if-eqz v4, :cond_1b

    iget v4, v4, Lrdc;->e:I

    goto :goto_1c

    :cond_1b
    move v4, v2

    :goto_1c
    add-int/2addr v3, v4

    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4, v3}, Ljava/util/HashMap;-><init>(I)V

    const/4 v3, 0x7

    const-wide v9, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    const/16 v11, 0x8

    if-eqz v1, :cond_8e

    iget-object v12, v1, Lrdc;->b:[Ljava/lang/Object;

    iget-object v13, v1, Lrdc;->c:[Ljava/lang/Object;

    iget-object v1, v1, Lrdc;->a:[J

    array-length v14, v1

    add-int/lit8 v14, v14, -0x2

    if-ltz v14, :cond_8e

    move v15, v2

    const-wide/16 v16, 0x80

    :goto_3a
    aget-wide v5, v1, v15

    const-wide/16 v18, 0xff

    not-long v7, v5

    shl-long/2addr v7, v3

    and-long/2addr v7, v5

    and-long/2addr v7, v9

    cmp-long v7, v7, v9

    if-eqz v7, :cond_81

    sub-int v7, v15, v14

    not-int v7, v7

    ushr-int/lit8 v7, v7, 0x1f

    rsub-int/lit8 v7, v7, 0x8

    move v8, v2

    :goto_4e
    if-ge v8, v7, :cond_7a

    and-long v20, v5, v18

    cmp-long v20, v20, v16

    if-gez v20, :cond_6e

    shl-int/lit8 v20, v15, 0x3

    add-int v20, v20, v8

    aget-object v21, v12, v20

    aget-object v20, v13, v20

    move/from16 v22, v3

    move-object/from16 v3, v20

    check-cast v3, Ljava/util/List;

    move-wide/from16 v23, v9

    move-object/from16 v9, v21

    check-cast v9, Ljava/lang/String;

    invoke-interface {v4, v9, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_72

    :cond_6e
    move/from16 v22, v3

    move-wide/from16 v23, v9

    :goto_72
    shr-long/2addr v5, v11

    add-int/lit8 v8, v8, 0x1

    move/from16 v3, v22

    move-wide/from16 v9, v23

    goto :goto_4e

    :cond_7a
    move/from16 v22, v3

    move-wide/from16 v23, v9

    if-ne v7, v11, :cond_96

    goto :goto_85

    :cond_81
    move/from16 v22, v3

    move-wide/from16 v23, v9

    :goto_85
    if-eq v15, v14, :cond_96

    add-int/lit8 v15, v15, 0x1

    move/from16 v3, v22

    move-wide/from16 v9, v23

    goto :goto_3a

    :cond_8e
    move/from16 v22, v3

    move-wide/from16 v23, v9

    const-wide/16 v16, 0x80

    const-wide/16 v18, 0xff

    :cond_96
    iget-object v1, v0, Lavf;->G:Lrdc;

    if-eqz v1, :cond_158

    iget-object v3, v1, Lrdc;->b:[Ljava/lang/Object;

    iget-object v5, v1, Lrdc;->c:[Ljava/lang/Object;

    iget-object v1, v1, Lrdc;->a:[J

    array-length v6, v1

    add-int/lit8 v6, v6, -0x2

    if-ltz v6, :cond_158

    move v7, v2

    :goto_a6
    aget-wide v8, v1, v7

    not-long v12, v8

    shl-long v12, v12, v22

    and-long/2addr v12, v8

    and-long v12, v12, v23

    cmp-long v10, v12, v23

    if-eqz v10, :cond_14b

    sub-int v10, v7, v6

    not-int v10, v10

    ushr-int/lit8 v10, v10, 0x1f

    rsub-int/lit8 v10, v10, 0x8

    move v12, v2

    :goto_ba
    if-ge v12, v10, :cond_145

    and-long v13, v8, v18

    cmp-long v13, v13, v16

    if-gez v13, :cond_136

    shl-int/lit8 v13, v7, 0x3

    add-int/2addr v13, v12

    aget-object v14, v3, v13

    aget-object v13, v5, v13

    check-cast v13, Ljava/util/List;

    check-cast v14, Ljava/lang/String;

    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v15

    const/16 v20, 0x0

    move/from16 v21, v11

    const/4 v11, 0x1

    if-ne v15, v11, :cond_100

    invoke-interface {v13, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La98;

    invoke-interface {v11}, La98;->a()Ljava/lang/Object;

    move-result-object v11

    if-eqz v11, :cond_f5

    invoke-virtual {v0, v11}, Lavf;->d(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_f8

    filled-new-array {v11}, [Ljava/lang/Object;

    move-result-object v11

    invoke-static {v11}, Loz4;->l([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v11

    invoke-interface {v4, v14, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_f5
    move-object/from16 v26, v1

    goto :goto_13a

    :cond_f8
    invoke-static {v11}, Lin6;->r(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lty9;->f(Ljava/lang/Object;)V

    return-object v20

    :cond_100
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v11

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15, v11}, Ljava/util/ArrayList;-><init>(I)V

    :goto_109
    if-ge v2, v11, :cond_130

    invoke-interface {v13, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v25

    check-cast v25, La98;

    move-object/from16 v26, v1

    invoke-interface/range {v25 .. v25}, La98;->a()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_128

    invoke-virtual {v0, v1}, Lavf;->d(Ljava/lang/Object;)Z

    move-result v25

    if-eqz v25, :cond_120

    goto :goto_128

    :cond_120
    invoke-static {v1}, Lin6;->r(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lty9;->f(Ljava/lang/Object;)V

    return-object v20

    :cond_128
    :goto_128
    invoke-virtual {v15, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    move-object/from16 v1, v26

    goto :goto_109

    :cond_130
    move-object/from16 v26, v1

    invoke-interface {v4, v14, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_13a

    :cond_136
    move-object/from16 v26, v1

    move/from16 v21, v11

    :goto_13a
    shr-long v8, v8, v21

    add-int/lit8 v12, v12, 0x1

    move/from16 v11, v21

    move-object/from16 v1, v26

    const/4 v2, 0x0

    goto/16 :goto_ba

    :cond_145
    move-object/from16 v26, v1

    move v1, v11

    if-ne v10, v1, :cond_158

    goto :goto_14e

    :cond_14b
    move-object/from16 v26, v1

    move v1, v11

    :goto_14e
    if-eq v7, v6, :cond_158

    add-int/lit8 v7, v7, 0x1

    move v11, v1

    move-object/from16 v1, v26

    const/4 v2, 0x0

    goto/16 :goto_a6

    :cond_158
    return-object v4
.end method

.method public final f(Ljava/lang/String;)Ljava/lang/Object;
    .registers 7

    const/4 v0, 0x0

    iget-object p0, p0, Lavf;->F:Lrdc;

    if-eqz p0, :cond_c

    invoke-virtual {p0, p1}, Lrdc;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    goto :goto_d

    :cond_c
    move-object v1, v0

    :goto_d
    move-object v2, v1

    check-cast v2, Ljava/util/Collection;

    if-eqz v2, :cond_43

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_19

    goto :goto_43

    :cond_19
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    if-le v0, v2, :cond_3d

    if-eqz p0, :cond_3d

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v0

    invoke-interface {v1, v2, v0}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v0

    invoke-virtual {p0, p1}, Lrdc;->f(Ljava/lang/Object;)I

    move-result v2

    if-gez v2, :cond_31

    not-int v2, v2

    :cond_31
    iget-object v3, p0, Lrdc;->c:[Ljava/lang/Object;

    aget-object v4, v3, v2

    iget-object p0, p0, Lrdc;->b:[Ljava/lang/Object;

    aput-object p1, p0, v2

    aput-object v0, v3, v2

    check-cast v4, Ljava/util/List;

    :cond_3d
    const/4 p0, 0x0

    invoke-interface {v1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_43
    :goto_43
    return-object v0
.end method
