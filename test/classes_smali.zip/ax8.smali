.class public final Lax8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lax8;->a:Ljava/lang/String;

    iput-object p2, p0, Lax8;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lax8;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lax8;

    iget-object v1, p0, Lax8;->a:Ljava/lang/String;

    iget-object v3, p1, Lax8;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lcom/anthropic/claude/types/strings/AccountId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object p0, p0, Lax8;->b:Ljava/lang/String;

    iget-object p1, p1, Lax8;->b:Ljava/lang/String;

    invoke-static {p0, p1}, Lcom/anthropic/claude/types/strings/OrganizationId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_22

    return v2

    :cond_22
    return v0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lax8;->a:Ljava/lang/String;

    invoke-static {v0}, Lcom/anthropic/claude/types/strings/AccountId;->hashCode-impl(Ljava/lang/String;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lax8;->b:Ljava/lang/String;

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/OrganizationId;->hashCode-impl(Ljava/lang/String;)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    iget-object v0, p0, Lax8;->a:Ljava/lang/String;

    invoke-static {v0}, Lcom/anthropic/claude/types/strings/AccountId;->toString-impl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object p0, p0, Lax8;->b:Ljava/lang/String;

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/OrganizationId;->toString-impl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v1, ", organizationId="

    const-string v2, ")"

    const-string v3, "HealthMetricOwner(accountId="

    invoke-static {v3, v0, v1, p0, v2}, Lti6;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
