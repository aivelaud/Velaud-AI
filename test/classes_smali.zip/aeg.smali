.class public final Laeg;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Executor;


# instance fields
.field public final synthetic E:I

.field public final F:Ljava/util/concurrent/Executor;

.field public final G:Ljava/util/ArrayDeque;

.field public H:Ljava/lang/Runnable;

.field public final I:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Executor;I)V
    .registers 3

    iput p2, p0, Laeg;->E:I

    packed-switch p2, :pswitch_data_30

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laeg;->F:Ljava/util/concurrent/Executor;

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, Laeg;->G:Ljava/util/ArrayDeque;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laeg;->I:Ljava/lang/Object;

    return-void

    :pswitch_19  #0x1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laeg;->F:Ljava/util/concurrent/Executor;

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, Laeg;->G:Ljava/util/ArrayDeque;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laeg;->I:Ljava/lang/Object;

    return-void

    :pswitch_data_30
    .packed-switch 0x1
        :pswitch_19  #00000001
    .end packed-switch
.end method


# virtual methods
.method public final a()V
    .registers 4

    iget v0, p0, Laeg;->E:I

    packed-switch v0, :pswitch_data_34

    iget-object v0, p0, Laeg;->I:Ljava/lang/Object;

    monitor-enter v0

    :try_start_8
    iget-object v1, p0, Laeg;->G:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/lang/Runnable;

    iput-object v2, p0, Laeg;->H:Ljava/lang/Runnable;

    if-eqz v1, :cond_1d

    iget-object p0, p0, Laeg;->F:Ljava/util/concurrent/Executor;

    invoke-interface {p0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_1a
    .catchall {:try_start_8 .. :try_end_1a} :catchall_1b

    goto :goto_1d

    :catchall_1b
    move-exception p0

    goto :goto_1f

    :cond_1d
    :goto_1d
    monitor-exit v0

    return-void

    :goto_1f
    monitor-exit v0

    throw p0

    :pswitch_21  #0x0
    iget-object v0, p0, Laeg;->G:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    iput-object v0, p0, Laeg;->H:Ljava/lang/Runnable;

    if-eqz v0, :cond_32

    iget-object p0, p0, Laeg;->F:Ljava/util/concurrent/Executor;

    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_32
    return-void

    nop

    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_21  #00000000
    .end packed-switch
.end method

.method public final execute(Ljava/lang/Runnable;)V
    .registers 6

    iget v0, p0, Laeg;->E:I

    packed-switch v0, :pswitch_data_40

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Laeg;->I:Ljava/lang/Object;

    monitor-enter v0

    :try_start_b
    iget-object v1, p0, Laeg;->G:Ljava/util/ArrayDeque;

    new-instance v2, Losi;

    const/4 v3, 0x0

    invoke-direct {v2, p1, v3, p0}, Losi;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    iget-object p1, p0, Laeg;->H:Ljava/lang/Runnable;

    if-nez p1, :cond_20

    invoke-virtual {p0}, Laeg;->a()V
    :try_end_1d
    .catchall {:try_start_b .. :try_end_1d} :catchall_1e

    goto :goto_20

    :catchall_1e
    move-exception p0

    goto :goto_22

    :cond_20
    :goto_20
    monitor-exit v0

    return-void

    :goto_22
    monitor-exit v0

    throw p0

    :pswitch_24  #0x0
    iget-object v0, p0, Laeg;->I:Ljava/lang/Object;

    monitor-enter v0

    :try_start_27
    iget-object v1, p0, Laeg;->G:Ljava/util/ArrayDeque;

    new-instance v2, Leia;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3, p1}, Leia;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, Laeg;->H:Ljava/lang/Runnable;

    if-nez p1, :cond_3c

    invoke-virtual {p0}, Laeg;->a()V

    goto :goto_3c

    :catchall_3a
    move-exception p0

    goto :goto_3e

    :cond_3c
    :goto_3c
    monitor-exit v0

    return-void

    :goto_3e
    monitor-exit v0
    :try_end_3f
    .catchall {:try_start_27 .. :try_end_3f} :catchall_3a

    throw p0

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_24  #00000000
    .end packed-switch
.end method
