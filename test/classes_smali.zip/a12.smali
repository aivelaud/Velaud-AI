.class public final La12;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le46;


# virtual methods
.method public final b(Ljavax/net/ssl/SSLSocket;)Z
    .registers 2

    sget-boolean p0, Lc12;->b:Z

    const/4 p0, 0x0

    return p0
.end method

.method public final h(Ljavax/net/ssl/SSLSocket;)Le8h;
    .registers 2

    new-instance p0, Lc12;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-object p0
.end method
