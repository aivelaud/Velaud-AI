.class public final La6j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/l6;


# instance fields
.field public volatile a:Ljava/util/List;


# direct methods
.method public constructor <init>()V
    .registers 2

    sget-object v0, Lyv6;->E:Lyv6;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, La6j;->a:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public a(Lio/sentry/protocol/e0;Lio/sentry/l0;)Lio/sentry/protocol/e0;
    .registers 4

    iget-object p0, p0, La6j;->a:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_9

    return-object p1

    :cond_9
    check-cast p0, Ljava/lang/Iterable;

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lio/sentry/l6;

    invoke-interface {v0, p1, p2}, Lio/sentry/l6;->a(Lio/sentry/protocol/e0;Lio/sentry/l0;)Lio/sentry/protocol/e0;

    move-result-object p1

    if-nez p1, :cond_f

    const/4 p0, 0x0

    return-object p0

    :cond_23
    return-object p1
.end method
