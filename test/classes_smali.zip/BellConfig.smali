.class public final LBellConfig;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Leeg;
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\u000e\n\u0002\b\u0014\b\u0087\b\u0018\u0000 62\u00020\u0001:\u000278BM\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0007\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\n\u0010\u000bBU\b\u0010\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\u000e¢\u0006\u0004\b\n\u0010\u0010J\'\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u0011\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0014H\u0001¢\u0006\u0004\b\u0017\u0010\u0018J\u0010\u0010\u001a\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u001a\u0010\u001bJ\u0012\u0010\u001c\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u001c\u0010\u001dJ\u0012\u0010\u001e\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u001e\u0010\u001dJ\u0012\u0010\u001f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u001f\u0010\u001dJ\u0012\u0010 \u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b \u0010!J\u0012\u0010\"\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b\"\u0010!JV\u0010#\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0007HÆ\u0001¢\u0006\u0004\b#\u0010$J\u0010\u0010&\u001a\u00020%HÖ\u0001¢\u0006\u0004\b&\u0010\'J\u0010\u0010(\u001a\u00020\fHÖ\u0001¢\u0006\u0004\b(\u0010)J\u001a\u0010+\u001a\u00020\u00022\b\u0010*\u001a\u0004\u0018\u00010\u0001HÖ\u0003¢\u0006\u0004\b+\u0010,R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0003\u0010-\u001a\u0004\b.\u0010\u001bR\u0019\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b\u0004\u0010/\u001a\u0004\b0\u0010\u001dR\u0019\u0010\u0005\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b\u0005\u0010/\u001a\u0004\b1\u0010\u001dR\u0019\u0010\u0006\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010/\u001a\u0004\b2\u0010\u001dR\u0019\u0010\b\u001a\u0004\u0018\u00010\u00078\u0006¢\u0006\f\n\u0004\b\b\u00103\u001a\u0004\b4\u0010!R\u0019\u0010\t\u001a\u0004\u0018\u00010\u00078\u0006¢\u0006\f\n\u0004\b\t\u00103\u001a\u0004\b5\u0010!¨\u00069"
    }
    d2 = {
        "LBellConfig;",
        "",
        "",
        "enabled",
        "show_tooltip",
        "server_interrupt_enabled",
        "auto_send_enabled",
        "",
        "ptt_background_stop_delay_ms",
        "hold_park_grace_ms",
        "<init>",
        "(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;)V",
        "",
        "seen0",
        "Lleg;",
        "serializationConstructorMarker",
        "(IZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;Lleg;)V",
        "self",
        "Llv4;",
        "output",
        "Lkotlinx/serialization/descriptors/SerialDescriptor;",
        "serialDesc",
        "Lz2j;",
        "write$Self$models",
        "(LBellConfig;Llv4;Lkotlinx/serialization/descriptors/SerialDescriptor;)V",
        "write$Self",
        "component1",
        "()Z",
        "component2",
        "()Ljava/lang/Boolean;",
        "component3",
        "component4",
        "component5",
        "()Ljava/lang/Long;",
        "component6",
        "copy",
        "(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;)LBellConfig;",
        "",
        "toString",
        "()Ljava/lang/String;",
        "hashCode",
        "()I",
        "other",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Z",
        "getEnabled",
        "Ljava/lang/Boolean;",
        "getShow_tooltip",
        "getServer_interrupt_enabled",
        "getAuto_send_enabled",
        "Ljava/lang/Long;",
        "getPtt_background_stop_delay_ms",
        "getHold_park_grace_ms",
        "Companion",
        "on1",
        "pn1",
        "models"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lpn1;


# instance fields
.field private final auto_send_enabled:Ljava/lang/Boolean;

.field private final enabled:Z

.field private final hold_park_grace_ms:Ljava/lang/Long;

.field private final ptt_background_stop_delay_ms:Ljava/lang/Long;

.field private final server_interrupt_enabled:Ljava/lang/Boolean;

.field private final show_tooltip:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lpn1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LBellConfig;->Companion:Lpn1;

    return-void
.end method

.method public constructor <init>()V
    .registers 10

    .line 63
    const/16 v7, 0x3f

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v8}, LBellConfig;-><init>(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;ILry5;)V

    return-void
.end method

.method public synthetic constructor <init>(IZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;Lleg;)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    and-int/lit8 p8, p1, 0x1

    if-nez p8, :cond_8

    const/4 p2, 0x0

    :cond_8
    iput-boolean p2, p0, LBellConfig;->enabled:Z

    and-int/lit8 p2, p1, 0x2

    if-nez p2, :cond_13

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object p2, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    goto :goto_15

    :cond_13
    iput-object p3, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    :goto_15
    and-int/lit8 p2, p1, 0x4

    if-nez p2, :cond_1e

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object p2, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    goto :goto_20

    :cond_1e
    iput-object p4, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    :goto_20
    and-int/lit8 p2, p1, 0x8

    if-nez p2, :cond_29

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object p2, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    goto :goto_2b

    :cond_29
    iput-object p5, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    :goto_2b
    and-int/lit8 p2, p1, 0x10

    const/4 p3, 0x0

    if-nez p2, :cond_33

    iput-object p3, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    goto :goto_35

    :cond_33
    iput-object p6, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    :goto_35
    and-int/lit8 p1, p1, 0x20

    if-nez p1, :cond_3c

    iput-object p3, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    return-void

    :cond_3c
    iput-object p7, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    return-void
.end method

.method public constructor <init>(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;)V
    .registers 7

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 65
    iput-boolean p1, p0, LBellConfig;->enabled:Z

    .line 66
    iput-object p2, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    .line 67
    iput-object p3, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    .line 68
    iput-object p4, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    .line 69
    iput-object p5, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    .line 70
    iput-object p6, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;ILry5;)V
    .registers 10

    and-int/lit8 p8, p7, 0x1

    if-eqz p8, :cond_5

    const/4 p1, 0x0

    :cond_5
    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_b

    .line 71
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    :cond_b
    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_11

    .line 72
    sget-object p3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    :cond_11
    and-int/lit8 p8, p7, 0x8

    if-eqz p8, :cond_17

    .line 73
    sget-object p4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    :cond_17
    and-int/lit8 p8, p7, 0x10

    const/4 v0, 0x0

    if-eqz p8, :cond_1d

    move-object p5, v0

    :cond_1d
    and-int/lit8 p7, p7, 0x20

    if-eqz p7, :cond_29

    move-object p8, v0

    move-object p6, p4

    move-object p7, p5

    move-object p4, p2

    move-object p5, p3

    move-object p2, p0

    move p3, p1

    goto :goto_30

    :cond_29
    move-object p8, p6

    move-object p7, p5

    move-object p5, p3

    move-object p6, p4

    move p3, p1

    move-object p4, p2

    move-object p2, p0

    .line 74
    :goto_30
    invoke-direct/range {p2 .. p8}, LBellConfig;-><init>(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;)V

    return-void
.end method

.method public static synthetic copy$default(LBellConfig;ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;ILjava/lang/Object;)LBellConfig;
    .registers 9

    and-int/lit8 p8, p7, 0x1

    if-eqz p8, :cond_6

    iget-boolean p1, p0, LBellConfig;->enabled:Z

    :cond_6
    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_c

    iget-object p2, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    :cond_c
    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_12

    iget-object p3, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    :cond_12
    and-int/lit8 p8, p7, 0x8

    if-eqz p8, :cond_18

    iget-object p4, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    :cond_18
    and-int/lit8 p8, p7, 0x10

    if-eqz p8, :cond_1e

    iget-object p5, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    :cond_1e
    and-int/lit8 p7, p7, 0x20

    if-eqz p7, :cond_24

    iget-object p6, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    :cond_24
    move-object p7, p5

    move-object p8, p6

    move-object p5, p3

    move-object p6, p4

    move p3, p1

    move-object p4, p2

    move-object p2, p0

    invoke-virtual/range {p2 .. p8}, LBellConfig;->copy(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;)LBellConfig;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic write$Self$models(LBellConfig;Llv4;Lkotlinx/serialization/descriptors/SerialDescriptor;)V
    .registers 6

    invoke-interface {p1, p2}, Llv4;->E(Lkotlinx/serialization/descriptors/SerialDescriptor;)Z

    move-result v0

    if-eqz v0, :cond_7

    goto :goto_b

    :cond_7
    iget-boolean v0, p0, LBellConfig;->enabled:Z

    if-eqz v0, :cond_11

    :goto_b
    iget-boolean v0, p0, LBellConfig;->enabled:Z

    const/4 v1, 0x0

    invoke-interface {p1, p2, v1, v0}, Llv4;->p(Lkotlinx/serialization/descriptors/SerialDescriptor;IZ)V

    :cond_11
    invoke-interface {p1, p2}, Llv4;->E(Lkotlinx/serialization/descriptors/SerialDescriptor;)Z

    move-result v0

    if-eqz v0, :cond_18

    goto :goto_22

    :cond_18
    iget-object v0, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2a

    :goto_22
    sget-object v0, Lsz1;->a:Lsz1;

    iget-object v1, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    const/4 v2, 0x1

    invoke-interface {p1, p2, v2, v0, v1}, Llv4;->B(Lkotlinx/serialization/descriptors/SerialDescriptor;ILpeg;Ljava/lang/Object;)V

    :cond_2a
    invoke-interface {p1, p2}, Llv4;->E(Lkotlinx/serialization/descriptors/SerialDescriptor;)Z

    move-result v0

    if-eqz v0, :cond_31

    goto :goto_3b

    :cond_31
    iget-object v0, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43

    :goto_3b
    sget-object v0, Lsz1;->a:Lsz1;

    iget-object v1, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    const/4 v2, 0x2

    invoke-interface {p1, p2, v2, v0, v1}, Llv4;->B(Lkotlinx/serialization/descriptors/SerialDescriptor;ILpeg;Ljava/lang/Object;)V

    :cond_43
    invoke-interface {p1, p2}, Llv4;->E(Lkotlinx/serialization/descriptors/SerialDescriptor;)Z

    move-result v0

    if-eqz v0, :cond_4a

    goto :goto_54

    :cond_4a
    iget-object v0, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5c

    :goto_54
    sget-object v0, Lsz1;->a:Lsz1;

    iget-object v1, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    const/4 v2, 0x3

    invoke-interface {p1, p2, v2, v0, v1}, Llv4;->B(Lkotlinx/serialization/descriptors/SerialDescriptor;ILpeg;Ljava/lang/Object;)V

    :cond_5c
    invoke-interface {p1, p2}, Llv4;->E(Lkotlinx/serialization/descriptors/SerialDescriptor;)Z

    move-result v0

    if-eqz v0, :cond_63

    goto :goto_67

    :cond_63
    iget-object v0, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    if-eqz v0, :cond_6f

    :goto_67
    sget-object v0, Leya;->a:Leya;

    iget-object v1, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    const/4 v2, 0x4

    invoke-interface {p1, p2, v2, v0, v1}, Llv4;->B(Lkotlinx/serialization/descriptors/SerialDescriptor;ILpeg;Ljava/lang/Object;)V

    :cond_6f
    invoke-interface {p1, p2}, Llv4;->E(Lkotlinx/serialization/descriptors/SerialDescriptor;)Z

    move-result v0

    if-eqz v0, :cond_76

    goto :goto_7a

    :cond_76
    iget-object v0, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    if-eqz v0, :cond_82

    :goto_7a
    sget-object v0, Leya;->a:Leya;

    iget-object p0, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    const/4 v1, 0x5

    invoke-interface {p1, p2, v1, v0, p0}, Llv4;->B(Lkotlinx/serialization/descriptors/SerialDescriptor;ILpeg;Ljava/lang/Object;)V

    :cond_82
    return-void
.end method


# virtual methods
.method public final component1()Z
    .registers 1

    iget-boolean p0, p0, LBellConfig;->enabled:Z

    return p0
.end method

.method public final component2()Ljava/lang/Boolean;
    .registers 1

    iget-object p0, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final component3()Ljava/lang/Boolean;
    .registers 1

    iget-object p0, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final component4()Ljava/lang/Boolean;
    .registers 1

    iget-object p0, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final component5()Ljava/lang/Long;
    .registers 1

    iget-object p0, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    return-object p0
.end method

.method public final component6()Ljava/lang/Long;
    .registers 1

    iget-object p0, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    return-object p0
.end method

.method public final copy(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;)LBellConfig;
    .registers 7

    new-instance p0, LBellConfig;

    invoke-direct/range {p0 .. p6}, LBellConfig;-><init>(ZLjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Long;Ljava/lang/Long;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, LBellConfig;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, LBellConfig;

    iget-boolean v1, p0, LBellConfig;->enabled:Z

    iget-boolean v3, p1, LBellConfig;->enabled:Z

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget-object v1, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    iget-object v3, p1, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    return v2

    :cond_1e
    iget-object v1, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    iget-object v3, p1, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_29

    return v2

    :cond_29
    iget-object v1, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    iget-object v3, p1, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_34

    return v2

    :cond_34
    iget-object v1, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    iget-object v3, p1, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3f

    return v2

    :cond_3f
    iget-object p0, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    iget-object p1, p1, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4a

    return v2

    :cond_4a
    return v0
.end method

.method public final getAuto_send_enabled()Ljava/lang/Boolean;
    .registers 1

    iget-object p0, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final getEnabled()Z
    .registers 1

    iget-boolean p0, p0, LBellConfig;->enabled:Z

    return p0
.end method

.method public final getHold_park_grace_ms()Ljava/lang/Long;
    .registers 1

    iget-object p0, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    return-object p0
.end method

.method public final getPtt_background_stop_delay_ms()Ljava/lang/Long;
    .registers 1

    iget-object p0, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    return-object p0
.end method

.method public final getServer_interrupt_enabled()Ljava/lang/Boolean;
    .registers 1

    iget-object p0, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final getShow_tooltip()Ljava/lang/Boolean;
    .registers 1

    iget-object p0, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    return-object p0
.end method

.method public hashCode()I
    .registers 4

    iget-boolean v0, p0, LBellConfig;->enabled:Z

    invoke-static {v0}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    const/4 v2, 0x0

    if-nez v1, :cond_f

    move v1, v2

    goto :goto_13

    :cond_f
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_13
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    if-nez v1, :cond_1c

    move v1, v2

    goto :goto_20

    :cond_1c
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_20
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    if-nez v1, :cond_29

    move v1, v2

    goto :goto_2d

    :cond_29
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_2d
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    if-nez v1, :cond_36

    move v1, v2

    goto :goto_3a

    :cond_36
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_3a
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    if-nez p0, :cond_42

    goto :goto_46

    :cond_42
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_46
    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 8

    iget-boolean v0, p0, LBellConfig;->enabled:Z

    iget-object v1, p0, LBellConfig;->show_tooltip:Ljava/lang/Boolean;

    iget-object v2, p0, LBellConfig;->server_interrupt_enabled:Ljava/lang/Boolean;

    iget-object v3, p0, LBellConfig;->auto_send_enabled:Ljava/lang/Boolean;

    iget-object v4, p0, LBellConfig;->ptt_background_stop_delay_ms:Ljava/lang/Long;

    iget-object p0, p0, LBellConfig;->hold_park_grace_ms:Ljava/lang/Long;

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "BellConfig(enabled="

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v0, ", show_tooltip="

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", server_interrupt_enabled="

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", auto_send_enabled="

    const-string v1, ", ptt_background_stop_delay_ms="

    invoke-static {v5, v2, v0, v3, v1}, Ls0i;->z(Ljava/lang/StringBuilder;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", hold_park_grace_ms="

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
