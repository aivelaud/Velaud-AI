.class public abstract Lajf;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lnw4;

.field public static final b:Lnw4;

.field public static final c:Landroidx/compose/material3/d;

.field public static final d:Landroidx/compose/material3/d;


# direct methods
.method static constructor <clinit>()V
    .registers 13

    new-instance v0, Ljre;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, Ljre;-><init>(I)V

    new-instance v1, Lnw4;

    invoke-direct {v1, v0}, Lnw4;-><init>(La98;)V

    sput-object v1, Lajf;->a:Lnw4;

    new-instance v0, Ld8e;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Ld8e;-><init>(I)V

    new-instance v1, Lnw4;

    invoke-direct {v1, v0}, Lnw4;-><init>(Lc98;)V

    sput-object v1, Lajf;->b:Lnw4;

    new-instance v2, Landroidx/compose/material3/d;

    sget-wide v5, Lan4;->h:J

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v3, 0x1

    const/high16 v4, 0x7fc00000  # Float.NaN

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct/range {v2 .. v11}, Landroidx/compose/material3/d;-><init>(ZFJLysg;ZZZZ)V

    sput-object v2, Lajf;->c:Landroidx/compose/material3/d;

    new-instance v3, Landroidx/compose/material3/d;

    const/4 v12, 0x1

    const/4 v4, 0x0

    move-wide v6, v5

    const/high16 v5, 0x7fc00000  # Float.NaN

    const/4 v8, 0x0

    invoke-direct/range {v3 .. v12}, Landroidx/compose/material3/d;-><init>(ZFJLysg;ZZZZ)V

    sput-object v3, Lajf;->d:Landroidx/compose/material3/d;

    return-void
.end method

.method public static a(ZFJLysg;ZI)Landroidx/compose/material3/d;
    .registers 20

    move/from16 v0, p6

    and-int/lit8 v1, v0, 0x1

    const/4 v2, 0x1

    if-eqz v1, :cond_9

    move v4, v2

    goto :goto_a

    :cond_9
    move v4, p0

    :goto_a
    and-int/lit8 p0, v0, 0x2

    const/high16 v1, 0x7fc00000  # Float.NaN

    if-eqz p0, :cond_12

    move v5, v1

    goto :goto_13

    :cond_12
    move v5, p1

    :goto_13
    and-int/lit8 p0, v0, 0x4

    if-eqz p0, :cond_1b

    sget-wide p0, Lan4;->h:J

    move-wide v6, p0

    goto :goto_1c

    :cond_1b
    move-wide v6, p2

    :goto_1c
    and-int/lit8 p0, v0, 0x8

    if-eqz p0, :cond_23

    const/4 p0, 0x0

    move-object v8, p0

    goto :goto_25

    :cond_23
    move-object/from16 v8, p4

    :goto_25
    and-int/lit8 p0, v0, 0x10

    const/4 p1, 0x0

    if-eqz p0, :cond_2c

    move v9, v2

    goto :goto_2d

    :cond_2c
    move v9, p1

    :goto_2d
    and-int/lit8 p0, v0, 0x20

    if-eqz p0, :cond_33

    move v10, v2

    goto :goto_35

    :cond_33
    move/from16 v10, p5

    :goto_35
    and-int/lit8 p0, v0, 0x40

    if-eqz p0, :cond_3b

    move v11, v2

    goto :goto_3c

    :cond_3b
    move v11, p1

    :goto_3c
    and-int/lit16 p0, v0, 0x80

    if-eqz p0, :cond_42

    move v12, v2

    goto :goto_43

    :cond_42
    move v12, p1

    :goto_43
    invoke-static {v5, v1}, Luj6;->b(FF)Z

    move-result p0

    if-eqz p0, :cond_63

    sget-wide p0, Lan4;->h:J

    invoke-static {v6, v7, p0, p1}, Lan4;->c(JJ)Z

    move-result p0

    if-eqz p0, :cond_63

    if-nez v8, :cond_63

    if-eqz v9, :cond_63

    if-eqz v10, :cond_63

    if-eqz v11, :cond_63

    if-eqz v12, :cond_63

    if-eqz v4, :cond_60

    sget-object p0, Lajf;->c:Landroidx/compose/material3/d;

    return-object p0

    :cond_60
    sget-object p0, Lajf;->d:Landroidx/compose/material3/d;

    return-object p0

    :cond_63
    new-instance v3, Landroidx/compose/material3/d;

    invoke-direct/range {v3 .. v12}, Landroidx/compose/material3/d;-><init>(ZFJLysg;ZZZZ)V

    return-object v3
.end method
