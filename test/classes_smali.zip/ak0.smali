.class public final Lak0;
.super Lc75;


# instance fields
.field public synthetic E:Ljava/lang/Object;

.field public F:I

.field public final synthetic G:Lck0;


# direct methods
.method public constructor <init>(Lck0;La75;)V
    .registers 3

    iput-object p1, p0, Lak0;->G:Lck0;

    invoke-direct {p0, p2}, Lc75;-><init>(La75;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lak0;->E:Ljava/lang/Object;

    iget p1, p0, Lak0;->F:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lak0;->F:I

    iget-object p1, p0, Lak0;->G:Lck0;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lck0;->a(Lrz7;La75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
