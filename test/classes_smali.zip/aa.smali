.class public final Laa;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lca;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/Long;

.field public final d:Lba;

.field public final e:Lva;

.field public final f:Lua;

.field public final g:Lna;

.field public final h:Lxa;

.field public final i:Lbb;


# direct methods
.method public constructor <init>(Lca;Ljava/lang/String;Ljava/lang/Long;Lba;Lva;Lua;Lna;Lxa;Lbb;)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laa;->a:Lca;

    iput-object p2, p0, Laa;->b:Ljava/lang/String;

    iput-object p3, p0, Laa;->c:Ljava/lang/Long;

    iput-object p4, p0, Laa;->d:Lba;

    iput-object p5, p0, Laa;->e:Lva;

    iput-object p6, p0, Laa;->f:Lua;

    iput-object p7, p0, Laa;->g:Lna;

    iput-object p8, p0, Laa;->h:Lxa;

    iput-object p9, p0, Laa;->i:Lbb;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_4

    goto/16 :goto_6b

    :cond_4
    instance-of v0, p1, Laa;

    if-nez v0, :cond_9

    goto :goto_69

    :cond_9
    check-cast p1, Laa;

    iget-object v0, p0, Laa;->a:Lca;

    iget-object v1, p1, Laa;->a:Lca;

    if-eq v0, v1, :cond_12

    goto :goto_69

    :cond_12
    iget-object v0, p0, Laa;->b:Ljava/lang/String;

    iget-object v1, p1, Laa;->b:Ljava/lang/String;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1d

    goto :goto_69

    :cond_1d
    iget-object v0, p0, Laa;->c:Ljava/lang/Long;

    iget-object v1, p1, Laa;->c:Ljava/lang/Long;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_28

    goto :goto_69

    :cond_28
    iget-object v0, p0, Laa;->d:Lba;

    iget-object v1, p1, Laa;->d:Lba;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_33

    goto :goto_69

    :cond_33
    iget-object v0, p0, Laa;->e:Lva;

    iget-object v1, p1, Laa;->e:Lva;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3e

    goto :goto_69

    :cond_3e
    iget-object v0, p0, Laa;->f:Lua;

    iget-object v1, p1, Laa;->f:Lua;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_49

    goto :goto_69

    :cond_49
    iget-object v0, p0, Laa;->g:Lna;

    iget-object v1, p1, Laa;->g:Lna;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_54

    goto :goto_69

    :cond_54
    iget-object v0, p0, Laa;->h:Lxa;

    iget-object v1, p1, Laa;->h:Lxa;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5f

    goto :goto_69

    :cond_5f
    iget-object p0, p0, Laa;->i:Lbb;

    iget-object p1, p1, Laa;->i:Lbb;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_6b

    :goto_69
    const/4 p0, 0x0

    return p0

    :cond_6b
    :goto_6b
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 5

    iget-object v0, p0, Laa;->a:Lca;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v1, 0x0

    iget-object v2, p0, Laa;->b:Ljava/lang/String;

    if-nez v2, :cond_f

    move v2, v1

    goto :goto_13

    :cond_f
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_13
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Laa;->c:Ljava/lang/Long;

    if-nez v2, :cond_1c

    move v2, v1

    goto :goto_20

    :cond_1c
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_20
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Laa;->d:Lba;

    if-nez v2, :cond_29

    move v2, v1

    goto :goto_2f

    :cond_29
    iget-object v2, v2, Lba;->a:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_2f
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Laa;->e:Lva;

    if-nez v2, :cond_38

    move v2, v1

    goto :goto_3e

    :cond_38
    iget-object v2, v2, Lva;->a:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_3e
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Laa;->f:Lua;

    if-nez v2, :cond_47

    move v2, v1

    goto :goto_4d

    :cond_47
    iget-wide v2, v2, Lua;->a:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    :goto_4d
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Laa;->g:Lna;

    if-nez v2, :cond_56

    move v2, v1

    goto :goto_5c

    :cond_56
    iget-wide v2, v2, Lna;->a:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    :goto_5c
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Laa;->h:Lxa;

    if-nez v2, :cond_65

    move v2, v1

    goto :goto_6b

    :cond_65
    iget-wide v2, v2, Lxa;->a:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    :goto_6b
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Laa;->i:Lbb;

    if-nez p0, :cond_73

    goto :goto_79

    :cond_73
    iget-wide v1, p0, Lbb;->a:J

    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    move-result v1

    :goto_79
    add-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ActionEventAction(type="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Laa;->a:Lca;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", id="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Laa;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", loadingTime="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Laa;->c:Ljava/lang/Long;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", target="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Laa;->d:Lba;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", frustration="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Laa;->e:Lva;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", error="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Laa;->f:Lua;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", crash="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Laa;->g:Lna;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", longTask="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Laa;->h:Lxa;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", resource="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Laa;->i:Lbb;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
