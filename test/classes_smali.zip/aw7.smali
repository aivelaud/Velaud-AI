.class public final synthetic Law7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lbw7;


# direct methods
.method public synthetic constructor <init>(Lbw7;I)V
    .registers 3

    iput p2, p0, Law7;->E:I

    iput-object p1, p0, Law7;->F:Lbw7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 8

    iget v0, p0, Law7;->E:I

    iget-object p0, p0, Law7;->F:Lbw7;

    packed-switch v0, :pswitch_data_e4

    invoke-virtual {p0}, Lbw7;->a()V

    return-void

    :pswitch_b  #0x1
    sget-object v0, Lbw7;->m:Ljava/lang/Object;

    monitor-enter v0

    :try_start_e
    iget-object v1, p0, Lbw7;->a:Ltv7;

    invoke-virtual {v1}, Ltv7;->a()V

    iget-object v1, v1, Ltv7;->a:Landroid/content/Context;

    invoke-static {v1}, Laqk;->w(Landroid/content/Context;)Laqk;

    move-result-object v1
    :try_end_19
    .catchall {:try_start_e .. :try_end_19} :catchall_25

    :try_start_19
    iget-object v2, p0, Lbw7;->c:Li47;

    invoke-virtual {v2}, Li47;->L()Lec1;

    move-result-object v2
    :try_end_1f
    .catchall {:try_start_19 .. :try_end_1f} :catchall_d7

    if-eqz v1, :cond_28

    :try_start_21
    invoke-virtual {v1}, Laqk;->L()V

    goto :goto_28

    :catchall_25
    move-exception p0

    goto/16 :goto_de

    :cond_28
    :goto_28
    monitor-exit v0
    :try_end_29
    .catchall {:try_start_21 .. :try_end_29} :catchall_25

    :try_start_29
    iget v1, v2, Lec1;->b:I

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-ne v1, v4, :cond_32

    move v6, v5

    goto :goto_33

    :cond_32
    move v6, v3

    :goto_33
    if-nez v6, :cond_4c

    const/4 v6, 0x3

    if-ne v1, v6, :cond_39

    move v3, v5

    :cond_39
    if-eqz v3, :cond_3c

    goto :goto_4c

    :cond_3c
    iget-object v1, p0, Lbw7;->d:Lwej;

    invoke-virtual {v1, v2}, Lwej;->a(Lec1;)Z

    move-result v1

    if-eqz v1, :cond_d6

    invoke-virtual {p0, v2}, Lbw7;->b(Lec1;)Lec1;

    move-result-object v1

    goto :goto_50

    :catch_49
    move-exception v0

    goto/16 :goto_d3

    :cond_4c
    :goto_4c
    invoke-virtual {p0, v2}, Lbw7;->f(Lec1;)Lec1;

    move-result-object v1
    :try_end_50
    .catch Lcom/google/firebase/installations/FirebaseInstallationsException; {:try_start_29 .. :try_end_50} :catch_49

    :goto_50
    monitor-enter v0

    :try_start_51
    iget-object v3, p0, Lbw7;->a:Ltv7;

    invoke-virtual {v3}, Ltv7;->a()V

    iget-object v3, v3, Ltv7;->a:Landroid/content/Context;

    invoke-static {v3}, Laqk;->w(Landroid/content/Context;)Laqk;

    move-result-object v3
    :try_end_5c
    .catchall {:try_start_51 .. :try_end_5c} :catchall_67

    :try_start_5c
    iget-object v6, p0, Lbw7;->c:Li47;

    invoke-virtual {v6, v1}, Li47;->I(Lec1;)V
    :try_end_61
    .catchall {:try_start_5c .. :try_end_61} :catchall_ca

    if-eqz v3, :cond_6a

    :try_start_63
    invoke-virtual {v3}, Laqk;->L()V

    goto :goto_6a

    :catchall_67
    move-exception p0

    goto/16 :goto_d1

    :cond_6a
    :goto_6a
    monitor-exit v0
    :try_end_6b
    .catchall {:try_start_63 .. :try_end_6b} :catchall_67

    monitor-enter p0

    :try_start_6c
    iget-object v0, p0, Lbw7;->k:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v0

    if-eqz v0, :cond_96

    iget-object v0, v2, Lec1;->a:Ljava/lang/String;

    iget-object v2, v1, Lec1;->a:Ljava/lang/String;

    invoke-static {v0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_96

    iget-object v0, p0, Lbw7;->k:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_8b

    goto :goto_96

    :cond_8b
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lb40;->x(Ljava/lang/Object;)V

    const/4 v0, 0x0

    throw v0
    :try_end_94
    .catchall {:try_start_6c .. :try_end_94} :catchall_94

    :catchall_94
    move-exception v0

    goto :goto_c8

    :cond_96
    :goto_96
    monitor-exit p0

    iget v0, v1, Lec1;->b:I

    const/4 v2, 0x4

    if-ne v0, v2, :cond_a6

    iget-object v0, v1, Lec1;->a:Ljava/lang/String;

    monitor-enter p0

    :try_start_9f
    iput-object v0, p0, Lbw7;->j:Ljava/lang/String;
    :try_end_a1
    .catchall {:try_start_9f .. :try_end_a1} :catchall_a3

    monitor-exit p0

    goto :goto_a6

    :catchall_a3
    move-exception v0

    :try_start_a4
    monitor-exit p0
    :try_end_a5
    .catchall {:try_start_a4 .. :try_end_a5} :catchall_a3

    throw v0

    :cond_a6
    :goto_a6
    iget v0, v1, Lec1;->b:I

    if-ne v0, v4, :cond_b3

    new-instance v0, Lcom/google/firebase/installations/FirebaseInstallationsException;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    invoke-virtual {p0, v0}, Lbw7;->g(Ljava/lang/Exception;)V

    goto :goto_d6

    :cond_b3
    const/4 v2, 0x2

    if-eq v0, v2, :cond_bd

    if-ne v0, v5, :cond_b9

    goto :goto_bd

    :cond_b9
    invoke-virtual {p0, v1}, Lbw7;->h(Lec1;)V

    goto :goto_d6

    :cond_bd
    :goto_bd
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Installation ID could not be validated with the Firebase servers (maybe it was deleted). Firebase Installations will need to create a new Installation ID and auth token. Please retry your last request."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lbw7;->g(Ljava/lang/Exception;)V

    goto :goto_d6

    :goto_c8
    :try_start_c8
    monitor-exit p0
    :try_end_c9
    .catchall {:try_start_c8 .. :try_end_c9} :catchall_94

    throw v0

    :catchall_ca
    move-exception p0

    if-eqz v3, :cond_d0

    :try_start_cd
    invoke-virtual {v3}, Laqk;->L()V

    :cond_d0
    throw p0

    :goto_d1
    monitor-exit v0
    :try_end_d2
    .catchall {:try_start_cd .. :try_end_d2} :catchall_67

    throw p0

    :goto_d3
    invoke-virtual {p0, v0}, Lbw7;->g(Ljava/lang/Exception;)V

    :cond_d6
    :goto_d6
    return-void

    :catchall_d7
    move-exception p0

    if-eqz v1, :cond_dd

    :try_start_da
    invoke-virtual {v1}, Laqk;->L()V

    :cond_dd
    throw p0

    :goto_de
    monitor-exit v0
    :try_end_df
    .catchall {:try_start_da .. :try_end_df} :catchall_25

    throw p0

    :pswitch_e0  #0x0
    invoke-virtual {p0}, Lbw7;->a()V

    return-void

    :pswitch_data_e4
    .packed-switch 0x0
        :pswitch_e0  #00000000
        :pswitch_b  #00000001
    .end packed-switch
.end method
