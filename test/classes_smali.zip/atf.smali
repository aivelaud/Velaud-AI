.class public final Latf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lqz7;
.implements Ldi2;


# instance fields
.field public final E:Lq98;


# direct methods
.method public constructor <init>(Lq98;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Latf;->E:Lq98;

    return-void
.end method


# virtual methods
.method public final a(Lrz7;La75;)Ljava/lang/Object;
    .registers 7

    instance-of v0, p2, Li1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Li1;

    iget v1, v0, Li1;->H:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Li1;->H:I

    goto :goto_18

    :cond_13
    new-instance v0, Li1;

    invoke-direct {v0, p0, p2}, Li1;-><init>(Latf;La75;)V

    :goto_18
    iget-object p2, v0, Li1;->F:Ljava/lang/Object;

    iget v1, v0, Li1;->H:I

    sget-object v2, Lz2j;->a:Lz2j;

    const/4 v3, 0x1

    if-eqz v1, :cond_32

    if-ne v1, v3, :cond_2b

    iget-object p0, v0, Li1;->E:Lwsf;

    :try_start_25
    invoke-static {p2}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_28
    .catchall {:try_start_25 .. :try_end_28} :catchall_29

    goto :goto_52

    :catchall_29
    move-exception p1

    goto :goto_5c

    :cond_2b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_32
    invoke-static {p2}, Lw10;->P(Ljava/lang/Object;)V

    new-instance p2, Lwsf;

    invoke-interface {v0}, La75;->getContext()Lla5;

    move-result-object v1

    invoke-direct {p2, p1, v1}, Lwsf;-><init>(Lrz7;Lla5;)V

    :try_start_3e
    iput-object p2, v0, Li1;->E:Lwsf;

    iput v3, v0, Li1;->H:I
    :try_end_42
    .catchall {:try_start_3e .. :try_end_42} :catchall_5a

    :try_start_42
    iget-object p0, p0, Latf;->E:Lq98;

    invoke-interface {p0, p2, v0}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_48
    .catchall {:try_start_42 .. :try_end_48} :catchall_56

    sget-object p1, Lva5;->E:Lva5;

    if-ne p0, p1, :cond_4d

    goto :goto_4e

    :cond_4d
    move-object p0, v2

    :goto_4e
    if-ne p0, p1, :cond_51

    return-object p1

    :cond_51
    move-object p0, p2

    :goto_52
    invoke-virtual {p0}, Lc75;->releaseIntercepted()V

    return-object v2

    :catchall_56
    move-exception p0

    move-object p1, p0

    :goto_58
    move-object p0, p2

    goto :goto_5c

    :catchall_5a
    move-exception p1

    goto :goto_58

    :goto_5c
    invoke-virtual {p0}, Lc75;->releaseIntercepted()V

    throw p1
.end method
