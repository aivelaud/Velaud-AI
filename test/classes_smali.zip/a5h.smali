.class public final La5h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lx4h;

.field public b:[I

.field public c:[Ljava/lang/Object;

.field public d:Ljava/util/ArrayList;

.field public e:Ljava/util/HashMap;

.field public f:Llcc;

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:I

.field public l:I

.field public m:I

.field public n:I

.field public o:I

.field public final p:Lzj9;

.field public final q:Lzj9;

.field public final r:Lzj9;

.field public s:Llcc;

.field public t:I

.field public u:I

.field public v:I

.field public w:Z

.field public x:Lkcc;


# direct methods
.method public constructor <init>(Lx4h;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La5h;->a:Lx4h;

    iget-object v0, p1, Lx4h;->E:[I

    iput-object v0, p0, La5h;->b:[I

    iget-object v1, p1, Lx4h;->G:[Ljava/lang/Object;

    iput-object v1, p0, La5h;->c:[Ljava/lang/Object;

    iget-object v2, p1, Lx4h;->M:Ljava/util/ArrayList;

    iput-object v2, p0, La5h;->d:Ljava/util/ArrayList;

    iget-object v2, p1, Lx4h;->N:Ljava/util/HashMap;

    iput-object v2, p0, La5h;->e:Ljava/util/HashMap;

    iget-object v2, p1, Lx4h;->O:Llcc;

    iput-object v2, p0, La5h;->f:Llcc;

    iget v2, p1, Lx4h;->F:I

    iput v2, p0, La5h;->g:I

    array-length v0, v0

    div-int/lit8 v0, v0, 0x5

    sub-int/2addr v0, v2

    iput v0, p0, La5h;->h:I

    iget p1, p1, Lx4h;->H:I

    iput p1, p0, La5h;->k:I

    array-length v0, v1

    sub-int/2addr v0, p1

    iput v0, p0, La5h;->l:I

    iput v2, p0, La5h;->m:I

    new-instance p1, Lzj9;

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p1, v0, v1}, Lzj9;-><init>(IZ)V

    iput-object p1, p0, La5h;->p:Lzj9;

    new-instance p1, Lzj9;

    invoke-direct {p1, v0, v1}, Lzj9;-><init>(IZ)V

    iput-object p1, p0, La5h;->q:Lzj9;

    new-instance p1, Lzj9;

    invoke-direct {p1, v0, v1}, Lzj9;-><init>(IZ)V

    iput-object p1, p0, La5h;->r:Lzj9;

    iput v2, p0, La5h;->u:I

    const/4 p1, -0x1

    iput p1, p0, La5h;->v:I

    return-void
.end method

.method public static i(IIII)I
    .registers 4

    if-le p0, p1, :cond_7

    sub-int/2addr p3, p2

    sub-int/2addr p3, p0

    add-int/lit8 p3, p3, 0x1

    neg-int p0, p3

    :cond_7
    return p0
.end method

.method public static z(La5h;)V
    .registers 7

    iget v0, p0, La5h;->v:I

    invoke-virtual {p0, v0}, La5h;->r(I)I

    move-result v1

    iget-object v2, p0, La5h;->b:[I

    mul-int/lit8 v1, v1, 0x5

    add-int/lit8 v1, v1, 0x1

    aget v3, v2, v1

    const/high16 v4, 0x8000000

    and-int v5, v3, v4

    if-eqz v5, :cond_15

    goto :goto_21

    :cond_15
    const v5, -0x8000001

    and-int/2addr v3, v5

    or-int/2addr v3, v4

    aput v3, v2, v1

    const/high16 v1, 0x4000000

    and-int/2addr v1, v3

    if-eqz v1, :cond_22

    :goto_21
    return-void

    :cond_22
    invoke-virtual {p0, v0, v2}, La5h;->G(I[I)I

    move-result v0

    invoke-virtual {p0, v0}, La5h;->W(I)V

    return-void
.end method


# virtual methods
.method public final A(Lx4h;I)V
    .registers 18

    move-object/from16 v0, p1

    iget v1, p0, La5h;->n:I

    if-lez v1, :cond_7

    goto :goto_c

    :cond_7
    const-string v1, "Check failed"

    invoke-static {v1}, Lev4;->a(Ljava/lang/String;)V

    :goto_c
    const/4 v7, 0x0

    if-nez p2, :cond_62

    iget v1, p0, La5h;->t:I

    if-nez v1, :cond_62

    iget-object v1, p0, La5h;->a:Lx4h;

    iget v1, v1, Lx4h;->F:I

    if-nez v1, :cond_62

    iget-object v1, v0, Lx4h;->E:[I

    mul-int/lit8 v2, p2, 0x5

    add-int/lit8 v2, v2, 0x3

    aget v2, v1, v2

    iget v4, v0, Lx4h;->F:I

    if-ne v2, v4, :cond_62

    iget-object v2, p0, La5h;->b:[I

    iget-object v5, p0, La5h;->c:[Ljava/lang/Object;

    iget-object v6, p0, La5h;->d:Ljava/util/ArrayList;

    iget-object v8, p0, La5h;->e:Ljava/util/HashMap;

    iget-object v9, p0, La5h;->f:Llcc;

    iget-object v10, v0, Lx4h;->G:[Ljava/lang/Object;

    iget v11, v0, Lx4h;->H:I

    iget-object v12, v0, Lx4h;->N:Ljava/util/HashMap;

    iget-object v13, v0, Lx4h;->O:Llcc;

    iput-object v1, p0, La5h;->b:[I

    iput-object v10, p0, La5h;->c:[Ljava/lang/Object;

    iget-object v14, v0, Lx4h;->M:Ljava/util/ArrayList;

    iput-object v14, p0, La5h;->d:Ljava/util/ArrayList;

    iput v4, p0, La5h;->g:I

    array-length v1, v1

    div-int/lit8 v1, v1, 0x5

    sub-int/2addr v1, v4

    iput v1, p0, La5h;->h:I

    iput v11, p0, La5h;->k:I

    array-length v1, v10

    sub-int/2addr v1, v11

    iput v1, p0, La5h;->l:I

    iput v4, p0, La5h;->m:I

    iput-object v12, p0, La5h;->e:Ljava/util/HashMap;

    iput-object v13, p0, La5h;->f:Llcc;

    iput-object v2, v0, Lx4h;->E:[I

    iput v7, v0, Lx4h;->F:I

    iput-object v5, v0, Lx4h;->G:[Ljava/lang/Object;

    iput v7, v0, Lx4h;->H:I

    iput-object v6, v0, Lx4h;->M:Ljava/util/ArrayList;

    iput-object v8, v0, Lx4h;->N:Ljava/util/HashMap;

    iput-object v9, v0, Lx4h;->O:Llcc;

    return-void

    :cond_62
    invoke-virtual {v0}, Lx4h;->k()La5h;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    move-object v3, p0

    move/from16 v2, p2

    :try_start_6c
    invoke-static/range {v1 .. v6}, Lbo5;->N(La5h;ILa5h;ZZZ)Ljava/util/List;
    :try_end_6f
    .catchall {:try_start_6c .. :try_end_6f} :catchall_74

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, La5h;->e(Z)V

    return-void

    :catchall_74
    move-exception v0

    invoke-virtual {v1, v7}, La5h;->e(Z)V

    throw v0
.end method

.method public final B(I)V
    .registers 10

    iget v0, p0, La5h;->h:I

    iget v1, p0, La5h;->g:I

    if-eq v1, p1, :cond_ab

    iget-object v2, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_59

    iget v2, p0, La5h;->h:I

    invoke-virtual {p0}, La5h;->o()I

    move-result v3

    sub-int/2addr v3, v2

    iget-object v2, p0, La5h;->d:Ljava/util/ArrayList;

    if-ge v1, p1, :cond_39

    invoke-static {v2, v1, v3}, Lz4h;->a(Ljava/util/ArrayList;II)I

    move-result v2

    :goto_1d
    iget-object v4, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_59

    iget-object v4, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lza8;

    iget v5, v4, Lza8;->a:I

    if-gez v5, :cond_59

    add-int/2addr v5, v3

    if-ge v5, p1, :cond_59

    iput v5, v4, Lza8;->a:I

    add-int/lit8 v2, v2, 0x1

    goto :goto_1d

    :cond_39
    invoke-static {v2, p1, v3}, Lz4h;->a(Ljava/util/ArrayList;II)I

    move-result v2

    :goto_3d
    iget-object v4, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_59

    iget-object v4, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lza8;

    iget v5, v4, Lza8;->a:I

    if-ltz v5, :cond_59

    sub-int v5, v3, v5

    neg-int v5, v5

    iput v5, v4, Lza8;->a:I

    add-int/lit8 v2, v2, 0x1

    goto :goto_3d

    :cond_59
    if-lez v0, :cond_70

    iget-object v2, p0, La5h;->b:[I

    mul-int/lit8 v3, p1, 0x5

    mul-int/lit8 v4, v0, 0x5

    mul-int/lit8 v5, v1, 0x5

    if-ge p1, v1, :cond_6a

    add-int/2addr v4, v3

    invoke-static {v4, v3, v5, v2, v2}, Lmr0;->t0(III[I[I)V

    goto :goto_70

    :cond_6a
    add-int v6, v5, v4

    add-int/2addr v3, v4

    invoke-static {v5, v6, v3, v2, v2}, Lmr0;->t0(III[I[I)V

    :cond_70
    :goto_70
    if-ge p1, v1, :cond_74

    add-int v1, p1, v0

    :cond_74
    invoke-virtual {p0}, La5h;->o()I

    move-result v2

    if-ge v1, v2, :cond_7b

    goto :goto_80

    :cond_7b
    const-string v3, "Check failed"

    invoke-static {v3}, Lev4;->a(Ljava/lang/String;)V

    :cond_80
    :goto_80
    if-ge v1, v2, :cond_ab

    iget-object v3, p0, La5h;->b:[I

    mul-int/lit8 v4, v1, 0x5

    add-int/lit8 v4, v4, 0x2

    aget v3, v3, v4

    const/4 v5, -0x2

    if-le v3, v5, :cond_8f

    move v6, v3

    goto :goto_95

    :cond_8f
    invoke-virtual {p0}, La5h;->p()I

    move-result v6

    add-int/2addr v6, v3

    sub-int/2addr v6, v5

    :goto_95
    if-ge v6, p1, :cond_98

    goto :goto_9f

    :cond_98
    invoke-virtual {p0}, La5h;->p()I

    move-result v7

    sub-int/2addr v7, v6

    sub-int/2addr v7, v5

    neg-int v6, v7

    :goto_9f
    if-eq v6, v3, :cond_a5

    iget-object v3, p0, La5h;->b:[I

    aput v6, v3, v4

    :cond_a5
    add-int/lit8 v1, v1, 0x1

    if-ne v1, p1, :cond_80

    add-int/2addr v1, v0

    goto :goto_80

    :cond_ab
    iput p1, p0, La5h;->g:I

    return-void
.end method

.method public final C(II)V
    .registers 10

    iget v0, p0, La5h;->l:I

    iget v1, p0, La5h;->k:I

    iget v2, p0, La5h;->m:I

    if-eq v1, p1, :cond_1b

    iget-object v3, p0, La5h;->c:[Ljava/lang/Object;

    if-ge p1, v1, :cond_13

    add-int v4, p1, v0

    sub-int/2addr v1, p1

    invoke-static {v3, p1, v3, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_1b

    :cond_13
    add-int v4, v1, v0

    add-int v5, p1, v0

    sub-int/2addr v5, v4

    invoke-static {v3, v4, v3, v1, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_1b
    :goto_1b
    add-int/lit8 p2, p2, 0x1

    invoke-virtual {p0}, La5h;->p()I

    move-result v1

    invoke-static {p2, v1}, Ljava/lang/Math;->min(II)I

    move-result p2

    if-eq v2, p2, :cond_87

    iget-object v1, p0, La5h;->c:[Ljava/lang/Object;

    array-length v1, v1

    sub-int/2addr v1, v0

    if-ge p2, v2, :cond_5a

    invoke-virtual {p0, p2}, La5h;->r(I)I

    move-result v0

    invoke-virtual {p0, v2}, La5h;->r(I)I

    move-result v2

    iget v3, p0, La5h;->g:I

    :cond_37
    :goto_37
    if-ge v0, v2, :cond_85

    iget-object v4, p0, La5h;->b:[I

    mul-int/lit8 v5, v0, 0x5

    add-int/lit8 v5, v5, 0x4

    aget v4, v4, v5

    if-ltz v4, :cond_44

    goto :goto_49

    :cond_44
    const-string v6, "Unexpected anchor value, expected a positive anchor"

    invoke-static {v6}, Lev4;->a(Ljava/lang/String;)V

    :goto_49
    iget-object v6, p0, La5h;->b:[I

    sub-int v4, v1, v4

    add-int/lit8 v4, v4, 0x1

    neg-int v4, v4

    aput v4, v6, v5

    add-int/lit8 v0, v0, 0x1

    if-ne v0, v3, :cond_37

    iget v4, p0, La5h;->h:I

    add-int/2addr v0, v4

    goto :goto_37

    :cond_5a
    invoke-virtual {p0, v2}, La5h;->r(I)I

    move-result v0

    invoke-virtual {p0, p2}, La5h;->r(I)I

    move-result v2

    :cond_62
    :goto_62
    if-ge v0, v2, :cond_85

    iget-object v3, p0, La5h;->b:[I

    mul-int/lit8 v4, v0, 0x5

    add-int/lit8 v4, v4, 0x4

    aget v3, v3, v4

    if-gez v3, :cond_6f

    goto :goto_74

    :cond_6f
    const-string v5, "Unexpected anchor value, expected a negative anchor"

    invoke-static {v5}, Lev4;->a(Ljava/lang/String;)V

    :goto_74
    iget-object v5, p0, La5h;->b:[I

    add-int/2addr v3, v1

    add-int/lit8 v3, v3, 0x1

    aput v3, v5, v4

    add-int/lit8 v0, v0, 0x1

    iget v3, p0, La5h;->g:I

    if-ne v0, v3, :cond_62

    iget v3, p0, La5h;->h:I

    add-int/2addr v0, v3

    goto :goto_62

    :cond_85
    iput p2, p0, La5h;->m:I

    :cond_87
    iput p1, p0, La5h;->k:I

    return-void
.end method

.method public final D(Lza8;La5h;)Ljava/util/List;
    .registers 14

    iget v0, p2, La5h;->n:I

    const-string v1, "Check failed"

    if-lez v0, :cond_7

    goto :goto_a

    :cond_7
    invoke-static {v1}, Lev4;->a(Ljava/lang/String;)V

    :goto_a
    iget v0, p0, La5h;->n:I

    if-nez v0, :cond_f

    goto :goto_12

    :cond_f
    invoke-static {v1}, Lev4;->a(Ljava/lang/String;)V

    :goto_12
    invoke-virtual {p1}, Lza8;->a()Z

    move-result v0

    if-nez v0, :cond_1b

    invoke-static {v1}, Lev4;->a(Ljava/lang/String;)V

    :cond_1b
    invoke-virtual {p0, p1}, La5h;->c(Lza8;)I

    move-result p1

    const/4 v0, 0x1

    add-int/lit8 v3, p1, 0x1

    iget p1, p0, La5h;->t:I

    if-gt p1, v3, :cond_2b

    iget v2, p0, La5h;->u:I

    if-ge v3, v2, :cond_2b

    goto :goto_2e

    :cond_2b
    invoke-static {v1}, Lev4;->a(Ljava/lang/String;)V

    :goto_2e
    iget-object v2, p0, La5h;->b:[I

    invoke-virtual {p0, v3, v2}, La5h;->G(I[I)I

    move-result v8

    invoke-virtual {p0, v3}, La5h;->u(I)I

    move-result v9

    invoke-virtual {p0, v3}, La5h;->y(I)Z

    move-result v2

    if-eqz v2, :cond_40

    move v10, v0

    goto :goto_45

    :cond_40
    invoke-virtual {p0, v3}, La5h;->F(I)I

    move-result v2

    move v10, v2

    :goto_45
    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v5, 0x0

    move-object v2, p0

    move-object v4, p2

    invoke-static/range {v2 .. v7}, Lbo5;->N(La5h;ILa5h;ZZZ)Ljava/util/List;

    move-result-object p0

    invoke-virtual {v2, v8}, La5h;->W(I)V

    const/4 p2, 0x0

    if-lez v10, :cond_55

    goto :goto_56

    :cond_55
    move v0, p2

    :goto_56
    if-lt v8, p1, :cond_83

    invoke-virtual {v2, v8}, La5h;->r(I)I

    move-result v3

    iget-object v4, v2, La5h;->b:[I

    mul-int/lit8 v5, v3, 0x5

    add-int/lit8 v6, v5, 0x3

    aget v7, v4, v6

    sub-int/2addr v7, v9

    aput v7, v4, v6

    if-eqz v0, :cond_7c

    add-int/lit8 v5, v5, 0x1

    aget v5, v4, v5

    const/high16 v6, 0x40000000  # 2.0f

    and-int/2addr v6, v5

    if-eqz v6, :cond_74

    move v0, p2

    goto :goto_7c

    :cond_74
    const v6, 0x3ffffff

    and-int/2addr v5, v6

    sub-int/2addr v5, v10

    invoke-static {v3, v5, v4}, Lz4h;->c(II[I)V

    :cond_7c
    :goto_7c
    iget-object v3, v2, La5h;->b:[I

    invoke-virtual {v2, v8, v3}, La5h;->G(I[I)I

    move-result v8

    goto :goto_56

    :cond_83
    if-eqz v0, :cond_92

    iget p1, v2, La5h;->o:I

    if-lt p1, v10, :cond_8a

    goto :goto_8d

    :cond_8a
    invoke-static {v1}, Lev4;->a(Ljava/lang/String;)V

    :goto_8d
    iget p1, v2, La5h;->o:I

    sub-int/2addr p1, v10

    iput p1, v2, La5h;->o:I

    :cond_92
    return-object p0
.end method

.method public final E(I)Ljava/lang/Object;
    .registers 5

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p1

    iget-object v0, p0, La5h;->b:[I

    mul-int/lit8 v1, p1, 0x5

    add-int/lit8 v1, v1, 0x1

    aget v1, v0, v1

    const/high16 v2, 0x40000000  # 2.0f

    and-int/2addr v1, v2

    if-eqz v1, :cond_1e

    iget-object v1, p0, La5h;->c:[Ljava/lang/Object;

    invoke-virtual {p0, p1, v0}, La5h;->g(I[I)I

    move-result p1

    invoke-virtual {p0, p1}, La5h;->h(I)I

    move-result p0

    aget-object p0, v1, p0

    return-object p0

    :cond_1e
    const/4 p0, 0x0

    return-object p0
.end method

.method public final F(I)I
    .registers 3

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p0

    mul-int/lit8 p0, p0, 0x5

    add-int/lit8 p0, p0, 0x1

    aget p0, v0, p0

    const p1, 0x3ffffff

    and-int/2addr p0, p1

    return p0
.end method

.method public final G(I[I)I
    .registers 3

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p1

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x2

    aget p1, p2, p1

    const/4 p2, -0x2

    if-le p1, p2, :cond_e

    return p1

    :cond_e
    invoke-virtual {p0}, La5h;->p()I

    move-result p0

    add-int/2addr p0, p1

    sub-int/2addr p0, p2

    return p0
.end method

.method public final H(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    iget v0, p0, La5h;->n:I

    const/4 v1, 0x1

    if-lez v0, :cond_a

    iget v0, p0, La5h;->v:I

    invoke-virtual {p0, v1, v0}, La5h;->x(II)V

    :cond_a
    iget-object v0, p0, La5h;->c:[Ljava/lang/Object;

    iget v2, p0, La5h;->i:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, La5h;->i:I

    invoke-virtual {p0, v2}, La5h;->h(I)I

    move-result v2

    aget-object v0, v0, v2

    iget v2, p0, La5h;->i:I

    iget v3, p0, La5h;->j:I

    if-gt v2, v3, :cond_1f

    goto :goto_24

    :cond_1f
    const-string v2, "Writing to an invalid slot"

    invoke-static {v2}, Lev4;->a(Ljava/lang/String;)V

    :goto_24
    iget-object v2, p0, La5h;->c:[Ljava/lang/Object;

    iget v3, p0, La5h;->i:I

    sub-int/2addr v3, v1

    invoke-virtual {p0, v3}, La5h;->h(I)I

    move-result p0

    aput-object p1, v2, p0

    return-object v0
.end method

.method public final I()V
    .registers 10

    iget-object v0, p0, La5h;->x:Lkcc;

    if-eqz v0, :cond_56

    :cond_4
    :goto_4
    iget v1, v0, Lkcc;->b:I

    if-eqz v1, :cond_56

    invoke-static {v0}, Lckf;->S(Lkcc;)I

    move-result v1

    invoke-virtual {p0, v1}, La5h;->r(I)I

    move-result v2

    add-int/lit8 v3, v1, 0x1

    invoke-virtual {p0, v1}, La5h;->u(I)I

    move-result v4

    add-int/2addr v4, v1

    :goto_17
    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ge v3, v4, :cond_33

    iget-object v7, p0, La5h;->b:[I

    invoke-virtual {p0, v3}, La5h;->r(I)I

    move-result v8

    mul-int/lit8 v8, v8, 0x5

    add-int/2addr v8, v6

    aget v7, v7, v8

    const/high16 v8, 0xc000000

    and-int/2addr v7, v8

    if-eqz v7, :cond_2d

    move v3, v6

    goto :goto_34

    :cond_2d
    invoke-virtual {p0, v3}, La5h;->u(I)I

    move-result v5

    add-int/2addr v3, v5

    goto :goto_17

    :cond_33
    move v3, v5

    :goto_34
    iget-object v4, p0, La5h;->b:[I

    mul-int/lit8 v2, v2, 0x5

    add-int/2addr v2, v6

    aget v7, v4, v2

    const/high16 v8, 0x4000000

    and-int/2addr v8, v7

    if-eqz v8, :cond_41

    move v5, v6

    :cond_41
    if-eq v5, v3, :cond_4

    const v5, -0x4000001

    and-int/2addr v5, v7

    shl-int/lit8 v3, v3, 0x1a

    or-int/2addr v3, v5

    aput v3, v4, v2

    invoke-virtual {p0, v1, v4}, La5h;->G(I[I)I

    move-result v1

    if-ltz v1, :cond_4

    invoke-static {v0, v1}, Lckf;->B(Lkcc;I)V

    goto :goto_4

    :cond_56
    return-void
.end method

.method public final J()Z
    .registers 8

    iget v0, p0, La5h;->n:I

    if-nez v0, :cond_5

    goto :goto_a

    :cond_5
    const-string v0, "Cannot remove group while inserting"

    invoke-static {v0}, Lev4;->a(Ljava/lang/String;)V

    :goto_a
    iget v0, p0, La5h;->t:I

    iget v1, p0, La5h;->i:I

    iget-object v2, p0, La5h;->b:[I

    invoke-virtual {p0, v0}, La5h;->r(I)I

    move-result v3

    invoke-virtual {p0, v3, v2}, La5h;->g(I[I)I

    move-result v2

    invoke-virtual {p0}, La5h;->N()I

    move-result v3

    iget v4, p0, La5h;->v:I

    invoke-virtual {p0, v4}, La5h;->Q(I)Lgb8;

    iget-object v4, p0, La5h;->x:Lkcc;

    if-eqz v4, :cond_3d

    :goto_25
    iget v5, v4, Lkcc;->b:I

    if-eqz v5, :cond_3d

    if-eqz v5, :cond_36

    iget-object v5, v4, Lkcc;->a:[I

    const/4 v6, 0x0

    aget v5, v5, v6

    if-lt v5, v0, :cond_3d

    invoke-static {v4}, Lckf;->S(Lkcc;)I

    goto :goto_25

    :cond_36
    const-string p0, "IntList is empty."

    invoke-static {p0}, Lef1;->k(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :cond_3d
    iget v4, p0, La5h;->t:I

    sub-int/2addr v4, v0

    invoke-virtual {p0, v0, v4}, La5h;->K(II)Z

    move-result v4

    iget v5, p0, La5h;->i:I

    sub-int/2addr v5, v2

    add-int/lit8 v6, v0, -0x1

    invoke-virtual {p0, v2, v5, v6}, La5h;->L(III)V

    iput v0, p0, La5h;->t:I

    iput v1, p0, La5h;->i:I

    iget v0, p0, La5h;->o:I

    sub-int/2addr v0, v3

    iput v0, p0, La5h;->o:I

    return v4
.end method

.method public final K(II)Z
    .registers 12

    const/4 v0, 0x0

    if-lez p2, :cond_93

    iget-object v1, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, La5h;->B(I)V

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_61

    iget-object v1, p0, La5h;->e:Ljava/util/HashMap;

    iget v3, p0, La5h;->h:I

    add-int v4, p1, p2

    invoke-virtual {p0}, La5h;->o()I

    move-result v5

    sub-int/2addr v5, v3

    iget-object v3, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-static {v3, v4, v5}, Lz4h;->a(Ljava/util/ArrayList;II)I

    move-result v3

    iget-object v5, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lt v3, v5, :cond_2a

    add-int/lit8 v3, v3, -0x1

    :cond_2a
    add-int/lit8 v5, v3, 0x1

    move v6, v0

    :goto_2d
    if-ltz v3, :cond_53

    iget-object v7, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lza8;

    invoke-virtual {p0, v7}, La5h;->c(Lza8;)I

    move-result v8

    if-lt v8, p1, :cond_53

    if-ge v8, v4, :cond_50

    const/high16 v5, -0x80000000

    iput v5, v7, Lza8;->a:I

    if-eqz v1, :cond_4b

    invoke-virtual {v1, v7}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lgb8;

    :cond_4b
    if-nez v6, :cond_4f

    add-int/lit8 v6, v3, 0x1

    :cond_4f
    move v5, v3

    :cond_50
    add-int/lit8 v3, v3, -0x1

    goto :goto_2d

    :cond_53
    if-ge v5, v6, :cond_56

    move v0, v2

    :cond_56
    if-eqz v0, :cond_61

    iget-object v1, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, v5, v6}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->clear()V

    :cond_61
    iput p1, p0, La5h;->g:I

    iget v1, p0, La5h;->h:I

    add-int/2addr v1, p2

    iput v1, p0, La5h;->h:I

    iget v1, p0, La5h;->m:I

    if-le v1, p1, :cond_73

    sub-int/2addr v1, p2

    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, La5h;->m:I

    :cond_73
    iget p1, p0, La5h;->u:I

    iget v1, p0, La5h;->g:I

    if-lt p1, v1, :cond_7c

    sub-int/2addr p1, p2

    iput p1, p0, La5h;->u:I

    :cond_7c
    iget p1, p0, La5h;->v:I

    if-ltz p1, :cond_93

    iget-object p2, p0, La5h;->b:[I

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result v1

    mul-int/lit8 v1, v1, 0x5

    add-int/2addr v1, v2

    aget p2, p2, v1

    const/high16 v1, 0x4000000

    and-int/2addr p2, v1

    if-eqz p2, :cond_93

    invoke-virtual {p0, p1}, La5h;->W(I)V

    :cond_93
    return v0
.end method

.method public final L(III)V
    .registers 6

    if-lez p2, :cond_1b

    iget v0, p0, La5h;->l:I

    add-int v1, p1, p2

    invoke-virtual {p0, v1, p3}, La5h;->C(II)V

    iput p1, p0, La5h;->k:I

    add-int/2addr v0, p2

    iput v0, p0, La5h;->l:I

    iget-object p3, p0, La5h;->c:[Ljava/lang/Object;

    const/4 v0, 0x0

    invoke-static {p3, p1, v1, v0}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    iget p3, p0, La5h;->j:I

    if-lt p3, p1, :cond_1b

    sub-int/2addr p3, p2

    iput p3, p0, La5h;->j:I

    :cond_1b
    return-void
.end method

.method public final M(ILjava/lang/Object;I)Ljava/lang/Object;
    .registers 7

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result v0

    iget-object v1, p0, La5h;->b:[I

    invoke-virtual {p0, v0, v1}, La5h;->P(I[I)I

    move-result v0

    iget-object v1, p0, La5h;->b:[I

    add-int/lit8 v2, p1, 0x1

    invoke-virtual {p0, v2}, La5h;->r(I)I

    move-result v2

    invoke-virtual {p0, v2, v1}, La5h;->g(I[I)I

    move-result v1

    add-int v2, v0, p3

    if-lt v2, v0, :cond_1d

    if-ge v2, v1, :cond_1d

    goto :goto_36

    :cond_1d
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Write to an invalid slot index "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, " for group "

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lev4;->a(Ljava/lang/String;)V

    :goto_36
    invoke-virtual {p0, v2}, La5h;->h(I)I

    move-result p1

    iget-object p0, p0, La5h;->c:[Ljava/lang/Object;

    aget-object p3, p0, p1

    aput-object p2, p0, p1

    return-object p3
.end method

.method public final N()I
    .registers 5

    iget v0, p0, La5h;->t:I

    invoke-virtual {p0, v0}, La5h;->r(I)I

    move-result v0

    iget v1, p0, La5h;->t:I

    iget-object v2, p0, La5h;->b:[I

    mul-int/lit8 v0, v0, 0x5

    add-int/lit8 v3, v0, 0x3

    aget v3, v2, v3

    add-int/2addr v3, v1

    iput v3, p0, La5h;->t:I

    invoke-virtual {p0, v3}, La5h;->r(I)I

    move-result v1

    invoke-virtual {p0, v1, v2}, La5h;->g(I[I)I

    move-result v1

    iput v1, p0, La5h;->i:I

    iget-object p0, p0, La5h;->b:[I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    aget p0, p0, v0

    const/high16 v0, 0x40000000  # 2.0f

    and-int/2addr v0, p0

    if-eqz v0, :cond_29

    return v1

    :cond_29
    const v0, 0x3ffffff

    and-int/2addr p0, v0

    return p0
.end method

.method public final O()V
    .registers 3

    iget v0, p0, La5h;->u:I

    iput v0, p0, La5h;->t:I

    iget-object v1, p0, La5h;->b:[I

    invoke-virtual {p0, v0}, La5h;->r(I)I

    move-result v0

    invoke-virtual {p0, v0, v1}, La5h;->g(I[I)I

    move-result v0

    iput v0, p0, La5h;->i:I

    return-void
.end method

.method public final P(I[I)I
    .registers 4

    invoke-virtual {p0}, La5h;->o()I

    move-result v0

    if-lt p1, v0, :cond_d

    iget-object p1, p0, La5h;->c:[Ljava/lang/Object;

    array-length p1, p1

    iget p0, p0, La5h;->l:I

    sub-int/2addr p1, p0

    return p1

    :cond_d
    invoke-static {p1, p2}, Lz4h;->b(I[I)I

    move-result p1

    iget p2, p0, La5h;->l:I

    iget-object p0, p0, La5h;->c:[Ljava/lang/Object;

    array-length p0, p0

    if-gez p1, :cond_1d

    sub-int/2addr p0, p2

    add-int/2addr p0, p1

    add-int/lit8 p0, p0, 0x1

    return p0

    :cond_1d
    return p1
.end method

.method public final Q(I)Lgb8;
    .registers 4

    iget-object v0, p0, La5h;->e:Ljava/util/HashMap;

    const/4 v1, 0x0

    if-eqz v0, :cond_12

    invoke-virtual {p0, p1}, La5h;->T(I)Lza8;

    move-result-object p0

    if-eqz p0, :cond_12

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lgb8;

    return-object p0

    :cond_12
    return-object v1
.end method

.method public final R()V
    .registers 3

    iget v0, p0, La5h;->n:I

    if-nez v0, :cond_5

    goto :goto_a

    :cond_5
    const-string v0, "Key must be supplied when inserting"

    invoke-static {v0}, Lev4;->a(Ljava/lang/String;)V

    :goto_a
    sget-object v0, Lxu4;->a:Lmx8;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v0, v1, v1}, La5h;->S(Ljava/lang/Object;Ljava/lang/Object;ZI)V

    return-void
.end method

.method public final S(Ljava/lang/Object;Ljava/lang/Object;ZI)V
    .registers 16

    iget v0, p0, La5h;->v:I

    iget v1, p0, La5h;->n:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lez v1, :cond_a

    move v1, v3

    goto :goto_b

    :cond_a
    move v1, v2

    :goto_b
    iget-object v4, p0, La5h;->r:Lzj9;

    iget v5, p0, La5h;->o:I

    invoke-virtual {v4, v5}, Lzj9;->e(I)V

    sget-object v4, Lxu4;->a:Lmx8;

    if-eqz v1, :cond_a4

    iget v1, p0, La5h;->t:I

    iget-object v5, p0, La5h;->b:[I

    invoke-virtual {p0, v1}, La5h;->r(I)I

    move-result v6

    invoke-virtual {p0, v6, v5}, La5h;->g(I[I)I

    move-result v5

    invoke-virtual {p0, v3}, La5h;->w(I)V

    iput v5, p0, La5h;->i:I

    iput v5, p0, La5h;->j:I

    invoke-virtual {p0, v1}, La5h;->r(I)I

    move-result v6

    if-eq p1, v4, :cond_31

    move v7, v3

    goto :goto_32

    :cond_31
    move v7, v2

    :goto_32
    if-nez p3, :cond_38

    if-eq p2, v4, :cond_38

    move v4, v3

    goto :goto_39

    :cond_38
    move v4, v2

    :goto_39
    iget v8, p0, La5h;->l:I

    iget v9, p0, La5h;->k:I

    iget-object v10, p0, La5h;->c:[Ljava/lang/Object;

    array-length v10, v10

    invoke-static {v5, v9, v8, v10}, La5h;->i(IIII)I

    move-result v5

    if-ltz v5, :cond_53

    iget v8, p0, La5h;->m:I

    if-ge v8, v1, :cond_53

    iget-object v8, p0, La5h;->c:[Ljava/lang/Object;

    array-length v8, v8

    iget v9, p0, La5h;->l:I

    sub-int/2addr v8, v9

    sub-int/2addr v8, v5

    add-int/2addr v8, v3

    neg-int v5, v8

    :cond_53
    iget-object v3, p0, La5h;->b:[I

    iget v8, p0, La5h;->v:I

    mul-int/lit8 v6, v6, 0x5

    aput p4, v3, v6

    add-int/lit8 p4, v6, 0x1

    shl-int/lit8 v9, p3, 0x1e

    shl-int/lit8 v10, v7, 0x1d

    or-int/2addr v9, v10

    shl-int/lit8 v10, v4, 0x1c

    or-int/2addr v9, v10

    aput v9, v3, p4

    add-int/lit8 p4, v6, 0x2

    aput v8, v3, p4

    add-int/lit8 p4, v6, 0x3

    aput v2, v3, p4

    add-int/lit8 v6, v6, 0x4

    aput v5, v3, v6

    add-int p4, p3, v7

    add-int/2addr p4, v4

    if-lez p4, :cond_96

    invoke-virtual {p0, p4, v1}, La5h;->x(II)V

    iget-object p4, p0, La5h;->c:[Ljava/lang/Object;

    iget v3, p0, La5h;->i:I

    if-eqz p3, :cond_86

    add-int/lit8 p3, v3, 0x1

    aput-object p2, p4, v3

    move v3, p3

    :cond_86
    if-eqz v7, :cond_8d

    add-int/lit8 p3, v3, 0x1

    aput-object p1, p4, v3

    move v3, p3

    :cond_8d
    if-eqz v4, :cond_94

    add-int/lit8 p1, v3, 0x1

    aput-object p2, p4, v3

    move v3, p1

    :cond_94
    iput v3, p0, La5h;->i:I

    :cond_96
    iput v2, p0, La5h;->o:I

    add-int/lit8 p1, v1, 0x1

    iput v1, p0, La5h;->v:I

    iput p1, p0, La5h;->t:I

    if-ltz v0, :cond_ff

    invoke-virtual {p0, v0}, La5h;->Q(I)Lgb8;

    goto :goto_ff

    :cond_a4
    iget-object p1, p0, La5h;->p:Lzj9;

    invoke-virtual {p1, v0}, Lzj9;->e(I)V

    invoke-virtual {p0}, La5h;->o()I

    move-result p1

    iget p4, p0, La5h;->h:I

    sub-int/2addr p1, p4

    iget p4, p0, La5h;->u:I

    sub-int/2addr p1, p4

    iget-object p4, p0, La5h;->q:Lzj9;

    invoke-virtual {p4, p1}, Lzj9;->e(I)V

    iget p1, p0, La5h;->t:I

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p4

    invoke-static {p2, v4}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_cf

    if-eqz p3, :cond_cc

    iget p3, p0, La5h;->t:I

    invoke-virtual {p0, p3, p2}, La5h;->X(ILjava/lang/Object;)V

    goto :goto_cf

    :cond_cc
    invoke-virtual {p0, p2}, La5h;->V(Ljava/lang/Object;)V

    :cond_cf
    :goto_cf
    iget-object p2, p0, La5h;->b:[I

    invoke-virtual {p0, p4, p2}, La5h;->P(I[I)I

    move-result p2

    iput p2, p0, La5h;->i:I

    iget-object p2, p0, La5h;->b:[I

    iget p3, p0, La5h;->t:I

    add-int/2addr p3, v3

    invoke-virtual {p0, p3}, La5h;->r(I)I

    move-result p3

    invoke-virtual {p0, p3, p2}, La5h;->g(I[I)I

    move-result p2

    iput p2, p0, La5h;->j:I

    iget-object p2, p0, La5h;->b:[I

    mul-int/lit8 p4, p4, 0x5

    add-int/lit8 p3, p4, 0x1

    aget p3, p2, p3

    const v0, 0x3ffffff

    and-int/2addr p3, v0

    iput p3, p0, La5h;->o:I

    iput p1, p0, La5h;->v:I

    add-int/lit8 p3, p1, 0x1

    iput p3, p0, La5h;->t:I

    add-int/lit8 p4, p4, 0x3

    aget p2, p2, p4

    add-int/2addr p1, p2

    :cond_ff
    :goto_ff
    iput p1, p0, La5h;->u:I

    return-void
.end method

.method public final T(I)Lza8;
    .registers 4

    const/4 v0, 0x0

    if-ltz p1, :cond_1c

    invoke-virtual {p0}, La5h;->p()I

    move-result v1

    if-ge p1, v1, :cond_1c

    iget-object v1, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {p0}, La5h;->p()I

    move-result p0

    invoke-static {v1, p1, p0}, Lz4h;->e(Ljava/util/ArrayList;II)I

    move-result p0

    if-ltz p0, :cond_1c

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lza8;

    return-object p0

    :cond_1c
    return-object v0
.end method

.method public final U(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, La5h;->n:I

    if-lez v0, :cond_2b

    iget v0, p0, La5h;->i:I

    iget v1, p0, La5h;->k:I

    if-eq v0, v1, :cond_2b

    iget-object v0, p0, La5h;->s:Llcc;

    if-nez v0, :cond_13

    new-instance v0, Llcc;

    invoke-direct {v0}, Llcc;-><init>()V

    :cond_13
    iput-object v0, p0, La5h;->s:Llcc;

    iget p0, p0, La5h;->v:I

    invoke-virtual {v0, p0}, Loj9;->b(I)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_25

    new-instance v1, Lddc;

    invoke-direct {v1}, Lddc;-><init>()V

    invoke-virtual {v0, p0, v1}, Llcc;->i(ILjava/lang/Object;)V

    :cond_25
    check-cast v1, Lddc;

    invoke-virtual {v1, p1}, Lddc;->a(Ljava/lang/Object;)V

    return-void

    :cond_2b
    invoke-virtual {p0, p1}, La5h;->H(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final V(Ljava/lang/Object;)V
    .registers 6

    iget v0, p0, La5h;->t:I

    invoke-virtual {p0, v0}, La5h;->r(I)I

    move-result v0

    iget-object v1, p0, La5h;->b:[I

    mul-int/lit8 v2, v0, 0x5

    add-int/lit8 v2, v2, 0x1

    aget v1, v1, v2

    const/high16 v3, 0x10000000

    and-int/2addr v1, v3

    if-eqz v1, :cond_14

    goto :goto_19

    :cond_14
    const-string v1, "Updating the data of a group that was not created with a data slot"

    invoke-static {v1}, Lev4;->a(Ljava/lang/String;)V

    :goto_19
    iget-object v1, p0, La5h;->c:[Ljava/lang/Object;

    iget-object v3, p0, La5h;->b:[I

    invoke-virtual {p0, v0, v3}, La5h;->g(I[I)I

    move-result v0

    aget v2, v3, v2

    shr-int/lit8 v2, v2, 0x1d

    invoke-static {v2}, Ljava/lang/Integer;->bitCount(I)I

    move-result v2

    add-int/2addr v2, v0

    invoke-virtual {p0, v2}, La5h;->h(I)I

    move-result p0

    aput-object p1, v1, p0

    return-void
.end method

.method public final W(I)V
    .registers 3

    if-ltz p1, :cond_10

    iget-object v0, p0, La5h;->x:Lkcc;

    if-nez v0, :cond_d

    new-instance v0, Lkcc;

    invoke-direct {v0}, Lkcc;-><init>()V

    iput-object v0, p0, La5h;->x:Lkcc;

    :cond_d
    invoke-static {v0, p1}, Lckf;->B(Lkcc;I)V

    :cond_10
    return-void
.end method

.method public final X(ILjava/lang/Object;)V
    .registers 6

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result v0

    iget-object v1, p0, La5h;->b:[I

    array-length v2, v1

    if-ge v0, v2, :cond_15

    mul-int/lit8 v2, v0, 0x5

    add-int/lit8 v2, v2, 0x1

    aget v1, v1, v2

    const/high16 v2, 0x40000000  # 2.0f

    and-int/2addr v1, v2

    if-eqz v1, :cond_15

    goto :goto_2b

    :cond_15
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Updating the node of a group at "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " that was not created with as a node group"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lev4;->a(Ljava/lang/String;)V

    :goto_2b
    iget-object p1, p0, La5h;->c:[Ljava/lang/Object;

    iget-object v1, p0, La5h;->b:[I

    invoke-virtual {p0, v0, v1}, La5h;->g(I[I)I

    move-result v0

    invoke-virtual {p0, v0}, La5h;->h(I)I

    move-result p0

    aput-object p2, p1, p0

    return-void
.end method

.method public final a(I)V
    .registers 4

    if-ltz p1, :cond_3

    goto :goto_8

    :cond_3
    const-string v0, "Cannot seek backwards"

    invoke-static {v0}, Lev4;->a(Ljava/lang/String;)V

    :goto_8
    iget v0, p0, La5h;->n:I

    if-gtz v0, :cond_d

    goto :goto_12

    :cond_d
    const-string v0, "Cannot call seek() while inserting"

    invoke-static {v0}, Lcud;->b(Ljava/lang/String;)V

    :goto_12
    if-nez p1, :cond_15

    return-void

    :cond_15
    iget v0, p0, La5h;->t:I

    add-int/2addr v0, p1

    iget p1, p0, La5h;->v:I

    if-lt v0, p1, :cond_21

    iget p1, p0, La5h;->u:I

    if-gt v0, p1, :cond_21

    goto :goto_43

    :cond_21
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "Cannot seek outside the current group ("

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, La5h;->v:I

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v1, 0x2d

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget v1, p0, La5h;->u:I

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lev4;->a(Ljava/lang/String;)V

    :goto_43
    iput v0, p0, La5h;->t:I

    iget-object p1, p0, La5h;->b:[I

    invoke-virtual {p0, v0}, La5h;->r(I)I

    move-result v0

    invoke-virtual {p0, v0, p1}, La5h;->g(I[I)I

    move-result p1

    iput p1, p0, La5h;->i:I

    iput p1, p0, La5h;->j:I

    return-void
.end method

.method public final b(I)Lza8;
    .registers 6

    iget-object v0, p0, La5h;->d:Ljava/util/ArrayList;

    invoke-virtual {p0}, La5h;->p()I

    move-result v1

    invoke-static {v0, p1, v1}, Lz4h;->e(Ljava/util/ArrayList;II)I

    move-result v1

    if-gez v1, :cond_23

    new-instance v2, Lza8;

    iget v3, p0, La5h;->g:I

    if-gt p1, v3, :cond_13

    goto :goto_19

    :cond_13
    invoke-virtual {p0}, La5h;->p()I

    move-result p0

    sub-int/2addr p0, p1

    neg-int p1, p0

    :goto_19
    invoke-direct {v2, p1}, Lza8;-><init>(I)V

    add-int/lit8 v1, v1, 0x1

    neg-int p0, v1

    invoke-virtual {v0, p0, v2}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    return-object v2

    :cond_23
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lza8;

    return-object p0
.end method

.method public final c(Lza8;)I
    .registers 2

    iget p1, p1, Lza8;->a:I

    if-gez p1, :cond_a

    invoke-virtual {p0}, La5h;->p()I

    move-result p0

    add-int/2addr p0, p1

    return p0

    :cond_a
    return p1
.end method

.method public final d()V
    .registers 3

    iget v0, p0, La5h;->n:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, La5h;->n:I

    if-nez v0, :cond_17

    invoke-virtual {p0}, La5h;->o()I

    move-result v0

    iget v1, p0, La5h;->h:I

    sub-int/2addr v0, v1

    iget v1, p0, La5h;->u:I

    sub-int/2addr v0, v1

    iget-object p0, p0, La5h;->q:Lzj9;

    invoke-virtual {p0, v0}, Lzj9;->e(I)V

    :cond_17
    return-void
.end method

.method public final e(Z)V
    .registers 9

    const/4 v0, 0x1

    iput-boolean v0, p0, La5h;->w:Z

    if-eqz p1, :cond_2b

    iget-object p1, p0, La5h;->p:Lzj9;

    iget p1, p1, Lzj9;->b:I

    if-nez p1, :cond_2b

    invoke-virtual {p0}, La5h;->p()I

    move-result p1

    invoke-virtual {p0, p1}, La5h;->B(I)V

    iget-object p1, p0, La5h;->c:[Ljava/lang/Object;

    array-length p1, p1

    iget v0, p0, La5h;->l:I

    sub-int/2addr p1, v0

    iget v0, p0, La5h;->g:I

    invoke-virtual {p0, p1, v0}, La5h;->C(II)V

    iget p1, p0, La5h;->k:I

    iget v0, p0, La5h;->l:I

    add-int/2addr v0, p1

    iget-object v1, p0, La5h;->c:[Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-static {v1, p1, v0, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    invoke-virtual {p0}, La5h;->I()V

    :cond_2b
    iget-object p1, p0, La5h;->b:[I

    iget v0, p0, La5h;->g:I

    iget-object v1, p0, La5h;->c:[Ljava/lang/Object;

    iget v2, p0, La5h;->k:I

    iget-object v3, p0, La5h;->d:Ljava/util/ArrayList;

    iget-object v4, p0, La5h;->e:Ljava/util/HashMap;

    iget-object v5, p0, La5h;->f:Llcc;

    iget-object p0, p0, La5h;->a:Lx4h;

    iget-boolean v6, p0, Lx4h;->K:Z

    if-eqz v6, :cond_40

    goto :goto_45

    :cond_40
    const-string v6, "Unexpected writer close()"

    invoke-static {v6}, Lcud;->a(Ljava/lang/String;)V

    :goto_45
    const/4 v6, 0x0

    iput-boolean v6, p0, Lx4h;->K:Z

    iput-object p1, p0, Lx4h;->E:[I

    iput v0, p0, Lx4h;->F:I

    iput-object v1, p0, Lx4h;->G:[Ljava/lang/Object;

    iput v2, p0, Lx4h;->H:I

    iput-object v3, p0, Lx4h;->M:Ljava/util/ArrayList;

    iput-object v4, p0, Lx4h;->N:Ljava/util/HashMap;

    iput-object v5, p0, Lx4h;->O:Llcc;

    return-void
.end method

.method public final f(I)I
    .registers 3

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p1

    invoke-virtual {p0, p1, v0}, La5h;->g(I[I)I

    move-result p0

    return p0
.end method

.method public final g(I[I)I
    .registers 4

    invoke-virtual {p0}, La5h;->o()I

    move-result v0

    if-lt p1, v0, :cond_d

    iget-object p1, p0, La5h;->c:[Ljava/lang/Object;

    array-length p1, p1

    iget p0, p0, La5h;->l:I

    sub-int/2addr p1, p0

    return p1

    :cond_d
    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x4

    aget p1, p2, p1

    iget p2, p0, La5h;->l:I

    iget-object p0, p0, La5h;->c:[Ljava/lang/Object;

    array-length p0, p0

    if-gez p1, :cond_1f

    sub-int/2addr p0, p2

    add-int/2addr p0, p1

    add-int/lit8 p0, p0, 0x1

    return p0

    :cond_1f
    return p1
.end method

.method public final h(I)I
    .registers 3

    iget v0, p0, La5h;->l:I

    iget p0, p0, La5h;->k:I

    if-ge p1, p0, :cond_8

    const/4 p0, 0x0

    goto :goto_9

    :cond_8
    const/4 p0, 0x1

    :goto_9
    mul-int/2addr v0, p0

    add-int/2addr v0, p1

    return v0
.end method

.method public final j()V
    .registers 15

    iget v0, p0, La5h;->n:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lez v0, :cond_8

    move v0, v2

    goto :goto_9

    :cond_8
    move v0, v1

    :goto_9
    iget v3, p0, La5h;->t:I

    iget v4, p0, La5h;->u:I

    iget v5, p0, La5h;->v:I

    invoke-virtual {p0, v5}, La5h;->r(I)I

    move-result v6

    iget v7, p0, La5h;->o:I

    sub-int v8, v3, v5

    iget-object v9, p0, La5h;->b:[I

    mul-int/lit8 v10, v6, 0x5

    add-int/lit8 v11, v10, 0x1

    aget v9, v9, v11

    const/high16 v12, 0x40000000  # 2.0f

    and-int/2addr v9, v12

    if-eqz v9, :cond_26

    move v9, v2

    goto :goto_27

    :cond_26
    move v9, v1

    :goto_27
    iget-object v13, p0, La5h;->r:Lzj9;

    if-eqz v0, :cond_81

    iget-object v0, p0, La5h;->s:Llcc;

    if-eqz v0, :cond_4c

    invoke-virtual {v0, v5}, Loj9;->b(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lddc;

    if-eqz v3, :cond_4c

    iget-object v4, v3, Lddc;->a:[Ljava/lang/Object;

    iget v3, v3, Lddc;->b:I

    move v11, v1

    :goto_3c
    if-ge v11, v3, :cond_46

    aget-object v12, v4, v11

    invoke-virtual {p0, v12}, La5h;->H(Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v11, v11, 0x1

    goto :goto_3c

    :cond_46
    invoke-virtual {v0, v5}, Llcc;->g(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lddc;

    :cond_4c
    iget-object v0, p0, La5h;->b:[I

    add-int/lit8 v10, v10, 0x3

    aput v8, v0, v10

    invoke-static {v6, v7, v0}, Lz4h;->c(II[I)V

    invoke-virtual {v13}, Lzj9;->d()I

    move-result v0

    if-eqz v9, :cond_5c

    move v7, v2

    :cond_5c
    add-int/2addr v0, v7

    iput v0, p0, La5h;->o:I

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, v5, v0}, La5h;->G(I[I)I

    move-result v0

    iput v0, p0, La5h;->v:I

    if-gez v0, :cond_6e

    invoke-virtual {p0}, La5h;->p()I

    move-result v0

    goto :goto_73

    :cond_6e
    add-int/2addr v0, v2

    invoke-virtual {p0, v0}, La5h;->r(I)I

    move-result v0

    :goto_73
    if-gez v0, :cond_76

    goto :goto_7c

    :cond_76
    iget-object v1, p0, La5h;->b:[I

    invoke-virtual {p0, v0, v1}, La5h;->g(I[I)I

    move-result v1

    :goto_7c
    iput v1, p0, La5h;->i:I

    iput v1, p0, La5h;->j:I

    return-void

    :cond_81
    if-ne v3, v4, :cond_84

    goto :goto_89

    :cond_84
    const-string v0, "Expected to be at the end of a group"

    invoke-static {v0}, Lev4;->a(Ljava/lang/String;)V

    :goto_89
    iget-object v0, p0, La5h;->b:[I

    add-int/lit8 v10, v10, 0x3

    aget v3, v0, v10

    aget v4, v0, v11

    const v11, 0x3ffffff

    and-int/2addr v4, v11

    aput v8, v0, v10

    invoke-static {v6, v7, v0}, Lz4h;->c(II[I)V

    iget-object v0, p0, La5h;->p:Lzj9;

    invoke-virtual {v0}, Lzj9;->d()I

    move-result v0

    invoke-virtual {p0}, La5h;->o()I

    move-result v6

    iget v10, p0, La5h;->h:I

    sub-int/2addr v6, v10

    iget-object v10, p0, La5h;->q:Lzj9;

    invoke-virtual {v10}, Lzj9;->d()I

    move-result v10

    sub-int/2addr v6, v10

    iput v6, p0, La5h;->u:I

    iput v0, p0, La5h;->v:I

    iget-object v6, p0, La5h;->b:[I

    invoke-virtual {p0, v5, v6}, La5h;->G(I[I)I

    move-result v5

    invoke-virtual {v13}, Lzj9;->d()I

    move-result v6

    iput v6, p0, La5h;->o:I

    if-ne v5, v0, :cond_c9

    if-eqz v9, :cond_c3

    goto :goto_c5

    :cond_c3
    sub-int v1, v7, v4

    :goto_c5
    add-int/2addr v6, v1

    iput v6, p0, La5h;->o:I

    return-void

    :cond_c9
    sub-int/2addr v8, v3

    if-eqz v9, :cond_ce

    move v7, v1

    goto :goto_cf

    :cond_ce
    sub-int/2addr v7, v4

    :goto_cf
    if-nez v8, :cond_d3

    if-eqz v7, :cond_10a

    :cond_d3
    :goto_d3
    if-eqz v5, :cond_10a

    if-eq v5, v0, :cond_10a

    if-nez v7, :cond_db

    if-eqz v8, :cond_10a

    :cond_db
    invoke-virtual {p0, v5}, La5h;->r(I)I

    move-result v3

    if-eqz v8, :cond_ec

    iget-object v4, p0, La5h;->b:[I

    mul-int/lit8 v6, v3, 0x5

    add-int/lit8 v6, v6, 0x3

    aget v9, v4, v6

    add-int/2addr v9, v8

    aput v9, v4, v6

    :cond_ec
    if-eqz v7, :cond_fa

    iget-object v4, p0, La5h;->b:[I

    mul-int/lit8 v6, v3, 0x5

    add-int/2addr v6, v2

    aget v6, v4, v6

    and-int/2addr v6, v11

    add-int/2addr v6, v7

    invoke-static {v3, v6, v4}, Lz4h;->c(II[I)V

    :cond_fa
    iget-object v4, p0, La5h;->b:[I

    mul-int/lit8 v3, v3, 0x5

    add-int/2addr v3, v2

    aget v3, v4, v3

    and-int/2addr v3, v12

    if-eqz v3, :cond_105

    move v7, v1

    :cond_105
    invoke-virtual {p0, v5, v4}, La5h;->G(I[I)I

    move-result v5

    goto :goto_d3

    :cond_10a
    iget v0, p0, La5h;->o:I

    add-int/2addr v0, v7

    iput v0, p0, La5h;->o:I

    return-void
.end method

.method public final k()V
    .registers 3

    iget v0, p0, La5h;->n:I

    if-lez v0, :cond_5

    goto :goto_a

    :cond_5
    const-string v0, "Unbalanced begin/end insert"

    invoke-static {v0}, Lcud;->b(Ljava/lang/String;)V

    :goto_a
    iget v0, p0, La5h;->n:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La5h;->n:I

    if-nez v0, :cond_32

    iget-object v0, p0, La5h;->r:Lzj9;

    iget v0, v0, Lzj9;->b:I

    iget-object v1, p0, La5h;->p:Lzj9;

    iget v1, v1, Lzj9;->b:I

    if-ne v0, v1, :cond_1d

    goto :goto_22

    :cond_1d
    const-string v0, "startGroup/endGroup mismatch while inserting"

    invoke-static {v0}, Lev4;->a(Ljava/lang/String;)V

    :goto_22
    invoke-virtual {p0}, La5h;->o()I

    move-result v0

    iget v1, p0, La5h;->h:I

    sub-int/2addr v0, v1

    iget-object v1, p0, La5h;->q:Lzj9;

    invoke-virtual {v1}, Lzj9;->d()I

    move-result v1

    sub-int/2addr v0, v1

    iput v0, p0, La5h;->u:I

    :cond_32
    return-void
.end method

.method public final l(I)V
    .registers 6

    iget v0, p0, La5h;->n:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-gtz v0, :cond_8

    move v0, v2

    goto :goto_9

    :cond_8
    move v0, v1

    :goto_9
    if-nez v0, :cond_10

    const-string v0, "Cannot call ensureStarted() while inserting"

    invoke-static {v0}, Lev4;->a(Ljava/lang/String;)V

    :cond_10
    iget v0, p0, La5h;->v:I

    if-eq v0, p1, :cond_47

    if-lt p1, v0, :cond_1b

    iget v3, p0, La5h;->u:I

    if-ge p1, v3, :cond_1b

    move v1, v2

    :cond_1b
    if-nez v1, :cond_36

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Started group at "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " must be a subgroup of the group at "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lev4;->a(Ljava/lang/String;)V

    :cond_36
    iget v0, p0, La5h;->t:I

    iget v1, p0, La5h;->i:I

    iget v2, p0, La5h;->j:I

    iput p1, p0, La5h;->t:I

    invoke-virtual {p0}, La5h;->R()V

    iput v0, p0, La5h;->t:I

    iput v1, p0, La5h;->i:I

    iput v2, p0, La5h;->j:I

    :cond_47
    return-void
.end method

.method public final m(III)V
    .registers 6

    iget v0, p0, La5h;->g:I

    if-ge p1, v0, :cond_5

    goto :goto_d

    :cond_5
    invoke-virtual {p0}, La5h;->p()I

    move-result v0

    sub-int/2addr v0, p1

    add-int/lit8 v0, v0, 0x2

    neg-int p1, v0

    :goto_d
    if-ge p3, p2, :cond_2f

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, p3}, La5h;->r(I)I

    move-result v1

    mul-int/lit8 v1, v1, 0x5

    add-int/lit8 v1, v1, 0x2

    aput p1, v0, v1

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, p3}, La5h;->r(I)I

    move-result v1

    mul-int/lit8 v1, v1, 0x5

    add-int/lit8 v1, v1, 0x3

    aget v0, v0, v1

    add-int/2addr v0, p3

    add-int/lit8 v1, p3, 0x1

    invoke-virtual {p0, p3, v0, v1}, La5h;->m(III)V

    move p3, v0

    goto :goto_d

    :cond_2f
    return-void
.end method

.method public final n(ILq98;)V
    .registers 23

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    iget-object v3, v0, La5h;->b:[I

    invoke-virtual {v0, v1, v3}, La5h;->G(I[I)I

    move-result v3

    invoke-virtual {v0}, La5h;->p()I

    move-result v4

    invoke-virtual/range {p0 .. p1}, La5h;->u(I)I

    move-result v5

    add-int/2addr v5, v1

    move v7, v1

    const/4 v8, 0x0

    const/4 v9, 0x0

    :goto_18
    if-ge v7, v5, :cond_152

    invoke-virtual {v0, v7}, La5h;->f(I)I

    move-result v10

    add-int/lit8 v11, v7, 0x1

    invoke-virtual {v0, v11}, La5h;->f(I)I

    move-result v12

    :goto_24
    if-ge v10, v12, :cond_a9

    invoke-virtual {v0, v10}, La5h;->h(I)I

    move-result v14

    iget-object v15, v0, La5h;->c:[Ljava/lang/Object;

    aget-object v14, v15, v14

    instance-of v15, v14, Lib8;

    if-eqz v15, :cond_99

    move-object v15, v14

    check-cast v15, Lib8;

    const/16 v16, 0x0

    instance-of v6, v15, Lib8;

    if-eqz v6, :cond_3c

    goto :goto_3e

    :cond_3c
    move-object/from16 v15, v16

    :goto_3e
    if-eqz v15, :cond_90

    iget v6, v15, Lib8;->b:I

    if-ltz v6, :cond_8d

    invoke-virtual {v0, v7}, La5h;->u(I)I

    move-result v14

    add-int/2addr v14, v7

    move v15, v11

    const/4 v13, 0x0

    :goto_4b
    if-ge v15, v14, :cond_71

    if-ge v13, v6, :cond_71

    invoke-virtual {v0, v15}, La5h;->r(I)I

    move-result v17

    move/from16 v18, v3

    iget-object v3, v0, La5h;->b:[I

    mul-int/lit8 v17, v17, 0x5

    add-int/lit8 v19, v17, 0x3

    aget v19, v3, v19

    add-int v15, v19, v15

    if-ge v15, v14, :cond_6e

    add-int/lit8 v17, v17, 0x1

    aget v3, v3, v17

    const/high16 v17, 0x20000000

    and-int v3, v3, v17

    if-eqz v3, :cond_6c

    goto :goto_6e

    :cond_6c
    add-int/lit8 v13, v13, 0x1

    :cond_6e
    :goto_6e
    move/from16 v3, v18

    goto :goto_4b

    :cond_71
    move/from16 v18, v3

    if-nez v8, :cond_7c

    sget-object v3, Lxj9;->a:[I

    new-instance v8, Lmcc;

    invoke-direct {v8}, Lmcc;-><init>()V

    :cond_7c
    if-nez v9, :cond_83

    new-instance v9, Lkcc;

    invoke-direct {v9}, Lkcc;-><init>()V

    :cond_83
    invoke-virtual {v8, v15}, Lmcc;->a(I)Z

    invoke-virtual {v9, v15}, Lkcc;->a(I)V

    invoke-virtual {v9, v10}, Lkcc;->a(I)V

    goto :goto_a3

    :cond_8d
    :goto_8d
    move/from16 v18, v3

    goto :goto_9c

    :cond_90
    const-string v0, "Inconsistent composition"

    invoke-static {v0}, Lev4;->b(Ljava/lang/String;)Ljava/lang/Void;

    invoke-static {}, Le97;->r()V

    return-void

    :cond_99
    const/16 v16, 0x0

    goto :goto_8d

    :goto_9c
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v14}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_a3
    add-int/lit8 v10, v10, 0x1

    move/from16 v3, v18

    goto/16 :goto_24

    :cond_a9
    move/from16 v18, v3

    const/16 v16, 0x0

    if-ge v11, v4, :cond_b6

    iget-object v3, v0, La5h;->b:[I

    invoke-virtual {v0, v11, v3}, La5h;->G(I[I)I

    move-result v3

    goto :goto_b7

    :cond_b6
    const/4 v3, -0x1

    :goto_b7
    if-eq v3, v7, :cond_149

    move/from16 v6, v18

    :goto_bb
    if-eqz v9, :cond_135

    if-eqz v8, :cond_135

    invoke-virtual {v8, v7}, Lmcc;->f(I)Z

    move-result v10

    if-eqz v10, :cond_135

    iget v10, v9, Lkcc;->b:I

    div-int/lit8 v12, v10, 0x2

    const/4 v14, 0x0

    const/4 v15, 0x0

    :goto_cb
    if-ge v14, v12, :cond_109

    mul-int/lit8 v13, v14, 0x2

    move/from16 v18, v4

    invoke-virtual {v9, v13}, Lkcc;->c(I)I

    move-result v4

    if-ne v4, v7, :cond_ed

    add-int/lit8 v13, v13, 0x1

    invoke-virtual {v9, v13}, Lkcc;->c(I)I

    move-result v4

    iget-object v13, v0, La5h;->c:[Ljava/lang/Object;

    invoke-virtual {v0, v4}, La5h;->h(I)I

    move-result v19

    aget-object v13, v13, v19

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4, v13}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_102

    :cond_ed
    if-eq v13, v15, :cond_100

    add-int/lit8 v2, v15, 0x1

    invoke-virtual {v9, v15, v4}, Lkcc;->f(II)V

    add-int/lit8 v15, v15, 0x2

    add-int/lit8 v13, v13, 0x1

    invoke-virtual {v9, v13}, Lkcc;->c(I)I

    move-result v4

    invoke-virtual {v9, v2, v4}, Lkcc;->f(II)V

    goto :goto_102

    :cond_100
    add-int/lit8 v15, v15, 0x2

    :goto_102
    add-int/lit8 v14, v14, 0x1

    move-object/from16 v2, p2

    move/from16 v4, v18

    goto :goto_cb

    :cond_109
    move/from16 v18, v4

    if-eq v15, v10, :cond_137

    if-ltz v15, :cond_12f

    iget v2, v9, Lkcc;->b:I

    if-gt v15, v2, :cond_12f

    if-ltz v10, :cond_12f

    if-gt v10, v2, :cond_12f

    if-lt v10, v15, :cond_129

    if-eq v10, v15, :cond_137

    if-ge v10, v2, :cond_122

    iget-object v4, v9, Lkcc;->a:[I

    invoke-static {v15, v10, v2, v4, v4}, Lmr0;->t0(III[I[I)V

    :cond_122
    iget v2, v9, Lkcc;->b:I

    sub-int/2addr v10, v15

    sub-int/2addr v2, v10

    iput v2, v9, Lkcc;->b:I

    goto :goto_137

    :cond_129
    const-string v0, "The end index must be < start index"

    invoke-static {v0}, Lef1;->h(Ljava/lang/String;)V

    throw v16

    :cond_12f
    const-string v0, "Index must be between 0 and size"

    invoke-static {v0}, Lef1;->j(Ljava/lang/String;)V

    throw v16

    :cond_135
    move/from16 v18, v4

    :cond_137
    :goto_137
    if-eq v7, v1, :cond_14b

    if-eq v6, v3, :cond_14b

    iget-object v2, v0, La5h;->b:[I

    invoke-virtual {v0, v6, v2}, La5h;->G(I[I)I

    move-result v2

    move v7, v6

    move/from16 v4, v18

    move v6, v2

    move-object/from16 v2, p2

    goto/16 :goto_bb

    :cond_149
    move/from16 v18, v4

    :cond_14b
    move-object/from16 v2, p2

    move v7, v11

    move/from16 v4, v18

    goto/16 :goto_18

    :cond_152
    return-void
.end method

.method public final o()I
    .registers 1

    iget-object p0, p0, La5h;->b:[I

    array-length p0, p0

    div-int/lit8 p0, p0, 0x5

    return p0
.end method

.method public final p()I
    .registers 2

    invoke-virtual {p0}, La5h;->o()I

    move-result v0

    iget p0, p0, La5h;->h:I

    sub-int/2addr v0, p0

    return v0
.end method

.method public final q(I)Ljava/lang/Object;
    .registers 6

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p1

    iget-object v0, p0, La5h;->b:[I

    mul-int/lit8 v1, p1, 0x5

    add-int/lit8 v1, v1, 0x1

    aget v2, v0, v1

    const/high16 v3, 0x10000000

    and-int/2addr v2, v3

    if-eqz v2, :cond_23

    iget-object v2, p0, La5h;->c:[Ljava/lang/Object;

    invoke-virtual {p0, p1, v0}, La5h;->g(I[I)I

    move-result p0

    aget p1, v0, v1

    shr-int/lit8 p1, p1, 0x1d

    invoke-static {p1}, Ljava/lang/Integer;->bitCount(I)I

    move-result p1

    add-int/2addr p1, p0

    aget-object p0, v2, p1

    return-object p0

    :cond_23
    sget-object p0, Lxu4;->a:Lmx8;

    return-object p0
.end method

.method public final r(I)I
    .registers 3

    iget v0, p0, La5h;->h:I

    iget p0, p0, La5h;->g:I

    if-ge p1, p0, :cond_8

    const/4 p0, 0x0

    goto :goto_9

    :cond_8
    const/4 p0, 0x1

    :goto_9
    mul-int/2addr v0, p0

    add-int/2addr v0, p1

    return v0
.end method

.method public final s(I)I
    .registers 3

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p0

    mul-int/lit8 p0, p0, 0x5

    aget p0, v0, p0

    return p0
.end method

.method public final t(I)Ljava/lang/Object;
    .registers 5

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p1

    iget-object v0, p0, La5h;->b:[I

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 v1, p1, 0x1

    aget v1, v0, v1

    const/high16 v2, 0x20000000

    and-int/2addr v2, v1

    if-eqz v2, :cond_21

    iget-object p0, p0, La5h;->c:[Ljava/lang/Object;

    add-int/lit8 p1, p1, 0x4

    aget p1, v0, p1

    shr-int/lit8 v0, v1, 0x1e

    invoke-static {v0}, Ljava/lang/Integer;->bitCount(I)I

    move-result v0

    add-int/2addr v0, p1

    aget-object p0, p0, v0

    return-object p0

    :cond_21
    const/4 p0, 0x0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "SlotWriter(current = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, La5h;->t:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " end="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La5h;->u:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " size = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, La5h;->p()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " gap="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La5h;->g:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v1, 0x2d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget v1, p0, La5h;->g:I

    iget p0, p0, La5h;->h:I

    add-int/2addr v1, p0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final u(I)I
    .registers 3

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p0

    mul-int/lit8 p0, p0, 0x5

    add-int/lit8 p0, p0, 0x3

    aget p0, v0, p0

    return p0
.end method

.method public final v(II)Z
    .registers 8

    iget v0, p0, La5h;->v:I

    const/4 v1, 0x0

    if-ne p2, v0, :cond_8

    iget p0, p0, La5h;->u:I

    goto :goto_41

    :cond_8
    iget-object v0, p0, La5h;->p:Lzj9;

    invoke-virtual {v0, v1}, Lzj9;->c(I)I

    move-result v2

    if-le p2, v2, :cond_16

    invoke-virtual {p0, p2}, La5h;->u(I)I

    move-result p0

    :goto_14
    add-int/2addr p0, p2

    goto :goto_41

    :cond_16
    iget-object v2, v0, Lzj9;->a:[I

    array-length v3, v2

    iget v0, v0, Lzj9;->b:I

    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    move v3, v1

    :goto_20
    if-ge v3, v0, :cond_2a

    aget v4, v2, v3

    if-ne v4, p2, :cond_27

    goto :goto_2b

    :cond_27
    add-int/lit8 v3, v3, 0x1

    goto :goto_20

    :cond_2a
    const/4 v3, -0x1

    :goto_2b
    if-gez v3, :cond_32

    invoke-virtual {p0, p2}, La5h;->u(I)I

    move-result p0

    goto :goto_14

    :cond_32
    invoke-virtual {p0}, La5h;->o()I

    move-result v0

    iget v2, p0, La5h;->h:I

    sub-int/2addr v0, v2

    iget-object p0, p0, La5h;->q:Lzj9;

    iget-object p0, p0, Lzj9;->a:[I

    aget p0, p0, v3

    sub-int p0, v0, p0

    :goto_41
    if-le p1, p2, :cond_47

    if-ge p1, p0, :cond_47

    const/4 p0, 0x1

    return p0

    :cond_47
    return v1
.end method

.method public final w(I)V
    .registers 13

    if-lez p1, :cond_78

    iget v0, p0, La5h;->t:I

    invoke-virtual {p0, v0}, La5h;->B(I)V

    iget v1, p0, La5h;->g:I

    iget v2, p0, La5h;->h:I

    iget-object v3, p0, La5h;->b:[I

    array-length v4, v3

    div-int/lit8 v4, v4, 0x5

    sub-int v5, v4, v2

    const/4 v6, 0x0

    if-ge v2, p1, :cond_3c

    mul-int/lit8 v7, v4, 0x2

    add-int v8, v5, p1

    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    move-result v7

    const/16 v8, 0x20

    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    move-result v7

    mul-int/lit8 v8, v7, 0x5

    new-array v8, v8, [I

    sub-int/2addr v7, v5

    add-int/2addr v2, v1

    add-int v9, v1, v7

    mul-int/lit8 v10, v1, 0x5

    invoke-static {v6, v6, v10, v3, v8}, Lmr0;->t0(III[I[I)V

    mul-int/lit8 v9, v9, 0x5

    mul-int/lit8 v2, v2, 0x5

    mul-int/lit8 v4, v4, 0x5

    invoke-static {v9, v2, v4, v3, v8}, Lmr0;->t0(III[I[I)V

    iput-object v8, p0, La5h;->b:[I

    move v2, v7

    :cond_3c
    iget v3, p0, La5h;->u:I

    if-lt v3, v1, :cond_43

    add-int/2addr v3, p1

    iput v3, p0, La5h;->u:I

    :cond_43
    add-int v3, v1, p1

    iput v3, p0, La5h;->g:I

    sub-int/2addr v2, p1

    iput v2, p0, La5h;->h:I

    if-lez v5, :cond_52

    add-int/2addr v0, p1

    invoke-virtual {p0, v0}, La5h;->f(I)I

    move-result v0

    goto :goto_53

    :cond_52
    move v0, v6

    :goto_53
    iget v2, p0, La5h;->m:I

    if-ge v2, v1, :cond_58

    goto :goto_5a

    :cond_58
    iget v6, p0, La5h;->k:I

    :goto_5a
    iget v2, p0, La5h;->l:I

    iget-object v4, p0, La5h;->c:[Ljava/lang/Object;

    array-length v4, v4

    invoke-static {v0, v6, v2, v4}, La5h;->i(IIII)I

    move-result v0

    move v2, v1

    :goto_64
    if-ge v2, v3, :cond_71

    iget-object v4, p0, La5h;->b:[I

    mul-int/lit8 v5, v2, 0x5

    add-int/lit8 v5, v5, 0x4

    aput v0, v4, v5

    add-int/lit8 v2, v2, 0x1

    goto :goto_64

    :cond_71
    iget v0, p0, La5h;->m:I

    if-lt v0, v1, :cond_78

    add-int/2addr v0, p1

    iput v0, p0, La5h;->m:I

    :cond_78
    return-void
.end method

.method public final x(II)V
    .registers 12

    if-lez p1, :cond_47

    iget v0, p0, La5h;->i:I

    invoke-virtual {p0, v0, p2}, La5h;->C(II)V

    iget p2, p0, La5h;->k:I

    iget v0, p0, La5h;->l:I

    if-ge v0, p1, :cond_3a

    iget-object v1, p0, La5h;->c:[Ljava/lang/Object;

    array-length v2, v1

    sub-int v3, v2, v0

    mul-int/lit8 v4, v2, 0x2

    add-int v5, v3, p1

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v4

    const/16 v5, 0x20

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v4

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v6, 0x0

    move v7, v6

    :goto_24
    if-ge v7, v4, :cond_2c

    const/4 v8, 0x0

    aput-object v8, v5, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_24

    :cond_2c
    sub-int/2addr v4, v3

    add-int/2addr v0, p2

    add-int v3, p2, v4

    invoke-static {v1, v6, v5, v6, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    sub-int/2addr v2, v0

    invoke-static {v1, v0, v5, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v5, p0, La5h;->c:[Ljava/lang/Object;

    move v0, v4

    :cond_3a
    iget v1, p0, La5h;->j:I

    if-lt v1, p2, :cond_41

    add-int/2addr v1, p1

    iput v1, p0, La5h;->j:I

    :cond_41
    add-int/2addr p2, p1

    iput p2, p0, La5h;->k:I

    sub-int/2addr v0, p1

    iput v0, p0, La5h;->l:I

    :cond_47
    return-void
.end method

.method public final y(I)Z
    .registers 3

    iget-object v0, p0, La5h;->b:[I

    invoke-virtual {p0, p1}, La5h;->r(I)I

    move-result p0

    mul-int/lit8 p0, p0, 0x5

    const/4 p1, 0x1

    add-int/2addr p0, p1

    aget p0, v0, p0

    const/high16 v0, 0x40000000  # 2.0f

    and-int/2addr p0, v0

    if-eqz p0, :cond_12

    return p1

    :cond_12
    const/4 p0, 0x0

    return p0
.end method
