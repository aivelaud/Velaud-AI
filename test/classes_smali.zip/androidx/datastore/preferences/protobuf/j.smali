.class public abstract Landroidx/datastore/preferences/protobuf/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/Class;

.field public static final b:Landroidx/datastore/preferences/protobuf/k;

.field public static final c:Landroidx/datastore/preferences/protobuf/m;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget-object v0, Lc00;->a:Ljava/lang/Class;

    const/4 v0, 0x0

    :try_start_3
    const-string v1, "androidx.datastore.preferences.protobuf.GeneratedMessage"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_a

    goto :goto_b

    :catchall_a
    move-object v1, v0

    :goto_b
    sput-object v1, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    :try_start_d
    sget-object v1, Lc00;->a:Ljava/lang/Class;
    :try_end_f
    .catchall {:try_start_d .. :try_end_f} :catchall_25

    :try_start_f
    const-string v1, "androidx.datastore.preferences.protobuf.UnknownFieldSetSchema"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1
    :try_end_15
    .catchall {:try_start_f .. :try_end_15} :catchall_16

    goto :goto_17

    :catchall_16
    move-object v1, v0

    :goto_17
    if-nez v1, :cond_1a

    goto :goto_25

    :cond_1a
    :try_start_1a
    invoke-virtual {v1, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/datastore/preferences/protobuf/k;
    :try_end_24
    .catchall {:try_start_1a .. :try_end_24} :catchall_25

    move-object v0, v1

    :catchall_25
    :goto_25
    sput-object v0, Landroidx/datastore/preferences/protobuf/j;->b:Landroidx/datastore/preferences/protobuf/k;

    new-instance v0, Landroidx/datastore/preferences/protobuf/m;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/datastore/preferences/protobuf/j;->c:Landroidx/datastore/preferences/protobuf/m;

    return-void
.end method

.method public static a(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lhj9;

    if-eqz v2, :cond_13

    check-cast p0, Lhj9;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_29

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_29
    return v2
.end method

.method public static b(ILjava/util/List;)I
    .registers 2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-nez p1, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result p0

    add-int/lit8 p0, p0, 0x4

    mul-int/2addr p0, p1

    return p0
.end method

.method public static c(ILjava/util/List;)I
    .registers 2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-nez p1, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result p0

    add-int/lit8 p0, p0, 0x8

    mul-int/2addr p0, p1

    return p0
.end method

.method public static d(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lhj9;

    if-eqz v2, :cond_13

    check-cast p0, Lhj9;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_29

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_29
    return v2
.end method

.method public static e(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lmxa;

    if-eqz v2, :cond_13

    check-cast p0, Lmxa;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_28

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_28
    return v2
.end method

.method public static f(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    goto :goto_11

    :cond_8
    instance-of v2, p0, Lhj9;

    if-eqz v2, :cond_14

    invoke-static {p0}, Lb40;->x(Ljava/lang/Object;)V

    if-gtz v0, :cond_12

    :goto_11
    return v1

    :cond_12
    const/4 p0, 0x0

    throw p0

    :cond_14
    move v2, v1

    :goto_15
    if-ge v1, v0, :cond_2e

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    shl-int/lit8 v4, v3, 0x1

    shr-int/lit8 v3, v3, 0x1f

    xor-int/2addr v3, v4

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :cond_2e
    return v2
.end method

.method public static g(Ljava/util/List;)I
    .registers 9

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    goto :goto_11

    :cond_8
    instance-of v2, p0, Lmxa;

    if-eqz v2, :cond_14

    invoke-static {p0}, Lb40;->x(Ljava/lang/Object;)V

    if-gtz v0, :cond_12

    :goto_11
    return v1

    :cond_12
    const/4 p0, 0x0

    throw p0

    :cond_14
    move v2, v1

    :goto_15
    if-ge v1, v0, :cond_30

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v5, 0x1

    shl-long v5, v3, v5

    const/16 v7, 0x3f

    shr-long/2addr v3, v7

    xor-long/2addr v3, v5

    invoke-static {v3, v4}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :cond_30
    return v2
.end method

.method public static h(Ljava/util/List;)I
    .registers 5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lhj9;

    if-eqz v2, :cond_13

    check-cast p0, Lhj9;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_28

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_28
    return v2
.end method

.method public static i(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lmxa;

    if-eqz v2, :cond_13

    check-cast p0, Lmxa;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_28

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_28
    return v2
.end method

.method public static j(Ljava/lang/Object;ILs3;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/k;)Ljava/lang/Object;
    .registers 5

    return-object p3
.end method

.method public static k(Landroidx/datastore/preferences/protobuf/k;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 9

    check-cast p0, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/datastore/preferences/protobuf/f;

    iget-object p0, p1, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    check-cast p2, Landroidx/datastore/preferences/protobuf/f;

    iget-object p2, p2, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    sget-object v0, Landroidx/datastore/preferences/protobuf/l;->f:Landroidx/datastore/preferences/protobuf/l;

    invoke-virtual {v0, p2}, Landroidx/datastore/preferences/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16

    goto :goto_75

    :cond_16
    invoke-virtual {v0, p0}, Landroidx/datastore/preferences/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_47

    iget v0, p0, Landroidx/datastore/preferences/protobuf/l;->a:I

    iget v1, p2, Landroidx/datastore/preferences/protobuf/l;->a:I

    add-int/2addr v0, v1

    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/l;->b:[I

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v1

    iget-object v3, p2, Landroidx/datastore/preferences/protobuf/l;->b:[I

    iget v4, p0, Landroidx/datastore/preferences/protobuf/l;->a:I

    iget v5, p2, Landroidx/datastore/preferences/protobuf/l;->a:I

    invoke-static {v3, v2, v1, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v3, p0, Landroidx/datastore/preferences/protobuf/l;->c:[Ljava/lang/Object;

    invoke-static {v3, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    iget-object v4, p2, Landroidx/datastore/preferences/protobuf/l;->c:[Ljava/lang/Object;

    iget p0, p0, Landroidx/datastore/preferences/protobuf/l;->a:I

    iget p2, p2, Landroidx/datastore/preferences/protobuf/l;->a:I

    invoke-static {v4, v2, v3, p0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance p0, Landroidx/datastore/preferences/protobuf/l;

    const/4 p2, 0x1

    invoke-direct {p0, v0, v1, v3, p2}, Landroidx/datastore/preferences/protobuf/l;-><init>(I[I[Ljava/lang/Object;Z)V

    goto :goto_75

    :cond_47
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2, v0}, Landroidx/datastore/preferences/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_51

    goto :goto_75

    :cond_51
    iget-boolean v0, p0, Landroidx/datastore/preferences/protobuf/l;->e:Z

    if-eqz v0, :cond_78

    iget v0, p0, Landroidx/datastore/preferences/protobuf/l;->a:I

    iget v1, p2, Landroidx/datastore/preferences/protobuf/l;->a:I

    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroidx/datastore/preferences/protobuf/l;->a(I)V

    iget-object v1, p2, Landroidx/datastore/preferences/protobuf/l;->b:[I

    iget-object v3, p0, Landroidx/datastore/preferences/protobuf/l;->b:[I

    iget v4, p0, Landroidx/datastore/preferences/protobuf/l;->a:I

    iget v5, p2, Landroidx/datastore/preferences/protobuf/l;->a:I

    invoke-static {v1, v2, v3, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v1, p2, Landroidx/datastore/preferences/protobuf/l;->c:[Ljava/lang/Object;

    iget-object v3, p0, Landroidx/datastore/preferences/protobuf/l;->c:[Ljava/lang/Object;

    iget v4, p0, Landroidx/datastore/preferences/protobuf/l;->a:I

    iget p2, p2, Landroidx/datastore/preferences/protobuf/l;->a:I

    invoke-static {v1, v2, v3, v4, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput v0, p0, Landroidx/datastore/preferences/protobuf/l;->a:I

    :goto_75
    iput-object p0, p1, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    return-void

    :cond_78
    invoke-static {}, Lty9;->u()V

    return-void
.end method

.method public static l(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 2

    if-eq p0, p1, :cond_d

    if-eqz p0, :cond_b

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_b

    goto :goto_d

    :cond_b
    const/4 p0, 0x0

    return p0

    :cond_d
    :goto_d
    const/4 p0, 0x1

    return p0
.end method

.method public static m(ILjava/util/List;Lxs5;Z)V
    .registers 6

    if-eqz p1, :cond_6a

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6a

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lnz1;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_54

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3a

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/datastore/preferences/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x1

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3a
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6a

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    int-to-byte p0, p0

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->m(B)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_54
    :goto_54
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6a

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Boolean;

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->o(IZ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_54

    :cond_6a
    return-void
.end method

.method public static n(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_74

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_74

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lgj6;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_57

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3a

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Double;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/datastore/preferences/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3a
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_74

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Double;

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->u(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_57
    :goto_57
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_74

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Double;

    invoke-virtual {p3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_57

    :cond_74
    return-void
.end method

.method public static o(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_6c

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6c

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lhj9;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_56

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3d

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3d
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_40
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->w(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_40

    :cond_56
    :goto_56
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->v(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_56

    :cond_6c
    return-void
.end method

.method public static p(ILjava/util/List;Lxs5;Z)V
    .registers 6

    if-eqz p1, :cond_69

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_69

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lhj9;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_53

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3a

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/datastore/preferences/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3a
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->s(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_53
    :goto_53
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_53

    :cond_69
    return-void
.end method

.method public static q(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_69

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_69

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lmxa;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_53

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3a

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/datastore/preferences/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3a
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->u(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_53
    :goto_53
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_53

    :cond_69
    return-void
.end method

.method public static r(ILjava/util/List;Lxs5;Z)V
    .registers 6

    if-eqz p1, :cond_74

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_74

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lwy7;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_57

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3a

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Float;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/datastore/preferences/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3a
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_74

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->s(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_57
    :goto_57
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_74

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Float;

    invoke-virtual {p3}, Ljava/lang/Float;->floatValue()F

    move-result p3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_57

    :cond_74
    return-void
.end method

.method public static s(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_6c

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6c

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lhj9;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_56

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3d

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3d
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_40
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->w(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_40

    :cond_56
    :goto_56
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->v(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_56

    :cond_6c
    return-void
.end method

.method public static t(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_6b

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6b

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lmxa;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_55

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3c

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3c
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3f
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6b

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->E(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3f

    :cond_55
    :goto_55
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6b

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_55

    :cond_6b
    return-void
.end method

.method public static u(ILjava/util/List;Lxs5;Z)V
    .registers 6

    if-eqz p1, :cond_69

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_69

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lhj9;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_53

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3a

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/datastore/preferences/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3a
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->s(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_53
    :goto_53
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_53

    :cond_69
    return-void
.end method

.method public static v(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_69

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_69

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lmxa;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_53

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3a

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/datastore/preferences/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3a
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->u(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_53
    :goto_53
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_69

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_53

    :cond_69
    return-void
.end method

.method public static w(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_7a

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7a

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lhj9;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_5f

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_41

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    shl-int/lit8 v2, v1, 0x1

    shr-int/lit8 v1, v1, 0x1f

    xor-int/2addr v1, v2

    invoke-static {v1}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_41
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_44
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_7a

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    shl-int/lit8 p3, p0, 0x1

    shr-int/lit8 p0, p0, 0x1f

    xor-int/2addr p0, p3

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_44

    :cond_5f
    :goto_5f
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_7a

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    shl-int/lit8 v1, p3, 0x1

    shr-int/lit8 p3, p3, 0x1f

    xor-int/2addr p3, v1

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->B(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_5f

    :cond_7a
    return-void
.end method

.method public static x(ILjava/util/List;Lxs5;Z)V
    .registers 12

    if-eqz p1, :cond_7a

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7a

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lmxa;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/16 v0, 0x3f

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p3, :cond_60

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v3

    move p3, p0

    :goto_27
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_43

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    shl-long v6, v4, v2

    shr-long/2addr v4, v0

    xor-long/2addr v4, v6

    invoke-static {v4, v5}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_27

    :cond_43
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_46
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v3, p0, :cond_7a

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    shl-long v6, v4, v2

    shr-long/2addr v4, v0

    xor-long/2addr v4, v6

    invoke-virtual {p2, v4, v5}, Landroidx/datastore/preferences/protobuf/e;->E(J)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_46

    :cond_60
    :goto_60
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v3, p3, :cond_7a

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    shl-long v6, v4, v2

    shr-long/2addr v4, v0

    xor-long/2addr v4, v6

    invoke-virtual {p2, p0, v4, v5}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_60

    :cond_7a
    return-void
.end method

.method public static y(ILjava/util/List;Lxs5;Z)V
    .registers 6

    if-eqz p1, :cond_6b

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6b

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lhj9;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_55

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3c

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v1}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3c
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3f
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6b

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3f

    :cond_55
    :goto_55
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6b

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/datastore/preferences/protobuf/e;->B(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_55

    :cond_6b
    return-void
.end method

.method public static z(ILjava/util/List;Lxs5;Z)V
    .registers 7

    if-eqz p1, :cond_6b

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6b

    iget-object p2, p2, Lxs5;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/preferences/protobuf/e;

    instance-of v0, p1, Lmxa;

    const/4 v1, 0x2

    if-eqz v0, :cond_1c

    invoke-static {p1}, Ljg2;->t(Ljava/util/List;)V

    const/4 p1, 0x0

    if-eqz p3, :cond_1b

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    throw p1

    :cond_1b
    throw p1

    :cond_1c
    const/4 v0, 0x0

    if-eqz p3, :cond_55

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    move p0, v0

    move p3, p0

    :goto_24
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_3c

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_24

    :cond_3c
    invoke-virtual {p2, p3}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    :goto_3f
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6b

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->E(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3f

    :cond_55
    :goto_55
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6b

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_55

    :cond_6b
    return-void
.end method
