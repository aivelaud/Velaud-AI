.class public final Landroidx/datastore/preferences/protobuf/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldyf;


# static fields
.field public static final n:[I

.field public static final o:Lsun/misc/Unsafe;


# instance fields
.field public final a:[I

.field public final b:[Ljava/lang/Object;

.field public final c:I

.field public final d:I

.field public final e:Landroidx/datastore/preferences/protobuf/a;

.field public final f:Z

.field public final g:[I

.field public final h:I

.field public final i:I

.field public final j:Lakc;

.field public final k:Lfma;

.field public final l:Landroidx/datastore/preferences/protobuf/k;

.field public final m:Lz5b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    new-array v0, v0, [I

    sput-object v0, Landroidx/datastore/preferences/protobuf/h;->n:[I

    invoke-static {}, Lm5j;->i()Lsun/misc/Unsafe;

    move-result-object v0

    sput-object v0, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    return-void
.end method

.method public constructor <init>([I[Ljava/lang/Object;IILandroidx/datastore/preferences/protobuf/a;[IIILakc;Lfma;Landroidx/datastore/preferences/protobuf/k;Lpm7;Lz5b;)V
    .registers 14

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    iput-object p2, p0, Landroidx/datastore/preferences/protobuf/h;->b:[Ljava/lang/Object;

    iput p3, p0, Landroidx/datastore/preferences/protobuf/h;->c:I

    iput p4, p0, Landroidx/datastore/preferences/protobuf/h;->d:I

    instance-of p1, p5, Landroidx/datastore/preferences/protobuf/f;

    iput-boolean p1, p0, Landroidx/datastore/preferences/protobuf/h;->f:Z

    iput-object p6, p0, Landroidx/datastore/preferences/protobuf/h;->g:[I

    iput p7, p0, Landroidx/datastore/preferences/protobuf/h;->h:I

    iput p8, p0, Landroidx/datastore/preferences/protobuf/h;->i:I

    iput-object p9, p0, Landroidx/datastore/preferences/protobuf/h;->j:Lakc;

    iput-object p10, p0, Landroidx/datastore/preferences/protobuf/h;->k:Lfma;

    iput-object p11, p0, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    iput-object p5, p0, Landroidx/datastore/preferences/protobuf/h;->e:Landroidx/datastore/preferences/protobuf/a;

    iput-object p13, p0, Landroidx/datastore/preferences/protobuf/h;->m:Lz5b;

    return-void
.end method

.method public static F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    .registers 8

    :try_start_0
    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0
    :try_end_4
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_4} :catch_5

    return-object p0

    :catch_5
    move-exception v0

    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_c
    if-ge v3, v2, :cond_1e

    aget-object v4, v1, v3

    invoke-virtual {v4}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1b

    return-object v4

    :cond_1b
    add-int/lit8 v3, v3, 0x1

    goto :goto_c

    :cond_1e
    new-instance v2, Ljava/lang/RuntimeException;

    const-string v3, "Field "

    const-string v4, " for "

    invoke-static {v3, p1, v4}, Ld07;->x(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " not found. Known fields are "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v2, p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2
.end method

.method public static K(I)I
    .registers 2

    const/high16 v0, 0xff00000

    and-int/2addr p0, v0

    ushr-int/lit8 p0, p0, 0x14

    return p0
.end method

.method public static p(Ljava/lang/Object;)Z
    .registers 2

    if-nez p0, :cond_4

    const/4 p0, 0x0

    return p0

    :cond_4
    instance-of v0, p0, Landroidx/datastore/preferences/protobuf/f;

    if-eqz v0, :cond_f

    check-cast p0, Landroidx/datastore/preferences/protobuf/f;

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/f;->f()Z

    move-result p0

    return p0

    :cond_f
    const/4 p0, 0x1

    return p0
.end method

.method public static w(Lpne;Lakc;Lfma;Landroidx/datastore/preferences/protobuf/k;Lpm7;Lz5b;)Landroidx/datastore/preferences/protobuf/h;
    .registers 42

    move-object/from16 v0, p0

    iget-object v1, v0, Lpne;->b:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const v6, 0xd800

    if-lt v4, v6, :cond_1d

    const/4 v4, 0x1

    :goto_13
    add-int/lit8 v7, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_1e

    move v4, v7

    goto :goto_13

    :cond_1d
    const/4 v7, 0x1

    :cond_1e
    add-int/lit8 v4, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_3d

    and-int/lit16 v7, v7, 0x1fff

    const/16 v9, 0xd

    :goto_2a
    add-int/lit8 v10, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_3a

    and-int/lit16 v4, v4, 0x1fff

    shl-int/2addr v4, v9

    or-int/2addr v7, v4

    add-int/lit8 v9, v9, 0xd

    move v4, v10

    goto :goto_2a

    :cond_3a
    shl-int/2addr v4, v9

    or-int/2addr v7, v4

    move v4, v10

    :cond_3d
    if-nez v7, :cond_4d

    sget-object v7, Landroidx/datastore/preferences/protobuf/h;->n:[I

    move v9, v3

    move v10, v9

    move v11, v10

    move v12, v11

    move v13, v12

    move/from16 v16, v13

    move-object v15, v7

    move/from16 v7, v16

    goto/16 :goto_160

    :cond_4d
    add-int/lit8 v7, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_6c

    and-int/lit16 v4, v4, 0x1fff

    const/16 v9, 0xd

    :goto_59
    add-int/lit8 v10, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_69

    and-int/lit16 v7, v7, 0x1fff

    shl-int/2addr v7, v9

    or-int/2addr v4, v7

    add-int/lit8 v9, v9, 0xd

    move v7, v10

    goto :goto_59

    :cond_69
    shl-int/2addr v7, v9

    or-int/2addr v4, v7

    move v7, v10

    :cond_6c
    add-int/lit8 v9, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_8b

    and-int/lit16 v7, v7, 0x1fff

    const/16 v10, 0xd

    :goto_78
    add-int/lit8 v11, v9, 0x1

    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-lt v9, v6, :cond_88

    and-int/lit16 v9, v9, 0x1fff

    shl-int/2addr v9, v10

    or-int/2addr v7, v9

    add-int/lit8 v10, v10, 0xd

    move v9, v11

    goto :goto_78

    :cond_88
    shl-int/2addr v9, v10

    or-int/2addr v7, v9

    move v9, v11

    :cond_8b
    add-int/lit8 v10, v9, 0x1

    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-lt v9, v6, :cond_aa

    and-int/lit16 v9, v9, 0x1fff

    const/16 v11, 0xd

    :goto_97
    add-int/lit8 v12, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v6, :cond_a7

    and-int/lit16 v10, v10, 0x1fff

    shl-int/2addr v10, v11

    or-int/2addr v9, v10

    add-int/lit8 v11, v11, 0xd

    move v10, v12

    goto :goto_97

    :cond_a7
    shl-int/2addr v10, v11

    or-int/2addr v9, v10

    move v10, v12

    :cond_aa
    add-int/lit8 v11, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v6, :cond_c9

    and-int/lit16 v10, v10, 0x1fff

    const/16 v12, 0xd

    :goto_b6
    add-int/lit8 v13, v11, 0x1

    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v11

    if-lt v11, v6, :cond_c6

    and-int/lit16 v11, v11, 0x1fff

    shl-int/2addr v11, v12

    or-int/2addr v10, v11

    add-int/lit8 v12, v12, 0xd

    move v11, v13

    goto :goto_b6

    :cond_c6
    shl-int/2addr v11, v12

    or-int/2addr v10, v11

    move v11, v13

    :cond_c9
    add-int/lit8 v12, v11, 0x1

    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v11

    if-lt v11, v6, :cond_e8

    and-int/lit16 v11, v11, 0x1fff

    const/16 v13, 0xd

    :goto_d5
    add-int/lit8 v14, v12, 0x1

    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    if-lt v12, v6, :cond_e5

    and-int/lit16 v12, v12, 0x1fff

    shl-int/2addr v12, v13

    or-int/2addr v11, v12

    add-int/lit8 v13, v13, 0xd

    move v12, v14

    goto :goto_d5

    :cond_e5
    shl-int/2addr v12, v13

    or-int/2addr v11, v12

    move v12, v14

    :cond_e8
    add-int/lit8 v13, v12, 0x1

    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    if-lt v12, v6, :cond_107

    and-int/lit16 v12, v12, 0x1fff

    const/16 v14, 0xd

    :goto_f4
    add-int/lit8 v15, v13, 0x1

    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-lt v13, v6, :cond_104

    and-int/lit16 v13, v13, 0x1fff

    shl-int/2addr v13, v14

    or-int/2addr v12, v13

    add-int/lit8 v14, v14, 0xd

    move v13, v15

    goto :goto_f4

    :cond_104
    shl-int/2addr v13, v14

    or-int/2addr v12, v13

    move v13, v15

    :cond_107
    add-int/lit8 v14, v13, 0x1

    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-lt v13, v6, :cond_128

    and-int/lit16 v13, v13, 0x1fff

    const/16 v15, 0xd

    :goto_113
    add-int/lit8 v16, v14, 0x1

    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-lt v14, v6, :cond_124

    and-int/lit16 v14, v14, 0x1fff

    shl-int/2addr v14, v15

    or-int/2addr v13, v14

    add-int/lit8 v15, v15, 0xd

    move/from16 v14, v16

    goto :goto_113

    :cond_124
    shl-int/2addr v14, v15

    or-int/2addr v13, v14

    move/from16 v14, v16

    :cond_128
    add-int/lit8 v15, v14, 0x1

    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-lt v14, v6, :cond_14b

    and-int/lit16 v14, v14, 0x1fff

    const/16 v16, 0xd

    :goto_134
    add-int/lit8 v17, v15, 0x1

    invoke-virtual {v1, v15}, Ljava/lang/String;->charAt(I)C

    move-result v15

    if-lt v15, v6, :cond_146

    and-int/lit16 v15, v15, 0x1fff

    shl-int v15, v15, v16

    or-int/2addr v14, v15

    add-int/lit8 v16, v16, 0xd

    move/from16 v15, v17

    goto :goto_134

    :cond_146
    shl-int v15, v15, v16

    or-int/2addr v14, v15

    move/from16 v15, v17

    :cond_14b
    add-int v16, v14, v12

    add-int v13, v16, v13

    new-array v13, v13, [I

    mul-int/lit8 v16, v4, 0x2

    add-int v16, v16, v7

    move v7, v12

    move v12, v9

    move v9, v7

    move v7, v4

    move v4, v15

    move-object v15, v13

    move v13, v10

    move/from16 v10, v16

    move/from16 v16, v14

    :goto_160
    sget-object v14, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    iget-object v3, v0, Lpne;->c:[Ljava/lang/Object;

    iget-object v8, v0, Lpne;->a:Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    mul-int/lit8 v5, v11, 0x3

    new-array v5, v5, [I

    const/4 v6, 0x2

    mul-int/2addr v11, v6

    new-array v11, v11, [Ljava/lang/Object;

    add-int v9, v16, v9

    move/from16 v24, v9

    move/from16 v23, v16

    const/4 v6, 0x0

    const/16 v21, 0x0

    :goto_17b
    if-ge v4, v2, :cond_408

    add-int/lit8 v25, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    move/from16 v26, v2

    const v2, 0xd800

    if-lt v4, v2, :cond_1af

    and-int/lit16 v4, v4, 0x1fff

    move/from16 v2, v25

    const/16 v25, 0xd

    :goto_190
    add-int/lit8 v27, v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    move-object/from16 v28, v3

    const v3, 0xd800

    if-lt v2, v3, :cond_1a9

    and-int/lit16 v2, v2, 0x1fff

    shl-int v2, v2, v25

    or-int/2addr v4, v2

    add-int/lit8 v25, v25, 0xd

    move/from16 v2, v27

    move-object/from16 v3, v28

    goto :goto_190

    :cond_1a9
    shl-int v2, v2, v25

    or-int/2addr v4, v2

    move/from16 v2, v27

    goto :goto_1b3

    :cond_1af
    move-object/from16 v28, v3

    move/from16 v2, v25

    :goto_1b3
    add-int/lit8 v3, v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    move/from16 v25, v3

    const v3, 0xd800

    if-lt v2, v3, :cond_1e5

    and-int/lit16 v2, v2, 0x1fff

    move/from16 v3, v25

    const/16 v25, 0xd

    :goto_1c6
    add-int/lit8 v27, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    move/from16 v29, v2

    const v2, 0xd800

    if-lt v3, v2, :cond_1de

    and-int/lit16 v2, v3, 0x1fff

    shl-int v2, v2, v25

    or-int v2, v29, v2

    add-int/lit8 v25, v25, 0xd

    move/from16 v3, v27

    goto :goto_1c6

    :cond_1de
    shl-int v2, v3, v25

    or-int v2, v29, v2

    move/from16 v3, v27

    goto :goto_1e7

    :cond_1e5
    move/from16 v3, v25

    :goto_1e7
    move/from16 v25, v4

    and-int/lit16 v4, v2, 0xff

    move-object/from16 v27, v5

    and-int/lit16 v5, v2, 0x400

    if-eqz v5, :cond_1f7

    add-int/lit8 v5, v21, 0x1

    aput v6, v15, v21

    move/from16 v21, v5

    :cond_1f7
    const/16 v5, 0x33

    move/from16 v31, v7

    if-lt v4, v5, :cond_2b0

    add-int/lit8 v5, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const v7, 0xd800

    if-lt v3, v7, :cond_226

    and-int/lit16 v3, v3, 0x1fff

    const/16 v34, 0xd

    :goto_20c
    add-int/lit8 v35, v5, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-lt v5, v7, :cond_221

    and-int/lit16 v5, v5, 0x1fff

    shl-int v5, v5, v34

    or-int/2addr v3, v5

    add-int/lit8 v34, v34, 0xd

    move/from16 v5, v35

    const v7, 0xd800

    goto :goto_20c

    :cond_221
    shl-int v5, v5, v34

    or-int/2addr v3, v5

    move/from16 v5, v35

    :cond_226
    add-int/lit8 v7, v4, -0x33

    move/from16 v34, v3

    const/16 v3, 0x9

    if-eq v7, v3, :cond_232

    const/16 v3, 0x11

    if-ne v7, v3, :cond_238

    :cond_232
    move/from16 v29, v5

    const/4 v3, 0x3

    const/4 v5, 0x2

    const/4 v7, 0x1

    goto :goto_263

    :cond_238
    const/16 v3, 0xc

    if-ne v7, v3, :cond_261

    invoke-virtual {v0}, Lpne;->a()I

    move-result v3

    const/4 v7, 0x1

    invoke-static {v3, v7}, Ld07;->c(II)Z

    move-result v3

    if-nez v3, :cond_24b

    and-int/lit16 v3, v2, 0x800

    if-eqz v3, :cond_250

    :cond_24b
    move/from16 v29, v5

    const/4 v3, 0x3

    const/4 v5, 0x2

    goto :goto_254

    :cond_250
    :goto_250
    move/from16 v29, v5

    const/4 v5, 0x2

    goto :goto_26e

    :goto_254
    invoke-static {v6, v3, v5, v7}, Lti6;->e(IIII)I

    move-result v3

    add-int/lit8 v19, v10, 0x1

    aget-object v10, v28, v10

    aput-object v10, v11, v3

    move/from16 v10, v19

    goto :goto_26e

    :cond_261
    const/4 v7, 0x1

    goto :goto_250

    :goto_263
    invoke-static {v6, v3, v5, v7}, Lti6;->e(IIII)I

    move-result v3

    add-int/lit8 v7, v10, 0x1

    aget-object v10, v28, v10

    aput-object v10, v11, v3

    move v10, v7

    :goto_26e
    mul-int/lit8 v3, v34, 0x2

    aget-object v5, v28, v3

    instance-of v7, v5, Ljava/lang/reflect/Field;

    if-eqz v7, :cond_27c

    check-cast v5, Ljava/lang/reflect/Field;

    :goto_278
    move v7, v9

    move/from16 v30, v10

    goto :goto_285

    :cond_27c
    check-cast v5, Ljava/lang/String;

    invoke-static {v8, v5}, Landroidx/datastore/preferences/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    aput-object v5, v28, v3

    goto :goto_278

    :goto_285
    invoke-virtual {v14, v5}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v5, v9

    add-int/lit8 v3, v3, 0x1

    aget-object v9, v28, v3

    instance-of v10, v9, Ljava/lang/reflect/Field;

    if-eqz v10, :cond_295

    check-cast v9, Ljava/lang/reflect/Field;

    goto :goto_29d

    :cond_295
    check-cast v9, Ljava/lang/String;

    invoke-static {v8, v9}, Landroidx/datastore/preferences/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v9

    aput-object v9, v28, v3

    :goto_29d
    invoke-virtual {v14, v9}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v3, v9

    move-object/from16 v32, v1

    move v9, v5

    move v1, v6

    move/from16 v10, v29

    const/16 v22, 0x2

    move v5, v3

    move/from16 v29, v7

    const/4 v3, 0x0

    goto/16 :goto_3c5

    :cond_2b0
    move v7, v9

    add-int/lit8 v5, v10, 0x1

    aget-object v9, v28, v10

    check-cast v9, Ljava/lang/String;

    invoke-static {v8, v9}, Landroidx/datastore/preferences/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v9

    move/from16 v34, v5

    const/16 v5, 0x9

    if-eq v4, v5, :cond_2c5

    const/16 v5, 0x11

    if-ne v4, v5, :cond_2cc

    :cond_2c5
    move/from16 v29, v7

    const/4 v5, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x2

    goto/16 :goto_345

    :cond_2cc
    const/16 v5, 0x1b

    if-eq v4, v5, :cond_2d4

    const/16 v5, 0x31

    if-ne v4, v5, :cond_2dc

    :cond_2d4
    move/from16 v29, v7

    move/from16 v19, v10

    const/4 v5, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x2

    goto :goto_33a

    :cond_2dc
    const/16 v5, 0xc

    if-eq v4, v5, :cond_31c

    const/16 v5, 0x1e

    if-eq v4, v5, :cond_31c

    const/16 v5, 0x2c

    if-ne v4, v5, :cond_2e9

    goto :goto_31c

    :cond_2e9
    const/16 v5, 0x32

    if-ne v4, v5, :cond_318

    add-int/lit8 v5, v23, 0x1

    aput v6, v15, v23

    div-int/lit8 v23, v6, 0x3

    const/16 v22, 0x2

    mul-int/lit8 v23, v23, 0x2

    add-int/lit8 v29, v10, 0x2

    aget-object v30, v28, v34

    aput-object v30, v11, v23

    move/from16 v30, v5

    and-int/lit16 v5, v2, 0x800

    if-eqz v5, :cond_311

    add-int/lit8 v23, v23, 0x1

    add-int/lit8 v5, v10, 0x3

    aget-object v10, v28, v29

    aput-object v10, v11, v23

    move/from16 v29, v7

    move/from16 v23, v30

    :goto_30f
    const/4 v7, 0x1

    goto :goto_351

    :cond_311
    move/from16 v5, v29

    move/from16 v23, v30

    move/from16 v29, v7

    goto :goto_30f

    :cond_318
    move/from16 v29, v7

    const/4 v7, 0x1

    goto :goto_34f

    :cond_31c
    :goto_31c
    invoke-virtual {v0}, Lpne;->a()I

    move-result v5

    move/from16 v29, v7

    const/4 v7, 0x1

    if-eq v5, v7, :cond_329

    and-int/lit16 v5, v2, 0x800

    if-eqz v5, :cond_34f

    :cond_329
    move/from16 v19, v10

    const/4 v5, 0x3

    const/4 v10, 0x2

    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    add-int/lit8 v19, v19, 0x2

    aget-object v22, v28, v34

    aput-object v22, v11, v5

    :goto_337
    move/from16 v5, v19

    goto :goto_351

    :goto_33a
    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    add-int/lit8 v19, v19, 0x2

    aget-object v22, v28, v34

    aput-object v22, v11, v5

    goto :goto_337

    :goto_345
    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    invoke-virtual {v9}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v10

    aput-object v10, v11, v5

    :cond_34f
    :goto_34f
    move/from16 v5, v34

    :goto_351
    invoke-virtual {v14, v9}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v9, v9

    and-int/lit16 v10, v2, 0x1000

    if-eqz v10, :cond_3ab

    const/16 v10, 0x11

    if-gt v4, v10, :cond_3ab

    add-int/lit8 v10, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const v7, 0xd800

    if-lt v3, v7, :cond_384

    and-int/lit16 v3, v3, 0x1fff

    const/16 v20, 0xd

    :goto_36d
    add-int/lit8 v30, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v7, :cond_37f

    and-int/lit16 v10, v10, 0x1fff

    shl-int v10, v10, v20

    or-int/2addr v3, v10

    add-int/lit8 v20, v20, 0xd

    move/from16 v10, v30

    goto :goto_36d

    :cond_37f
    shl-int v10, v10, v20

    or-int/2addr v3, v10

    move/from16 v10, v30

    :cond_384
    const/16 v22, 0x2

    mul-int/lit8 v20, v31, 0x2

    div-int/lit8 v30, v3, 0x20

    add-int v30, v30, v20

    aget-object v7, v28, v30

    move-object/from16 v32, v1

    instance-of v1, v7, Ljava/lang/reflect/Field;

    if-eqz v1, :cond_39a

    check-cast v7, Ljava/lang/reflect/Field;

    :goto_396
    move/from16 v30, v5

    move v1, v6

    goto :goto_3a3

    :cond_39a
    check-cast v7, Ljava/lang/String;

    invoke-static {v8, v7}, Landroidx/datastore/preferences/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v7

    aput-object v7, v28, v30

    goto :goto_396

    :goto_3a3
    invoke-virtual {v14, v7}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v5

    long-to-int v5, v5

    rem-int/lit8 v3, v3, 0x20

    goto :goto_3b7

    :cond_3ab
    move-object/from16 v32, v1

    move/from16 v30, v5

    move v1, v6

    const/16 v22, 0x2

    const v5, 0xfffff

    move v10, v3

    const/4 v3, 0x0

    :goto_3b7
    const/16 v6, 0x12

    if-lt v4, v6, :cond_3c5

    const/16 v6, 0x31

    if-gt v4, v6, :cond_3c5

    add-int/lit8 v6, v24, 0x1

    aput v9, v15, v24

    move/from16 v24, v6

    :cond_3c5
    :goto_3c5
    add-int/lit8 v6, v1, 0x1

    aput v25, v27, v1

    add-int/lit8 v7, v1, 0x2

    move/from16 v25, v1

    and-int/lit16 v1, v2, 0x200

    if-eqz v1, :cond_3d4

    const/high16 v1, 0x20000000

    goto :goto_3d5

    :cond_3d4
    const/4 v1, 0x0

    :goto_3d5
    move/from16 v33, v1

    and-int/lit16 v1, v2, 0x100

    if-eqz v1, :cond_3de

    const/high16 v1, 0x10000000

    goto :goto_3df

    :cond_3de
    const/4 v1, 0x0

    :goto_3df
    or-int v1, v33, v1

    and-int/lit16 v2, v2, 0x800

    if-eqz v2, :cond_3e8

    const/high16 v2, -0x80000000

    goto :goto_3e9

    :cond_3e8
    const/4 v2, 0x0

    :goto_3e9
    or-int/2addr v1, v2

    shl-int/lit8 v2, v4, 0x14

    or-int/2addr v1, v2

    or-int/2addr v1, v9

    aput v1, v27, v6

    add-int/lit8 v6, v25, 0x3

    shl-int/lit8 v1, v3, 0x14

    or-int/2addr v1, v5

    aput v1, v27, v7

    move v4, v10

    move/from16 v2, v26

    move-object/from16 v5, v27

    move-object/from16 v3, v28

    move/from16 v9, v29

    move/from16 v10, v30

    move/from16 v7, v31

    move-object/from16 v1, v32

    goto/16 :goto_17b

    :cond_408
    move-object/from16 v27, v5

    move/from16 v29, v9

    new-instance v9, Landroidx/datastore/preferences/protobuf/h;

    iget-object v14, v0, Lpne;->a:Landroidx/datastore/preferences/protobuf/a;

    move-object/from16 v18, p1

    move-object/from16 v19, p2

    move-object/from16 v20, p3

    move-object/from16 v21, p4

    move-object/from16 v22, p5

    move-object/from16 v10, v27

    move/from16 v17, v29

    invoke-direct/range {v9 .. v22}, Landroidx/datastore/preferences/protobuf/h;-><init>([I[Ljava/lang/Object;IILandroidx/datastore/preferences/protobuf/a;[IIILakc;Lfma;Landroidx/datastore/preferences/protobuf/k;Lpm7;Lz5b;)V

    return-object v9
.end method

.method public static x(I)J
    .registers 3

    const v0, 0xfffff

    and-int/2addr p0, v0

    int-to-long v0, p0

    return-wide v0
.end method

.method public static y(JLjava/lang/Object;)I
    .registers 4

    sget-object v0, Lm5j;->c:Lh5j;

    invoke-virtual {v0, p0, p1, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public static z(JLjava/lang/Object;)J
    .registers 4

    sget-object v0, Lm5j;->c:Lh5j;

    invoke-virtual {v0, p0, p1, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    return-wide p0
.end method


# virtual methods
.method public final A(I)I
    .registers 7

    iget v0, p0, Landroidx/datastore/preferences/protobuf/h;->c:I

    if-lt p1, v0, :cond_27

    iget v0, p0, Landroidx/datastore/preferences/protobuf/h;->d:I

    if-gt p1, v0, :cond_27

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    array-length v0, p0

    div-int/lit8 v0, v0, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    :goto_10
    if-gt v1, v0, :cond_27

    add-int v2, v0, v1

    ushr-int/lit8 v2, v2, 0x1

    mul-int/lit8 v3, v2, 0x3

    aget v4, p0, v3

    if-ne p1, v4, :cond_1d

    return v3

    :cond_1d
    if-ge p1, v4, :cond_23

    add-int/lit8 v2, v2, -0x1

    move v0, v2

    goto :goto_10

    :cond_23
    add-int/lit8 v2, v2, 0x1

    move v1, v2

    goto :goto_10

    :cond_27
    const/4 p0, -0x1

    return p0
.end method

.method public final B(Ljava/lang/Object;JLandroidx/datastore/preferences/protobuf/d;Ldyf;Lkm7;)V
    .registers 8

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->k:Lfma;

    invoke-virtual {p0, p2, p3, p1}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object p0

    iget-object p1, p4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    iget p2, p4, Landroidx/datastore/preferences/protobuf/d;->b:I

    and-int/lit8 p3, p2, 0x7

    const/4 v0, 0x3

    if-ne p3, v0, :cond_33

    :cond_f
    invoke-interface {p5}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p3

    invoke-virtual {p4, p3, p5, p6}, Landroidx/datastore/preferences/protobuf/d;->b(Ljava/lang/Object;Ldyf;Lkm7;)V

    invoke-interface {p5, p3}, Ldyf;->b(Ljava/lang/Object;)V

    move-object v0, p0

    check-cast v0, Lvfe;

    invoke-virtual {v0, p3}, Lvfe;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Lnl4;->c()Z

    move-result p3

    if-nez p3, :cond_32

    iget p3, p4, Landroidx/datastore/preferences/protobuf/d;->d:I

    if-eqz p3, :cond_2a

    goto :goto_32

    :cond_2a
    invoke-virtual {p1}, Lnl4;->u()I

    move-result p3

    if-eq p3, p2, :cond_f

    iput p3, p4, Landroidx/datastore/preferences/protobuf/d;->d:I

    :cond_32
    :goto_32
    return-void

    :cond_33
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->b()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p0

    throw p0
.end method

.method public final C(Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/d;Ldyf;Lkm7;)V
    .registers 8

    const v0, 0xfffff

    and-int/2addr p2, v0

    int-to-long v0, p2

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->k:Lfma;

    invoke-virtual {p0, v0, v1, p1}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object p0

    iget-object p1, p3, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    iget p2, p3, Landroidx/datastore/preferences/protobuf/d;->b:I

    and-int/lit8 v0, p2, 0x7

    const/4 v1, 0x2

    if-ne v0, v1, :cond_38

    :cond_14
    invoke-interface {p4}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object v0

    invoke-virtual {p3, v0, p4, p5}, Landroidx/datastore/preferences/protobuf/d;->c(Ljava/lang/Object;Ldyf;Lkm7;)V

    invoke-interface {p4, v0}, Ldyf;->b(Ljava/lang/Object;)V

    move-object v1, p0

    check-cast v1, Lvfe;

    invoke-virtual {v1, v0}, Lvfe;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Lnl4;->c()Z

    move-result v0

    if-nez v0, :cond_37

    iget v0, p3, Landroidx/datastore/preferences/protobuf/d;->d:I

    if-eqz v0, :cond_2f

    goto :goto_37

    :cond_2f
    invoke-virtual {p1}, Lnl4;->u()I

    move-result v0

    if-eq v0, p2, :cond_14

    iput v0, p3, Landroidx/datastore/preferences/protobuf/d;->d:I

    :cond_37
    :goto_37
    return-void

    :cond_38
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->b()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p0

    throw p0
.end method

.method public final D(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)V
    .registers 7

    const/high16 v0, 0x20000000

    and-int/2addr v0, p1

    const/4 v1, 0x2

    const v2, 0xfffff

    if-eqz v0, :cond_19

    and-int p0, p1, v2

    int-to-long p0, p0

    invoke-virtual {p2, v1}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object p2, p2, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {p2}, Lnl4;->t()Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1, p3, p2}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_19
    iget-boolean p0, p0, Landroidx/datastore/preferences/protobuf/h;->f:Z

    if-eqz p0, :cond_2d

    and-int p0, p1, v2

    int-to-long p0, p0

    invoke-virtual {p2, v1}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object p2, p2, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {p2}, Lnl4;->s()Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1, p3, p2}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_2d
    and-int p0, p1, v2

    int-to-long p0, p0

    invoke-virtual {p2}, Landroidx/datastore/preferences/protobuf/d;->e()Lk92;

    move-result-object p2

    invoke-static {p0, p1, p3, p2}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final E(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)V
    .registers 8

    const/high16 v0, 0x20000000

    and-int/2addr v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_9

    move v0, v2

    goto :goto_a

    :cond_9
    move v0, v1

    :goto_a
    const v3, 0xfffff

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->k:Lfma;

    if-eqz v0, :cond_1b

    and-int/2addr p1, v3

    int-to-long v0, p1

    invoke-virtual {p0, v0, v1, p3}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object p0

    invoke-virtual {p2, p0, v2}, Landroidx/datastore/preferences/protobuf/d;->s(Ls3;Z)V

    return-void

    :cond_1b
    and-int/2addr p1, v3

    int-to-long v2, p1

    invoke-virtual {p0, v2, v3, p3}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object p0

    invoke-virtual {p2, p0, v1}, Landroidx/datastore/preferences/protobuf/d;->s(Ls3;Z)V

    return-void
.end method

.method public final G(ILjava/lang/Object;)V
    .registers 7

    add-int/lit8 p1, p1, 0x2

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget p0, p0, p1

    const p1, 0xfffff

    and-int/2addr p1, p0

    int-to-long v0, p1

    const-wide/32 v2, 0xfffff

    cmp-long p1, v0, v2

    if-nez p1, :cond_13

    return-void

    :cond_13
    ushr-int/lit8 p0, p0, 0x14

    const/4 p1, 0x1

    shl-int p0, p1, p0

    sget-object p1, Lm5j;->c:Lh5j;

    invoke-virtual {p1, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p1

    or-int/2addr p0, p1

    invoke-static {p0, v0, v1, p2}, Lm5j;->m(IJLjava/lang/Object;)V

    return-void
.end method

.method public final H(ILjava/lang/Object;I)V
    .registers 6

    add-int/lit8 p3, p3, 0x2

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget p0, p0, p3

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v0, p0

    invoke-static {p1, v0, v1, p2}, Lm5j;->m(IJLjava/lang/Object;)V

    return-void
.end method

.method public final I(Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/a;)V
    .registers 7

    sget-object v0, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {v0, p1, v1, v2, p3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {p0, p2, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    return-void
.end method

.method public final J(Ljava/lang/Object;IILandroidx/datastore/preferences/protobuf/a;)V
    .registers 8

    sget-object v0, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p3}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {v0, p1, v1, v2, p4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {p0, p2, p1, p3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    return-void
.end method

.method public final L(I)I
    .registers 2

    add-int/lit8 p1, p1, 0x1

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget p0, p0, p1

    return p0
.end method

.method public final M(Ljava/lang/Object;Lxs5;)V
    .registers 24

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v6, p2

    iget-object v2, v6, Lxs5;->F:Ljava/lang/Object;

    move-object v7, v2

    check-cast v7, Landroidx/datastore/preferences/protobuf/e;

    iget-object v8, v0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    array-length v9, v8

    sget-object v10, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    const v11, 0xfffff

    move v3, v11

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_16
    if-ge v2, v9, :cond_608

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v5

    aget v13, v8, v2

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v14

    const/16 v15, 0x11

    if-gt v14, v15, :cond_45

    add-int/lit8 v15, v2, 0x2

    aget v15, v8, v15

    const/16 v17, 0x1

    and-int v12, v15, v11

    if-eq v12, v3, :cond_3b

    if-ne v12, v11, :cond_34

    const/4 v4, 0x0

    goto :goto_3a

    :cond_34
    int-to-long v3, v12

    invoke-virtual {v10, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    move v4, v3

    :goto_3a
    move v3, v12

    :cond_3b
    ushr-int/lit8 v12, v15, 0x14

    shl-int v12, v17, v12

    move/from16 v20, v12

    move v12, v5

    move/from16 v5, v20

    goto :goto_49

    :cond_45
    const/16 v17, 0x1

    move v12, v5

    const/4 v5, 0x0

    :goto_49
    and-int/2addr v12, v11

    int-to-long v11, v12

    const/16 v18, 0x3f

    const/4 v15, 0x3

    packed-switch v14, :pswitch_data_618

    :cond_51
    :goto_51
    const/4 v14, 0x0

    goto/16 :goto_601

    :pswitch_54  #0x44
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v11

    check-cast v5, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v7, v13, v15}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    invoke-interface {v11, v5, v6}, Ldyf;->h(Ljava/lang/Object;Lxs5;)V

    const/4 v5, 0x4

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    goto :goto_51

    :pswitch_6f  #0x43
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v11

    shl-long v14, v11, v17

    shr-long v11, v11, v18

    xor-long/2addr v11, v14

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    goto :goto_51

    :pswitch_82  #0x42
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    shl-int/lit8 v11, v5, 0x1

    shr-int/lit8 v5, v5, 0x1f

    xor-int/2addr v5, v11

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->B(II)V

    goto :goto_51

    :pswitch_95  #0x41
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    goto :goto_51

    :pswitch_a3  #0x40
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    goto :goto_51

    :pswitch_b1  #0x3f
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->v(II)V

    goto :goto_51

    :pswitch_bf  #0x3e
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->B(II)V

    goto :goto_51

    :pswitch_cd  #0x3d
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lk92;

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->p(ILk92;)V

    goto/16 :goto_51

    :pswitch_de  #0x3c
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v11

    invoke-virtual {v6, v13, v5, v11}, Lxs5;->Q(ILjava/lang/Object;Ldyf;)V

    goto/16 :goto_51

    :pswitch_f1  #0x3b
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    instance-of v11, v5, Ljava/lang/String;

    if-eqz v11, :cond_106

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->y(ILjava/lang/String;)V

    goto/16 :goto_51

    :cond_106
    check-cast v5, Lk92;

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->p(ILk92;)V

    goto/16 :goto_51

    :pswitch_10d  #0x3a
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v11, v12, v1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->o(IZ)V

    goto/16 :goto_51

    :pswitch_124  #0x39
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    goto/16 :goto_51

    :pswitch_133  #0x38
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    goto/16 :goto_51

    :pswitch_142  #0x37
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->v(II)V

    goto/16 :goto_51

    :pswitch_151  #0x36
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    goto/16 :goto_51

    :pswitch_160  #0x35
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    invoke-static {v11, v12, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    goto/16 :goto_51

    :pswitch_16f  #0x34
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v11, v12, v1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Float;

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v5

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    goto/16 :goto_51

    :pswitch_18d  #0x33
    invoke-virtual {v0, v13, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_51

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v11, v12, v1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Double;

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v11

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v11, v12}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    goto/16 :goto_51

    :pswitch_1ab  #0x32
    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    if-eqz v5, :cond_20d

    div-int/lit8 v11, v2, 0x3

    const/4 v12, 0x2

    mul-int/2addr v11, v12

    iget-object v14, v0, Landroidx/datastore/preferences/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v11, v14, v11

    iget-object v14, v0, Landroidx/datastore/preferences/protobuf/h;->m:Lz5b;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Lm5b;

    iget-object v11, v11, Lm5b;->a:Lhk0;

    check-cast v5, Lu5b;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v5}, Lu5b;->entrySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1cf
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_20d

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/util/Map$Entry;

    invoke-virtual {v7, v13, v12}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v15

    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v12

    invoke-static {v11, v15, v12}, Lm5b;->a(Lhk0;Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v12

    invoke-virtual {v7, v12}, Landroidx/datastore/preferences/protobuf/e;->C(I)V

    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v12

    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v14

    iget-object v15, v11, Lhk0;->E:Ljava/lang/Object;

    check-cast v15, Lx5k;

    move/from16 v19, v3

    move/from16 v3, v17

    invoke-static {v7, v15, v3, v12}, Llr7;->b(Landroidx/datastore/preferences/protobuf/e;Lx5k;ILjava/lang/Object;)V

    iget-object v3, v11, Lhk0;->F:Ljava/lang/Object;

    check-cast v3, Lx5k;

    const/4 v12, 0x2

    invoke-static {v7, v3, v12, v14}, Llr7;->b(Landroidx/datastore/preferences/protobuf/e;Lx5k;ILjava/lang/Object;)V

    move/from16 v3, v19

    const/16 v17, 0x1

    goto :goto_1cf

    :cond_20d
    move/from16 v19, v3

    :cond_20f
    :goto_20f
    move/from16 v3, v19

    goto/16 :goto_51

    :pswitch_213  #0x31
    move/from16 v19, v3

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v11

    sget-object v12, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v5, :cond_20f

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_20f

    const/4 v12, 0x0

    :goto_22c
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v13

    if-ge v12, v13, :cond_20f

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v7, v3, v15}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    invoke-interface {v11, v13, v6}, Ldyf;->h(Ljava/lang/Object;Lxs5;)V

    const/4 v13, 0x4

    invoke-virtual {v7, v3, v13}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_22c

    :pswitch_245  #0x30
    move/from16 v19, v3

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    const/4 v13, 0x1

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->x(ILjava/util/List;Lxs5;Z)V

    goto :goto_20f

    :pswitch_254  #0x2f
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->w(ILjava/util/List;Lxs5;Z)V

    goto :goto_20f

    :pswitch_264  #0x2e
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->v(ILjava/util/List;Lxs5;Z)V

    goto :goto_20f

    :pswitch_274  #0x2d
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->u(ILjava/util/List;Lxs5;Z)V

    goto :goto_20f

    :pswitch_284  #0x2c
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->o(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_295  #0x2b
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->y(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_2a6  #0x2a
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->m(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_2b7  #0x29
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->p(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_2c8  #0x28
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->q(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_2d9  #0x27
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->s(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_2ea  #0x26
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->z(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_2fb  #0x25
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->t(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_30c  #0x24
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->r(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_31d  #0x23
    move/from16 v19, v3

    move/from16 v13, v17

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->n(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_20f

    :pswitch_32e  #0x22
    move/from16 v19, v3

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    const/4 v13, 0x0

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->x(ILjava/util/List;Lxs5;Z)V

    :goto_33c
    move v14, v13

    :goto_33d
    move/from16 v3, v19

    goto/16 :goto_601

    :pswitch_341  #0x21
    move/from16 v19, v3

    const/4 v13, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->w(ILjava/util/List;Lxs5;Z)V

    goto :goto_33c

    :pswitch_350  #0x20
    move/from16 v19, v3

    const/4 v13, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->v(ILjava/util/List;Lxs5;Z)V

    goto :goto_33c

    :pswitch_35f  #0x1f
    move/from16 v19, v3

    const/4 v13, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->u(ILjava/util/List;Lxs5;Z)V

    goto :goto_33c

    :pswitch_36e  #0x1e
    move/from16 v19, v3

    const/4 v13, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->o(ILjava/util/List;Lxs5;Z)V

    goto :goto_33c

    :pswitch_37d  #0x1d
    move/from16 v19, v3

    const/4 v13, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v13}, Landroidx/datastore/preferences/protobuf/j;->y(ILjava/util/List;Lxs5;Z)V

    goto :goto_33c

    :pswitch_38c  #0x1c
    move/from16 v19, v3

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v11, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v5, :cond_20f

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_20f

    const/4 v13, 0x0

    :goto_3a1
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    if-ge v13, v11, :cond_20f

    invoke-interface {v5, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lk92;

    invoke-virtual {v7, v3, v11}, Landroidx/datastore/preferences/protobuf/e;->p(ILk92;)V

    add-int/lit8 v13, v13, 0x1

    goto :goto_3a1

    :pswitch_3b3  #0x1b
    move/from16 v19, v3

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v11

    sget-object v12, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v5, :cond_20f

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_20f

    const/4 v13, 0x0

    :goto_3cc
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v12

    if-ge v13, v12, :cond_20f

    invoke-interface {v5, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    invoke-virtual {v6, v3, v12, v11}, Lxs5;->Q(ILjava/lang/Object;Ldyf;)V

    add-int/lit8 v13, v13, 0x1

    goto :goto_3cc

    :pswitch_3dc  #0x1a
    move/from16 v19, v3

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v11, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v5, :cond_20f

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_20f

    instance-of v11, v5, Lpea;

    if-eqz v11, :cond_414

    move-object v11, v5

    check-cast v11, Lpea;

    const/4 v13, 0x0

    :goto_3f8
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v12

    if-ge v13, v12, :cond_20f

    invoke-interface {v11}, Lpea;->f()Ljava/lang/Object;

    move-result-object v12

    instance-of v14, v12, Ljava/lang/String;

    if-eqz v14, :cond_40c

    check-cast v12, Ljava/lang/String;

    invoke-virtual {v7, v3, v12}, Landroidx/datastore/preferences/protobuf/e;->y(ILjava/lang/String;)V

    goto :goto_411

    :cond_40c
    check-cast v12, Lk92;

    invoke-virtual {v7, v3, v12}, Landroidx/datastore/preferences/protobuf/e;->p(ILk92;)V

    :goto_411
    add-int/lit8 v13, v13, 0x1

    goto :goto_3f8

    :cond_414
    const/4 v13, 0x0

    :goto_415
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    if-ge v13, v11, :cond_20f

    invoke-interface {v5, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v7, v3, v11}, Landroidx/datastore/preferences/protobuf/e;->y(ILjava/lang/String;)V

    add-int/lit8 v13, v13, 0x1

    goto :goto_415

    :pswitch_427  #0x19
    move/from16 v19, v3

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    const/4 v14, 0x0

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->m(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_437  #0x18
    move/from16 v19, v3

    const/4 v14, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->p(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_447  #0x17
    move/from16 v19, v3

    const/4 v14, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->q(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_457  #0x16
    move/from16 v19, v3

    const/4 v14, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->s(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_467  #0x15
    move/from16 v19, v3

    const/4 v14, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->z(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_477  #0x14
    move/from16 v19, v3

    const/4 v14, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->t(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_487  #0x13
    move/from16 v19, v3

    const/4 v14, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->r(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_497  #0x12
    move/from16 v19, v3

    const/4 v14, 0x0

    aget v3, v8, v2

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v3, v5, v6, v14}, Landroidx/datastore/preferences/protobuf/j;->n(ILjava/util/List;Lxs5;Z)V

    goto/16 :goto_33d

    :pswitch_4a7  #0x11
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_601

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v11

    check-cast v5, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v7, v13, v15}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    invoke-interface {v11, v5, v6}, Ldyf;->h(Ljava/lang/Object;Lxs5;)V

    const/4 v5, 0x4

    invoke-virtual {v7, v13, v5}, Landroidx/datastore/preferences/protobuf/e;->A(II)V

    goto/16 :goto_601

    :pswitch_4c4  #0x10
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v11

    const/16 v17, 0x1

    shl-long v15, v11, v17

    shr-long v11, v11, v18

    xor-long/2addr v11, v15

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    :cond_4d9
    :goto_4d9
    move-object/from16 v0, p0

    goto/16 :goto_601

    :pswitch_4dd  #0xf
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    shl-int/lit8 v5, v0, 0x1

    shr-int/lit8 v0, v0, 0x1f

    xor-int/2addr v0, v5

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->B(II)V

    goto :goto_4d9

    :pswitch_4f1  #0xe
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    goto :goto_4d9

    :pswitch_500  #0xd
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    goto :goto_4d9

    :pswitch_50f  #0xc
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->v(II)V

    goto :goto_4d9

    :pswitch_51e  #0xb
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->B(II)V

    goto :goto_4d9

    :pswitch_52d  #0xa
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lk92;

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->p(ILk92;)V

    goto :goto_4d9

    :pswitch_53e  #0x9
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_601

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v11

    invoke-virtual {v6, v13, v5, v11}, Lxs5;->Q(ILjava/lang/Object;Ldyf;)V

    goto/16 :goto_601

    :pswitch_552  #0x8
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    instance-of v5, v0, Ljava/lang/String;

    if-eqz v5, :cond_568

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->y(ILjava/lang/String;)V

    goto/16 :goto_4d9

    :cond_568
    check-cast v0, Lk92;

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->p(ILk92;)V

    goto/16 :goto_4d9

    :pswitch_56f  #0x7
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    sget-object v0, Lm5j;->c:Lh5j;

    invoke-virtual {v0, v11, v12, v1}, Lh5j;->c(JLjava/lang/Object;)Z

    move-result v0

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->o(IZ)V

    goto/16 :goto_4d9

    :pswitch_581  #0x6
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    goto/16 :goto_4d9

    :pswitch_591  #0x5
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    goto/16 :goto_4d9

    :pswitch_5a1  #0x4
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->v(II)V

    goto/16 :goto_4d9

    :pswitch_5b1  #0x3
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    goto/16 :goto_4d9

    :pswitch_5c1  #0x2
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    invoke-virtual {v10, v1, v11, v12}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->D(IJ)V

    goto/16 :goto_4d9

    :pswitch_5d1  #0x1
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d9

    sget-object v0, Lm5j;->c:Lh5j;

    invoke-virtual {v0, v11, v12, v1}, Lh5j;->e(JLjava/lang/Object;)F

    move-result v0

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    invoke-virtual {v7, v13, v0}, Landroidx/datastore/preferences/protobuf/e;->r(II)V

    goto/16 :goto_4d9

    :pswitch_5ea  #0x0
    const/4 v14, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_601

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v11, v12, v1}, Lh5j;->d(JLjava/lang/Object;)D

    move-result-wide v11

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v11, v12}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v11

    invoke-virtual {v7, v13, v11, v12}, Landroidx/datastore/preferences/protobuf/e;->t(IJ)V

    :cond_601
    :goto_601
    add-int/lit8 v2, v2, 0x3

    const v11, 0xfffff

    goto/16 :goto_16

    :cond_608
    iget-object v0, v0, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    check-cast v0, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, v1

    check-cast v0, Landroidx/datastore/preferences/protobuf/f;

    iget-object v0, v0, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    invoke-virtual {v0, v6}, Landroidx/datastore/preferences/protobuf/l;->d(Lxs5;)V

    return-void

    :pswitch_data_618
    .packed-switch 0x0
        :pswitch_5ea  #00000000
        :pswitch_5d1  #00000001
        :pswitch_5c1  #00000002
        :pswitch_5b1  #00000003
        :pswitch_5a1  #00000004
        :pswitch_591  #00000005
        :pswitch_581  #00000006
        :pswitch_56f  #00000007
        :pswitch_552  #00000008
        :pswitch_53e  #00000009
        :pswitch_52d  #0000000a
        :pswitch_51e  #0000000b
        :pswitch_50f  #0000000c
        :pswitch_500  #0000000d
        :pswitch_4f1  #0000000e
        :pswitch_4dd  #0000000f
        :pswitch_4c4  #00000010
        :pswitch_4a7  #00000011
        :pswitch_497  #00000012
        :pswitch_487  #00000013
        :pswitch_477  #00000014
        :pswitch_467  #00000015
        :pswitch_457  #00000016
        :pswitch_447  #00000017
        :pswitch_437  #00000018
        :pswitch_427  #00000019
        :pswitch_3dc  #0000001a
        :pswitch_3b3  #0000001b
        :pswitch_38c  #0000001c
        :pswitch_37d  #0000001d
        :pswitch_36e  #0000001e
        :pswitch_35f  #0000001f
        :pswitch_350  #00000020
        :pswitch_341  #00000021
        :pswitch_32e  #00000022
        :pswitch_31d  #00000023
        :pswitch_30c  #00000024
        :pswitch_2fb  #00000025
        :pswitch_2ea  #00000026
        :pswitch_2d9  #00000027
        :pswitch_2c8  #00000028
        :pswitch_2b7  #00000029
        :pswitch_2a6  #0000002a
        :pswitch_295  #0000002b
        :pswitch_284  #0000002c
        :pswitch_274  #0000002d
        :pswitch_264  #0000002e
        :pswitch_254  #0000002f
        :pswitch_245  #00000030
        :pswitch_213  #00000031
        :pswitch_1ab  #00000032
        :pswitch_18d  #00000033
        :pswitch_16f  #00000034
        :pswitch_160  #00000035
        :pswitch_151  #00000036
        :pswitch_142  #00000037
        :pswitch_133  #00000038
        :pswitch_124  #00000039
        :pswitch_10d  #0000003a
        :pswitch_f1  #0000003b
        :pswitch_de  #0000003c
        :pswitch_cd  #0000003d
        :pswitch_bf  #0000003e
        :pswitch_b1  #0000003f
        :pswitch_a3  #00000040
        :pswitch_95  #00000041
        :pswitch_82  #00000042
        :pswitch_6f  #00000043
        :pswitch_54  #00000044
    .end packed-switch
.end method

.method public final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 13

    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1f5

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    :goto_a
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    array-length v2, v1

    if-ge v0, v2, :cond_1ee

    invoke-virtual {p0, v0}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v2

    const v3, 0xfffff

    and-int/2addr v3, v2

    int-to-long v6, v3

    aget v1, v1, v0

    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v2

    packed-switch v2, :pswitch_data_200

    goto :goto_25

    :pswitch_22  #0x44
    invoke-virtual {p0, p1, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->t(Ljava/lang/Object;ILjava/lang/Object;)V

    :cond_25
    :goto_25
    move-object v5, p1

    goto/16 :goto_1e9

    :pswitch_28  #0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43
    invoke-virtual {p0, v1, p2, v0}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v2

    if-eqz v2, :cond_25

    sget-object v2, Lm5j;->c:Lh5j;

    invoke-virtual {v2, v6, v7, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v6, v7, p1, v2}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v1, p1, v0}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_25

    :pswitch_3b  #0x3c
    invoke-virtual {p0, p1, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->t(Ljava/lang/Object;ILjava/lang/Object;)V

    goto :goto_25

    :pswitch_3f  #0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b
    invoke-virtual {p0, v1, p2, v0}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v2

    if-eqz v2, :cond_25

    sget-object v2, Lm5j;->c:Lh5j;

    invoke-virtual {v2, v6, v7, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v6, v7, p1, v2}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v1, p1, v0}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_25

    :pswitch_52  #0x32
    sget-object v1, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iget-object v3, p0, Landroidx/datastore/preferences/protobuf/h;->m:Lz5b;

    invoke-virtual {v3, v2, v1}, Lz5b;->a(Ljava/lang/Object;Ljava/lang/Object;)Lu5b;

    move-result-object v1

    invoke-static {v6, v7, p1, v1}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    goto :goto_25

    :pswitch_68  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/h;->k:Lfma;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lfl9;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lfl9;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v4

    if-lez v3, :cond_9a

    if-lez v4, :cond_9a

    move-object v5, v2

    check-cast v5, Ls3;

    invoke-virtual {v5}, Ls3;->b()Z

    move-result v5

    if-nez v5, :cond_97

    add-int/2addr v4, v3

    check-cast v2, Lvfe;

    invoke-virtual {v2, v4}, Lvfe;->k(I)Lvfe;

    move-result-object v2

    :cond_97
    invoke-interface {v2, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_9a
    if-lez v3, :cond_9d

    move-object v1, v2

    :cond_9d
    invoke-static {v6, v7, p1, v1}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    goto :goto_25

    :pswitch_a1  #0x11
    invoke-virtual {p0, p1, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->s(Ljava/lang/Object;ILjava/lang/Object;)V

    goto :goto_25

    :pswitch_a5  #0x10
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_b9  #0xf
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_cd  #0xe
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_e1  #0xd
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_f5  #0xc
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_109  #0xb
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_11d  #0xa
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v6, v7, p1, v1}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_131  #0x9
    invoke-virtual {p0, p1, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->s(Ljava/lang/Object;ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_136  #0x8
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v6, v7, p1, v1}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_14a  #0x7
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->c(JLjava/lang/Object;)Z

    move-result v2

    invoke-virtual {v1, p1, v6, v7, v2}, Lh5j;->j(Ljava/lang/Object;JZ)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_15e  #0x6
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_172  #0x5
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_186  #0x4
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_19a  #0x3
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_1ae  #0x2
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_1c2  #0x1
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Lm5j;->c:Lh5j;

    invoke-virtual {v1, v6, v7, p2}, Lh5j;->e(JLjava/lang/Object;)F

    move-result v2

    invoke-virtual {v1, p1, v6, v7, v2}, Lh5j;->m(Ljava/lang/Object;JF)V

    invoke-virtual {p0, v0, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_1d6  #0x0
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p2}, Lh5j;->d(JLjava/lang/Object;)D

    move-result-wide v8

    move-object v5, p1

    invoke-virtual/range {v4 .. v9}, Lh5j;->l(Ljava/lang/Object;JD)V

    invoke-virtual {p0, v0, v5}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    :goto_1e9
    add-int/lit8 v0, v0, 0x3

    move-object p1, v5

    goto/16 :goto_a

    :cond_1ee
    move-object v5, p1

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    invoke-static {p0, v5, p2}, Landroidx/datastore/preferences/protobuf/j;->k(Landroidx/datastore/preferences/protobuf/k;Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_1f5
    move-object v5, p1

    const-string p0, "Mutating immutable message: "

    invoke-static {p0, v5}, Lb40;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    return-void

    :pswitch_data_200
    .packed-switch 0x0
        :pswitch_1d6  #00000000
        :pswitch_1c2  #00000001
        :pswitch_1ae  #00000002
        :pswitch_19a  #00000003
        :pswitch_186  #00000004
        :pswitch_172  #00000005
        :pswitch_15e  #00000006
        :pswitch_14a  #00000007
        :pswitch_136  #00000008
        :pswitch_131  #00000009
        :pswitch_11d  #0000000a
        :pswitch_109  #0000000b
        :pswitch_f5  #0000000c
        :pswitch_e1  #0000000d
        :pswitch_cd  #0000000e
        :pswitch_b9  #0000000f
        :pswitch_a5  #00000010
        :pswitch_a1  #00000011
        :pswitch_68  #00000012
        :pswitch_68  #00000013
        :pswitch_68  #00000014
        :pswitch_68  #00000015
        :pswitch_68  #00000016
        :pswitch_68  #00000017
        :pswitch_68  #00000018
        :pswitch_68  #00000019
        :pswitch_68  #0000001a
        :pswitch_68  #0000001b
        :pswitch_68  #0000001c
        :pswitch_68  #0000001d
        :pswitch_68  #0000001e
        :pswitch_68  #0000001f
        :pswitch_68  #00000020
        :pswitch_68  #00000021
        :pswitch_68  #00000022
        :pswitch_68  #00000023
        :pswitch_68  #00000024
        :pswitch_68  #00000025
        :pswitch_68  #00000026
        :pswitch_68  #00000027
        :pswitch_68  #00000028
        :pswitch_68  #00000029
        :pswitch_68  #0000002a
        :pswitch_68  #0000002b
        :pswitch_68  #0000002c
        :pswitch_68  #0000002d
        :pswitch_68  #0000002e
        :pswitch_68  #0000002f
        :pswitch_68  #00000030
        :pswitch_68  #00000031
        :pswitch_52  #00000032
        :pswitch_3f  #00000033
        :pswitch_3f  #00000034
        :pswitch_3f  #00000035
        :pswitch_3f  #00000036
        :pswitch_3f  #00000037
        :pswitch_3f  #00000038
        :pswitch_3f  #00000039
        :pswitch_3f  #0000003a
        :pswitch_3f  #0000003b
        :pswitch_3b  #0000003c
        :pswitch_28  #0000003d
        :pswitch_28  #0000003e
        :pswitch_28  #0000003f
        :pswitch_28  #00000040
        :pswitch_28  #00000041
        :pswitch_28  #00000042
        :pswitch_28  #00000043
        :pswitch_22  #00000044
    .end packed-switch
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 11

    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto/16 :goto_a4

    :cond_8
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/f;

    const/4 v1, 0x0

    if-eqz v0, :cond_1b

    move-object v0, p1

    check-cast v0, Landroidx/datastore/preferences/protobuf/f;

    const v2, 0x7fffffff

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/f;->k(I)V

    iput v1, v0, Landroidx/datastore/preferences/protobuf/a;->memoizedHashCode:I

    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/f;->h()V

    :cond_1b
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    array-length v2, v0

    move v3, v1

    :goto_1f
    if-ge v3, v2, :cond_93

    invoke-virtual {p0, v3}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v4

    const v5, 0xfffff

    and-int/2addr v5, v4

    int-to-long v5, v5

    invoke-static {v4}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v4

    const/16 v7, 0x9

    if-eq v4, v7, :cond_7d

    const/16 v7, 0x3c

    if-eq v4, v7, :cond_67

    const/16 v7, 0x44

    if-eq v4, v7, :cond_67

    packed-switch v4, :pswitch_data_a6

    goto :goto_90

    :pswitch_3e  #0x32
    sget-object v4, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v4, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_90

    iget-object v8, p0, Landroidx/datastore/preferences/protobuf/h;->m:Lz5b;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v8, v7

    check-cast v8, Lu5b;

    iput-boolean v1, v8, Lu5b;->E:Z

    invoke-virtual {v4, p1, v5, v6, v7}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_90

    :pswitch_54  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    iget-object v4, p0, Landroidx/datastore/preferences/protobuf/h;->k:Lfma;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v5, v6, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lfl9;

    check-cast v4, Ls3;

    invoke-virtual {v4}, Ls3;->c()V

    goto :goto_90

    :cond_67
    aget v4, v0, v3

    invoke-virtual {p0, v4, p1, v3}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_90

    invoke-virtual {p0, v3}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v4

    sget-object v7, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v4, v5}, Ldyf;->b(Ljava/lang/Object;)V

    goto :goto_90

    :cond_7d
    :pswitch_7d  #0x11
    invoke-virtual {p0, v3, p1}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_90

    invoke-virtual {p0, v3}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v4

    sget-object v7, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v4, v5}, Ldyf;->b(Ljava/lang/Object;)V

    :cond_90
    :goto_90
    add-int/lit8 v3, v3, 0x3

    goto :goto_1f

    :cond_93
    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    check-cast p0, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/datastore/preferences/protobuf/f;

    iget-object p0, p1, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    iget-boolean p1, p0, Landroidx/datastore/preferences/protobuf/l;->e:Z

    if-eqz p1, :cond_a4

    iput-boolean v1, p0, Landroidx/datastore/preferences/protobuf/l;->e:Z

    :cond_a4
    :goto_a4
    return-void

    nop

    :pswitch_data_a6
    .packed-switch 0x11
        :pswitch_7d  #00000011
        :pswitch_54  #00000012
        :pswitch_54  #00000013
        :pswitch_54  #00000014
        :pswitch_54  #00000015
        :pswitch_54  #00000016
        :pswitch_54  #00000017
        :pswitch_54  #00000018
        :pswitch_54  #00000019
        :pswitch_54  #0000001a
        :pswitch_54  #0000001b
        :pswitch_54  #0000001c
        :pswitch_54  #0000001d
        :pswitch_54  #0000001e
        :pswitch_54  #0000001f
        :pswitch_54  #00000020
        :pswitch_54  #00000021
        :pswitch_54  #00000022
        :pswitch_54  #00000023
        :pswitch_54  #00000024
        :pswitch_54  #00000025
        :pswitch_54  #00000026
        :pswitch_54  #00000027
        :pswitch_54  #00000028
        :pswitch_54  #00000029
        :pswitch_54  #0000002a
        :pswitch_54  #0000002b
        :pswitch_54  #0000002c
        :pswitch_54  #0000002d
        :pswitch_54  #0000002e
        :pswitch_54  #0000002f
        :pswitch_54  #00000030
        :pswitch_54  #00000031
        :pswitch_3e  #00000032
    .end packed-switch
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const v6, 0xfffff

    const/4 v7, 0x0

    move v2, v6

    move v3, v7

    move v8, v3

    :goto_b
    iget v4, v0, Landroidx/datastore/preferences/protobuf/h;->h:I

    const/4 v5, 0x1

    if-ge v8, v4, :cond_122

    iget-object v4, v0, Landroidx/datastore/preferences/protobuf/h;->g:[I

    aget v4, v4, v8

    iget-object v9, v0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget v10, v9, v4

    invoke-virtual {v0, v4}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v11

    add-int/lit8 v12, v4, 0x2

    aget v9, v9, v12

    and-int v12, v9, v6

    ushr-int/lit8 v9, v9, 0x14

    shl-int/2addr v5, v9

    if-eq v12, v2, :cond_34

    if-eq v12, v6, :cond_30

    sget-object v2, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    int-to-long v13, v12

    invoke-virtual {v2, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    :cond_30
    move v2, v4

    move v4, v3

    move v3, v12

    goto :goto_38

    :cond_34
    move v15, v3

    move v3, v2

    move v2, v4

    move v4, v15

    :goto_38
    const/high16 v9, 0x10000000

    and-int/2addr v9, v11

    if-eqz v9, :cond_45

    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v9

    if-nez v9, :cond_45

    goto/16 :goto_11b

    :cond_45
    invoke-static {v11}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v9

    const/16 v12, 0x9

    if-eq v9, v12, :cond_102

    const/16 v12, 0x11

    if-eq v9, v12, :cond_102

    const/16 v5, 0x1b

    if-eq v9, v5, :cond_d7

    const/16 v5, 0x3c

    if-eq v9, v5, :cond_bd

    const/16 v5, 0x44

    if-eq v9, v5, :cond_bd

    const/16 v5, 0x31

    if-eq v9, v5, :cond_d7

    const/16 v5, 0x32

    if-eq v9, v5, :cond_67

    goto/16 :goto_11c

    :cond_67
    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v9, v10, v1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    iget-object v9, v0, Landroidx/datastore/preferences/protobuf/h;->m:Lz5b;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, Lu5b;

    invoke-virtual {v5}, Ljava/util/HashMap;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_7f

    goto/16 :goto_11c

    :cond_7f
    div-int/lit8 v2, v2, 0x3

    mul-int/lit8 v2, v2, 0x2

    iget-object v9, v0, Landroidx/datastore/preferences/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v2, v9, v2

    check-cast v2, Lm5b;

    iget-object v2, v2, Lm5b;->a:Lhk0;

    iget-object v2, v2, Lhk0;->F:Ljava/lang/Object;

    check-cast v2, Lx5k;

    iget-object v2, v2, Lx5k;->E:Lb6k;

    sget-object v9, Lb6k;->M:Lb6k;

    if-eq v2, v9, :cond_97

    goto/16 :goto_11c

    :cond_97
    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v5, 0x0

    :cond_a0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_11c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    if-nez v5, :cond_b6

    sget-object v5, Lqfe;->c:Lqfe;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v10

    invoke-virtual {v5, v10}, Lqfe;->a(Ljava/lang/Class;)Ldyf;

    move-result-object v5

    :cond_b6
    invoke-interface {v5, v9}, Ldyf;->c(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_a0

    goto :goto_11b

    :cond_bd
    invoke-virtual {v0, v10, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_11c

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v2

    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v9, v10, v1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Ldyf;->c(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_11c

    goto :goto_11b

    :cond_d7
    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v9, v10, v1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_e9

    goto :goto_11c

    :cond_e9
    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v2

    move v9, v7

    :goto_ee
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-ge v9, v10, :cond_11c

    invoke-interface {v5, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-interface {v2, v10}, Ldyf;->c(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_ff

    goto :goto_11b

    :cond_ff
    add-int/lit8 v9, v9, 0x1

    goto :goto_ee

    :cond_102
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_11c

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v2

    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v9, v10, v1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Ldyf;->c(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_11c

    :goto_11b
    return v7

    :cond_11c
    :goto_11c
    add-int/lit8 v8, v8, 0x1

    move v2, v3

    move v3, v4

    goto/16 :goto_b

    :cond_122
    return v5
.end method

.method public final d()Landroidx/datastore/preferences/protobuf/f;
    .registers 2

    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/h;->j:Lakc;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->e:Landroidx/datastore/preferences/protobuf/a;

    check-cast p0, Landroidx/datastore/preferences/protobuf/f;

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/f;->i()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p0

    return-object p0
.end method

.method public final e(Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/d;Lkm7;)V
    .registers 22

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_65b

    iget-object v8, v1, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    iget-object v9, v1, Landroidx/datastore/preferences/protobuf/h;->g:[I

    iget v10, v1, Landroidx/datastore/preferences/protobuf/h;->i:I

    iget v11, v1, Landroidx/datastore/preferences/protobuf/h;->h:I

    const/4 v0, 0x0

    move-object v12, v0

    :goto_1b
    :try_start_1b
    invoke-virtual {v4}, Landroidx/datastore/preferences/protobuf/d;->a()I

    move-result v0

    invoke-virtual {v1, v0}, Landroidx/datastore/preferences/protobuf/h;->A(I)I

    move-result v3
    :try_end_23
    .catchall {:try_start_1b .. :try_end_23} :catchall_4e

    const/4 v13, 0x0

    if-gez v3, :cond_66

    const v3, 0x7fffffff

    if-ne v0, v3, :cond_43

    :goto_2b
    if-ge v11, v10, :cond_35

    aget v0, v9, v11

    invoke-virtual {v1, v2, v0, v12}, Landroidx/datastore/preferences/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_2b

    :cond_35
    if-eqz v12, :cond_63d

    check-cast v8, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_3c
    move-object v0, v2

    check-cast v0, Landroidx/datastore/preferences/protobuf/f;

    iput-object v12, v0, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    goto/16 :goto_63d

    :cond_43
    :try_start_43
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v12, :cond_52

    invoke-virtual {v8, v2}, Landroidx/datastore/preferences/protobuf/k;->a(Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/l;

    move-result-object v0

    move-object v12, v0

    goto :goto_52

    :catchall_4e
    move-exception v0

    :goto_4f
    move-object v6, v1

    goto/16 :goto_644

    :cond_52
    :goto_52
    invoke-virtual {v8, v13, v4, v12}, Landroidx/datastore/preferences/protobuf/k;->b(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)Z

    move-result v0
    :try_end_56
    .catchall {:try_start_43 .. :try_end_56} :catchall_4e

    if-eqz v0, :cond_59

    goto :goto_1b

    :cond_59
    :goto_59
    if-ge v11, v10, :cond_63

    aget v0, v9, v11

    invoke-virtual {v1, v2, v0, v12}, Landroidx/datastore/preferences/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_59

    :cond_63
    if-eqz v12, :cond_63d

    :goto_65
    goto :goto_3c

    :cond_66
    :try_start_66
    invoke-virtual {v1, v3}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v6
    :try_end_6a
    .catchall {:try_start_66 .. :try_end_6a} :catchall_4e

    :try_start_6a
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v7
    :try_end_6e
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_6a .. :try_end_6e} :catch_7c
    .catchall {:try_start_6a .. :try_end_6e} :catchall_4e

    const/4 v15, 0x3

    iget-object v14, v1, Landroidx/datastore/preferences/protobuf/h;->k:Lfma;

    packed-switch v7, :pswitch_data_666

    if-nez v12, :cond_80

    :try_start_76
    invoke-virtual {v8, v2}, Landroidx/datastore/preferences/protobuf/k;->a(Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/l;

    move-result-object v0

    move-object v12, v0

    goto :goto_80

    :catch_7c
    move-object v6, v1

    :goto_7d
    move-object v14, v4

    goto/16 :goto_61f

    :cond_80
    :goto_80
    invoke-virtual {v8, v13, v4, v12}, Landroidx/datastore/preferences/protobuf/k;->b(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)Z

    move-result v0
    :try_end_84
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_76 .. :try_end_84} :catch_7c
    .catchall {:try_start_76 .. :try_end_84} :catchall_4e

    if-nez v0, :cond_a6

    :goto_86
    if-ge v11, v10, :cond_90

    aget v0, v9, v11

    invoke-virtual {v1, v2, v0, v12}, Landroidx/datastore/preferences/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_86

    :cond_90
    if-eqz v12, :cond_63d

    goto :goto_65

    :pswitch_93  #0x44
    :try_start_93
    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->v(ILjava/lang/Object;I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v1, v3}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v7

    invoke-virtual {v4, v15}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    invoke-virtual {v4, v6, v7, v5}, Landroidx/datastore/preferences/protobuf/d;->b(Ljava/lang/Object;Ldyf;Lkm7;)V

    invoke-virtual {v1, v2, v0, v3, v6}, Landroidx/datastore/preferences/protobuf/h;->J(Ljava/lang/Object;IILandroidx/datastore/preferences/protobuf/a;)V

    :cond_a6
    :goto_a6
    move-object v6, v1

    move-object v14, v4

    goto/16 :goto_63e

    :pswitch_aa  #0x43
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->r()J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_a6

    :pswitch_c2  #0x42
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->q()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_a6

    :pswitch_da  #0x41
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    const/4 v14, 0x1

    invoke-virtual {v4, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->p()J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_a6

    :pswitch_f3  #0x40
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    const/4 v14, 0x5

    invoke-virtual {v4, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->o()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_a6

    :pswitch_10c  #0x3f
    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v7, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v7}, Lnl4;->i()I

    move-result v7

    invoke-virtual {v1, v3}, Landroidx/datastore/preferences/protobuf/h;->l(I)V

    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v14

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v14, v15, v2, v6}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_128  #0x3e
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->v()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_141  #0x3d
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4}, Landroidx/datastore/preferences/protobuf/d;->e()Lk92;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_151  #0x3c
    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->v(ILjava/lang/Object;I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v1, v3}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v7

    const/4 v14, 0x2

    invoke-virtual {v4, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    invoke-virtual {v4, v6, v7, v5}, Landroidx/datastore/preferences/protobuf/d;->c(Ljava/lang/Object;Ldyf;Lkm7;)V

    invoke-virtual {v1, v2, v0, v3, v6}, Landroidx/datastore/preferences/protobuf/h;->J(Ljava/lang/Object;IILandroidx/datastore/preferences/protobuf/a;)V

    goto/16 :goto_a6

    :pswitch_167  #0x3b
    invoke-virtual {v1, v6, v4, v2}, Landroidx/datastore/preferences/protobuf/h;->D(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_16f  #0x3a
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->f()Z

    move-result v14

    invoke-static {v14}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_188  #0x39
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    const/4 v14, 0x5

    invoke-virtual {v4, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->j()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_1a2  #0x38
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    const/4 v14, 0x1

    invoke-virtual {v4, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->k()J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_1bc  #0x37
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->m()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_1d5  #0x36
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->w()J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_1ee  #0x35
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    invoke-virtual {v4, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->n()J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_207  #0x34
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    const/4 v14, 0x5

    invoke-virtual {v4, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->l()F

    move-result v14

    invoke-static {v14}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_a6

    :pswitch_221  #0x33
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v6

    const/4 v14, 0x1

    invoke-virtual {v4, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v14, v4, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v14}, Lnl4;->h()D

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v14

    invoke-static {v6, v7, v2, v14}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v3}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V
    :try_end_239
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_93 .. :try_end_239} :catch_7c
    .catchall {:try_start_93 .. :try_end_239} :catchall_4e

    goto/16 :goto_a6

    :pswitch_23b  #0x32
    :try_start_23b
    iget-object v0, v1, Landroidx/datastore/preferences/protobuf/h;->b:[Ljava/lang/Object;

    div-int/lit8 v6, v3, 0x3

    const/16 v16, 0x2

    mul-int/lit8 v6, v6, 0x2

    aget-object v0, v0, v6

    move-object v6, v4

    move-object v4, v0

    invoke-virtual/range {v1 .. v6}, Landroidx/datastore/preferences/protobuf/h;->r(Ljava/lang/Object;ILjava/lang/Object;Lkm7;Landroidx/datastore/preferences/protobuf/d;)V

    move-object/from16 v2, p1

    move-object/from16 v14, p2

    move-object v6, v1

    goto/16 :goto_63e

    :catchall_251
    move-exception v0

    move-object/from16 v2, p1

    goto/16 :goto_4f

    :catch_256
    move-object/from16 v2, p1

    move-object/from16 v14, p2

    move-object v6, v1

    goto/16 :goto_61f

    :pswitch_25d  #0x31
    move v7, v3

    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v1, v7}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v6
    :try_end_266
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_23b .. :try_end_266} :catch_256
    .catchall {:try_start_23b .. :try_end_266} :catchall_251

    move-object/from16 v2, p1

    move-object/from16 v5, p2

    move-object/from16 v7, p3

    :try_start_26c
    invoke-virtual/range {v1 .. v7}, Landroidx/datastore/preferences/protobuf/h;->B(Ljava/lang/Object;JLandroidx/datastore/preferences/protobuf/d;Ldyf;Lkm7;)V
    :try_end_26f
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_26c .. :try_end_26f} :catch_272
    .catchall {:try_start_26c .. :try_end_26f} :catchall_4e

    move-object v4, v5

    goto/16 :goto_a6

    :catch_272
    move-object v6, v1

    move-object v14, v5

    goto/16 :goto_61f

    :pswitch_276  #0x30
    :try_start_276
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->r(Ls3;)V

    goto/16 :goto_a6

    :pswitch_283  #0x2f
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->q(Ls3;)V

    goto/16 :goto_a6

    :pswitch_290  #0x2e
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->p(Ls3;)V

    goto/16 :goto_a6

    :pswitch_29d  #0x2d
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->o(Ls3;)V

    goto/16 :goto_a6

    :pswitch_2aa  #0x2c
    move v7, v3

    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroidx/datastore/preferences/protobuf/d;->h(Ls3;)V

    invoke-virtual {v1, v7}, Landroidx/datastore/preferences/protobuf/h;->l(I)V

    invoke-static {v2, v0, v3, v12, v8}, Landroidx/datastore/preferences/protobuf/j;->j(Ljava/lang/Object;ILs3;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/k;)Ljava/lang/Object;

    goto/16 :goto_a6

    :pswitch_2be  #0x2b
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->t(Ls3;)V

    goto/16 :goto_a6

    :pswitch_2cb  #0x2a
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->d(Ls3;)V

    goto/16 :goto_a6

    :pswitch_2d8  #0x29
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->j(Ls3;)V

    goto/16 :goto_a6

    :pswitch_2e5  #0x28
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->k(Ls3;)V

    goto/16 :goto_a6

    :pswitch_2f2  #0x27
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->m(Ls3;)V

    goto/16 :goto_a6

    :pswitch_2ff  #0x26
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->u(Ls3;)V

    goto/16 :goto_a6

    :pswitch_30c  #0x25
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->n(Ls3;)V

    goto/16 :goto_a6

    :pswitch_319  #0x24
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->l(Ls3;)V

    goto/16 :goto_a6

    :pswitch_326  #0x23
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->g(Ls3;)V

    goto/16 :goto_a6

    :pswitch_333  #0x22
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->r(Ls3;)V

    goto/16 :goto_a6

    :pswitch_340  #0x21
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->q(Ls3;)V

    goto/16 :goto_a6

    :pswitch_34d  #0x20
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->p(Ls3;)V

    goto/16 :goto_a6

    :pswitch_35a  #0x1f
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->o(Ls3;)V

    goto/16 :goto_a6

    :pswitch_367  #0x1e
    move v7, v3

    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroidx/datastore/preferences/protobuf/d;->h(Ls3;)V

    invoke-virtual {v1, v7}, Landroidx/datastore/preferences/protobuf/h;->l(I)V

    invoke-static {v2, v0, v3, v12, v8}, Landroidx/datastore/preferences/protobuf/j;->j(Ljava/lang/Object;ILs3;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/k;)Ljava/lang/Object;

    goto/16 :goto_a6

    :pswitch_37b  #0x1d
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->t(Ls3;)V

    goto/16 :goto_a6

    :pswitch_388  #0x1c
    invoke-static {v6}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v14, v5, v6, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/datastore/preferences/protobuf/d;->f(Ls3;)V
    :try_end_393
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_276 .. :try_end_393} :catch_7c
    .catchall {:try_start_276 .. :try_end_393} :catchall_4e

    goto/16 :goto_a6

    :pswitch_395  #0x1b
    move v7, v3

    :try_start_396
    invoke-virtual {v1, v7}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v5
    :try_end_39a
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_396 .. :try_end_39a} :catch_3ae
    .catchall {:try_start_396 .. :try_end_39a} :catchall_4e

    move v3, v6

    move-object/from16 v6, p3

    :try_start_39d
    invoke-virtual/range {v1 .. v6}, Landroidx/datastore/preferences/protobuf/h;->C(Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/d;Ldyf;Lkm7;)V
    :try_end_3a0
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_39d .. :try_end_3a0} :catch_3a7
    .catchall {:try_start_39d .. :try_end_3a0} :catchall_4e

    move-object v0, v6

    move-object v6, v1

    move-object v1, v0

    move-object v0, v4

    :goto_3a4
    move-object v14, v0

    goto/16 :goto_63e

    :catch_3a7
    move-object/from16 v17, v6

    move-object v6, v1

    move-object/from16 v1, v17

    goto/16 :goto_7d

    :catch_3ae
    move-object v6, v1

    move-object/from16 v1, p3

    goto/16 :goto_7d

    :pswitch_3b3  #0x1a
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    :try_start_3b7
    invoke-virtual {v6, v3, v0, v2}, Landroidx/datastore/preferences/protobuf/h;->E(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)V

    goto :goto_3a4

    :catch_3bb
    move-object v14, v0

    goto/16 :goto_61f

    :pswitch_3be  #0x19
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->d(Ls3;)V

    goto :goto_3a4

    :pswitch_3ce  #0x18
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->j(Ls3;)V

    goto :goto_3a4

    :pswitch_3de  #0x17
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->k(Ls3;)V

    goto :goto_3a4

    :pswitch_3ee  #0x16
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->m(Ls3;)V

    goto :goto_3a4

    :pswitch_3fe  #0x15
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->u(Ls3;)V

    goto :goto_3a4

    :pswitch_40e  #0x14
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->n(Ls3;)V

    goto :goto_3a4

    :pswitch_41e  #0x13
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->l(Ls3;)V

    goto/16 :goto_3a4

    :pswitch_42f  #0x12
    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v14, v3, v4, v2}, Lfma;->a(JLjava/lang/Object;)Ls3;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroidx/datastore/preferences/protobuf/d;->g(Ls3;)V

    goto/16 :goto_3a4

    :pswitch_440  #0x11
    move-object v6, v1

    move v7, v3

    move-object v0, v4

    move-object v1, v5

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->u(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v6, v7}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v4

    invoke-virtual {v0, v15}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    invoke-virtual {v0, v3, v4, v1}, Landroidx/datastore/preferences/protobuf/d;->b(Ljava/lang/Object;Ldyf;Lkm7;)V

    invoke-virtual {v6, v2, v7, v3}, Landroidx/datastore/preferences/protobuf/h;->I(Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/a;)V

    goto/16 :goto_3a4

    :catchall_459
    move-exception v0

    goto/16 :goto_644

    :pswitch_45c  #0x10
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->r()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_476  #0xf
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->q()I

    move-result v5

    invoke-static {v5, v3, v4, v2}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_490  #0xe
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v14, 0x1

    invoke-virtual {v0, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->p()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_4ab  #0xd
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v14, 0x5

    invoke-virtual {v0, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->o()I

    move-result v5

    invoke-static {v5, v3, v4, v2}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_4c6  #0xc
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v4, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v4}, Lnl4;->i()I

    move-result v4

    invoke-virtual {v6, v7}, Landroidx/datastore/preferences/protobuf/h;->l(I)V

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v14

    invoke-static {v4, v14, v15, v2}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_4e3  #0xb
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->v()I

    move-result v5

    invoke-static {v5, v3, v4, v2}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_4fd  #0xa
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/d;->e()Lk92;

    move-result-object v5

    invoke-static {v3, v4, v2, v5}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_512  #0x9
    move-object v6, v1

    move v7, v3

    move-object v0, v4

    move-object v1, v5

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->u(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v6, v7}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v4

    const/4 v14, 0x2

    invoke-virtual {v0, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    invoke-virtual {v0, v3, v4, v1}, Landroidx/datastore/preferences/protobuf/d;->c(Ljava/lang/Object;Ldyf;Lkm7;)V

    invoke-virtual {v6, v2, v7, v3}, Landroidx/datastore/preferences/protobuf/h;->I(Ljava/lang/Object;ILandroidx/datastore/preferences/protobuf/a;)V

    goto/16 :goto_3a4

    :pswitch_52c  #0x8
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-virtual {v6, v3, v0, v2}, Landroidx/datastore/preferences/protobuf/h;->D(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_539  #0x7
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->f()Z

    move-result v5

    sget-object v14, Lm5j;->c:Lh5j;

    invoke-virtual {v14, v2, v3, v4, v5}, Lh5j;->j(Ljava/lang/Object;JZ)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_555  #0x6
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v14, 0x5

    invoke-virtual {v0, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->j()I

    move-result v5

    invoke-static {v5, v3, v4, v2}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_570  #0x5
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v14, 0x1

    invoke-virtual {v0, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->k()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_58b  #0x4
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->m()I

    move-result v5

    invoke-static {v5, v3, v4, v2}, Lm5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_5a5  #0x3
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->w()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_5bf  #0x2
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v0, v13}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->n()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Lm5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_5d9  #0x1
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v14, 0x5

    invoke-virtual {v0, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->l()F

    move-result v5

    sget-object v14, Lm5j;->c:Lh5j;

    invoke-virtual {v14, v2, v3, v4, v5}, Lh5j;->m(Ljava/lang/Object;JF)V

    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_3a4

    :pswitch_5f6  #0x0
    move v7, v3

    move-object v0, v4

    move v3, v6

    move-object v6, v1

    move-object v1, v5

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v14, 0x1

    invoke-virtual {v0, v14}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {v5}, Lnl4;->h()D

    move-result-wide v14
    :try_end_609
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_3b7 .. :try_end_609} :catch_3bb
    .catchall {:try_start_3b7 .. :try_end_609} :catchall_459

    :try_start_609
    sget-object v0, Lm5j;->c:Lh5j;
    :try_end_60b
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_609 .. :try_end_60b} :catch_61d
    .catchall {:try_start_609 .. :try_end_60b} :catchall_459

    move-object v1, v2

    move-wide v2, v3

    move-wide v4, v14

    move-object/from16 v14, p2

    :try_start_610
    invoke-virtual/range {v0 .. v5}, Lh5j;->l(Ljava/lang/Object;JD)V
    :try_end_613
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_610 .. :try_end_613} :catch_61b
    .catchall {:try_start_610 .. :try_end_613} :catchall_618

    move-object v2, v1

    :try_start_614
    invoke-virtual {v6, v7, v2}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V
    :try_end_617
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_614 .. :try_end_617} :catch_61f
    .catchall {:try_start_614 .. :try_end_617} :catchall_459

    goto :goto_63e

    :catchall_618
    move-exception v0

    move-object v2, v1

    goto :goto_644

    :catch_61b
    move-object v2, v1

    goto :goto_61f

    :catch_61d
    move-object/from16 v14, p2

    :catch_61f
    :goto_61f
    :try_start_61f
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v12, :cond_629

    invoke-virtual {v8, v2}, Landroidx/datastore/preferences/protobuf/k;->a(Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/l;

    move-result-object v0

    move-object v12, v0

    :cond_629
    invoke-virtual {v8, v13, v14, v12}, Landroidx/datastore/preferences/protobuf/k;->b(ILandroidx/datastore/preferences/protobuf/d;Ljava/lang/Object;)Z

    move-result v0
    :try_end_62d
    .catchall {:try_start_61f .. :try_end_62d} :catchall_459

    if-nez v0, :cond_63e

    :goto_62f
    if-ge v11, v10, :cond_639

    aget v0, v9, v11

    invoke-virtual {v6, v2, v0, v12}, Landroidx/datastore/preferences/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_62f

    :cond_639
    if-eqz v12, :cond_63d

    goto/16 :goto_65

    :cond_63d
    :goto_63d
    return-void

    :cond_63e
    :goto_63e
    move-object/from16 v5, p3

    move-object v1, v6

    move-object v4, v14

    goto/16 :goto_1b

    :goto_644
    if-ge v11, v10, :cond_64e

    aget v1, v9, v11

    invoke-virtual {v6, v2, v1, v12}, Landroidx/datastore/preferences/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_644

    :cond_64e
    if-eqz v12, :cond_65a

    check-cast v8, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v1, v2

    check-cast v1, Landroidx/datastore/preferences/protobuf/f;

    iput-object v12, v1, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    :cond_65a
    throw v0

    :cond_65b
    const-string v0, "Mutating immutable message: "

    invoke-static {v0, v2}, Lb40;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le97;->p(Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_666
    .packed-switch 0x0
        :pswitch_5f6  #00000000
        :pswitch_5d9  #00000001
        :pswitch_5bf  #00000002
        :pswitch_5a5  #00000003
        :pswitch_58b  #00000004
        :pswitch_570  #00000005
        :pswitch_555  #00000006
        :pswitch_539  #00000007
        :pswitch_52c  #00000008
        :pswitch_512  #00000009
        :pswitch_4fd  #0000000a
        :pswitch_4e3  #0000000b
        :pswitch_4c6  #0000000c
        :pswitch_4ab  #0000000d
        :pswitch_490  #0000000e
        :pswitch_476  #0000000f
        :pswitch_45c  #00000010
        :pswitch_440  #00000011
        :pswitch_42f  #00000012
        :pswitch_41e  #00000013
        :pswitch_40e  #00000014
        :pswitch_3fe  #00000015
        :pswitch_3ee  #00000016
        :pswitch_3de  #00000017
        :pswitch_3ce  #00000018
        :pswitch_3be  #00000019
        :pswitch_3b3  #0000001a
        :pswitch_395  #0000001b
        :pswitch_388  #0000001c
        :pswitch_37b  #0000001d
        :pswitch_367  #0000001e
        :pswitch_35a  #0000001f
        :pswitch_34d  #00000020
        :pswitch_340  #00000021
        :pswitch_333  #00000022
        :pswitch_326  #00000023
        :pswitch_319  #00000024
        :pswitch_30c  #00000025
        :pswitch_2ff  #00000026
        :pswitch_2f2  #00000027
        :pswitch_2e5  #00000028
        :pswitch_2d8  #00000029
        :pswitch_2cb  #0000002a
        :pswitch_2be  #0000002b
        :pswitch_2aa  #0000002c
        :pswitch_29d  #0000002d
        :pswitch_290  #0000002e
        :pswitch_283  #0000002f
        :pswitch_276  #00000030
        :pswitch_25d  #00000031
        :pswitch_23b  #00000032
        :pswitch_221  #00000033
        :pswitch_207  #00000034
        :pswitch_1ee  #00000035
        :pswitch_1d5  #00000036
        :pswitch_1bc  #00000037
        :pswitch_1a2  #00000038
        :pswitch_188  #00000039
        :pswitch_16f  #0000003a
        :pswitch_167  #0000003b
        :pswitch_151  #0000003c
        :pswitch_141  #0000003d
        :pswitch_128  #0000003e
        :pswitch_10c  #0000003f
        :pswitch_f3  #00000040
        :pswitch_da  #00000041
        :pswitch_c2  #00000042
        :pswitch_aa  #00000043
        :pswitch_93  #00000044
    .end packed-switch
.end method

.method public final f(Landroidx/datastore/preferences/protobuf/f;)I
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    sget-object v6, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    const v8, 0xfffff

    move v3, v8

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v9, 0x0

    :goto_d
    iget-object v5, v0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    array-length v10, v5

    if-ge v2, v10, :cond_6cc

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v10

    invoke-static {v10}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v11

    aget v12, v5, v2

    add-int/lit8 v13, v2, 0x2

    aget v5, v5, v13

    and-int v13, v5, v8

    const/16 v14, 0x11

    const/4 v15, 0x1

    if-gt v11, v14, :cond_39

    if-eq v13, v3, :cond_34

    if-ne v13, v8, :cond_2d

    const/4 v4, 0x0

    goto :goto_33

    :cond_2d
    int-to-long v3, v13

    invoke-virtual {v6, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    move v4, v3

    :goto_33
    move v3, v13

    :cond_34
    ushr-int/lit8 v5, v5, 0x14

    shl-int v5, v15, v5

    goto :goto_3a

    :cond_39
    const/4 v5, 0x0

    :goto_3a
    and-int/2addr v10, v8

    int-to-long v13, v10

    sget-object v10, Lpr7;->F:Lpr7;

    iget v10, v10, Lpr7;->E:I

    if-lt v11, v10, :cond_46

    sget-object v10, Lpr7;->G:Lpr7;

    iget v10, v10, Lpr7;->E:I

    :cond_46
    const/16 v10, 0x3f

    packed-switch v11, :pswitch_data_6dc

    goto/16 :goto_6c8

    :pswitch_4d  #0x44
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v10

    sget-object v11, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v11

    mul-int/lit8 v11, v11, 0x2

    invoke-virtual {v5, v10}, Landroidx/datastore/preferences/protobuf/a;->a(Ldyf;)I

    move-result v5

    add-int/2addr v5, v11

    :goto_6a
    add-int/2addr v9, v5

    goto/16 :goto_6c8

    :pswitch_6d  #0x43
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v13, v14, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v13

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    shl-long v11, v13, v15

    shr-long/2addr v13, v10

    xor-long v10, v11, v13

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v10

    :goto_84
    add-int/2addr v10, v5

    :goto_85
    add-int/2addr v9, v10

    goto/16 :goto_6c8

    :pswitch_88  #0x42
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v13, v14, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1

    shr-int/lit8 v5, v5, 0x1f

    xor-int/2addr v5, v11

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v5

    :goto_9f
    add-int/2addr v5, v10

    goto :goto_6a

    :pswitch_a1  #0x41
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    :goto_ab
    add-int/lit8 v5, v5, 0x8

    goto :goto_6a

    :pswitch_ae  #0x40
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    :goto_b8
    add-int/lit8 v5, v5, 0x4

    goto :goto_6a

    :pswitch_bb  #0x3f
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v13, v14, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    int-to-long v11, v5

    invoke-static {v11, v12}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v5

    goto :goto_9f

    :pswitch_cf  #0x3e
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v13, v14, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v5

    goto :goto_9f

    :pswitch_e2  #0x3d
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lk92;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/e;->f(ILk92;)I

    move-result v5

    goto/16 :goto_6a

    :pswitch_f4  #0x3c
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v10

    sget-object v11, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    check-cast v5, Landroidx/datastore/preferences/protobuf/a;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v11

    invoke-virtual {v5, v10}, Landroidx/datastore/preferences/protobuf/a;->a(Ldyf;)I

    move-result v5

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    add-int/2addr v10, v5

    add-int/2addr v10, v11

    goto/16 :goto_85

    :pswitch_116  #0x3b
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    instance-of v10, v5, Lk92;

    if-eqz v10, :cond_12e

    check-cast v5, Lk92;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/e;->f(ILk92;)I

    move-result v5

    :goto_12a
    add-int/2addr v5, v9

    move v9, v5

    goto/16 :goto_6c8

    :cond_12e
    check-cast v5, Ljava/lang/String;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->g(Ljava/lang/String;)I

    move-result v5

    add-int/2addr v5, v10

    goto :goto_12a

    :pswitch_13a  #0x3a
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    add-int/2addr v5, v15

    goto/16 :goto_6a

    :pswitch_147  #0x39
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_b8

    :pswitch_153  #0x38
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_ab

    :pswitch_15f  #0x37
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v13, v14, v1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    int-to-long v11, v5

    invoke-static {v11, v12}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v5

    goto/16 :goto_9f

    :pswitch_174  #0x36
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v13, v14, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v10

    goto/16 :goto_84

    :pswitch_188  #0x35
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v13, v14, v1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v10

    goto/16 :goto_84

    :pswitch_19c  #0x34
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_b8

    :pswitch_1a8  #0x33
    invoke-virtual {v0, v12, v1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_ab

    :pswitch_1b4  #0x32
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    div-int/lit8 v10, v2, 0x3

    mul-int/lit8 v10, v10, 0x2

    iget-object v11, v0, Landroidx/datastore/preferences/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v10, v11, v10

    iget-object v11, v0, Landroidx/datastore/preferences/protobuf/h;->m:Lz5b;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, Lu5b;

    check-cast v10, Lm5b;

    invoke-virtual {v5}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_1d1

    :goto_1cf
    const/4 v11, 0x0

    goto :goto_203

    :cond_1d1
    invoke-virtual {v5}, Lu5b;->entrySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    const/4 v11, 0x0

    :goto_1da
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_203

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/util/Map$Entry;

    invoke-interface {v13}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v14

    invoke-interface {v13}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v15

    iget-object v7, v10, Lm5b;->a:Lhk0;

    invoke-static {v7, v14, v13}, Lm5b;->a(Lhk0;Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v7

    invoke-static {v7}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v13

    add-int/2addr v13, v7

    add-int/2addr v13, v15

    add-int/2addr v11, v13

    goto :goto_1da

    :cond_203
    :goto_203
    add-int/2addr v9, v11

    goto/16 :goto_6c8

    :pswitch_206  #0x31
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v7

    sget-object v10, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_21a

    const/4 v13, 0x0

    goto :goto_233

    :cond_21a
    const/4 v11, 0x0

    const/4 v13, 0x0

    :goto_21c
    if-ge v11, v10, :cond_233

    invoke-interface {v5, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/datastore/preferences/protobuf/a;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v15

    mul-int/lit8 v15, v15, 0x2

    invoke-virtual {v14, v7}, Landroidx/datastore/preferences/protobuf/a;->a(Ldyf;)I

    move-result v14

    add-int/2addr v14, v15

    add-int/2addr v13, v14

    add-int/lit8 v11, v11, 0x1

    goto :goto_21c

    :cond_233
    :goto_233
    add-int/2addr v9, v13

    goto/16 :goto_6c8

    :pswitch_236  #0x30
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->g(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    :goto_24a
    add-int/2addr v10, v7

    goto/16 :goto_84

    :pswitch_24d  #0x2f
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->f(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto :goto_24a

    :pswitch_262  #0x2e
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto :goto_24a

    :pswitch_27b  #0x2d
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto :goto_24a

    :pswitch_294  #0x2c
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->a(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto :goto_24a

    :pswitch_2a9  #0x2b
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->h(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto :goto_24a

    :pswitch_2be  #0x2a
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_2d6  #0x29
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_2f0  #0x28
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_30a  #0x27
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->d(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_320  #0x26
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->i(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_336  #0x25
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->e(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_34c  #0x24
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_366  #0x23
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_24a

    :pswitch_380  #0x22
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_390

    :goto_38e
    const/4 v10, 0x0

    goto :goto_39a

    :cond_390
    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->g(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    :goto_398
    mul-int/2addr v10, v7

    add-int/2addr v10, v5

    :cond_39a
    :goto_39a
    add-int/2addr v9, v10

    goto/16 :goto_6c8

    :pswitch_39d  #0x21
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_3ac

    goto :goto_38e

    :cond_3ac
    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->f(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    goto :goto_398

    :pswitch_3b5  #0x20
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/j;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_6a

    :pswitch_3c1  #0x1f
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/j;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_6a

    :pswitch_3cd  #0x1e
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_3dc

    goto :goto_38e

    :cond_3dc
    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->a(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    goto :goto_398

    :pswitch_3e5  #0x1d
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_3f4

    goto :goto_38e

    :cond_3f4
    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->h(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    goto :goto_398

    :pswitch_3fd  #0x1c
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_40c

    goto :goto_38e

    :cond_40c
    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    mul-int/2addr v10, v7

    const/4 v7, 0x0

    :goto_412
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    if-ge v7, v11, :cond_39a

    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lk92;

    invoke-virtual {v11}, Lk92;->size()I

    move-result v11

    invoke-static {v11}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v12

    add-int/2addr v12, v11

    add-int/2addr v10, v12

    add-int/lit8 v7, v7, 0x1

    goto :goto_412

    :pswitch_42b  #0x1b
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v7

    sget-object v10, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_43f

    goto/16 :goto_1cf

    :cond_43f
    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v11

    mul-int/2addr v11, v10

    const/4 v12, 0x0

    :goto_445
    if-ge v12, v10, :cond_203

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v13, v7}, Landroidx/datastore/preferences/protobuf/a;->a(Ldyf;)I

    move-result v13

    invoke-static {v13}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v14

    add-int/2addr v14, v13

    add-int/2addr v11, v14

    add-int/lit8 v12, v12, 0x1

    goto :goto_445

    :pswitch_45a  #0x1a
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_46a

    goto/16 :goto_38e

    :cond_46a
    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    mul-int/2addr v10, v7

    instance-of v11, v5, Lpea;

    if-eqz v11, :cond_499

    check-cast v5, Lpea;

    const/4 v11, 0x0

    :goto_476
    if-ge v11, v7, :cond_39a

    invoke-interface {v5}, Lpea;->f()Ljava/lang/Object;

    move-result-object v12

    instance-of v13, v12, Lk92;

    if-eqz v13, :cond_48e

    check-cast v12, Lk92;

    invoke-virtual {v12}, Lk92;->size()I

    move-result v12

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v13

    add-int/2addr v13, v12

    add-int/2addr v13, v10

    move v10, v13

    goto :goto_496

    :cond_48e
    check-cast v12, Ljava/lang/String;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->g(Ljava/lang/String;)I

    move-result v12

    add-int/2addr v12, v10

    move v10, v12

    :goto_496
    add-int/lit8 v11, v11, 0x1

    goto :goto_476

    :cond_499
    const/4 v11, 0x0

    :goto_49a
    if-ge v11, v7, :cond_39a

    invoke-interface {v5, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    instance-of v13, v12, Lk92;

    if-eqz v13, :cond_4b2

    check-cast v12, Lk92;

    invoke-virtual {v12}, Lk92;->size()I

    move-result v12

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v13

    add-int/2addr v13, v12

    add-int/2addr v13, v10

    move v10, v13

    goto :goto_4ba

    :cond_4b2
    check-cast v12, Ljava/lang/String;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->g(Ljava/lang/String;)I

    move-result v12

    add-int/2addr v12, v10

    move v10, v12

    :goto_4ba
    add-int/lit8 v11, v11, 0x1

    goto :goto_49a

    :pswitch_4bd  #0x19
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-nez v5, :cond_4cd

    const/4 v7, 0x0

    goto :goto_4d3

    :cond_4cd
    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v7

    add-int/2addr v7, v15

    mul-int/2addr v7, v5

    :goto_4d3
    add-int/2addr v9, v7

    goto/16 :goto_6c8

    :pswitch_4d6  #0x18
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/j;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_6a

    :pswitch_4e2  #0x17
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/j;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_6a

    :pswitch_4ee  #0x16
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_4fe

    goto/16 :goto_38e

    :cond_4fe
    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->d(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    goto/16 :goto_398

    :pswitch_508  #0x15
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_518

    goto/16 :goto_38e

    :cond_518
    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->i(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    goto/16 :goto_398

    :pswitch_522  #0x14
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_532

    goto/16 :goto_38e

    :cond_532
    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/j;->e(Ljava/util/List;)I

    move-result v7

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    mul-int/2addr v10, v5

    add-int/2addr v10, v7

    goto/16 :goto_39a

    :pswitch_542  #0x13
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/j;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_6a

    :pswitch_54e  #0x12
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/datastore/preferences/protobuf/j;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_6a

    :pswitch_55a  #0x11
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/datastore/preferences/protobuf/a;

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v7

    sget-object v10, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    mul-int/lit8 v10, v10, 0x2

    invoke-virtual {v5, v7}, Landroidx/datastore/preferences/protobuf/a;->a(Ldyf;)I

    move-result v5

    goto/16 :goto_9f

    :pswitch_578  #0x10
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v13

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    shl-long v11, v13, v15

    shr-long/2addr v13, v10

    xor-long v10, v11, v13

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v5

    :goto_58f
    add-int/2addr v5, v0

    add-int/2addr v9, v5

    :cond_591
    :goto_591
    move-object/from16 v0, p0

    goto/16 :goto_6c8

    :pswitch_595  #0xf
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    shl-int/lit8 v7, v0, 0x1

    shr-int/lit8 v0, v0, 0x1f

    xor-int/2addr v0, v7

    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v0

    :goto_5ac
    add-int/2addr v0, v5

    :goto_5ad
    add-int/2addr v9, v0

    goto :goto_591

    :pswitch_5af  #0xe
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5bc

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    :goto_5b9
    add-int/lit8 v0, v0, 0x8

    :goto_5bb
    add-int/2addr v9, v0

    :cond_5bc
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    goto/16 :goto_6c8

    :pswitch_5c2  #0xd
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5bc

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    :goto_5cc
    add-int/lit8 v0, v0, 0x4

    goto :goto_5bb

    :pswitch_5cf  #0xc
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    int-to-long v10, v0

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v0

    goto :goto_5ac

    :pswitch_5e3  #0xb
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v0

    goto :goto_5ac

    :pswitch_5f6  #0xa
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lk92;

    invoke-static {v12, v0}, Landroidx/datastore/preferences/protobuf/e;->f(ILk92;)I

    move-result v0

    goto :goto_5ad

    :pswitch_607  #0x9
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v7

    sget-object v10, Landroidx/datastore/preferences/protobuf/j;->a:Ljava/lang/Class;

    check-cast v5, Landroidx/datastore/preferences/protobuf/a;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v10

    invoke-virtual {v5, v7}, Landroidx/datastore/preferences/protobuf/a;->a(Ldyf;)I

    move-result v5

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/e;->i(I)I

    move-result v7

    add-int/2addr v7, v5

    add-int/2addr v7, v10

    add-int/2addr v9, v7

    goto/16 :goto_6c8

    :pswitch_62a  #0x8
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    instance-of v5, v0, Lk92;

    if-eqz v5, :cond_642

    check-cast v0, Lk92;

    invoke-static {v12, v0}, Landroidx/datastore/preferences/protobuf/e;->f(ILk92;)I

    move-result v0

    :goto_63e
    add-int/2addr v0, v9

    move v9, v0

    goto/16 :goto_591

    :cond_642
    check-cast v0, Ljava/lang/String;

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/e;->g(Ljava/lang/String;)I

    move-result v0

    add-int/2addr v0, v5

    goto :goto_63e

    :pswitch_64e  #0x7
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5bc

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    add-int/2addr v0, v15

    goto/16 :goto_5bb

    :pswitch_65b  #0x6
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5bc

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    goto/16 :goto_5cc

    :pswitch_667  #0x5
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5bc

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    goto/16 :goto_5b9

    :pswitch_673  #0x4
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    int-to-long v10, v0

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v0

    goto/16 :goto_5ac

    :pswitch_688  #0x3
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v5

    goto/16 :goto_58f

    :pswitch_69c  #0x2
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_591

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    invoke-static {v10, v11}, Landroidx/datastore/preferences/protobuf/e;->j(J)I

    move-result v5

    goto/16 :goto_58f

    :pswitch_6b0  #0x1
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5bc

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v0

    goto/16 :goto_5cc

    :pswitch_6bc  #0x0
    invoke-virtual/range {v0 .. v5}, Landroidx/datastore/preferences/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6c8

    invoke-static {v12}, Landroidx/datastore/preferences/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_ab

    :cond_6c8
    :goto_6c8
    add-int/lit8 v2, v2, 0x3

    goto/16 :goto_d

    :cond_6cc
    iget-object v0, v0, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    check-cast v0, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v1, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/l;->b()I

    move-result v0

    add-int/2addr v0, v9

    return v0

    nop

    :pswitch_data_6dc
    .packed-switch 0x0
        :pswitch_6bc  #00000000
        :pswitch_6b0  #00000001
        :pswitch_69c  #00000002
        :pswitch_688  #00000003
        :pswitch_673  #00000004
        :pswitch_667  #00000005
        :pswitch_65b  #00000006
        :pswitch_64e  #00000007
        :pswitch_62a  #00000008
        :pswitch_607  #00000009
        :pswitch_5f6  #0000000a
        :pswitch_5e3  #0000000b
        :pswitch_5cf  #0000000c
        :pswitch_5c2  #0000000d
        :pswitch_5af  #0000000e
        :pswitch_595  #0000000f
        :pswitch_578  #00000010
        :pswitch_55a  #00000011
        :pswitch_54e  #00000012
        :pswitch_542  #00000013
        :pswitch_522  #00000014
        :pswitch_508  #00000015
        :pswitch_4ee  #00000016
        :pswitch_4e2  #00000017
        :pswitch_4d6  #00000018
        :pswitch_4bd  #00000019
        :pswitch_45a  #0000001a
        :pswitch_42b  #0000001b
        :pswitch_3fd  #0000001c
        :pswitch_3e5  #0000001d
        :pswitch_3cd  #0000001e
        :pswitch_3c1  #0000001f
        :pswitch_3b5  #00000020
        :pswitch_39d  #00000021
        :pswitch_380  #00000022
        :pswitch_366  #00000023
        :pswitch_34c  #00000024
        :pswitch_336  #00000025
        :pswitch_320  #00000026
        :pswitch_30a  #00000027
        :pswitch_2f0  #00000028
        :pswitch_2d6  #00000029
        :pswitch_2be  #0000002a
        :pswitch_2a9  #0000002b
        :pswitch_294  #0000002c
        :pswitch_27b  #0000002d
        :pswitch_262  #0000002e
        :pswitch_24d  #0000002f
        :pswitch_236  #00000030
        :pswitch_206  #00000031
        :pswitch_1b4  #00000032
        :pswitch_1a8  #00000033
        :pswitch_19c  #00000034
        :pswitch_188  #00000035
        :pswitch_174  #00000036
        :pswitch_15f  #00000037
        :pswitch_153  #00000038
        :pswitch_147  #00000039
        :pswitch_13a  #0000003a
        :pswitch_116  #0000003b
        :pswitch_f4  #0000003c
        :pswitch_e2  #0000003d
        :pswitch_cf  #0000003e
        :pswitch_bb  #0000003f
        :pswitch_ae  #00000040
        :pswitch_a1  #00000041
        :pswitch_88  #00000042
        :pswitch_6d  #00000043
        :pswitch_4d  #00000044
    .end packed-switch
.end method

.method public final g(Landroidx/datastore/preferences/protobuf/f;)I
    .registers 13

    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_5
    if-ge v2, v1, :cond_27c

    invoke-virtual {p0, v2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v4

    aget v5, v0, v2

    const v6, 0xfffff

    and-int/2addr v6, v4

    int-to-long v6, v6

    invoke-static {v4}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v4

    const/16 v8, 0x4d5

    const/16 v9, 0x4cf

    const/16 v10, 0x25

    packed-switch v4, :pswitch_data_28e

    goto/16 :goto_278

    :pswitch_21  #0x44
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    mul-int/lit8 v3, v3, 0x35

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    :goto_33
    add-int/2addr v4, v3

    move v3, v4

    goto/16 :goto_278

    :pswitch_37  #0x43
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto :goto_33

    :pswitch_48  #0x42
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_55  #0x41
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto :goto_33

    :pswitch_66  #0x40
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_73  #0x3f
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_80  #0x3e
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_8d  #0x3d
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto :goto_33

    :pswitch_a0  #0x3c
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    mul-int/lit8 v3, v3, 0x35

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto :goto_33

    :pswitch_b3  #0x3b
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_c9  #0x3a
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    sget-object v5, Lll9;->a:Ljava/nio/charset/Charset;

    if-eqz v4, :cond_e2

    :goto_e1
    move v8, v9

    :cond_e2
    add-int/2addr v8, v3

    move v3, v8

    goto/16 :goto_278

    :pswitch_e6  #0x39
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_f4  #0x38
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_106  #0x37
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_114  #0x36
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_126  #0x35
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/datastore/preferences/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_138  #0x34
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Float;

    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v4

    goto/16 :goto_33

    :pswitch_152  #0x33
    invoke-virtual {p0, v5, p1, v2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Double;

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_170  #0x32
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_17e  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_18c  #0x11
    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_198

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v10

    :cond_198
    :goto_198
    mul-int/lit8 v3, v3, 0x35

    add-int/2addr v3, v10

    goto/16 :goto_278

    :pswitch_19d  #0x10
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1ab  #0xf
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1b5  #0xe
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1c3  #0xd
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1cd  #0xc
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1d7  #0xb
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1e1  #0xa
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_1ef  #0x9
    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_198

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v10

    goto :goto_198

    :pswitch_1fc  #0x8
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_20c  #0x7
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->c(JLjava/lang/Object;)Z

    move-result v4

    sget-object v5, Lll9;->a:Ljava/nio/charset/Charset;

    if-eqz v4, :cond_e2

    goto/16 :goto_e1

    :pswitch_21a  #0x6
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_224  #0x5
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_232  #0x4
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_23c  #0x3
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_24a  #0x2
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_258  #0x1
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->e(JLjava/lang/Object;)F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v4

    goto/16 :goto_33

    :pswitch_266  #0x0
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v6, v7, p1}, Lh5j;->d(JLjava/lang/Object;)D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    invoke-static {v4, v5}, Lll9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :cond_278
    :goto_278
    add-int/lit8 v2, v2, 0x3

    goto/16 :goto_5

    :cond_27c
    mul-int/lit8 v3, v3, 0x35

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    check-cast p0, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p1, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/l;->hashCode()I

    move-result p0

    add-int/2addr p0, v3

    return p0

    nop

    :pswitch_data_28e
    .packed-switch 0x0
        :pswitch_266  #00000000
        :pswitch_258  #00000001
        :pswitch_24a  #00000002
        :pswitch_23c  #00000003
        :pswitch_232  #00000004
        :pswitch_224  #00000005
        :pswitch_21a  #00000006
        :pswitch_20c  #00000007
        :pswitch_1fc  #00000008
        :pswitch_1ef  #00000009
        :pswitch_1e1  #0000000a
        :pswitch_1d7  #0000000b
        :pswitch_1cd  #0000000c
        :pswitch_1c3  #0000000d
        :pswitch_1b5  #0000000e
        :pswitch_1ab  #0000000f
        :pswitch_19d  #00000010
        :pswitch_18c  #00000011
        :pswitch_17e  #00000012
        :pswitch_17e  #00000013
        :pswitch_17e  #00000014
        :pswitch_17e  #00000015
        :pswitch_17e  #00000016
        :pswitch_17e  #00000017
        :pswitch_17e  #00000018
        :pswitch_17e  #00000019
        :pswitch_17e  #0000001a
        :pswitch_17e  #0000001b
        :pswitch_17e  #0000001c
        :pswitch_17e  #0000001d
        :pswitch_17e  #0000001e
        :pswitch_17e  #0000001f
        :pswitch_17e  #00000020
        :pswitch_17e  #00000021
        :pswitch_17e  #00000022
        :pswitch_17e  #00000023
        :pswitch_17e  #00000024
        :pswitch_17e  #00000025
        :pswitch_17e  #00000026
        :pswitch_17e  #00000027
        :pswitch_17e  #00000028
        :pswitch_17e  #00000029
        :pswitch_17e  #0000002a
        :pswitch_17e  #0000002b
        :pswitch_17e  #0000002c
        :pswitch_17e  #0000002d
        :pswitch_17e  #0000002e
        :pswitch_17e  #0000002f
        :pswitch_17e  #00000030
        :pswitch_17e  #00000031
        :pswitch_170  #00000032
        :pswitch_152  #00000033
        :pswitch_138  #00000034
        :pswitch_126  #00000035
        :pswitch_114  #00000036
        :pswitch_106  #00000037
        :pswitch_f4  #00000038
        :pswitch_e6  #00000039
        :pswitch_c9  #0000003a
        :pswitch_b3  #0000003b
        :pswitch_a0  #0000003c
        :pswitch_8d  #0000003d
        :pswitch_80  #0000003e
        :pswitch_73  #0000003f
        :pswitch_66  #00000040
        :pswitch_55  #00000041
        :pswitch_48  #00000042
        :pswitch_37  #00000043
        :pswitch_21  #00000044
    .end packed-switch
.end method

.method public final h(Ljava/lang/Object;Lxs5;)V
    .registers 3

    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/h;->M(Ljava/lang/Object;Lxs5;)V

    return-void
.end method

.method public final i(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;)Z
    .registers 14

    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_5
    const/4 v4, 0x1

    if-ge v3, v1, :cond_1f5

    invoke-virtual {p0, v3}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v5

    const v6, 0xfffff

    and-int v7, v5, v6

    int-to-long v7, v7

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result v5

    packed-switch v5, :pswitch_data_20c

    goto/16 :goto_1ee

    :pswitch_1b  #0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43, 0x44
    add-int/lit8 v5, v3, 0x2

    aget v5, v0, v5

    and-int/2addr v5, v6

    int-to-long v5, v5

    sget-object v9, Lm5j;->c:Lh5j;

    invoke-virtual {v9, v5, v6, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v10

    invoke-virtual {v9, v5, v6, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v10, v5, :cond_3d

    invoke-virtual {v9, v7, v8, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v9, v7, v8, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5, v6}, Landroidx/datastore/preferences/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :cond_3d
    move v4, v2

    goto/16 :goto_1ee

    :pswitch_40  #0x32
    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v7, v8, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v7, v8, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v5, v4}, Landroidx/datastore/preferences/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_1ee

    :pswitch_50  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    sget-object v4, Lm5j;->c:Lh5j;

    invoke-virtual {v4, v7, v8, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v7, v8, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v5, v4}, Landroidx/datastore/preferences/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_1ee

    :pswitch_60  #0x11
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/datastore/preferences/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_78  #0x10
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_8e  #0xf
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_a2  #0xe
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_b8  #0xd
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_cc  #0xc
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_e0  #0xb
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_f4  #0xa
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/datastore/preferences/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_10c  #0x9
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/datastore/preferences/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_124  #0x8
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/datastore/preferences/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_13c  #0x7
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->c(JLjava/lang/Object;)Z

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->c(JLjava/lang/Object;)Z

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_150  #0x6
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_164  #0x5
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_17a  #0x4
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto :goto_1ee

    :pswitch_18d  #0x3
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto :goto_1ee

    :pswitch_1a2  #0x2
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto :goto_1ee

    :pswitch_1b7  #0x1
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->e(JLjava/lang/Object;)F

    move-result v6

    invoke-static {v6}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->e(JLjava/lang/Object;)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto :goto_1ee

    :pswitch_1d2  #0x0
    invoke-virtual {p0, p1, p2, v3}, Landroidx/datastore/preferences/protobuf/h;->j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lm5j;->c:Lh5j;

    invoke-virtual {v5, v7, v8, p1}, Lh5j;->d(JLjava/lang/Object;)D

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Lh5j;->d(JLjava/lang/Object;)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    :goto_1ee
    if-nez v4, :cond_1f1

    goto :goto_209

    :cond_1f1
    add-int/lit8 v3, v3, 0x3

    goto/16 :goto_5

    :cond_1f5
    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->l:Landroidx/datastore/preferences/protobuf/k;

    check-cast p0, Landroidx/datastore/preferences/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p2, Landroidx/datastore/preferences/protobuf/f;->unknownFields:Landroidx/datastore/preferences/protobuf/l;

    invoke-virtual {p1, p0}, Landroidx/datastore/preferences/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_20a

    :goto_209
    return v2

    :cond_20a
    return v4

    nop

    :pswitch_data_20c
    .packed-switch 0x0
        :pswitch_1d2  #00000000
        :pswitch_1b7  #00000001
        :pswitch_1a2  #00000002
        :pswitch_18d  #00000003
        :pswitch_17a  #00000004
        :pswitch_164  #00000005
        :pswitch_150  #00000006
        :pswitch_13c  #00000007
        :pswitch_124  #00000008
        :pswitch_10c  #00000009
        :pswitch_f4  #0000000a
        :pswitch_e0  #0000000b
        :pswitch_cc  #0000000c
        :pswitch_b8  #0000000d
        :pswitch_a2  #0000000e
        :pswitch_8e  #0000000f
        :pswitch_78  #00000010
        :pswitch_60  #00000011
        :pswitch_50  #00000012
        :pswitch_50  #00000013
        :pswitch_50  #00000014
        :pswitch_50  #00000015
        :pswitch_50  #00000016
        :pswitch_50  #00000017
        :pswitch_50  #00000018
        :pswitch_50  #00000019
        :pswitch_50  #0000001a
        :pswitch_50  #0000001b
        :pswitch_50  #0000001c
        :pswitch_50  #0000001d
        :pswitch_50  #0000001e
        :pswitch_50  #0000001f
        :pswitch_50  #00000020
        :pswitch_50  #00000021
        :pswitch_50  #00000022
        :pswitch_50  #00000023
        :pswitch_50  #00000024
        :pswitch_50  #00000025
        :pswitch_50  #00000026
        :pswitch_50  #00000027
        :pswitch_50  #00000028
        :pswitch_50  #00000029
        :pswitch_50  #0000002a
        :pswitch_50  #0000002b
        :pswitch_50  #0000002c
        :pswitch_50  #0000002d
        :pswitch_50  #0000002e
        :pswitch_50  #0000002f
        :pswitch_50  #00000030
        :pswitch_50  #00000031
        :pswitch_40  #00000032
        :pswitch_1b  #00000033
        :pswitch_1b  #00000034
        :pswitch_1b  #00000035
        :pswitch_1b  #00000036
        :pswitch_1b  #00000037
        :pswitch_1b  #00000038
        :pswitch_1b  #00000039
        :pswitch_1b  #0000003a
        :pswitch_1b  #0000003b
        :pswitch_1b  #0000003c
        :pswitch_1b  #0000003d
        :pswitch_1b  #0000003e
        :pswitch_1b  #0000003f
        :pswitch_1b  #00000040
        :pswitch_1b  #00000041
        :pswitch_1b  #00000042
        :pswitch_1b  #00000043
        :pswitch_1b  #00000044
    .end packed-switch
.end method

.method public final j(Landroidx/datastore/preferences/protobuf/f;Landroidx/datastore/preferences/protobuf/f;I)Z
    .registers 4

    invoke-virtual {p0, p3, p1}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p1

    invoke-virtual {p0, p3, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p0

    if-ne p1, p0, :cond_c

    const/4 p0, 0x1

    return p0

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method public final k(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 6

    iget-object p3, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget p3, p3, p2

    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result p3

    const v0, 0xfffff

    and-int/2addr p3, v0

    int-to-long v0, p3

    sget-object p3, Lm5j;->c:Lh5j;

    invoke-virtual {p3, v0, v1, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-nez p1, :cond_16

    return-void

    :cond_16
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->l(I)V

    return-void
.end method

.method public final l(I)V
    .registers 5

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1, v2, v0, v1}, Lti6;->e(IIII)I

    move-result p1

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->b:[Ljava/lang/Object;

    aget-object p0, p0, p1

    if-nez p0, :cond_e

    return-void

    :cond_e
    invoke-static {}, Lty9;->a()V

    return-void
.end method

.method public final m(I)Ldyf;
    .registers 4

    div-int/lit8 p1, p1, 0x3

    mul-int/lit8 p1, p1, 0x2

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v0, p0, p1

    check-cast v0, Ldyf;

    if-eqz v0, :cond_d

    return-object v0

    :cond_d
    sget-object v0, Lqfe;->c:Lqfe;

    add-int/lit8 v1, p1, 0x1

    aget-object v1, p0, v1

    check-cast v1, Ljava/lang/Class;

    invoke-virtual {v0, v1}, Lqfe;->a(Ljava/lang/Class;)Ldyf;

    move-result-object v0

    aput-object v0, p0, p1

    return-object v0
.end method

.method public final n(ILjava/lang/Object;)Z
    .registers 10

    add-int/lit8 v0, p1, 0x2

    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget v0, v1, v0

    const v1, 0xfffff

    and-int v2, v0, v1

    int-to-long v2, v2

    const-wide/32 v4, 0xfffff

    cmp-long v4, v2, v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v4, :cond_103

    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result p0

    and-int p1, p0, v1

    int-to-long v0, p1

    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/h;->K(I)I

    move-result p0

    const-wide/16 v2, 0x0

    packed-switch p0, :pswitch_data_112

    invoke-static {}, Lty9;->y()V

    return v5

    :pswitch_29  #0x11
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_33  #0x10
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_3f  #0xf
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_49  #0xe
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_55  #0xd
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_5f  #0xc
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_69  #0xb
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_73  #0xa
    sget-object p0, Lk92;->G:Lk92;

    sget-object p1, Lm5j;->c:Lh5j;

    invoke-virtual {p1, v0, v1, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p0, p1}, Lk92;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :pswitch_81  #0x9
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_8b  #0x8
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_9d

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :cond_9d
    instance-of p1, p0, Lk92;

    if-eqz p1, :cond_a9

    sget-object p1, Lk92;->G:Lk92;

    invoke-virtual {p1, p0}, Lk92;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :cond_a9
    invoke-static {}, Lty9;->y()V

    return v5

    :pswitch_ad  #0x7
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->c(JLjava/lang/Object;)Z

    move-result p0

    return p0

    :pswitch_b4  #0x6
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_bd  #0x5
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_c8  #0x4
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_d1  #0x3
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_dc  #0x2
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_e7  #0x1
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->e(JLjava/lang/Object;)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_f4  #0x0
    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->d(JLjava/lang/Object;)D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :cond_103
    ushr-int/lit8 p0, v0, 0x14

    shl-int p0, v6, p0

    sget-object p1, Lm5j;->c:Lh5j;

    invoke-virtual {p1, v2, v3, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p1

    and-int/2addr p0, p1

    if-eqz p0, :cond_111

    :goto_110
    return v6

    :cond_111
    return v5

    :pswitch_data_112
    .packed-switch 0x0
        :pswitch_f4  #00000000
        :pswitch_e7  #00000001
        :pswitch_dc  #00000002
        :pswitch_d1  #00000003
        :pswitch_c8  #00000004
        :pswitch_bd  #00000005
        :pswitch_b4  #00000006
        :pswitch_ad  #00000007
        :pswitch_8b  #00000008
        :pswitch_81  #00000009
        :pswitch_73  #0000000a
        :pswitch_69  #0000000b
        :pswitch_5f  #0000000c
        :pswitch_55  #0000000d
        :pswitch_49  #0000000e
        :pswitch_3f  #0000000f
        :pswitch_33  #00000010
        :pswitch_29  #00000011
    .end packed-switch
.end method

.method public final o(Ljava/lang/Object;IIII)Z
    .registers 7

    const v0, 0xfffff

    if-ne p3, v0, :cond_a

    invoke-virtual {p0, p2, p1}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p0

    return p0

    :cond_a
    and-int p0, p4, p5

    if-eqz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method public final q(ILjava/lang/Object;I)Z
    .registers 6

    add-int/lit8 p3, p3, 0x2

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget p0, p0, p3

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v0, p0

    sget-object p0, Lm5j;->c:Lh5j;

    invoke-virtual {p0, v0, v1, p2}, Lh5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-ne p0, p1, :cond_15

    const/4 p0, 0x1

    return p0

    :cond_15
    const/4 p0, 0x0

    return p0
.end method

.method public final r(Ljava/lang/Object;ILjava/lang/Object;Lkm7;Landroidx/datastore/preferences/protobuf/d;)V
    .registers 13

    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result p2

    const v0, 0xfffff

    and-int/2addr p2, v0

    int-to-long v0, p2

    sget-object p2, Lm5j;->c:Lh5j;

    invoke-virtual {p2, v0, v1, p1}, Lh5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->m:Lz5b;

    if-nez p2, :cond_20

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Lu5b;->F:Lu5b;

    invoke-virtual {p2}, Lu5b;->c()Lu5b;

    move-result-object p2

    invoke-static {v0, v1, p1, p2}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    goto :goto_3a

    :cond_20
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v2, p2

    check-cast v2, Lu5b;

    iget-boolean v2, v2, Lu5b;->E:Z

    if-nez v2, :cond_3a

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lu5b;->F:Lu5b;

    invoke-virtual {v2}, Lu5b;->c()Lu5b;

    move-result-object v2

    invoke-virtual {p0, v2, p2}, Lz5b;->a(Ljava/lang/Object;Ljava/lang/Object;)Lu5b;

    invoke-static {v0, v1, p1, v2}, Lm5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    move-object p2, v2

    :cond_3a
    :goto_3a
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lu5b;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p3, Lm5b;

    iget-object p0, p3, Lm5b;->a:Lhk0;

    const/4 p1, 0x2

    invoke-virtual {p5, p1}, Landroidx/datastore/preferences/protobuf/d;->w(I)V

    iget-object p3, p5, Landroidx/datastore/preferences/protobuf/d;->a:Lnl4;

    invoke-virtual {p3}, Lnl4;->v()I

    move-result v0

    invoke-virtual {p3, v0}, Lnl4;->e(I)I

    move-result v0

    iget-object v1, p0, Lhk0;->G:Ljava/lang/Object;

    const-string v2, ""

    move-object v3, v1

    :goto_59
    :try_start_59
    invoke-virtual {p5}, Landroidx/datastore/preferences/protobuf/d;->a()I

    move-result v4

    const v5, 0x7fffffff

    if-eq v4, v5, :cond_a5

    invoke-virtual {p3}, Lnl4;->c()Z

    move-result v5
    :try_end_66
    .catchall {:try_start_59 .. :try_end_66} :catchall_7d

    if-eqz v5, :cond_69

    goto :goto_a5

    :cond_69
    const/4 v5, 0x1

    const-string v6, "Unable to parse map entry."

    if-eq v4, v5, :cond_8e

    if-eq v4, p1, :cond_81

    :try_start_70
    invoke-virtual {p5}, Landroidx/datastore/preferences/protobuf/d;->x()Z

    move-result v4

    if-eqz v4, :cond_77

    goto :goto_59

    :cond_77
    new-instance v4, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    invoke-direct {v4, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v4

    :catchall_7d
    move-exception p0

    goto :goto_ac

    :catch_7f
    move-exception v4

    goto :goto_98

    :cond_81
    iget-object v4, p0, Lhk0;->F:Ljava/lang/Object;

    check-cast v4, Lx5k;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {p5, v4, v5, p4}, Landroidx/datastore/preferences/protobuf/d;->i(Lx5k;Ljava/lang/Class;Lkm7;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_59

    :cond_8e
    iget-object v4, p0, Lhk0;->E:Ljava/lang/Object;

    check-cast v4, Lx5k;

    const/4 v5, 0x0

    invoke-virtual {p5, v4, v5, v5}, Landroidx/datastore/preferences/protobuf/d;->i(Lx5k;Ljava/lang/Class;Lkm7;)Ljava/lang/Object;

    move-result-object v2
    :try_end_97
    .catch Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_70 .. :try_end_97} :catch_7f
    .catchall {:try_start_70 .. :try_end_97} :catchall_7d

    goto :goto_59

    :goto_98
    :try_start_98
    invoke-virtual {p5}, Landroidx/datastore/preferences/protobuf/d;->x()Z

    move-result v5

    if-eqz v5, :cond_9f

    goto :goto_59

    :cond_9f
    new-instance p0, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    invoke-direct {p0, v6, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p0

    :cond_a5
    :goto_a5
    invoke-virtual {p2, v2, v3}, Lu5b;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_a8
    .catchall {:try_start_98 .. :try_end_a8} :catchall_7d

    invoke-virtual {p3, v0}, Lnl4;->d(I)V

    return-void

    :goto_ac
    invoke-virtual {p3, v0}, Lnl4;->d(I)V

    throw p0
.end method

.method public final s(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 9

    invoke-virtual {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v0

    const v1, 0xfffff

    and-int/2addr v0, v1

    int-to-long v0, v0

    sget-object v2, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v2, p3, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_53

    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object p3

    invoke-virtual {p0, p2, p1}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3a

    invoke-static {v3}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2c

    invoke-virtual {v2, p1, v0, v1, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_36

    :cond_2c
    invoke-interface {p3}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object v4

    invoke-interface {p3, v4, v3}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v0, v1, v4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :goto_36
    invoke-virtual {p0, p2, p1}, Landroidx/datastore/preferences/protobuf/h;->G(ILjava/lang/Object;)V

    return-void

    :cond_3a
    invoke-virtual {v2, p1, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_4f

    invoke-interface {p3}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p2

    invoke-interface {p3, p2, p0}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v0, v1, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    move-object p0, p2

    :cond_4f
    invoke-interface {p3, p0, v3}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_53
    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget p0, p0, p2

    const-string p1, " is present but null: "

    const-string p2, "Source subfield "

    invoke-static {p0, p1, p3, p2}, Lm1f;->i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final t(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 10

    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/h;->a:[I

    aget v1, v0, p2

    invoke-virtual {p0, v1, p3, p2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v2

    if-nez v2, :cond_b

    return-void

    :cond_b
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v2

    const v3, 0xfffff

    and-int/2addr v2, v3

    int-to-long v2, v2

    sget-object v4, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v4, p3, v2, v3}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    if-eqz v5, :cond_57

    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object p3

    invoke-virtual {p0, v1, p1, p2}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v0

    if-nez v0, :cond_3e

    invoke-static {v5}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_30

    invoke-virtual {v4, p1, v2, v3, v5}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_3a

    :cond_30
    invoke-interface {p3}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object v0

    invoke-interface {p3, v0, v5}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v4, p1, v2, v3, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :goto_3a
    invoke-virtual {p0, v1, p1, p2}, Landroidx/datastore/preferences/protobuf/h;->H(ILjava/lang/Object;I)V

    return-void

    :cond_3e
    invoke-virtual {v4, p1, v2, v3}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_53

    invoke-interface {p3}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p2

    invoke-interface {p3, p2, p0}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v4, p1, v2, v3, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    move-object p0, p2

    :cond_53
    invoke-interface {p3, p0, v5}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_57
    aget p0, v0, p2

    const-string p1, " is present but null: "

    const-string p2, "Source subfield "

    invoke-static {p0, p1, p3, p2}, Lm1f;->i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final u(ILjava/lang/Object;)Ljava/lang/Object;
    .registers 6

    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v0

    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_18

    invoke-interface {v0}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p0

    return-object p0

    :cond_18
    sget-object p0, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p2, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_25

    return-object p0

    :cond_25
    invoke-interface {v0}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p1

    if-eqz p0, :cond_2e

    invoke-interface {v0, p1, p0}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2e
    return-object p1
.end method

.method public final v(ILjava/lang/Object;I)Ljava/lang/Object;
    .registers 7

    invoke-virtual {p0, p3}, Landroidx/datastore/preferences/protobuf/h;->m(I)Ldyf;

    move-result-object v0

    invoke-virtual {p0, p1, p2, p3}, Landroidx/datastore/preferences/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result p1

    if-nez p1, :cond_f

    invoke-interface {v0}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p0

    return-object p0

    :cond_f
    sget-object p1, Landroidx/datastore/preferences/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p3}, Landroidx/datastore/preferences/protobuf/h;->L(I)I

    move-result p0

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v1, p0

    invoke-virtual {p1, p2, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_25

    return-object p0

    :cond_25
    invoke-interface {v0}, Ldyf;->d()Landroidx/datastore/preferences/protobuf/f;

    move-result-object p1

    if-eqz p0, :cond_2e

    invoke-interface {v0, p1, p0}, Ldyf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2e
    return-object p1
.end method
