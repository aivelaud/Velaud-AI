.class public final Landroidx/datastore/preferences/protobuf/n;
.super Lylk;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Landroidx/datastore/preferences/protobuf/n;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final C([BII)Ljava/lang/String;
    .registers 13

    iget p0, p0, Landroidx/datastore/preferences/protobuf/n;->d:I

    packed-switch p0, :pswitch_data_156

    new-instance p0, Ljava/lang/String;

    sget-object v0, Lll9;->a:Ljava/nio/charset/Charset;

    invoke-direct {p0, p1, p2, p3, v0}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const v1, 0xfffd

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    if-gez v1, :cond_16

    goto :goto_25

    :cond_16
    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    add-int/2addr p3, p2

    invoke-static {p1, p2, p3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p1

    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([B[B)Z

    move-result p1

    if-eqz p1, :cond_26

    :goto_25
    return-object p0

    :cond_26
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->a()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :pswitch_2b  #0x0
    or-int p0, p2, p3

    array-length v0, p1

    sub-int/2addr v0, p2

    sub-int/2addr v0, p3

    or-int/2addr p0, v0

    if-ltz p0, :cond_13d

    add-int p0, p2, p3

    new-array p3, p3, [C

    const/4 v0, 0x0

    move v1, v0

    :goto_39
    if-ge p2, p0, :cond_48

    aget-byte v2, p1, p2

    if-ltz v2, :cond_48

    add-int/lit8 p2, p2, 0x1

    add-int/lit8 v3, v1, 0x1

    int-to-char v2, v2

    aput-char v2, p3, v1

    move v1, v3

    goto :goto_39

    :cond_48
    :goto_48
    if-ge p2, p0, :cond_137

    add-int/lit8 v2, p2, 0x1

    aget-byte v3, p1, p2

    if-ltz v3, :cond_67

    add-int/lit8 p2, v1, 0x1

    int-to-char v3, v3

    aput-char v3, p3, v1

    :goto_55
    if-ge v2, p0, :cond_64

    aget-byte v1, p1, v2

    if-ltz v1, :cond_64

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v3, p2, 0x1

    int-to-char v1, v1

    aput-char v1, p3, p2

    move p2, v3

    goto :goto_55

    :cond_64
    move v1, p2

    move p2, v2

    goto :goto_48

    :cond_67
    const/16 v4, -0x20

    if-ge v3, v4, :cond_93

    if-ge v2, p0, :cond_8e

    add-int/lit8 p2, p2, 0x2

    aget-byte v2, p1, v2

    add-int/lit8 v4, v1, 0x1

    const/16 v5, -0x3e

    if-lt v3, v5, :cond_89

    invoke-static {v2}, Lrck;->F(B)Z

    move-result v5

    if-nez v5, :cond_89

    and-int/lit8 v3, v3, 0x1f

    shl-int/lit8 v3, v3, 0x6

    and-int/lit8 v2, v2, 0x3f

    or-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, p3, v1

    move v1, v4

    goto :goto_48

    :cond_89
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->a()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_8e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->a()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_93
    const/16 v5, -0x10

    if-ge v3, v5, :cond_d9

    add-int/lit8 v5, p0, -0x1

    if-ge v2, v5, :cond_d4

    add-int/lit8 v5, p2, 0x2

    aget-byte v2, p1, v2

    add-int/lit8 p2, p2, 0x3

    aget-byte v5, p1, v5

    add-int/lit8 v6, v1, 0x1

    invoke-static {v2}, Lrck;->F(B)Z

    move-result v7

    if-nez v7, :cond_cf

    const/16 v7, -0x60

    if-ne v3, v4, :cond_b1

    if-lt v2, v7, :cond_cf

    :cond_b1
    const/16 v4, -0x13

    if-ne v3, v4, :cond_b7

    if-ge v2, v7, :cond_cf

    :cond_b7
    invoke-static {v5}, Lrck;->F(B)Z

    move-result v4

    if-nez v4, :cond_cf

    and-int/lit8 v3, v3, 0xf

    shl-int/lit8 v3, v3, 0xc

    and-int/lit8 v2, v2, 0x3f

    shl-int/lit8 v2, v2, 0x6

    or-int/2addr v2, v3

    and-int/lit8 v3, v5, 0x3f

    or-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, p3, v1

    move v1, v6

    goto/16 :goto_48

    :cond_cf
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->a()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_d4
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->a()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_d9
    add-int/lit8 v4, p0, -0x2

    if-ge v2, v4, :cond_132

    add-int/lit8 v4, p2, 0x2

    aget-byte v2, p1, v2

    add-int/lit8 v5, p2, 0x3

    aget-byte v4, p1, v4

    add-int/lit8 p2, p2, 0x4

    aget-byte v5, p1, v5

    add-int/lit8 v6, v1, 0x1

    invoke-static {v2}, Lrck;->F(B)Z

    move-result v7

    if-nez v7, :cond_12d

    shl-int/lit8 v7, v3, 0x1c

    add-int/lit8 v8, v2, 0x70

    add-int/2addr v8, v7

    shr-int/lit8 v7, v8, 0x1e

    if-nez v7, :cond_12d

    invoke-static {v4}, Lrck;->F(B)Z

    move-result v7

    if-nez v7, :cond_12d

    invoke-static {v5}, Lrck;->F(B)Z

    move-result v7

    if-nez v7, :cond_12d

    and-int/lit8 v3, v3, 0x7

    shl-int/lit8 v3, v3, 0x12

    and-int/lit8 v2, v2, 0x3f

    shl-int/lit8 v2, v2, 0xc

    or-int/2addr v2, v3

    and-int/lit8 v3, v4, 0x3f

    shl-int/lit8 v3, v3, 0x6

    or-int/2addr v2, v3

    and-int/lit8 v3, v5, 0x3f

    or-int/2addr v2, v3

    ushr-int/lit8 v3, v2, 0xa

    const v4, 0xd7c0

    add-int/2addr v3, v4

    int-to-char v3, v3

    aput-char v3, p3, v1

    and-int/lit16 v2, v2, 0x3ff

    const v3, 0xdc00

    add-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, p3, v6

    add-int/lit8 v1, v1, 0x2

    goto/16 :goto_48

    :cond_12d
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->a()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_132
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->a()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_137
    new-instance p0, Ljava/lang/String;

    invoke-direct {p0, p3, v0, v1}, Ljava/lang/String;-><init>([CII)V

    goto :goto_154

    :cond_13d
    array-length p0, p1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    filled-new-array {p0, p1, p2}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "buffer length=%d, index=%d, size=%d"

    invoke-static {p1, p0}, Lgdg;->k(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 p0, 0x0

    :goto_154
    return-object p0

    nop

    :pswitch_data_156
    .packed-switch 0x0
        :pswitch_2b  #00000000
    .end packed-switch
.end method

.method public final F(Ljava/lang/String;[BII)I
    .registers 28

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move/from16 v2, p3

    move-object/from16 v3, p0

    move/from16 v4, p4

    iget v3, v3, Landroidx/datastore/preferences/protobuf/n;->d:I

    const/16 v5, 0x800

    const/4 v6, 0x0

    const/16 v7, 0x80

    const v8, 0xd800

    const v9, 0xdfff

    const-string v10, "Not enough space in output buffer to encode UTF-8 string"

    packed-switch v3, :pswitch_data_234

    int-to-long v11, v2

    int-to-long v13, v4

    add-long/2addr v13, v11

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    if-gt v3, v4, :cond_13f

    array-length v15, v1

    sub-int/2addr v15, v4

    if-lt v15, v2, :cond_13f

    :goto_29
    const-wide/16 v15, 0x1

    if-ge v6, v3, :cond_3c

    invoke-virtual {v0, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-ge v2, v7, :cond_3c

    add-long/2addr v15, v11

    int-to-byte v2, v2

    invoke-static {v1, v11, v12, v2}, Lm5j;->j([BJB)V

    add-int/lit8 v6, v6, 0x1

    move-wide v11, v15

    goto :goto_29

    :cond_3c
    if-ne v6, v3, :cond_41

    :cond_3e
    long-to-int v0, v11

    goto/16 :goto_13e

    :cond_41
    :goto_41
    if-ge v6, v3, :cond_3e

    invoke-virtual {v0, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-ge v2, v7, :cond_5b

    cmp-long v4, v11, v13

    if-gez v4, :cond_5b

    add-long v17, v11, v15

    int-to-byte v2, v2

    invoke-static {v1, v11, v12, v2}, Lm5j;->j([BJB)V

    move-wide/from16 p3, v15

    move-wide/from16 v11, v17

    :goto_57
    move-object/from16 v16, v10

    goto/16 :goto_fe

    :cond_5b
    const-wide/16 v17, 0x2

    if-ge v2, v5, :cond_7d

    sub-long v19, v13, v17

    cmp-long v4, v11, v19

    if-gtz v4, :cond_7d

    move v4, v6

    add-long v5, v11, v15

    move-wide/from16 p3, v15

    ushr-int/lit8 v15, v2, 0x6

    or-int/lit16 v15, v15, 0x3c0

    int-to-byte v15, v15

    invoke-static {v1, v11, v12, v15}, Lm5j;->j([BJB)V

    add-long v11, v11, v17

    and-int/lit8 v2, v2, 0x3f

    or-int/2addr v2, v7

    int-to-byte v2, v2

    invoke-static {v1, v5, v6, v2}, Lm5j;->j([BJB)V

    move v6, v4

    goto :goto_57

    :cond_7d
    move v4, v6

    move-wide/from16 p3, v15

    const-wide/16 v5, 0x3

    if-lt v2, v8, :cond_8c

    if-ge v9, v2, :cond_87

    goto :goto_8c

    :cond_87
    move-wide/from16 v19, v5

    move-object/from16 v16, v10

    goto :goto_b7

    :cond_8c
    :goto_8c
    sub-long v15, v13, v5

    cmp-long v15, v11, v15

    if-gtz v15, :cond_87

    move-wide v15, v5

    add-long v5, v11, p3

    move-wide/from16 v19, v15

    ushr-int/lit8 v15, v2, 0xc

    or-int/lit16 v15, v15, 0x1e0

    int-to-byte v15, v15

    invoke-static {v1, v11, v12, v15}, Lm5j;->j([BJB)V

    move-object/from16 v16, v10

    add-long v9, v11, v17

    ushr-int/lit8 v17, v2, 0x6

    and-int/lit8 v15, v17, 0x3f

    or-int/2addr v15, v7

    int-to-byte v15, v15

    invoke-static {v1, v5, v6, v15}, Lm5j;->j([BJB)V

    add-long v11, v11, v19

    and-int/lit8 v2, v2, 0x3f

    or-int/2addr v2, v7

    int-to-byte v2, v2

    invoke-static {v1, v9, v10, v2}, Lm5j;->j([BJB)V

    move v6, v4

    goto :goto_fe

    :goto_b7
    const-wide/16 v5, 0x4

    sub-long v9, v13, v5

    cmp-long v9, v11, v9

    if-gtz v9, :cond_11a

    add-int/lit8 v9, v4, 0x1

    if-eq v9, v3, :cond_111

    invoke-virtual {v0, v9}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v10

    if-eqz v10, :cond_10e

    invoke-static {v2, v4}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v2

    move-wide/from16 v21, v5

    add-long v5, v11, p3

    ushr-int/lit8 v4, v2, 0x12

    or-int/lit16 v4, v4, 0xf0

    int-to-byte v4, v4

    invoke-static {v1, v11, v12, v4}, Lm5j;->j([BJB)V

    move v15, v9

    add-long v8, v11, v17

    ushr-int/lit8 v4, v2, 0xc

    and-int/lit8 v4, v4, 0x3f

    or-int/2addr v4, v7

    int-to-byte v4, v4

    invoke-static {v1, v5, v6, v4}, Lm5j;->j([BJB)V

    add-long v5, v11, v19

    ushr-int/lit8 v4, v2, 0x6

    and-int/lit8 v4, v4, 0x3f

    or-int/2addr v4, v7

    int-to-byte v4, v4

    invoke-static {v1, v8, v9, v4}, Lm5j;->j([BJB)V

    add-long v11, v11, v21

    and-int/lit8 v2, v2, 0x3f

    or-int/2addr v2, v7

    int-to-byte v2, v2

    invoke-static {v1, v5, v6, v2}, Lm5j;->j([BJB)V

    move v6, v15

    :goto_fe
    add-int/lit8 v6, v6, 0x1

    move-object/from16 v10, v16

    const/16 v5, 0x800

    const v8, 0xd800

    const v9, 0xdfff

    move-wide/from16 v15, p3

    goto/16 :goto_41

    :cond_10e
    move v15, v9

    move v6, v15

    goto :goto_112

    :cond_111
    move v6, v4

    :goto_112
    new-instance v0, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;

    add-int/lit8 v6, v6, -0x1

    invoke-direct {v0, v6, v3}, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_11a
    move v10, v8

    if-gt v10, v2, :cond_136

    const v15, 0xdfff

    if-gt v2, v15, :cond_136

    add-int/lit8 v6, v4, 0x1

    if-eq v6, v3, :cond_130

    invoke-virtual {v0, v6}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v2, v0}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v0

    if-nez v0, :cond_136

    :cond_130
    new-instance v0, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;

    invoke-direct {v0, v4, v3}, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_136
    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    move-object/from16 v3, v16

    invoke-direct {v0, v3}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_13e
    return v0

    :cond_13f
    move-object v3, v10

    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    invoke-direct {v0, v3}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_146  #0x0
    move-object v3, v10

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v5

    add-int/2addr v4, v2

    :goto_14c
    if-ge v6, v5, :cond_15e

    add-int v8, v6, v2

    if-ge v8, v4, :cond_15e

    invoke-virtual {v0, v6}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-ge v9, v7, :cond_15e

    int-to-byte v9, v9

    aput-byte v9, v1, v8

    add-int/lit8 v6, v6, 0x1

    goto :goto_14c

    :cond_15e
    if-ne v6, v5, :cond_164

    add-int v0, v2, v5

    goto/16 :goto_233

    :cond_164
    add-int/2addr v2, v6

    :goto_165
    if-ge v6, v5, :cond_232

    invoke-virtual {v0, v6}, Ljava/lang/String;->charAt(I)C

    move-result v8

    if-ge v8, v7, :cond_179

    if-ge v2, v4, :cond_179

    add-int/lit8 v9, v2, 0x1

    int-to-byte v8, v8

    aput-byte v8, v1, v2

    move v2, v9

    const/16 v9, 0x800

    goto/16 :goto_1fd

    :cond_179
    const/16 v9, 0x800

    if-ge v8, v9, :cond_193

    add-int/lit8 v11, v4, -0x2

    if-gt v2, v11, :cond_193

    add-int/lit8 v11, v2, 0x1

    ushr-int/lit8 v12, v8, 0x6

    or-int/lit16 v12, v12, 0x3c0

    int-to-byte v12, v12

    aput-byte v12, v1, v2

    add-int/lit8 v2, v2, 0x2

    and-int/lit8 v8, v8, 0x3f

    or-int/2addr v8, v7

    int-to-byte v8, v8

    aput-byte v8, v1, v11

    goto :goto_1fd

    :cond_193
    const v10, 0xd800

    if-lt v8, v10, :cond_19d

    const v15, 0xdfff

    if-ge v15, v8, :cond_1bd

    :cond_19d
    add-int/lit8 v11, v4, -0x3

    if-gt v2, v11, :cond_1bd

    add-int/lit8 v11, v2, 0x1

    ushr-int/lit8 v12, v8, 0xc

    or-int/lit16 v12, v12, 0x1e0

    int-to-byte v12, v12

    aput-byte v12, v1, v2

    add-int/lit8 v12, v2, 0x2

    ushr-int/lit8 v13, v8, 0x6

    and-int/lit8 v13, v13, 0x3f

    or-int/2addr v13, v7

    int-to-byte v13, v13

    aput-byte v13, v1, v11

    add-int/lit8 v2, v2, 0x3

    and-int/lit8 v8, v8, 0x3f

    or-int/2addr v8, v7

    int-to-byte v8, v8

    aput-byte v8, v1, v12

    goto :goto_1fd

    :cond_1bd
    add-int/lit8 v11, v4, -0x4

    if-gt v2, v11, :cond_20a

    add-int/lit8 v11, v6, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v12

    if-eq v11, v12, :cond_202

    invoke-virtual {v0, v11}, Ljava/lang/String;->charAt(I)C

    move-result v6

    invoke-static {v8, v6}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v12

    if-eqz v12, :cond_201

    invoke-static {v8, v6}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v6

    add-int/lit8 v8, v2, 0x1

    ushr-int/lit8 v12, v6, 0x12

    or-int/lit16 v12, v12, 0xf0

    int-to-byte v12, v12

    aput-byte v12, v1, v2

    add-int/lit8 v12, v2, 0x2

    ushr-int/lit8 v13, v6, 0xc

    and-int/lit8 v13, v13, 0x3f

    or-int/2addr v13, v7

    int-to-byte v13, v13

    aput-byte v13, v1, v8

    add-int/lit8 v8, v2, 0x3

    ushr-int/lit8 v13, v6, 0x6

    and-int/lit8 v13, v13, 0x3f

    or-int/2addr v13, v7

    int-to-byte v13, v13

    aput-byte v13, v1, v12

    add-int/lit8 v2, v2, 0x4

    and-int/lit8 v6, v6, 0x3f

    or-int/2addr v6, v7

    int-to-byte v6, v6

    aput-byte v6, v1, v8

    move v6, v11

    :goto_1fd
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_165

    :cond_201
    move v6, v11

    :cond_202
    new-instance v0, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;

    add-int/lit8 v6, v6, -0x1

    invoke-direct {v0, v6, v5}, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_20a
    const v10, 0xd800

    if-gt v10, v8, :cond_22c

    const v15, 0xdfff

    if-gt v8, v15, :cond_22c

    add-int/lit8 v1, v6, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-eq v1, v2, :cond_226

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v8, v0}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v0

    if-nez v0, :cond_22c

    :cond_226
    new-instance v0, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;

    invoke-direct {v0, v6, v5}, Landroidx/datastore/preferences/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_22c
    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    invoke-direct {v0, v3}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_232
    move v0, v2

    :goto_233
    return v0

    :pswitch_data_234
    .packed-switch 0x0
        :pswitch_146  #00000000
    .end packed-switch
.end method
