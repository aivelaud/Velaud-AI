.class public final Landroidx/datastore/preferences/protobuf/b;
.super Lnl4;
.source "SourceFile"


# instance fields
.field public final d:[B

.field public e:I

.field public f:I

.field public g:I

.field public final h:I

.field public i:I

.field public j:I


# direct methods
.method public constructor <init>([BIIZ)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const p4, 0x7fffffff

    iput p4, p0, Landroidx/datastore/preferences/protobuf/b;->j:I

    iput-object p1, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    add-int/2addr p3, p2

    iput p3, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iput p2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iput p2, p0, Landroidx/datastore/preferences/protobuf/b;->h:I

    return-void
.end method


# virtual methods
.method public final A()J
    .registers 10

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    sub-int/2addr v1, v0

    const/16 v2, 0x8

    if-lt v1, v2, :cond_5c

    add-int/lit8 v1, v0, 0x8

    iput v1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    aget-byte v1, p0, v0

    int-to-long v3, v1

    const-wide/16 v5, 0xff

    and-long/2addr v3, v5

    add-int/lit8 v1, v0, 0x1

    aget-byte v1, p0, v1

    int-to-long v7, v1

    and-long/2addr v7, v5

    shl-long v1, v7, v2

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x2

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x10

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x3

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x18

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x4

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x20

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x5

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x28

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x6

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x30

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v0, v0, 0x7

    aget-byte p0, p0, v0

    int-to-long v3, p0

    and-long/2addr v3, v5

    const/16 p0, 0x38

    shl-long/2addr v3, p0

    or-long v0, v1, v3

    return-wide v0

    :cond_5c
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final B()I
    .registers 8

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    if-ne v1, v0, :cond_7

    goto :goto_6b

    :cond_7
    add-int/lit8 v2, v0, 0x1

    iget-object v3, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    aget-byte v4, v3, v0

    if-ltz v4, :cond_12

    iput v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    return v4

    :cond_12
    sub-int/2addr v1, v2

    const/16 v5, 0x9

    if-ge v1, v5, :cond_18

    goto :goto_6b

    :cond_18
    add-int/lit8 v1, v0, 0x2

    aget-byte v2, v3, v2

    shl-int/lit8 v2, v2, 0x7

    xor-int/2addr v2, v4

    if-gez v2, :cond_24

    xor-int/lit8 v0, v2, -0x80

    goto :goto_79

    :cond_24
    add-int/lit8 v4, v0, 0x3

    aget-byte v1, v3, v1

    shl-int/lit8 v1, v1, 0xe

    xor-int/2addr v1, v2

    if-ltz v1, :cond_31

    xor-int/lit16 v0, v1, 0x3f80

    :goto_2f
    move v1, v4

    goto :goto_79

    :cond_31
    add-int/lit8 v2, v0, 0x4

    aget-byte v4, v3, v4

    shl-int/lit8 v4, v4, 0x15

    xor-int/2addr v1, v4

    if-gez v1, :cond_40

    const v0, -0x1fc080

    xor-int/2addr v0, v1

    :goto_3e
    move v1, v2

    goto :goto_79

    :cond_40
    add-int/lit8 v4, v0, 0x5

    aget-byte v2, v3, v2

    shl-int/lit8 v5, v2, 0x1c

    xor-int/2addr v1, v5

    const v5, 0xfe03f80

    xor-int/2addr v1, v5

    if-gez v2, :cond_75

    add-int/lit8 v2, v0, 0x6

    aget-byte v4, v3, v4

    if-gez v4, :cond_77

    add-int/lit8 v4, v0, 0x7

    aget-byte v2, v3, v2

    if-gez v2, :cond_75

    add-int/lit8 v2, v0, 0x8

    aget-byte v4, v3, v4

    if-gez v4, :cond_77

    add-int/lit8 v4, v0, 0x9

    aget-byte v2, v3, v2

    if-gez v2, :cond_75

    add-int/lit8 v0, v0, 0xa

    aget-byte v2, v3, v4

    if-gez v2, :cond_71

    :goto_6b
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->D()J

    move-result-wide v0

    long-to-int p0, v0

    return p0

    :cond_71
    move v6, v1

    move v1, v0

    move v0, v6

    goto :goto_79

    :cond_75
    move v0, v1

    goto :goto_2f

    :cond_77
    move v0, v1

    goto :goto_3e

    :goto_79
    iput v1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    return v0
.end method

.method public final C()J
    .registers 13

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    if-ne v1, v0, :cond_8

    goto/16 :goto_b6

    :cond_8
    add-int/lit8 v2, v0, 0x1

    iget-object v3, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    aget-byte v4, v3, v0

    if-ltz v4, :cond_14

    iput v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    int-to-long v0, v4

    return-wide v0

    :cond_14
    sub-int/2addr v1, v2

    const/16 v5, 0x9

    if-ge v1, v5, :cond_1b

    goto/16 :goto_b6

    :cond_1b
    add-int/lit8 v1, v0, 0x2

    aget-byte v2, v3, v2

    shl-int/lit8 v2, v2, 0x7

    xor-int/2addr v2, v4

    if-gez v2, :cond_29

    xor-int/lit8 v0, v2, -0x80

    int-to-long v2, v0

    goto/16 :goto_bd

    :cond_29
    add-int/lit8 v4, v0, 0x3

    aget-byte v1, v3, v1

    shl-int/lit8 v1, v1, 0xe

    xor-int/2addr v1, v2

    if-ltz v1, :cond_38

    xor-int/lit16 v0, v1, 0x3f80

    int-to-long v2, v0

    move v1, v4

    goto/16 :goto_bd

    :cond_38
    add-int/lit8 v2, v0, 0x4

    aget-byte v4, v3, v4

    shl-int/lit8 v4, v4, 0x15

    xor-int/2addr v1, v4

    if-gez v1, :cond_4b

    const v0, -0x1fc080

    xor-int/2addr v0, v1

    int-to-long v0, v0

    :goto_46
    move-wide v10, v0

    move v1, v2

    move-wide v2, v10

    goto/16 :goto_bd

    :cond_4b
    int-to-long v4, v1

    add-int/lit8 v1, v0, 0x5

    aget-byte v2, v3, v2

    int-to-long v6, v2

    const/16 v2, 0x1c

    shl-long/2addr v6, v2

    xor-long/2addr v4, v6

    const-wide/16 v6, 0x0

    cmp-long v2, v4, v6

    if-ltz v2, :cond_60

    const-wide/32 v2, 0xfe03f80

    :goto_5e
    xor-long/2addr v2, v4

    goto :goto_bd

    :cond_60
    add-int/lit8 v2, v0, 0x6

    aget-byte v1, v3, v1

    int-to-long v8, v1

    const/16 v1, 0x23

    shl-long/2addr v8, v1

    xor-long/2addr v4, v8

    cmp-long v1, v4, v6

    if-gez v1, :cond_74

    const-wide v0, -0x7f01fc080L

    :goto_72
    xor-long/2addr v0, v4

    goto :goto_46

    :cond_74
    add-int/lit8 v1, v0, 0x7

    aget-byte v2, v3, v2

    int-to-long v8, v2

    const/16 v2, 0x2a

    shl-long/2addr v8, v2

    xor-long/2addr v4, v8

    cmp-long v2, v4, v6

    if-ltz v2, :cond_87

    const-wide v2, 0x3f80fe03f80L

    goto :goto_5e

    :cond_87
    add-int/lit8 v2, v0, 0x8

    aget-byte v1, v3, v1

    int-to-long v8, v1

    const/16 v1, 0x31

    shl-long/2addr v8, v1

    xor-long/2addr v4, v8

    cmp-long v1, v4, v6

    if-gez v1, :cond_9a

    const-wide v0, -0x1fc07f01fc080L

    goto :goto_72

    :cond_9a
    add-int/lit8 v1, v0, 0x9

    aget-byte v2, v3, v2

    int-to-long v8, v2

    const/16 v2, 0x38

    shl-long/2addr v8, v2

    xor-long/2addr v4, v8

    const-wide v8, 0xfe03f80fe03f80L

    xor-long/2addr v4, v8

    cmp-long v2, v4, v6

    if-gez v2, :cond_bc

    add-int/lit8 v0, v0, 0xa

    aget-byte v1, v3, v1

    int-to-long v1, v1

    cmp-long v1, v1, v6

    if-gez v1, :cond_bb

    :goto_b6
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->D()J

    move-result-wide v0

    return-wide v0

    :cond_bb
    move v1, v0

    :cond_bc
    move-wide v2, v4

    :goto_bd
    iput v1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    return-wide v2
.end method

.method public final D()J
    .registers 7

    const-wide/16 v0, 0x0

    const/4 v2, 0x0

    :goto_3
    const/16 v3, 0x40

    if-ge v2, v3, :cond_27

    iget v3, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget v4, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    if-eq v3, v4, :cond_22

    add-int/lit8 v4, v3, 0x1

    iput v4, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget-object v4, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    aget-byte v3, v4, v3

    and-int/lit8 v4, v3, 0x7f

    int-to-long v4, v4

    shl-long/2addr v4, v2

    or-long/2addr v0, v4

    and-int/lit16 v3, v3, 0x80

    if-nez v3, :cond_1f

    return-wide v0

    :cond_1f
    add-int/lit8 v2, v2, 0x7

    goto :goto_3

    :cond_22
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_27
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->c()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final E()V
    .registers 4

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->f:I

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->h:I

    sub-int v1, v0, v1

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->j:I

    if-le v1, v2, :cond_16

    sub-int/2addr v1, v2

    iput v1, p0, Landroidx/datastore/preferences/protobuf/b;->f:I

    sub-int/2addr v0, v1

    iput v0, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    return-void

    :cond_16
    const/4 v0, 0x0

    iput v0, p0, Landroidx/datastore/preferences/protobuf/b;->f:I

    return-void
.end method

.method public final F(I)V
    .registers 4

    if-ltz p1, :cond_d

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    sub-int/2addr v0, v1

    if-gt p1, v0, :cond_d

    add-int/2addr v1, p1

    iput v1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    return-void

    :cond_d
    if-gez p1, :cond_14

    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->d()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_14
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final a(I)V
    .registers 2

    iget p0, p0, Landroidx/datastore/preferences/protobuf/b;->i:I

    if-ne p0, p1, :cond_5

    return-void

    :cond_5
    new-instance p0, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    const-string p1, "Protocol message end-group tag did not match expected tag."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final b()I
    .registers 2

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget p0, p0, Landroidx/datastore/preferences/protobuf/b;->h:I

    sub-int/2addr v0, p0

    return v0
.end method

.method public final c()Z
    .registers 2

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget p0, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    if-ne v0, p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final d(I)V
    .registers 2

    iput p1, p0, Landroidx/datastore/preferences/protobuf/b;->j:I

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->E()V

    return-void
.end method

.method public final e(I)I
    .registers 3

    if-ltz p1, :cond_20

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->b()I

    move-result v0

    add-int/2addr v0, p1

    if-ltz v0, :cond_18

    iget p1, p0, Landroidx/datastore/preferences/protobuf/b;->j:I

    if-gt v0, p1, :cond_13

    iput v0, p0, Landroidx/datastore/preferences/protobuf/b;->j:I

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->E()V

    return p1

    :cond_13
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_18
    new-instance p0, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    const-string p1, "Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit. If reading multiple messages, consider resetting the counter between each message using CodedInputStream.resetSizeCounter()."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->d()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final f()Z
    .registers 5

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->C()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long p0, v0, v2

    if-eqz p0, :cond_c

    const/4 p0, 0x1

    return p0

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method public final g()Lk92;
    .registers 5

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result v0

    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    if-lez v0, :cond_19

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v3, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    sub-int/2addr v2, v3

    if-gt v0, v2, :cond_19

    invoke-static {v1, v3, v0}, Lk92;->c([BII)Lk92;

    move-result-object v1

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    add-int/2addr v2, v0

    iput v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    return-object v1

    :cond_19
    if-nez v0, :cond_1e

    sget-object p0, Lk92;->G:Lk92;

    return-object p0

    :cond_1e
    if-lez v0, :cond_2f

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v3, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    sub-int/2addr v2, v3

    if-gt v0, v2, :cond_2f

    add-int/2addr v0, v3

    iput v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    invoke-static {v1, v3, v0}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p0

    goto :goto_35

    :cond_2f
    if-gtz v0, :cond_42

    if-nez v0, :cond_3d

    sget-object p0, Lll9;->b:[B

    :goto_35
    sget-object v0, Lk92;->G:Lk92;

    new-instance v0, Lk92;

    invoke-direct {v0, p0}, Lk92;-><init>([B)V

    return-object v0

    :cond_3d
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->d()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_42
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final h()D
    .registers 3

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->A()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    return-wide v0
.end method

.method public final i()I
    .registers 1

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result p0

    return p0
.end method

.method public final j()I
    .registers 1

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->z()I

    move-result p0

    return p0
.end method

.method public final k()J
    .registers 3

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->A()J

    move-result-wide v0

    return-wide v0
.end method

.method public final l()F
    .registers 1

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->z()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    return p0
.end method

.method public final m()I
    .registers 1

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result p0

    return p0
.end method

.method public final n()J
    .registers 3

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->C()J

    move-result-wide v0

    return-wide v0
.end method

.method public final o()I
    .registers 1

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->z()I

    move-result p0

    return p0
.end method

.method public final p()J
    .registers 3

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->A()J

    move-result-wide v0

    return-wide v0
.end method

.method public final q()I
    .registers 2

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result p0

    ushr-int/lit8 v0, p0, 0x1

    and-int/lit8 p0, p0, 0x1

    neg-int p0, p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public final r()J
    .registers 7

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->C()J

    move-result-wide v0

    const/4 p0, 0x1

    ushr-long v2, v0, p0

    const-wide/16 v4, 0x1

    and-long/2addr v0, v4

    neg-long v0, v0

    xor-long/2addr v0, v2

    return-wide v0
.end method

.method public final s()Ljava/lang/String;
    .registers 6

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result v0

    if-lez v0, :cond_1c

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    sub-int/2addr v1, v2

    if-gt v0, v1, :cond_1c

    new-instance v1, Ljava/lang/String;

    iget-object v3, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    sget-object v4, Lll9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v1, v3, v2, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    add-int/2addr v2, v0

    iput v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    return-object v1

    :cond_1c
    if-nez v0, :cond_21

    const-string p0, ""

    return-object p0

    :cond_21
    if-gez v0, :cond_28

    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->d()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_28
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final t()Ljava/lang/String;
    .registers 5

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result v0

    if-lez v0, :cond_1b

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    sub-int/2addr v1, v2

    if-gt v0, v1, :cond_1b

    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    sget-object v3, Landroidx/datastore/preferences/protobuf/o;->a:Lylk;

    invoke-virtual {v3, v1, v2, v0}, Lylk;->C([BII)Ljava/lang/String;

    move-result-object v1

    iget v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    add-int/2addr v2, v0

    iput v2, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    return-object v1

    :cond_1b
    if-nez v0, :cond_20

    const-string p0, ""

    return-object p0

    :cond_20
    if-gtz v0, :cond_27

    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->d()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_27
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final u()I
    .registers 2

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->c()Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 v0, 0x0

    iput v0, p0, Landroidx/datastore/preferences/protobuf/b;->i:I

    return v0

    :cond_a
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result v0

    iput v0, p0, Landroidx/datastore/preferences/protobuf/b;->i:I

    ushr-int/lit8 p0, v0, 0x3

    if-eqz p0, :cond_15

    return v0

    :cond_15
    new-instance p0, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    const-string v0, "Protocol message contained an invalid tag (zero)."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final v()I
    .registers 1

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result p0

    return p0
.end method

.method public final w()J
    .registers 3

    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->C()J

    move-result-wide v0

    return-wide v0
.end method

.method public final x(I)Z
    .registers 7

    and-int/lit8 v0, p1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_3d

    if-eq v0, v2, :cond_37

    const/4 v3, 0x2

    if-eq v0, v3, :cond_2f

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eq v0, v4, :cond_25

    if-eq v0, v3, :cond_1d

    const/4 p1, 0x5

    if-ne v0, p1, :cond_18

    invoke-virtual {p0, v3}, Landroidx/datastore/preferences/protobuf/b;->F(I)V

    return v2

    :cond_18
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->b()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p0

    throw p0

    :cond_1d
    iget p1, p0, Lnl4;->b:I

    if-nez p1, :cond_24

    invoke-virtual {p0, v1}, Landroidx/datastore/preferences/protobuf/b;->a(I)V

    :cond_24
    return v1

    :cond_25
    invoke-virtual {p0}, Lnl4;->y()V

    ushr-int/2addr p1, v4

    shl-int/2addr p1, v4

    or-int/2addr p1, v3

    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/b;->a(I)V

    return v2

    :cond_2f
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/b;->B()I

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/b;->F(I)V

    return v2

    :cond_37
    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/b;->F(I)V

    return v2

    :cond_3d
    iget p1, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    sub-int/2addr p1, v0

    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    const/16 v3, 0xa

    if-lt p1, v3, :cond_5d

    :goto_48
    if-ge v1, v3, :cond_58

    iget p1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    add-int/lit8 v4, p1, 0x1

    iput v4, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    aget-byte p1, v0, p1

    if-ltz p1, :cond_55

    goto :goto_6d

    :cond_55
    add-int/lit8 v1, v1, 0x1

    goto :goto_48

    :cond_58
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->c()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_5d
    :goto_5d
    if-ge v1, v3, :cond_76

    iget p1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget v4, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    if-eq p1, v4, :cond_71

    add-int/lit8 v4, p1, 0x1

    iput v4, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    aget-byte p1, v0, p1

    if-ltz p1, :cond_6e

    :goto_6d
    return v2

    :cond_6e
    add-int/lit8 v1, v1, 0x1

    goto :goto_5d

    :cond_71
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_76
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->c()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final z()I
    .registers 4

    iget v0, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget v1, p0, Landroidx/datastore/preferences/protobuf/b;->e:I

    sub-int/2addr v1, v0

    const/4 v2, 0x4

    if-lt v1, v2, :cond_2e

    add-int/lit8 v1, v0, 0x4

    iput v1, p0, Landroidx/datastore/preferences/protobuf/b;->g:I

    iget-object p0, p0, Landroidx/datastore/preferences/protobuf/b;->d:[B

    aget-byte v1, p0, v0

    and-int/lit16 v1, v1, 0xff

    add-int/lit8 v2, v0, 0x1

    aget-byte v2, p0, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x8

    or-int/2addr v1, v2

    add-int/lit8 v2, v0, 0x2

    aget-byte v2, p0, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x10

    or-int/2addr v1, v2

    add-int/lit8 v0, v0, 0x3

    aget-byte p0, p0, v0

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x18

    or-int/2addr p0, v1

    return p0

    :cond_2e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;->e()Landroidx/datastore/preferences/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method
