.class public Landroidx/work/impl/background/systemalarm/RescheduleReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "RescheduleReceiver"

    invoke-static {v0}, Lyta;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/work/impl/background/systemalarm/RescheduleReceiver;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 4

    invoke-static {}, Lyta;->c()Lyta;

    move-result-object v0

    invoke-static {p2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_a
    invoke-static {p1}, Lx6k;->d(Landroid/content/Context;)Lx6k;

    move-result-object p1

    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object p0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Lx6k;->m:Ljava/lang/Object;

    monitor-enter p2
    :try_end_18
    .catch Ljava/lang/IllegalStateException; {:try_start_a .. :try_end_18} :catch_32

    :try_start_18
    iget-object v0, p1, Lx6k;->i:Landroid/content/BroadcastReceiver$PendingResult;

    if-eqz v0, :cond_22

    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    goto :goto_22

    :catchall_20
    move-exception p0

    goto :goto_30

    :cond_22
    :goto_22
    iput-object p0, p1, Lx6k;->i:Landroid/content/BroadcastReceiver$PendingResult;

    iget-boolean v0, p1, Lx6k;->h:Z

    if-eqz v0, :cond_2e

    invoke-virtual {p0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    const/4 p0, 0x0

    iput-object p0, p1, Lx6k;->i:Landroid/content/BroadcastReceiver$PendingResult;

    :cond_2e
    monitor-exit p2

    return-void

    :goto_30
    monitor-exit p2
    :try_end_31
    .catchall {:try_start_18 .. :try_end_31} :catchall_20

    :try_start_31
    throw p0
    :try_end_32
    .catch Ljava/lang/IllegalStateException; {:try_start_31 .. :try_end_32} :catch_32

    :catch_32
    move-exception p0

    invoke-static {}, Lyta;->c()Lyta;

    move-result-object p1

    sget-object p2, Landroidx/work/impl/background/systemalarm/RescheduleReceiver;->a:Ljava/lang/String;

    const-string v0, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate()."

    invoke-virtual {p1, p2, v0, p0}, Lyta;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
