.class public final Landroidx/concurrent/futures/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Lug2;

.field public c:Lobf;

.field public d:Z


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .registers 3

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/concurrent/futures/b;->d:Z

    iget-object v0, p0, Landroidx/concurrent/futures/b;->b:Lug2;

    if-eqz v0, :cond_16

    iget-object v0, v0, Lug2;->F:Ltg2;

    invoke-virtual {v0, p1}, Lz3;->k(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_16

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/concurrent/futures/b;->a:Ljava/lang/Object;

    iput-object p1, p0, Landroidx/concurrent/futures/b;->b:Lug2;

    iput-object p1, p0, Landroidx/concurrent/futures/b;->c:Lobf;

    :cond_16
    return-void
.end method

.method public final b(Ljava/lang/Throwable;)V
    .registers 3

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/concurrent/futures/b;->d:Z

    iget-object v0, p0, Landroidx/concurrent/futures/b;->b:Lug2;

    if-eqz v0, :cond_16

    iget-object v0, v0, Lug2;->F:Ltg2;

    invoke-virtual {v0, p1}, Lz3;->l(Ljava/lang/Throwable;)Z

    move-result p1

    if-eqz p1, :cond_16

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/concurrent/futures/b;->a:Ljava/lang/Object;

    iput-object p1, p0, Landroidx/concurrent/futures/b;->b:Lug2;

    iput-object p1, p0, Landroidx/concurrent/futures/b;->c:Lobf;

    :cond_16
    return-void
.end method

.method public final finalize()V
    .registers 5

    iget-object v0, p0, Landroidx/concurrent/futures/b;->b:Lug2;

    if-eqz v0, :cond_24

    iget-object v0, v0, Lug2;->F:Ltg2;

    invoke-virtual {v0}, Lz3;->isDone()Z

    move-result v1

    if-nez v1, :cond_24

    new-instance v1, Landroidx/concurrent/futures/CallbackToFutureAdapter$FutureGarbageCollectedException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "The completer object was garbage collected - this future would otherwise never complete. The tag was: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Landroidx/concurrent/futures/b;->a:Ljava/lang/Object;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Landroidx/concurrent/futures/CallbackToFutureAdapter$FutureGarbageCollectedException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lz3;->l(Ljava/lang/Throwable;)Z

    :cond_24
    iget-boolean v0, p0, Landroidx/concurrent/futures/b;->d:Z

    if-nez v0, :cond_30

    iget-object p0, p0, Landroidx/concurrent/futures/b;->c:Lobf;

    if-eqz p0, :cond_30

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lz3;->k(Ljava/lang/Object;)Z

    :cond_30
    return-void
.end method
