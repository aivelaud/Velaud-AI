.class public final Landroidx/compose/material3/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lhn4;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroidx/compose/material3/DelegatingThemeAwareRippleNode;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/material3/DelegatingThemeAwareRippleNode;I)V
    .registers 3

    iput p2, p0, Landroidx/compose/material3/c;->a:I

    iput-object p1, p0, Landroidx/compose/material3/c;->b:Landroidx/compose/material3/DelegatingThemeAwareRippleNode;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()J
    .registers 6

    iget v0, p0, Landroidx/compose/material3/c;->a:I

    iget-object p0, p0, Landroidx/compose/material3/c;->b:Landroidx/compose/material3/DelegatingThemeAwareRippleNode;

    packed-switch v0, :pswitch_data_5c

    sget-object v0, Lajf;->b:Lnw4;

    invoke-static {p0, v0}, Lzxh;->S(Lew4;Ldge;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvif;

    sget-object v0, Liab;->a:Lfih;

    invoke-static {p0, v0}, Lzxh;->S(Lew4;Ldge;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lfab;

    iget-object p0, p0, Lfab;->a:Lkn4;

    iget-wide v0, p0, Lkn4;->f:J

    return-wide v0

    :pswitch_1c  #0x1
    sget-object v0, Lajf;->b:Lnw4;

    invoke-static {p0, v0}, Lzxh;->S(Lew4;Ldge;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvif;

    sget-object v0, Liab;->a:Lfih;

    invoke-static {p0, v0}, Lzxh;->S(Lew4;Ldge;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lfab;

    iget-object p0, p0, Lfab;->a:Lkn4;

    iget-wide v0, p0, Lkn4;->g:J

    return-wide v0

    :pswitch_31  #0x0
    invoke-static {p0}, Landroidx/compose/material3/DelegatingThemeAwareRippleNode;->s1(Landroidx/compose/material3/DelegatingThemeAwareRippleNode;)Lhn4;

    move-result-object v0

    invoke-interface {v0}, Lhn4;->a()J

    move-result-wide v0

    const-wide/16 v2, 0x10

    cmp-long v4, v0, v2

    if-eqz v4, :cond_40

    goto :goto_5b

    :cond_40
    sget-object v0, Lajf;->b:Lnw4;

    invoke-static {p0, v0}, Lzxh;->S(Lew4;Ldge;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvif;

    if-eqz v0, :cond_51

    iget-wide v0, v0, Lvif;->a:J

    cmp-long v2, v0, v2

    if-eqz v2, :cond_51

    goto :goto_5b

    :cond_51
    sget-object v0, Ly45;->a:Lnw4;

    invoke-static {p0, v0}, Lzxh;->S(Lew4;Ldge;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lan4;

    iget-wide v0, p0, Lan4;->a:J

    :goto_5b
    return-wide v0

    :pswitch_data_5c
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_1c  #00000001
    .end packed-switch
.end method
