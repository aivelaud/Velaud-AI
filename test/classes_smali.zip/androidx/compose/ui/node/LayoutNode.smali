.class public final Landroidx/compose/ui/node/LayoutNode;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lhu4;
.implements La5d;
.implements Lru4;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\b\u0001\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u00042\u00020\u0003:\u0003\u0018\u0019\u001aJ\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0000H\u0002¢\u0006\u0004\b\u0007\u0010\bR\u001a\u0010\n\u001a\u00020\t8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\n\u0010\u000b\u001a\u0004\b\f\u0010\rR\u001a\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00000\u000e8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0015\u001a\u00020\u00128@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00000\u000e8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0010¨\u0006\u001b"
    }
    d2 = {
        "Landroidx/compose/ui/node/LayoutNode;",
        "Lhu4;",
        "La5d;",
        "",
        "Lru4;",
        "instance",
        "",
        "l",
        "(Landroidx/compose/ui/node/LayoutNode;)Ljava/lang/String;",
        "Ld8a;",
        "layoutDelegate",
        "Ld8a;",
        "s",
        "()Ld8a;",
        "",
        "getChildren$ui",
        "()Ljava/util/List;",
        "children",
        "Ldnc;",
        "getOuterCoordinator$ui",
        "()Ldnc;",
        "outerCoordinator",
        "getChildrenInfo",
        "childrenInfo",
        "w7a",
        "v7a",
        "x7a",
        "ui"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final v0:Lfkf;

.field public static final w0:Lu7a;

.field public static final x0:Lj60;


# instance fields
.field public final E:Z

.field public F:I

.field public G:Z

.field public H:J

.field public I:Z

.field public J:Z

.field public K:Z

.field public L:Z

.field public M:Landroidx/compose/ui/node/LayoutNode;

.field public N:I

.field public final O:Li47;

.field public P:Ljec;

.field public Q:Z

.field public R:Landroidx/compose/ui/node/LayoutNode;

.field public S:Landroidx/compose/ui/node/Owner;

.field public T:Lhmj;

.field public U:I

.field public V:Z

.field public W:Z

.field public X:Lhag;

.field public Y:Z

.field public final Z:Ljec;

.field public a0:Z

.field public b0:Lnlb;

.field public c0:Li47;

.field public d0:Ld76;

.field public e0:Lf7a;

.field public f0:Likj;

.field public g0:Lgw4;

.field public h0:Lx7a;

.field public i0:Lx7a;

.field public j0:Z

.field public final k0:Lxmc;

.field public l0:Lm8a;

.field private final layoutDelegate:Ld8a;

.field public m0:Ldnc;

.field public n0:Z

.field public o0:Lt7c;

.field public p0:Lt7c;

.field public q0:Lq80;

.field public r0:Lr80;

.field public s0:Z

.field public t0:I

.field public u0:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lfkf;

    const-string v1, "Undefined intrinsics block and it is required"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lfkf;-><init>(Ljava/lang/String;I)V

    sput-object v0, Landroidx/compose/ui/node/LayoutNode;->v0:Lfkf;

    new-instance v0, Lu7a;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/compose/ui/node/LayoutNode;->w0:Lu7a;

    new-instance v0, Lj60;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lj60;-><init>(I)V

    sput-object v0, Landroidx/compose/ui/node/LayoutNode;->x0:Lj60;

    return-void
.end method

.method public constructor <init>(I)V
    .registers 4

    const/4 v0, 0x1

    and-int/2addr p1, v0

    if-eqz p1, :cond_6

    const/4 p1, 0x0

    goto :goto_7

    :cond_6
    move p1, v0

    .line 104
    :goto_7
    sget-object v1, Lkag;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v0

    .line 105
    invoke-direct {p0, p1, v0}, Landroidx/compose/ui/node/LayoutNode;-><init>(ZI)V

    return-void
.end method

.method public constructor <init>(ZI)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    iput p2, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    const-wide p1, 0x7fffffff7fffffffL

    iput-wide p1, p0, Landroidx/compose/ui/node/LayoutNode;->H:J

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/compose/ui/node/LayoutNode;->I:Z

    iput-boolean p1, p0, Landroidx/compose/ui/node/LayoutNode;->J:Z

    new-instance p2, Li47;

    new-instance v0, Ljec;

    const/16 v1, 0x10

    new-array v2, v1, [Landroidx/compose/ui/node/LayoutNode;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v2}, Ljec;-><init>(I[Ljava/lang/Object;)V

    new-instance v2, Lz7a;

    invoke-direct {v2, v3, p0}, Lz7a;-><init>(ILandroidx/compose/ui/node/LayoutNode;)V

    invoke-direct {p2, v0, v1, v2}, Li47;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    new-instance p2, Ljec;

    new-array v0, v1, [Landroidx/compose/ui/node/LayoutNode;

    invoke-direct {p2, v3, v0}, Ljec;-><init>(I[Ljava/lang/Object;)V

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->Z:Ljec;

    iput-boolean p1, p0, Landroidx/compose/ui/node/LayoutNode;->a0:Z

    sget-object p2, Landroidx/compose/ui/node/LayoutNode;->v0:Lfkf;

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->b0:Lnlb;

    sget-object p2, Lc8a;->a:Lg76;

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->d0:Ld76;

    sget-object p2, Lf7a;->E:Lf7a;

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->e0:Lf7a;

    sget-object p2, Landroidx/compose/ui/node/LayoutNode;->w0:Lu7a;

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->f0:Likj;

    sget-object p2, Lgw4;->f:Lfw4;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Lfw4;->b:Lnhd;

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->g0:Lgw4;

    sget-object p2, Lx7a;->G:Lx7a;

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->i0:Lx7a;

    new-instance p2, Lxmc;

    invoke-direct {p2, p0}, Lxmc;-><init>(Landroidx/compose/ui/node/LayoutNode;)V

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    new-instance p2, Ld8a;

    invoke-direct {p2, p0}, Ld8a;-><init>(Landroidx/compose/ui/node/LayoutNode;)V

    iput-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iput-boolean p1, p0, Landroidx/compose/ui/node/LayoutNode;->n0:Z

    sget-object p1, Lq7c;->E:Lq7c;

    iput-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->o0:Lt7c;

    return-void
.end method

.method public static b0(Landroidx/compose/ui/node/LayoutNode;)Z
    .registers 2

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, v0, Ld8a;->q:Lsza;

    if-eqz v0, :cond_9

    iget-object v0, v0, Lsza;->R:Lj35;

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    invoke-virtual {p0, v0}, Landroidx/compose/ui/node/LayoutNode;->a0(Lj35;)Z

    move-result p0

    return p0
.end method

.method private final l(Landroidx/compose/ui/node/LayoutNode;)Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Cannot insert "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " because it already has a parent or an owner. This tree: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroidx/compose/ui/node/LayoutNode;->g(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " Other tree: "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p1, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    if-eqz p0, :cond_25

    invoke-virtual {p0, v1}, Landroidx/compose/ui/node/LayoutNode;->g(I)Ljava/lang/String;

    move-result-object p0

    goto :goto_26

    :cond_25
    const/4 p0, 0x0

    :goto_26
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static n0(Landroidx/compose/ui/node/LayoutNode;)Z
    .registers 4

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, v0, Ld8a;->p:Lmlb;

    iget-boolean v1, v0, Lmlb;->N:Z

    if-eqz v1, :cond_10

    iget-wide v0, v0, Lemd;->H:J

    new-instance v2, Lj35;

    invoke-direct {v2, v0, v1}, Lj35;-><init>(J)V

    goto :goto_11

    :cond_10
    const/4 v2, 0x0

    :goto_11
    invoke-virtual {p0, v2}, Landroidx/compose/ui/node/LayoutNode;->m0(Lj35;)Z

    move-result p0

    return p0
.end method

.method public static s0(Landroidx/compose/ui/node/LayoutNode;ZI)V
    .registers 7

    and-int/lit8 v0, p2, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    move p1, v1

    :cond_6
    and-int/lit8 v0, p2, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_d

    move v0, v2

    goto :goto_e

    :cond_d
    move v0, v1

    :goto_e
    and-int/lit8 p2, p2, 0x4

    if-eqz p2, :cond_13

    move v1, v2

    :cond_13
    iget-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    if-eqz p2, :cond_18

    goto :goto_1d

    :cond_18
    const-string p2, "Lookahead measure cannot be requested on a node that is not a part of the LookaheadScope"

    invoke-static {p2}, Ldf9;->c(Ljava/lang/String;)V

    :goto_1d
    iget-object p2, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-nez p2, :cond_22

    goto :goto_7d

    :cond_22
    iget-boolean v3, p0, Landroidx/compose/ui/node/LayoutNode;->V:Z

    if-nez v3, :cond_7d

    iget-boolean v3, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-nez v3, :cond_7d

    check-cast p2, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {p2, p0, v2, p1, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->z(Landroidx/compose/ui/node/LayoutNode;ZZZ)V

    if-eqz v1, :cond_7d

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->q:Lsza;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lsza;->J:Ld8a;

    iget-object p2, p0, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p2

    iget-object p0, p0, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    if-eqz p2, :cond_7d

    sget-object v0, Lx7a;->G:Lx7a;

    if-eq p0, v0, :cond_7d

    :goto_4a
    iget-object v0, p2, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    if-ne v0, p0, :cond_57

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-nez v0, :cond_55

    goto :goto_57

    :cond_55
    move-object p2, v0

    goto :goto_4a

    :cond_57
    :goto_57
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    if-eqz p0, :cond_71

    if-ne p0, v2, :cond_6b

    iget-object p0, p2, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    if-eqz p0, :cond_67

    invoke-virtual {p2, p1}, Landroidx/compose/ui/node/LayoutNode;->r0(Z)V

    return-void

    :cond_67
    invoke-virtual {p2, p1}, Landroidx/compose/ui/node/LayoutNode;->t0(Z)V

    return-void

    :cond_6b
    const-string p0, "Intrinsics isn\'t used by the parent"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void

    :cond_71
    iget-object p0, p2, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    const/4 v0, 0x6

    if-eqz p0, :cond_7a

    invoke-static {p2, p1, v0}, Landroidx/compose/ui/node/LayoutNode;->s0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    return-void

    :cond_7a
    invoke-static {p2, p1, v0}, Landroidx/compose/ui/node/LayoutNode;->u0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    :cond_7d
    :goto_7d
    return-void
.end method

.method public static u0(Landroidx/compose/ui/node/LayoutNode;ZI)V
    .registers 7

    and-int/lit8 v0, p2, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    move p1, v1

    :cond_6
    and-int/lit8 v0, p2, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_d

    move v0, v2

    goto :goto_e

    :cond_d
    move v0, v1

    :goto_e
    and-int/lit8 p2, p2, 0x4

    if-eqz p2, :cond_14

    move p2, v2

    goto :goto_15

    :cond_14
    move p2, v1

    :goto_15
    iget-boolean v3, p0, Landroidx/compose/ui/node/LayoutNode;->V:Z

    if-nez v3, :cond_62

    iget-boolean v3, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-nez v3, :cond_62

    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-nez v3, :cond_22

    goto :goto_62

    :cond_22
    check-cast v3, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v3, p0, v1, p1, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->z(Landroidx/compose/ui/node/LayoutNode;ZZZ)V

    if-eqz p2, :cond_62

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget-object p0, p0, Lmlb;->J:Ld8a;

    iget-object p2, p0, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p2

    iget-object p0, p0, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    if-eqz p2, :cond_62

    sget-object v0, Lx7a;->G:Lx7a;

    if-eq p0, v0, :cond_62

    :goto_3f
    iget-object v0, p2, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    if-ne v0, p0, :cond_4c

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-nez v0, :cond_4a

    goto :goto_4c

    :cond_4a
    move-object p2, v0

    goto :goto_3f

    :cond_4c
    :goto_4c
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    if-eqz p0, :cond_5e

    if-ne p0, v2, :cond_58

    invoke-virtual {p2, p1}, Landroidx/compose/ui/node/LayoutNode;->t0(Z)V

    return-void

    :cond_58
    const-string p0, "Intrinsics isn\'t used by the parent"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void

    :cond_5e
    const/4 p0, 0x6

    invoke-static {p2, p1, p0}, Landroidx/compose/ui/node/LayoutNode;->u0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    :cond_62
    :goto_62
    return-void
.end method

.method public static v0(Landroidx/compose/ui/node/LayoutNode;)V
    .registers 5

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, v0, Ld8a;->d:Lv7a;

    sget-object v1, Ly7a;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    iget-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    const/4 v2, 0x1

    if-ne v0, v2, :cond_35

    iget-boolean v0, v1, Ld8a;->e:Z

    const/4 v3, 0x6

    if-eqz v0, :cond_1a

    invoke-static {p0, v2, v3}, Landroidx/compose/ui/node/LayoutNode;->s0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    return-void

    :cond_1a
    iget-boolean v0, v1, Ld8a;->f:Z

    if-eqz v0, :cond_21

    invoke-virtual {p0, v2}, Landroidx/compose/ui/node/LayoutNode;->r0(Z)V

    :cond_21
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->A()Z

    move-result v0

    if-eqz v0, :cond_2b

    invoke-static {p0, v2, v3}, Landroidx/compose/ui/node/LayoutNode;->u0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    return-void

    :cond_2b
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->t()Z

    move-result v0

    if-eqz v0, :cond_34

    invoke-virtual {p0, v2}, Landroidx/compose/ui/node/LayoutNode;->t0(Z)V

    :cond_34
    return-void

    :cond_35
    const-string p0, "Unexpected state "

    iget-object v0, v1, Ld8a;->d:Lv7a;

    invoke-static {p0, v0}, Lmf6;->n(Ljava/lang/String;Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final A()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget-boolean p0, p0, Lmlb;->Z:Z

    return p0
.end method

.method public final A0(Landroidx/compose/ui/node/LayoutNode;)V
    .registers 4

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    invoke-static {p1, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3e

    iput-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    if-eqz p1, :cond_33

    iget-object p1, v0, Ld8a;->q:Lsza;

    if-nez p1, :cond_19

    new-instance p1, Lsza;

    invoke-direct {p1, v0}, Lsza;-><init>(Ld8a;)V

    iput-object p1, v0, Ld8a;->q:Lsza;

    :cond_19
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object p1

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v0, v0, Lxmc;->H:Ljava/lang/Object;

    check-cast v0, Lkg9;

    iget-object v0, v0, Ldnc;->V:Ldnc;

    :goto_25
    invoke-static {p1, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3b

    if-eqz p1, :cond_3b

    invoke-virtual {p1}, Ldnc;->a1()V

    iget-object p1, p1, Ldnc;->V:Ldnc;

    goto :goto_25

    :cond_33
    const/4 p1, 0x0

    iput-object p1, v0, Ld8a;->q:Lsza;

    const/4 p1, 0x0

    iput-boolean p1, v0, Ld8a;->f:Z

    iput-boolean p1, v0, Ld8a;->e:Z

    :cond_3b
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->S()V

    :cond_3e
    return-void
.end method

.method public final B()Lx7a;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget-object p0, p0, Lmlb;->P:Lx7a;

    return-object p0
.end method

.method public final B0(Lnlb;)V
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->b0:Lnlb;

    invoke-static {v0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    iput-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->b0:Lnlb;

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->c0:Li47;

    if-eqz v0, :cond_15

    iget-object v0, v0, Li47;->G:Ljava/lang/Object;

    check-cast v0, Ltad;

    invoke-virtual {v0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    :cond_15
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->S()V

    :cond_18
    return-void
.end method

.method public final C()Lx7a;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->q:Lsza;

    if-eqz p0, :cond_c

    iget-object p0, p0, Lsza;->N:Lx7a;

    if-nez p0, :cond_b

    goto :goto_c

    :cond_b
    return-object p0

    :cond_c
    :goto_c
    sget-object p0, Lx7a;->G:Lx7a;

    return-object p0
.end method

.method public final C0(Lt7c;)V
    .registers 4

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-eqz v0, :cond_10

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->o0:Lt7c;

    sget-object v1, Lq7c;->E:Lq7c;

    if-ne v0, v1, :cond_b

    goto :goto_10

    :cond_b
    const-string v0, "Modifiers are not supported on virtual LayoutNodes"

    invoke-static {v0}, Ldf9;->a(Ljava/lang/String;)V

    :cond_10
    :goto_10
    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-eqz v0, :cond_19

    const-string v0, "modifier is updated when deactivated"

    invoke-static {v0}, Ldf9;->a(Ljava/lang/String;)V

    :cond_19
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->W()Z

    move-result v0

    if-eqz v0, :cond_2a

    invoke-virtual {p0, p1}, Landroidx/compose/ui/node/LayoutNode;->a(Lt7c;)V

    iget-boolean p1, p0, Landroidx/compose/ui/node/LayoutNode;->W:Z

    if-eqz p1, :cond_29

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->U()V

    :cond_29
    return-void

    :cond_2a
    iput-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->p0:Lt7c;

    return-void
.end method

.method public final D()Ljava/util/List;
    .registers 11

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v0, p0, Lxmc;->L:Ljava/lang/Object;

    check-cast v0, Ljec;

    if-nez v0, :cond_b

    sget-object p0, Lyv6;->E:Lyv6;

    return-object p0

    :cond_b
    iget v1, v0, Ljec;->G:I

    new-instance v2, Ljec;

    new-array v1, v1, [Lu7c;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v1}, Ljec;-><init>(I[Ljava/lang/Object;)V

    iget-object v1, p0, Lxmc;->K:Ljava/lang/Object;

    check-cast v1, Ls7c;

    :goto_19
    if-eqz v1, :cond_54

    iget-object v4, p0, Lxmc;->J:Ljava/lang/Object;

    check-cast v4, Lhzh;

    if-eq v1, v4, :cond_54

    iget-object v5, v1, Ls7c;->L:Ldnc;

    const/4 v6, 0x0

    if-eqz v5, :cond_4e

    iget-object v7, v5, Ldnc;->r0:Lz4d;

    iget-object v8, p0, Lxmc;->H:Ljava/lang/Object;

    check-cast v8, Lkg9;

    iget-object v8, v8, Ldnc;->r0:Lz4d;

    iget-object v9, v1, Ls7c;->J:Ls7c;

    if-ne v9, v4, :cond_37

    iget-object v4, v9, Ls7c;->L:Ldnc;

    if-eq v5, v4, :cond_37

    move-object v6, v8

    :cond_37
    if-nez v7, :cond_3a

    move-object v7, v6

    :cond_3a
    new-instance v4, Lu7c;

    add-int/lit8 v6, v3, 0x1

    iget-object v8, v0, Ljec;->E:[Ljava/lang/Object;

    aget-object v3, v8, v3

    check-cast v3, Lt7c;

    invoke-direct {v4, v3, v5, v7}, Lu7c;-><init>(Lt7c;Ldnc;Lz4d;)V

    invoke-virtual {v2, v4}, Ljec;->b(Ljava/lang/Object;)V

    iget-object v1, v1, Ls7c;->J:Ls7c;

    move v3, v6

    goto :goto_19

    :cond_4e
    const-string p0, "getModifierInfo called on node with no coordinator"

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    return-object v6

    :cond_54
    invoke-virtual {v2}, Ljec;->g()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final D0(Likj;)V
    .registers 10

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->f0:Likj;

    invoke-static {v0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_70

    iput-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->f0:Likj;

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object p0, p0, Lxmc;->K:Ljava/lang/Object;

    check-cast p0, Ls7c;

    iget p1, p0, Ls7c;->H:I

    const/16 v0, 0x10

    and-int/2addr p1, v0

    if-eqz p1, :cond_70

    :goto_17
    if-eqz p0, :cond_70

    iget p1, p0, Ls7c;->G:I

    and-int/2addr p1, v0

    if-eqz p1, :cond_68

    const/4 p1, 0x0

    move-object v1, p0

    move-object v2, p1

    :goto_21
    if-eqz v1, :cond_68

    instance-of v3, v1, Lgrd;

    if-eqz v3, :cond_2d

    check-cast v1, Lgrd;

    invoke-interface {v1}, Lgrd;->V0()V

    goto :goto_63

    :cond_2d
    iget v3, v1, Ls7c;->G:I

    and-int/2addr v3, v0

    if-eqz v3, :cond_63

    instance-of v3, v1, Ls46;

    if-eqz v3, :cond_63

    move-object v3, v1

    check-cast v3, Ls46;

    iget-object v3, v3, Ls46;->T:Ls7c;

    const/4 v4, 0x0

    move v5, v4

    :goto_3d
    const/4 v6, 0x1

    if-eqz v3, :cond_60

    iget v7, v3, Ls7c;->G:I

    and-int/2addr v7, v0

    if-eqz v7, :cond_5d

    add-int/lit8 v5, v5, 0x1

    if-ne v5, v6, :cond_4b

    move-object v1, v3

    goto :goto_5d

    :cond_4b
    if-nez v2, :cond_54

    new-instance v2, Ljec;

    new-array v6, v0, [Ls7c;

    invoke-direct {v2, v4, v6}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_54
    if-eqz v1, :cond_5a

    invoke-virtual {v2, v1}, Ljec;->b(Ljava/lang/Object;)V

    move-object v1, p1

    :cond_5a
    invoke-virtual {v2, v3}, Ljec;->b(Ljava/lang/Object;)V

    :cond_5d
    :goto_5d
    iget-object v3, v3, Ls7c;->J:Ls7c;

    goto :goto_3d

    :cond_60
    if-ne v5, v6, :cond_63

    goto :goto_21

    :cond_63
    :goto_63
    invoke-static {v2}, La60;->l(Ljec;)Ls7c;

    move-result-object v1

    goto :goto_21

    :cond_68
    iget p1, p0, Ls7c;->H:I

    and-int/2addr p1, v0

    if-eqz p1, :cond_70

    iget-object p0, p0, Ls7c;->J:Ls7c;

    goto :goto_17

    :cond_70
    return-void
.end method

.method public final E()Li47;
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->c0:Li47;

    if-nez v0, :cond_d

    new-instance v0, Li47;

    iget-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->b0:Lnlb;

    invoke-direct {v0, p0, v1}, Li47;-><init>(Landroidx/compose/ui/node/LayoutNode;Lnlb;)V

    iput-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->c0:Li47;

    :cond_d
    return-object v0
.end method

.method public final E0()V
    .registers 7

    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->N:I

    if-lez v0, :cond_4e

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->Q:Z

    if-eqz v0, :cond_4e

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->Q:Z

    iget-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->P:Ljec;

    if-nez v1, :cond_1a

    new-instance v1, Ljec;

    const/16 v2, 0x10

    new-array v2, v2, [Landroidx/compose/ui/node/LayoutNode;

    invoke-direct {v1, v0, v2}, Ljec;-><init>(I[Ljava/lang/Object;)V

    iput-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->P:Ljec;

    :cond_1a
    invoke-virtual {v1}, Ljec;->h()V

    iget-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object v2, v2, Li47;->F:Ljava/lang/Object;

    check-cast v2, Ljec;

    iget-object v3, v2, Ljec;->E:[Ljava/lang/Object;

    iget v2, v2, Ljec;->G:I

    :goto_27
    if-ge v0, v2, :cond_41

    aget-object v4, v3, v0

    check-cast v4, Landroidx/compose/ui/node/LayoutNode;

    iget-boolean v5, v4, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-eqz v5, :cond_3b

    invoke-virtual {v4}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object v4

    iget v5, v1, Ljec;->G:I

    invoke-virtual {v1, v5, v4}, Ljec;->c(ILjec;)V

    goto :goto_3e

    :cond_3b
    invoke-virtual {v1, v4}, Ljec;->b(Ljava/lang/Object;)V

    :goto_3e
    add-int/lit8 v0, v0, 0x1

    goto :goto_27

    :cond_41
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, p0, Ld8a;->p:Lmlb;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lmlb;->e0:Z

    iget-object p0, p0, Ld8a;->q:Lsza;

    if-eqz p0, :cond_4e

    iput-boolean v1, p0, Lsza;->Y:Z

    :cond_4e
    return-void
.end method

.method public final F()Landroidx/compose/ui/node/LayoutNode;
    .registers 3

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    :goto_2
    if-eqz p0, :cond_c

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    const/4 v1, 0x1

    if-ne v0, v1, :cond_c

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    goto :goto_2

    :cond_c
    return-object p0
.end method

.method public final G()I
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget p0, p0, Lmlb;->M:I

    return p0
.end method

.method public final H()Lhag;
    .registers 3

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->W()Z

    move-result v0

    if-eqz v0, :cond_18

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-nez v0, :cond_18

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Lxmc;->i(I)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_18

    :cond_15
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->X:Lhag;

    return-object p0

    :cond_18
    :goto_18
    const/4 p0, 0x0

    return-object p0
.end method

.method public final I()I
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget p0, p0, Lemd;->E:I

    return p0
.end method

.method public final J()F
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget p0, p0, Lmlb;->j0:F

    return p0
.end method

.method public final K()Ljec;
    .registers 6

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->a0:Z

    iget-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->Z:Ljec;

    if-eqz v0, :cond_1e

    invoke-virtual {v1}, Ljec;->h()V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object v0

    iget v2, v1, Ljec;->G:I

    invoke-virtual {v1, v2, v0}, Ljec;->c(ILjec;)V

    iget-object v0, v1, Ljec;->E:[Ljava/lang/Object;

    iget v2, v1, Ljec;->G:I

    const/4 v3, 0x0

    sget-object v4, Landroidx/compose/ui/node/LayoutNode;->x0:Lj60;

    invoke-static {v0, v3, v2, v4}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V

    iput-boolean v3, p0, Landroidx/compose/ui/node/LayoutNode;->a0:Z

    :cond_1e
    return-object v1
.end method

.method public final L()Ljec;
    .registers 2

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->E0()V

    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->N:I

    if-nez v0, :cond_e

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object p0, p0, Li47;->F:Ljava/lang/Object;

    check-cast p0, Ljec;

    return-object p0

    :cond_e
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->P:Ljec;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0
.end method

.method public final M(JLxy8;IZ)V
    .registers 15

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v0

    sget-object v1, Ldnc;->t0:Lqgf;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Ldnc;->e1(JZ)J

    move-result-wide v4

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v2

    sget-object v3, Ldnc;->w0:Lymc;

    move-object v6, p3

    move v7, p4

    move v8, p5

    invoke-virtual/range {v2 .. v8}, Ldnc;->m1(Lzmc;JLxy8;IZ)V

    return-void
.end method

.method public final N(ILandroidx/compose/ui/node/LayoutNode;)V
    .registers 5

    iget-object v0, p2, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    if-eqz v0, :cond_10

    iget-object v0, p2, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-nez v0, :cond_9

    goto :goto_10

    :cond_9
    invoke-direct {p0, p2}, Landroidx/compose/ui/node/LayoutNode;->l(Landroidx/compose/ui/node/LayoutNode;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldf9;->c(Ljava/lang/String;)V

    :cond_10
    :goto_10
    iput-object p0, p2, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object v1, v0, Li47;->F:Ljava/lang/Object;

    check-cast v1, Ljec;

    invoke-virtual {v1, p1, p2}, Ljec;->a(ILjava/lang/Object;)V

    iget-object p1, v0, Li47;->G:Ljava/lang/Object;

    check-cast p1, Lz7a;

    invoke-virtual {p1}, Lz7a;->a()Ljava/lang/Object;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->k0()V

    iget-boolean p1, p2, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-eqz p1, :cond_2f

    iget p1, p0, Landroidx/compose/ui/node/LayoutNode;->N:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Landroidx/compose/ui/node/LayoutNode;->N:I

    :cond_2f
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->V()V

    iget-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz p1, :cond_39

    invoke-virtual {p2, p1}, Landroidx/compose/ui/node/LayoutNode;->d(Landroidx/compose/ui/node/Owner;)V

    :cond_39
    iget-object p1, p2, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget p1, p1, Ld8a;->l:I

    if-lez p1, :cond_48

    iget-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget v0, p1, Ld8a;->l:I

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p1, v0}, Ld8a;->d(I)V

    :cond_48
    iget p1, p2, Landroidx/compose/ui/node/LayoutNode;->t0:I

    if-lez p1, :cond_53

    iget p1, p0, Landroidx/compose/ui/node/LayoutNode;->t0:I

    add-int/lit8 p1, p1, 0x1

    invoke-virtual {p0, p1}, Landroidx/compose/ui/node/LayoutNode;->z0(I)V

    :cond_53
    return-void
.end method

.method public final O(Z)V
    .registers 11

    if-eqz p1, :cond_15

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    if-eqz p1, :cond_c

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->P()V

    goto :goto_15

    :cond_c
    iget-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz p1, :cond_15

    check-cast p1, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    :cond_15
    :goto_15
    iget-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object p1, p1, Lxmc;->K:Ljava/lang/Object;

    check-cast p1, Ls7c;

    iget v0, p1, Ls7c;->H:I

    const/4 v1, 0x2

    and-int/2addr v0, v1

    const/4 v2, 0x0

    if-eqz v0, :cond_86

    :goto_22
    if-eqz p1, :cond_86

    iget v0, p1, Ls7c;->G:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_7e

    const/4 v0, 0x0

    move-object v3, p1

    move-object v4, v0

    :goto_2c
    if-eqz v3, :cond_7e

    instance-of v5, v3, Lp7a;

    if-eqz v5, :cond_42

    check-cast v3, Lp7a;

    invoke-static {v3, v1}, La60;->O(Lp46;I)Ldnc;

    move-result-object v3

    iget-object v3, v3, Ldnc;->r0:Lz4d;

    if-eqz v3, :cond_79

    check-cast v3, Ltl8;

    invoke-virtual {v3}, Ltl8;->c()V

    goto :goto_79

    :cond_42
    iget v5, v3, Ls7c;->G:I

    and-int/2addr v5, v1

    if-eqz v5, :cond_79

    instance-of v5, v3, Ls46;

    if-eqz v5, :cond_79

    move-object v5, v3

    check-cast v5, Ls46;

    iget-object v5, v5, Ls46;->T:Ls7c;

    move v6, v2

    :goto_51
    const/4 v7, 0x1

    if-eqz v5, :cond_76

    iget v8, v5, Ls7c;->G:I

    and-int/2addr v8, v1

    if-eqz v8, :cond_73

    add-int/lit8 v6, v6, 0x1

    if-ne v6, v7, :cond_5f

    move-object v3, v5

    goto :goto_73

    :cond_5f
    if-nez v4, :cond_6a

    new-instance v4, Ljec;

    const/16 v7, 0x10

    new-array v7, v7, [Ls7c;

    invoke-direct {v4, v2, v7}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_6a
    if-eqz v3, :cond_70

    invoke-virtual {v4, v3}, Ljec;->b(Ljava/lang/Object;)V

    move-object v3, v0

    :cond_70
    invoke-virtual {v4, v5}, Ljec;->b(Ljava/lang/Object;)V

    :cond_73
    :goto_73
    iget-object v5, v5, Ls7c;->J:Ls7c;

    goto :goto_51

    :cond_76
    if-ne v6, v7, :cond_79

    goto :goto_2c

    :cond_79
    :goto_79
    invoke-static {v4}, La60;->l(Ljec;)Ls7c;

    move-result-object v3

    goto :goto_2c

    :cond_7e
    iget v0, p1, Ls7c;->H:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_86

    iget-object p1, p1, Ls7c;->J:Ls7c;

    goto :goto_22

    :cond_86
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    iget-object p1, p0, Ljec;->E:[Ljava/lang/Object;

    iget p0, p0, Ljec;->G:I

    move v0, v2

    :goto_8f
    if-ge v0, p0, :cond_9b

    aget-object v1, p1, v0

    check-cast v1, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v1, v2}, Landroidx/compose/ui/node/LayoutNode;->O(Z)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_8f

    :cond_9b
    return-void
.end method

.method public final P()V
    .registers 5

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->n0:Z

    if-eqz v0, :cond_2e

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v0, v0, Lxmc;->H:Ljava/lang/Object;

    check-cast v0, Lkg9;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v1

    iget-object v1, v1, Ldnc;->W:Ldnc;

    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->m0:Ldnc;

    :goto_13
    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2b

    if-eqz v0, :cond_1e

    iget-object v3, v0, Ldnc;->r0:Lz4d;

    goto :goto_1f

    :cond_1e
    move-object v3, v2

    :goto_1f
    if-eqz v3, :cond_24

    iput-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->m0:Ldnc;

    goto :goto_2b

    :cond_24
    if-eqz v0, :cond_29

    iget-object v0, v0, Ldnc;->W:Ldnc;

    goto :goto_13

    :cond_29
    move-object v0, v2

    goto :goto_13

    :cond_2b
    :goto_2b
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->n0:Z

    :cond_2e
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->m0:Ldnc;

    if-eqz v0, :cond_3e

    iget-object v1, v0, Ldnc;->r0:Lz4d;

    if-eqz v1, :cond_37

    goto :goto_3e

    :cond_37
    const-string p0, "layer was not set. This error is usually caused by operating off of the UI thread. Did you call invalidate() instead of postInvalidate()?"

    invoke-static {p0}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object p0

    throw p0

    :cond_3e
    :goto_3e
    if-eqz v0, :cond_44

    invoke-virtual {v0}, Ldnc;->o1()V

    return-void

    :cond_44
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_4e

    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->P()V

    return-void

    :cond_4e
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz p0, :cond_57

    check-cast p0, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_57
    return-void
.end method

.method public final Q()V
    .registers 4

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v0

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v1, p0, Lxmc;->H:Ljava/lang/Object;

    check-cast v1, Lkg9;

    :goto_a
    if-eq v0, v1, :cond_1d

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Ls7a;

    iget-object v2, v0, Ldnc;->r0:Lz4d;

    if-eqz v2, :cond_1a

    check-cast v2, Ltl8;

    invoke-virtual {v2}, Ltl8;->c()V

    :cond_1a
    iget-object v0, v0, Ldnc;->V:Ldnc;

    goto :goto_a

    :cond_1d
    iget-object p0, p0, Lxmc;->H:Ljava/lang/Object;

    check-cast p0, Lkg9;

    iget-object p0, p0, Ldnc;->r0:Lz4d;

    if-eqz p0, :cond_2a

    check-cast p0, Ltl8;

    invoke-virtual {p0}, Ltl8;->c()V

    :cond_2a
    return-void
.end method

.method public final R()V
    .registers 4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, v1, v0}, Landroidx/compose/ui/node/LayoutNode;->u0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    iget-object v0, p0, Ljec;->E:[Ljava/lang/Object;

    iget p0, p0, Ljec;->G:I

    :goto_d
    if-ge v1, p0, :cond_19

    aget-object v2, v0, v1

    check-cast v2, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v2}, Landroidx/compose/ui/node/LayoutNode;->R()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_19
    return-void
.end method

.method public final S()V
    .registers 4

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p0

    if-eqz p0, :cond_d

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->S()V

    :cond_d
    return-void

    :cond_e
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_18

    invoke-static {p0, v2, v1}, Landroidx/compose/ui/node/LayoutNode;->s0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    return-void

    :cond_18
    invoke-static {p0, v2, v1}, Landroidx/compose/ui/node/LayoutNode;->u0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    return-void
.end method

.method public final T()V
    .registers 3

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, p0, Ld8a;->p:Lmlb;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lmlb;->V:Z

    iget-object p0, p0, Ld8a;->q:Lsza;

    if-eqz p0, :cond_d

    iput-boolean v1, p0, Lsza;->b0:Z

    :cond_d
    return-void
.end method

.method public final U()V
    .registers 6

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->Y:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v0, v0, Lxmc;->G:Ljava/lang/Object;

    check-cast v0, Lwmc;

    iget-object v0, v0, Ls7c;->J:Ls7c;

    const/4 v1, 0x1

    if-eqz v0, :cond_11

    goto :goto_15

    :cond_11
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->p0:Lt7c;

    if-eqz v0, :cond_18

    :goto_15
    iput-boolean v1, p0, Landroidx/compose/ui/node/LayoutNode;->W:Z

    return-void

    :cond_18
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->X:Lhag;

    iput-boolean v1, p0, Landroidx/compose/ui/node/LayoutNode;->Y:Z

    new-instance v1, Lixe;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    new-instance v2, Lhag;

    invoke-direct {v2}, Lhag;-><init>()V

    iput-object v2, v1, Lixe;->E:Ljava/lang/Object;

    invoke-static {p0}, Lc8a;->a(Landroidx/compose/ui/node/LayoutNode;)Landroidx/compose/ui/node/Owner;

    move-result-object v2

    invoke-interface {v2}, Landroidx/compose/ui/node/Owner;->getSnapshotObserver()Lb5d;

    move-result-object v2

    new-instance v3, Ll32;

    const/16 v4, 0xa

    invoke-direct {v3, p0, v4, v1}, Ll32;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    iget-object v4, v2, Lb5d;->d:Ll86;

    iget-object v2, v2, Lb5d;->a:Lv7h;

    invoke-virtual {v2, p0, v4, v3}, Lv7h;->d(Ljava/lang/Object;Lc98;La98;)V

    const/4 v2, 0x0

    iput-boolean v2, p0, Landroidx/compose/ui/node/LayoutNode;->Y:Z

    iget-object v1, v1, Lixe;->E:Ljava/lang/Object;

    check-cast v1, Lhag;

    iput-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->X:Lhag;

    iput-boolean v2, p0, Landroidx/compose/ui/node/LayoutNode;->W:Z

    invoke-static {p0}, Lc8a;->a(Landroidx/compose/ui/node/LayoutNode;)Landroidx/compose/ui/node/Owner;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/node/Owner;->getSemanticsOwner()Lqag;

    move-result-object v2

    invoke-virtual {v2, p0, v0}, Lqag;->b(Landroidx/compose/ui/node/LayoutNode;Lhag;)V

    check-cast v1, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v1}, Landroidx/compose/ui/platform/AndroidComposeView;->B()V

    return-void
.end method

.method public final V()V
    .registers 2

    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->N:I

    if-lez v0, :cond_7

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->Q:Z

    :cond_7
    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-eqz v0, :cond_12

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    if-eqz p0, :cond_12

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->V()V

    :cond_12
    return-void
.end method

.method public final W()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public final X()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget-boolean p0, p0, Lmlb;->X:Z

    return p0
.end method

.method public final Y()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget-boolean p0, p0, Lmlb;->Y:Z

    return p0
.end method

.method public final Z()Ljava/lang/Boolean;
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->q:Lsza;

    if-eqz p0, :cond_14

    iget-object p0, p0, Lsza;->V:Lqza;

    sget-object v0, Lqza;->G:Lqza;

    if-eq p0, v0, :cond_e

    const/4 p0, 0x1

    goto :goto_f

    :cond_e
    const/4 p0, 0x0

    :goto_f
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :cond_14
    const/4 p0, 0x0

    return-object p0
.end method

.method public final a(Lt7c;)V
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    const/16 v7, 0x10

    invoke-virtual {v2, v7}, Lxmc;->i(I)Z

    move-result v8

    iget-object v3, v2, Lxmc;->J:Ljava/lang/Object;

    move-object v9, v3

    check-cast v9, Lhzh;

    const/16 v10, 0x400

    invoke-virtual {v2, v10}, Lxmc;->i(I)Z

    move-result v11

    iput-object v1, v0, Landroidx/compose/ui/node/LayoutNode;->o0:Lt7c;

    iget-object v3, v2, Lxmc;->H:Ljava/lang/Object;

    check-cast v3, Lkg9;

    iget-object v4, v2, Lxmc;->F:Ljava/lang/Object;

    check-cast v4, Landroidx/compose/ui/node/LayoutNode;

    iget-object v5, v2, Lxmc;->K:Ljava/lang/Object;

    check-cast v5, Ls7c;

    iget-object v6, v2, Lxmc;->G:Ljava/lang/Object;

    move-object v12, v6

    check-cast v12, Lwmc;

    if-eq v5, v12, :cond_2d

    goto :goto_32

    :cond_2d
    const-string v5, "padChain called on already padded chain"

    invoke-static {v5}, Ldf9;->c(Ljava/lang/String;)V

    :goto_32
    iget-object v5, v2, Lxmc;->K:Ljava/lang/Object;

    check-cast v5, Ls7c;

    iput-object v12, v5, Ls7c;->I:Ls7c;

    iput-object v5, v12, Ls7c;->J:Ls7c;

    iget-object v5, v2, Lxmc;->L:Ljava/lang/Object;

    check-cast v5, Ljec;

    const/4 v13, 0x0

    if-eqz v5, :cond_44

    iget v6, v5, Ljec;->G:I

    goto :goto_45

    :cond_44
    move v6, v13

    :goto_45
    iget-object v14, v2, Lxmc;->M:Ljava/lang/Object;

    check-cast v14, Ljec;

    if-nez v14, :cond_52

    new-instance v14, Ljec;

    new-array v15, v7, [Lr7c;

    invoke-direct {v14, v13, v15}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_52
    iget-object v15, v2, Lxmc;->N:Ljava/lang/Object;

    check-cast v15, Ljec;

    invoke-virtual {v15, v1}, Ljec;->b(Ljava/lang/Object;)V

    const/16 v16, 0x0

    :goto_5b
    iget v1, v15, Ljec;->G:I

    if-eqz v1, :cond_95

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v15, v1}, Ljec;->m(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lt7c;

    instance-of v10, v1, Lyo4;

    if-eqz v10, :cond_78

    check-cast v1, Lyo4;

    iget-object v10, v1, Lyo4;->F:Lt7c;

    invoke-virtual {v15, v10}, Ljec;->b(Ljava/lang/Object;)V

    iget-object v1, v1, Lyo4;->E:Lt7c;

    invoke-virtual {v15, v1}, Ljec;->b(Ljava/lang/Object;)V

    goto :goto_91

    :cond_78
    instance-of v10, v1, Lr7c;

    if-eqz v10, :cond_80

    invoke-virtual {v14, v1}, Ljec;->b(Ljava/lang/Object;)V

    goto :goto_91

    :cond_80
    if-nez v16, :cond_8c

    new-instance v10, Le0;

    const/16 v13, 0x17

    invoke-direct {v10, v13, v14}, Le0;-><init>(ILjava/lang/Object;)V

    move-object/from16 v16, v10

    goto :goto_8e

    :cond_8c
    move-object/from16 v10, v16

    :goto_8e
    invoke-interface {v1, v10}, Lt7c;->e(Lc98;)Z

    :goto_91
    const/16 v10, 0x400

    const/4 v13, 0x0

    goto :goto_5b

    :cond_95
    iget v1, v14, Ljec;->G:I

    const-string v13, "expected prior modifier list to be non-empty"

    if-ne v1, v6, :cond_11e

    iget-object v1, v12, Ls7c;->J:Ls7c;

    move-object v3, v2

    const/4 v2, 0x0

    :goto_9f
    if-eqz v1, :cond_e7

    if-ge v2, v6, :cond_e7

    if-eqz v5, :cond_e2

    const/16 v16, 0x2

    iget-object v10, v5, Ljec;->E:[Ljava/lang/Object;

    aget-object v10, v10, v2

    check-cast v10, Lr7c;

    iget-object v7, v14, Ljec;->E:[Ljava/lang/Object;

    aget-object v7, v7, v2

    check-cast v7, Lr7c;

    invoke-static {v10, v7}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_be

    move-object/from16 v18, v3

    move/from16 v3, v16

    goto :goto_cd

    :cond_be
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v15

    move-object/from16 v18, v3

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    if-ne v15, v3, :cond_cc

    const/4 v3, 0x1

    goto :goto_cd

    :cond_cc
    const/4 v3, 0x0

    :goto_cd
    if-eqz v3, :cond_df

    const/4 v15, 0x1

    if-eq v3, v15, :cond_d3

    goto :goto_d6

    :cond_d3
    invoke-static {v10, v7, v1}, Lxmc;->n(Lr7c;Lr7c;Ls7c;)V

    :goto_d6
    iget-object v1, v1, Ls7c;->J:Ls7c;

    add-int/lit8 v2, v2, 0x1

    move-object/from16 v3, v18

    const/16 v7, 0x10

    goto :goto_9f

    :cond_df
    iget-object v1, v1, Ls7c;->I:Ls7c;

    goto :goto_eb

    :cond_e2
    invoke-static {v13}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0

    :cond_e7
    move-object/from16 v18, v3

    const/16 v16, 0x2

    :goto_eb
    if-ge v2, v6, :cond_11a

    if-eqz v5, :cond_115

    if-eqz v1, :cond_10e

    iget-object v3, v4, Landroidx/compose/ui/node/LayoutNode;->p0:Lt7c;

    if-eqz v3, :cond_f9

    const/16 v17, 0x1

    :goto_f7
    const/4 v15, 0x1

    goto :goto_fc

    :cond_f9
    const/16 v17, 0x0

    goto :goto_f7

    :goto_fc
    xor-int/lit8 v6, v17, 0x1

    move-object v3, v5

    move-object v4, v14

    const/4 v7, 0x0

    move-object v5, v1

    move-object/from16 v1, v18

    invoke-virtual/range {v1 .. v6}, Lxmc;->k(ILjec;Ljec;Ls7c;Z)V

    move-object v5, v3

    move-object v5, v12

    :goto_109
    const/4 v15, 0x0

    const/16 v17, 0x1

    goto/16 :goto_1a7

    :cond_10e
    const-string v0, "structuralUpdate requires a non-null tail"

    invoke-static {v0}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0

    :cond_115
    invoke-static {v13}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0

    :cond_11a
    move-object/from16 v2, v18

    const/4 v7, 0x0

    goto :goto_176

    :cond_11e
    const/4 v7, 0x0

    const/16 v16, 0x2

    iget-object v10, v4, Landroidx/compose/ui/node/LayoutNode;->p0:Lt7c;

    if-eqz v10, :cond_14e

    if-nez v6, :cond_14e

    move-object v3, v12

    const/4 v1, 0x0

    :goto_129
    iget v4, v14, Ljec;->G:I

    if-ge v1, v4, :cond_13a

    iget-object v4, v14, Ljec;->E:[Ljava/lang/Object;

    aget-object v4, v4, v1

    check-cast v4, Lr7c;

    invoke-static {v4, v3}, Lxmc;->d(Lr7c;Ls7c;)Ls7c;

    move-result-object v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_129

    :cond_13a
    iget-object v1, v9, Ls7c;->I:Ls7c;

    const/4 v3, 0x0

    :goto_13d
    if-eqz v1, :cond_149

    if-eq v1, v12, :cond_149

    iget v4, v1, Ls7c;->G:I

    or-int/2addr v3, v4

    iput v3, v1, Ls7c;->H:I

    iget-object v1, v1, Ls7c;->I:Ls7c;

    goto :goto_13d

    :cond_149
    move-object v1, v2

    move-object v3, v5

    move-object v5, v12

    move-object v4, v14

    goto :goto_109

    :cond_14e
    if-nez v1, :cond_183

    if-eqz v5, :cond_17e

    iget-object v1, v12, Ls7c;->J:Ls7c;

    const/4 v6, 0x0

    :goto_155
    if-eqz v1, :cond_164

    iget v10, v5, Ljec;->G:I

    if-ge v6, v10, :cond_164

    invoke-static {v1}, Lxmc;->f(Ls7c;)Ls7c;

    move-result-object v1

    iget-object v1, v1, Ls7c;->J:Ls7c;

    add-int/lit8 v6, v6, 0x1

    goto :goto_155

    :cond_164
    invoke-virtual {v4}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    if-eqz v1, :cond_171

    iget-object v1, v1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v1, v1, Lxmc;->H:Ljava/lang/Object;

    check-cast v1, Lkg9;

    goto :goto_172

    :cond_171
    move-object v1, v7

    :goto_172
    iput-object v1, v3, Ldnc;->W:Ldnc;

    iput-object v3, v2, Lxmc;->I:Ljava/lang/Object;

    :goto_176
    move-object v1, v2

    move-object v3, v5

    move-object v5, v12

    move-object v4, v14

    const/4 v15, 0x0

    const/16 v17, 0x0

    goto :goto_1a7

    :cond_17e
    invoke-static {v13}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0

    :cond_183
    if-nez v5, :cond_191

    new-instance v5, Ljec;

    const/16 v1, 0x10

    new-array v3, v1, [Lr7c;

    const/4 v15, 0x0

    invoke-direct {v5, v15, v3}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :goto_18f
    move-object v3, v5

    goto :goto_193

    :cond_191
    const/4 v15, 0x0

    goto :goto_18f

    :goto_193
    if-eqz v10, :cond_199

    const/16 v17, 0x1

    :goto_197
    const/4 v10, 0x1

    goto :goto_19c

    :cond_199
    move/from16 v17, v15

    goto :goto_197

    :goto_19c
    xor-int/lit8 v6, v17, 0x1

    move-object v1, v2

    const/4 v2, 0x0

    move-object v5, v12

    move-object v4, v14

    invoke-virtual/range {v1 .. v6}, Lxmc;->k(ILjec;Ljec;Ls7c;Z)V

    move/from16 v17, v10

    :goto_1a7
    iput-object v4, v1, Lxmc;->L:Ljava/lang/Object;

    if-eqz v3, :cond_1af

    invoke-virtual {v3}, Ljec;->h()V

    goto :goto_1b0

    :cond_1af
    move-object v3, v7

    :goto_1b0
    iput-object v3, v1, Lxmc;->M:Ljava/lang/Object;

    iget-object v2, v5, Ls7c;->J:Ls7c;

    if-nez v2, :cond_1b7

    goto :goto_1b8

    :cond_1b7
    move-object v9, v2

    :goto_1b8
    iput-object v7, v9, Ls7c;->I:Ls7c;

    iput-object v7, v5, Ls7c;->J:Ls7c;

    const/4 v2, -0x1

    iput v2, v5, Ls7c;->H:I

    iput-object v7, v5, Ls7c;->L:Ldnc;

    if-eq v9, v5, :cond_1c4

    goto :goto_1c9

    :cond_1c4
    const-string v2, "trimChain did not update the head"

    invoke-static {v2}, Ldf9;->c(Ljava/lang/String;)V

    :goto_1c9
    iput-object v9, v1, Lxmc;->K:Ljava/lang/Object;

    if-eqz v17, :cond_1d0

    invoke-virtual {v1}, Lxmc;->l()V

    :cond_1d0
    const/16 v2, 0x10

    invoke-virtual {v1, v2}, Lxmc;->i(I)Z

    move-result v2

    const/16 v3, 0x400

    invoke-virtual {v1, v3}, Lxmc;->i(I)Z

    move-result v3

    iget-object v4, v0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    invoke-virtual {v4}, Ld8a;->j()V

    iget-object v4, v0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    if-nez v4, :cond_1f0

    const/16 v4, 0x200

    invoke-virtual {v1, v4}, Lxmc;->i(I)Z

    move-result v1

    if-eqz v1, :cond_1f0

    invoke-virtual {v0, v0}, Landroidx/compose/ui/node/LayoutNode;->A0(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_1f0
    if-ne v8, v2, :cond_1f4

    if-eq v11, v3, :cond_239

    :cond_1f4
    invoke-static {v0}, Lc8a;->a(Landroidx/compose/ui/node/LayoutNode;)Landroidx/compose/ui/node/Owner;

    move-result-object v1

    invoke-interface {v1}, Landroidx/compose/ui/node/Owner;->getRectManager()Lswe;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->W()Z

    move-result v4

    if-eqz v4, :cond_239

    iget-object v1, v1, Lswe;->b:Lbr4;

    iget v0, v0, Landroidx/compose/ui/node/LayoutNode;->F:I

    const v4, 0x1ffffff

    and-int/2addr v0, v4

    iget-object v5, v1, Lbr4;->c:Ljava/lang/Object;

    check-cast v5, [J

    iget v1, v1, Lbr4;->b:I

    move v13, v15

    :goto_214
    array-length v6, v5

    add-int/lit8 v6, v6, -0x2

    if-ge v13, v6, :cond_239

    if-ge v13, v1, :cond_239

    add-int/lit8 v6, v13, 0x2

    aget-wide v7, v5, v6

    long-to-int v9, v7

    and-int/2addr v9, v4

    if-ne v9, v0, :cond_236

    const-wide v0, -0x6000000000000001L

    and-long/2addr v0, v7

    const-wide/high16 v7, 0x2000000000000000L

    int-to-long v3, v3

    mul-long/2addr v3, v7

    or-long/2addr v0, v3

    const-wide/high16 v3, 0x4000000000000000L  # 2.0

    int-to-long v7, v2

    mul-long/2addr v7, v3

    or-long/2addr v0, v7

    aput-wide v0, v5, v6

    return-void

    :cond_236
    add-int/lit8 v13, v13, 0x3

    goto :goto_214

    :cond_239
    return-void
.end method

.method public final a0(Lj35;)Z
    .registers 4

    if-eqz p1, :cond_14

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    if-eqz v0, :cond_14

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->q:Lsza;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v0, p1, Lj35;->a:J

    invoke-virtual {p0, v0, v1}, Lsza;->u0(J)Z

    move-result p0

    return p0

    :cond_14
    const/4 p0, 0x0

    return p0
.end method

.method public final b()V
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->T:Lhmj;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lx80;->b()V

    :cond_7
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->l0:Lm8a;

    if-eqz v0, :cond_e

    invoke-virtual {v0}, Lm8a;->b()V

    :cond_e
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v0

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object p0, p0, Lxmc;->H:Ljava/lang/Object;

    check-cast p0, Lkg9;

    iget-object p0, p0, Ldnc;->V:Ldnc;

    :goto_1a
    invoke-static {v0, p0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_28

    if-eqz v0, :cond_28

    invoke-virtual {v0}, Ldnc;->t1()V

    iget-object v0, v0, Ldnc;->V:Ldnc;

    goto :goto_1a

    :cond_28
    return-void
.end method

.method public final c()V
    .registers 5

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->T:Lhmj;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lx80;->c()V

    :cond_7
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->l0:Lm8a;

    const/4 v1, 0x1

    if-eqz v0, :cond_f

    invoke-virtual {v0, v1}, Lm8a;->j(Z)V

    :cond_f
    iput-boolean v1, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v0, v0, Lxmc;->J:Ljava/lang/Object;

    check-cast v0, Lhzh;

    move-object v1, v0

    :goto_18
    if-eqz v1, :cond_24

    iget-boolean v2, v1, Ls7c;->R:Z

    if-eqz v2, :cond_21

    invoke-virtual {v1}, Ls7c;->k1()V

    :cond_21
    iget-object v1, v1, Ls7c;->I:Ls7c;

    goto :goto_18

    :cond_24
    move-object v1, v0

    :goto_25
    if-eqz v1, :cond_31

    iget-boolean v2, v1, Ls7c;->R:Z

    if-eqz v2, :cond_2e

    invoke-virtual {v1}, Ls7c;->m1()V

    :cond_2e
    iget-object v1, v1, Ls7c;->I:Ls7c;

    goto :goto_25

    :cond_31
    :goto_31
    if-eqz v0, :cond_3d

    iget-boolean v1, v0, Ls7c;->R:Z

    if-eqz v1, :cond_3a

    invoke-virtual {v0}, Ls7c;->g1()V

    :cond_3a
    iget-object v0, v0, Ls7c;->I:Ls7c;

    goto :goto_31

    :cond_3d
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->W()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_49

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->X:Lhag;

    iput-boolean v1, p0, Landroidx/compose/ui/node/LayoutNode;->W:Z

    :cond_49
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v0, :cond_66

    check-cast v0, Landroidx/compose/ui/platform/AndroidComposeView;

    iget-object v0, v0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz v0, :cond_66

    iget-object v2, v0, Li00;->L:Lmcc;

    iget v3, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v2, v3}, Lmcc;->f(I)Z

    move-result v2

    if-eqz v2, :cond_66

    iget-object v2, v0, Li00;->E:Ld3f;

    iget-object v0, v0, Li00;->G:Landroidx/compose/ui/platform/AndroidComposeView;

    iget p0, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v2, v0, p0, v1}, Ld3f;->z(Landroid/view/View;IZ)V

    :cond_66
    return-void
.end method

.method public final c0()V
    .registers 7

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    sget-object v1, Lx7a;->G:Lx7a;

    if-ne v0, v1, :cond_9

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->f()V

    :cond_9
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->q:Lsza;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    const/4 v1, 0x0

    :try_start_12
    iput-boolean v0, p0, Lsza;->K:Z

    iget-boolean v2, p0, Lsza;->P:Z

    if-nez v2, :cond_20

    const-string v2, "replace() called on item that was not placed"

    invoke-static {v2}, Ldf9;->c(Ljava/lang/String;)V

    goto :goto_20

    :catchall_1e
    move-exception v0

    goto :goto_49

    :cond_20
    :goto_20
    iput-boolean v1, p0, Lsza;->g0:Z

    iget-object v2, p0, Lsza;->V:Lqza;

    sget-object v3, Lqza;->G:Lqza;

    if-eq v2, v3, :cond_29

    goto :goto_2a

    :cond_29
    move v0, v1

    :goto_2a
    iget-wide v2, p0, Lsza;->S:J

    iget-object v4, p0, Lsza;->T:Lc98;

    iget-object v5, p0, Lsza;->U:Lql8;

    invoke-virtual {p0, v2, v3, v4, v5}, Lsza;->t0(JLc98;Lql8;)V

    if-eqz v0, :cond_46

    iget-boolean v0, p0, Lsza;->g0:Z

    if-nez v0, :cond_46

    iget-object v0, p0, Lsza;->J:Ld8a;

    iget-object v0, v0, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_46

    invoke-virtual {v0, v1}, Landroidx/compose/ui/node/LayoutNode;->r0(Z)V
    :try_end_46
    .catchall {:try_start_12 .. :try_end_46} :catchall_1e

    :cond_46
    iput-boolean v1, p0, Lsza;->K:Z

    return-void

    :goto_49
    iput-boolean v1, p0, Lsza;->K:Z

    throw v0
.end method

.method public final d(Landroidx/compose/ui/node/Owner;)V
    .registers 9

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    goto :goto_23

    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Cannot attach "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " as it already is attached.  Tree: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Landroidx/compose/ui/node/LayoutNode;->g(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldf9;->c(Ljava/lang/String;)V

    :goto_23
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    const/4 v2, 0x0

    if-eqz v0, :cond_72

    iget-object v0, v0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    invoke-static {v0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_31

    goto :goto_72

    :cond_31
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Attaching to a different owner("

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, ") than the parent\'s owner("

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v3

    if-eqz v3, :cond_49

    iget-object v3, v3, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    goto :goto_4a

    :cond_49
    move-object v3, v2

    :goto_4a
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, "). This tree: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Landroidx/compose/ui/node/LayoutNode;->g(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " Parent tree: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    if-eqz v3, :cond_67

    invoke-virtual {v3, v1}, Landroidx/compose/ui/node/LayoutNode;->g(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_68

    :cond_67
    move-object v3, v2

    :goto_68
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldf9;->c(Ljava/lang/String;)V

    :cond_72
    :goto_72
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    const/4 v3, 0x1

    if-nez v0, :cond_90

    iget-object v4, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v4, v4, Ld8a;->p:Lmlb;

    iput-boolean v3, v4, Lmlb;->X:Z

    invoke-interface {p1}, Landroidx/compose/ui/node/Owner;->getRectManager()Lswe;

    move-result-object v4

    invoke-virtual {v4, p0}, Lswe;->f(Landroidx/compose/ui/node/LayoutNode;)V

    iget-object v4, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v4, v4, Ld8a;->q:Lsza;

    if-eqz v4, :cond_90

    sget-object v5, Lqza;->E:Lqza;

    iput-object v5, v4, Lsza;->V:Lqza;

    :cond_90
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v4

    if-eqz v0, :cond_9d

    iget-object v5, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v5, v5, Lxmc;->H:Ljava/lang/Object;

    check-cast v5, Lkg9;

    goto :goto_9e

    :cond_9d
    move-object v5, v2

    :goto_9e
    iput-object v5, v4, Ldnc;->W:Ldnc;

    iput-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v0, :cond_a7

    iget v4, v0, Landroidx/compose/ui/node/LayoutNode;->U:I

    goto :goto_a8

    :cond_a7
    const/4 v4, -0x1

    :goto_a8
    add-int/2addr v4, v3

    iput v4, p0, Landroidx/compose/ui/node/LayoutNode;->U:I

    iget-object v4, p0, Landroidx/compose/ui/node/LayoutNode;->p0:Lt7c;

    if-eqz v4, :cond_b2

    invoke-virtual {p0, v4}, Landroidx/compose/ui/node/LayoutNode;->a(Lt7c;)V

    :cond_b2
    iput-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->p0:Lt7c;

    move-object v2, p1

    check-cast v2, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v2}, Landroidx/compose/ui/platform/AndroidComposeView;->getLayoutNodes()Llcc;

    move-result-object v2

    iget v4, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v2, v4, p0}, Llcc;->i(ILjava/lang/Object;)V

    iget-boolean v2, p0, Landroidx/compose/ui/node/LayoutNode;->L:Z

    iget-object v4, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v2, :cond_ca

    invoke-virtual {p0, p0}, Landroidx/compose/ui/node/LayoutNode;->A0(Landroidx/compose/ui/node/LayoutNode;)V

    goto :goto_e6

    :cond_ca
    iget-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    if-eqz v2, :cond_d2

    iget-object v2, v2, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    if-nez v2, :cond_d4

    :cond_d2
    iget-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    :cond_d4
    invoke-virtual {p0, v2}, Landroidx/compose/ui/node/LayoutNode;->A0(Landroidx/compose/ui/node/LayoutNode;)V

    iget-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    if-nez v2, :cond_e6

    const/16 v2, 0x200

    invoke-virtual {v4, v2}, Lxmc;->i(I)Z

    move-result v2

    if-eqz v2, :cond_e6

    invoke-virtual {p0, p0}, Landroidx/compose/ui/node/LayoutNode;->A0(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_e6
    :goto_e6
    iget-boolean v2, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-nez v2, :cond_f6

    iget-object v2, v4, Lxmc;->K:Ljava/lang/Object;

    check-cast v2, Ls7c;

    :goto_ee
    if-eqz v2, :cond_f6

    invoke-virtual {v2}, Ls7c;->f1()V

    iget-object v2, v2, Ls7c;->J:Ls7c;

    goto :goto_ee

    :cond_f6
    iget-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object v2, v2, Li47;->F:Ljava/lang/Object;

    check-cast v2, Ljec;

    iget-object v5, v2, Ljec;->E:[Ljava/lang/Object;

    iget v2, v2, Ljec;->G:I

    :goto_100
    if-ge v1, v2, :cond_10c

    aget-object v6, v5, v1

    check-cast v6, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v6, p1}, Landroidx/compose/ui/node/LayoutNode;->d(Landroidx/compose/ui/node/Owner;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_100

    :cond_10c
    iget-boolean v1, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-nez v1, :cond_113

    invoke-virtual {v4}, Lxmc;->j()V

    :cond_113
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->S()V

    if-eqz v0, :cond_11b

    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->S()V

    :cond_11b
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->q0:Lq80;

    if-eqz v0, :cond_122

    invoke-virtual {v0, p1}, Lq80;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_122
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    invoke-virtual {v0}, Ld8a;->j()V

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-nez v0, :cond_136

    const/16 v0, 0x8

    invoke-virtual {v4, v0}, Lxmc;->i(I)Z

    move-result v0

    if-eqz v0, :cond_136

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->U()V

    :cond_136
    check-cast p1, Landroidx/compose/ui/platform/AndroidComposeView;

    iget-object p1, p1, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz p1, :cond_15c

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->H()Lhag;

    move-result-object v0

    if-eqz v0, :cond_15c

    iget-object v0, v0, Lhag;->E:Lrdc;

    sget-object v1, Lrag;->r:Luag;

    invoke-virtual {v0, v1}, Lrdc;->b(Ljava/lang/Object;)Z

    move-result v0

    if-ne v0, v3, :cond_15c

    iget-object v0, p1, Li00;->L:Lmcc;

    iget v1, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v0, v1}, Lmcc;->a(I)Z

    iget-object v0, p1, Li00;->E:Ld3f;

    iget-object p1, p1, Li00;->G:Landroidx/compose/ui/platform/AndroidComposeView;

    iget p0, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v0, p1, p0, v3}, Ld3f;->z(Landroid/view/View;IZ)V

    :cond_15c
    return-void
.end method

.method public final d0()V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lmlb;->a0:Z

    iput-boolean v0, p0, Lmlb;->b0:Z

    return-void
.end method

.method public final e()V
    .registers 6

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    iput-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->i0:Lx7a;

    sget-object v0, Lx7a;->G:Lx7a;

    iput-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    iget-object v1, p0, Ljec;->E:[Ljava/lang/Object;

    iget p0, p0, Ljec;->G:I

    const/4 v2, 0x0

    :goto_11
    if-ge v2, p0, :cond_21

    aget-object v3, v1, v2

    check-cast v3, Landroidx/compose/ui/node/LayoutNode;

    iget-object v4, v3, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    if-eq v4, v0, :cond_1e

    invoke-virtual {v3}, Landroidx/compose/ui/node/LayoutNode;->e()V

    :cond_1e
    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    :cond_21
    return-void
.end method

.method public final e0()V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    const/4 v0, 0x1

    iput-boolean v0, p0, Ld8a;->f:Z

    iput-boolean v0, p0, Ld8a;->g:Z

    return-void
.end method

.method public final f()V
    .registers 6

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    iput-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->i0:Lx7a;

    sget-object v0, Lx7a;->G:Lx7a;

    iput-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    iget-object v0, p0, Ljec;->E:[Ljava/lang/Object;

    iget p0, p0, Ljec;->G:I

    const/4 v1, 0x0

    :goto_11
    if-ge v1, p0, :cond_23

    aget-object v2, v0, v1

    check-cast v2, Landroidx/compose/ui/node/LayoutNode;

    iget-object v3, v2, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    sget-object v4, Lx7a;->F:Lx7a;

    if-ne v3, v4, :cond_20

    invoke-virtual {v2}, Landroidx/compose/ui/node/LayoutNode;->f()V

    :cond_20
    add-int/lit8 v1, v1, 0x1

    goto :goto_11

    :cond_23
    return-void
.end method

.method public final f0()V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    const/4 v0, 0x1

    iput-boolean v0, p0, Ld8a;->e:Z

    return-void
.end method

.method public final g(I)Ljava/lang/String;
    .registers 8

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    :goto_7
    if-ge v2, p1, :cond_11

    const-string v3, "  "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_11
    const-string v2, "|-"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0xa

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    iget-object v2, p0, Ljec;->E:[Ljava/lang/Object;

    iget p0, p0, Ljec;->G:I

    move v3, v1

    :goto_2b
    if-ge v3, p0, :cond_3d

    aget-object v4, v2, v3

    check-cast v4, Landroidx/compose/ui/node/LayoutNode;

    add-int/lit8 v5, p1, 0x1

    invoke-virtual {v4, v5}, Landroidx/compose/ui/node/LayoutNode;->g(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_2b

    :cond_3d
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    if-nez p1, :cond_48

    const/4 p1, 0x1

    invoke-static {p1, v1, p0}, Lti6;->k(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :cond_48
    return-object p0
.end method

.method public final g0()V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lmlb;->Z:Z

    return-void
.end method

.method public final getChildren$ui()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/compose/ui/node/LayoutNode;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    invoke-virtual {p0}, Ljec;->g()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public getChildrenInfo()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/compose/ui/node/LayoutNode;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getChildren$ui()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final getOuterCoordinator$ui()Ldnc;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object p0, p0, Lxmc;->I:Ljava/lang/Object;

    check-cast p0, Ldnc;

    return-object p0
.end method

.method public final h()V
    .registers 11

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_25

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Cannot detach node that is already detached!  Tree: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p0

    if-eqz p0, :cond_17

    invoke-virtual {p0, v2}, Landroidx/compose/ui/node/LayoutNode;->g(I)Ljava/lang/String;

    move-result-object v1

    :cond_17
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ldf9;->d(Ljava/lang/String;)Ljava/lang/Void;

    invoke-static {}, Le97;->r()V

    return-void

    :cond_25
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v3

    if-eqz v3, :cond_3f

    invoke-virtual {v3}, Landroidx/compose/ui/node/LayoutNode;->P()V

    invoke-virtual {v3}, Landroidx/compose/ui/node/LayoutNode;->S()V

    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v4, v3, Ld8a;->p:Lmlb;

    sget-object v5, Lx7a;->G:Lx7a;

    iput-object v5, v4, Lmlb;->P:Lx7a;

    iget-object v3, v3, Ld8a;->q:Lsza;

    if-eqz v3, :cond_3f

    iput-object v5, v3, Lsza;->N:Lx7a;

    :cond_3f
    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v4, v3, Ld8a;->p:Lmlb;

    iget-object v4, v4, Lmlb;->c0:La8a;

    const/4 v5, 0x1

    iput-boolean v5, v4, La8a;->b:Z

    iput-boolean v2, v4, La8a;->c:Z

    iput-boolean v2, v4, La8a;->e:Z

    iput-boolean v2, v4, La8a;->d:Z

    iput-boolean v2, v4, La8a;->f:Z

    iput-boolean v2, v4, La8a;->g:Z

    iput-object v1, v4, La8a;->h:Ltu;

    iget-object v3, v3, Ld8a;->q:Lsza;

    if-eqz v3, :cond_6a

    iget-object v3, v3, Lsza;->W:La8a;

    if-eqz v3, :cond_6a

    iput-boolean v5, v3, La8a;->b:Z

    iput-boolean v2, v3, La8a;->c:Z

    iput-boolean v2, v3, La8a;->e:Z

    iput-boolean v2, v3, La8a;->d:Z

    iput-boolean v2, v3, La8a;->f:Z

    iput-boolean v2, v3, La8a;->g:Z

    iput-object v1, v3, La8a;->h:Ltu;

    :cond_6a
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v3

    iget-object v4, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v6, v4, Lxmc;->H:Ljava/lang/Object;

    check-cast v6, Lkg9;

    iget-object v7, v4, Lxmc;->J:Ljava/lang/Object;

    check-cast v7, Lhzh;

    iget-object v6, v6, Ldnc;->V:Ldnc;

    :goto_7a
    invoke-static {v3, v6}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_93

    if-eqz v3, :cond_93

    invoke-virtual {v3}, Ldnc;->z1()V

    iget-object v8, v3, Ldnc;->S:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v8}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result v8

    if-eqz v8, :cond_90

    invoke-virtual {v3}, Ldnc;->u1()V

    :cond_90
    iget-object v3, v3, Ldnc;->V:Ldnc;

    goto :goto_7a

    :cond_93
    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->r0:Lr80;

    if-eqz v3, :cond_9a

    invoke-virtual {v3, v0}, Lr80;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9a
    move-object v3, v7

    :goto_9b
    if-eqz v3, :cond_a7

    iget-boolean v6, v3, Ls7c;->R:Z

    if-eqz v6, :cond_a4

    invoke-virtual {v3}, Ls7c;->m1()V

    :cond_a4
    iget-object v3, v3, Ls7c;->I:Ls7c;

    goto :goto_9b

    :cond_a7
    iput-boolean v5, p0, Landroidx/compose/ui/node/LayoutNode;->V:Z

    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object v3, v3, Li47;->F:Ljava/lang/Object;

    check-cast v3, Ljec;

    iget-object v6, v3, Ljec;->E:[Ljava/lang/Object;

    iget v3, v3, Ljec;->G:I

    move v8, v2

    :goto_b4
    if-ge v8, v3, :cond_c0

    aget-object v9, v6, v8

    check-cast v9, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v9}, Landroidx/compose/ui/node/LayoutNode;->h()V

    add-int/lit8 v8, v8, 0x1

    goto :goto_b4

    :cond_c0
    iput-boolean v2, p0, Landroidx/compose/ui/node/LayoutNode;->V:Z

    :goto_c2
    if-eqz v7, :cond_ce

    iget-boolean v3, v7, Ls7c;->R:Z

    if-eqz v3, :cond_cb

    invoke-virtual {v7}, Ls7c;->g1()V

    :cond_cb
    iget-object v7, v7, Ls7c;->I:Ls7c;

    goto :goto_c2

    :cond_ce
    move-object v3, v0

    check-cast v3, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getLayoutNodes()Llcc;

    move-result-object v6

    iget v7, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v6, v7}, Llcc;->g(I)Ljava/lang/Object;

    iget-object v6, v3, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    iget-object v7, v6, Lilb;->b:Lhk0;

    iget-object v8, v7, Lhk0;->E:Ljava/lang/Object;

    check-cast v8, Lxs5;

    invoke-virtual {v8, p0}, Lxs5;->H(Landroidx/compose/ui/node/LayoutNode;)Z

    iget-object v8, v7, Lhk0;->F:Ljava/lang/Object;

    check-cast v8, Lxs5;

    invoke-virtual {v8, p0}, Lxs5;->H(Landroidx/compose/ui/node/LayoutNode;)Z

    iget-object v7, v7, Lhk0;->G:Ljava/lang/Object;

    check-cast v7, Lxs5;

    invoke-virtual {v7, p0}, Lxs5;->H(Landroidx/compose/ui/node/LayoutNode;)Z

    iget-object v6, v6, Lilb;->e:Li47;

    iget-object v6, v6, Li47;->F:Ljava/lang/Object;

    check-cast v6, Ljec;

    invoke-virtual {v6, p0}, Ljec;->k(Ljava/lang/Object;)Z

    iput-boolean v5, v3, Landroidx/compose/ui/platform/AndroidComposeView;->v0:Z

    iget-object v5, v3, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz v5, :cond_115

    iget-object v6, v5, Li00;->L:Lmcc;

    iget v7, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v6, v7}, Lmcc;->f(I)Z

    move-result v6

    if-eqz v6, :cond_115

    iget-object v6, v5, Li00;->E:Ld3f;

    iget-object v5, v5, Li00;->G:Landroidx/compose/ui/platform/AndroidComposeView;

    iget v7, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v6, v5, v7, v2}, Ld3f;->z(Landroid/view/View;IZ)V

    :cond_115
    invoke-interface {v0}, Landroidx/compose/ui/node/Owner;->getRectManager()Lswe;

    move-result-object v5

    invoke-virtual {v5, p0}, Lswe;->g(Landroidx/compose/ui/node/LayoutNode;)V

    iput-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    invoke-virtual {p0, v1}, Landroidx/compose/ui/node/LayoutNode;->A0(Landroidx/compose/ui/node/LayoutNode;)V

    iput v2, p0, Landroidx/compose/ui/node/LayoutNode;->U:I

    iget-object v5, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v6, v5, Ld8a;->p:Lmlb;

    const v7, 0x7fffffff

    iput v7, v6, Lmlb;->M:I

    iput v7, v6, Lmlb;->L:I

    iput-boolean v2, v6, Lmlb;->X:Z

    iget-object v5, v5, Ld8a;->q:Lsza;

    if-eqz v5, :cond_13c

    iput v7, v5, Lsza;->M:I

    iput v7, v5, Lsza;->L:I

    sget-object v6, Lqza;->G:Lqza;

    iput-object v6, v5, Lsza;->V:Lqza;

    :cond_13c
    const/16 v5, 0x8

    invoke-virtual {v4, v5}, Lxmc;->i(I)Z

    move-result v4

    if-eqz v4, :cond_154

    iget-object v4, p0, Landroidx/compose/ui/node/LayoutNode;->X:Lhag;

    iput-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->X:Lhag;

    iput-boolean v2, p0, Landroidx/compose/ui/node/LayoutNode;->W:Z

    invoke-interface {v0}, Landroidx/compose/ui/node/Owner;->getSemanticsOwner()Lqag;

    move-result-object v0

    invoke-virtual {v0, p0, v4}, Lqag;->b(Landroidx/compose/ui/node/LayoutNode;Lhag;)V

    invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->B()V

    :cond_154
    return-void
.end method

.method public final h0(III)V
    .registers 10

    if-ne p1, p2, :cond_3

    return-void

    :cond_3
    const/4 v0, 0x0

    :goto_4
    if-ge v0, p3, :cond_35

    if-le p1, p2, :cond_b

    add-int v1, p1, v0

    goto :goto_c

    :cond_b
    move v1, p1

    :goto_c
    if-le p1, p2, :cond_11

    add-int v2, p2, v0

    goto :goto_15

    :cond_11
    add-int v2, p2, p3

    add-int/lit8 v2, v2, -0x2

    :goto_15
    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object v4, v3, Li47;->F:Ljava/lang/Object;

    check-cast v4, Ljec;

    iget-object v5, v3, Li47;->G:Ljava/lang/Object;

    check-cast v5, Lz7a;

    invoke-virtual {v4, v1}, Ljec;->m(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v5}, Lz7a;->a()Ljava/lang/Object;

    check-cast v1, Landroidx/compose/ui/node/LayoutNode;

    iget-object v3, v3, Li47;->F:Ljava/lang/Object;

    check-cast v3, Ljec;

    invoke-virtual {v3, v2, v1}, Ljec;->a(ILjava/lang/Object;)V

    invoke-virtual {v5}, Lz7a;->a()Ljava/lang/Object;

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_35
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->k0()V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->V()V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->S()V

    return-void
.end method

.method public final i()V
    .registers 8

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->W()Z

    move-result v0

    if-nez v0, :cond_b

    const-string v0, "onReuse is only expected on attached node"

    invoke-static {v0}, Ldf9;->a(Ljava/lang/String;)V

    :cond_b
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->T:Lhmj;

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Lx80;->i()V

    :cond_12
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->l0:Lm8a;

    const/4 v1, 0x0

    if-eqz v0, :cond_1a

    invoke-virtual {v0, v1}, Lm8a;->j(Z)V

    :cond_1a
    iput-boolean v1, p0, Landroidx/compose/ui/node/LayoutNode;->Y:Z

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    iget-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v0, :cond_25

    iput-boolean v1, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    goto :goto_4f

    :cond_25
    iget-object v0, v2, Lxmc;->J:Ljava/lang/Object;

    check-cast v0, Lhzh;

    move-object v3, v0

    :goto_2a
    if-eqz v3, :cond_36

    iget-boolean v4, v3, Ls7c;->R:Z

    if-eqz v4, :cond_33

    invoke-virtual {v3}, Ls7c;->k1()V

    :cond_33
    iget-object v3, v3, Ls7c;->I:Ls7c;

    goto :goto_2a

    :cond_36
    move-object v3, v0

    :goto_37
    if-eqz v3, :cond_43

    iget-boolean v4, v3, Ls7c;->R:Z

    if-eqz v4, :cond_40

    invoke-virtual {v3}, Ls7c;->m1()V

    :cond_40
    iget-object v3, v3, Ls7c;->I:Ls7c;

    goto :goto_37

    :cond_43
    :goto_43
    if-eqz v0, :cond_4f

    iget-boolean v3, v0, Ls7c;->R:Z

    if-eqz v3, :cond_4c

    invoke-virtual {v0}, Ls7c;->g1()V

    :cond_4c
    iget-object v0, v0, Ls7c;->I:Ls7c;

    goto :goto_43

    :cond_4f
    :goto_4f
    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v3, :cond_5e

    invoke-interface {v3}, Landroidx/compose/ui/node/Owner;->getRectManager()Lswe;

    move-result-object v3

    if-eqz v3, :cond_5e

    invoke-virtual {v3, p0}, Lswe;->g(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_5e
    sget-object v3, Lkag;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    iput v3, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    iget-object v3, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v3, :cond_7d

    check-cast v3, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getLayoutNodes()Llcc;

    move-result-object v5

    invoke-virtual {v5, v0}, Llcc;->g(I)Ljava/lang/Object;

    invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getLayoutNodes()Llcc;

    move-result-object v3

    iget v5, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v3, v5, p0}, Llcc;->i(ILjava/lang/Object;)V

    :cond_7d
    iget-object v3, v2, Lxmc;->K:Ljava/lang/Object;

    check-cast v3, Ls7c;

    :goto_81
    if-eqz v3, :cond_89

    invoke-virtual {v3}, Ls7c;->f1()V

    iget-object v3, v3, Ls7c;->J:Ls7c;

    goto :goto_81

    :cond_89
    invoke-virtual {v2}, Lxmc;->j()V

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Lxmc;->i(I)Z

    move-result v2

    if-eqz v2, :cond_97

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->U()V

    :cond_97
    invoke-static {p0}, Landroidx/compose/ui/node/LayoutNode;->v0(Landroidx/compose/ui/node/LayoutNode;)V

    iget-object v2, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v2, :cond_cd

    check-cast v2, Landroidx/compose/ui/platform/AndroidComposeView;

    iget-object v2, v2, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz v2, :cond_cd

    iget-object v3, v2, Li00;->G:Landroidx/compose/ui/platform/AndroidComposeView;

    iget-object v5, v2, Li00;->E:Ld3f;

    iget-object v2, v2, Li00;->L:Lmcc;

    invoke-virtual {v2, v0}, Lmcc;->f(I)Z

    move-result v6

    if-eqz v6, :cond_b3

    invoke-virtual {v5, v3, v0, v1}, Ld3f;->z(Landroid/view/View;IZ)V

    :cond_b3
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->H()Lhag;

    move-result-object v0

    if-eqz v0, :cond_cd

    iget-object v0, v0, Lhag;->E:Lrdc;

    sget-object v1, Lrag;->r:Luag;

    invoke-virtual {v0, v1}, Lrdc;->b(Ljava/lang/Object;)Z

    move-result v0

    if-ne v0, v4, :cond_cd

    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v2, v0}, Lmcc;->a(I)Z

    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v5, v3, v0, v4}, Ld3f;->z(Landroid/view/View;IZ)V

    :cond_cd
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v0, :cond_da

    invoke-interface {v0}, Landroidx/compose/ui/node/Owner;->getRectManager()Lswe;

    move-result-object v0

    if-eqz v0, :cond_da

    invoke-virtual {v0, p0}, Lswe;->f(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_da
    return-void
.end method

.method public final i0(Landroidx/compose/ui/node/LayoutNode;)V
    .registers 6

    iget-object v0, p1, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget v0, v0, Ld8a;->l:I

    if-lez v0, :cond_f

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget v1, v0, Ld8a;->l:I

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ld8a;->d(I)V

    :cond_f
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v0, :cond_16

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->h()V

    :cond_16
    const/4 v0, 0x0

    iput-object v0, p1, Landroidx/compose/ui/node/LayoutNode;->R:Landroidx/compose/ui/node/LayoutNode;

    iget v1, p1, Landroidx/compose/ui/node/LayoutNode;->t0:I

    if-lez v1, :cond_24

    iget v1, p0, Landroidx/compose/ui/node/LayoutNode;->t0:I

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p0, v1}, Landroidx/compose/ui/node/LayoutNode;->z0(I)V

    :cond_24
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v1

    iput-object v0, v1, Ldnc;->W:Ldnc;

    iget-boolean v1, p1, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-eqz v1, :cond_4e

    iget v1, p0, Landroidx/compose/ui/node/LayoutNode;->N:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Landroidx/compose/ui/node/LayoutNode;->N:I

    iget-object p1, p1, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object p1, p1, Li47;->F:Ljava/lang/Object;

    check-cast p1, Ljec;

    iget-object v1, p1, Ljec;->E:[Ljava/lang/Object;

    iget p1, p1, Ljec;->G:I

    const/4 v2, 0x0

    :goto_3f
    if-ge v2, p1, :cond_4e

    aget-object v3, v1, v2

    check-cast v3, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v3}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v3

    iput-object v0, v3, Ldnc;->W:Ldnc;

    add-int/lit8 v2, v2, 0x1

    goto :goto_3f

    :cond_4e
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->V()V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->k0()V

    return-void
.end method

.method public final j()V
    .registers 10

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, v0, Ld8a;->d:Lv7a;

    sget-object v1, Lv7a;->I:Lv7a;

    if-ne v0, v1, :cond_8e

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->t()Z

    move-result v0

    if-nez v0, :cond_8e

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->A()Z

    move-result v0

    if-nez v0, :cond_8e

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-eqz v0, :cond_1a

    goto/16 :goto_8e

    :cond_1a
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result v0

    if-nez v0, :cond_22

    goto/16 :goto_8e

    :cond_22
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object p0, p0, Lxmc;->K:Ljava/lang/Object;

    check-cast p0, Ls7c;

    iget v0, p0, Ls7c;->H:I

    const/16 v1, 0x100

    and-int/2addr v0, v1

    if-eqz v0, :cond_8e

    :goto_2f
    if-eqz p0, :cond_8e

    iget v0, p0, Ls7c;->G:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_86

    const/4 v0, 0x0

    move-object v2, p0

    move-object v3, v0

    :goto_39
    if-eqz v2, :cond_86

    instance-of v4, v2, Lji8;

    if-eqz v4, :cond_49

    check-cast v2, Lji8;

    invoke-static {v2, v1}, La60;->O(Lp46;I)Ldnc;

    move-result-object v4

    invoke-interface {v2, v4}, Lji8;->n0(Ldnc;)V

    goto :goto_81

    :cond_49
    iget v4, v2, Ls7c;->G:I

    and-int/2addr v4, v1

    if-eqz v4, :cond_81

    instance-of v4, v2, Ls46;

    if-eqz v4, :cond_81

    move-object v4, v2

    check-cast v4, Ls46;

    iget-object v4, v4, Ls46;->T:Ls7c;

    const/4 v5, 0x0

    move v6, v5

    :goto_59
    const/4 v7, 0x1

    if-eqz v4, :cond_7e

    iget v8, v4, Ls7c;->G:I

    and-int/2addr v8, v1

    if-eqz v8, :cond_7b

    add-int/lit8 v6, v6, 0x1

    if-ne v6, v7, :cond_67

    move-object v2, v4

    goto :goto_7b

    :cond_67
    if-nez v3, :cond_72

    new-instance v3, Ljec;

    const/16 v7, 0x10

    new-array v7, v7, [Ls7c;

    invoke-direct {v3, v5, v7}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_72
    if-eqz v2, :cond_78

    invoke-virtual {v3, v2}, Ljec;->b(Ljava/lang/Object;)V

    move-object v2, v0

    :cond_78
    invoke-virtual {v3, v4}, Ljec;->b(Ljava/lang/Object;)V

    :cond_7b
    :goto_7b
    iget-object v4, v4, Ls7c;->J:Ls7c;

    goto :goto_59

    :cond_7e
    if-ne v6, v7, :cond_81

    goto :goto_39

    :cond_81
    :goto_81
    invoke-static {v3}, La60;->l(Ljec;)Ls7c;

    move-result-object v2

    goto :goto_39

    :cond_86
    iget v0, p0, Ls7c;->H:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_8e

    iget-object p0, p0, Ls7c;->J:Ls7c;

    goto :goto_2f

    :cond_8e
    :goto_8e
    return-void
.end method

.method public final j0(Ldnc;)V
    .registers 12

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v0, :cond_9

    invoke-interface {v0}, Landroidx/compose/ui/node/Owner;->getRectManager()Lswe;

    move-result-object v0

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    iget-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v1, v1, Ld8a;->d:Lv7a;

    sget-object v2, Lv7a;->I:Lv7a;

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ne v1, v2, :cond_23

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->A()Z

    move-result v1

    if-nez v1, :cond_23

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->t()Z

    move-result v1

    if-eqz v1, :cond_21

    goto :goto_23

    :cond_21
    move v1, v3

    goto :goto_24

    :cond_23
    :goto_23
    move v1, v4

    :goto_24
    iget-boolean v2, p0, Landroidx/compose/ui/node/LayoutNode;->K:Z

    if-eqz v2, :cond_8a

    if-eqz v0, :cond_8a

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v2

    if-ne p1, v2, :cond_38

    iput-boolean v4, p0, Landroidx/compose/ui/node/LayoutNode;->J:Z

    if-nez v1, :cond_8a

    invoke-virtual {v0, p0}, Lswe;->f(Landroidx/compose/ui/node/LayoutNode;)V

    goto :goto_8a

    :cond_38
    iput-boolean v4, p0, Landroidx/compose/ui/node/LayoutNode;->I:Z

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p1

    iget-object v2, p1, Ljec;->E:[Ljava/lang/Object;

    iget p1, p1, Ljec;->G:I

    move v5, v3

    :goto_43
    if-ge v5, p1, :cond_53

    aget-object v6, v2, v5

    check-cast v6, Landroidx/compose/ui/node/LayoutNode;

    iput-boolean v4, v6, Landroidx/compose/ui/node/LayoutNode;->J:Z

    if-nez v1, :cond_50

    invoke-virtual {v0, v6}, Lswe;->f(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_50
    add-int/lit8 v5, v5, 0x1

    goto :goto_43

    :cond_53
    iget-boolean p1, p0, Landroidx/compose/ui/node/LayoutNode;->K:Z

    if-eqz p1, :cond_87

    iput-boolean v4, v0, Lswe;->e:Z

    iget-object p1, v0, Lswe;->b:Lbr4;

    iget v1, p0, Landroidx/compose/ui/node/LayoutNode;->F:I

    const v2, 0x1ffffff

    and-int/2addr v1, v2

    iget-object v4, p1, Lbr4;->c:Ljava/lang/Object;

    check-cast v4, [J

    iget p1, p1, Lbr4;->b:I

    :goto_67
    array-length v5, v4

    add-int/lit8 v5, v5, -0x2

    if-ge v3, v5, :cond_87

    if-ge v3, p1, :cond_87

    add-int/lit8 v5, v3, 0x2

    aget-wide v6, v4, v5

    long-to-int v8, v6

    and-int/2addr v8, v2

    if-ne v8, v1, :cond_84

    const/16 p1, 0x3f

    shr-long v1, v6, p1

    const-wide/16 v8, 0x1

    and-long/2addr v1, v8

    const/16 p1, 0x3c

    shl-long/2addr v1, p1

    or-long/2addr v1, v6

    aput-wide v1, v4, v5

    goto :goto_87

    :cond_84
    add-int/lit8 v3, v3, 0x3

    goto :goto_67

    :cond_87
    :goto_87
    invoke-virtual {v0}, Lswe;->i()V

    :cond_8a
    :goto_8a
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    invoke-virtual {p0}, Lmlb;->w0()V

    return-void
.end method

.method public final k(Lmi2;Lql8;)V
    .registers 4

    :try_start_0
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Ldnc;->X0(Lmi2;Lql8;)V
    :try_end_7
    .catchall {:try_start_0 .. :try_end_7} :catchall_8

    return-void

    :catchall_8
    move-exception p1

    invoke-virtual {p0, p1}, Landroidx/compose/ui/node/LayoutNode;->x0(Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final k0()V
    .registers 2

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p0

    if-eqz p0, :cond_d

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->k0()V

    :cond_d
    return-void

    :cond_e
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->a0:Z

    return-void
.end method

.method public final l0()V
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    sget-object v1, Lx7a;->G:Lx7a;

    if-ne v0, v1, :cond_9

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->f()V

    :cond_9
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_1b

    iget-object v0, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v0, v0, Lxmc;->H:Ljava/lang/Object;

    check-cast v0, Lkg9;

    if-eqz v0, :cond_1b

    iget-object v0, v0, Lmza;->P:Lnza;

    if-nez v0, :cond_23

    :cond_1b
    invoke-static {p0}, Lc8a;->a(Landroidx/compose/ui/node/LayoutNode;)Landroidx/compose/ui/node/Owner;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/ui/node/Owner;->getPlacementScope()Ldmd;

    move-result-object v0

    :cond_23
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    const/4 v1, 0x0

    invoke-static {v0, p0, v1, v1}, Ldmd;->k(Ldmd;Lemd;II)V

    return-void
.end method

.method public final m()V
    .registers 4

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_a

    invoke-static {p0, v2, v1}, Landroidx/compose/ui/node/LayoutNode;->s0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    goto :goto_d

    :cond_a
    invoke-static {p0, v2, v1}, Landroidx/compose/ui/node/LayoutNode;->u0(Landroidx/compose/ui/node/LayoutNode;ZI)V

    :goto_d
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, v0, Ld8a;->p:Lmlb;

    iget-boolean v1, v0, Lmlb;->N:Z

    if-eqz v1, :cond_1d

    iget-wide v0, v0, Lemd;->H:J

    new-instance v2, Lj35;

    invoke-direct {v2, v0, v1}, Lj35;-><init>(J)V

    goto :goto_1e

    :cond_1d
    const/4 v2, 0x0

    :goto_1e
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v2, :cond_2c

    if-eqz v0, :cond_34

    iget-wide v1, v2, Lj35;->a:J

    check-cast v0, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v0, p0, v1, v2}, Landroidx/compose/ui/platform/AndroidComposeView;->v(Landroidx/compose/ui/node/LayoutNode;J)V

    return-void

    :cond_2c
    if-eqz v0, :cond_34

    const/4 p0, 0x1

    check-cast v0, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v0, p0}, Landroidx/compose/ui/platform/AndroidComposeView;->u(Z)V

    :cond_34
    return-void
.end method

.method public final m0(Lj35;)Z
    .registers 4

    if-eqz p1, :cond_16

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    sget-object v1, Lx7a;->G:Lx7a;

    if-ne v0, v1, :cond_b

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->e()V

    :cond_b
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget-wide v0, p1, Lj35;->a:J

    invoke-virtual {p0, v0, v1}, Lmlb;->u0(J)Z

    move-result p0

    return p0

    :cond_16
    const/4 p0, 0x0

    return p0
.end method

.method public final n()Z
    .registers 3

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v0, p0, Ld8a;->p:Lmlb;

    iget-object v0, v0, Lmlb;->c0:La8a;

    invoke-virtual {v0}, La8a;->e()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_1e

    iget-object p0, p0, Ld8a;->q:Lsza;

    if-eqz p0, :cond_1c

    iget-object p0, p0, Lsza;->W:La8a;

    if-eqz p0, :cond_1c

    invoke-virtual {p0}, La8a;->e()Z

    move-result p0

    if-ne p0, v1, :cond_1c

    goto :goto_1e

    :cond_1c
    const/4 p0, 0x0

    return p0

    :cond_1e
    :goto_1e
    return v1
.end method

.method public final o()Ljava/util/List;
    .registers 10

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->q:Lsza;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lsza;->X:Ljec;

    iget-object v1, p0, Lsza;->J:Ld8a;

    iget-object v2, v1, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v2}, Landroidx/compose/ui/node/LayoutNode;->getChildren$ui()Ljava/util/List;

    iget-boolean v2, p0, Lsza;->Y:Z

    if-nez v2, :cond_19

    invoke-virtual {v0}, Ljec;->g()Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_19
    iget-object v1, v1, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v1}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object v2

    iget-object v3, v2, Ljec;->E:[Ljava/lang/Object;

    iget v2, v2, Ljec;->G:I

    const/4 v4, 0x0

    move v5, v4

    :goto_25
    if-ge v5, v2, :cond_4a

    aget-object v6, v3, v5

    check-cast v6, Landroidx/compose/ui/node/LayoutNode;

    iget v7, v0, Ljec;->G:I

    if-gt v7, v5, :cond_3a

    iget-object v6, v6, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v6, v6, Ld8a;->q:Lsza;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v6}, Ljec;->b(Ljava/lang/Object;)V

    goto :goto_47

    :cond_3a
    iget-object v6, v6, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v6, v6, Ld8a;->q:Lsza;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v0, Ljec;->E:[Ljava/lang/Object;

    aget-object v8, v7, v5

    aput-object v6, v7, v5

    :goto_47
    add-int/lit8 v5, v5, 0x1

    goto :goto_25

    :cond_4a
    invoke-virtual {v1}, Landroidx/compose/ui/node/LayoutNode;->getChildren$ui()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    iget v2, v0, Ljec;->G:I

    invoke-virtual {v0, v1, v2}, Ljec;->n(II)V

    iput-boolean v4, p0, Lsza;->Y:Z

    invoke-virtual {v0}, Ljec;->g()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final o0()V
    .registers 5

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object v1, v0, Li47;->F:Ljava/lang/Object;

    check-cast v1, Ljec;

    iget v1, v1, Ljec;->G:I

    add-int/lit8 v1, v1, -0x1

    :goto_a
    iget-object v2, v0, Li47;->F:Ljava/lang/Object;

    check-cast v2, Ljec;

    const/4 v3, -0x1

    if-ge v3, v1, :cond_1d

    iget-object v2, v2, Ljec;->E:[Ljava/lang/Object;

    aget-object v2, v2, v1

    check-cast v2, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {p0, v2}, Landroidx/compose/ui/node/LayoutNode;->i0(Landroidx/compose/ui/node/LayoutNode;)V

    add-int/lit8 v1, v1, -0x1

    goto :goto_a

    :cond_1d
    invoke-virtual {v2}, Ljec;->h()V

    iget-object p0, v0, Li47;->G:Ljava/lang/Object;

    check-cast p0, Lz7a;

    invoke-virtual {p0}, Lz7a;->a()Ljava/lang/Object;

    return-void
.end method

.method public final p()Ljava/util/List;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    invoke-virtual {p0}, Lmlb;->h0()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final p0(II)V
    .registers 5

    if-ltz p2, :cond_3

    goto :goto_19

    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "count ("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ") must be greater than 0"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldf9;->a(Ljava/lang/String;)V

    :goto_19
    add-int/2addr p2, p1

    add-int/lit8 p2, p2, -0x1

    if-gt p1, p2, :cond_43

    :goto_1e
    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object v1, v0, Li47;->F:Ljava/lang/Object;

    check-cast v1, Ljec;

    iget-object v1, v1, Ljec;->E:[Ljava/lang/Object;

    aget-object v1, v1, p2

    check-cast v1, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {p0, v1}, Landroidx/compose/ui/node/LayoutNode;->i0(Landroidx/compose/ui/node/LayoutNode;)V

    iget-object v1, v0, Li47;->F:Ljava/lang/Object;

    check-cast v1, Ljec;

    invoke-virtual {v1, p2}, Ljec;->m(I)Ljava/lang/Object;

    move-result-object v1

    iget-object v0, v0, Li47;->G:Ljava/lang/Object;

    check-cast v0, Lz7a;

    invoke-virtual {v0}, Lz7a;->a()Ljava/lang/Object;

    check-cast v1, Landroidx/compose/ui/node/LayoutNode;

    if-eq p2, p1, :cond_43

    add-int/lit8 p2, p2, -0x1

    goto :goto_1e

    :cond_43
    return-void
.end method

.method public final q()Ljava/util/List;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->O:Li47;

    iget-object p0, p0, Li47;->F:Ljava/lang/Object;

    check-cast p0, Ljec;

    invoke-virtual {p0}, Ljec;->g()Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final q0()V
    .registers 9

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    sget-object v1, Lx7a;->G:Lx7a;

    if-ne v0, v1, :cond_9

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->f()V

    :cond_9
    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object v1, p0, Ld8a;->p:Lmlb;

    iget-object p0, v1, Lmlb;->J:Ld8a;

    const/4 v7, 0x0

    const/4 v0, 0x1

    :try_start_11
    iput-boolean v0, v1, Lmlb;->K:Z

    iget-boolean v0, v1, Lmlb;->O:Z

    if-nez v0, :cond_1f

    const-string v0, "replace called on unplaced item"

    invoke-static {v0}, Ldf9;->c(Ljava/lang/String;)V

    goto :goto_1f

    :catchall_1d
    move-exception v0

    goto :goto_40

    :cond_1f
    :goto_1f
    iget-boolean v0, v1, Lmlb;->X:Z

    iget-wide v2, v1, Lmlb;->R:J

    iget v4, v1, Lmlb;->U:F

    iget-object v5, v1, Lmlb;->S:Lc98;

    iget-object v6, v1, Lmlb;->T:Lql8;

    invoke-virtual/range {v1 .. v6}, Lmlb;->r0(JFLc98;Lql8;)V

    if-eqz v0, :cond_3d

    iget-boolean v0, v1, Lmlb;->k0:Z

    if-nez v0, :cond_3d

    iget-object v0, p0, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_3d

    invoke-virtual {v0, v7}, Landroidx/compose/ui/node/LayoutNode;->t0(Z)V
    :try_end_3d
    .catchall {:try_start_11 .. :try_end_3d} :catchall_1d

    :cond_3d
    iput-boolean v7, v1, Lmlb;->K:Z

    return-void

    :goto_40
    :try_start_40
    iget-object p0, p0, Ld8a;->a:Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {p0, v0}, Landroidx/compose/ui/node/LayoutNode;->x0(Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    throw p0
    :try_end_47
    .catchall {:try_start_40 .. :try_end_47} :catchall_47

    :catchall_47
    move-exception v0

    move-object p0, v0

    iput-boolean v7, v1, Lmlb;->K:Z

    throw p0
.end method

.method public final r()I
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget p0, p0, Lemd;->F:I

    return p0
.end method

.method public final r0(Z)V
    .registers 4

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-nez v0, :cond_e

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v0, :cond_e

    const/4 v1, 0x1

    check-cast v0, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v0, p0, v1, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->A(Landroidx/compose/ui/node/LayoutNode;ZZ)V

    :cond_e
    return-void
.end method

.method public final s()Ld8a;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    return-object p0
.end method

.method public final t()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    iget-boolean p0, p0, Lmlb;->a0:Z

    return p0
.end method

.method public final t0(Z)V
    .registers 4

    iget-boolean v0, p0, Landroidx/compose/ui/node/LayoutNode;->E:Z

    if-nez v0, :cond_e

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz v0, :cond_e

    const/4 v1, 0x0

    check-cast v0, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v0, p0, v1, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->A(Landroidx/compose/ui/node/LayoutNode;ZZ)V

    :cond_e
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lolk;->n(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " children: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->getChildren$ui()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " measurePolicy: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/ui/node/LayoutNode;->b0:Lnlb;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " deactivated: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final u()Lv7a;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->d:Lv7a;

    return-object p0
.end method

.method public final v()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-boolean p0, p0, Ld8a;->f:Z

    return p0
.end method

.method public final w()Z
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->W()Z

    move-result p0

    return p0
.end method

.method public final w0()V
    .registers 6

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    iget-object v0, p0, Ljec;->E:[Ljava/lang/Object;

    iget p0, p0, Ljec;->G:I

    const/4 v1, 0x0

    :goto_9
    if-ge v1, p0, :cond_1d

    aget-object v2, v0, v1

    check-cast v2, Landroidx/compose/ui/node/LayoutNode;

    iget-object v3, v2, Landroidx/compose/ui/node/LayoutNode;->i0:Lx7a;

    iput-object v3, v2, Landroidx/compose/ui/node/LayoutNode;->h0:Lx7a;

    sget-object v4, Lx7a;->G:Lx7a;

    if-eq v3, v4, :cond_1a

    invoke-virtual {v2}, Landroidx/compose/ui/node/LayoutNode;->w0()V

    :cond_1a
    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_1d
    return-void
.end method

.method public final x()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-boolean p0, p0, Ld8a;->e:Z

    return p0
.end method

.method public final x0(Ljava/lang/Throwable;)V
    .registers 5

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->g0:Lgw4;

    invoke-static {}, Law4;->a()Lfih;

    move-result-object v1

    check-cast v0, Lnhd;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1}, Lsyi;->P(Lnhd;Ldge;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lzv4;

    if-eqz v0, :cond_1d

    new-instance v1, Lqx3;

    const/16 v2, 0x13

    invoke-direct {v1, v0, v2, p0}, Lqx3;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {p1, v1}, Lzjl;->m(Ljava/lang/Throwable;La98;)Z

    :cond_1d
    throw p1
.end method

.method public final y()Lsza;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->q:Lsza;

    return-object p0
.end method

.method public final y0(Ld76;)V
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/node/LayoutNode;->d0:Ld76;

    invoke-static {v0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_31

    iput-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->d0:Ld76;

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->S()V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    if-eqz p1, :cond_17

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->P()V

    goto :goto_20

    :cond_17
    iget-object p1, p0, Landroidx/compose/ui/node/LayoutNode;->S:Landroidx/compose/ui/node/Owner;

    if-eqz p1, :cond_20

    check-cast p1, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    :cond_20
    :goto_20
    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->Q()V

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object p0, p0, Lxmc;->K:Ljava/lang/Object;

    check-cast p0, Ls7c;

    :goto_29
    if-eqz p0, :cond_31

    invoke-interface {p0}, Lp46;->f()V

    iget-object p0, p0, Ls7c;->J:Ls7c;

    goto :goto_29

    :cond_31
    return-void
.end method

.method public final z()Lmlb;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/node/LayoutNode;->layoutDelegate:Ld8a;

    iget-object p0, p0, Ld8a;->p:Lmlb;

    return-object p0
.end method

.method public final z0(I)V
    .registers 4

    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->t0:I

    if-eq v0, p1, :cond_2a

    if-lez p1, :cond_15

    if-nez v0, :cond_15

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_15

    iget v1, v0, Landroidx/compose/ui/node/LayoutNode;->t0:I

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/node/LayoutNode;->z0(I)V

    :cond_15
    if-nez p1, :cond_28

    iget v0, p0, Landroidx/compose/ui/node/LayoutNode;->t0:I

    if-lez v0, :cond_28

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_28

    iget v1, v0, Landroidx/compose/ui/node/LayoutNode;->t0:I

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/node/LayoutNode;->z0(I)V

    :cond_28
    iput p1, p0, Landroidx/compose/ui/node/LayoutNode;->t0:I

    :cond_2a
    return-void
.end method
