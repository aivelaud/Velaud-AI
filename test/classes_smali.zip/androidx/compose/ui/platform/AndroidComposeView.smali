.class public final Landroidx/compose/ui/platform/AndroidComposeView;
.super Landroid/view/ViewGroup;
.source "SourceFile"

# interfaces
.implements Landroidx/compose/ui/node/Owner;
.implements Lekf;
.implements Landroidx/lifecycle/DefaultLifecycleObserver;
.implements Li3d;
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
.implements Landroid/view/ViewTreeObserver$OnScrollChangedListener;
.implements Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;
.implements Lq28;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000º\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0001\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u00042\u00020\u00052\u00020\u00062\u00020\u00072\u00020\b2\u00020\t2\u00020\u0003:\u0006Ö\u0002Ý\u0001×\u0002J\u000f\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u0011\u0010\u000e\u001a\u0004\u0018\u00010\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u0019\u0010\u0017\u001a\u00020\u00122\b\u0010\u0016\u001a\u0004\u0018\u00010\u0015H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J!\u0010\u001c\u001a\u00020\u00122\u0012\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u00120\u0019¢\u0006\u0004\b\u001c\u0010\u001dJ\u0017\u0010 \u001a\u0004\u0018\u00010\u001f2\u0006\u0010\u001e\u001a\u00020\n¢\u0006\u0004\b \u0010!R+\u0010)\u001a\u00020\u001a2\u0006\u0010\"\u001a\u00020\u001a8B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b#\u0010$\u001a\u0004\b%\u0010&\"\u0004\b\'\u0010(R*\u00103\u001a\u0004\u0018\u00010*8\u0000@\u0000X\u0081\u000e¢\u0006\u0018\n\u0004\b+\u0010,\u0012\u0004\b1\u00102\u001a\u0004\b-\u0010.\"\u0004\b/\u00100R\u001a\u00109\u001a\u0002048\u0016X\u0096\u0004¢\u0006\f\n\u0004\b5\u00106\u001a\u0004\b7\u00108R$\u0010A\u001a\u0004\u0018\u00010:8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b;\u0010<\u001a\u0004\b=\u0010>\"\u0004\b?\u0010@R$\u0010H\u001a\u00020B2\u0006\u0010C\u001a\u00020B8\u0016@RX\u0096\u000e¢\u0006\f\n\u0004\bD\u0010E\u001a\u0004\bF\u0010GR+\u0010O\u001a\u00020I2\u0006\u0010\"\u001a\u00020I8V@RX\u0096\u008e\u0002¢\u0006\u0012\n\u0004\bJ\u0010$\u001a\u0004\bK\u0010L\"\u0004\bM\u0010NR\u001a\u0010U\u001a\u00020P8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bQ\u0010R\u001a\u0004\bS\u0010TR\"\u0010]\u001a\u00020V8\u0016@\u0016X\u0096\u000e¢\u0006\u0012\n\u0004\bW\u0010X\u001a\u0004\bY\u0010Z\"\u0004\b[\u0010\\R\u001a\u0010c\u001a\u00020^8\u0016X\u0096\u0004¢\u0006\f\n\u0004\b_\u0010`\u001a\u0004\ba\u0010bR+\u0010f\u001a\u00020d2\u0006\u0010\"\u001a\u00020d8B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\be\u0010$\u001a\u0004\bf\u0010g\"\u0004\bh\u0010iR\u001b\u0010m\u001a\u00020d8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\bj\u0010k\u001a\u0004\bl\u0010gR\u001a\u0010s\u001a\u00020n8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bo\u0010p\u001a\u0004\bq\u0010rR\u0017\u0010y\u001a\u00020t8\u0006¢\u0006\f\n\u0004\bu\u0010v\u001a\u0004\bw\u0010xR!\u0010\u0080\u0001\u001a\u00020z8\u0016X\u0096\u0004¢\u0006\u0012\n\u0004\b{\u0010|\u0012\u0004\b\u007f\u00102\u001a\u0004\b}\u0010~R&\u0010\u0086\u0001\u001a\t\u0012\u0004\u0012\u00020z0\u0081\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u0082\u0001\u0010\u0083\u0001\u001a\u0006\b\u0084\u0001\u0010\u0085\u0001R \u0010\u008c\u0001\u001a\u00030\u0087\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u0088\u0001\u0010\u0089\u0001\u001a\u0006\b\u008a\u0001\u0010\u008b\u0001R \u0010\u0092\u0001\u001a\u00030\u008d\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u008e\u0001\u0010\u008f\u0001\u001a\u0006\b\u0090\u0001\u0010\u0091\u0001R*\u0010\u009a\u0001\u001a\u00030\u0093\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0018\n\u0006\b\u0094\u0001\u0010\u0095\u0001\u001a\u0006\b\u0096\u0001\u0010\u0097\u0001\"\u0006\b\u0098\u0001\u0010\u0099\u0001R \u0010\u00a0\u0001\u001a\u00030\u009b\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u009c\u0001\u0010\u009d\u0001\u001a\u0006\b\u009e\u0001\u0010\u009f\u0001R \u0010¦\u0001\u001a\u00030¡\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b¢\u0001\u0010£\u0001\u001a\u0006\b¤\u0001\u0010¥\u0001R \u0010¬\u0001\u001a\u00030§\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b¨\u0001\u0010©\u0001\u001a\u0006\bª\u0001\u0010«\u0001R3\u0010³\u0001\u001a\u00030\u00ad\u00012\u0007\u0010\"\u001a\u00030\u00ad\u00018F@FX\u0086\u008e\u0002¢\u0006\u0017\n\u0005\b®\u0001\u0010$\u001a\u0006\b¯\u0001\u0010°\u0001\"\u0006\b±\u0001\u0010²\u0001R \u0010¸\u0001\u001a\u00030´\u00018VX\u0096\u0084\u0002¢\u0006\u000f\n\u0005\bµ\u0001\u0010k\u001a\u0006\b¶\u0001\u0010·\u0001R\"\u0010¾\u0001\u001a\u0005\u0018\u00010¹\u00018\u0000X\u0080\u0004¢\u0006\u0010\n\u0006\bº\u0001\u0010»\u0001\u001a\u0006\b¼\u0001\u0010½\u0001R \u0010Ä\u0001\u001a\u00030¿\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bÀ\u0001\u0010Á\u0001\u001a\u0006\bÂ\u0001\u0010Ã\u0001R \u0010Ê\u0001\u001a\u00030Å\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bÆ\u0001\u0010Ç\u0001\u001a\u0006\bÈ\u0001\u0010É\u0001R \u0010Ð\u0001\u001a\u00030Ë\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bÌ\u0001\u0010Í\u0001\u001a\u0006\bÎ\u0001\u0010Ï\u0001R.\u0010Ö\u0001\u001a\u00020d8V@\u0016X\u0096\u000e¢\u0006\u001d\n\u0006\bÑ\u0001\u0010Ò\u0001\u0012\u0005\bÕ\u0001\u00102\u001a\u0005\bÓ\u0001\u0010g\"\u0005\bÔ\u0001\u0010iR.\u0010Ü\u0001\u001a\u00020\u00108\u0000@\u0000X\u0081\u000e¢\u0006\u001d\n\u0005\b×\u0001\u0010;\u0012\u0005\bÛ\u0001\u00102\u001a\u0006\bØ\u0001\u0010Ù\u0001\"\u0005\bÚ\u0001\u0010\u0014R7\u0010ã\u0001\u001a\u0005\u0018\u00010Ý\u00012\t\u0010\"\u001a\u0005\u0018\u00010Ý\u00018B@BX\u0082\u008e\u0002¢\u0006\u0017\n\u0005\bÞ\u0001\u0010$\u001a\u0006\bß\u0001\u0010à\u0001\"\u0006\bá\u0001\u0010â\u0001R\"\u0010æ\u0001\u001a\u0005\u0018\u00010Ý\u00018FX\u0086\u0084\u0002¢\u0006\u000f\n\u0005\bä\u0001\u0010k\u001a\u0006\bå\u0001\u0010à\u0001R\'\u0010í\u0001\u001a\u00030ç\u00018\u0016X\u0097\u0004¢\u0006\u0017\n\u0006\bè\u0001\u0010é\u0001\u0012\u0005\bì\u0001\u00102\u001a\u0006\bê\u0001\u0010ë\u0001R3\u0010ô\u0001\u001a\u00030î\u00012\u0007\u0010\"\u001a\u00030î\u00018V@RX\u0096\u008e\u0002¢\u0006\u0017\n\u0005\bï\u0001\u0010$\u001a\u0006\bð\u0001\u0010ñ\u0001\"\u0006\bò\u0001\u0010ó\u0001R3\u0010û\u0001\u001a\u00030õ\u00012\u0007\u0010\"\u001a\u00030õ\u00018V@RX\u0096\u008e\u0002¢\u0006\u0017\n\u0005\bö\u0001\u0010$\u001a\u0006\b÷\u0001\u0010ø\u0001\"\u0006\bù\u0001\u0010ú\u0001R \u0010\u0081\u0002\u001a\u00030ü\u00018\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\bý\u0001\u0010þ\u0001\u001a\u0006\bÿ\u0001\u0010\u0080\u0002R \u0010\u0087\u0002\u001a\u00030\u0082\u00028\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u0083\u0002\u0010\u0084\u0002\u001a\u0006\b\u0085\u0002\u0010\u0086\u0002R \u0010\u008d\u0002\u001a\u00030\u0088\u00028\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u0089\u0002\u0010\u008a\u0002\u001a\u0006\b\u008b\u0002\u0010\u008c\u0002R\'\u0010\u0091\u0002\u001a\u00020d8\u0000@\u0000X\u0080\u000e¢\u0006\u0016\n\u0006\b\u008e\u0002\u0010Ò\u0001\u001a\u0005\b\u008f\u0002\u0010g\"\u0005\b\u0090\u0002\u0010iR \u0010\u0097\u0002\u001a\u00030\u0092\u00028\u0016X\u0096\u0004¢\u0006\u0010\n\u0006\b\u0093\u0002\u0010\u0094\u0002\u001a\u0006\b\u0095\u0002\u0010\u0096\u0002R\'\u0010\u009a\u0002\u001a\u00020\u001a2\u0006\u0010C\u001a\u00020\u001a8F@FX\u0086\u000e¢\u0006\u000e\u001a\u0005\b\u0098\u0002\u0010&\"\u0005\b\u0099\u0002\u0010(R\u0017\u0010\u009d\u0002\u001a\u00020\u001f8VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u009b\u0002\u0010\u009c\u0002R\u001f\u0010¢\u0002\u001a\u00030\u009e\u00028VX\u0096\u0004¢\u0006\u000f\u0012\u0005\b¡\u0002\u00102\u001a\u0006\b\u009f\u0002\u0010\u00a0\u0002R\u0018\u0010¦\u0002\u001a\u00030£\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\b¤\u0002\u0010¥\u0002R*\u0010§\u0002\u001a\u0004\u0018\u00010\u00158\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0006\b§\u0002\u0010¨\u0002\u001a\u0006\b©\u0002\u0010ª\u0002\"\u0005\b«\u0002\u0010\u0018R\u001a\u0010¯\u0002\u001a\u0005\u0018\u00010¬\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\b\u00ad\u0002\u0010®\u0002R\u001a\u0010³\u0002\u001a\u0005\u0018\u00010°\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\b±\u0002\u0010²\u0002R\u0018\u0010·\u0002\u001a\u00030´\u00028@X\u0080\u0004¢\u0006\b\u001a\u0006\bµ\u0002\u0010¶\u0002R\u0017\u0010¹\u0002\u001a\u00020\u00108VX\u0096\u0004¢\u0006\b\u001a\u0006\b¸\u0002\u0010Ù\u0001R\u0016\u0010»\u0002\u001a\u00020d8VX\u0096\u0004¢\u0006\u0007\u001a\u0005\bº\u0002\u0010gR\u001f\u0010À\u0002\u001a\u00030¼\u00028VX\u0097\u0004¢\u0006\u000f\u0012\u0005\b¿\u0002\u00102\u001a\u0006\b½\u0002\u0010¾\u0002R\u0018\u0010Ä\u0002\u001a\u00030Á\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\bÂ\u0002\u0010Ã\u0002R\u0018\u0010È\u0002\u001a\u00030Å\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\bÆ\u0002\u0010Ç\u0002R\u0018\u0010Ì\u0002\u001a\u00030É\u00028VX\u0096\u0004¢\u0006\b\u001a\u0006\bÊ\u0002\u0010Ë\u0002R\u0016\u0010Î\u0002\u001a\u00020d8@X\u0080\u0004¢\u0006\u0007\u001a\u0005\bÍ\u0002\u0010gR\u0019\u0010Ñ\u0002\u001a\u0004\u0018\u00010\u00008VX\u0096\u0004¢\u0006\b\u001a\u0006\bÏ\u0002\u0010Ð\u0002R\u0018\u0010Õ\u0002\u001a\u00030Ò\u00028BX\u0082\u0004¢\u0006\b\u001a\u0006\bÓ\u0002\u0010Ô\u0002¨\u0006Ø\u0002"
    }
    d2 = {
        "Landroidx/compose/ui/platform/AndroidComposeView;",
        "Landroid/view/ViewGroup;",
        "Landroidx/compose/ui/node/Owner;",
        "",
        "Landroidx/lifecycle/DefaultLifecycleObserver;",
        "Li3d;",
        "Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;",
        "Landroid/view/ViewTreeObserver$OnScrollChangedListener;",
        "Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;",
        "Lq28;",
        "",
        "getImportantForAutofill",
        "()I",
        "Lqwe;",
        "getEmbeddedViewFocusRect",
        "()Lqwe;",
        "",
        "intervalMillis",
        "Lz2j;",
        "setAccessibilityEventBatchIntervalMillis",
        "(J)V",
        "Ldkf;",
        "handler",
        "setUncaughtExceptionHandler",
        "(Ldkf;)V",
        "Lkotlin/Function1;",
        "Lvu4;",
        "callback",
        "setOnReadyForComposition",
        "(Lc98;)V",
        "accessibilityId",
        "Landroid/view/View;",
        "findViewByAccessibilityIdTraversal",
        "(I)Landroid/view/View;",
        "<set-?>",
        "E",
        "Laec;",
        "get_composeViewContext",
        "()Lvu4;",
        "set_composeViewContext",
        "(Lvu4;)V",
        "_composeViewContext",
        "Lod9;",
        "H",
        "Lod9;",
        "getPrimaryDirectionalMotionAxisOverride-dqNNBbU$ui",
        "()Lod9;",
        "setPrimaryDirectionalMotionAxisOverride-r2epLt8$ui",
        "(Lod9;)V",
        "getPrimaryDirectionalMotionAxisOverride-dqNNBbU$ui$annotations",
        "()V",
        "primaryDirectionalMotionAxisOverride",
        "Lb8a;",
        "I",
        "Lb8a;",
        "getSharedDrawScope",
        "()Lb8a;",
        "sharedDrawScope",
        "Lnha;",
        "J",
        "Lnha;",
        "getFrameEndScheduler$ui",
        "()Lnha;",
        "setFrameEndScheduler$ui",
        "(Lnha;)V",
        "frameEndScheduler",
        "Lhgf;",
        "value",
        "L",
        "Lhgf;",
        "getRetainedValuesStore",
        "()Lhgf;",
        "retainedValuesStore",
        "Ld76;",
        "O",
        "getDensity",
        "()Ld76;",
        "setDensity",
        "(Ld76;)V",
        "density",
        "Ls28;",
        "Q",
        "Ls28;",
        "getFocusOwner",
        "()Ls28;",
        "focusOwner",
        "Lla5;",
        "R",
        "Lla5;",
        "getCoroutineContext",
        "()Lla5;",
        "setCoroutineContext",
        "(Lla5;)V",
        "coroutineContext",
        "Ly20;",
        "S",
        "Ly20;",
        "getDragAndDropManager",
        "()Ly20;",
        "dragAndDropManager",
        "",
        "U",
        "isAttached",
        "()Z",
        "setAttached",
        "(Z)V",
        "V",
        "Lghh;",
        "getDerivedIsAttached",
        "derivedIsAttached",
        "Likj;",
        "a0",
        "Likj;",
        "getViewConfiguration",
        "()Likj;",
        "viewConfiguration",
        "Luh9;",
        "b0",
        "Luh9;",
        "getInsetsListener",
        "()Luh9;",
        "insetsListener",
        "Landroidx/compose/ui/node/LayoutNode;",
        "c0",
        "Landroidx/compose/ui/node/LayoutNode;",
        "getRoot",
        "()Landroidx/compose/ui/node/LayoutNode;",
        "getRoot$annotations",
        "root",
        "Llcc;",
        "d0",
        "Llcc;",
        "getLayoutNodes",
        "()Llcc;",
        "layoutNodes",
        "Lswe;",
        "e0",
        "Lswe;",
        "getRectManager",
        "()Lswe;",
        "rectManager",
        "Lqag;",
        "f0",
        "Lqag;",
        "getSemanticsOwner",
        "()Lqag;",
        "semanticsOwner",
        "Lc20;",
        "h0",
        "Lc20;",
        "getContentCaptureManager$ui",
        "()Lc20;",
        "setContentCaptureManager$ui",
        "(Lc20;)V",
        "contentCaptureManager",
        "Ld00;",
        "i0",
        "Ld00;",
        "getAccessibilityManager",
        "()Ld00;",
        "accessibilityManager",
        "Lnl8;",
        "j0",
        "Lnl8;",
        "getGraphicsContext",
        "()Lnl8;",
        "graphicsContext",
        "Lrc1;",
        "k0",
        "Lrc1;",
        "getAutofillTree",
        "()Lrc1;",
        "autofillTree",
        "Landroid/content/res/Configuration;",
        "r0",
        "getConfiguration",
        "()Landroid/content/res/Configuration;",
        "setConfiguration",
        "(Landroid/content/res/Configuration;)V",
        "configuration",
        "Lrra;",
        "s0",
        "getLocaleList",
        "()Lrra;",
        "localeList",
        "Li00;",
        "u0",
        "Li00;",
        "get_autofillManager$ui",
        "()Li00;",
        "_autofillManager",
        "Lp00;",
        "w0",
        "Lp00;",
        "getClipboardManager",
        "()Lp00;",
        "clipboardManager",
        "Lo00;",
        "x0",
        "Lo00;",
        "getClipboard",
        "()Lo00;",
        "clipboard",
        "Lb5d;",
        "y0",
        "Lb5d;",
        "getSnapshotObserver",
        "()Lb5d;",
        "snapshotObserver",
        "z0",
        "Z",
        "getShowLayoutBounds",
        "setShowLayoutBounds",
        "getShowLayoutBounds$annotations",
        "showLayoutBounds",
        "J0",
        "getLastMatrixRecalculationAnimationTime$ui",
        "()J",
        "setLastMatrixRecalculationAnimationTime$ui",
        "getLastMatrixRecalculationAnimationTime$ui$annotations",
        "lastMatrixRecalculationAnimationTime",
        "Lw00;",
        "M0",
        "get_viewTreeOwners",
        "()Lw00;",
        "set_viewTreeOwners",
        "(Lw00;)V",
        "_viewTreeOwners",
        "N0",
        "getViewTreeOwners",
        "viewTreeOwners",
        "Lt38;",
        "T0",
        "Lt38;",
        "getFontLoader",
        "()Lt38;",
        "getFontLoader$annotations",
        "fontLoader",
        "Ly38;",
        "U0",
        "getFontFamilyResolver",
        "()Ly38;",
        "setFontFamilyResolver",
        "(Ly38;)V",
        "fontFamilyResolver",
        "Lf7a;",
        "V0",
        "getLayoutDirection",
        "()Lf7a;",
        "setLayoutDirection",
        "(Lf7a;)V",
        "layoutDirection",
        "Lzq8;",
        "W0",
        "Lzq8;",
        "getHapticFeedBack",
        "()Lzq8;",
        "hapticFeedBack",
        "Lw7c;",
        "Y0",
        "Lw7c;",
        "getModifierLocalManager",
        "()Lw7c;",
        "modifierLocalManager",
        "Llai;",
        "Z0",
        "Llai;",
        "getTextToolbar",
        "()Llai;",
        "textToolbar",
        "n1",
        "getComposeViewContextIncrementedDuringInit$ui",
        "setComposeViewContextIncrementedDuringInit$ui",
        "composeViewContextIncrementedDuringInit",
        "Lbrd;",
        "q1",
        "Lbrd;",
        "getPointerIconService",
        "()Lbrd;",
        "pointerIconService",
        "getComposeViewContext",
        "setComposeViewContext",
        "composeViewContext",
        "getView",
        "()Landroid/view/View;",
        "view",
        "Ly2k;",
        "getWindowInfo",
        "()Ly2k;",
        "getWindowInfo$annotations",
        "windowInfo",
        "Lekf;",
        "getRootForTest",
        "()Lekf;",
        "rootForTest",
        "uncaughtExceptionHandler",
        "Ldkf;",
        "getUncaughtExceptionHandler$ui",
        "()Ldkf;",
        "setUncaughtExceptionHandler$ui",
        "Llc1;",
        "getAutofill",
        "()Llc1;",
        "autofill",
        "Lqc1;",
        "getAutofillManager",
        "()Lqc1;",
        "autofillManager",
        "Lc90;",
        "getAndroidViewsHandler$ui",
        "()Lc90;",
        "androidViewsHandler",
        "getMeasureIteration",
        "measureIteration",
        "getHasPendingMeasureOrLayout",
        "hasPendingMeasureOrLayout",
        "Lz8i;",
        "getTextInputService",
        "()Lz8i;",
        "getTextInputService$annotations",
        "textInputService",
        "Li8h;",
        "getSoftwareKeyboardController",
        "()Li8h;",
        "softwareKeyboardController",
        "Ldmd;",
        "getPlacementScope",
        "()Ldmd;",
        "placementScope",
        "Lyg9;",
        "getInputModeManager",
        "()Lyg9;",
        "inputModeManager",
        "getScrollCaptureInProgress$ui",
        "scrollCaptureInProgress",
        "getOutOfFrameExecutor",
        "()Landroidx/compose/ui/platform/AndroidComposeView;",
        "outOfFrameExecutor",
        "Lb9i;",
        "getLegacyTextInputServiceAndroid",
        "()Lb9i;",
        "legacyTextInputServiceAndroid",
        "ezg",
        "v00",
        "ui"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static r1:Ljava/lang/Class;

.field public static s1:Ljava/lang/reflect/Method;

.field public static t1:Ljava/lang/reflect/Method;

.field public static final u1:Lddc;

.field public static v1:Ls00;

.field public static w1:Ljava/lang/reflect/Method;


# instance fields
.field public A0:Lc90;

.field public B0:Lj35;

.field public C0:Z

.field public final D0:Lilb;

.field public final E:Ltad;

.field public E0:J

.field public F:J

.field public final F0:[I

.field public final G:Z

.field public final G0:[F

.field public H:Lod9;

.field public final H0:[F

.field public final I:Lb8a;

.field public final I0:[F

.field public J:Lnha;

.field public J0:J

.field public K:Loha;

.field public K0:Z

.field public L:Lhgf;

.field public L0:J

.field public final M:Lqq0;

.field public final M0:Ltad;

.field public final N:Lq00;

.field public final N0:Ly76;

.field public final O:Ltad;

.field public O0:Lc98;

.field public final P:Landroid/view/View;

.field public P0:Lb9i;

.field public final Q:Lu28;

.field public Q0:Lz8i;

.field public R:Lla5;

.field public final R0:Ljava/util/concurrent/atomic/AtomicReference;

.field public final S:Ly20;

.field public S0:Lf56;

.field public final T:Ltea;

.field public final T0:Lt38;

.field public final U:Ltad;

.field public final U0:Laec;

.field public final V:Ly76;

.field public final V0:Ltad;

.field public final W:Lpi2;

.field public final W0:Lzq8;

.field public final X0:Lzg9;

.field public final Y0:Lw7c;

.field public final Z0:Ld80;

.field public final a0:Lo80;

.field public a1:Landroid/view/MotionEvent;

.field public final b0:Luh9;

.field public b1:J

.field public final c0:Landroidx/compose/ui/node/LayoutNode;

.field public final c1:Lrpf;

.field public final d0:Llcc;

.field public final d1:Lddc;

.field public final e0:Lswe;

.field public e1:F

.field public final f0:Lqag;

.field public f1:F

.field public final g0:Lm10;

.field public final g1:Lm;

.field public h0:Lc20;

.field public final h1:Lq00;

.field public final i0:Ld00;

.field public i1:Z

.field public final j0:Lr30;

.field public final j1:Lzd9;

.field public final k0:Lrc1;

.field public final k1:Ly00;

.field public final l0:Lddc;

.field public final l1:Lod2;

.field public m0:Lddc;

.field public m1:Z

.field public n0:Z

.field public n1:Z

.field public o0:Z

.field public final o1:Ld3f;

.field public final p0:Lf9c;

.field public p1:Landroid/view/View;

.field public final q0:Li70;

.field public final q1:Ld10;

.field public final r0:Ltad;

.field public final s0:Ly76;

.field public final t0:Ltfg;

.field public final u0:Li00;

.field public v0:Z

.field public final w0:Lp00;

.field public final x0:Lo00;

.field public final y0:Lb5d;

.field public z0:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lddc;

    invoke-direct {v0}, Lddc;-><init>()V

    sput-object v0, Landroidx/compose/ui/platform/AndroidComposeView;->u1:Lddc;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lvu4;)V
    .registers 18

    move-object/from16 v8, p1

    move-object/from16 v9, p2

    invoke-direct/range {p0 .. p1}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V

    invoke-static {v9}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->E:Ltad;

    const-wide v0, 0x7fc000007fc00000L  # 2.247117487993712E307

    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->F:J

    const/4 v10, 0x1

    iput-boolean v10, p0, Landroidx/compose/ui/platform/AndroidComposeView;->G:Z

    iget-object v0, v9, Lvu4;->r:Lb8a;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->I:Lb8a;

    sget-object v0, Lmx8;->I:Lmx8;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L:Lhgf;

    new-instance v0, Lqq0;

    invoke-direct {v0}, Lqq0;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->M:Lqq0;

    new-instance v0, Lq00;

    const/4 v11, 0x0

    invoke-direct {v0, p0, v11}, Lq00;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->N:Lq00;

    invoke-static {v8}, Lzcj;->c(Landroid/content/Context;)Li76;

    move-result-object v0

    sget-object v1, Luwa;->f0:Luwa;

    new-instance v3, Ltad;

    invoke-direct {v3, v0, v1}, Ltad;-><init>(Ljava/lang/Object;Lm7h;)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->O:Ltad;

    new-instance v0, Lu28;

    invoke-direct {v0, p0, p0}, Lu28;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;Landroidx/compose/ui/platform/AndroidComposeView;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Q:Lu28;

    iget-object v0, v9, Lvu4;->b:Lwv4;

    invoke-virtual {v0}, Lwv4;->k()Lla5;

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->R:Lla5;

    new-instance v0, Ly20;

    new-instance v1, La10;

    invoke-direct {v0}, Ly20;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->S:Ly20;

    new-instance v0, Ltea;

    invoke-direct {v0}, Ltea;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->T:Ltea;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->U:Ltad;

    new-instance v0, Ly00;

    invoke-direct {v0, p0, v11}, Ly00;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    invoke-static {v0}, Lao9;->D(La98;)Ly76;

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->V:Ly76;

    iget-object v0, v9, Lvu4;->t:Lpi2;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->W:Lpi2;

    iget-object v0, v9, Lvu4;->q:Lo80;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->a0:Lo80;

    new-instance v0, Luh9;

    invoke-direct {v0}, Luh9;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->b0:Luh9;

    new-instance v0, Landroidx/compose/ui/node/LayoutNode;

    const/4 v12, 0x3

    invoke-direct {v0, v12}, Landroidx/compose/ui/node/LayoutNode;-><init>(I)V

    sget-object v1, Lfkf;->c:Lfkf;

    invoke-virtual {v0, v1}, Landroidx/compose/ui/node/LayoutNode;->B0(Lnlb;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getDensity()Ld76;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/node/LayoutNode;->y0(Ld76;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getViewConfiguration()Likj;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/node/LayoutNode;->D0(Likj;)V

    new-instance v1, Lf10;

    invoke-direct {v1, p0}, Lf10;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v3

    check-cast v3, Lu28;

    iget-object v3, v3, Lu28;->e:Lt28;

    invoke-interface {v1, v3}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getDragAndDropManager()Ly20;

    move-result-object v3

    iget-object v3, v3, Ly20;->c:Lx20;

    invoke-interface {v1, v3}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/compose/ui/node/LayoutNode;->C0(Lt7c;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->c0:Landroidx/compose/ui/node/LayoutNode;

    sget-object v0, Lpj9;->a:Llcc;

    new-instance v0, Llcc;

    invoke-direct {v0}, Llcc;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d0:Llcc;

    new-instance v0, Lswe;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getLayoutNodes()Llcc;

    invoke-direct {v0, p0}, Lswe;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->e0:Lswe;

    new-instance v0, Lqag;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    new-instance v3, Lfw6;

    invoke-direct {v3}, Ls7c;-><init>()V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getLayoutNodes()Llcc;

    move-result-object v4

    invoke-direct {v0, v1, v3, v4}, Lqag;-><init>(Landroidx/compose/ui/node/LayoutNode;Lfw6;Llcc;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f0:Lqag;

    new-instance v13, Lm10;

    invoke-direct {v13, p0}, Lm10;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;)V

    iput-object v13, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    new-instance v14, Lc20;

    new-instance v0, Ltn;

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v1, 0x0

    const-class v3, Lw10;

    const-string v4, "getContentCaptureSessionCompat"

    const-string v5, "getContentCaptureSessionCompat(Landroid/view/View;)Landroidx/compose/ui/contentcapture/ContentCaptureSessionWrapper;"

    move-object v2, p0

    invoke-direct/range {v0 .. v7}, Ltn;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-direct {v14, p0, v0}, Lc20;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;Ltn;)V

    iput-object v14, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    iget-object v0, v9, Lvu4;->j:Ld00;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->i0:Ld00;

    new-instance v0, Lr30;

    invoke-direct {v0, p0}, Lr30;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->j0:Lr30;

    new-instance v0, Lrc1;

    invoke-direct {v0}, Lrc1;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->k0:Lrc1;

    new-instance v0, Lddc;

    invoke-direct {v0}, Lddc;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->l0:Lddc;

    new-instance v0, Lf9c;

    invoke-direct {v0}, Lf9c;-><init>()V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->p0:Lf9c;

    new-instance v0, Li70;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Li70;->b:Ljava/lang/Object;

    new-instance v3, Luy8;

    iget-object v1, v1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v1, v1, Lxmc;->H:Ljava/lang/Object;

    check-cast v1, Lkg9;

    invoke-direct {v3, v1}, Luy8;-><init>(Lc7a;)V

    iput-object v3, v0, Li70;->c:Ljava/lang/Object;

    new-instance v1, Lxs5;

    const/16 v6, 0x15

    invoke-direct {v1, v6}, Lxs5;-><init>(I)V

    iput-object v1, v0, Li70;->d:Ljava/lang/Object;

    new-instance v1, Lxy8;

    invoke-direct {v1}, Lxy8;-><init>()V

    iput-object v1, v0, Li70;->e:Ljava/lang/Object;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->q0:Li70;

    new-instance v0, Landroid/content/res/Configuration;

    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    invoke-static {v0}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->r0:Ltad;

    new-instance v0, Ly00;

    invoke-direct {v0, p0, v10}, Ly00;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    invoke-static {v0}, Lao9;->D(La98;)Ly76;

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->s0:Ly76;

    new-instance v0, Ltfg;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getAutofillTree()Lrc1;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Ltfg;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;Lrc1;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->t0:Ltfg;

    const-class v0, Landroid/view/autofill/AutofillManager;

    invoke-virtual {v8, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/autofill/AutofillManager;

    if-eqz v0, :cond_306

    new-instance v1, Li00;

    move-object v3, v1

    new-instance v1, Ld3f;

    invoke-direct {v1, v0}, Ld3f;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getSemanticsOwner()Lqag;

    move-result-object v2

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object v4

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    move-object v0, v3

    move-object v3, p0

    invoke-direct/range {v0 .. v5}, Li00;-><init>(Ld3f;Lqag;Landroidx/compose/ui/platform/AndroidComposeView;Lswe;Ljava/lang/String;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    iget-object v0, v9, Lvu4;->l:Lp00;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->w0:Lp00;

    iget-object v0, v9, Lvu4;->m:Lo00;

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->x0:Lo00;

    new-instance v0, Lb5d;

    new-instance v1, Lc10;

    invoke-direct {v1, p0, v10}, Lc10;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    invoke-direct {v0, v1}, Lb5d;-><init>(Lc10;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->y0:Lb5d;

    new-instance v0, Lilb;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    invoke-direct {v0, v1}, Lilb;-><init>(Landroidx/compose/ui/node/LayoutNode;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    const-wide v0, 0x7fffffff7fffffffL

    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->E0:J

    filled-new-array {v11, v11}, [I

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->F0:[I

    invoke-static {}, Lmab;->a()[F

    move-result-object v0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->G0:[F

    invoke-static {}, Lmab;->a()[F

    move-result-object v1

    iput-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->H0:[F

    invoke-static {}, Lmab;->a()[F

    move-result-object v1

    iput-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->I0:[F

    const-wide/16 v3, -0x1

    iput-wide v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    const-wide v3, 0x7f8000007f800000L  # 1.404448428688076E306

    iput-wide v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    const/4 v1, 0x0

    invoke-static {v1}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object v3

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->M0:Ltad;

    new-instance v3, Ly00;

    invoke-direct {v3, p0, v12}, Ly00;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    invoke-static {v3}, Lao9;->D(La98;)Ly76;

    move-result-object v3

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->N0:Ly76;

    new-instance v3, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v3, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->R0:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v3, v9, Lvu4;->n:Lt38;

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->T0:Lt38;

    iget-object v3, v9, Lvu4;->o:Laec;

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->U0:Laec;

    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Configuration;->getLayoutDirection()I

    move-result v3

    sget-object v4, Lo28;->a:[I

    sget-object v4, Lf7a;->E:Lf7a;

    if-eqz v3, :cond_214

    if-eq v3, v10, :cond_211

    move-object v3, v1

    goto :goto_215

    :cond_211
    sget-object v3, Lf7a;->F:Lf7a;

    goto :goto_215

    :cond_214
    move-object v3, v4

    :goto_215
    if-nez v3, :cond_218

    goto :goto_219

    :cond_218
    move-object v4, v3

    :goto_219
    invoke-static {v4}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object v3

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->V0:Ltad;

    iget-object v3, v9, Lvu4;->p:Lzq8;

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->W0:Lzq8;

    new-instance v3, Lzg9;

    invoke-virtual {p0}, Landroid/view/View;->isInTouchMode()Z

    move-result v4

    const/4 v5, 0x2

    if-eqz v4, :cond_22e

    move v4, v10

    goto :goto_22f

    :cond_22e
    move v4, v5

    :goto_22f
    invoke-direct {v3, v4}, Lzg9;-><init>(I)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->X0:Lzg9;

    new-instance v3, Lw7c;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    new-instance v4, Ljec;

    const/16 v7, 0x10

    new-array v9, v7, [Lvg1;

    invoke-direct {v4, v11, v9}, Ljec;-><init>(I[Ljava/lang/Object;)V

    new-instance v4, Ljec;

    new-array v9, v7, [Lfi8;

    invoke-direct {v4, v11, v9}, Ljec;-><init>(I[Ljava/lang/Object;)V

    new-instance v4, Ljec;

    new-array v9, v7, [Landroidx/compose/ui/node/LayoutNode;

    invoke-direct {v4, v11, v9}, Ljec;-><init>(I[Ljava/lang/Object;)V

    new-instance v4, Ljec;

    new-array v7, v7, [Lfi8;

    invoke-direct {v4, v11, v7}, Ljec;-><init>(I[Ljava/lang/Object;)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Y0:Lw7c;

    new-instance v3, Ld80;

    invoke-direct {v3, p0}, Ld80;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Z0:Ld80;

    new-instance v3, Lrpf;

    invoke-direct {v3, v6}, Lrpf;-><init>(I)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->c1:Lrpf;

    new-instance v3, Lddc;

    invoke-direct {v3}, Lddc;-><init>()V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d1:Lddc;

    new-instance v3, Lm;

    invoke-direct {v3, v10, p0}, Lm;-><init>(ILjava/lang/Object;)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g1:Lm;

    new-instance v3, Lq00;

    invoke-direct {v3, p0, v10}, Lq00;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h1:Lq00;

    new-instance v3, Lzd9;

    new-instance v4, Lc10;

    invoke-direct {v4, p0, v11}, Lc10;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    invoke-direct {v3, v8, v4}, Lzd9;-><init>(Landroid/content/Context;Lc10;)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->j1:Lzd9;

    new-instance v3, Ly00;

    invoke-direct {v3, p0, v5}, Ly00;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    iput-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->k1:Ly00;

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1d

    if-ge v3, v4, :cond_29b

    new-instance v5, Ldhl;

    invoke-direct {v5, v0}, Ldhl;-><init>([F)V

    goto :goto_2a0

    :cond_29b
    new-instance v5, Lpd2;

    invoke-direct {v5}, Lpd2;-><init>()V

    :goto_2a0
    iput-object v5, p0, Landroidx/compose/ui/platform/AndroidComposeView;->l1:Lod2;

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    invoke-virtual {p0, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    invoke-virtual {p0, v11}, Landroid/view/View;->setWillNotDraw(Z)V

    invoke-virtual {p0, v10}, Landroid/view/View;->setFocusable(Z)V

    sget-object v0, Lv10;->a:Lv10;

    invoke-virtual {v0, p0, v10, v11}, Lv10;->a(Landroid/view/View;IZ)V

    invoke-virtual {p0, v10}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    invoke-virtual {p0, v11}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    invoke-static {p0, v13}, Lgkj;->h(Landroid/view/View;Lh5;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getDragAndDropManager()Ly20;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/view/View;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroidx/compose/ui/node/LayoutNode;->d(Landroidx/compose/ui/node/Owner;)V

    if-lt v3, v4, :cond_2d0

    sget-object v0, Lo10;->a:Lo10;

    invoke-virtual {v0, p0}, Lo10;->a(Landroid/view/View;)V

    :cond_2d0
    invoke-static {}, Landroidx/compose/ui/platform/AndroidComposeView;->o()Z

    move-result v0

    if-eqz v0, :cond_2f1

    new-instance v0, Landroid/view/View;

    invoke-direct {v0, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v4, v10, v10}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v4, 0x7f0a0331

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v4, v5}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->P:Landroid/view/View;

    const/4 v4, -0x1

    invoke-virtual {p0, v0, v4}, Landroidx/compose/ui/platform/AndroidComposeView;->addView(Landroid/view/View;I)V

    :cond_2f1
    const/16 v0, 0x1f

    if-lt v3, v0, :cond_2fc

    new-instance v1, Ld3f;

    const/16 v0, 0x19

    invoke-direct {v1, v0, v11}, Ld3f;-><init>(IZ)V

    :cond_2fc
    iput-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->o1:Ld3f;

    new-instance v0, Ld10;

    invoke-direct {v0, p0}, Ld10;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->q1:Ld10;

    return-void

    :cond_306
    const-string v0, "Autofill service could not be located."

    invoke-static {v0}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0
.end method

.method public static final b(Landroidx/compose/ui/platform/AndroidComposeView;ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)V
    .registers 6

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    iget-object v0, p0, Lm10;->h0:Ljava/lang/String;

    invoke-static {p3, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, -0x1

    if-eqz v0, :cond_1b

    iget-object p0, p0, Lm10;->f0:Ljcc;

    invoke-virtual {p0, p1}, Ljcc;->d(I)I

    move-result p0

    if-eq p0, v1, :cond_32

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    invoke-virtual {p1, p3, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    return-void

    :cond_1b
    iget-object v0, p0, Lm10;->i0:Ljava/lang/String;

    invoke-static {p3, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_32

    iget-object p0, p0, Lm10;->g0:Ljcc;

    invoke-virtual {p0, p1}, Ljcc;->d(I)I

    move-result p0

    if-eq p0, v1, :cond_32

    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    invoke-virtual {p1, p3, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_32
    return-void
.end method

.method public static final synthetic c(Landroid/view/MotionEvent;Landroidx/compose/ui/platform/AndroidComposeView;)Z
    .registers 2

    invoke-super {p1, p0}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static final synthetic e(Landroidx/compose/ui/platform/AndroidComposeView;Landroid/view/KeyEvent;)Z
    .registers 2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p0

    return p0
.end method

.method public static final synthetic f(Landroidx/compose/ui/platform/AndroidComposeView;)V
    .registers 1

    invoke-direct {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->get_viewTreeOwners()Lw00;

    return-void
.end method

.method public static g(Landroid/view/ViewGroup;)V
    .registers 5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_5
    if-ge v1, v0, :cond_21

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    instance-of v3, v2, Landroidx/compose/ui/platform/AndroidComposeView;

    if-eqz v3, :cond_15

    check-cast v2, Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v2}, Landroidx/compose/ui/platform/AndroidComposeView;->x()V

    goto :goto_1e

    :cond_15
    instance-of v3, v2, Landroid/view/ViewGroup;

    if-eqz v3, :cond_1e

    check-cast v2, Landroid/view/ViewGroup;

    invoke-static {v2}, Landroidx/compose/ui/platform/AndroidComposeView;->g(Landroid/view/ViewGroup;)V

    :cond_1e
    :goto_1e
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_21
    return-void
.end method

.method private final getDerivedIsAttached()Z
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->V:Ly76;

    invoke-virtual {p0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public static synthetic getFontLoader$annotations()V
    .registers 0
    .annotation runtime Ln76;
    .end annotation

    return-void
.end method

.method public static synthetic getLastMatrixRecalculationAnimationTime$ui$annotations()V
    .registers 0

    return-void
.end method

.method private final getLegacyTextInputServiceAndroid()Lb9i;
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->P0:Lb9i;

    if-nez v0, :cond_f

    new-instance v0, Lb9i;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getView()Landroid/view/View;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lb9i;-><init>(Landroid/view/View;Landroidx/compose/ui/platform/AndroidComposeView;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->P0:Lb9i;

    :cond_f
    return-object v0
.end method

.method public static synthetic getPrimaryDirectionalMotionAxisOverride-dqNNBbU$ui$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic getRoot$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic getShowLayoutBounds$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic getTextInputService$annotations()V
    .registers 0
    .annotation runtime Ln76;
    .end annotation

    return-void
.end method

.method public static synthetic getWindowInfo$annotations()V
    .registers 0

    return-void
.end method

.method private final get_composeViewContext()Lvu4;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->E:Ltad;

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvu4;

    return-object p0
.end method

.method private final get_viewTreeOwners()Lw00;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->M0:Ltad;

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lb40;->x(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static h(I)J
    .registers 5

    invoke-static {p0}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    invoke-static {p0}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p0

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_23

    if-eqz v0, :cond_1f

    const/high16 v1, 0x40000000  # 2.0f

    if-ne v0, v1, :cond_19

    int-to-long v0, p0

    const/16 p0, 0x20

    shl-long v2, v0, p0

    or-long/2addr v0, v2

    return-wide v0

    :cond_19
    invoke-static {}, Lio/sentry/i2;->b()V

    const-wide/16 v0, 0x0

    return-wide v0

    :cond_1f
    const-wide/32 v0, 0x7fffffff

    return-wide v0

    :cond_23
    int-to-long v0, p0

    return-wide v0
.end method

.method public static j(Landroid/view/View;I)Landroid/view/View;
    .registers 6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    const/4 v2, 0x0

    if-ge v0, v1, :cond_3d

    const-class v0, Landroid/view/View;

    const-string v1, "getAccessibilityViewId"

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v0, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_22

    return-object p0

    :cond_22
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3d

    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_2d
    if-ge v1, v0, :cond_3d

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->j(Landroid/view/View;I)Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_3a

    return-object v3

    :cond_3a
    add-int/lit8 v1, v1, 0x1

    goto :goto_2d

    :cond_3d
    return-object v2
.end method

.method public static m(Landroidx/compose/ui/node/LayoutNode;)V
    .registers 4

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->Q()V

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p0

    iget-object v0, p0, Ljec;->E:[Ljava/lang/Object;

    iget p0, p0, Ljec;->G:I

    const/4 v1, 0x0

    :goto_c
    if-ge v1, p0, :cond_18

    aget-object v2, v0, v1

    check-cast v2, Landroidx/compose/ui/node/LayoutNode;

    invoke-static {v2}, Landroidx/compose/ui/platform/AndroidComposeView;->m(Landroidx/compose/ui/node/LayoutNode;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_c

    :cond_18
    return-void
.end method

.method public static o()Z
    .registers 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x23

    if-lt v0, v1, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public static p(Landroid/view/MotionEvent;)Z
    .registers 9

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    const v1, 0x7fffffff

    and-int/2addr v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/high16 v4, 0x7f800000  # Float.POSITIVE_INFINITY

    if-ge v0, v4, :cond_35

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    and-int/2addr v0, v1

    if-ge v0, v4, :cond_35

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    and-int/2addr v0, v1

    if-ge v0, v4, :cond_35

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    and-int/2addr v0, v1

    if-ge v0, v4, :cond_35

    move v0, v2

    goto :goto_36

    :cond_35
    move v0, v3

    :goto_36
    if-nez v0, :cond_6c

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v5

    move v6, v3

    :goto_3d
    if-ge v6, v5, :cond_6c

    invoke-virtual {p0, v6}, Landroid/view/MotionEvent;->getX(I)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    and-int/2addr v0, v1

    if-ge v0, v4, :cond_66

    invoke-virtual {p0, v6}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    and-int/2addr v0, v1

    if-ge v0, v4, :cond_66

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1d

    if-lt v0, v7, :cond_64

    sget-object v0, Lg9c;->a:Lg9c;

    invoke-virtual {v0, p0, v6}, Lg9c;->a(Landroid/view/MotionEvent;I)Z

    move-result v0

    if-nez v0, :cond_64

    goto :goto_66

    :cond_64
    move v0, v2

    goto :goto_67

    :cond_66
    :goto_66
    move v0, v3

    :goto_67
    if-nez v0, :cond_6c

    add-int/lit8 v6, v6, 0x1

    goto :goto_3d

    :cond_6c
    return v0
.end method

.method private final setAttached(Z)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->U:Ltad;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private setDensity(Ld76;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->O:Ltad;

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private setFontFamilyResolver(Ly38;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->U0:Laec;

    invoke-interface {p0, p1}, Laec;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private setLayoutDirection(Lf7a;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->V0:Ltad;

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final set_composeViewContext(Lvu4;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->E:Ltad;

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final set_viewTreeOwners(Lw00;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->M0:Ltad;

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final A(Landroidx/compose/ui/node/LayoutNode;ZZ)V
    .registers 12

    const/4 v0, 0x0

    sget-object v1, Lno9;->H:Lno9;

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v6, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    if-eqz p2, :cond_8b

    iget-object p2, v6, Lilb;->b:Lhk0;

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->u()Lv7a;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    move-result v7

    if-eqz v7, :cond_24

    if-eq v7, v5, :cond_101

    if-eq v7, v4, :cond_24

    if-eq v7, v3, :cond_101

    if-ne v7, v2, :cond_20

    goto :goto_24

    :cond_20
    invoke-static {}, Le97;->d()V

    return-void

    :cond_24
    :goto_24
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->x()Z

    move-result v2

    if-nez v2, :cond_30

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->v()Z

    move-result v2

    if-eqz v2, :cond_34

    :cond_30
    if-nez p3, :cond_34

    goto/16 :goto_101

    :cond_34
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->e0()V

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->d0()V

    iget-boolean p3, p1, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-eqz p3, :cond_40

    goto/16 :goto_101

    :cond_40
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p3

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->Z()Ljava/lang/Boolean;

    move-result-object v2

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v2, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_68

    if-eqz p3, :cond_59

    invoke-virtual {p3}, Landroidx/compose/ui/node/LayoutNode;->x()Z

    move-result v2

    if-ne v2, v5, :cond_59

    goto :goto_68

    :cond_59
    if-eqz p3, :cond_62

    invoke-virtual {p3}, Landroidx/compose/ui/node/LayoutNode;->v()Z

    move-result v2

    if-ne v2, v5, :cond_62

    goto :goto_68

    :cond_62
    sget-object p3, Lno9;->F:Lno9;

    invoke-virtual {p2, p1, p3}, Lhk0;->b(Landroidx/compose/ui/node/LayoutNode;Lno9;)V

    goto :goto_83

    :cond_68
    :goto_68
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result v2

    if-eqz v2, :cond_83

    if-eqz p3, :cond_77

    invoke-virtual {p3}, Landroidx/compose/ui/node/LayoutNode;->t()Z

    move-result v2

    if-ne v2, v5, :cond_77

    goto :goto_83

    :cond_77
    if-eqz p3, :cond_80

    invoke-virtual {p3}, Landroidx/compose/ui/node/LayoutNode;->A()Z

    move-result p3

    if-ne p3, v5, :cond_80

    goto :goto_83

    :cond_80
    invoke-virtual {p2, p1, v1}, Lhk0;->b(Landroidx/compose/ui/node/LayoutNode;Lno9;)V

    :cond_83
    :goto_83
    iget-boolean p1, v6, Lilb;->d:Z

    if-nez p1, :cond_101

    invoke-virtual {p0, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->F(Landroidx/compose/ui/node/LayoutNode;)V

    return-void

    :cond_8b
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->u()Lv7a;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    if-eqz p2, :cond_101

    if-eq p2, v5, :cond_101

    if-eq p2, v4, :cond_101

    if-eq p2, v3, :cond_101

    if-ne p2, v2, :cond_fe

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p2

    if-eqz p2, :cond_af

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result v2

    if-eqz v2, :cond_ad

    goto :goto_af

    :cond_ad
    const/4 v2, 0x0

    goto :goto_b0

    :cond_af
    :goto_af
    move v2, v5

    :goto_b0
    if-nez p3, :cond_cf

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->A()Z

    move-result p3

    if-nez p3, :cond_101

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->t()Z

    move-result p3

    if-eqz p3, :cond_cf

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result p3

    if-ne p3, v2, :cond_cf

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result p3

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->Y()Z

    move-result v3

    if-ne p3, v3, :cond_cf

    goto :goto_101

    :cond_cf
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->d0()V

    iget-boolean p3, p1, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-eqz p3, :cond_d7

    goto :goto_101

    :cond_d7
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->Y()Z

    move-result p3

    if-eqz p3, :cond_101

    if-eqz v2, :cond_101

    if-eqz p2, :cond_e8

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->t()Z

    move-result p3

    if-ne p3, v5, :cond_e8

    goto :goto_f6

    :cond_e8
    if-eqz p2, :cond_f1

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->A()Z

    move-result p2

    if-ne p2, v5, :cond_f1

    goto :goto_f6

    :cond_f1
    iget-object p2, v6, Lilb;->b:Lhk0;

    invoke-virtual {p2, p1, v1}, Lhk0;->b(Landroidx/compose/ui/node/LayoutNode;Lno9;)V

    :goto_f6
    iget-boolean p1, v6, Lilb;->d:Z

    if-nez p1, :cond_101

    invoke-virtual {p0, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->F(Landroidx/compose/ui/node/LayoutNode;)V

    return-void

    :cond_fe
    invoke-static {}, Le97;->d()V

    :cond_101
    :goto_101
    return-void
.end method

.method public final B()V
    .registers 5

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lm10;->b0:Z

    iget-object v2, v0, Lm10;->H:Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    move-result-object v2

    invoke-virtual {v0}, Lm10;->q()Z

    move-result v3

    if-eqz v3, :cond_1e

    iget-boolean v3, v0, Lm10;->m0:Z

    if-nez v3, :cond_1e

    if-eqz v2, :cond_1e

    iput-boolean v1, v0, Lm10;->m0:Z

    iget-object v0, v0, Lm10;->o0:Ly0;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1e
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    iput-boolean v1, p0, Lc20;->K:Z

    iget-object v0, p0, Lc20;->E:Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v0}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    move-result-object v0

    invoke-virtual {p0}, Lc20;->e()Z

    move-result v2

    if-eqz v2, :cond_3b

    iget-boolean v2, p0, Lc20;->Q:Z

    if-nez v2, :cond_3b

    if-eqz v0, :cond_3b

    iput-boolean v1, p0, Lc20;->Q:Z

    iget-object p0, p0, Lc20;->R:Ly0;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_3b
    return-void
.end method

.method public final C()V
    .registers 7

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->K0:Z

    if-nez v0, :cond_5e

    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    cmp-long v2, v0, v2

    if-eqz v2, :cond_5e

    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->l1:Lod2;

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->H0:[F

    invoke-interface {v0, p0, v1}, Lod2;->a(Landroid/view/View;[F)V

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->I0:[F

    invoke-static {v1, v0}, Lik5;->E([F[F)Z

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    move-object v1, p0

    :goto_21
    instance-of v2, v0, Landroid/view/ViewGroup;

    if-eqz v2, :cond_30

    move-object v1, v0

    check-cast v1, Landroid/view/View;

    move-object v0, v1

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    goto :goto_21

    :cond_30
    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->F0:[I

    invoke-virtual {v1, v0}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v2, 0x0

    aget v3, v0, v2

    int-to-float v3, v3

    const/4 v4, 0x1

    aget v5, v0, v4

    int-to-float v5, v5

    invoke-virtual {v1, v0}, Landroid/view/View;->getLocationInWindow([I)V

    aget v1, v0, v2

    int-to-float v1, v1

    aget v0, v0, v4

    int-to-float v0, v0

    sub-float/2addr v3, v1

    sub-float/2addr v5, v0

    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    int-to-long v0, v0

    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v2

    int-to-long v2, v2

    const/16 v4, 0x20

    shl-long/2addr v0, v4

    const-wide v4, 0xffffffffL

    and-long/2addr v2, v4

    or-long/2addr v0, v2

    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    :cond_5e
    return-void
.end method

.method public final D(Landroid/view/MotionEvent;)V
    .registers 11

    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->l1:Lod2;

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->H0:[F

    invoke-interface {v0, p0, v1}, Lod2;->a(Landroid/view/View;[F)V

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->I0:[F

    invoke-static {v1, v0}, Lik5;->E([F[F)Z

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    int-to-long v3, v0

    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    int-to-long v5, v0

    const/16 v0, 0x20

    shl-long v2, v3, v0

    const-wide v7, 0xffffffffL

    and-long v4, v5, v7

    or-long/2addr v2, v4

    invoke-static {v2, v3, v1}, Lmab;->b(J[F)J

    move-result-wide v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v3

    shr-long v4, v1, v0

    long-to-int v4, v4

    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v4

    sub-float/2addr v3, v4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    and-long/2addr v1, v7

    long-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    sub-float/2addr p1, v1

    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v1

    int-to-long v1, v1

    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    int-to-long v3, p1

    shl-long v0, v1, v0

    and-long v2, v3, v7

    or-long/2addr v0, v2

    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    return-void
.end method

.method public final E()Z
    .registers 3

    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/16 v0, 0x82

    const/4 v1, 0x0

    invoke-super {p0, v0, v1}, Landroid/view/ViewGroup;->requestFocus(ILandroid/graphics/Rect;)Z

    move-result p0

    return p0
.end method

.method public final F(Landroidx/compose/ui/node/LayoutNode;)V
    .registers 5

    invoke-virtual {p0}, Landroid/view/View;->isLayoutRequested()Z

    move-result v0

    if-nez v0, :cond_5a

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_5a

    if-eqz p1, :cond_46

    :goto_e
    if-eqz p1, :cond_3c

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->B()Lx7a;

    move-result-object v0

    sget-object v1, Lx7a;->E:Lx7a;

    if-ne v0, v1, :cond_3c

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->C0:Z

    if-nez v0, :cond_37

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_3c

    iget-object v0, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v0, v0, Lxmc;->H:Ljava/lang/Object;

    check-cast v0, Lkg9;

    iget-wide v0, v0, Lemd;->H:J

    invoke-static {v0, v1}, Lj35;->f(J)Z

    move-result v2

    if-eqz v2, :cond_37

    invoke-static {v0, v1}, Lj35;->e(J)Z

    move-result v0

    if-eqz v0, :cond_37

    goto :goto_3c

    :cond_37
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    goto :goto_e

    :cond_3c
    :goto_3c
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-ne p1, v0, :cond_46

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void

    :cond_46
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    if-eqz p1, :cond_57

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p1

    if-nez p1, :cond_53

    goto :goto_57

    :cond_53
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void

    :cond_57
    :goto_57
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_5a
    return-void
.end method

.method public final G(J)J
    .registers 9

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->C()V

    const/16 v0, 0x20

    shr-long v1, p1, v0

    long-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    iget-wide v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    shr-long/2addr v2, v0

    long-to-int v2, v2

    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v2

    sub-float/2addr v1, v2

    const-wide v2, 0xffffffffL

    and-long/2addr p1, v2

    long-to-int p1, p1

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    iget-wide v4, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    and-long/2addr v4, v2

    long-to-int p2, v4

    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p2

    sub-float/2addr p1, p2

    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p2

    int-to-long v4, p2

    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    int-to-long p1, p1

    shl-long v0, v4, v0

    and-long/2addr p1, v2

    or-long/2addr p1, v0

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->I0:[F

    invoke-static {p1, p2, p0}, Lmab;->b(J[F)J

    move-result-wide p0

    return-wide p0
.end method

.method public final H(Landroid/view/MotionEvent;)I
    .registers 11

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->m1:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_22

    iput-boolean v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->m1:Z

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v0

    iget-object v0, v0, Lvu4;->s:Ltea;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getMetaState()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lz2k;->a:Ltad;

    invoke-static {}, Lqll;->f()Ltad;

    move-result-object v0

    new-instance v3, Llrd;

    invoke-direct {v3, v2}, Llrd;-><init>(I)V

    invoke-virtual {v0, v3}, Ltad;->setValue(Ljava/lang/Object;)V

    :cond_22
    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->p0:Lf9c;

    invoke-virtual {v0, p1, p0}, Lf9c;->c(Landroid/view/MotionEvent;Landroidx/compose/ui/platform/AndroidComposeView;)Lug9;

    move-result-object v2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    iget-object v4, p0, Landroidx/compose/ui/platform/AndroidComposeView;->q0:Li70;

    if-eqz v2, :cond_8b

    invoke-virtual {v2}, Lug9;->y()Ljava/util/List;

    move-result-object v1

    move-object v5, v1

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    const/4 v6, 0x5

    if-ltz v5, :cond_59

    :goto_40
    add-int/lit8 v7, v5, -0x1

    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    move-object v8, v5

    check-cast v8, Lerd;

    invoke-virtual {v8}, Lerd;->b()Z

    move-result v8

    if-eqz v8, :cond_54

    if-eqz v3, :cond_5a

    if-ne v3, v6, :cond_54

    goto :goto_5a

    :cond_54
    if-gez v7, :cond_57

    goto :goto_59

    :cond_57
    move v5, v7

    goto :goto_40

    :cond_59
    :goto_59
    const/4 v5, 0x0

    :cond_5a
    :goto_5a
    check-cast v5, Lerd;

    if-eqz v5, :cond_64

    invoke-virtual {v5}, Lerd;->g()J

    move-result-wide v7

    iput-wide v7, p0, Landroidx/compose/ui/platform/AndroidComposeView;->F:J

    :cond_64
    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->q(Landroid/view/MotionEvent;)Z

    move-result v1

    invoke-virtual {v4, v2, p0, v1}, Li70;->b(Lug9;Landroidx/compose/ui/platform/AndroidComposeView;Z)I

    move-result p0

    invoke-virtual {v2}, Lug9;->P()V

    if-eqz v3, :cond_73

    if-ne v3, v6, :cond_77

    :cond_73
    and-int/lit8 v1, p0, 0x1

    if-eqz v1, :cond_78

    :cond_77
    return p0

    :cond_78
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result p1

    iget-object v1, v0, Lf9c;->c:Landroid/util/SparseBooleanArray;

    invoke-virtual {v1, p1}, Landroid/util/SparseBooleanArray;->delete(I)V

    iget-object v0, v0, Lf9c;->b:Landroid/util/SparseLongArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseLongArray;->delete(I)V

    return p0

    :cond_8b
    iget-boolean p0, v4, Li70;->a:Z

    if-nez p0, :cond_a1

    iget-object p0, v4, Li70;->d:Ljava/lang/Object;

    check-cast p0, Lxs5;

    iget-object p0, p0, Lxs5;->F:Ljava/lang/Object;

    check-cast p0, Lgya;

    invoke-virtual {p0}, Lgya;->a()V

    iget-object p0, v4, Li70;->c:Ljava/lang/Object;

    check-cast p0, Luy8;

    invoke-virtual {p0}, Luy8;->c()V

    :cond_a1
    invoke-static {v1, v1, v1}, Lzal;->b(ZZZ)I

    move-result p0

    return p0
.end method

.method public final I(Landroid/view/MotionEvent;IJZ)V
    .registers 23

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v5, p2

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    const/4 v3, -0x1

    const/4 v6, 0x1

    if-eq v2, v6, :cond_17

    const/4 v7, 0x6

    if-eq v2, v7, :cond_12

    goto :goto_20

    :cond_12
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v3

    goto :goto_20

    :cond_17
    const/16 v2, 0x9

    if-eq v5, v2, :cond_20

    const/16 v2, 0xa

    if-eq v5, v2, :cond_20

    const/4 v3, 0x0

    :cond_20
    :goto_20
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v2

    if-ltz v3, :cond_28

    move v7, v6

    goto :goto_29

    :cond_28
    const/4 v7, 0x0

    :goto_29
    sub-int/2addr v2, v7

    if-nez v2, :cond_2d

    return-void

    :cond_2d
    new-array v7, v2, [Landroid/view/MotionEvent$PointerProperties;

    const/4 v8, 0x0

    :goto_30
    if-ge v8, v2, :cond_3c

    new-instance v9, Landroid/view/MotionEvent$PointerProperties;

    invoke-direct {v9}, Landroid/view/MotionEvent$PointerProperties;-><init>()V

    aput-object v9, v7, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_30

    :cond_3c
    new-array v8, v2, [Landroid/view/MotionEvent$PointerCoords;

    const/4 v9, 0x0

    :goto_3f
    if-ge v9, v2, :cond_4b

    new-instance v10, Landroid/view/MotionEvent$PointerCoords;

    invoke-direct {v10}, Landroid/view/MotionEvent$PointerCoords;-><init>()V

    aput-object v10, v8, v9

    add-int/lit8 v9, v9, 0x1

    goto :goto_3f

    :cond_4b
    const/4 v9, 0x0

    :goto_4c
    if-ge v9, v2, :cond_93

    if-ltz v3, :cond_55

    if-ge v9, v3, :cond_53

    goto :goto_55

    :cond_53
    move v10, v6

    goto :goto_56

    :cond_55
    :goto_55
    const/4 v10, 0x0

    :goto_56
    add-int/2addr v10, v9

    aget-object v11, v7, v9

    invoke-virtual {v1, v10, v11}, Landroid/view/MotionEvent;->getPointerProperties(ILandroid/view/MotionEvent$PointerProperties;)V

    aget-object v11, v8, v9

    invoke-virtual {v1, v10, v11}, Landroid/view/MotionEvent;->getPointerCoords(ILandroid/view/MotionEvent$PointerCoords;)V

    iget v10, v11, Landroid/view/MotionEvent$PointerCoords;->x:F

    iget v12, v11, Landroid/view/MotionEvent$PointerCoords;->y:F

    invoke-static {v10}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v10

    int-to-long v13, v10

    invoke-static {v12}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v10

    int-to-long v4, v10

    const/16 v10, 0x20

    shl-long/2addr v13, v10

    const-wide v15, 0xffffffffL

    and-long/2addr v4, v15

    or-long/2addr v4, v13

    invoke-virtual {v0, v4, v5}, Landroidx/compose/ui/platform/AndroidComposeView;->t(J)J

    move-result-wide v4

    shr-long v13, v4, v10

    long-to-int v10, v13

    invoke-static {v10}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v10

    iput v10, v11, Landroid/view/MotionEvent$PointerCoords;->x:F

    and-long/2addr v4, v15

    long-to-int v4, v4

    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v4

    iput v4, v11, Landroid/view/MotionEvent$PointerCoords;->y:F

    add-int/lit8 v9, v9, 0x1

    move/from16 v5, p2

    goto :goto_4c

    :cond_93
    if-eqz p5, :cond_97

    const/4 v10, 0x0

    goto :goto_9c

    :cond_97
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getButtonState()I

    move-result v4

    move v10, v4

    :goto_9c
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDownTime()J

    move-result-wide v3

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v11

    cmp-long v3, v3, v11

    if-nez v3, :cond_ab

    move-wide/from16 v3, p3

    goto :goto_af

    :cond_ab
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDownTime()J

    move-result-wide v3

    :goto_af
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getMetaState()I

    move-result v9

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getXPrecision()F

    move-result v11

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getYPrecision()F

    move-result v12

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v13

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEdgeFlags()I

    move-result v14

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getSource()I

    move-result v15

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getFlags()I

    move-result v16

    move/from16 v5, p2

    move v6, v2

    move-wide v1, v3

    move-wide/from16 v3, p3

    invoke-static/range {v1 .. v16}, Landroid/view/MotionEvent;->obtain(JJII[Landroid/view/MotionEvent$PointerProperties;[Landroid/view/MotionEvent$PointerCoords;IIFFIIII)Landroid/view/MotionEvent;

    move-result-object v1

    iget-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->p0:Lf9c;

    invoke-virtual {v2, v1, v0}, Lf9c;->c(Landroid/view/MotionEvent;Landroidx/compose/ui/platform/AndroidComposeView;)Lug9;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v0, Landroidx/compose/ui/platform/AndroidComposeView;->q0:Li70;

    const/4 v4, 0x1

    invoke-virtual {v3, v2, v0, v4}, Li70;->b(Lug9;Landroidx/compose/ui/platform/AndroidComposeView;Z)I

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    return-void
.end method

.method public final J(Lq98;Lc75;)V
    .registers 10

    instance-of v0, p2, Lg10;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lg10;

    iget v1, v0, Lg10;->G:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lg10;->G:I

    goto :goto_18

    :cond_13
    new-instance v0, Lg10;

    invoke-direct {v0, p0, p2}, Lg10;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;Lc75;)V

    :goto_18
    iget-object p2, v0, Lg10;->E:Ljava/lang/Object;

    iget v1, v0, Lg10;->G:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2b

    if-eq v1, v2, :cond_27

    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void

    :cond_27
    invoke-static {p2}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_4b

    :cond_2b
    invoke-static {p2}, Lw10;->P(Ljava/lang/Object;)V

    move p2, v2

    new-instance v2, Lc10;

    const/4 v1, 0x2

    invoke-direct {v2, p0, v1}, Lc10;-><init>(Landroidx/compose/ui/platform/AndroidComposeView;I)V

    iput p2, v0, Lg10;->G:I

    new-instance v1, Lyx;

    const/4 v5, 0x0

    const/16 v6, 0x14

    iget-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->R0:Ljava/util/concurrent/atomic/AtomicReference;

    move-object v4, p1

    invoke-direct/range {v1 .. v6}, Lyx;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;La75;I)V

    invoke-static {v1, v0}, Lvi9;->E(Lq98;La75;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lva5;->E:Lva5;

    if-ne p0, p1, :cond_4b

    return-void

    :cond_4b
    :goto_4b
    invoke-static {}, Le97;->r()V

    return-void
.end method

.method public final K(Landroid/content/res/Configuration;)V
    .registers 5

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    invoke-static {v0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_42

    new-instance v1, Landroid/content/res/Configuration;

    invoke-direct {v1, p1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    invoke-virtual {p0, v1}, Landroidx/compose/ui/platform/AndroidComposeView;->setConfiguration(Landroid/content/res/Configuration;)V

    iget v1, v0, Landroid/content/res/Configuration;->fontScale:F

    iget v2, p1, Landroid/content/res/Configuration;->fontScale:F

    cmpg-float v1, v1, v2

    if-nez v1, :cond_20

    iget v1, v0, Landroid/content/res/Configuration;->densityDpi:I

    iget v2, p1, Landroid/content/res/Configuration;->densityDpi:I

    if-eq v1, v2, :cond_2b

    :cond_20
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lzcj;->c(Landroid/content/Context;)Li76;

    move-result-object v1

    invoke-direct {p0, v1}, Landroidx/compose/ui/platform/AndroidComposeView;->setDensity(Ld76;)V

    :cond_2b
    invoke-virtual {v0, p1}, Landroid/content/res/Configuration;->diff(Landroid/content/res/Configuration;)I

    move-result p1

    const v0, -0x5000e280

    and-int/2addr p1, v0

    if-eqz p1, :cond_42

    iget-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->T:Ltea;

    iget-object p1, p1, Ltea;->b:Ltad;

    if-eqz p1, :cond_42

    invoke-static {p0}, Lp8;->n(Landroid/view/View;)Lu76;

    move-result-object p0

    invoke-virtual {p1, p0}, Ltad;->setValue(Ljava/lang/Object;)V

    :cond_42
    return-void
.end method

.method public final L()V
    .registers 19

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/compose/ui/platform/AndroidComposeView;->F0:[I

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    iget-wide v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->E0:J

    const/16 v4, 0x20

    shr-long v5, v2, v4

    long-to-int v5, v5

    const-wide v6, 0xffffffffL

    and-long/2addr v2, v6

    long-to-int v2, v2

    const/4 v3, 0x0

    aget v8, v1, v3

    const/4 v9, 0x1

    if-ne v5, v8, :cond_27

    aget v10, v1, v9

    if-ne v2, v10, :cond_27

    iget-wide v10, v0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    const-wide/16 v12, 0x0

    cmp-long v10, v10, v12

    if-gez v10, :cond_56

    :cond_27
    aget v1, v1, v9

    int-to-long v10, v8

    shl-long/2addr v10, v4

    int-to-long v12, v1

    and-long/2addr v6, v12

    or-long/2addr v6, v10

    iput-wide v6, v0, Landroidx/compose/ui/platform/AndroidComposeView;->E0:J

    const v1, 0x7fffffff

    if-eq v5, v1, :cond_56

    if-eq v2, v1, :cond_56

    invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object v1

    iget-object v2, v1, Ljec;->E:[Ljava/lang/Object;

    iget v1, v1, Ljec;->G:I

    move v4, v3

    :goto_44
    if-ge v4, v1, :cond_54

    aget-object v5, v2, v4

    check-cast v5, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v5}, Landroidx/compose/ui/node/LayoutNode;->z()Lmlb;

    move-result-object v5

    invoke-virtual {v5}, Lmlb;->w0()V

    add-int/lit8 v4, v4, 0x1

    goto :goto_44

    :cond_54
    move v1, v9

    goto :goto_57

    :cond_56
    move v1, v3

    :goto_57
    invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->C()V

    iget-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->p1:Landroid/view/View;

    if-nez v2, :cond_64

    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->p1:Landroid/view/View;

    :cond_64
    invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object v4

    iget-wide v11, v0, Landroidx/compose/ui/platform/AndroidComposeView;->E0:J

    iget-wide v5, v0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    invoke-static {v5, v6}, Lz6k;->B(J)J

    move-result-wide v13

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v16

    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    move-result v17

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->H0:[F

    array-length v5, v2

    const/16 v6, 0x10

    const/4 v7, 0x2

    if-ge v5, v6, :cond_86

    move v5, v3

    goto/16 :goto_f0

    :cond_86
    aget v5, v2, v3

    const/high16 v6, 0x3f800000  # 1.0f

    cmpg-float v5, v5, v6

    const/4 v8, 0x0

    if-nez v5, :cond_ca

    aget v5, v2, v9

    cmpg-float v5, v5, v8

    if-nez v5, :cond_ca

    aget v5, v2, v7

    cmpg-float v5, v5, v8

    if-nez v5, :cond_ca

    const/4 v5, 0x4

    aget v5, v2, v5

    cmpg-float v5, v5, v8

    if-nez v5, :cond_ca

    const/4 v5, 0x5

    aget v5, v2, v5

    cmpg-float v5, v5, v6

    if-nez v5, :cond_ca

    const/4 v5, 0x6

    aget v5, v2, v5

    cmpg-float v5, v5, v8

    if-nez v5, :cond_ca

    const/16 v5, 0x8

    aget v5, v2, v5

    cmpg-float v5, v5, v8

    if-nez v5, :cond_ca

    const/16 v5, 0x9

    aget v5, v2, v5

    cmpg-float v5, v5, v8

    if-nez v5, :cond_ca

    const/16 v5, 0xa

    aget v5, v2, v5

    cmpg-float v5, v5, v6

    if-nez v5, :cond_ca

    move v5, v9

    goto :goto_cb

    :cond_ca
    move v5, v3

    :goto_cb
    const/16 v10, 0xc

    aget v10, v2, v10

    cmpg-float v10, v10, v8

    if-nez v10, :cond_ed

    const/16 v10, 0xd

    aget v10, v2, v10

    cmpg-float v10, v10, v8

    if-nez v10, :cond_ed

    const/16 v10, 0xe

    aget v10, v2, v10

    cmpg-float v8, v10, v8

    if-nez v8, :cond_ed

    const/16 v8, 0xf

    aget v8, v2, v8

    cmpg-float v6, v8, v6

    if-nez v6, :cond_ed

    move v6, v9

    goto :goto_ee

    :cond_ed
    move v6, v3

    :goto_ee
    shl-int/2addr v5, v9

    or-int/2addr v5, v6

    :goto_f0
    iget-object v10, v4, Lswe;->c:Lmei;

    and-int/2addr v5, v7

    if-nez v5, :cond_f7

    :goto_f5
    move-object v15, v2

    goto :goto_f9

    :cond_f7
    const/4 v2, 0x0

    goto :goto_f5

    :goto_f9
    invoke-virtual/range {v10 .. v17}, Lmei;->b(JJ[FII)Z

    move-result v2

    if-nez v2, :cond_103

    iget-boolean v2, v4, Lswe;->f:Z

    if-eqz v2, :cond_104

    :cond_103
    move v3, v9

    :cond_104
    iput-boolean v3, v4, Lswe;->f:Z

    iget-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    invoke-virtual {v2, v1}, Lilb;->c(Z)V

    invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object v0

    invoke-virtual {v0}, Lswe;->a()V

    return-void
.end method

.method public final M(F)V
    .registers 4

    invoke-static {}, Landroidx/compose/ui/platform/AndroidComposeView;->o()Z

    move-result v0

    if-eqz v0, :cond_30

    const/4 v0, 0x0

    cmpl-float v1, p1, v0

    if-lez v1, :cond_1c

    iget v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->e1:F

    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    if-nez v0, :cond_19

    iget v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->e1:F

    cmpl-float v0, p1, v0

    if-lez v0, :cond_30

    :cond_19
    iput p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->e1:F

    return-void

    :cond_1c
    cmpg-float v0, p1, v0

    if-gez v0, :cond_30

    iget v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f1:F

    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    if-nez v0, :cond_2e

    iget v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f1:F

    cmpg-float v0, p1, v0

    if-gez v0, :cond_30

    :cond_2e
    iput p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f1:F

    :cond_30
    return-void
.end method

.method public final a(Lm38;Lm38;)V
    .registers 15

    if-eqz p1, :cond_144

    move-object p0, p1

    check-cast p0, Ls7c;

    iget-object v0, p0, Ls7c;->E:Ls7c;

    iget-boolean v0, v0, Ls7c;->R:Z

    const-string v1, "visitAncestors called on an unattached node"

    if-nez v0, :cond_10

    invoke-static {v1}, Ldf9;->c(Ljava/lang/String;)V

    :cond_10
    iget-object p0, p0, Ls7c;->E:Ls7c;

    invoke-static {p1}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    const/4 v0, 0x0

    move-object v2, v0

    :goto_18
    const/16 v3, 0x10

    const/high16 v4, 0x200000

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz p1, :cond_96

    iget-object v7, p1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v7, v7, Lxmc;->K:Ljava/lang/Object;

    check-cast v7, Ls7c;

    iget v7, v7, Ls7c;->H:I

    and-int/2addr v7, v4

    if-eqz v7, :cond_85

    :goto_2b
    if-eqz p0, :cond_85

    iget v7, p0, Ls7c;->G:I

    and-int/2addr v7, v4

    if-eqz v7, :cond_82

    move-object v7, p0

    move-object v8, v0

    :goto_34
    if-eqz v7, :cond_82

    instance-of v9, v7, Lxd9;

    if-eqz v9, :cond_46

    if-nez v2, :cond_41

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    :cond_41
    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v9, v5

    goto :goto_47

    :cond_46
    move v9, v6

    :goto_47
    if-eqz v9, :cond_7d

    iget v9, v7, Ls7c;->G:I

    and-int/2addr v9, v4

    if-eqz v9, :cond_7d

    instance-of v9, v7, Ls46;

    if-eqz v9, :cond_7d

    move-object v9, v7

    check-cast v9, Ls46;

    iget-object v9, v9, Ls46;->T:Ls7c;

    move v10, v5

    :goto_58
    if-eqz v9, :cond_7a

    iget v11, v9, Ls7c;->G:I

    and-int/2addr v11, v4

    if-eqz v11, :cond_77

    add-int/lit8 v10, v10, 0x1

    if-ne v10, v6, :cond_65

    move-object v7, v9

    goto :goto_77

    :cond_65
    if-nez v8, :cond_6e

    new-instance v8, Ljec;

    new-array v11, v3, [Ls7c;

    invoke-direct {v8, v5, v11}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_6e
    if-eqz v7, :cond_74

    invoke-virtual {v8, v7}, Ljec;->b(Ljava/lang/Object;)V

    move-object v7, v0

    :cond_74
    invoke-virtual {v8, v9}, Ljec;->b(Ljava/lang/Object;)V

    :cond_77
    :goto_77
    iget-object v9, v9, Ls7c;->J:Ls7c;

    goto :goto_58

    :cond_7a
    if-ne v10, v6, :cond_7d

    goto :goto_34

    :cond_7d
    invoke-static {v8}, La60;->l(Ljec;)Ls7c;

    move-result-object v7

    goto :goto_34

    :cond_82
    iget-object p0, p0, Ls7c;->I:Ls7c;

    goto :goto_2b

    :cond_85
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    if-eqz p1, :cond_94

    iget-object p0, p1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz p0, :cond_94

    iget-object p0, p0, Lxmc;->J:Ljava/lang/Object;

    check-cast p0, Lhzh;

    goto :goto_18

    :cond_94
    move-object p0, v0

    goto :goto_18

    :cond_96
    if-nez v2, :cond_9a

    goto/16 :goto_144

    :cond_9a
    if-eqz p2, :cond_127

    iget-object p0, p2, Ls7c;->E:Ls7c;

    iget-boolean p0, p0, Ls7c;->R:Z

    if-nez p0, :cond_a5

    invoke-static {v1}, Ldf9;->c(Ljava/lang/String;)V

    :cond_a5
    iget-object p0, p2, Ls7c;->E:Ls7c;

    invoke-static {p2}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    move-object p2, v0

    :goto_ac
    if-eqz p1, :cond_126

    iget-object v1, p1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v1, v1, Lxmc;->K:Ljava/lang/Object;

    check-cast v1, Ls7c;

    iget v1, v1, Ls7c;->H:I

    and-int/2addr v1, v4

    if-eqz v1, :cond_115

    :goto_b9
    if-eqz p0, :cond_115

    iget v1, p0, Ls7c;->G:I

    and-int/2addr v1, v4

    if-eqz v1, :cond_112

    move-object v1, p0

    move-object v7, v0

    :goto_c2
    if-eqz v1, :cond_112

    instance-of v8, v1, Lxd9;

    if-eqz v8, :cond_d6

    if-nez p2, :cond_d1

    sget-object p2, Lpwf;->a:Lsdc;

    new-instance p2, Lsdc;

    invoke-direct {p2}, Lsdc;-><init>()V

    :cond_d1
    invoke-virtual {p2, v1}, Lsdc;->a(Ljava/lang/Object;)Z

    move v8, v5

    goto :goto_d7

    :cond_d6
    move v8, v6

    :goto_d7
    if-eqz v8, :cond_10d

    iget v8, v1, Ls7c;->G:I

    and-int/2addr v8, v4

    if-eqz v8, :cond_10d

    instance-of v8, v1, Ls46;

    if-eqz v8, :cond_10d

    move-object v8, v1

    check-cast v8, Ls46;

    iget-object v8, v8, Ls46;->T:Ls7c;

    move v9, v5

    :goto_e8
    if-eqz v8, :cond_10a

    iget v10, v8, Ls7c;->G:I

    and-int/2addr v10, v4

    if-eqz v10, :cond_107

    add-int/lit8 v9, v9, 0x1

    if-ne v9, v6, :cond_f5

    move-object v1, v8

    goto :goto_107

    :cond_f5
    if-nez v7, :cond_fe

    new-instance v7, Ljec;

    new-array v10, v3, [Ls7c;

    invoke-direct {v7, v5, v10}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_fe
    if-eqz v1, :cond_104

    invoke-virtual {v7, v1}, Ljec;->b(Ljava/lang/Object;)V

    move-object v1, v0

    :cond_104
    invoke-virtual {v7, v8}, Ljec;->b(Ljava/lang/Object;)V

    :cond_107
    :goto_107
    iget-object v8, v8, Ls7c;->J:Ls7c;

    goto :goto_e8

    :cond_10a
    if-ne v9, v6, :cond_10d

    goto :goto_c2

    :cond_10d
    invoke-static {v7}, La60;->l(Ljec;)Ls7c;

    move-result-object v1

    goto :goto_c2

    :cond_112
    iget-object p0, p0, Ls7c;->I:Ls7c;

    goto :goto_b9

    :cond_115
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    if-eqz p1, :cond_124

    iget-object p0, p1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz p0, :cond_124

    iget-object p0, p0, Lxmc;->J:Ljava/lang/Object;

    check-cast p0, Lhzh;

    goto :goto_ac

    :cond_124
    move-object p0, v0

    goto :goto_ac

    :cond_126
    move-object v0, p2

    :cond_127
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result p0

    move p1, v5

    :goto_12c
    if-ge p1, p0, :cond_144

    invoke-interface {v2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lxd9;

    if-eqz v0, :cond_13b

    invoke-virtual {v0, p2}, Lsdc;->c(Ljava/lang/Object;)Z

    move-result v1

    goto :goto_13c

    :cond_13b
    move v1, v5

    :goto_13c
    if-nez v1, :cond_141

    invoke-interface {p2}, Lxd9;->u0()V

    :cond_141
    add-int/lit8 p1, p1, 0x1

    goto :goto_12c

    :cond_144
    :goto_144
    return-void
.end method

.method public final addFocusables(Ljava/util/ArrayList;II)V
    .registers 17

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    check-cast v0, Lu28;

    iget-object v0, v0, Lu28;->c:Lm38;

    iget-boolean v1, v0, Ls7c;->R:Z

    if-nez v1, :cond_e

    goto/16 :goto_164

    :cond_e
    iget-object v1, v0, Ls7c;->E:Ls7c;

    iget-boolean v1, v1, Ls7c;->R:Z

    const-string v2, "visitSubtreeIf called on an unattached node"

    if-nez v1, :cond_19

    invoke-static {v2}, Ldf9;->c(Ljava/lang/String;)V

    :cond_19
    new-instance v1, Ljec;

    const/16 v3, 0x10

    new-array v4, v3, [Ls7c;

    const/4 v5, 0x0

    invoke-direct {v1, v5, v4}, Ljec;-><init>(I[Ljava/lang/Object;)V

    iget-object v0, v0, Ls7c;->E:Ls7c;

    iget-object v4, v0, Ls7c;->J:Ls7c;

    if-nez v4, :cond_2d

    invoke-static {v1, v0}, La60;->k(Ljec;Ls7c;)V

    goto :goto_30

    :cond_2d
    invoke-virtual {v1, v4}, Ljec;->b(Ljava/lang/Object;)V

    :goto_30
    iget v0, v1, Ljec;->G:I

    if-eqz v0, :cond_164

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v1, v0}, Ljec;->m(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ls7c;

    iget v4, v0, Ls7c;->H:I

    and-int/lit16 v4, v4, 0x400

    if-eqz v4, :cond_15f

    move-object v4, v0

    :goto_43
    if-eqz v4, :cond_15f

    iget-boolean v6, v4, Ls7c;->R:Z

    if-eqz v6, :cond_15f

    iget v6, v4, Ls7c;->G:I

    and-int/lit16 v6, v6, 0x400

    if-eqz v6, :cond_15b

    const/4 v6, 0x0

    move-object v7, v4

    move-object v8, v6

    :goto_52
    if-eqz v7, :cond_15b

    instance-of v9, v7, Lm38;

    const/4 v10, 0x1

    if-eqz v9, :cond_11e

    check-cast v7, Lm38;

    iget-boolean v9, v7, Ls7c;->R:Z

    if-eqz v9, :cond_155

    invoke-virtual {v7}, Lm38;->r1()Lx28;

    move-result-object v7

    iget-boolean v7, v7, Lx28;->a:Z

    if-eqz v7, :cond_155

    invoke-super/range {p0 .. p3}, Landroid/view/ViewGroup;->addFocusables(Ljava/util/ArrayList;II)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    check-cast v0, Lu28;

    iget-object v0, v0, Lu28;->c:Lm38;

    iget-boolean v1, v0, Ls7c;->R:Z

    if-nez v1, :cond_78

    goto/16 :goto_118

    :cond_78
    iget-object v1, v0, Ls7c;->E:Ls7c;

    iget-boolean v1, v1, Ls7c;->R:Z

    if-nez v1, :cond_81

    invoke-static {v2}, Ldf9;->c(Ljava/lang/String;)V

    :cond_81
    new-instance v1, Ljec;

    new-array v2, v3, [Ls7c;

    invoke-direct {v1, v5, v2}, Ljec;-><init>(I[Ljava/lang/Object;)V

    iget-object v0, v0, Ls7c;->E:Ls7c;

    iget-object v2, v0, Ls7c;->J:Ls7c;

    if-nez v2, :cond_92

    invoke-static {v1, v0}, La60;->k(Ljec;Ls7c;)V

    goto :goto_95

    :cond_92
    invoke-virtual {v1, v2}, Ljec;->b(Ljava/lang/Object;)V

    :goto_95
    iget v0, v1, Ljec;->G:I

    if-eqz v0, :cond_118

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v1, v0}, Ljec;->m(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ls7c;

    iget v2, v0, Ls7c;->H:I

    and-int/lit16 v2, v2, 0x400

    if-eqz v2, :cond_113

    move-object v2, v0

    :goto_a8
    if-eqz v2, :cond_113

    iget-boolean v4, v2, Ls7c;->R:Z

    if-eqz v4, :cond_113

    iget v4, v2, Ls7c;->G:I

    and-int/lit16 v4, v4, 0x400

    if-eqz v4, :cond_110

    move-object v4, v2

    move-object v7, v6

    :goto_b6
    if-eqz v4, :cond_110

    instance-of v8, v4, Lm38;

    if-eqz v8, :cond_d5

    check-cast v4, Lm38;

    iget-boolean v8, v4, Ls7c;->R:Z

    if-nez v8, :cond_c3

    goto :goto_10b

    :cond_c3
    invoke-virtual {v4}, Lm38;->r1()Lx28;

    move-result-object v8

    iget-boolean v9, v4, Ls7c;->R:Z

    if-eqz v9, :cond_10b

    iget-boolean v4, v4, Lm38;->S:Z

    if-nez v4, :cond_10b

    iget-boolean v4, v8, Lx28;->a:Z

    if-eqz v4, :cond_10b

    goto/16 :goto_164

    :cond_d5
    iget v8, v4, Ls7c;->G:I

    and-int/lit16 v8, v8, 0x400

    if-eqz v8, :cond_10b

    instance-of v8, v4, Ls46;

    if-eqz v8, :cond_10b

    move-object v8, v4

    check-cast v8, Ls46;

    iget-object v8, v8, Ls46;->T:Ls7c;

    move v9, v5

    :goto_e5
    if-eqz v8, :cond_108

    iget v11, v8, Ls7c;->G:I

    and-int/lit16 v11, v11, 0x400

    if-eqz v11, :cond_105

    add-int/lit8 v9, v9, 0x1

    if-ne v9, v10, :cond_f3

    move-object v4, v8

    goto :goto_105

    :cond_f3
    if-nez v7, :cond_fc

    new-instance v7, Ljec;

    new-array v11, v3, [Ls7c;

    invoke-direct {v7, v5, v11}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_fc
    if-eqz v4, :cond_102

    invoke-virtual {v7, v4}, Ljec;->b(Ljava/lang/Object;)V

    move-object v4, v6

    :cond_102
    invoke-virtual {v7, v8}, Ljec;->b(Ljava/lang/Object;)V

    :cond_105
    :goto_105
    iget-object v8, v8, Ls7c;->J:Ls7c;

    goto :goto_e5

    :cond_108
    if-ne v9, v10, :cond_10b

    goto :goto_b6

    :cond_10b
    :goto_10b
    invoke-static {v7}, La60;->l(Ljec;)Ls7c;

    move-result-object v4

    goto :goto_b6

    :cond_110
    iget-object v2, v2, Ls7c;->J:Ls7c;

    goto :goto_a8

    :cond_113
    invoke-static {v1, v0}, La60;->k(Ljec;Ls7c;)V

    goto/16 :goto_95

    :cond_118
    :goto_118
    if-eqz p1, :cond_164

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    return-void

    :cond_11e
    iget v9, v7, Ls7c;->G:I

    and-int/lit16 v9, v9, 0x400

    if-eqz v9, :cond_155

    instance-of v9, v7, Ls46;

    if-eqz v9, :cond_155

    move-object v9, v7

    check-cast v9, Ls46;

    iget-object v9, v9, Ls46;->T:Ls7c;

    move v11, v5

    :goto_12e
    if-eqz v9, :cond_151

    iget v12, v9, Ls7c;->G:I

    and-int/lit16 v12, v12, 0x400

    if-eqz v12, :cond_14e

    add-int/lit8 v11, v11, 0x1

    if-ne v11, v10, :cond_13c

    move-object v7, v9

    goto :goto_14e

    :cond_13c
    if-nez v8, :cond_145

    new-instance v8, Ljec;

    new-array v12, v3, [Ls7c;

    invoke-direct {v8, v5, v12}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_145
    if-eqz v7, :cond_14b

    invoke-virtual {v8, v7}, Ljec;->b(Ljava/lang/Object;)V

    move-object v7, v6

    :cond_14b
    invoke-virtual {v8, v9}, Ljec;->b(Ljava/lang/Object;)V

    :cond_14e
    :goto_14e
    iget-object v9, v9, Ls7c;->J:Ls7c;

    goto :goto_12e

    :cond_151
    if-ne v11, v10, :cond_155

    goto/16 :goto_52

    :cond_155
    invoke-static {v8}, La60;->l(Ljec;)Ls7c;

    move-result-object v7

    goto/16 :goto_52

    :cond_15b
    iget-object v4, v4, Ls7c;->J:Ls7c;

    goto/16 :goto_43

    :cond_15f
    invoke-static {v1, v0}, La60;->k(Ljec;Ls7c;)V

    goto/16 :goto_30

    :cond_164
    :goto_164
    return-void
.end method

.method public final addView(Landroid/view/View;)V
    .registers 3

    const/4 v0, -0x1

    .line 18
    invoke-virtual {p0, p1, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->addView(Landroid/view/View;I)V

    return-void
.end method

.method public final addView(Landroid/view/View;I)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-nez v0, :cond_d

    invoke-virtual {p0}, Landroid/view/ViewGroup;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    :cond_d
    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, v0, v1}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    return-void
.end method

.method public final addView(Landroid/view/View;II)V
    .registers 5

    .line 19
    invoke-virtual {p0}, Landroid/view/ViewGroup;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 20
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 21
    iput p3, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 p2, 0x1

    const/4 p3, -0x1

    .line 22
    invoke-virtual {p0, p1, p3, v0, p2}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    return-void
.end method

.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .registers 5

    const/4 v0, 0x1

    .line 23
    invoke-virtual {p0, p1, p2, p3, v0}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    return-void
.end method

.method public final addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 5

    const/4 v0, -0x1

    const/4 v1, 0x1

    .line 24
    invoke-virtual {p0, p1, v0, p2, v1}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    return-void
.end method

.method public final autofill(Landroid/util/SparseArray;)V
    .registers 11

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz v0, :cond_72

    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_9
    if-ge v2, v1, :cond_72

    invoke-virtual {p1, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/view/autofill/AutofillValue;

    iget-object v5, v0, Li00;->F:Lqag;

    iget-object v5, v5, Lqag;->c:Loj9;

    invoke-virtual {v5, v3}, Loj9;->b(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/node/LayoutNode;

    if-eqz v3, :cond_6f

    invoke-virtual {v3}, Landroidx/compose/ui/node/LayoutNode;->H()Lhag;

    move-result-object v3

    if-eqz v3, :cond_6f

    iget-object v3, v3, Lhag;->E:Lrdc;

    sget-object v5, Lfag;->g:Luag;

    invoke-virtual {v3, v5}, Lrdc;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v6, 0x0

    if-nez v5, :cond_33

    move-object v5, v6

    :cond_33
    check-cast v5, Le5;

    if-eqz v5, :cond_50

    iget-object v5, v5, Le5;->b:Lr98;

    check-cast v5, Lc98;

    if-eqz v5, :cond_50

    new-instance v7, Lkd0;

    invoke-static {v4}, Lss6;->k1(Landroid/view/autofill/AutofillValue;)Ljava/lang/CharSequence;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Lkd0;-><init>(Ljava/lang/String;)V

    invoke-interface {v5, v7}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    :cond_50
    sget-object v5, Lfag;->h:Luag;

    invoke-virtual {v3, v5}, Lrdc;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_59

    goto :goto_5a

    :cond_59
    move-object v6, v3

    :goto_5a
    check-cast v6, Le5;

    if-eqz v6, :cond_6f

    iget-object v3, v6, Le5;->b:Lr98;

    check-cast v3, Lc98;

    if-eqz v3, :cond_6f

    new-instance v5, Lh30;

    invoke-direct {v5, v4}, Lh30;-><init>(Landroid/view/autofill/AutofillValue;)V

    invoke-interface {v3, v5}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    :cond_6f
    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    :cond_72
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->t0:Ltfg;

    if-eqz p0, :cond_79

    invoke-static {p0, p1}, Legl;->v(Ltfg;Landroid/util/SparseArray;)V

    :cond_79
    return-void
.end method

.method public final canScrollHorizontally(I)Z
    .registers 5

    const/4 v0, 0x0

    iget-wide v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->F:J

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    invoke-virtual {p0, p1, v1, v2, v0}, Lm10;->h(IJZ)Z

    move-result p0

    return p0
.end method

.method public final canScrollVertically(I)Z
    .registers 5

    const/4 v0, 0x1

    iget-wide v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->F:J

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    invoke-virtual {p0, p1, v1, v2, v0}, Lm10;->h(IJZ)Z

    move-result p0

    return p0
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .registers 8

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->l0:Lddc;

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-nez v1, :cond_f

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    invoke-static {v1}, Landroidx/compose/ui/platform/AndroidComposeView;->m(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_f
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Landroidx/compose/ui/platform/AndroidComposeView;->u(Z)V

    invoke-static {}, Le7h;->j()Lx6h;

    move-result-object v2

    invoke-virtual {v2}, Lx6h;->m()V

    iput-boolean v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->n0:Z

    const-string v1, "AndroidOwner:draw"

    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_21
    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->W:Lpi2;

    iget-object v2, v1, Lpi2;->a:Lk00;

    iget-object v3, v2, Lk00;->a:Landroid/graphics/Canvas;

    iput-object p1, v2, Lk00;->a:Landroid/graphics/Canvas;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v4, v2, v5}, Landroidx/compose/ui/node/LayoutNode;->k(Lmi2;Lql8;)V

    iget-object v1, v1, Lpi2;->a:Lk00;

    iput-object v3, v1, Lk00;->a:Landroid/graphics/Canvas;

    invoke-virtual {v0}, Lddc;->i()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_4f

    iget v1, v0, Lddc;->b:I

    move v3, v2

    :goto_3f
    if-ge v3, v1, :cond_4f

    invoke-virtual {v0, v3}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lz4d;

    check-cast v4, Ltl8;

    invoke-virtual {v4}, Ltl8;->g()V

    add-int/lit8 v3, v3, 0x1

    goto :goto_3f

    :cond_4f
    sget v1, Lmmj;->E:I

    invoke-virtual {v0}, Lddc;->d()V

    iput-boolean v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->n0:Z
    :try_end_56
    .catchall {:try_start_21 .. :try_end_56} :catchall_90

    invoke-static {}, Landroid/os/Trace;->endSection()V

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->m0:Lddc;

    if-eqz v1, :cond_63

    invoke-virtual {v0, v1}, Lddc;->b(Lddc;)V

    invoke-virtual {v1}, Lddc;->d()V

    :cond_63
    invoke-static {}, Landroidx/compose/ui/platform/AndroidComposeView;->o()Z

    move-result v0

    if-eqz v0, :cond_8f

    iget v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->e1:F

    invoke-static {p0, v0}, Luf0;->a(Landroid/view/View;F)V

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->P:Landroid/view/View;

    if-eqz v0, :cond_89

    iget v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f1:F

    invoke-static {v0, v1}, Luf0;->a(Landroid/view/View;F)V

    iget v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f1:F

    invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z

    move-result v1

    if-nez v1, :cond_89

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    invoke-virtual {p0}, Landroid/view/View;->getDrawingTime()J

    move-result-wide v1

    invoke-virtual {p0, p1, v0, v1, v2}, Landroid/view/ViewGroup;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    :cond_89
    const/high16 p1, 0x7fc00000  # Float.NaN

    iput p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->e1:F

    iput p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f1:F

    :cond_8f
    return-void

    :catchall_90
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
.end method

.method public final dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 39

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-boolean v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->i1:Z

    const/16 v3, 0x8

    const/4 v4, 0x0

    if-eqz v2, :cond_1c

    iget-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->h1:Lq00;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v5

    if-ne v5, v3, :cond_19

    iput-boolean v4, v0, Landroidx/compose/ui/platform/AndroidComposeView;->i1:Z

    goto :goto_1c

    :cond_19
    invoke-virtual {v2}, Lq00;->run()V

    :cond_1c
    :goto_1c
    invoke-static {v1}, Landroidx/compose/ui/platform/AndroidComposeView;->p(Landroid/view/MotionEvent;)Z

    move-result v2

    if-nez v2, :cond_6d6

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v2

    if-nez v2, :cond_2a

    goto/16 :goto_6d6

    :cond_2a
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    const/16 v5, 0x10

    const-string v6, "visitAncestors called on an unattached node"

    const/4 v7, -0x1

    const/4 v9, 0x1

    if-ne v2, v3, :cond_260

    const/high16 v2, 0x400000

    invoke-virtual {v1, v2}, Landroid/view/InputEvent;->isFromSource(I)Z

    move-result v2

    if-eqz v2, :cond_256

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v2

    const/16 v3, 0x1a

    invoke-virtual {v1, v3}, Landroid/view/MotionEvent;->getAxisValue(I)F

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    invoke-static {v2}, Lycl;->p(Landroid/view/ViewConfiguration;)V

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    invoke-static {v2}, Lycl;->o(Landroid/view/ViewConfiguration;)V

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getDeviceId()I

    invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v2

    new-instance v3, Lz00;

    invoke-direct {v3, v0, v9, v1}, Lz00;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    check-cast v2, Lu28;

    iget-object v0, v2, Lu28;->d:Lp28;

    iget-boolean v0, v0, Lp28;->e:Z

    if-eqz v0, :cond_76

    const-string v0, "FocusRelatedWarning: Dispatching rotary event while the focus system is invalidated."

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/Object;)V

    return v4

    :cond_76
    iget-object v0, v2, Lu28;->c:Lm38;

    invoke-static {v0}, Lohl;->d(Lm38;)Lm38;

    move-result-object v0

    if-eqz v0, :cond_ff

    iget-object v1, v0, Ls7c;->E:Ls7c;

    iget-boolean v1, v1, Ls7c;->R:Z

    if-nez v1, :cond_87

    invoke-static {v6}, Ldf9;->c(Ljava/lang/String;)V

    :cond_87
    iget-object v1, v0, Ls7c;->E:Ls7c;

    invoke-static {v0}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    :goto_8d
    if-eqz v0, :cond_fb

    iget-object v2, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v2, v2, Lxmc;->K:Ljava/lang/Object;

    check-cast v2, Ls7c;

    iget v2, v2, Ls7c;->H:I

    and-int/lit16 v2, v2, 0x4000

    if-eqz v2, :cond_ea

    :goto_9b
    if-eqz v1, :cond_ea

    iget v2, v1, Ls7c;->G:I

    and-int/lit16 v2, v2, 0x4000

    if-eqz v2, :cond_e7

    move-object v2, v1

    const/4 v10, 0x0

    :goto_a5
    if-eqz v2, :cond_e7

    instance-of v11, v2, Lv00;

    if-eqz v11, :cond_ac

    goto :goto_fc

    :cond_ac
    iget v11, v2, Ls7c;->G:I

    and-int/lit16 v11, v11, 0x4000

    if-eqz v11, :cond_e2

    instance-of v11, v2, Ls46;

    if-eqz v11, :cond_e2

    move-object v11, v2

    check-cast v11, Ls46;

    iget-object v11, v11, Ls46;->T:Ls7c;

    move v12, v4

    :goto_bc
    if-eqz v11, :cond_df

    iget v13, v11, Ls7c;->G:I

    and-int/lit16 v13, v13, 0x4000

    if-eqz v13, :cond_dc

    add-int/lit8 v12, v12, 0x1

    if-ne v12, v9, :cond_ca

    move-object v2, v11

    goto :goto_dc

    :cond_ca
    if-nez v10, :cond_d3

    new-instance v10, Ljec;

    new-array v13, v5, [Ls7c;

    invoke-direct {v10, v4, v13}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_d3
    if-eqz v2, :cond_d9

    invoke-virtual {v10, v2}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v2, 0x0

    :cond_d9
    invoke-virtual {v10, v11}, Ljec;->b(Ljava/lang/Object;)V

    :cond_dc
    :goto_dc
    iget-object v11, v11, Ls7c;->J:Ls7c;

    goto :goto_bc

    :cond_df
    if-ne v12, v9, :cond_e2

    goto :goto_a5

    :cond_e2
    invoke-static {v10}, La60;->l(Ljec;)Ls7c;

    move-result-object v2

    goto :goto_a5

    :cond_e7
    iget-object v1, v1, Ls7c;->I:Ls7c;

    goto :goto_9b

    :cond_ea
    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_f9

    iget-object v1, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v1, :cond_f9

    iget-object v1, v1, Lxmc;->J:Ljava/lang/Object;

    check-cast v1, Lhzh;

    goto :goto_8d

    :cond_f9
    const/4 v1, 0x0

    goto :goto_8d

    :cond_fb
    const/4 v2, 0x0

    :goto_fc
    check-cast v2, Lv00;

    goto :goto_100

    :cond_ff
    const/4 v2, 0x0

    :goto_100
    if-eqz v2, :cond_25f

    iget-object v0, v2, Ls7c;->E:Ls7c;

    iget-boolean v0, v0, Ls7c;->R:Z

    if-nez v0, :cond_10b

    invoke-static {v6}, Ldf9;->c(Ljava/lang/String;)V

    :cond_10b
    iget-object v0, v2, Ls7c;->E:Ls7c;

    iget-object v0, v0, Ls7c;->I:Ls7c;

    invoke-static {v2}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    const/4 v6, 0x0

    :goto_114
    if-eqz v1, :cond_190

    iget-object v10, v1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v10, v10, Lxmc;->K:Ljava/lang/Object;

    check-cast v10, Ls7c;

    iget v10, v10, Ls7c;->H:I

    and-int/lit16 v10, v10, 0x4000

    if-eqz v10, :cond_17f

    :goto_122
    if-eqz v0, :cond_17f

    iget v10, v0, Ls7c;->G:I

    and-int/lit16 v10, v10, 0x4000

    if-eqz v10, :cond_17c

    move-object v10, v0

    const/4 v11, 0x0

    :goto_12c
    if-eqz v10, :cond_17c

    instance-of v12, v10, Lv00;

    if-eqz v12, :cond_13e

    if-nez v6, :cond_139

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    :cond_139
    invoke-interface {v6, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v12, v4

    goto :goto_13f

    :cond_13e
    move v12, v9

    :goto_13f
    if-eqz v12, :cond_177

    iget v12, v10, Ls7c;->G:I

    and-int/lit16 v12, v12, 0x4000

    if-eqz v12, :cond_177

    instance-of v12, v10, Ls46;

    if-eqz v12, :cond_177

    move-object v12, v10

    check-cast v12, Ls46;

    iget-object v12, v12, Ls46;->T:Ls7c;

    move v13, v4

    :goto_151
    if-eqz v12, :cond_174

    iget v14, v12, Ls7c;->G:I

    and-int/lit16 v14, v14, 0x4000

    if-eqz v14, :cond_171

    add-int/lit8 v13, v13, 0x1

    if-ne v13, v9, :cond_15f

    move-object v10, v12

    goto :goto_171

    :cond_15f
    if-nez v11, :cond_168

    new-instance v11, Ljec;

    new-array v14, v5, [Ls7c;

    invoke-direct {v11, v4, v14}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_168
    if-eqz v10, :cond_16e

    invoke-virtual {v11, v10}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v10, 0x0

    :cond_16e
    invoke-virtual {v11, v12}, Ljec;->b(Ljava/lang/Object;)V

    :cond_171
    :goto_171
    iget-object v12, v12, Ls7c;->J:Ls7c;

    goto :goto_151

    :cond_174
    if-ne v13, v9, :cond_177

    goto :goto_12c

    :cond_177
    invoke-static {v11}, La60;->l(Ljec;)Ls7c;

    move-result-object v10

    goto :goto_12c

    :cond_17c
    iget-object v0, v0, Ls7c;->I:Ls7c;

    goto :goto_122

    :cond_17f
    invoke-virtual {v1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    if-eqz v1, :cond_18e

    iget-object v0, v1, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v0, :cond_18e

    iget-object v0, v0, Lxmc;->J:Ljava/lang/Object;

    check-cast v0, Lhzh;

    goto :goto_114

    :cond_18e
    const/4 v0, 0x0

    goto :goto_114

    :cond_190
    if-eqz v6, :cond_1a9

    invoke-interface {v6}, Ljava/util/Collection;->size()I

    move-result v0

    add-int/2addr v0, v7

    if-ltz v0, :cond_1a9

    :goto_199
    add-int/lit8 v1, v0, -0x1

    invoke-interface {v6, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lv00;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-gez v1, :cond_1a7

    goto :goto_1a9

    :cond_1a7
    move v0, v1

    goto :goto_199

    :cond_1a9
    :goto_1a9
    iget-object v0, v2, Ls7c;->E:Ls7c;

    const/4 v1, 0x0

    :goto_1ac
    if-eqz v0, :cond_1ee

    instance-of v7, v0, Lv00;

    if-eqz v7, :cond_1b3

    goto :goto_1e9

    :cond_1b3
    iget v7, v0, Ls7c;->G:I

    and-int/lit16 v7, v7, 0x4000

    if-eqz v7, :cond_1e9

    instance-of v7, v0, Ls46;

    if-eqz v7, :cond_1e9

    move-object v7, v0

    check-cast v7, Ls46;

    iget-object v7, v7, Ls46;->T:Ls7c;

    move v10, v4

    :goto_1c3
    if-eqz v7, :cond_1e6

    iget v11, v7, Ls7c;->G:I

    and-int/lit16 v11, v11, 0x4000

    if-eqz v11, :cond_1e3

    add-int/lit8 v10, v10, 0x1

    if-ne v10, v9, :cond_1d1

    move-object v0, v7

    goto :goto_1e3

    :cond_1d1
    if-nez v1, :cond_1da

    new-instance v1, Ljec;

    new-array v11, v5, [Ls7c;

    invoke-direct {v1, v4, v11}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_1da
    if-eqz v0, :cond_1e0

    invoke-virtual {v1, v0}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v0, 0x0

    :cond_1e0
    invoke-virtual {v1, v7}, Ljec;->b(Ljava/lang/Object;)V

    :cond_1e3
    :goto_1e3
    iget-object v7, v7, Ls7c;->J:Ls7c;

    goto :goto_1c3

    :cond_1e6
    if-ne v10, v9, :cond_1e9

    goto :goto_1ac

    :cond_1e9
    :goto_1e9
    invoke-static {v1}, La60;->l(Ljec;)Ls7c;

    move-result-object v0

    goto :goto_1ac

    :cond_1ee
    invoke-virtual {v3}, Lz00;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1fc

    goto/16 :goto_25e

    :cond_1fc
    iget-object v0, v2, Ls7c;->E:Ls7c;

    const/4 v1, 0x0

    :goto_1ff
    if-eqz v0, :cond_241

    instance-of v2, v0, Lv00;

    if-eqz v2, :cond_206

    goto :goto_23c

    :cond_206
    iget v2, v0, Ls7c;->G:I

    and-int/lit16 v2, v2, 0x4000

    if-eqz v2, :cond_23c

    instance-of v2, v0, Ls46;

    if-eqz v2, :cond_23c

    move-object v2, v0

    check-cast v2, Ls46;

    iget-object v2, v2, Ls46;->T:Ls7c;

    move v3, v4

    :goto_216
    if-eqz v2, :cond_239

    iget v7, v2, Ls7c;->G:I

    and-int/lit16 v7, v7, 0x4000

    if-eqz v7, :cond_236

    add-int/lit8 v3, v3, 0x1

    if-ne v3, v9, :cond_224

    move-object v0, v2

    goto :goto_236

    :cond_224
    if-nez v1, :cond_22d

    new-instance v1, Ljec;

    new-array v7, v5, [Ls7c;

    invoke-direct {v1, v4, v7}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_22d
    if-eqz v0, :cond_233

    invoke-virtual {v1, v0}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v0, 0x0

    :cond_233
    invoke-virtual {v1, v2}, Ljec;->b(Ljava/lang/Object;)V

    :cond_236
    :goto_236
    iget-object v2, v2, Ls7c;->J:Ls7c;

    goto :goto_216

    :cond_239
    if-ne v3, v9, :cond_23c

    goto :goto_1ff

    :cond_23c
    :goto_23c
    invoke-static {v1}, La60;->l(Ljec;)Ls7c;

    move-result-object v0

    goto :goto_1ff

    :cond_241
    if-eqz v6, :cond_25f

    invoke-interface {v6}, Ljava/util/Collection;->size()I

    move-result v0

    move v1, v4

    :goto_248
    if-ge v1, v0, :cond_25f

    invoke-interface {v6, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lv00;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v1, v1, 0x1

    goto :goto_248

    :cond_256
    invoke-virtual/range {p0 .. p1}, Landroidx/compose/ui/platform/AndroidComposeView;->l(Landroid/view/MotionEvent;)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_25f

    :goto_25e
    return v9

    :cond_25f
    return v4

    :cond_260
    const/high16 v2, 0x200000

    invoke-virtual {v1, v2}, Landroid/view/InputEvent;->isFromSource(I)Z

    move-result v3

    if-eqz v3, :cond_6d1

    iget-object v3, v0, Landroidx/compose/ui/platform/AndroidComposeView;->H:Lod9;

    iget-object v10, v0, Landroidx/compose/ui/platform/AndroidComposeView;->p0:Lf9c;

    iget-object v11, v10, Lf9c;->e:Lgya;

    iget-object v12, v10, Lf9c;->b:Landroid/util/SparseLongArray;

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v13

    invoke-virtual {v10, v1}, Lf9c;->b(Landroid/view/MotionEvent;)V

    const/4 v14, 0x3

    const/4 v15, 0x2

    if-ne v13, v14, :cond_28b

    invoke-virtual {v12}, Landroid/util/SparseLongArray;->clear()V

    iget-object v1, v10, Lf9c;->c:Landroid/util/SparseBooleanArray;

    invoke-virtual {v1}, Landroid/util/SparseBooleanArray;->clear()V

    move/from16 v16, v2

    move-object v4, v6

    move/from16 v17, v7

    const/4 v3, 0x0

    goto/16 :goto_393

    :cond_28b
    invoke-virtual {v10, v1}, Lf9c;->a(Landroid/view/MotionEvent;)V

    if-eq v13, v9, :cond_29a

    const/4 v14, 0x6

    if-eq v13, v14, :cond_295

    move v14, v7

    goto :goto_29b

    :cond_295
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v14

    goto :goto_29b

    :cond_29a
    move v14, v4

    :goto_29b
    if-eqz v13, :cond_2a6

    if-eq v13, v15, :cond_2a6

    move/from16 v16, v2

    const/4 v2, 0x5

    if-eq v13, v2, :cond_2a8

    move v2, v4

    goto :goto_2a9

    :cond_2a6
    move/from16 v16, v2

    :cond_2a8
    move v2, v9

    :goto_2a9
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v13

    move/from16 v17, v7

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7, v13}, Ljava/util/ArrayList;-><init>(I)V

    move v8, v4

    :goto_2b5
    if-ge v8, v13, :cond_37c

    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v15

    invoke-virtual {v12, v15}, Landroid/util/SparseLongArray;->indexOfKey(I)I

    move-result v4

    if-ltz v4, :cond_2cd

    invoke-virtual {v12, v4}, Landroid/util/SparseLongArray;->valueAt(I)J

    move-result-wide v18

    move/from16 v22, v2

    move-object/from16 v21, v3

    move-object v4, v6

    move-wide/from16 v5, v18

    goto :goto_2dd

    :cond_2cd
    move-object v4, v6

    iget-wide v5, v10, Lf9c;->a:J

    const-wide/16 v19, 0x1

    move/from16 v22, v2

    move-object/from16 v21, v3

    add-long v2, v5, v19

    iput-wide v2, v10, Lf9c;->a:J

    invoke-virtual {v12, v15, v5, v6}, Landroid/util/SparseLongArray;->put(IJ)V

    :goto_2dd
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getX(I)F

    move-result v2

    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getY(I)F

    move-result v3

    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v2

    move-object/from16 v19, v10

    int-to-long v9, v2

    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v2

    int-to-long v2, v2

    const/16 v20, 0x20

    shl-long v9, v9, v20

    const-wide v23, 0xffffffffL

    and-long v2, v2, v23

    or-long/2addr v2, v9

    if-eq v8, v14, :cond_302

    const/16 v30, 0x1

    goto :goto_304

    :cond_302
    const/16 v30, 0x0

    :goto_304
    invoke-virtual {v11, v5, v6}, Lgya;->b(J)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Le9c;

    if-ne v8, v14, :cond_312

    invoke-virtual {v11, v5, v6}, Lgya;->f(J)V

    move-object/from16 v20, v9

    goto :goto_325

    :cond_312
    move-object/from16 v20, v9

    if-eqz v22, :cond_325

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v9

    invoke-static {v9, v10, v2, v3}, Le9c;->b(JJ)J

    move-result-wide v9

    invoke-static {v9, v10}, Le9c;->a(J)Le9c;

    move-result-object v9

    invoke-virtual {v11, v5, v6, v9}, Lgya;->e(JLjava/lang/Object;)V

    :cond_325
    :goto_325
    new-instance v23, Lpd9;

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v26

    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getPressure(I)F

    move-result v31

    if-eqz v20, :cond_33c

    invoke-virtual/range {v20 .. v20}, Le9c;->f()J

    move-result-wide v9

    invoke-static {v9, v10}, Le9c;->e(J)J

    move-result-wide v9

    :goto_339
    move-wide/from16 v32, v9

    goto :goto_341

    :cond_33c
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v9

    goto :goto_339

    :goto_341
    if-eqz v20, :cond_34e

    invoke-virtual/range {v20 .. v20}, Le9c;->f()J

    move-result-wide v9

    invoke-static {v9, v10}, Le9c;->d(J)J

    move-result-wide v9

    move-wide/from16 v34, v9

    goto :goto_350

    :cond_34e
    move-wide/from16 v34, v2

    :goto_350
    if-eqz v20, :cond_361

    invoke-virtual/range {v20 .. v20}, Le9c;->f()J

    move-result-wide v9

    invoke-static {v9, v10}, Le9c;->c(J)Z

    move-result v9

    move/from16 v36, v9

    :goto_35c
    move-wide/from16 v28, v2

    move-wide/from16 v24, v5

    goto :goto_364

    :cond_361
    const/16 v36, 0x0

    goto :goto_35c

    :goto_364
    invoke-direct/range {v23 .. v36}, Lpd9;-><init>(JJJZFJJZ)V

    move-object/from16 v2, v23

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v8, v8, 0x1

    move-object v6, v4

    move-object/from16 v10, v19

    move-object/from16 v3, v21

    move/from16 v2, v22

    const/4 v4, 0x0

    const/16 v5, 0x10

    const/4 v9, 0x1

    const/4 v15, 0x2

    goto/16 :goto_2b5

    :cond_37c
    move-object/from16 v21, v3

    move-object v4, v6

    move-object v2, v10

    invoke-virtual {v2, v1}, Lf9c;->e(Landroid/view/MotionEvent;)V

    if-eqz v21, :cond_38a

    move-object/from16 v2, v21

    iget v2, v2, Lod9;->a:I

    goto :goto_38e

    :cond_38a
    invoke-static {v1}, Lqgl;->t(Landroid/view/MotionEvent;)I

    move-result v2

    :goto_38e
    new-instance v3, Lv30;

    invoke-direct {v3, v7, v2, v1}, Lv30;-><init>(Ljava/util/ArrayList;ILandroid/view/MotionEvent;)V

    :goto_393
    iget-object v1, v0, Landroidx/compose/ui/platform/AndroidComposeView;->j1:Lzd9;

    if-eqz v3, :cond_578

    invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    check-cast v0, Lu28;

    iget-object v2, v0, Lu28;->d:Lp28;

    iget-boolean v2, v2, Lp28;->e:Z

    if-eqz v2, :cond_3ad

    const-string v0, "FocusRelatedWarning: Dispatching indirect pointer event while the focus system is invalidated."

    sget-object v2, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v2, v0}, Ljava/io/PrintStream;->println(Ljava/lang/Object;)V

    :cond_3aa
    const/4 v0, 0x0

    goto/16 :goto_54a

    :cond_3ad
    invoke-virtual {v0}, Lu28;->h()Lm38;

    move-result-object v0

    if-eqz v0, :cond_439

    iget-object v2, v0, Ls7c;->E:Ls7c;

    iget-boolean v2, v2, Ls7c;->R:Z

    if-nez v2, :cond_3bc

    invoke-static {v4}, Ldf9;->c(Ljava/lang/String;)V

    :cond_3bc
    iget-object v2, v0, Ls7c;->E:Ls7c;

    invoke-static {v0}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    :goto_3c2
    if-eqz v0, :cond_435

    iget-object v5, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v5, v5, Lxmc;->K:Ljava/lang/Object;

    check-cast v5, Ls7c;

    iget v5, v5, Ls7c;->H:I

    and-int v5, v5, v16

    if-eqz v5, :cond_424

    :goto_3d0
    if-eqz v2, :cond_424

    iget v5, v2, Ls7c;->G:I

    and-int v5, v5, v16

    if-eqz v5, :cond_421

    move-object v5, v2

    const/4 v6, 0x0

    :goto_3da
    if-eqz v5, :cond_421

    instance-of v7, v5, Lxd9;

    if-eqz v7, :cond_3e1

    goto :goto_436

    :cond_3e1
    iget v7, v5, Ls7c;->G:I

    and-int v7, v7, v16

    if-eqz v7, :cond_41c

    instance-of v7, v5, Ls46;

    if-eqz v7, :cond_41c

    move-object v7, v5

    check-cast v7, Ls46;

    iget-object v7, v7, Ls46;->T:Ls7c;

    const/4 v8, 0x0

    :goto_3f1
    if-eqz v7, :cond_418

    iget v9, v7, Ls7c;->G:I

    and-int v9, v9, v16

    if-eqz v9, :cond_415

    add-int/lit8 v8, v8, 0x1

    const/4 v15, 0x1

    if-ne v8, v15, :cond_400

    move-object v5, v7

    goto :goto_415

    :cond_400
    if-nez v6, :cond_40c

    new-instance v6, Ljec;

    const/16 v9, 0x10

    new-array v10, v9, [Ls7c;

    const/4 v9, 0x0

    invoke-direct {v6, v9, v10}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_40c
    if-eqz v5, :cond_412

    invoke-virtual {v6, v5}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v5, 0x0

    :cond_412
    invoke-virtual {v6, v7}, Ljec;->b(Ljava/lang/Object;)V

    :cond_415
    :goto_415
    iget-object v7, v7, Ls7c;->J:Ls7c;

    goto :goto_3f1

    :cond_418
    const/4 v15, 0x1

    if-ne v8, v15, :cond_41c

    goto :goto_3da

    :cond_41c
    invoke-static {v6}, La60;->l(Ljec;)Ls7c;

    move-result-object v5

    goto :goto_3da

    :cond_421
    iget-object v2, v2, Ls7c;->I:Ls7c;

    goto :goto_3d0

    :cond_424
    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_433

    iget-object v2, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v2, :cond_433

    iget-object v2, v2, Lxmc;->J:Ljava/lang/Object;

    check-cast v2, Lhzh;

    goto :goto_3c2

    :cond_433
    const/4 v2, 0x0

    goto :goto_3c2

    :cond_435
    const/4 v5, 0x0

    :goto_436
    check-cast v5, Lxd9;

    goto :goto_43a

    :cond_439
    const/4 v5, 0x0

    :goto_43a
    if-eqz v5, :cond_52b

    move-object v0, v5

    check-cast v0, Ls7c;

    iget-object v2, v0, Ls7c;->E:Ls7c;

    iget-boolean v2, v2, Ls7c;->R:Z

    if-nez v2, :cond_448

    invoke-static {v4}, Ldf9;->c(Ljava/lang/String;)V

    :cond_448
    iget-object v0, v0, Ls7c;->E:Ls7c;

    iget-object v0, v0, Ls7c;->I:Ls7c;

    invoke-static {v5}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v2

    const/4 v4, 0x0

    :goto_451
    if-eqz v2, :cond_4d3

    iget-object v6, v2, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v6, v6, Lxmc;->K:Ljava/lang/Object;

    check-cast v6, Ls7c;

    iget v6, v6, Ls7c;->H:I

    and-int v6, v6, v16

    if-eqz v6, :cond_4c1

    :goto_45f
    if-eqz v0, :cond_4c1

    iget v6, v0, Ls7c;->G:I

    and-int v6, v6, v16

    if-eqz v6, :cond_4be

    move-object v6, v0

    const/4 v7, 0x0

    :goto_469
    if-eqz v6, :cond_4be

    instance-of v8, v6, Lxd9;

    if-eqz v8, :cond_47b

    if-nez v4, :cond_476

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :cond_476
    invoke-interface {v4, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x0

    goto :goto_47c

    :cond_47b
    const/4 v8, 0x1

    :goto_47c
    if-eqz v8, :cond_4b9

    iget v8, v6, Ls7c;->G:I

    and-int v8, v8, v16

    if-eqz v8, :cond_4b9

    instance-of v8, v6, Ls46;

    if-eqz v8, :cond_4b9

    move-object v8, v6

    check-cast v8, Ls46;

    iget-object v8, v8, Ls46;->T:Ls7c;

    const/4 v9, 0x0

    :goto_48e
    if-eqz v8, :cond_4b5

    iget v10, v8, Ls7c;->G:I

    and-int v10, v10, v16

    if-eqz v10, :cond_4b2

    add-int/lit8 v9, v9, 0x1

    const/4 v15, 0x1

    if-ne v9, v15, :cond_49d

    move-object v6, v8

    goto :goto_4b2

    :cond_49d
    if-nez v7, :cond_4a9

    new-instance v7, Ljec;

    const/16 v10, 0x10

    new-array v11, v10, [Ls7c;

    const/4 v10, 0x0

    invoke-direct {v7, v10, v11}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_4a9
    if-eqz v6, :cond_4af

    invoke-virtual {v7, v6}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v6, 0x0

    :cond_4af
    invoke-virtual {v7, v8}, Ljec;->b(Ljava/lang/Object;)V

    :cond_4b2
    :goto_4b2
    iget-object v8, v8, Ls7c;->J:Ls7c;

    goto :goto_48e

    :cond_4b5
    const/4 v15, 0x1

    if-ne v9, v15, :cond_4b9

    goto :goto_469

    :cond_4b9
    invoke-static {v7}, La60;->l(Ljec;)Ls7c;

    move-result-object v6

    goto :goto_469

    :cond_4be
    iget-object v0, v0, Ls7c;->I:Ls7c;

    goto :goto_45f

    :cond_4c1
    invoke-virtual {v2}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v2

    if-eqz v2, :cond_4d0

    iget-object v0, v2, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v0, :cond_4d0

    iget-object v0, v0, Lxmc;->J:Ljava/lang/Object;

    check-cast v0, Lhzh;

    goto :goto_451

    :cond_4d0
    const/4 v0, 0x0

    goto/16 :goto_451

    :cond_4d3
    sget-object v0, Lxqd;->E:Lxqd;

    if-eqz v4, :cond_4ef

    invoke-interface {v4}, Ljava/util/Collection;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    if-ltz v2, :cond_4ef

    :goto_4df
    add-int/lit8 v6, v2, -0x1

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lxd9;

    invoke-interface {v2, v3, v0}, Lxd9;->A(Lv30;Lxqd;)V

    if-gez v6, :cond_4ed

    goto :goto_4ef

    :cond_4ed
    move v2, v6

    goto :goto_4df

    :cond_4ef
    :goto_4ef
    invoke-interface {v5, v3, v0}, Lxd9;->A(Lv30;Lxqd;)V

    sget-object v0, Lxqd;->F:Lxqd;

    invoke-interface {v5, v3, v0}, Lxd9;->A(Lv30;Lxqd;)V

    if-eqz v4, :cond_50c

    invoke-interface {v4}, Ljava/util/Collection;->size()I

    move-result v2

    const/4 v6, 0x0

    :goto_4fe
    if-ge v6, v2, :cond_50c

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lxd9;

    invoke-interface {v7, v3, v0}, Lxd9;->A(Lv30;Lxqd;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_4fe

    :cond_50c
    sget-object v0, Lxqd;->G:Lxqd;

    if-eqz v4, :cond_528

    invoke-interface {v4}, Ljava/util/Collection;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    if-ltz v2, :cond_528

    :goto_518
    add-int/lit8 v6, v2, -0x1

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lxd9;

    invoke-interface {v2, v3, v0}, Lxd9;->A(Lv30;Lxqd;)V

    if-gez v6, :cond_526

    goto :goto_528

    :cond_526
    move v2, v6

    goto :goto_518

    :cond_528
    :goto_528
    invoke-interface {v5, v3, v0}, Lxd9;->A(Lv30;Lxqd;)V

    :cond_52b
    invoke-virtual {v3}, Lv30;->f()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v2

    const/4 v4, 0x0

    :goto_534
    if-ge v4, v2, :cond_3aa

    move-object v5, v0

    check-cast v5, Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lpd9;

    invoke-virtual {v5}, Lpd9;->f()Z

    move-result v5

    if-eqz v5, :cond_547

    const/4 v0, 0x1

    goto :goto_54a

    :cond_547
    add-int/lit8 v4, v4, 0x1

    goto :goto_534

    :goto_54a
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3}, Lqgl;->n(Lv30;)Landroid/view/MotionEvent;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/MotionEvent;->getAction()I

    move-result v4

    if-eqz v4, :cond_566

    const/4 v15, 0x1

    if-eq v4, v15, :cond_55e

    const/4 v3, 0x2

    if-eq v4, v3, :cond_55e

    goto :goto_570

    :cond_55e
    if-eqz v0, :cond_570

    const/4 v9, 0x0

    iput v9, v1, Lzd9;->b:I

    iput-boolean v15, v1, Lzd9;->a:Z

    goto :goto_570

    :cond_566
    const/4 v9, 0x0

    const/4 v15, 0x1

    invoke-virtual {v3}, Lv30;->h()I

    move-result v0

    iput v0, v1, Lzd9;->b:I

    iput-boolean v9, v1, Lzd9;->a:Z

    :cond_570
    :goto_570
    iget-object v0, v1, Lzd9;->d:Ljava/lang/Object;

    check-cast v0, Landroid/view/GestureDetector;

    invoke-virtual {v0, v2}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    return v15

    :cond_578
    invoke-virtual {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    check-cast v0, Lu28;

    invoke-virtual {v0}, Lu28;->h()Lm38;

    move-result-object v0

    if-eqz v0, :cond_60a

    iget-object v2, v0, Ls7c;->E:Ls7c;

    iget-boolean v2, v2, Ls7c;->R:Z

    if-nez v2, :cond_58d

    invoke-static {v4}, Ldf9;->c(Ljava/lang/String;)V

    :cond_58d
    iget-object v2, v0, Ls7c;->E:Ls7c;

    invoke-static {v0}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    :goto_593
    if-eqz v0, :cond_606

    iget-object v3, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v3, v3, Lxmc;->K:Ljava/lang/Object;

    check-cast v3, Ls7c;

    iget v3, v3, Ls7c;->H:I

    and-int v3, v3, v16

    if-eqz v3, :cond_5f5

    :goto_5a1
    if-eqz v2, :cond_5f5

    iget v3, v2, Ls7c;->G:I

    and-int v3, v3, v16

    if-eqz v3, :cond_5f2

    move-object v3, v2

    const/4 v5, 0x0

    :goto_5ab
    if-eqz v3, :cond_5f2

    instance-of v6, v3, Lxd9;

    if-eqz v6, :cond_5b2

    goto :goto_607

    :cond_5b2
    iget v6, v3, Ls7c;->G:I

    and-int v6, v6, v16

    if-eqz v6, :cond_5ed

    instance-of v6, v3, Ls46;

    if-eqz v6, :cond_5ed

    move-object v6, v3

    check-cast v6, Ls46;

    iget-object v6, v6, Ls46;->T:Ls7c;

    const/4 v7, 0x0

    :goto_5c2
    if-eqz v6, :cond_5e9

    iget v8, v6, Ls7c;->G:I

    and-int v8, v8, v16

    if-eqz v8, :cond_5e6

    add-int/lit8 v7, v7, 0x1

    const/4 v15, 0x1

    if-ne v7, v15, :cond_5d1

    move-object v3, v6

    goto :goto_5e6

    :cond_5d1
    if-nez v5, :cond_5dd

    new-instance v5, Ljec;

    const/16 v9, 0x10

    new-array v8, v9, [Ls7c;

    const/4 v9, 0x0

    invoke-direct {v5, v9, v8}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_5dd
    if-eqz v3, :cond_5e3

    invoke-virtual {v5, v3}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v3, 0x0

    :cond_5e3
    invoke-virtual {v5, v6}, Ljec;->b(Ljava/lang/Object;)V

    :cond_5e6
    :goto_5e6
    iget-object v6, v6, Ls7c;->J:Ls7c;

    goto :goto_5c2

    :cond_5e9
    const/4 v15, 0x1

    if-ne v7, v15, :cond_5ed

    goto :goto_5ab

    :cond_5ed
    invoke-static {v5}, La60;->l(Ljec;)Ls7c;

    move-result-object v3

    goto :goto_5ab

    :cond_5f2
    iget-object v2, v2, Ls7c;->I:Ls7c;

    goto :goto_5a1

    :cond_5f5
    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_604

    iget-object v2, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v2, :cond_604

    iget-object v2, v2, Lxmc;->J:Ljava/lang/Object;

    check-cast v2, Lhzh;

    goto :goto_593

    :cond_604
    const/4 v2, 0x0

    goto :goto_593

    :cond_606
    const/4 v3, 0x0

    :goto_607
    check-cast v3, Lxd9;

    goto :goto_60b

    :cond_60a
    const/4 v3, 0x0

    :goto_60b
    if-eqz v3, :cond_6ca

    move-object v0, v3

    check-cast v0, Ls7c;

    iget-object v2, v0, Ls7c;->E:Ls7c;

    iget-boolean v2, v2, Ls7c;->R:Z

    if-nez v2, :cond_619

    invoke-static {v4}, Ldf9;->c(Ljava/lang/String;)V

    :cond_619
    iget-object v0, v0, Ls7c;->E:Ls7c;

    iget-object v0, v0, Ls7c;->I:Ls7c;

    invoke-static {v3}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v2

    const/4 v4, 0x0

    :goto_622
    if-eqz v2, :cond_6b2

    iget-object v5, v2, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v5, v5, Lxmc;->K:Ljava/lang/Object;

    check-cast v5, Ls7c;

    iget v5, v5, Ls7c;->H:I

    and-int v5, v5, v16

    if-eqz v5, :cond_69d

    :goto_630
    if-eqz v0, :cond_69d

    iget v5, v0, Ls7c;->G:I

    and-int v5, v5, v16

    if-eqz v5, :cond_698

    move-object v5, v0

    const/4 v6, 0x0

    :goto_63a
    if-eqz v5, :cond_698

    instance-of v7, v5, Lxd9;

    if-eqz v7, :cond_64c

    if-nez v4, :cond_647

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :cond_647
    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x0

    goto :goto_64d

    :cond_64c
    const/4 v7, 0x1

    :goto_64d
    if-eqz v7, :cond_691

    iget v7, v5, Ls7c;->G:I

    and-int v7, v7, v16

    if-eqz v7, :cond_691

    instance-of v7, v5, Ls46;

    if-eqz v7, :cond_691

    move-object v7, v5

    check-cast v7, Ls46;

    iget-object v7, v7, Ls46;->T:Ls7c;

    const/4 v9, 0x0

    :goto_65f
    if-eqz v7, :cond_68b

    iget v8, v7, Ls7c;->G:I

    and-int v8, v8, v16

    if-eqz v8, :cond_66d

    add-int/lit8 v9, v9, 0x1

    const/4 v15, 0x1

    if-ne v9, v15, :cond_670

    move-object v5, v7

    :cond_66d
    const/16 v10, 0x10

    goto :goto_688

    :cond_670
    if-nez v6, :cond_67d

    new-instance v6, Ljec;

    const/16 v10, 0x10

    new-array v8, v10, [Ls7c;

    const/4 v11, 0x0

    invoke-direct {v6, v11, v8}, Ljec;-><init>(I[Ljava/lang/Object;)V

    goto :goto_67f

    :cond_67d
    const/16 v10, 0x10

    :goto_67f
    if-eqz v5, :cond_685

    invoke-virtual {v6, v5}, Ljec;->b(Ljava/lang/Object;)V

    const/4 v5, 0x0

    :cond_685
    invoke-virtual {v6, v7}, Ljec;->b(Ljava/lang/Object;)V

    :goto_688
    iget-object v7, v7, Ls7c;->J:Ls7c;

    goto :goto_65f

    :cond_68b
    const/16 v10, 0x10

    const/4 v15, 0x1

    if-ne v9, v15, :cond_693

    goto :goto_63a

    :cond_691
    const/16 v10, 0x10

    :cond_693
    invoke-static {v6}, La60;->l(Ljec;)Ls7c;

    move-result-object v5

    goto :goto_63a

    :cond_698
    const/16 v10, 0x10

    iget-object v0, v0, Ls7c;->I:Ls7c;

    goto :goto_630

    :cond_69d
    const/16 v10, 0x10

    invoke-virtual {v2}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v2

    if-eqz v2, :cond_6af

    iget-object v0, v2, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v0, :cond_6af

    iget-object v0, v0, Lxmc;->J:Ljava/lang/Object;

    check-cast v0, Lhzh;

    goto/16 :goto_622

    :cond_6af
    const/4 v0, 0x0

    goto/16 :goto_622

    :cond_6b2
    invoke-interface {v3}, Lxd9;->u0()V

    if-eqz v4, :cond_6ca

    invoke-interface {v4}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v9, 0x0

    :goto_6bc
    if-ge v9, v0, :cond_6ca

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lxd9;

    invoke-interface {v2}, Lxd9;->u0()V

    add-int/lit8 v9, v9, 0x1

    goto :goto_6bc

    :cond_6ca
    const/4 v9, 0x0

    iput v9, v1, Lzd9;->b:I

    const/4 v15, 0x1

    iput-boolean v15, v1, Lzd9;->a:Z

    return v15

    :cond_6d1
    invoke-super/range {p0 .. p1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    return v0

    :cond_6d6
    :goto_6d6
    invoke-super/range {p0 .. p1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    return v0
.end method

.method public final dispatchHoverEvent(Landroid/view/MotionEvent;)Z
    .registers 25

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-boolean v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->i1:Z

    iget-object v3, v0, Landroidx/compose/ui/platform/AndroidComposeView;->h1:Lq00;

    if-eqz v2, :cond_10

    invoke-virtual {v0, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {v3}, Lq00;->run()V

    :cond_10
    invoke-static {v1}, Landroidx/compose/ui/platform/AndroidComposeView;->p(Landroid/view/MotionEvent;)Z

    move-result v2

    const/4 v4, 0x0

    if-nez v2, :cond_158

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v2

    if-nez v2, :cond_1f

    goto/16 :goto_158

    :cond_1f
    iget-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    iget-object v5, v2, Lm10;->H:Landroidx/compose/ui/platform/AndroidComposeView;

    iget-object v6, v2, Lm10;->K:Landroid/view/accessibility/AccessibilityManager;

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    move-result v7

    const/16 v8, 0xa

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-eqz v7, :cond_114

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityManager;->isTouchExplorationEnabled()Z

    move-result v6

    if-eqz v6, :cond_114

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getAction()I

    move-result v6

    const/16 v7, 0x100

    const/16 v11, 0x80

    const/4 v12, 0x0

    const/16 v13, 0xc

    const/high16 v14, -0x80000000

    if-eq v6, v9, :cond_67

    const/16 v15, 0x9

    if-eq v6, v15, :cond_67

    if-eq v6, v8, :cond_4c

    goto/16 :goto_114

    :cond_4c
    iget v6, v2, Lm10;->I:I

    if-eq v6, v14, :cond_5e

    if-ne v6, v14, :cond_54

    goto/16 :goto_114

    :cond_54
    iput v14, v2, Lm10;->I:I

    invoke-static {v2, v14, v11, v12, v13}, Lm10;->z(Lm10;IILjava/lang/Integer;I)V

    invoke-static {v2, v6, v7, v12, v13}, Lm10;->z(Lm10;IILjava/lang/Integer;I)V

    goto/16 :goto_114

    :cond_5e
    invoke-virtual {v5}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui()Lc90;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    goto/16 :goto_114

    :cond_67
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getX()F

    move-result v6

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getY()F

    move-result v15

    invoke-virtual {v5, v10}, Landroidx/compose/ui/platform/AndroidComposeView;->u(Z)V

    new-instance v20, Lxy8;

    invoke-direct/range {v20 .. v20}, Lxy8;-><init>()V

    invoke-virtual {v5}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v16

    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v6

    move/from16 v17, v15

    int-to-long v14, v6

    invoke-static/range {v17 .. v17}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v6

    int-to-long v8, v6

    const/16 v6, 0x20

    shl-long/2addr v14, v6

    const-wide v17, 0xffffffffL

    and-long v8, v8, v17

    or-long/2addr v8, v14

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v6

    sget-object v14, Ldnc;->t0:Lqgf;

    invoke-virtual {v6, v8, v9, v10}, Ldnc;->e1(JZ)J

    move-result-wide v18

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/LayoutNode;->getOuterCoordinator$ui()Ldnc;

    move-result-object v16

    sget-object v17, Ldnc;->x0:Loo8;

    const/16 v21, 0x1

    const/16 v22, 0x1

    invoke-virtual/range {v16 .. v22}, Ldnc;->m1(Lzmc;JLxy8;IZ)V

    move-object/from16 v6, v20

    iget-object v6, v6, Lxy8;->E:Lddc;

    iget v8, v6, Lddc;->b:I

    sub-int/2addr v8, v10

    :goto_b0
    const/4 v9, -0x1

    if-ge v9, v8, :cond_d0

    invoke-virtual {v6, v8}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v9, Ls7c;

    invoke-static {v9}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v9

    invoke-virtual {v5}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui()Lc90;

    move-result-object v14

    invoke-virtual {v14}, Lc90;->getLayoutNodeToHolder()Ljava/util/HashMap;

    move-result-object v14

    invoke-virtual {v14, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lx80;

    if-eqz v14, :cond_d3

    :cond_d0
    const/high16 v14, -0x80000000

    goto :goto_100

    :cond_d3
    iget-object v14, v9, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    const/16 v15, 0x8

    invoke-virtual {v14, v15}, Lxmc;->i(I)Z

    move-result v14

    if-nez v14, :cond_de

    goto :goto_fd

    :cond_de
    iget v14, v9, Landroidx/compose/ui/node/LayoutNode;->F:I

    invoke-virtual {v2, v14}, Lm10;->v(I)I

    move-result v14

    invoke-static {v9, v4}, Llab;->i(Landroidx/compose/ui/node/LayoutNode;Z)Lnag;

    move-result-object v9

    invoke-static {v9}, Letf;->O(Lnag;)Z

    move-result v15

    if-nez v15, :cond_ef

    goto :goto_fd

    :cond_ef
    invoke-virtual {v9}, Lnag;->k()Lhag;

    move-result-object v9

    sget-object v15, Lrag;->B:Luag;

    iget-object v9, v9, Lhag;->E:Lrdc;

    invoke-virtual {v9, v15}, Lrdc;->c(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_100

    :goto_fd
    add-int/lit8 v8, v8, -0x1

    goto :goto_b0

    :cond_100
    :goto_100
    invoke-virtual {v5}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui()Lc90;

    move-result-object v5

    invoke-virtual {v5, v1}, Landroid/view/View;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    iget v5, v2, Lm10;->I:I

    if-ne v5, v14, :cond_10c

    goto :goto_114

    :cond_10c
    iput v14, v2, Lm10;->I:I

    invoke-static {v2, v14, v11, v12, v13}, Lm10;->z(Lm10;IILjava/lang/Integer;I)V

    invoke-static {v2, v5, v7, v12, v13}, Lm10;->z(Lm10;IILjava/lang/Integer;I)V

    :cond_114
    :goto_114
    invoke-virtual {v1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    const/4 v5, 0x7

    if-eq v2, v5, :cond_149

    const/16 v5, 0xa

    if-eq v2, v5, :cond_120

    goto :goto_150

    :cond_120
    invoke-virtual/range {p0 .. p1}, Landroidx/compose/ui/platform/AndroidComposeView;->q(Landroid/view/MotionEvent;)Z

    move-result v2

    if-eqz v2, :cond_150

    invoke-virtual {v1, v4}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v2

    const/4 v5, 0x3

    if-ne v2, v5, :cond_134

    invoke-virtual {v1}, Landroid/view/MotionEvent;->getButtonState()I

    move-result v2

    if-eqz v2, :cond_134

    goto :goto_158

    :cond_134
    iget-object v2, v0, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    if-eqz v2, :cond_13b

    invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V

    :cond_13b
    invoke-static {v1}, Landroid/view/MotionEvent;->obtainNoHistory(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v1

    iput-object v1, v0, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    iput-boolean v10, v0, Landroidx/compose/ui/platform/AndroidComposeView;->i1:Z

    const-wide/16 v1, 0x8

    invoke-virtual {v0, v3, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return v4

    :cond_149
    invoke-virtual/range {p0 .. p1}, Landroidx/compose/ui/platform/AndroidComposeView;->r(Landroid/view/MotionEvent;)Z

    move-result v2

    if-nez v2, :cond_150

    goto :goto_158

    :cond_150
    :goto_150
    invoke-virtual/range {p0 .. p1}, Landroidx/compose/ui/platform/AndroidComposeView;->l(Landroid/view/MotionEvent;)I

    move-result v0

    and-int/2addr v0, v10

    if-eqz v0, :cond_158

    return v10

    :cond_158
    :goto_158
    return v4
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .registers 6

    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3a

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v0

    iget-object v0, v0, Lvu4;->s:Ltea;

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getMetaState()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lz2k;->a:Ltad;

    invoke-static {}, Lqll;->f()Ltad;

    move-result-object v0

    new-instance v3, Llrd;

    invoke-direct {v3, v2}, Llrd;-><init>(I)V

    invoke-virtual {v0, v3}, Ltad;->setValue(Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    sget-object v2, Lht5;->L:Lht5;

    check-cast v0, Lu28;

    invoke-virtual {v0, p1, v2}, Lu28;->f(Landroid/view/KeyEvent;La98;)Z

    move-result v0

    if-nez v0, :cond_38

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p0

    if-eqz p0, :cond_37

    goto :goto_38

    :cond_37
    return v1

    :cond_38
    :goto_38
    const/4 p0, 0x1

    return p0

    :cond_3a
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    new-instance v2, Lz00;

    invoke-direct {v2, p0, v1, p1}, Lz00;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    check-cast v0, Lu28;

    invoke-virtual {v0, p1, v2}, Lu28;->f(Landroid/view/KeyEvent;La98;)Z

    move-result p0

    return p0
.end method

.method public final dispatchKeyEventPreIme(Landroid/view/KeyEvent;)Z
    .registers 16

    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_218

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    check-cast v0, Lu28;

    iget-object v3, v0, Lu28;->d:Lp28;

    iget-boolean v3, v3, Lp28;->e:Z

    if-eqz v3, :cond_1d

    const-string v0, "FocusRelatedWarning: Dispatching intercepted soft keyboard event while the focus system is invalidated."

    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v3, v0}, Ljava/io/PrintStream;->println(Ljava/lang/Object;)V

    goto/16 :goto_218

    :cond_1d
    iget-object v0, v0, Lu28;->c:Lm38;

    invoke-static {v0}, Lohl;->d(Lm38;)Lm38;

    move-result-object v0

    const-string v3, "visitAncestors called on an unattached node"

    const/high16 v4, 0x20000

    const/16 v5, 0x10

    const/4 v6, 0x0

    if-eqz v0, :cond_a9

    iget-object v7, v0, Ls7c;->E:Ls7c;

    iget-boolean v7, v7, Ls7c;->R:Z

    if-nez v7, :cond_35

    invoke-static {v3}, Ldf9;->c(Ljava/lang/String;)V

    :cond_35
    iget-object v7, v0, Ls7c;->E:Ls7c;

    invoke-static {v0}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    :goto_3b
    if-eqz v0, :cond_a5

    iget-object v8, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v8, v8, Lxmc;->K:Ljava/lang/Object;

    check-cast v8, Ls7c;

    iget v8, v8, Ls7c;->H:I

    and-int/2addr v8, v4

    if-eqz v8, :cond_94

    :goto_48
    if-eqz v7, :cond_94

    iget v8, v7, Ls7c;->G:I

    and-int/2addr v8, v4

    if-eqz v8, :cond_91

    move-object v9, v6

    move-object v8, v7

    :goto_51
    if-eqz v8, :cond_91

    instance-of v10, v8, Ltk9;

    if-eqz v10, :cond_58

    goto :goto_a6

    :cond_58
    iget v10, v8, Ls7c;->G:I

    and-int/2addr v10, v4

    if-eqz v10, :cond_8c

    instance-of v10, v8, Ls46;

    if-eqz v10, :cond_8c

    move-object v10, v8

    check-cast v10, Ls46;

    iget-object v10, v10, Ls46;->T:Ls7c;

    move v11, v2

    :goto_67
    if-eqz v10, :cond_89

    iget v12, v10, Ls7c;->G:I

    and-int/2addr v12, v4

    if-eqz v12, :cond_86

    add-int/lit8 v11, v11, 0x1

    if-ne v11, v1, :cond_74

    move-object v8, v10

    goto :goto_86

    :cond_74
    if-nez v9, :cond_7d

    new-instance v9, Ljec;

    new-array v12, v5, [Ls7c;

    invoke-direct {v9, v2, v12}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_7d
    if-eqz v8, :cond_83

    invoke-virtual {v9, v8}, Ljec;->b(Ljava/lang/Object;)V

    move-object v8, v6

    :cond_83
    invoke-virtual {v9, v10}, Ljec;->b(Ljava/lang/Object;)V

    :cond_86
    :goto_86
    iget-object v10, v10, Ls7c;->J:Ls7c;

    goto :goto_67

    :cond_89
    if-ne v11, v1, :cond_8c

    goto :goto_51

    :cond_8c
    invoke-static {v9}, La60;->l(Ljec;)Ls7c;

    move-result-object v8

    goto :goto_51

    :cond_91
    iget-object v7, v7, Ls7c;->I:Ls7c;

    goto :goto_48

    :cond_94
    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    if-eqz v0, :cond_a3

    iget-object v7, v0, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v7, :cond_a3

    iget-object v7, v7, Lxmc;->J:Ljava/lang/Object;

    check-cast v7, Lhzh;

    goto :goto_3b

    :cond_a3
    move-object v7, v6

    goto :goto_3b

    :cond_a5
    move-object v8, v6

    :goto_a6
    check-cast v8, Ltk9;

    goto :goto_aa

    :cond_a9
    move-object v8, v6

    :goto_aa
    if-eqz v8, :cond_218

    iget-object v0, v8, Ls7c;->E:Ls7c;

    iget-boolean v0, v0, Ls7c;->R:Z

    if-nez v0, :cond_b5

    invoke-static {v3}, Ldf9;->c(Ljava/lang/String;)V

    :cond_b5
    iget-object v0, v8, Ls7c;->E:Ls7c;

    iget-object v0, v0, Ls7c;->I:Ls7c;

    invoke-static {v8}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v3

    move-object v7, v6

    :goto_be
    if-eqz v3, :cond_136

    iget-object v9, v3, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    iget-object v9, v9, Lxmc;->K:Ljava/lang/Object;

    check-cast v9, Ls7c;

    iget v9, v9, Ls7c;->H:I

    and-int/2addr v9, v4

    if-eqz v9, :cond_125

    :goto_cb
    if-eqz v0, :cond_125

    iget v9, v0, Ls7c;->G:I

    and-int/2addr v9, v4

    if-eqz v9, :cond_122

    move-object v9, v0

    move-object v10, v6

    :goto_d4
    if-eqz v9, :cond_122

    instance-of v11, v9, Ltk9;

    if-eqz v11, :cond_e6

    if-nez v7, :cond_e1

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    :cond_e1
    invoke-interface {v7, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v11, v2

    goto :goto_e7

    :cond_e6
    move v11, v1

    :goto_e7
    if-eqz v11, :cond_11d

    iget v11, v9, Ls7c;->G:I

    and-int/2addr v11, v4

    if-eqz v11, :cond_11d

    instance-of v11, v9, Ls46;

    if-eqz v11, :cond_11d

    move-object v11, v9

    check-cast v11, Ls46;

    iget-object v11, v11, Ls46;->T:Ls7c;

    move v12, v2

    :goto_f8
    if-eqz v11, :cond_11a

    iget v13, v11, Ls7c;->G:I

    and-int/2addr v13, v4

    if-eqz v13, :cond_117

    add-int/lit8 v12, v12, 0x1

    if-ne v12, v1, :cond_105

    move-object v9, v11

    goto :goto_117

    :cond_105
    if-nez v10, :cond_10e

    new-instance v10, Ljec;

    new-array v13, v5, [Ls7c;

    invoke-direct {v10, v2, v13}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_10e
    if-eqz v9, :cond_114

    invoke-virtual {v10, v9}, Ljec;->b(Ljava/lang/Object;)V

    move-object v9, v6

    :cond_114
    invoke-virtual {v10, v11}, Ljec;->b(Ljava/lang/Object;)V

    :cond_117
    :goto_117
    iget-object v11, v11, Ls7c;->J:Ls7c;

    goto :goto_f8

    :cond_11a
    if-ne v12, v1, :cond_11d

    goto :goto_d4

    :cond_11d
    invoke-static {v10}, La60;->l(Ljec;)Ls7c;

    move-result-object v9

    goto :goto_d4

    :cond_122
    iget-object v0, v0, Ls7c;->I:Ls7c;

    goto :goto_cb

    :cond_125
    invoke-virtual {v3}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v3

    if-eqz v3, :cond_134

    iget-object v0, v3, Landroidx/compose/ui/node/LayoutNode;->k0:Lxmc;

    if-eqz v0, :cond_134

    iget-object v0, v0, Lxmc;->J:Ljava/lang/Object;

    check-cast v0, Lhzh;

    goto :goto_be

    :cond_134
    move-object v0, v6

    goto :goto_be

    :cond_136
    if-eqz v7, :cond_150

    invoke-interface {v7}, Ljava/util/Collection;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    if-ltz v0, :cond_150

    :goto_140
    add-int/lit8 v3, v0, -0x1

    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltk9;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-gez v3, :cond_14e

    goto :goto_150

    :cond_14e
    move v0, v3

    goto :goto_140

    :cond_150
    :goto_150
    iget-object v0, v8, Ls7c;->E:Ls7c;

    move-object v3, v6

    :goto_153
    if-eqz v0, :cond_193

    instance-of v9, v0, Ltk9;

    if-eqz v9, :cond_15a

    goto :goto_18e

    :cond_15a
    iget v9, v0, Ls7c;->G:I

    and-int/2addr v9, v4

    if-eqz v9, :cond_18e

    instance-of v9, v0, Ls46;

    if-eqz v9, :cond_18e

    move-object v9, v0

    check-cast v9, Ls46;

    iget-object v9, v9, Ls46;->T:Ls7c;

    move v10, v2

    :goto_169
    if-eqz v9, :cond_18b

    iget v11, v9, Ls7c;->G:I

    and-int/2addr v11, v4

    if-eqz v11, :cond_188

    add-int/lit8 v10, v10, 0x1

    if-ne v10, v1, :cond_176

    move-object v0, v9

    goto :goto_188

    :cond_176
    if-nez v3, :cond_17f

    new-instance v3, Ljec;

    new-array v11, v5, [Ls7c;

    invoke-direct {v3, v2, v11}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_17f
    if-eqz v0, :cond_185

    invoke-virtual {v3, v0}, Ljec;->b(Ljava/lang/Object;)V

    move-object v0, v6

    :cond_185
    invoke-virtual {v3, v9}, Ljec;->b(Ljava/lang/Object;)V

    :cond_188
    :goto_188
    iget-object v9, v9, Ls7c;->J:Ls7c;

    goto :goto_169

    :cond_18b
    if-ne v10, v1, :cond_18e

    goto :goto_153

    :cond_18e
    :goto_18e
    invoke-static {v3}, La60;->l(Ljec;)Ls7c;

    move-result-object v0

    goto :goto_153

    :cond_193
    iget-object v0, v8, Ls7c;->E:Ls7c;

    move-object v3, v6

    :goto_196
    if-eqz v0, :cond_1ef

    instance-of v8, v0, Ltk9;

    if-eqz v8, :cond_1b6

    check-cast v0, Ltk9;

    iget-object v0, v0, Ltk9;->S:Lc98;

    if-eqz v0, :cond_1b1

    invoke-static {p1}, Lo1a;->a(Landroid/view/KeyEvent;)Lo1a;

    move-result-object v8

    invoke-interface {v0, v8}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    goto :goto_1b2

    :cond_1b1
    move v0, v2

    :goto_1b2
    if-eqz v0, :cond_1ea

    goto/16 :goto_21e

    :cond_1b6
    iget v8, v0, Ls7c;->G:I

    and-int/2addr v8, v4

    if-eqz v8, :cond_1ea

    instance-of v8, v0, Ls46;

    if-eqz v8, :cond_1ea

    move-object v8, v0

    check-cast v8, Ls46;

    iget-object v8, v8, Ls46;->T:Ls7c;

    move v9, v2

    :goto_1c5
    if-eqz v8, :cond_1e7

    iget v10, v8, Ls7c;->G:I

    and-int/2addr v10, v4

    if-eqz v10, :cond_1e4

    add-int/lit8 v9, v9, 0x1

    if-ne v9, v1, :cond_1d2

    move-object v0, v8

    goto :goto_1e4

    :cond_1d2
    if-nez v3, :cond_1db

    new-instance v3, Ljec;

    new-array v10, v5, [Ls7c;

    invoke-direct {v3, v2, v10}, Ljec;-><init>(I[Ljava/lang/Object;)V

    :cond_1db
    if-eqz v0, :cond_1e1

    invoke-virtual {v3, v0}, Ljec;->b(Ljava/lang/Object;)V

    move-object v0, v6

    :cond_1e1
    invoke-virtual {v3, v8}, Ljec;->b(Ljava/lang/Object;)V

    :cond_1e4
    :goto_1e4
    iget-object v8, v8, Ls7c;->J:Ls7c;

    goto :goto_1c5

    :cond_1e7
    if-ne v9, v1, :cond_1ea

    goto :goto_196

    :cond_1ea
    invoke-static {v3}, La60;->l(Ljec;)Ls7c;

    move-result-object v0

    goto :goto_196

    :cond_1ef
    if-eqz v7, :cond_218

    invoke-interface {v7}, Ljava/util/Collection;->size()I

    move-result v0

    move v3, v2

    :goto_1f6
    if-ge v3, v0, :cond_218

    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltk9;

    iget-object v4, v4, Ltk9;->S:Lc98;

    if-eqz v4, :cond_211

    invoke-static {p1}, Lo1a;->a(Landroid/view/KeyEvent;)Lo1a;

    move-result-object v5

    invoke-interface {v4, v5}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    goto :goto_212

    :cond_211
    move v4, v2

    :goto_212
    if-eqz v4, :cond_215

    goto :goto_21e

    :cond_215
    add-int/lit8 v3, v3, 0x1

    goto :goto_1f6

    :cond_218
    :goto_218
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEventPreIme(Landroid/view/KeyEvent;)Z

    move-result p0

    if-eqz p0, :cond_21f

    :goto_21e
    return v1

    :cond_21f
    return v2
.end method

.method public final dispatchProvideStructure(Landroid/view/ViewStructure;)V
    .registers 4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-ge v0, v1, :cond_10

    sget-object v0, Ln10;->a:Ln10;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getView()Landroid/view/View;

    move-result-object p0

    invoke-virtual {v0, p1, p0}, Ln10;->a(Landroid/view/ViewStructure;Landroid/view/View;)V

    return-void

    :cond_10
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchProvideStructure(Landroid/view/ViewStructure;)V

    return-void
.end method

.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 12

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->i1:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_30

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h1:Lq00;

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    if-nez v3, :cond_2d

    invoke-virtual {v2}, Landroid/view/MotionEvent;->getSource()I

    move-result v3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v4

    if-ne v3, v4, :cond_2d

    invoke-virtual {v2, v1}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v2

    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v3

    if-eq v2, v3, :cond_2a

    goto :goto_2d

    :cond_2a
    iput-boolean v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->i1:Z

    goto :goto_30

    :cond_2d
    :goto_2d
    invoke-virtual {v0}, Lq00;->run()V

    :cond_30
    :goto_30
    invoke-static {p1}, Landroidx/compose/ui/platform/AndroidComposeView;->p(Landroid/view/MotionEvent;)Z

    move-result v0

    if-nez v0, :cond_f4

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-nez v0, :cond_3e

    goto/16 :goto_f4

    :cond_3e
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v2, 0x2

    if-ne v0, v2, :cond_4d

    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->r(Landroid/view/MotionEvent;)Z

    move-result v0

    if-nez v0, :cond_4d

    goto/16 :goto_f4

    :cond_4d
    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->l(Landroid/view/MotionEvent;)I

    move-result v0

    and-int/lit8 v2, v0, 0x2

    const/4 v3, 0x1

    if-eqz v2, :cond_5d

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    invoke-interface {v2, v3}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_5d
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    if-eqz v2, :cond_6d

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    const/4 v4, 0x5

    if-ne v2, v4, :cond_6b

    goto :goto_6d

    :cond_6b
    move v2, v1

    goto :goto_6e

    :cond_6d
    :goto_6d
    move v2, v3

    :goto_6e
    const/16 v4, 0x2002

    invoke-virtual {p1, v4}, Landroid/view/InputEvent;->isFromSource(I)Z

    move-result v4

    if-nez v4, :cond_82

    const v4, 0x100008

    invoke-virtual {p1, v4}, Landroid/view/InputEvent;->isFromSource(I)Z

    move-result v4

    if-eqz v4, :cond_80

    goto :goto_82

    :cond_80
    move v4, v1

    goto :goto_83

    :cond_82
    :goto_82
    move v4, v3

    :goto_83
    if-eqz v2, :cond_ef

    if-eqz v4, :cond_ef

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v4, v2, Landroid/view/View;

    if-eqz v4, :cond_92

    check-cast v2, Landroid/view/View;

    goto :goto_93

    :cond_92
    const/4 v2, 0x0

    :goto_93
    if-eqz v2, :cond_9e

    const v4, 0x7f0a005a

    invoke-virtual {v2, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_a2

    :cond_9e
    invoke-static {v3}, Lna1;->a(I)Lna1;

    move-result-object v2

    :cond_a2
    invoke-static {v3}, Lna1;->a(I)Lna1;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_ef

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v2

    check-cast v2, Lu28;

    invoke-virtual {v2}, Lu28;->h()Lm38;

    move-result-object v2

    if-eqz v2, :cond_ef

    invoke-static {v2}, La60;->P(Lp46;)Ldnc;

    move-result-object v2

    invoke-static {v2}, Lnfl;->m(Lc7a;)Lc7a;

    move-result-object v4

    invoke-interface {v4, v2, v3}, Lc7a;->J(Lc7a;Z)Lqwe;

    move-result-object v2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v4

    int-to-long v4, v4

    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    int-to-long v6, p1

    const/16 p1, 0x20

    shl-long/2addr v4, p1

    const-wide v8, 0xffffffffL

    and-long/2addr v6, v8

    or-long/2addr v4, v6

    invoke-virtual {v2, v4, v5}, Lqwe;->a(J)Z

    move-result p1

    if-nez p1, :cond_ef

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object p0

    check-cast p0, Lu28;

    invoke-virtual {p0, v1}, Lu28;->b(Z)V

    :cond_ef
    and-int/lit8 p0, v0, 0x1

    if-eqz p0, :cond_f4

    return v3

    :cond_f4
    :goto_f4
    return v1
.end method

.method public final findViewByAccessibilityIdTraversal(I)Landroid/view/View;
    .registers 8

    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-lt v0, v1, :cond_2c

    const-class v0, Landroid/view/View;

    const-string v1, "findViewByAccessibilityIdTraversal"

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    new-array v1, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v1, v5

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Landroid/view/View;

    if-eqz p1, :cond_31

    check-cast p0, Landroid/view/View;

    return-object p0

    :cond_2c
    invoke-static {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->j(Landroid/view/View;I)Landroid/view/View;

    move-result-object p0
    :try_end_30
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_30} :catch_31

    return-object p0

    :catch_31
    :cond_31
    const/4 p0, 0x0

    return-object p0
.end method

.method public final focusSearch(Landroid/view/View;I)Landroid/view/View;
    .registers 10

    if-eqz p1, :cond_90

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    iget-boolean v0, v0, Lilb;->c:Z

    if-eqz v0, :cond_a

    goto/16 :goto_90

    :cond_a
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Landroid/view/ViewGroup;

    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    move-result-object v1

    invoke-virtual {v1, v0, p1, p2}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_25

    invoke-static {p0, v0}, Lw10;->o(Landroid/view/View;Landroid/view/View;)Z

    move-result v2

    if-eqz v2, :cond_25

    goto :goto_26

    :cond_25
    move-object v0, v1

    :goto_26
    if-ne p1, p0, :cond_41

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v2

    check-cast v2, Lu28;

    iget-object v2, v2, Lu28;->c:Lm38;

    invoke-static {v2}, Lohl;->d(Lm38;)Lm38;

    move-result-object v2

    if-eqz v2, :cond_3a

    invoke-static {v2}, Lohl;->f(Lm38;)Lqwe;

    move-result-object v1

    :cond_3a
    if-nez v1, :cond_45

    invoke-static {p1, p0}, Lo28;->a(Landroid/view/View;Landroid/view/View;)Lqwe;

    move-result-object v1

    goto :goto_45

    :cond_41
    invoke-static {p1, p0}, Lo28;->a(Landroid/view/View;Landroid/view/View;)Lqwe;

    move-result-object v1

    :cond_45
    :goto_45
    invoke-static {p2}, Lo28;->d(I)Ly18;

    move-result-object v2

    if-eqz v2, :cond_4e

    iget v2, v2, Ly18;->a:I

    goto :goto_4f

    :cond_4e
    const/4 v2, 0x6

    :goto_4f
    new-instance v3, Lixe;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v4

    new-instance v5, Lb10;

    const/4 v6, 0x0

    invoke-direct {v5, v6, v3}, Lb10;-><init>(ILixe;)V

    check-cast v4, Lu28;

    invoke-virtual {v4, v2, v1, v5}, Lu28;->g(ILqwe;Lc98;)Ljava/lang/Boolean;

    move-result-object v4

    if-nez v4, :cond_67

    return-object p1

    :cond_67
    iget-object v4, v3, Lixe;->E:Ljava/lang/Object;

    if-nez v4, :cond_72

    if-nez v0, :cond_8f

    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->focusSearch(Landroid/view/View;I)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_72
    if-nez v0, :cond_75

    goto :goto_8e

    :cond_75
    invoke-static {v2}, Ljhl;->f(I)Z

    move-result p1

    if-eqz p1, :cond_7c

    goto :goto_8e

    :cond_7c
    iget-object p1, v3, Lixe;->E:Ljava/lang/Object;

    check-cast p1, Lm38;

    invoke-static {p1}, Lohl;->f(Lm38;)Lqwe;

    move-result-object p1

    invoke-static {v0, p0}, Lo28;->a(Landroid/view/View;Landroid/view/View;)Lqwe;

    move-result-object p2

    invoke-static {p1, p2, v1, v2}, Lbo9;->a0(Lqwe;Lqwe;Lqwe;I)Z

    move-result p1

    if-eqz p1, :cond_8f

    :goto_8e
    return-object p0

    :cond_8f
    return-object v0

    :cond_90
    :goto_90
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->focusSearch(Landroid/view/View;I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public getAccessibilityManager()Ld00;
    .registers 1

    .line 5
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->i0:Ld00;

    return-object p0
.end method

.method public bridge synthetic getAccessibilityManager()Lt5;
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getAccessibilityManager()Ld00;

    move-result-object p0

    return-object p0
.end method

.method public final getAndroidViewsHandler$ui()Lc90;
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->A0:Lc90;

    if-nez v0, :cond_16

    new-instance v0, Lc90;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lc90;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->A0:Lc90;

    const/4 v1, -0x1

    invoke-virtual {p0, v0, v1}, Landroidx/compose/ui/platform/AndroidComposeView;->addView(Landroid/view/View;I)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_16
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->A0:Lc90;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0
.end method

.method public getAutofill()Llc1;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->t0:Ltfg;

    return-object p0
.end method

.method public getAutofillManager()Lqc1;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    return-object p0
.end method

.method public getAutofillTree()Lrc1;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->k0:Lrc1;

    return-object p0
.end method

.method public getClipboard()Lo00;
    .registers 1

    .line 5
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->x0:Lo00;

    return-object p0
.end method

.method public bridge synthetic getClipboard()Lq04;
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getClipboard()Lo00;

    move-result-object p0

    return-object p0
.end method

.method public getClipboardManager()Lp00;
    .registers 1

    .line 5
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->w0:Lp00;

    return-object p0
.end method

.method public bridge synthetic getClipboardManager()Ls04;
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getClipboardManager()Lp00;

    move-result-object p0

    return-object p0
.end method

.method public final getComposeViewContext()Lvu4;
    .registers 1

    invoke-direct {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->get_composeViewContext()Lvu4;

    move-result-object p0

    return-object p0
.end method

.method public final getComposeViewContextIncrementedDuringInit$ui()Z
    .registers 1

    iget-boolean p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->n1:Z

    return p0
.end method

.method public final getConfiguration()Landroid/content/res/Configuration;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->r0:Ltad;

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/res/Configuration;

    return-object p0
.end method

.method public final getContentCaptureManager$ui()Lc20;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    return-object p0
.end method

.method public getCoroutineContext()Lla5;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->R:Lla5;

    return-object p0
.end method

.method public getDensity()Ld76;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->O:Ltad;

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ld76;

    return-object p0
.end method

.method public bridge synthetic getDragAndDropManager()Lvk6;
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getDragAndDropManager()Ly20;

    move-result-object p0

    return-object p0
.end method

.method public getDragAndDropManager()Ly20;
    .registers 1

    .line 5
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->S:Ly20;

    return-object p0
.end method

.method public getEmbeddedViewFocusRect()Lqwe;
    .registers 3

    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1b

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object p0

    check-cast p0, Lu28;

    iget-object p0, p0, Lu28;->c:Lm38;

    invoke-static {p0}, Lohl;->d(Lm38;)Lm38;

    move-result-object p0

    if-eqz p0, :cond_1a

    invoke-static {p0}, Lohl;->f(Lm38;)Lqwe;

    move-result-object p0

    return-object p0

    :cond_1a
    return-object v1

    :cond_1b
    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_26

    invoke-static {v0, p0}, Lo28;->a(Landroid/view/View;Landroid/view/View;)Lqwe;

    move-result-object p0

    return-object p0

    :cond_26
    return-object v1
.end method

.method public getFocusOwner()Ls28;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Q:Lu28;

    return-object p0
.end method

.method public final getFocusedRect(Landroid/graphics/Rect;)V
    .registers 6

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getEmbeddedViewFocusRect()Lqwe;

    move-result-object v0

    if-eqz v0, :cond_27

    iget p0, v0, Lqwe;->a:F

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    iput p0, p1, Landroid/graphics/Rect;->left:I

    iget p0, v0, Lqwe;->b:F

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    iput p0, p1, Landroid/graphics/Rect;->top:I

    iget p0, v0, Lqwe;->c:F

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    iput p0, p1, Landroid/graphics/Rect;->right:I

    iget p0, v0, Lqwe;->d:F

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    iput p0, p1, Landroid/graphics/Rect;->bottom:I

    return-void

    :cond_27
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    sget-object v1, Ley;->H:Ley;

    check-cast v0, Lu28;

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3, v1}, Lu28;->g(ILqwe;Lc98;)Ljava/lang/Boolean;

    move-result-object v0

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43

    const/high16 p0, -0x80000000

    invoke-virtual {p1, p0, p0, p0, p0}, Landroid/graphics/Rect;->set(IIII)V

    return-void

    :cond_43
    invoke-super {p0, p1}, Landroid/view/View;->getFocusedRect(Landroid/graphics/Rect;)V

    return-void
.end method

.method public getFontFamilyResolver()Ly38;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->U0:Laec;

    invoke-interface {p0}, Lghh;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ly38;

    return-object p0
.end method

.method public getFontLoader()Lt38;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->T0:Lt38;

    return-object p0
.end method

.method public final getFrameEndScheduler$ui()Lnha;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J:Lnha;

    return-object p0
.end method

.method public getGraphicsContext()Lnl8;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->j0:Lr30;

    return-object p0
.end method

.method public getHapticFeedBack()Lzq8;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->W0:Lzq8;

    return-object p0
.end method

.method public getHasPendingMeasureOrLayout()Z
    .registers 2

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    iget-object v0, v0, Lilb;->b:Lhk0;

    invoke-virtual {v0}, Lhk0;->A()Z

    move-result v0

    if-nez v0, :cond_15

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->M:Lqq0;

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_13

    goto :goto_15

    :cond_13
    const/4 p0, 0x0

    return p0

    :cond_15
    :goto_15
    const/4 p0, 0x1

    return p0
.end method

.method public getImportantForAutofill()I
    .registers 1

    const/4 p0, 0x1

    return p0
.end method

.method public getInputModeManager()Lyg9;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->X0:Lzg9;

    return-object p0
.end method

.method public final getInsetsListener()Luh9;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->b0:Luh9;

    return-object p0
.end method

.method public final getLastMatrixRecalculationAnimationTime$ui()J
    .registers 3

    iget-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    return-wide v0
.end method

.method public getLayoutDirection()Lf7a;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->V0:Ltad;

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lf7a;

    return-object p0
.end method

.method public getLayoutNodes()Llcc;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Llcc;"
        }
    .end annotation

    .line 5
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d0:Llcc;

    return-object p0
.end method

.method public bridge synthetic getLayoutNodes()Loj9;
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getLayoutNodes()Llcc;

    move-result-object p0

    return-object p0
.end method

.method public getLocaleList()Lrra;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->s0:Ly76;

    invoke-virtual {p0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lrra;

    return-object p0
.end method

.method public getMeasureIteration()J
    .registers 3

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    iget-boolean v0, p0, Lilb;->c:Z

    if-nez v0, :cond_b

    const-string v0, "measureIteration should be only used during the measure/layout pass"

    invoke-static {v0}, Ldf9;->a(Ljava/lang/String;)V

    :cond_b
    iget-wide v0, p0, Lilb;->g:J

    return-wide v0
.end method

.method public getModifierLocalManager()Lw7c;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Y0:Lw7c;

    return-object p0
.end method

.method public getOutOfFrameExecutor()Landroidx/compose/ui/platform/AndroidComposeView;
    .registers 2

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_7

    return-object p0

    :cond_7
    const/4 p0, 0x0

    return-object p0
.end method

.method public bridge synthetic getOutOfFrameExecutor()Li3d;
    .registers 1

    .line 9
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getOutOfFrameExecutor()Landroidx/compose/ui/platform/AndroidComposeView;

    move-result-object p0

    return-object p0
.end method

.method public getPlacementScope()Ldmd;
    .registers 3

    sget v0, Lfmd;->b:I

    new-instance v0, Lnza;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0}, Lnza;-><init>(ILjava/lang/Object;)V

    return-object v0
.end method

.method public getPointerIconService()Lbrd;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->q1:Ld10;

    return-object p0
.end method

.method public final getPrimaryDirectionalMotionAxisOverride-dqNNBbU$ui()Lod9;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->H:Lod9;

    return-object p0
.end method

.method public getRectManager()Lswe;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->e0:Lswe;

    return-object p0
.end method

.method public getRetainedValuesStore()Lhgf;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L:Lhgf;

    return-object p0
.end method

.method public getRoot()Landroidx/compose/ui/node/LayoutNode;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->c0:Landroidx/compose/ui/node/LayoutNode;

    return-object p0
.end method

.method public getRootForTest()Lekf;
    .registers 1

    return-object p0
.end method

.method public final getScrollCaptureInProgress$ui()Z
    .registers 3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_19

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->o1:Ld3f;

    if-eqz p0, :cond_19

    iget-object p0, p0, Ld3f;->E:Ljava/lang/Object;

    check-cast p0, Ltad;

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    :cond_19
    const/4 p0, 0x0

    return p0
.end method

.method public getSemanticsOwner()Lqag;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->f0:Lqag;

    return-object p0
.end method

.method public getSharedDrawScope()Lb8a;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->I:Lb8a;

    return-object p0
.end method

.method public getShowLayoutBounds()Z
    .registers 3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_d

    sget-object v0, Lpf0;->a:Lpf0;

    invoke-virtual {v0, p0}, Lpf0;->a(Landroid/view/View;)Z

    move-result p0

    return p0

    :cond_d
    iget-boolean p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->z0:Z

    return p0
.end method

.method public getSnapshotObserver()Lb5d;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->y0:Lb5d;

    return-object p0
.end method

.method public getSoftwareKeyboardController()Li8h;
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->S0:Lf56;

    if-nez v0, :cond_f

    new-instance v0, Lf56;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getTextInputService()Lz8i;

    move-result-object v1

    invoke-direct {v0, v1}, Lf56;-><init>(Lz8i;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->S0:Lf56;

    :cond_f
    return-object v0
.end method

.method public getTextInputService()Lz8i;
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Q0:Lz8i;

    if-nez v0, :cond_f

    new-instance v0, Lz8i;

    invoke-direct {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getLegacyTextInputServiceAndroid()Lb9i;

    move-result-object v1

    invoke-direct {v0, v1}, Lz8i;-><init>(Lzod;)V

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Q0:Lz8i;

    :cond_f
    return-object v0
.end method

.method public getTextToolbar()Llai;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->Z0:Ld80;

    return-object p0
.end method

.method public final getUncaughtExceptionHandler$ui()Ldkf;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method

.method public getView()Landroid/view/View;
    .registers 1

    return-object p0
.end method

.method public getViewConfiguration()Likj;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->a0:Lo80;

    return-object p0
.end method

.method public final getViewTreeOwners()Lw00;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->N0:Ly76;

    invoke-virtual {p0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lb40;->x(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public getWindowInfo()Ly2k;
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object p0

    iget-object p0, p0, Lvu4;->s:Ltea;

    return-object p0
.end method

.method public final get_autofillManager$ui()Li00;
    .registers 1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    return-object p0
.end method

.method public final i(Lq98;Lanc;Lql8;)Lz4d;
    .registers 11

    if-eqz p3, :cond_d

    new-instance v0, Ltl8;

    const/4 v2, 0x0

    move-object v3, p0

    move-object v4, p1

    move-object v5, p2

    move-object v1, p3

    invoke-direct/range {v0 .. v5}, Ltl8;-><init>(Lql8;Lnl8;Landroidx/compose/ui/platform/AndroidComposeView;Lq98;La98;)V

    return-object v0

    :cond_d
    move-object v3, p0

    move-object v4, p1

    move-object v5, p2

    :cond_10
    iget-object p0, v3, Landroidx/compose/ui/platform/AndroidComposeView;->c1:Lrpf;

    iget-object p1, p0, Lrpf;->G:Ljava/lang/Object;

    check-cast p1, Ljava/lang/ref/ReferenceQueue;

    iget-object p0, p0, Lrpf;->F:Ljava/lang/Object;

    check-cast p0, Ljec;

    invoke-virtual {p1}, Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;

    move-result-object p1

    if-eqz p1, :cond_23

    invoke-virtual {p0, p1}, Ljec;->k(Ljava/lang/Object;)Z

    :cond_23
    if-nez p1, :cond_10

    :cond_25
    iget p1, p0, Ljec;->G:I

    const/4 p2, 0x0

    if-eqz p1, :cond_39

    add-int/lit8 p1, p1, -0x1

    invoke-virtual {p0, p1}, Ljec;->m(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/ref/Reference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_25

    goto :goto_3a

    :cond_39
    move-object p1, p2

    :goto_3a
    check-cast p1, Lz4d;

    if-eqz p1, :cond_89

    move-object p0, p1

    check-cast p0, Ltl8;

    iget-object p3, p0, Ltl8;->F:Lnl8;

    if-eqz p3, :cond_82

    iget-object v0, p0, Ltl8;->E:Lql8;

    iget-boolean v0, v0, Lql8;->s:Z

    if-nez v0, :cond_50

    const-string v0, "layer should have been released before reuse"

    invoke-static {v0}, Ldf9;->a(Ljava/lang/String;)V

    :cond_50
    invoke-interface {p3}, Lnl8;->c()Lql8;

    move-result-object p3

    iput-object p3, p0, Ltl8;->E:Lql8;

    const/4 p3, 0x0

    iput-boolean p3, p0, Ltl8;->K:Z

    iput-object v4, p0, Ltl8;->H:Lq98;

    iput-object v5, p0, Ltl8;->I:La98;

    iput-boolean p3, p0, Ltl8;->U:Z

    iput-boolean p3, p0, Ltl8;->V:Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Ltl8;->W:Z

    iget-object v0, p0, Ltl8;->L:[F

    invoke-static {v0}, Lmab;->d([F)V

    iget-object v0, p0, Ltl8;->M:[F

    if-eqz v0, :cond_70

    invoke-static {v0}, Lmab;->d([F)V

    :cond_70
    sget-wide v0, Lvsi;->b:J

    iput-wide v0, p0, Ltl8;->S:J

    iput-boolean p3, p0, Ltl8;->X:Z

    const-wide v0, 0x7fffffff7fffffffL

    iput-wide v0, p0, Ltl8;->J:J

    iput-object p2, p0, Ltl8;->T:Letf;

    iput p3, p0, Ltl8;->R:I

    return-object p1

    :cond_82
    const-string p0, "currently reuse is only supported when we manage the layer lifecycle"

    invoke-static {p0}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object p0

    throw p0

    :cond_89
    new-instance v1, Ltl8;

    invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getGraphicsContext()Lnl8;

    move-result-object p0

    invoke-interface {p0}, Lnl8;->c()Lql8;

    move-result-object v2

    move-object v6, v5

    move-object v5, v4

    move-object v4, v3

    invoke-virtual {v4}, Landroidx/compose/ui/platform/AndroidComposeView;->getGraphicsContext()Lnl8;

    move-result-object v3

    invoke-direct/range {v1 .. v6}, Ltl8;-><init>(Lql8;Lnl8;Landroidx/compose/ui/platform/AndroidComposeView;Lq98;La98;)V

    return-object v1
.end method

.method public final k(Landroidx/compose/ui/node/LayoutNode;Z)V
    .registers 3

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    invoke-virtual {p0, p1, p2}, Lilb;->h(Landroidx/compose/ui/node/LayoutNode;Z)V

    return-void
.end method

.method public final l(Landroid/view/MotionEvent;)I
    .registers 18

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    iget-object v2, v1, Landroidx/compose/ui/platform/AndroidComposeView;->g1:Lm;

    invoke-virtual {v1, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v7, 0x0

    :try_start_a
    invoke-virtual/range {p0 .. p1}, Landroidx/compose/ui/platform/AndroidComposeView;->D(Landroid/view/MotionEvent;)V

    const/4 v8, 0x1

    iput-boolean v8, v1, Landroidx/compose/ui/platform/AndroidComposeView;->K0:Z

    invoke-virtual {v1, v7}, Landroidx/compose/ui/platform/AndroidComposeView;->u(Z)V

    const-string v2, "AndroidOwner:onTouch"

    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_18
    .catchall {:try_start_a .. :try_end_18} :catchall_16c

    :try_start_18
    invoke-virtual {v0}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v9

    iget-object v2, v1, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    const/4 v10, 0x3

    if-eqz v2, :cond_29

    invoke-virtual {v2, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v3
    :try_end_25
    .catchall {:try_start_18 .. :try_end_25} :catchall_2b

    if-ne v3, v10, :cond_29

    move v11, v8

    goto :goto_2e

    :cond_29
    move v11, v7

    goto :goto_2e

    :catchall_2b
    move-exception v0

    goto/16 :goto_16e

    :goto_2e
    const/16 v12, 0xa

    iget-object v13, v1, Landroidx/compose/ui/platform/AndroidComposeView;->q0:Li70;

    if-eqz v2, :cond_7b

    :try_start_34
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getSource()I

    move-result v3

    invoke-virtual {v0}, Landroid/view/MotionEvent;->getSource()I

    move-result v4

    if-ne v3, v4, :cond_4b

    invoke-virtual {v2, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v3

    invoke-virtual {v0, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v4

    if-eq v3, v4, :cond_49

    goto :goto_4b

    :cond_49
    move v3, v7

    goto :goto_4c

    :cond_4b
    :goto_4b
    move v3, v8

    :goto_4c
    if-eqz v3, :cond_7b

    invoke-virtual {v2}, Landroid/view/MotionEvent;->getButtonState()I

    move-result v3

    if-eqz v3, :cond_56

    :cond_54
    move-object v14, v2

    goto :goto_7d

    :cond_56
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    if-eqz v3, :cond_54

    const/4 v4, 0x2

    if-eq v3, v4, :cond_54

    const/4 v4, 0x6

    if-eq v3, v4, :cond_54

    invoke-virtual {v2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    if-eq v3, v12, :cond_7b

    if-eqz v11, :cond_7b

    invoke-virtual {v2}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v4

    const/4 v6, 0x1

    const/16 v3, 0xa

    invoke-virtual/range {v1 .. v6}, Landroidx/compose/ui/platform/AndroidComposeView;->I(Landroid/view/MotionEvent;IJZ)V

    move-object v14, v2

    goto :goto_93

    :catchall_76
    move-exception v0

    move-object/from16 v1, p0

    goto/16 :goto_16e

    :cond_7b
    move-object v14, v2

    goto :goto_93

    :goto_7d
    iget-boolean v1, v13, Li70;->a:Z

    if-nez v1, :cond_93

    iget-object v1, v13, Li70;->d:Ljava/lang/Object;

    check-cast v1, Lxs5;

    iget-object v1, v1, Lxs5;->F:Ljava/lang/Object;

    check-cast v1, Lgya;

    invoke-virtual {v1}, Lgya;->a()V

    iget-object v1, v13, Li70;->c:Ljava/lang/Object;

    check-cast v1, Luy8;

    invoke-virtual {v1}, Luy8;->c()V

    :cond_93
    :goto_93
    invoke-virtual {v0, v7}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v1

    if-ne v1, v10, :cond_9b

    move v1, v8

    goto :goto_9c

    :cond_9b
    move v1, v7

    :goto_9c
    const/16 v15, 0x9

    if-nez v11, :cond_ba

    if-eqz v1, :cond_ba

    if-eq v9, v10, :cond_ba

    if-eq v9, v15, :cond_ba

    invoke-virtual/range {p0 .. p1}, Landroidx/compose/ui/platform/AndroidComposeView;->q(Landroid/view/MotionEvent;)Z

    move-result v1

    if-eqz v1, :cond_ba

    invoke-virtual {v0}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v4
    :try_end_b0
    .catchall {:try_start_34 .. :try_end_b0} :catchall_76

    const/4 v6, 0x1

    const/16 v3, 0x9

    move-object/from16 v1, p0

    move-object v2, v0

    :try_start_b6
    invoke-virtual/range {v1 .. v6}, Landroidx/compose/ui/platform/AndroidComposeView;->I(Landroid/view/MotionEvent;IJZ)V

    goto :goto_bc

    :cond_ba
    move-object/from16 v1, p0

    :goto_bc
    if-eqz v14, :cond_c1

    invoke-virtual {v14}, Landroid/view/MotionEvent;->recycle()V

    :cond_c1
    iget-object v0, v1, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    if-eqz v0, :cond_15c

    invoke-virtual {v0}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-ne v0, v12, :cond_15c

    iget-object v0, v1, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    if-eqz v0, :cond_d4

    invoke-virtual {v0, v7}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    goto :goto_d5

    :cond_d4
    const/4 v0, -0x1

    :goto_d5
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2
    :try_end_d9
    .catchall {:try_start_b6 .. :try_end_d9} :catchall_2b

    iget-object v3, v1, Landroidx/compose/ui/platform/AndroidComposeView;->p0:Lf9c;

    if-ne v2, v15, :cond_f1

    :try_start_dd
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getHistorySize()I

    move-result v2

    if-nez v2, :cond_f1

    if-ltz v0, :cond_15c

    iget-object v2, v3, Lf9c;->c:Landroid/util/SparseBooleanArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseBooleanArray;->delete(I)V

    iget-object v2, v3, Lf9c;->b:Landroid/util/SparseLongArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseLongArray;->delete(I)V

    goto/16 :goto_15c

    :cond_f1
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    if-nez v2, :cond_15c

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getHistorySize()I

    move-result v2

    if-nez v2, :cond_15c

    iget-object v2, v1, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    const/high16 v4, 0x7fc00000  # Float.NaN

    if-eqz v2, :cond_108

    invoke-virtual {v2}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    goto :goto_109

    :cond_108
    move v2, v4

    :goto_109
    iget-object v5, v1, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    if-eqz v5, :cond_111

    invoke-virtual {v5}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    :cond_111
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    cmpg-float v2, v2, v5

    if-nez v2, :cond_123

    cmpg-float v2, v4, v6

    if-nez v2, :cond_123

    move v2, v7

    goto :goto_124

    :cond_123
    move v2, v8

    :goto_124
    iget-object v4, v1, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    if-eqz v4, :cond_12d

    invoke-virtual {v4}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v4

    goto :goto_12f

    :cond_12d
    const-wide/16 v4, -0x1

    :goto_12f
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v9

    cmp-long v4, v4, v9

    if-eqz v4, :cond_139

    move v4, v8

    goto :goto_13a

    :cond_139
    move v4, v7

    :goto_13a
    if-nez v2, :cond_13e

    if-eqz v4, :cond_15c

    :cond_13e
    if-ltz v0, :cond_14a

    iget-object v2, v3, Lf9c;->c:Landroid/util/SparseBooleanArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseBooleanArray;->delete(I)V

    iget-object v2, v3, Lf9c;->b:Landroid/util/SparseLongArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseLongArray;->delete(I)V

    :cond_14a
    iget-object v0, v13, Li70;->c:Ljava/lang/Object;

    check-cast v0, Luy8;

    iget-boolean v2, v0, Luy8;->d:Z

    if-eqz v2, :cond_155

    iput-boolean v8, v0, Luy8;->d:Z

    goto :goto_15c

    :cond_155
    iget-object v0, v0, Luy8;->g:Linc;

    iget-object v0, v0, Linc;->a:Ljec;

    invoke-virtual {v0}, Ljec;->h()V

    :cond_15c
    :goto_15c
    invoke-static/range {p1 .. p1}, Landroid/view/MotionEvent;->obtainNoHistory(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v0

    iput-object v0, v1, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    invoke-virtual/range {p0 .. p1}, Landroidx/compose/ui/platform/AndroidComposeView;->H(Landroid/view/MotionEvent;)I

    move-result v0
    :try_end_166
    .catchall {:try_start_dd .. :try_end_166} :catchall_2b

    :try_start_166
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_169
    .catchall {:try_start_166 .. :try_end_169} :catchall_16c

    iput-boolean v7, v1, Landroidx/compose/ui/platform/AndroidComposeView;->K0:Z

    return v0

    :catchall_16c
    move-exception v0

    goto :goto_172

    :goto_16e
    :try_start_16e
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0
    :try_end_172
    .catchall {:try_start_16e .. :try_end_172} :catchall_16c

    :goto_172
    iput-boolean v7, v1, Landroidx/compose/ui/platform/AndroidComposeView;->K0:Z

    throw v0
.end method

.method public final n(Landroidx/compose/ui/node/LayoutNode;)V
    .registers 5

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Lilb;->s(Landroidx/compose/ui/node/LayoutNode;Z)Z

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->L()Ljec;

    move-result-object p1

    iget-object v0, p1, Ljec;->E:[Ljava/lang/Object;

    iget p1, p1, Ljec;->G:I

    :goto_e
    if-ge v1, p1, :cond_1a

    aget-object v2, v0, v1

    check-cast v2, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {p0, v2}, Landroidx/compose/ui/platform/AndroidComposeView;->n(Landroidx/compose/ui/node/LayoutNode;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_e

    :cond_1a
    return-void
.end method

.method public final onAttachedToWindow()V
    .registers 10

    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->setAttached(Z)V

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-ge v1, v2, :cond_14

    invoke-static {}, Lezg;->e0()Z

    move-result v2

    invoke-virtual {p0, v2}, Landroidx/compose/ui/platform/AndroidComposeView;->setShowLayoutBounds(Z)V

    :cond_14
    iget-object v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->b0:Luh9;

    invoke-virtual {v2, p0}, Luh9;->onViewAttachedToWindow(Landroid/view/View;)V

    const/16 v2, 0x1c

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-le v1, v2, :cond_70

    sget-object v1, Landroidx/compose/ui/platform/AndroidComposeView;->v1:Ls00;

    if-nez v1, :cond_65

    new-instance v1, Ls00;

    invoke-direct {v1, v3}, Ls00;-><init>(I)V

    sput-object v1, Landroidx/compose/ui/platform/AndroidComposeView;->v1:Ls00;

    invoke-static {}, Landroid/os/StrictMode;->getVmPolicy()Landroid/os/StrictMode$VmPolicy;

    move-result-object v2

    :try_start_2e
    sget-object v5, Landroidx/compose/ui/platform/AndroidComposeView;->r1:Ljava/lang/Class;

    if-nez v5, :cond_3a

    const-string v5, "android.os.SystemProperties"

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    sput-object v5, Landroidx/compose/ui/platform/AndroidComposeView;->r1:Ljava/lang/Class;

    :cond_3a
    sget-object v5, Landroidx/compose/ui/platform/AndroidComposeView;->t1:Ljava/lang/reflect/Method;

    if-nez v5, :cond_57

    sget-object v5, Landroid/os/StrictMode$VmPolicy;->LAX:Landroid/os/StrictMode$VmPolicy;

    invoke-static {v5}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    sget-object v5, Landroidx/compose/ui/platform/AndroidComposeView;->r1:Ljava/lang/Class;

    if-eqz v5, :cond_54

    const-string v6, "addChangeCallback"

    new-array v7, v0, [Ljava/lang/Class;

    const-class v8, Ljava/lang/Runnable;

    aput-object v8, v7, v3

    invoke-virtual {v5, v6, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    goto :goto_55

    :cond_54
    move-object v5, v4

    :goto_55
    sput-object v5, Landroidx/compose/ui/platform/AndroidComposeView;->t1:Ljava/lang/reflect/Method;

    :cond_57
    sget-object v5, Landroidx/compose/ui/platform/AndroidComposeView;->t1:Ljava/lang/reflect/Method;

    if-eqz v5, :cond_62

    new-array v6, v0, [Ljava/lang/Object;

    aput-object v1, v6, v3

    invoke-virtual {v5, v4, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_62
    .catchall {:try_start_2e .. :try_end_62} :catchall_62

    :catchall_62
    :cond_62
    invoke-static {v2}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    :cond_65
    sget-object v1, Landroidx/compose/ui/platform/AndroidComposeView;->u1:Lddc;

    monitor-enter v1

    :try_start_68
    invoke-virtual {v1, p0}, Lddc;->a(Ljava/lang/Object;)V
    :try_end_6b
    .catchall {:try_start_68 .. :try_end_6b} :catchall_6d

    monitor-exit v1

    goto :goto_70

    :catchall_6d
    move-exception p0

    monitor-exit v1

    throw p0

    :cond_70
    :goto_70
    iget-boolean v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->n1:Z

    if-nez v1, :cond_7b

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v1

    invoke-virtual {v1}, Lvu4;->c()V

    :cond_7b
    iput-boolean v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->n1:Z

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroidx/compose/ui/platform/AndroidComposeView;->n(Landroidx/compose/ui/node/LayoutNode;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    invoke-static {v1}, Landroidx/compose/ui/platform/AndroidComposeView;->m(Landroidx/compose/ui/node/LayoutNode;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getSnapshotObserver()Lb5d;

    move-result-object v1

    iget-object v1, v1, Lb5d;->a:Lv7h;

    invoke-virtual {v1}, Lv7h;->e()V

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->t0:Ltfg;

    if-eqz v1, :cond_a4

    sget-object v2, Lnc1;->a:Lnc1;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v1, Ltfg;->H:Ljava/lang/Object;

    check-cast v1, Landroid/view/autofill/AutofillManager;

    invoke-virtual {v1, v2}, Landroid/view/autofill/AutofillManager;->registerCallback(Landroid/view/autofill/AutofillManager$AutofillCallback;)V

    :cond_a4
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v1

    iget-object v1, v1, Lvu4;->c:Lhha;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v2

    iget-object v2, v2, Lvu4;->e:Lwmj;

    iget-object v5, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J:Lnha;

    if-eqz v1, :cond_136

    if-eqz v2, :cond_136

    if-nez v5, :cond_ba

    goto/16 :goto_136

    :cond_ba
    invoke-interface {v2}, Lwmj;->f()Lvmj;

    move-result-object v1

    new-instance v2, Ltmj;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    sget-object v5, Lsg5;->b:Lsg5;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v6, Ltfg;

    invoke-direct {v6, v1, v2, v5}, Ltfg;-><init>(Lvmj;Lsmj;Ltg5;)V

    const-class v1, Lpha;

    sget-object v2, Loze;->a:Lpze;

    invoke-virtual {v2, v1}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v1

    invoke-interface {v1}, Lky9;->d()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_130

    const-string v5, "androidx.lifecycle.ViewModelProvider.DefaultKey:"

    invoke-virtual {v5, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v1, v2}, Ltfg;->L(Lky9;Ljava/lang/String;)Lpmj;

    move-result-object v1

    check-cast v1, Lpha;

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    move-result v2

    iget-object v1, v1, Lpha;->b:Llcc;

    invoke-virtual {v1, v2}, Loj9;->b(I)Ljava/lang/Object;

    move-result-object v5

    if-nez v5, :cond_107

    new-instance v5, Lddc;

    invoke-direct {v5, v0}, Lddc;-><init>(I)V

    invoke-virtual {v1, v2, v5}, Llcc;->i(ILjava/lang/Object;)V

    :cond_107
    check-cast v5, Lddc;

    iget-object v1, v5, Lddc;->a:[Ljava/lang/Object;

    iget v2, v5, Lddc;->b:I

    :goto_10d
    if-ge v3, v2, :cond_11c

    aget-object v6, v1, v3

    move-object v7, v6

    check-cast v7, Loha;

    iget-boolean v7, v7, Loha;->c:Z

    if-nez v7, :cond_119

    goto :goto_11d

    :cond_119
    add-int/lit8 v3, v3, 0x1

    goto :goto_10d

    :cond_11c
    move-object v6, v4

    :goto_11d
    check-cast v6, Loha;

    if-nez v6, :cond_129

    new-instance v6, Loha;

    invoke-direct {v6}, Loha;-><init>()V

    invoke-virtual {v5, v6}, Lddc;->a(Ljava/lang/Object;)V

    :cond_129
    iput-boolean v0, v6, Loha;->c:Z

    iput-object v6, p0, Landroidx/compose/ui/platform/AndroidComposeView;->K:Loha;

    iget-object v1, v6, Loha;->b:Lfi8;

    goto :goto_137

    :cond_130
    const-string p0, "Local and anonymous classes can not be ViewModels"

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    return-void

    :cond_136
    :goto_136
    move-object v1, v4

    :goto_137
    if-nez v1, :cond_13b

    sget-object v1, Lmx8;->I:Lmx8;

    :cond_13b
    iput-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L:Lhgf;

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->O0:Lc98;

    if-eqz v1, :cond_14a

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v2

    invoke-interface {v1, v2}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v4, p0, Landroidx/compose/ui/platform/AndroidComposeView;->O0:Lc98;

    :cond_14a
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v1

    iget-object v1, v1, Lvu4;->c:Lhha;

    invoke-interface {v1}, Lhha;->a()Lwga;

    move-result-object v1

    invoke-virtual {v1, p0}, Lwga;->a(Lgha;)V

    iget-object v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    invoke-virtual {v1, v2}, Lwga;->a(Lgha;)V

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->X0:Lzg9;

    invoke-virtual {p0}, Landroid/view/View;->isInTouchMode()Z

    move-result v2

    if-eqz v2, :cond_165

    goto :goto_166

    :cond_165
    const/4 v0, 0x2

    :goto_166
    iget-object v1, v1, Lzg9;->a:Ltad;

    new-instance v2, Lxg9;

    invoke-direct {v2, v0}, Lxg9;-><init>(I)V

    invoke-virtual {v1, v2}, Ltad;->setValue(Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnScrollChangedListener(Landroid/view/ViewTreeObserver$OnScrollChangedListener;)V

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnTouchModeChangeListener(Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_190

    sget-object v0, Lt10;->a:Lt10;

    invoke-virtual {v0, p0}, Lt10;->b(Landroid/view/View;)V

    :cond_190
    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz v0, :cond_1a8

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v1

    check-cast v1, Lu28;

    iget-object v1, v1, Lu28;->g:Lddc;

    invoke-virtual {v1, v0}, Lddc;->a(Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getSemanticsOwner()Lqag;

    move-result-object v1

    iget-object v1, v1, Lqag;->d:Lddc;

    invoke-virtual {v1, v0}, Lddc;->a(Ljava/lang/Object;)V

    :cond_1a8
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    check-cast v0, Lu28;

    iget-object v0, v0, Lu28;->g:Lddc;

    invoke-virtual {v0, p0}, Lddc;->a(Ljava/lang/Object;)V

    return-void
.end method

.method public final onCheckIsTextEditor()Z
    .registers 3

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->R0:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lclg;

    const/4 v1, 0x0

    if-eqz v0, :cond_e

    iget-object v0, v0, Lclg;->b:Ljava/lang/Object;

    goto :goto_f

    :cond_e
    move-object v0, v1

    :goto_f
    check-cast v0, Lp50;

    if-nez v0, :cond_1a

    invoke-direct {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getLegacyTextInputServiceAndroid()Lb9i;

    move-result-object p0

    iget-boolean p0, p0, Lb9i;->d:Z

    return p0

    :cond_1a
    iget-object p0, v0, Lp50;->H:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lclg;

    if-eqz p0, :cond_26

    iget-object v1, p0, Lclg;->b:Ljava/lang/Object;

    :cond_26
    check-cast v1, Lvg9;

    if-eqz v1, :cond_31

    iget-boolean p0, v1, Lvg9;->e:Z

    const/4 v0, 0x1

    xor-int/2addr p0, v0

    if-ne p0, v0, :cond_31

    return v0

    :cond_31
    const/4 p0, 0x0

    return p0
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 2

    invoke-super {p0, p1}, Landroid/view/View;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->K(Landroid/content/res/Configuration;)V

    return-void
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .registers 16

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->R0:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lclg;

    const/4 v1, 0x0

    if-eqz v0, :cond_e

    iget-object v0, v0, Lclg;->b:Ljava/lang/Object;

    goto :goto_f

    :cond_e
    move-object v0, v1

    :goto_f
    check-cast v0, Lp50;

    if-nez v0, :cond_129

    invoke-direct {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getLegacyTextInputServiceAndroid()Lb9i;

    move-result-object p0

    iget-boolean v0, p0, Lb9i;->d:Z

    if-nez v0, :cond_1d

    goto/16 :goto_171

    :cond_1d
    iget-object v0, p0, Lb9i;->h:Lva9;

    iget-object v2, p0, Lb9i;->g:Ls8i;

    iget v3, v0, Lva9;->e:I

    iget-boolean v4, v0, Lva9;->a:Z

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-ne v3, v5, :cond_34

    if-eqz v4, :cond_32

    :goto_30
    move v12, v9

    goto :goto_4f

    :cond_32
    const/4 v12, 0x0

    goto :goto_4f

    :cond_34
    if-nez v3, :cond_38

    move v12, v5

    goto :goto_4f

    :cond_38
    if-ne v3, v11, :cond_3c

    move v12, v11

    goto :goto_4f

    :cond_3c
    if-ne v3, v9, :cond_40

    move v12, v8

    goto :goto_4f

    :cond_40
    if-ne v3, v8, :cond_44

    move v12, v7

    goto :goto_4f

    :cond_44
    if-ne v3, v10, :cond_48

    move v12, v10

    goto :goto_4f

    :cond_48
    if-ne v3, v6, :cond_4c

    move v12, v6

    goto :goto_4f

    :cond_4c
    if-ne v3, v7, :cond_123

    goto :goto_30

    :goto_4f
    iput v12, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    iget v13, v0, Lva9;->d:I

    if-ne v13, v5, :cond_58

    iput v5, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_92

    :cond_58
    if-ne v13, v11, :cond_62

    iput v5, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    const/high16 v1, -0x80000000

    or-int/2addr v1, v12

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    goto :goto_92

    :cond_62
    if-ne v13, v10, :cond_67

    iput v11, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_92

    :cond_67
    if-ne v13, v6, :cond_6c

    iput v10, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_92

    :cond_6c
    if-ne v13, v8, :cond_73

    const/16 v1, 0x11

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_92

    :cond_73
    if-ne v13, v9, :cond_7a

    const/16 v1, 0x21

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_92

    :cond_7a
    if-ne v13, v7, :cond_81

    const/16 v1, 0x81

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_92

    :cond_81
    const/16 v6, 0x8

    if-ne v13, v6, :cond_8a

    const/16 v1, 0x12

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_92

    :cond_8a
    const/16 v6, 0x9

    if-ne v13, v6, :cond_11d

    const/16 v1, 0x2002

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    :goto_92
    if-nez v4, :cond_a8

    iget v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    and-int/lit8 v4, v1, 0x1

    if-ne v4, v5, :cond_a8

    const/high16 v4, 0x20000

    or-int/2addr v1, v4

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    if-ne v3, v5, :cond_a8

    iget v1, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    const/high16 v3, 0x40000000  # 2.0f

    or-int/2addr v1, v3

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    :cond_a8
    iget v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    and-int/lit8 v3, v1, 0x1

    if-ne v3, v5, :cond_d0

    iget v3, v0, Lva9;->b:I

    if-ne v3, v5, :cond_b7

    or-int/lit16 v1, v1, 0x1000

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_c4

    :cond_b7
    if-ne v3, v11, :cond_be

    or-int/lit16 v1, v1, 0x2000

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    goto :goto_c4

    :cond_be
    if-ne v3, v10, :cond_c4

    or-int/lit16 v1, v1, 0x4000

    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    :cond_c4
    :goto_c4
    iget-boolean v0, v0, Lva9;->c:Z

    if-eqz v0, :cond_d0

    iget v0, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    const v1, 0x8000

    or-int/2addr v0, v1

    iput v0, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    :cond_d0
    iget-wide v0, v2, Ls8i;->b:J

    sget v3, Lz9i;->c:I

    const/16 v3, 0x20

    shr-long v3, v0, v3

    long-to-int v3, v3

    iput v3, p1, Landroid/view/inputmethod/EditorInfo;->initialSelStart:I

    const-wide v3, 0xffffffffL

    and-long/2addr v0, v3

    long-to-int v0, v0

    iput v0, p1, Landroid/view/inputmethod/EditorInfo;->initialSelEnd:I

    iget-object v0, v2, Ls8i;->a:Lkd0;

    iget-object v0, v0, Lkd0;->F:Ljava/lang/String;

    invoke-static {p1, v0}, Lzxh;->g0(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;)V

    iget v0, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    const/high16 v1, 0x2000000

    or-int/2addr v0, v1

    iput v0, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    invoke-static {}, Lsu6;->d()Z

    move-result v0

    if-nez v0, :cond_f9

    goto :goto_100

    :cond_f9
    invoke-static {}, Lsu6;->a()Lsu6;

    move-result-object v0

    invoke-virtual {v0, p1}, Lsu6;->i(Landroid/view/inputmethod/EditorInfo;)V

    :goto_100
    iget-object p1, p0, Lb9i;->g:Ls8i;

    iget-object v0, p0, Lb9i;->h:Lva9;

    iget-boolean v0, v0, Lva9;->c:Z

    new-instance v1, Lc1f;

    const/16 v2, 0xa

    invoke-direct {v1, v2, p0}, Lc1f;-><init>(ILjava/lang/Object;)V

    new-instance v2, Llwe;

    invoke-direct {v2, p1, v1, v0}, Llwe;-><init>(Ls8i;Lc1f;Z)V

    iget-object p0, p0, Lb9i;->i:Ljava/util/ArrayList;

    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v2

    :cond_11d
    const-string p0, "Invalid Keyboard Type"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-object v1

    :cond_123
    const-string p0, "invalid ImeAction"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-object v1

    :cond_129
    iget-object p0, v0, Lp50;->H:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lclg;

    if-eqz p0, :cond_136

    iget-object p0, p0, Lclg;->b:Ljava/lang/Object;

    goto :goto_137

    :cond_136
    move-object p0, v1

    :goto_137
    check-cast p0, Lvg9;

    if-eqz p0, :cond_171

    iget-object v0, p0, Lvg9;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_13e
    iget-boolean v2, p0, Lvg9;->e:Z
    :try_end_140
    .catchall {:try_start_13e .. :try_end_140} :catchall_16e

    if-eqz v2, :cond_144

    monitor-exit v0

    return-object v1

    :cond_144
    :try_start_144
    iget-object v1, p0, Lvg9;->a:Luod;

    invoke-interface {v1, p1}, Luod;->i(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    move-result-object p1

    new-instance v1, Le0;

    const/16 v2, 0x14

    invoke-direct {v1, v2, p0}, Le0;-><init>(ILjava/lang/Object;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x22

    if-lt v2, v3, :cond_15d

    new-instance v2, Lcrc;

    invoke-direct {v2, p1, v1}, Lbrc;-><init>(Landroid/view/inputmethod/InputConnection;Le0;)V

    goto :goto_162

    :cond_15d
    new-instance v2, Lbrc;

    invoke-direct {v2, p1, v1}, Lbrc;-><init>(Landroid/view/inputmethod/InputConnection;Le0;)V

    :goto_162
    iget-object p0, p0, Lvg9;->d:Ljec;

    new-instance p1, Lwxj;

    invoke-direct {p1, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p0, p1}, Ljec;->b(Ljava/lang/Object;)V
    :try_end_16c
    .catchall {:try_start_144 .. :try_end_16c} :catchall_16e

    monitor-exit v0

    return-object v2

    :catchall_16e
    move-exception p0

    monitor-exit v0

    throw p0

    :cond_171
    :goto_171
    return-object v1
.end method

.method public final onCreateVirtualViewTranslationRequests([J[ILjava/util/function/Consumer;)V
    .registers 4

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, p1, p3}, Ligl;->g(Lc20;[JLjava/util/function/Consumer;)V

    return-void
.end method

.method public final onDetachedFromWindow()V
    .registers 11

    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->setAttached(Z)V

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->b0:Luh9;

    invoke-virtual {v1, p0}, Luh9;->onViewDetachedFromWindow(Landroid/view/View;)V

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->P:Landroid/view/View;

    invoke-static {}, Landroidx/compose/ui/platform/AndroidComposeView;->o()Z

    move-result v2

    if-eqz v2, :cond_19

    if-eqz v1, :cond_19

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_19
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1c

    if-le v1, v2, :cond_2b

    sget-object v2, Landroidx/compose/ui/platform/AndroidComposeView;->u1:Lddc;

    monitor-enter v2

    :try_start_22
    invoke-virtual {v2, p0}, Lddc;->j(Ljava/lang/Object;)Z
    :try_end_25
    .catchall {:try_start_22 .. :try_end_25} :catchall_27

    monitor-exit v2

    goto :goto_2b

    :catchall_27
    move-exception v0

    move-object p0, v0

    monitor-exit v2

    throw p0

    :cond_2b
    :goto_2b
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v2

    invoke-virtual {v2}, Lvu4;->b()V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getSnapshotObserver()Lb5d;

    move-result-object v2

    iget-object v2, v2, Lb5d;->a:Lv7h;

    iget-object v3, v2, Lv7h;->i:Ljava/lang/Object;

    check-cast v3, Lgd;

    if-eqz v3, :cond_41

    invoke-virtual {v3}, Lgd;->f()V

    :cond_41
    invoke-virtual {v2}, Lv7h;->a()V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object v2

    iget-object v2, v2, Lvu4;->c:Lhha;

    invoke-interface {v2}, Lhha;->a()Lwga;

    move-result-object v2

    iget-object v3, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    invoke-virtual {v2, v3}, Lwga;->c(Lgha;)V

    invoke-virtual {v2, p0}, Lwga;->c(Lgha;)V

    iget-object v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->t0:Ltfg;

    if-eqz v2, :cond_66

    sget-object v3, Lnc1;->a:Lnc1;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v2, Ltfg;->H:Ljava/lang/Object;

    check-cast v2, Landroid/view/autofill/AutofillManager;

    invoke-virtual {v2, v3}, Landroid/view/autofill/AutofillManager;->unregisterCallback(Landroid/view/autofill/AutofillManager$AutofillCallback;)V

    :cond_66
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/ViewTreeObserver;->removeOnScrollChangedListener(Landroid/view/ViewTreeObserver$OnScrollChangedListener;)V

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/ViewTreeObserver;->removeOnTouchModeChangeListener(Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;)V

    iget-object v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->K:Loha;

    if-eqz v2, :cond_81

    iput-boolean v0, v2, Loha;->c:Z

    :cond_81
    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->K:Loha;

    const/16 v2, 0x1f

    if-lt v1, v2, :cond_8d

    sget-object v1, Lt10;->a:Lt10;

    invoke-virtual {v1, p0}, Lt10;->a(Landroid/view/View;)V

    :cond_8d
    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz v1, :cond_a5

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getSemanticsOwner()Lqag;

    move-result-object v2

    iget-object v2, v2, Lqag;->d:Lddc;

    invoke-virtual {v2, v1}, Lddc;->j(Ljava/lang/Object;)Z

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v2

    check-cast v2, Lu28;

    iget-object v2, v2, Lu28;->g:Lddc;

    invoke-virtual {v2, v1}, Lddc;->j(Ljava/lang/Object;)Z

    :cond_a5
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object v1

    iget-object v2, v1, Lswe;->c:Lmei;

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    invoke-virtual/range {v2 .. v9}, Lmei;->b(JJ[FII)Z

    move-result v2

    iput-boolean v2, v1, Lswe;->f:Z

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object v1

    invoke-virtual {v1}, Lswe;->a()V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object v1

    iget-object v2, v1, Lswe;->h:Lr00;

    if-eqz v2, :cond_ce

    iget-object v3, v1, Lswe;->a:Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v3, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-object v0, v1, Lswe;->h:Lr00;

    :cond_ce
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    check-cast v0, Lu28;

    iget-object v0, v0, Lu28;->g:Lddc;

    invoke-virtual {v0, p0}, Lddc;->j(Ljava/lang/Object;)Z

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .registers 2

    return-void
.end method

.method public final onFocusChanged(ZILandroid/graphics/Rect;)V
    .registers 4

    invoke-super {p0, p1, p2, p3}, Landroid/view/View;->onFocusChanged(ZILandroid/graphics/Rect;)V

    if-nez p1, :cond_2e

    invoke-virtual {p0}, Landroid/view/View;->hasFocus()Z

    move-result p1

    if-nez p1, :cond_2e

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object p0

    check-cast p0, Lu28;

    iget-object p1, p0, Lu28;->c:Lm38;

    const/4 p2, 0x1

    invoke-static {p1, p2}, Letf;->r(Lm38;Z)Z

    invoke-virtual {p0}, Lu28;->h()Lm38;

    move-result-object p1

    if-eqz p1, :cond_2e

    invoke-virtual {p0}, Lu28;->h()Lm38;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p0, p2}, Lu28;->k(Lm38;)V

    if-eqz p1, :cond_2e

    sget-object p0, Lg38;->E:Lg38;

    sget-object p2, Lg38;->G:Lg38;

    invoke-virtual {p1, p0, p2}, Lm38;->q1(Lg38;Lg38;)V

    :cond_2e
    return-void
.end method

.method public final onGlobalLayout()V
    .registers 3

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->L()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x20

    if-gt v1, v0, :cond_1c

    const/16 v1, 0x22

    if-ge v0, v1, :cond_1c

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->K(Landroid/content/res/Configuration;)V

    :cond_1c
    return-void
.end method

.method public final onLayout(ZIIII)V
    .registers 8

    const-string p1, "AndroidOwner:onLayout"

    invoke-static {p1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    const-wide/16 v0, 0x0

    :try_start_7
    iput-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    iget-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->k1:Ly00;

    invoke-virtual {p1, v0}, Lilb;->m(Ly00;)Z

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->B0:Lj35;

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->L()V

    iget-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->A0:Lc90;

    if-eqz p1, :cond_32

    const-string p1, "AndroidOwner:viewLayout"

    invoke-static {p1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_1f
    .catchall {:try_start_7 .. :try_end_1f} :catchall_36

    :try_start_1f
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui()Lc90;

    move-result-object p0

    sub-int/2addr p4, p2

    sub-int/2addr p5, p3

    const/4 p1, 0x0

    invoke-virtual {p0, p1, p1, p4, p5}, Landroid/view/View;->layout(IIII)V
    :try_end_29
    .catchall {:try_start_1f .. :try_end_29} :catchall_2d

    :try_start_29
    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto :goto_32

    :catchall_2d
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
    :try_end_32
    .catchall {:try_start_29 .. :try_end_32} :catchall_36

    :cond_32
    :goto_32
    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void

    :catchall_36
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
.end method

.method public final onMeasure(II)V
    .registers 11

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    const-string v1, "AndroidOwner:onMeasure"

    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_7
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-nez v1, :cond_14

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroidx/compose/ui/platform/AndroidComposeView;->n(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_14
    invoke-static {p1}, Landroidx/compose/ui/platform/AndroidComposeView;->h(I)J

    move-result-wide v1

    const/16 p1, 0x20

    ushr-long v3, v1, p1

    long-to-int v3, v3

    const-wide v4, 0xffffffffL

    and-long/2addr v1, v4

    long-to-int v1, v1

    invoke-static {p2}, Landroidx/compose/ui/platform/AndroidComposeView;->h(I)J

    move-result-wide v6

    ushr-long p1, v6, p1

    long-to-int p1, p1

    and-long/2addr v4, v6

    long-to-int p2, v4

    invoke-static {v3, v1, p1, p2}, Lnfl;->n(IIII)J

    move-result-wide p1

    iget-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->B0:Lj35;

    if-nez v1, :cond_40

    new-instance v1, Lj35;

    invoke-direct {v1, p1, p2}, Lj35;-><init>(J)V

    iput-object v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->B0:Lj35;

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->C0:Z

    goto :goto_4b

    :cond_40
    iget-wide v1, v1, Lj35;->a:J

    invoke-static {v1, v2, p1, p2}, Lj35;->b(JJ)Z

    move-result v1

    if-nez v1, :cond_4b

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->C0:Z

    :cond_4b
    :goto_4b
    invoke-virtual {v0, p1, p2}, Lilb;->t(J)V

    invoke-virtual {v0}, Lilb;->o()V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->I()I

    move-result p1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p2

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->r()I

    move-result p2

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    iget-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->A0:Lc90;

    if-eqz p1, :cond_97

    const-string p1, "AndroidOwner:androidViewMeasure"

    invoke-static {p1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_6d
    .catchall {:try_start_7 .. :try_end_6d} :catchall_9b

    :try_start_6d
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getAndroidViewsHandler$ui()Lc90;

    move-result-object p1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p2

    invoke-virtual {p2}, Landroidx/compose/ui/node/LayoutNode;->I()I

    move-result p2

    const/high16 v0, 0x40000000  # 2.0f

    invoke-static {p2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p0

    invoke-virtual {p0}, Landroidx/compose/ui/node/LayoutNode;->r()I

    move-result p0

    invoke-static {p0, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p0

    invoke-virtual {p1, p2, p0}, Landroid/view/View;->measure(II)V
    :try_end_8e
    .catchall {:try_start_6d .. :try_end_8e} :catchall_92

    :try_start_8e
    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto :goto_97

    :catchall_92
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
    :try_end_97
    .catchall {:try_start_8e .. :try_end_97} :catchall_9b

    :cond_97
    :goto_97
    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void

    :catchall_9b
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
.end method

.method public final onProvideAutofillVirtualStructure(Landroid/view/ViewStructure;I)V
    .registers 13

    if-eqz p1, :cond_b0

    iget-object p2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz p2, :cond_a9

    iget-object v0, p2, Li00;->F:Lqag;

    iget-object v0, v0, Lqag;->a:Landroidx/compose/ui/node/LayoutNode;

    iget-object v1, p2, Li00;->K:Landroid/view/autofill/AutofillId;

    iget-object v2, p2, Li00;->I:Ljava/lang/String;

    iget-object p2, p2, Li00;->H:Lswe;

    invoke-static {p1, v0, v1, v2, p2}, Lrbl;->i(Landroid/view/ViewStructure;Landroidx/compose/ui/node/LayoutNode;Landroid/view/autofill/AutofillId;Ljava/lang/String;Lswe;)V

    sget-object v3, Lesc;->a:[Ljava/lang/Object;

    new-instance v3, Lddc;

    const/4 v4, 0x2

    invoke-direct {v3, v4}, Lddc;-><init>(I)V

    invoke-virtual {v3, v0}, Lddc;->a(Ljava/lang/Object;)V

    invoke-virtual {v3, p1}, Lddc;->a(Ljava/lang/Object;)V

    :cond_21
    invoke-virtual {v3}, Lddc;->i()Z

    move-result v0

    if-eqz v0, :cond_a9

    iget v0, v3, Lddc;->b:I

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v3, v0}, Lddc;->k(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Landroid/view/ViewStructure;

    iget v4, v3, Lddc;->b:I

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v3, v4}, Lddc;->k(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroidx/compose/ui/node/LayoutNode;

    invoke-virtual {v4}, Landroidx/compose/ui/node/LayoutNode;->getChildrenInfo()Ljava/util/List;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v5

    const/4 v6, 0x0

    :goto_4d
    if-ge v6, v5, :cond_21

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/compose/ui/node/LayoutNode;

    iget-boolean v8, v7, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-nez v8, :cond_a6

    invoke-virtual {v7}, Landroidx/compose/ui/node/LayoutNode;->W()Z

    move-result v8

    if-eqz v8, :cond_a6

    invoke-virtual {v7}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result v8

    if-nez v8, :cond_66

    goto :goto_a6

    :cond_66
    invoke-virtual {v7}, Landroidx/compose/ui/node/LayoutNode;->H()Lhag;

    move-result-object v8

    if-eqz v8, :cond_a0

    iget-object v8, v8, Lhag;->E:Lrdc;

    sget-object v9, Lfag;->g:Luag;

    invoke-virtual {v8, v9}, Lrdc;->b(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_8e

    sget-object v9, Lfag;->h:Luag;

    invoke-virtual {v8, v9}, Lrdc;->b(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_8e

    sget-object v9, Lrag;->r:Luag;

    invoke-virtual {v8, v9}, Lrdc;->b(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_8e

    sget-object v9, Lrag;->s:Luag;

    invoke-virtual {v8, v9}, Lrdc;->b(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_a0

    :cond_8e
    invoke-static {v0}, Lss6;->K0(Landroid/view/ViewStructure;)I

    move-result v8

    invoke-static {v0, v8}, Lss6;->g1(Landroid/view/ViewStructure;I)Landroid/view/ViewStructure;

    move-result-object v8

    invoke-static {v8, v7, v1, v2, p2}, Lrbl;->i(Landroid/view/ViewStructure;Landroidx/compose/ui/node/LayoutNode;Landroid/view/autofill/AutofillId;Ljava/lang/String;Lswe;)V

    invoke-virtual {v3, v7}, Lddc;->a(Ljava/lang/Object;)V

    invoke-virtual {v3, v8}, Lddc;->a(Ljava/lang/Object;)V

    goto :goto_a6

    :cond_a0
    invoke-virtual {v3, v7}, Lddc;->a(Ljava/lang/Object;)V

    invoke-virtual {v3, v0}, Lddc;->a(Ljava/lang/Object;)V

    :cond_a6
    :goto_a6
    add-int/lit8 v6, v6, 0x1

    goto :goto_4d

    :cond_a9
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->t0:Ltfg;

    if-eqz p0, :cond_b0

    invoke-static {p0, p1}, Legl;->w(Ltfg;Landroid/view/ViewStructure;)V

    :cond_b0
    return-void
.end method

.method public final onResolvePointerIcon(Landroid/view/MotionEvent;I)Landroid/view/PointerIcon;
    .registers 5

    invoke-virtual {p1, p2}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v0

    const/16 v1, 0x2002

    invoke-virtual {p1, v1}, Landroid/view/InputEvent;->isFromSource(I)Z

    move-result v1

    if-nez v1, :cond_2d

    const/16 v1, 0x4002

    invoke-virtual {p1, v1}, Landroid/view/InputEvent;->isFromSource(I)Z

    move-result v1

    if-eqz v1, :cond_2d

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1a

    const/4 v1, 0x4

    if-ne v0, v1, :cond_2d

    :cond_1a
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getPointerIconService()Lbrd;

    move-result-object v0

    check-cast v0, Ld10;

    iget-object v0, v0, Ld10;->a:Lard;

    if-eqz v0, :cond_2d

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0, v0}, Lu10;->b(Landroid/content/Context;Lard;)Landroid/view/PointerIcon;

    move-result-object p0

    return-object p0

    :cond_2d
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->onResolvePointerIcon(Landroid/view/MotionEvent;I)Landroid/view/PointerIcon;

    move-result-object p0

    return-object p0
.end method

.method public final onResume(Lhha;)V
    .registers 5

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1e

    if-ge p1, v0, :cond_d

    invoke-static {}, Lezg;->e0()Z

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->setShowLayoutBounds(Z)V

    :cond_d
    iget-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->K:Loha;

    if-eqz p1, :cond_56

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J:Lnha;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Loha;->a:Lfi8;

    iget-object v1, v0, Lfi8;->F:Ljava/lang/Object;

    check-cast v1, Li3b;

    iget-boolean v2, v1, Li3b;->E:Z

    if-eqz v2, :cond_56

    iget-boolean v1, v1, Li3b;->G:Z

    if-nez v1, :cond_56

    :try_start_24
    new-instance v1, Lh31;

    const/16 v2, 0x1a

    invoke-direct {v1, v2, p1}, Lh31;-><init>(ILjava/lang/Object;)V

    check-cast p0, Lm9k;

    iget-object p0, p0, Lm9k;->E:Lwv4;

    invoke-virtual {p0, v1}, Lwv4;->v(Lh31;)Lgi2;

    move-result-object p0
    :try_end_33
    .catch Ljava/util/concurrent/CancellationException; {:try_start_24 .. :try_end_33} :catch_34

    goto :goto_4d

    :catch_34
    iget-object p0, v0, Lfi8;->F:Ljava/lang/Object;

    check-cast p0, Li3b;

    iget-boolean v0, p0, Li3b;->F:Z

    if-eqz v0, :cond_3d

    goto :goto_4c

    :cond_3d
    iget-boolean v0, p0, Li3b;->G:Z

    if-eqz v0, :cond_46

    const-string v0, "ManagedValuesStore tried to enter composition twice. Did you attempt to install the same store multiple times or into two compositions?"

    invoke-static {v0}, Ldud;->a(Ljava/lang/String;)V

    :cond_46
    invoke-virtual {p0}, Li3b;->a()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Li3b;->G:Z

    :goto_4c
    const/4 p0, 0x0

    :goto_4d
    iget-object v0, p1, Loha;->d:Lgi2;

    if-eqz v0, :cond_54

    invoke-interface {v0}, Lgi2;->cancel()V

    :cond_54
    iput-object p0, p1, Loha;->d:Lgi2;

    :cond_56
    return-void
.end method

.method public final onRtlPropertiesChanged(I)V
    .registers 4

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->G:Z

    if-eqz v0, :cond_1a

    sget-object v0, Lo28;->a:[I

    sget-object v0, Lf7a;->E:Lf7a;

    if-eqz p1, :cond_12

    const/4 v1, 0x1

    if-eq p1, v1, :cond_f

    const/4 p1, 0x0

    goto :goto_13

    :cond_f
    sget-object p1, Lf7a;->F:Lf7a;

    goto :goto_13

    :cond_12
    move-object p1, v0

    :goto_13
    if-nez p1, :cond_16

    goto :goto_17

    :cond_16
    move-object v0, p1

    :goto_17
    invoke-direct {p0, v0}, Landroidx/compose/ui/platform/AndroidComposeView;->setLayoutDirection(Lf7a;)V

    :cond_1a
    return-void
.end method

.method public final onScrollCaptureSearch(Landroid/graphics/Rect;Landroid/graphics/Point;Ljava/util/function/Consumer;)V
    .registers 12

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x1f

    if-lt p1, p2, :cond_a0

    iget-object v4, p0, Landroidx/compose/ui/platform/AndroidComposeView;->o1:Ld3f;

    if-eqz v4, :cond_a0

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getSemanticsOwner()Lqag;

    move-result-object p1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getCoroutineContext()Lla5;

    move-result-object p2

    new-instance v0, Ljec;

    const/16 v1, 0x10

    new-array v1, v1, [Lrzf;

    const/4 v2, 0x0

    invoke-direct {v0, v2, v1}, Ljec;-><init>(I[Ljava/lang/Object;)V

    invoke-virtual {p1}, Lqag;->a()Lnag;

    move-result-object p1

    new-instance v1, Lyu0;

    invoke-direct {v1, v0}, Lyu0;-><init>(Ljec;)V

    invoke-static {p1, v1}, Lwkk;->g(Lnag;Lyu0;)V

    const/4 p1, 0x2

    new-array p1, p1, [Lc98;

    sget-object v1, Lrsd;->b0:Lrsd;

    aput-object v1, p1, v2

    sget-object v1, Lrsd;->c0:Lrsd;

    const/4 v6, 0x1

    aput-object v1, p1, v6

    invoke-static {p1}, Lbo9;->F([Lc98;)Lkq4;

    move-result-object p1

    iget-object v1, v0, Ljec;->E:[Ljava/lang/Object;

    iget v3, v0, Ljec;->G:I

    invoke-static {v1, v2, v3, p1}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V

    iget p1, v0, Ljec;->G:I

    if-nez p1, :cond_45

    const/4 p1, 0x0

    goto :goto_4a

    :cond_45
    sub-int/2addr p1, v6

    iget-object v0, v0, Ljec;->E:[Ljava/lang/Object;

    aget-object p1, v0, p1

    :goto_4a
    check-cast p1, Lrzf;

    if-nez p1, :cond_4f

    goto :goto_a0

    :cond_4f
    invoke-static {p2}, Lvi9;->d(Lla5;)Lt65;

    move-result-object v3

    new-instance v0, Lmu4;

    invoke-virtual {p1}, Lrzf;->b()Lnag;

    move-result-object v1

    invoke-virtual {p1}, Lrzf;->c()Luj9;

    move-result-object v2

    move-object v5, p0

    invoke-direct/range {v0 .. v5}, Lmu4;-><init>(Lnag;Luj9;Lt65;Ld3f;Landroidx/compose/ui/platform/AndroidComposeView;)V

    invoke-virtual {p1}, Lrzf;->a()Lc7a;

    move-result-object p0

    invoke-static {p0}, Lnfl;->m(Lc7a;)Lc7a;

    move-result-object p2

    invoke-interface {p2, p0, v6}, Lc7a;->J(Lc7a;Z)Lqwe;

    move-result-object p0

    invoke-virtual {p1}, Lrzf;->c()Luj9;

    move-result-object p2

    invoke-virtual {p2}, Luj9;->e()J

    move-result-wide v1

    invoke-static {p0}, Lrck;->V(Lqwe;)Luj9;

    move-result-object p0

    invoke-static {p0}, Lik5;->W(Luj9;)Landroid/graphics/Rect;

    move-result-object p0

    new-instance p2, Landroid/graphics/Point;

    const/16 v3, 0x20

    shr-long v3, v1, v3

    long-to-int v3, v3

    const-wide v6, 0xffffffffL

    and-long/2addr v1, v6

    long-to-int v1, v1

    invoke-direct {p2, v3, v1}, Landroid/graphics/Point;-><init>(II)V

    invoke-static {v5, p0, p2, v0}, Lpod;->m(Landroidx/compose/ui/platform/AndroidComposeView;Landroid/graphics/Rect;Landroid/graphics/Point;Landroid/view/ScrollCaptureCallback;)Landroid/view/ScrollCaptureTarget;

    move-result-object p0

    invoke-virtual {p1}, Lrzf;->c()Luj9;

    move-result-object p1

    invoke-static {p1}, Lik5;->W(Luj9;)Landroid/graphics/Rect;

    move-result-object p1

    invoke-static {p0, p1}, Lpod;->v(Landroid/view/ScrollCaptureTarget;Landroid/graphics/Rect;)V

    invoke-interface {p3, p0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_a0
    :goto_a0
    return-void
.end method

.method public final onScrollChanged()V
    .registers 1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->L()V

    return-void
.end method

.method public final onStop(Lhha;)V
    .registers 3

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->K:Loha;

    if-eqz p0, :cond_3b

    iget-object p1, p0, Loha;->a:Lfi8;

    iget-object p1, p1, Lfi8;->F:Ljava/lang/Object;

    check-cast p1, Li3b;

    iget-boolean v0, p1, Li3b;->E:Z

    if-eqz v0, :cond_1d

    iget-boolean v0, p1, Li3b;->G:Z

    if-nez v0, :cond_1d

    iget-object p1, p0, Loha;->d:Lgi2;

    if-eqz p1, :cond_19

    invoke-interface {p1}, Lgi2;->cancel()V

    :cond_19
    const/4 p1, 0x0

    iput-object p1, p0, Loha;->d:Lgi2;

    return-void

    :cond_1d
    iget-boolean p0, p1, Li3b;->F:Z

    if-eqz p0, :cond_22

    goto :goto_3b

    :cond_22
    iget-boolean p0, p1, Li3b;->G:Z

    if-nez p0, :cond_2b

    const-string p0, "ManagedValuesStore tried to leave composition twice. Is the store installed in multiple places?"

    invoke-static {p0}, Ldud;->a(Ljava/lang/String;)V

    :cond_2b
    iget-object p0, p1, Li3b;->H:Lrdc;

    invoke-virtual {p0}, Lrdc;->i()Z

    move-result p0

    if-nez p0, :cond_38

    const-string p0, "Attempted to start retaining exited values with pending exited values"

    invoke-static {p0}, Ldud;->a(Ljava/lang/String;)V

    :cond_38
    const/4 p0, 0x0

    iput-boolean p0, p1, Li3b;->G:Z

    :cond_3b
    :goto_3b
    return-void
.end method

.method public final onTouchModeChanged(Z)V
    .registers 3

    if-eqz p1, :cond_4

    const/4 p1, 0x1

    goto :goto_5

    :cond_4
    const/4 p1, 0x2

    :goto_5
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->X0:Lzg9;

    iget-object p0, p0, Lzg9;->a:Ltad;

    new-instance v0, Lxg9;

    invoke-direct {v0, p1}, Lxg9;-><init>(I)V

    invoke-virtual {p0, v0}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public final onVirtualViewTranslationResponses(Landroid/util/LongSparseArray;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, p1}, Ligl;->h(Lc20;Landroid/util/LongSparseArray;)V

    return-void
.end method

.method public final onWindowFocusChanged(Z)V
    .registers 3

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->m1:Z

    invoke-super {p0, p1}, Landroid/view/View;->onWindowFocusChanged(Z)V

    if-eqz p1, :cond_22

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1e

    if-ge p1, v0, :cond_22

    invoke-static {}, Lezg;->e0()Z

    move-result p1

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getShowLayoutBounds()Z

    move-result v0

    if-eq v0, p1, :cond_22

    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->setShowLayoutBounds(Z)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p0

    invoke-static {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->m(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_22
    return-void
.end method

.method public final q(Landroid/view/MotionEvent;)Z
    .registers 5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v1, 0x0

    cmpg-float v2, v1, v0

    if-gtz v2, :cond_25

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    cmpg-float v0, v0, v2

    if-gtz v0, :cond_25

    cmpg-float v0, v1, p1

    if-gtz v0, :cond_25

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p0

    int-to-float p0, p0

    cmpg-float p0, p1, p0

    if-gtz p0, :cond_25

    const/4 p0, 0x1

    return p0

    :cond_25
    const/4 p0, 0x0

    return p0
.end method

.method public final r(Landroid/view/MotionEvent;)Z
    .registers 5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_8

    goto :goto_30

    :cond_8
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->a1:Landroid/view/MotionEvent;

    if-eqz p0, :cond_30

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v2

    if-ne v0, v2, :cond_30

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawX()F

    move-result v2

    cmpg-float v0, v0, v2

    if-nez v0, :cond_30

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawY()F

    move-result p0

    cmpg-float p0, p1, p0

    if-nez p0, :cond_30

    const/4 p0, 0x0

    return p0

    :cond_30
    :goto_30
    return v1
.end method

.method public final requestFocus(ILandroid/graphics/Rect;)Z
    .registers 8

    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    goto :goto_49

    :cond_8
    invoke-static {p1}, Lo28;->d(I)Ly18;

    move-result-object p1

    if-eqz p1, :cond_11

    iget p1, p1, Ly18;->a:I

    goto :goto_12

    :cond_11
    const/4 p1, 0x7

    :goto_12
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v0

    const/4 v2, 0x0

    if-eqz p2, :cond_1e

    invoke-static {p2}, Lik5;->Y(Landroid/graphics/Rect;)Lqwe;

    move-result-object p2

    goto :goto_1f

    :cond_1e
    move-object p2, v2

    :goto_1f
    new-instance v3, Le10;

    const/4 v4, 0x0

    invoke-direct {v3, p1, v4}, Le10;-><init>(II)V

    check-cast v0, Lu28;

    invoke-virtual {v0, p1, p2, v3}, Lu28;->g(ILqwe;Lc98;)Ljava/lang/Boolean;

    move-result-object p2

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p2, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_34

    goto :goto_49

    :cond_34
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object p2

    new-instance v3, Le10;

    invoke-direct {v3, p1, v1}, Le10;-><init>(II)V

    check-cast p2, Lu28;

    invoke-virtual {p2, p1, v2, v3}, Lu28;->g(ILqwe;Lc98;)Ljava/lang/Boolean;

    move-result-object p2

    invoke-static {p2, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_4a

    :goto_49
    return v1

    :cond_4a
    invoke-virtual {p0}, Landroid/view/View;->hasFocus()Z

    move-result p2

    if-eqz p2, :cond_61

    invoke-static {p1}, Ljhl;->f(I)Z

    move-result p2

    if-eqz p2, :cond_61

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object p0

    check-cast p0, Lu28;

    invoke-virtual {p0, p1}, Lu28;->j(I)Z

    move-result p0

    return p0

    :cond_61
    return v4
.end method

.method public final s([F)V
    .registers 7

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->C()V

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->H0:[F

    invoke-static {p1, v0}, Lmab;->h([F[F)V

    iget-wide v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    const/16 v2, 0x20

    shr-long/2addr v0, v2

    long-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    iget-wide v1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    long-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->G0:[F

    invoke-static {p0}, Lmab;->d([F)V

    invoke-static {p0, v0, v1}, Lmab;->i([FFF)V

    invoke-static {p1, p0}, Lw10;->J([F[F)V

    return-void
.end method

.method public setAccessibilityEventBatchIntervalMillis(J)V
    .registers 3

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    iput-wide p1, p0, Lm10;->L:J

    return-void
.end method

.method public final setComposeViewContext(Lvu4;)V
    .registers 6

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getCoroutineContext()Lla5;

    move-result-object v0

    iget-object v1, p1, Lvu4;->b:Lwv4;

    invoke-virtual {v1}, Lwv4;->k()Lla5;

    move-result-object v1

    if-eq v0, v1, :cond_20

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRoot()Landroidx/compose/ui/node/LayoutNode;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/ui/node/LayoutNode;->getChildren$ui()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1b

    goto :goto_20

    :cond_1b
    const-string v0, "Changing ComposeViewContext cannot change the coroutine context without disposing of the composition first."

    invoke-static {v0}, Ldf9;->a(Ljava/lang/String;)V

    :cond_20
    :goto_20
    invoke-static {}, Lw6h;->a()Lx6h;

    move-result-object v0

    if-eqz v0, :cond_2b

    invoke-virtual {v0}, Lx6h;->e()Lc98;

    move-result-object v1

    goto :goto_2c

    :cond_2b
    const/4 v1, 0x0

    :goto_2c
    invoke-static {v0}, Lw6h;->b(Lx6h;)Lx6h;

    move-result-object v2

    :try_start_30
    invoke-direct {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->get_composeViewContext()Lvu4;

    move-result-object v3
    :try_end_34
    .catchall {:try_start_30 .. :try_end_34} :catchall_52

    invoke-static {v0, v2, v1}, Lw6h;->d(Lx6h;Lx6h;Lc98;)V

    if-eq p1, v3, :cond_51

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_45

    invoke-virtual {v3}, Lvu4;->b()V

    invoke-virtual {p1}, Lvu4;->c()V

    :cond_45
    invoke-direct {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->set_composeViewContext(Lvu4;)V

    iget-object p1, p1, Lvu4;->b:Lwv4;

    invoke-virtual {p1}, Lwv4;->k()Lla5;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->setCoroutineContext(Lla5;)V

    :cond_51
    return-void

    :catchall_52
    move-exception p0

    invoke-static {v0, v2, v1}, Lw6h;->d(Lx6h;Lx6h;Lc98;)V

    throw p0
.end method

.method public final setComposeViewContextIncrementedDuringInit$ui(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->n1:Z

    return-void
.end method

.method public final setConfiguration(Landroid/content/res/Configuration;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->r0:Ltad;

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public final setContentCaptureManager$ui(Lc20;)V
    .registers 2

    iput-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    return-void
.end method

.method public setCoroutineContext(Lla5;)V
    .registers 2

    iput-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->R:Lla5;

    return-void
.end method

.method public final setFrameEndScheduler$ui(Lnha;)V
    .registers 2

    iput-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J:Lnha;

    return-void
.end method

.method public final setLastMatrixRecalculationAnimationTime$ui(J)V
    .registers 3

    iput-wide p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->J0:J

    return-void
.end method

.method public final setOnReadyForComposition(Lc98;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lc98;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getDerivedIsAttached()Z

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-nez v0, :cond_11

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->n1:Z

    if-eqz v0, :cond_e

    goto :goto_11

    :cond_e
    iput-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->O0:Lc98;

    return-void

    :cond_11
    :goto_11
    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getComposeViewContext()Lvu4;

    move-result-object p0

    invoke-interface {p1, p0}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final setPrimaryDirectionalMotionAxisOverride-r2epLt8$ui(Lod9;)V
    .registers 2

    iput-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->H:Lod9;

    return-void
.end method

.method public setShowLayoutBounds(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->z0:Z

    return-void
.end method

.method public setUncaughtExceptionHandler(Ldkf;)V
    .registers 2

    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final setUncaughtExceptionHandler$ui(Ldkf;)V
    .registers 2

    return-void
.end method

.method public final shouldDelayChildPressedState()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final t(J)J
    .registers 10

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->C()V

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->H0:[F

    invoke-static {p1, p2, v0}, Lmab;->b(J[F)J

    move-result-wide p1

    const/16 v0, 0x20

    shr-long v1, p1, v0

    long-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    iget-wide v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    shr-long/2addr v2, v0

    long-to-int v2, v2

    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v2

    add-float/2addr v2, v1

    const-wide v3, 0xffffffffL

    and-long/2addr p1, v3

    long-to-int p1, p1

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    iget-wide v5, p0, Landroidx/compose/ui/platform/AndroidComposeView;->L0:J

    and-long/2addr v5, v3

    long-to-int p0, v5

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    add-float/2addr p0, p1

    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    int-to-long p1, p1

    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    int-to-long v1, p0

    shl-long p0, p1, v0

    and-long v0, v1, v3

    or-long/2addr p0, v0

    return-wide p0
.end method

.method public final u(Z)V
    .registers 4

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    iget-object v1, v0, Lilb;->b:Lhk0;

    invoke-virtual {v1}, Lhk0;->A()Z

    move-result v1

    if-nez v1, :cond_16

    iget-object v1, v0, Lilb;->e:Li47;

    iget-object v1, v1, Li47;->F:Ljava/lang/Object;

    check-cast v1, Ljec;

    iget v1, v1, Ljec;->G:I

    if-eqz v1, :cond_15

    goto :goto_16

    :cond_15
    return-void

    :cond_16
    :goto_16
    const-string v1, "AndroidOwner:measureAndLayout"

    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    if-eqz p1, :cond_20

    :try_start_1d
    iget-object p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->k1:Ly00;

    goto :goto_21

    :cond_20
    const/4 p1, 0x0

    :goto_21
    invoke-virtual {v0, p1}, Lilb;->m(Ly00;)Z

    move-result p1

    if-eqz p1, :cond_2a

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_2a
    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Lilb;->c(Z)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object v0

    invoke-virtual {v0}, Lswe;->a()V

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->o0:Z

    if-eqz v0, :cond_42

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->dispatchOnGlobalLayout()V

    iput-boolean p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->o0:Z
    :try_end_42
    .catchall {:try_start_1d .. :try_end_42} :catchall_46

    :cond_42
    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void

    :catchall_46
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
.end method

.method public final v(Landroidx/compose/ui/node/LayoutNode;J)V
    .registers 6

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    const-string v1, "AndroidOwner:measureAndLayout"

    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_7
    invoke-virtual {v0, p1, p2, p3}, Lilb;->n(Landroidx/compose/ui/node/LayoutNode;J)V

    iget-object p1, v0, Lilb;->b:Lhk0;

    invoke-virtual {p1}, Lhk0;->A()Z

    move-result p1

    if-nez p1, :cond_2a

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Lilb;->c(Z)V

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getRectManager()Lswe;

    move-result-object p2

    invoke-virtual {p2}, Lswe;->a()V

    iget-boolean p2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->o0:Z

    if-eqz p2, :cond_2a

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p2

    invoke-virtual {p2}, Landroid/view/ViewTreeObserver;->dispatchOnGlobalLayout()V

    iput-boolean p1, p0, Landroidx/compose/ui/platform/AndroidComposeView;->o0:Z
    :try_end_2a
    .catchall {:try_start_7 .. :try_end_2a} :catchall_2e

    :cond_2a
    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void

    :catchall_2e
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
.end method

.method public final w(I)Z
    .registers 8

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-ne p1, v0, :cond_5

    goto :goto_68

    :cond_5
    const/16 v0, 0x8

    if-ne p1, v0, :cond_a

    goto :goto_68

    :cond_a
    invoke-static {p1}, Lo28;->c(I)Ljava/lang/Integer;

    move-result-object v0

    const-string v2, "Invalid focus direction"

    if-eqz v0, :cond_74

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getFocusOwner()Ls28;

    move-result-object v3

    check-cast v3, Lu28;

    invoke-virtual {v3}, Lu28;->h()Lm38;

    move-result-object v3

    if-eqz v3, :cond_6e

    invoke-static {p1}, Lo28;->c(I)Ljava/lang/Integer;

    move-result-object p1

    if-eqz p1, :cond_69

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    invoke-static {v3}, La60;->Q(Lp46;)Landroidx/compose/ui/node/LayoutNode;

    move-result-object v2

    iget-object v2, v2, Landroidx/compose/ui/node/LayoutNode;->T:Lhmj;

    const/4 v3, 0x0

    if-eqz v2, :cond_3a

    invoke-virtual {v2}, Lx80;->getInteropView()Landroid/view/View;

    move-result-object v2

    goto :goto_3b

    :cond_3a
    move-object v2, v3

    :goto_3b
    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v4

    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    move-result-object v5

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {v5, p0, v4, p1}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_5c

    if-eqz v2, :cond_5c

    invoke-static {v2, p0}, Lw10;->o(Landroid/view/View;Landroid/view/View;)Z

    move-result p1

    const/4 v2, 0x1

    if-ne p1, v2, :cond_5c

    goto :goto_5d

    :cond_5c
    move-object p0, v3

    :goto_5d
    if-eqz p0, :cond_68

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p0, p1, v3}, Lo28;->b(Landroid/view/View;Ljava/lang/Integer;Landroid/graphics/Rect;)Z

    move-result p0

    return p0

    :cond_68
    :goto_68
    return v1

    :cond_69
    invoke-static {v2}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object p0

    throw p0

    :cond_6e
    const-string p0, "findNextViewInEmbeddedView called when owner does not have anything focused."

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return v1

    :cond_74
    invoke-static {v2}, Ld07;->z(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object p0

    throw p0
.end method

.method public final x()V
    .registers 11

    iget-boolean v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->v0:Z

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_4a

    invoke-virtual {p0}, Landroidx/compose/ui/platform/AndroidComposeView;->getSnapshotObserver()Lb5d;

    move-result-object v0

    iget-object v0, v0, Lb5d;->a:Lv7h;

    iget-object v3, v0, Lv7h;->h:Ljava/lang/Object;

    monitor-enter v3

    :try_start_f
    iget-object v0, v0, Lv7h;->g:Ljava/lang/Object;

    check-cast v0, Ljec;

    iget v4, v0, Ljec;->G:I
    :try_end_15
    .catchall {:try_start_f .. :try_end_15} :catchall_38

    move v5, v2

    move v6, v5

    :goto_17
    iget-object v7, v0, Ljec;->E:[Ljava/lang/Object;

    if-ge v5, v4, :cond_3d

    :try_start_1b
    aget-object v7, v7, v5

    check-cast v7, Lu7h;

    invoke-virtual {v7}, Lu7h;->d()V

    iget-object v7, v7, Lu7h;->f:Lrdc;

    invoke-virtual {v7}, Lrdc;->j()Z

    move-result v7

    if-nez v7, :cond_2d

    add-int/lit8 v6, v6, 0x1

    goto :goto_3a

    :cond_2d
    if-lez v6, :cond_3a

    iget-object v7, v0, Ljec;->E:[Ljava/lang/Object;

    sub-int v8, v5, v6

    aget-object v9, v7, v5

    aput-object v9, v7, v8

    goto :goto_3a

    :catchall_38
    move-exception p0

    goto :goto_48

    :cond_3a
    :goto_3a
    add-int/lit8 v5, v5, 0x1

    goto :goto_17

    :cond_3d
    sub-int v5, v4, v6

    invoke-static {v7, v5, v4, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    iput v5, v0, Ljec;->G:I
    :try_end_44
    .catchall {:try_start_1b .. :try_end_44} :catchall_38

    monitor-exit v3

    iput-boolean v2, p0, Landroidx/compose/ui/platform/AndroidComposeView;->v0:Z

    goto :goto_4a

    :goto_48
    monitor-exit v3

    throw p0

    :cond_4a
    :goto_4a
    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->A0:Lc90;

    if-eqz v0, :cond_51

    invoke-static {v0}, Landroidx/compose/ui/platform/AndroidComposeView;->g(Landroid/view/ViewGroup;)V

    :cond_51
    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->u0:Li00;

    if-eqz v0, :cond_71

    iget-object v3, v0, Li00;->L:Lmcc;

    iget v4, v3, Lmcc;->d:I

    if-nez v4, :cond_6a

    iget-boolean v4, v0, Li00;->M:Z

    if-eqz v4, :cond_6a

    iget-object v4, v0, Li00;->E:Ld3f;

    iget-object v4, v4, Ld3f;->E:Ljava/lang/Object;

    check-cast v4, Landroid/view/autofill/AutofillManager;

    invoke-virtual {v4}, Landroid/view/autofill/AutofillManager;->commit()V

    iput-boolean v2, v0, Li00;->M:Z

    :cond_6a
    iget v3, v3, Lmcc;->d:I

    if-eqz v3, :cond_71

    const/4 v3, 0x1

    iput-boolean v3, v0, Li00;->M:Z

    :cond_71
    :goto_71
    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d1:Lddc;

    invoke-virtual {v0}, Lddc;->i()Z

    move-result v0

    if-eqz v0, :cond_a1

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d1:Lddc;

    invoke-virtual {v0, v2}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_a1

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d1:Lddc;

    iget v0, v0, Lddc;->b:I

    move v3, v2

    :goto_86
    iget-object v4, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d1:Lddc;

    if-ge v3, v0, :cond_9d

    invoke-virtual {v4, v3}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La98;

    iget-object v5, p0, Landroidx/compose/ui/platform/AndroidComposeView;->d1:Lddc;

    invoke-virtual {v5, v3, v1}, Lddc;->n(ILjava/lang/Object;)Ljava/lang/Object;

    if-eqz v4, :cond_9a

    invoke-interface {v4}, La98;->a()Ljava/lang/Object;

    :cond_9a
    add-int/lit8 v3, v3, 0x1

    goto :goto_86

    :cond_9d
    invoke-virtual {v4, v2, v0}, Lddc;->l(II)V

    goto :goto_71

    :cond_a1
    return-void
.end method

.method public final y(Landroidx/compose/ui/node/LayoutNode;)V
    .registers 5

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->g0:Lm10;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lm10;->b0:Z

    invoke-virtual {v0}, Lm10;->q()Z

    move-result v2

    if-nez v2, :cond_c

    goto :goto_f

    :cond_c
    invoke-virtual {v0, p1}, Lm10;->r(Landroidx/compose/ui/node/LayoutNode;)V

    :goto_f
    iget-object p0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->h0:Lc20;

    iput-boolean v1, p0, Lc20;->K:Z

    invoke-virtual {p0}, Lc20;->e()Z

    move-result p1

    if-eqz p1, :cond_20

    iget-object p0, p0, Lc20;->L:Ly42;

    sget-object p1, Lz2j;->a:Lz2j;

    invoke-interface {p0, p1}, Ldbg;->t(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_20
    return-void
.end method

.method public final z(Landroidx/compose/ui/node/LayoutNode;ZZZ)V
    .registers 9

    iget-object v0, p0, Landroidx/compose/ui/platform/AndroidComposeView;->D0:Lilb;

    if-eqz p2, :cond_96

    iget-object p2, v0, Lilb;->b:Lhk0;

    iget-object v1, p1, Landroidx/compose/ui/node/LayoutNode;->M:Landroidx/compose/ui/node/LayoutNode;

    if-eqz v1, :cond_b

    goto :goto_10

    :cond_b
    const-string v1, "Error: requestLookaheadRemeasure cannot be called on a node outside LookaheadScope"

    invoke-static {v1}, Ldf9;->c(Ljava/lang/String;)V

    :goto_10
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->u()Lv7a;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_8b

    if-eq v1, v2, :cond_a1

    const/4 v3, 0x2

    if-eq v1, v3, :cond_8b

    const/4 v3, 0x3

    if-eq v1, v3, :cond_8b

    const/4 v3, 0x4

    if-ne v1, v3, :cond_87

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->x()Z

    move-result v1

    if-eqz v1, :cond_30

    if-nez p3, :cond_30

    goto/16 :goto_a1

    :cond_30
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->f0()V

    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->g0()V

    iget-boolean p3, p1, Landroidx/compose/ui/node/LayoutNode;->u0:Z

    if-eqz p3, :cond_3b

    goto :goto_a1

    :cond_3b
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->Z()Ljava/lang/Boolean;

    move-result-object p3

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p3, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_4d

    invoke-static {p1}, Lilb;->j(Landroidx/compose/ui/node/LayoutNode;)Z

    move-result p3

    if-eqz p3, :cond_59

    :cond_4d
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p3

    if-eqz p3, :cond_78

    invoke-virtual {p3}, Landroidx/compose/ui/node/LayoutNode;->x()Z

    move-result p3

    if-ne p3, v2, :cond_78

    :cond_59
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->X()Z

    move-result p3

    if-nez p3, :cond_65

    invoke-static {p1}, Lilb;->k(Landroidx/compose/ui/node/LayoutNode;)Z

    move-result p3

    if-eqz p3, :cond_7d

    :cond_65
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNode;->F()Landroidx/compose/ui/node/LayoutNode;

    move-result-object p3

    if-eqz p3, :cond_72

    invoke-virtual {p3}, Landroidx/compose/ui/node/LayoutNode;->A()Z

    move-result p3

    if-ne p3, v2, :cond_72

    goto :goto_7d

    :cond_72
    sget-object p3, Lno9;->G:Lno9;

    invoke-virtual {p2, p1, p3}, Lhk0;->b(Landroidx/compose/ui/node/LayoutNode;Lno9;)V

    goto :goto_7d

    :cond_78
    sget-object p3, Lno9;->E:Lno9;

    invoke-virtual {p2, p1, p3}, Lhk0;->b(Landroidx/compose/ui/node/LayoutNode;Lno9;)V

    :cond_7d
    :goto_7d
    iget-boolean p2, v0, Lilb;->d:Z

    if-nez p2, :cond_a1

    if-eqz p4, :cond_a1

    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->F(Landroidx/compose/ui/node/LayoutNode;)V

    return-void

    :cond_87
    invoke-static {}, Le97;->d()V

    return-void

    :cond_8b
    iget-object p0, v0, Lilb;->h:Ljec;

    new-instance p2, Lhlb;

    invoke-direct {p2, p1, v2, p3}, Lhlb;-><init>(Landroidx/compose/ui/node/LayoutNode;ZZ)V

    invoke-virtual {p0, p2}, Ljec;->b(Ljava/lang/Object;)V

    return-void

    :cond_96
    invoke-virtual {v0, p1, p3}, Lilb;->s(Landroidx/compose/ui/node/LayoutNode;Z)Z

    move-result p2

    if-eqz p2, :cond_a1

    if-eqz p4, :cond_a1

    invoke-virtual {p0, p1}, Landroidx/compose/ui/platform/AndroidComposeView;->F(Landroidx/compose/ui/node/LayoutNode;)V

    :cond_a1
    :goto_a1
    return-void
.end method
