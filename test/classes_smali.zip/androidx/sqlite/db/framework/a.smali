.class public final Landroidx/sqlite/db/framework/a;
.super Landroid/database/sqlite/SQLiteOpenHelper;
.source "SourceFile"


# static fields
.field public static final synthetic L:I


# instance fields
.field public final E:Landroid/content/Context;

.field public final F:Lxs5;

.field public final G:Ls31;

.field public final H:Z

.field public I:Z

.field public final J:Lb1e;

.field public K:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Lxs5;Ls31;Z)V
    .registers 12

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v4, p4, Ls31;->F:I

    new-instance v5, Lo88;

    invoke-direct {v5, p4, p3}, Lo88;-><init>(Ls31;Lxs5;)V

    const/4 v3, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    invoke-direct/range {v0 .. v5}, Landroid/database/sqlite/SQLiteOpenHelper;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;ILandroid/database/DatabaseErrorHandler;)V

    iput-object v1, v0, Landroidx/sqlite/db/framework/a;->E:Landroid/content/Context;

    iput-object p3, v0, Landroidx/sqlite/db/framework/a;->F:Lxs5;

    iput-object p4, v0, Landroidx/sqlite/db/framework/a;->G:Ls31;

    iput-boolean p5, v0, Landroidx/sqlite/db/framework/a;->H:Z

    new-instance p0, Lb1e;

    if-nez v2, :cond_25

    invoke-static {}, Lti6;->j()Ljava/lang/String;

    move-result-object p2

    goto :goto_26

    :cond_25
    move-object p2, v2

    :goto_26
    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p1

    const/4 p3, 0x0

    invoke-direct {p0, p2, p1, p3}, Lb1e;-><init>(Ljava/lang/String;Ljava/io/File;Z)V

    iput-object p0, v0, Landroidx/sqlite/db/framework/a;->J:Lb1e;

    return-void
.end method


# virtual methods
.method public final b(Z)Ln88;
    .registers 5

    iget-object v0, p0, Landroidx/sqlite/db/framework/a;->J:Lb1e;

    :try_start_2
    iget-boolean v1, p0, Landroidx/sqlite/db/framework/a;->K:Z

    const/4 v2, 0x0

    if-nez v1, :cond_11

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getDatabaseName()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_11

    const/4 v1, 0x1

    goto :goto_12

    :catchall_f
    move-exception p0

    goto :goto_32

    :cond_11
    move v1, v2

    :goto_12
    invoke-virtual {v0, v1}, Lb1e;->a(Z)V

    iput-boolean v2, p0, Landroidx/sqlite/db/framework/a;->I:Z

    invoke-virtual {p0, p1}, Landroidx/sqlite/db/framework/a;->e(Z)Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    iget-boolean v2, p0, Landroidx/sqlite/db/framework/a;->I:Z

    if-eqz v2, :cond_2a

    invoke-virtual {p0}, Landroidx/sqlite/db/framework/a;->close()V

    invoke-virtual {p0, p1}, Landroidx/sqlite/db/framework/a;->b(Z)Ln88;

    move-result-object p0
    :try_end_26
    .catchall {:try_start_2 .. :try_end_26} :catchall_f

    invoke-virtual {v0}, Lb1e;->b()V

    return-object p0

    :cond_2a
    :try_start_2a
    invoke-virtual {p0, v1}, Landroidx/sqlite/db/framework/a;->d(Landroid/database/sqlite/SQLiteDatabase;)Ln88;

    move-result-object p0
    :try_end_2e
    .catchall {:try_start_2a .. :try_end_2e} :catchall_f

    invoke-virtual {v0}, Lb1e;->b()V

    return-object p0

    :goto_32
    invoke-virtual {v0}, Lb1e;->b()V

    throw p0
.end method

.method public final close()V
    .registers 4

    iget-object v0, p0, Landroidx/sqlite/db/framework/a;->J:Lb1e;

    :try_start_2
    iget-boolean v1, v0, Lb1e;->a:Z

    invoke-virtual {v0, v1}, Lb1e;->a(Z)V

    invoke-super {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->close()V

    iget-object v1, p0, Landroidx/sqlite/db/framework/a;->F:Lxs5;

    const/4 v2, 0x0

    iput-object v2, v1, Lxs5;->F:Ljava/lang/Object;

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/sqlite/db/framework/a;->K:Z
    :try_end_12
    .catchall {:try_start_2 .. :try_end_12} :catchall_16

    invoke-virtual {v0}, Lb1e;->b()V

    return-void

    :catchall_16
    move-exception p0

    invoke-virtual {v0}, Lb1e;->b()V

    throw p0
.end method

.method public final d(Landroid/database/sqlite/SQLiteDatabase;)Ln88;
    .registers 4

    iget-object p0, p0, Landroidx/sqlite/db/framework/a;->F:Lxs5;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lxs5;->F:Ljava/lang/Object;

    check-cast v0, Ln88;

    if-eqz v0, :cond_15

    iget-object v1, v0, Ln88;->E:Landroid/database/sqlite/SQLiteDatabase;

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_14

    goto :goto_15

    :cond_14
    return-object v0

    :cond_15
    :goto_15
    new-instance v0, Ln88;

    invoke-direct {v0, p1}, Ln88;-><init>(Landroid/database/sqlite/SQLiteDatabase;)V

    iput-object v0, p0, Lxs5;->F:Ljava/lang/Object;

    return-object v0
.end method

.method public final e(Z)Landroid/database/sqlite/SQLiteDatabase;
    .registers 7

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getDatabaseName()Ljava/lang/String;

    move-result-object v0

    iget-boolean v1, p0, Landroidx/sqlite/db/framework/a;->K:Z

    iget-object v2, p0, Landroidx/sqlite/db/framework/a;->E:Landroid/content/Context;

    if-eqz v0, :cond_32

    if-nez v1, :cond_32

    invoke-virtual {v2, v0}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v1

    if-eqz v1, :cond_32

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v3

    if-nez v3, :cond_32

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Invalid database parent file, not a directory: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "SupportSQLite"

    invoke-static {v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_32
    if-eqz p1, :cond_3c

    :try_start_34
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :cond_3c
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_43
    .catchall {:try_start_34 .. :try_end_43} :catchall_44

    return-object v1

    :catchall_44
    const-wide/16 v3, 0x1f4

    :try_start_46
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_49
    .catch Ljava/lang/InterruptedException; {:try_start_46 .. :try_end_49} :catch_49

    :catch_49
    if-eqz p1, :cond_55

    :try_start_4b
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_5c

    :catchall_53
    move-exception v1

    goto :goto_5d

    :cond_55
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_5c
    .catchall {:try_start_4b .. :try_end_5c} :catchall_53

    :goto_5c
    return-object v1

    :goto_5d
    instance-of v3, v1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;

    if-eqz v3, :cond_85

    check-cast v1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;

    iget-object v3, v1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;->E:Lp88;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    iget-object v1, v1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;->F:Ljava/lang/Throwable;

    if-eqz v3, :cond_84

    const/4 v4, 0x1

    if-eq v3, v4, :cond_84

    const/4 v4, 0x2

    if-eq v3, v4, :cond_84

    const/4 v4, 0x3

    if-eq v3, v4, :cond_84

    const/4 v4, 0x4

    if-ne v3, v4, :cond_7f

    instance-of v3, v1, Landroid/database/sqlite/SQLiteException;

    if-eqz v3, :cond_7e

    goto :goto_85

    :cond_7e
    throw v1

    :cond_7f
    invoke-static {}, Le97;->d()V

    const/4 p0, 0x0

    return-object p0

    :cond_84
    throw v1

    :cond_85
    :goto_85
    instance-of v3, v1, Landroid/database/sqlite/SQLiteException;

    if-eqz v3, :cond_a9

    if-eqz v0, :cond_a9

    iget-boolean v3, p0, Landroidx/sqlite/db/framework/a;->H:Z

    if-eqz v3, :cond_a9

    invoke-virtual {v2, v0}, Landroid/content/Context;->deleteDatabase(Ljava/lang/String;)Z

    if-eqz p1, :cond_9e

    :try_start_94
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_a5

    :catch_9c
    move-exception p0

    goto :goto_a6

    :cond_9e
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_a5
    .catch Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException; {:try_start_94 .. :try_end_a5} :catch_9c

    :goto_a5
    return-object p0

    :goto_a6
    iget-object p0, p0, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;->F:Ljava/lang/Throwable;

    throw p0

    :cond_a9
    throw v1
.end method

.method public final onConfigure(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Landroidx/sqlite/db/framework/a;->I:Z

    iget-object v1, p0, Landroidx/sqlite/db/framework/a;->G:Ls31;

    if-nez v0, :cond_15

    iget v0, v1, Ls31;->F:I

    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteDatabase;->getVersion()I

    move-result v2

    if-eq v0, v2, :cond_15

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->setMaxSqlCacheSize(I)V

    :cond_15
    :try_start_15
    invoke-virtual {p0, p1}, Landroidx/sqlite/db/framework/a;->d(Landroid/database/sqlite/SQLiteDatabase;)Ln88;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1c

    return-void

    :catchall_1c
    move-exception p0

    new-instance p1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;

    sget-object v0, Lp88;->E:Lp88;

    invoke-direct {p1, v0, p0}, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;-><init>(Lp88;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public final onCreate(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_3
    iget-object v0, p0, Landroidx/sqlite/db/framework/a;->G:Ls31;

    invoke-virtual {p0, p1}, Landroidx/sqlite/db/framework/a;->d(Landroid/database/sqlite/SQLiteDatabase;)Ln88;

    move-result-object p0

    iget-object p1, v0, Ls31;->G:Ljava/lang/Object;

    check-cast p1, Lwjf;

    new-instance v0, Lzth;

    invoke-direct {v0, p0}, Lzth;-><init>(Ln88;)V

    invoke-virtual {p1, v0}, Lwjf;->c(Ljpf;)V
    :try_end_15
    .catchall {:try_start_3 .. :try_end_15} :catchall_16

    return-void

    :catchall_16
    move-exception p0

    new-instance p1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;

    sget-object v0, Lp88;->F:Lp88;

    invoke-direct {p1, v0, p0}, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;-><init>(Lp88;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public final onDowngrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/sqlite/db/framework/a;->I:Z

    :try_start_6
    iget-object v0, p0, Landroidx/sqlite/db/framework/a;->G:Ls31;

    invoke-virtual {p0, p1}, Landroidx/sqlite/db/framework/a;->d(Landroid/database/sqlite/SQLiteDatabase;)Ln88;

    move-result-object p0

    invoke-virtual {v0, p0, p2, p3}, Ls31;->l(Ln88;II)V
    :try_end_f
    .catchall {:try_start_6 .. :try_end_f} :catchall_10

    return-void

    :catchall_10
    move-exception p0

    new-instance p1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;

    sget-object p2, Lp88;->H:Lp88;

    invoke-direct {p1, p2, p0}, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;-><init>(Lp88;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public final onOpen(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Landroidx/sqlite/db/framework/a;->I:Z

    if-nez v0, :cond_25

    :try_start_7
    iget-object v0, p0, Landroidx/sqlite/db/framework/a;->G:Ls31;

    invoke-virtual {p0, p1}, Landroidx/sqlite/db/framework/a;->d(Landroid/database/sqlite/SQLiteDatabase;)Ln88;

    move-result-object p1

    iget-object v0, v0, Ls31;->G:Ljava/lang/Object;

    check-cast v0, Lwjf;

    new-instance v1, Lzth;

    invoke-direct {v1, p1}, Lzth;-><init>(Ln88;)V

    invoke-virtual {v0, v1}, Lwjf;->e(Ljpf;)V

    iput-object p1, v0, Lwjf;->h:Ln88;
    :try_end_1b
    .catchall {:try_start_7 .. :try_end_1b} :catchall_1c

    goto :goto_25

    :catchall_1c
    move-exception p0

    new-instance p1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;

    sget-object v0, Lp88;->I:Lp88;

    invoke-direct {p1, v0, p0}, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;-><init>(Lp88;Ljava/lang/Throwable;)V

    throw p1

    :cond_25
    :goto_25
    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/sqlite/db/framework/a;->K:Z

    return-void
.end method

.method public final onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/sqlite/db/framework/a;->I:Z

    :try_start_6
    iget-object v0, p0, Landroidx/sqlite/db/framework/a;->G:Ls31;

    invoke-virtual {p0, p1}, Landroidx/sqlite/db/framework/a;->d(Landroid/database/sqlite/SQLiteDatabase;)Ln88;

    move-result-object p0

    invoke-virtual {v0, p0, p2, p3}, Ls31;->l(Ln88;II)V
    :try_end_f
    .catchall {:try_start_6 .. :try_end_f} :catchall_10

    return-void

    :catchall_10
    move-exception p0

    new-instance p1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;

    sget-object p2, Lp88;->G:Lp88;

    invoke-direct {p1, p2, p0}, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;-><init>(Lp88;Ljava/lang/Throwable;)V

    throw p1
.end method
