.class public final synthetic Laha;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldha;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lixe;

.field public final synthetic G:Lc98;

.field public final synthetic H:Lhha;


# direct methods
.method public synthetic constructor <init>(Lhha;Lixe;Lc98;I)V
    .registers 5

    iput p4, p0, Laha;->E:I

    iput-object p1, p0, Laha;->H:Lhha;

    iput-object p2, p0, Laha;->F:Lixe;

    iput-object p3, p0, Laha;->G:Lc98;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Lhha;Lsga;)V
    .registers 6

    iget p1, p0, Laha;->E:I

    const/4 v0, 0x0

    iget-object v1, p0, Laha;->G:Lc98;

    iget-object v2, p0, Laha;->F:Lixe;

    iget-object p0, p0, Laha;->H:Lhha;

    packed-switch p1, :pswitch_data_54

    check-cast p0, Lqha;

    sget-object p1, Lcha;->a:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    aget p1, p1, p2

    const/4 p2, 0x1

    if-eq p1, p2, :cond_29

    const/4 p0, 0x2

    if-eq p1, p0, :cond_1d

    goto :goto_2f

    :cond_1d
    iget-object p0, v2, Lixe;->E:Ljava/lang/Object;

    check-cast p0, Lrha;

    if-eqz p0, :cond_26

    invoke-interface {p0}, Lrha;->a()V

    :cond_26
    iput-object v0, v2, Lixe;->E:Ljava/lang/Object;

    goto :goto_2f

    :cond_29
    invoke-interface {v1, p0}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    iput-object p0, v2, Lixe;->E:Ljava/lang/Object;

    :goto_2f
    return-void

    :pswitch_30  #0x0
    check-cast p0, Lmha;

    sget-object p1, Lcha;->a:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    aget p1, p1, p2

    const/4 p2, 0x3

    if-eq p1, p2, :cond_4d

    const/4 p0, 0x4

    if-eq p1, p0, :cond_41

    goto :goto_53

    :cond_41
    iget-object p0, v2, Lixe;->E:Ljava/lang/Object;

    check-cast p0, Liha;

    if-eqz p0, :cond_4a

    invoke-interface {p0}, Liha;->a()V

    :cond_4a
    iput-object v0, v2, Lixe;->E:Ljava/lang/Object;

    goto :goto_53

    :cond_4d
    invoke-interface {v1, p0}, Lc98;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    iput-object p0, v2, Lixe;->E:Ljava/lang/Object;

    :goto_53
    return-void

    :pswitch_data_54
    .packed-switch 0x0
        :pswitch_30  #00000000
    .end packed-switch
.end method
