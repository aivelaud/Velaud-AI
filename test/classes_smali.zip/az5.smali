.class public final Laz5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/List;

.field public final b:[F

.field public final c:I


# direct methods
.method public constructor <init>(Ljava/util/List;[F)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laz5;->a:Ljava/util/List;

    iput-object p2, p0, Laz5;->b:[F

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    array-length v1, p2

    if-ne v0, v1, :cond_f

    goto :goto_2c

    :cond_f
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DraggableAnchors were constructed with inconsistent key-value sizes. Keys: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " | Anchors: "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Lmr0;->a1([F)Ljava/util/List;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lgf9;->a(Ljava/lang/String;)V

    :goto_2c
    array-length p1, p2

    iput p1, p0, Laz5;->c:I

    return-void
.end method


# virtual methods
.method public final a(F)Ljava/lang/Object;
    .registers 12

    iget-object v0, p0, Laz5;->b:[F

    array-length v1, v0

    const/4 v2, -0x1

    const/high16 v3, 0x7f800000  # Float.POSITIVE_INFINITY

    const/4 v4, 0x0

    move v6, v2

    move v5, v4

    :goto_9
    if-ge v4, v1, :cond_1f

    aget v7, v0, v4

    add-int/lit8 v8, v5, 0x1

    sub-float v7, p1, v7

    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v7

    cmpg-float v9, v7, v3

    if-gtz v9, :cond_1b

    move v6, v5

    move v3, v7

    :cond_1b
    add-int/lit8 v4, v4, 0x1

    move v5, v8

    goto :goto_9

    :cond_1f
    if-ne v6, v2, :cond_23

    const/4 p0, 0x0

    return-object p0

    :cond_23
    iget-object p0, p0, Laz5;->a:Ljava/util/List;

    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final b(FZ)Ljava/lang/Object;
    .registers 14

    iget-object v0, p0, Laz5;->b:[F

    array-length v1, v0

    const/4 v2, -0x1

    const/high16 v3, 0x7f800000  # Float.POSITIVE_INFINITY

    const/4 v4, 0x0

    move v6, v2

    move v7, v3

    move v5, v4

    :goto_a
    if-ge v4, v1, :cond_26

    aget v8, v0, v4

    add-int/lit8 v9, v5, 0x1

    if-eqz p2, :cond_14

    sub-float/2addr v8, p1

    goto :goto_16

    :cond_14
    sub-float v8, p1, v8

    :goto_16
    const/4 v10, 0x0

    cmpg-float v10, v8, v10

    if-gez v10, :cond_1c

    move v8, v3

    :cond_1c
    cmpg-float v10, v8, v7

    if-gtz v10, :cond_22

    move v6, v5

    move v7, v8

    :cond_22
    add-int/lit8 v4, v4, 0x1

    move v5, v9

    goto :goto_a

    :cond_26
    if-ne v6, v2, :cond_2a

    const/4 p0, 0x0

    return-object p0

    :cond_2a
    iget-object p0, p0, Laz5;->a:Ljava/util/List;

    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 2

    iget-object p0, p0, Laz5;->a:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result p0

    const/4 p1, -0x1

    if-eq p0, p1, :cond_b

    const/4 p0, 0x1

    return p0

    :cond_b
    const/4 p0, 0x0

    return p0
.end method

.method public final d()F
    .registers 5

    iget-object p0, p0, Laz5;->b:[F

    array-length v0, p0

    if-nez v0, :cond_8

    const/high16 p0, 0x7fc00000  # Float.NaN

    return p0

    :cond_8
    const/4 v0, 0x0

    aget v0, p0, v0

    array-length v1, p0

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    if-gt v2, v1, :cond_1b

    :goto_10
    aget v3, p0, v2

    invoke-static {v0, v3}, Ljava/lang/Math;->max(FF)F

    move-result v0

    if-eq v2, v1, :cond_1b

    add-int/lit8 v2, v2, 0x1

    goto :goto_10

    :cond_1b
    return v0
.end method

.method public final e()F
    .registers 5

    iget-object p0, p0, Laz5;->b:[F

    array-length v0, p0

    if-nez v0, :cond_8

    const/high16 p0, 0x7fc00000  # Float.NaN

    return p0

    :cond_8
    const/4 v0, 0x0

    aget v0, p0, v0

    array-length v1, p0

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    if-gt v2, v1, :cond_1b

    :goto_10
    aget v3, p0, v2

    invoke-static {v0, v3}, Ljava/lang/Math;->min(FF)F

    move-result v0

    if-eq v2, v1, :cond_1b

    add-int/lit8 v2, v2, 0x1

    goto :goto_10

    :cond_1b
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_3

    goto :goto_28

    :cond_3
    instance-of v0, p1, Laz5;

    if-nez v0, :cond_8

    goto :goto_26

    :cond_8
    check-cast p1, Laz5;

    iget-object v0, p1, Laz5;->a:Ljava/util/List;

    iget-object v1, p0, Laz5;->a:Ljava/util/List;

    invoke-static {v1, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_26

    :cond_15
    iget-object v0, p0, Laz5;->b:[F

    iget-object v1, p1, Laz5;->b:[F

    invoke-static {v0, v1}, Ljava/util/Arrays;->equals([F[F)Z

    move-result v0

    if-nez v0, :cond_20

    goto :goto_26

    :cond_20
    iget p0, p0, Laz5;->c:I

    iget p1, p1, Laz5;->c:I

    if-eq p0, p1, :cond_28

    :goto_26
    const/4 p0, 0x0

    return p0

    :cond_28
    :goto_28
    const/4 p0, 0x1

    return p0
.end method

.method public final f(Ljava/lang/Object;)F
    .registers 3

    iget-object v0, p0, Laz5;->a:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result p1

    if-ltz p1, :cond_10

    iget-object p0, p0, Laz5;->b:[F

    array-length v0, p0

    if-ge p1, v0, :cond_10

    aget p0, p0, p1

    return p0

    :cond_10
    const/high16 p0, 0x7fc00000  # Float.NaN

    return p0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Laz5;->a:Ljava/util/List;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Laz5;->b:[F

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([F)I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget p0, p0, Laz5;->c:I

    add-int/2addr v1, p0

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 7

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DraggableAnchors(anchors={"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    :goto_8
    iget v2, p0, Laz5;->c:I

    if-ge v1, v2, :cond_41

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Laz5;->a:Ljava/util/List;

    invoke-static {v1, v4}, Lsm4;->w0(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v4, 0x3d

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    if-ltz v1, :cond_29

    iget-object v4, p0, Laz5;->b:[F

    array-length v5, v4

    if-ge v1, v5, :cond_29

    aget v4, v4, v1

    goto :goto_2b

    :cond_29
    const/high16 v4, 0x7fc00000  # Float.NaN

    :goto_2b
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, -0x1

    if-ge v1, v2, :cond_3e

    const-string v2, ", "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3e
    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    :cond_41
    const-string p0, "})"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
