.class public final synthetic Laf6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:La98;

.field public final synthetic G:La98;


# direct methods
.method public synthetic constructor <init>(La98;La98;I)V
    .registers 4

    iput p3, p0, Laf6;->E:I

    iput-object p1, p0, Laf6;->F:La98;

    iput-object p2, p0, Laf6;->G:La98;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    iget v0, p0, Laf6;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v5, p0, Laf6;->G:La98;

    iget-object p0, p0, Laf6;->F:La98;

    check-cast p1, Lzu4;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    packed-switch v0, :pswitch_data_46

    and-int/lit8 v0, p2, 0x3

    if-eq v0, v2, :cond_1c

    move v0, v3

    goto :goto_1d

    :cond_1c
    move v0, v4

    :goto_1d
    and-int/2addr p2, v3

    check-cast p1, Leb8;

    invoke-virtual {p1, p2, v0}, Leb8;->W(IZ)Z

    move-result p2

    if-eqz p2, :cond_2a

    invoke-static {p0, v5, p1, v4}, Louk;->b(La98;La98;Lzu4;I)V

    goto :goto_2d

    :cond_2a
    invoke-virtual {p1}, Leb8;->Z()V

    :goto_2d
    return-object v1

    :pswitch_2e  #0x0
    and-int/lit8 v0, p2, 0x3

    if-eq v0, v2, :cond_34

    move v0, v3

    goto :goto_35

    :cond_34
    move v0, v4

    :goto_35
    and-int/2addr p2, v3

    check-cast p1, Leb8;

    invoke-virtual {p1, p2, v0}, Leb8;->W(IZ)Z

    move-result p2

    if-eqz p2, :cond_42

    invoke-static {p0, v5, p1, v4}, Ljll;->b(La98;La98;Lzu4;I)V

    goto :goto_45

    :cond_42
    invoke-virtual {p1}, Leb8;->Z()V

    :goto_45
    return-object v1

    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_2e  #00000000
    .end packed-switch
.end method
