.class public final Lad3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lrf3;


# direct methods
.method public synthetic constructor <init>(Lrf3;I)V
    .registers 3

    iput p2, p0, Lad3;->E:I

    iput-object p1, p0, Lad3;->F:Lrf3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 3

    iget v0, p0, Lad3;->E:I

    iget-object p0, p0, Lad3;->F:Lrf3;

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_62

    invoke-virtual {p0}, Lrf3;->b1()Lo4e;

    move-result-object p0

    if-eqz p0, :cond_11

    iget-object p0, p0, Lo4e;->a:Ljava/lang/String;

    goto :goto_12

    :cond_11
    move-object p0, v1

    :goto_12
    if-eqz p0, :cond_18

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/ProjectId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/ProjectId;

    move-result-object v1

    :cond_18
    return-object v1

    :pswitch_19  #0x3
    invoke-virtual {p0}, Lrf3;->U0()Li1e;

    move-result-object p0

    if-eqz p0, :cond_24

    invoke-virtual {p0}, Li1e;->c()Ljava/lang/String;

    move-result-object p0

    goto :goto_25

    :cond_24
    move-object p0, v1

    :goto_25
    if-eqz p0, :cond_2b

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/MessageId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/MessageId;

    move-result-object v1

    :cond_2b
    return-object v1

    :pswitch_2c  #0x2
    iget-object p0, p0, Lrf3;->k0:Lzj3;

    invoke-virtual {p0}, Lzj3;->t()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_38

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/ModelId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/ModelId;

    move-result-object v1

    :cond_38
    return-object v1

    :pswitch_39  #0x1
    iget-object p0, p0, Lrf3;->t:Lcom/anthropic/claude/bell/tts/i;

    invoke-virtual {p0}, Lcom/anthropic/claude/bell/tts/i;->c()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_46

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/MessageId;->constructor-impl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_47

    :cond_46
    move-object p0, v1

    :goto_47
    if-eqz p0, :cond_4d

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/MessageId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/MessageId;

    move-result-object v1

    :cond_4d
    return-object v1

    :pswitch_4e  #0x0
    invoke-virtual {p0}, Lrf3;->k1()Lcom/anthropic/claude/bell/VoiceSessionSummary;

    move-result-object p0

    if-eqz p0, :cond_59

    invoke-virtual {p0}, Lcom/anthropic/claude/bell/VoiceSessionSummary;->getAudioCaptureSessionId-v45hjMY()Ljava/lang/String;

    move-result-object p0

    goto :goto_5a

    :cond_59
    move-object p0, v1

    :goto_5a
    if-eqz p0, :cond_60

    invoke-static {p0}, Lcom/anthropic/claude/types/strings/AudioCaptureSessionId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/AudioCaptureSessionId;

    move-result-object v1

    :cond_60
    return-object v1

    nop

    :pswitch_data_62
    .packed-switch 0x0
        :pswitch_4e  #00000000
        :pswitch_39  #00000001
        :pswitch_2c  #00000002
        :pswitch_19  #00000003
    .end packed-switch
.end method
