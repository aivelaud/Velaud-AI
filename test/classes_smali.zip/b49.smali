.class public final Lb49;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lb49;->a:I

    return-void
.end method

.method public static a(I)Ljava/lang/String;
    .registers 2

    const/4 v0, 0x1

    if-ne p0, v0, :cond_6

    const-string p0, "Hyphens.None"

    return-object p0

    :cond_6
    const/4 v0, 0x2

    if-ne p0, v0, :cond_c

    const-string p0, "Hyphens.Auto"

    return-object p0

    :cond_c
    if-nez p0, :cond_11

    const-string p0, "Hyphens.Unspecified"

    return-object p0

    :cond_11
    const-string p0, "Invalid"

    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, Lb49;

    if-nez v0, :cond_5

    goto :goto_d

    :cond_5
    check-cast p1, Lb49;

    iget p1, p1, Lb49;->a:I

    iget p0, p0, Lb49;->a:I

    if-eq p0, p1, :cond_f

    :goto_d
    const/4 p0, 0x0

    return p0

    :cond_f
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 1

    iget p0, p0, Lb49;->a:I

    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget p0, p0, Lb49;->a:I

    invoke-static {p0}, Lb49;->a(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
