.class public abstract La79;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Loo8;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Loo8;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La79;->a:Loo8;

    return-void
.end method
