.class public final Lad0;
.super Ldd0;
.source "SourceFile"


# instance fields
.field public a:F

.field public b:F


# direct methods
.method public constructor <init>(FF)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lad0;->a:F

    iput p2, p0, Lad0;->b:F

    return-void
.end method


# virtual methods
.method public final a(I)F
    .registers 3

    if-eqz p1, :cond_a

    const/4 v0, 0x1

    if-eq p1, v0, :cond_7

    const/4 p0, 0x0

    return p0

    :cond_7
    iget p0, p0, Lad0;->b:F

    return p0

    :cond_a
    iget p0, p0, Lad0;->a:F

    return p0
.end method

.method public final b()I
    .registers 1

    const/4 p0, 0x2

    return p0
.end method

.method public final c()Ldd0;
    .registers 2

    new-instance p0, Lad0;

    const/4 v0, 0x0

    invoke-direct {p0, v0, v0}, Lad0;-><init>(FF)V

    return-object p0
.end method

.method public final d()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, Lad0;->a:F

    iput v0, p0, Lad0;->b:F

    return-void
.end method

.method public final e(IF)V
    .registers 4

    if-eqz p1, :cond_9

    const/4 v0, 0x1

    if-eq p1, v0, :cond_6

    return-void

    :cond_6
    iput p2, p0, Lad0;->b:F

    return-void

    :cond_9
    iput p2, p0, Lad0;->a:F

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Lad0;

    if-eqz v0, :cond_18

    check-cast p1, Lad0;

    iget v0, p1, Lad0;->a:F

    iget v1, p0, Lad0;->a:F

    cmpg-float v0, v0, v1

    if-nez v0, :cond_18

    iget p1, p1, Lad0;->b:F

    iget p0, p0, Lad0;->b:F

    cmpg-float p0, p1, p0

    if-nez p0, :cond_18

    const/4 p0, 0x1

    return p0

    :cond_18
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 2

    iget v0, p0, Lad0;->a:F

    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Lad0;->b:F

    invoke-static {p0}, Ljava/lang/Float;->hashCode(F)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "AnimationVector2D: v1 = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lad0;->a:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", v2 = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Lad0;->b:F

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
