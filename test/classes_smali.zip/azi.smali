.class public final Lazi;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Luke;


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lky9;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lly9;->a(Lky9;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lazi;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    const/4 v1, 0x0

    if-eqz p1, :cond_1e

    const-class v2, Lazi;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    if-eq v2, v3, :cond_10

    goto :goto_1e

    :cond_10
    check-cast p1, Lazi;

    iget-object p0, p0, Lazi;->a:Ljava/lang/String;

    iget-object p1, p1, Lazi;->a:Ljava/lang/String;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1d

    return v1

    :cond_1d
    return v0

    :cond_1e
    :goto_1e
    return v1
.end method

.method public final getValue()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lazi;->a:Ljava/lang/String;

    return-object p0
.end method

.method public final hashCode()I
    .registers 1

    iget-object p0, p0, Lazi;->a:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lazi;->a:Ljava/lang/String;

    return-object p0
.end method
