.class public final Lac9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lmc9;


# instance fields
.field public final E:Lfnc;


# direct methods
.method public constructor <init>(Lfnc;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lac9;->E:Lfnc;

    return-void
.end method


# virtual methods
.method public final b()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final d()Lfnc;
    .registers 1

    iget-object p0, p0, Lac9;->E:Lfnc;

    return-object p0
.end method
