.class public final Lb1d;
.super Lgpd;
.source "SourceFile"


# instance fields
.field public i:[Lrx7;

.field public j:I

.field public k:[I

.field public l:I

.field public m:[Ljava/lang/Object;

.field public n:I


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x10

    new-array v1, v0, [Lrx7;

    iput-object v1, p0, Lb1d;->i:[Lrx7;

    new-array v1, v0, [I

    iput-object v1, p0, Lb1d;->k:[I

    new-array v0, v0, [Ljava/lang/Object;

    iput-object v0, p0, Lb1d;->m:[Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final O()V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, Lb1d;->j:I

    iput v0, p0, Lb1d;->l:I

    iget-object v1, p0, Lb1d;->m:[Ljava/lang/Object;

    const/4 v2, 0x0

    iget v3, p0, Lb1d;->n:I

    invoke-static {v1, v0, v3, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    iput v0, p0, Lb1d;->n:I

    return-void
.end method

.method public final P(Lvo0;La5h;Lz70;Lz0d;)V
    .registers 13

    iget v0, p0, Lb1d;->j:I

    if-eqz v0, :cond_46

    new-instance v2, La1d;

    invoke-direct {v2, p0}, La1d;-><init>(Lb1d;)V

    :goto_9
    iget-object v0, v2, La1d;->d:Lb1d;

    iget-object v1, v0, Lb1d;->i:[Lrx7;

    iget v3, v2, La1d;->a:I

    aget-object v1, v1, v3

    invoke-virtual {v1, v2}, Lrx7;->d(La1d;)Lza8;

    move-result-object v7

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    :try_start_19
    invoke-virtual/range {v1 .. v6}, Lrx7;->c(La1d;Lvo0;La5h;Lz70;Lz0d;)V
    :try_end_1c
    .catchall {:try_start_19 .. :try_end_1c} :catchall_40

    iget p1, v2, La1d;->a:I

    iget p2, v0, Lb1d;->j:I

    if-lt p1, p2, :cond_23

    goto :goto_46

    :cond_23
    iget-object p3, v0, Lb1d;->i:[Lrx7;

    aget-object p3, p3, p1

    iget p4, v2, La1d;->b:I

    iget v0, p3, Lrx7;->b:I

    add-int/2addr p4, v0

    iput p4, v2, La1d;->b:I

    iget p4, v2, La1d;->c:I

    iget p3, p3, Lrx7;->c:I

    add-int/2addr p4, p3

    iput p4, v2, La1d;->c:I

    add-int/lit8 p1, p1, 0x1

    iput p1, v2, La1d;->a:I

    if-ge p1, p2, :cond_46

    move-object p1, v3

    move-object p2, v4

    move-object p3, v5

    move-object p4, v6

    goto :goto_9

    :catchall_40
    move-exception v0

    move-object p0, v0

    invoke-static {p0, v6, v4, v7}, Lhmk;->e(Ljava/lang/Throwable;Lz0d;La5h;Lza8;)Ljava/lang/Throwable;

    throw p0

    :cond_46
    :goto_46
    invoke-virtual {p0}, Lb1d;->O()V

    return-void
.end method

.method public final Q()Z
    .registers 1

    iget p0, p0, Lb1d;->j:I

    if-nez p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public final R(Lrx7;)V
    .registers 9

    iget v0, p0, Lb1d;->j:I

    iget-object v1, p0, Lb1d;->i:[Lrx7;

    array-length v2, v1

    const/16 v3, 0x400

    const/4 v4, 0x0

    if-ne v0, v2, :cond_17

    if-le v0, v3, :cond_e

    move v2, v3

    goto :goto_f

    :cond_e
    move v2, v0

    :goto_f
    add-int/2addr v2, v0

    new-array v2, v2, [Lrx7;

    invoke-static {v1, v4, v2, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v2, p0, Lb1d;->i:[Lrx7;

    :cond_17
    iget v0, p0, Lb1d;->l:I

    iget v1, p1, Lrx7;->b:I

    iget v2, p1, Lrx7;->c:I

    add-int/2addr v0, v1

    iget-object v1, p0, Lb1d;->k:[I

    array-length v5, v1

    if-le v0, v5, :cond_34

    if-le v5, v3, :cond_27

    move v6, v3

    goto :goto_28

    :cond_27
    move v6, v5

    :goto_28
    add-int/2addr v6, v5

    if-ge v6, v0, :cond_2c

    goto :goto_2d

    :cond_2c
    move v0, v6

    :goto_2d
    new-array v0, v0, [I

    invoke-static {v4, v4, v5, v1, v0}, Lmr0;->t0(III[I[I)V

    iput-object v0, p0, Lb1d;->k:[I

    :cond_34
    iget v0, p0, Lb1d;->n:I

    add-int/2addr v0, v2

    iget-object v1, p0, Lb1d;->m:[Ljava/lang/Object;

    array-length v5, v1

    if-le v0, v5, :cond_4c

    if-le v5, v3, :cond_3f

    goto :goto_40

    :cond_3f
    move v3, v5

    :goto_40
    add-int/2addr v3, v5

    if-ge v3, v0, :cond_44

    goto :goto_45

    :cond_44
    move v0, v3

    :goto_45
    new-array v0, v0, [Ljava/lang/Object;

    invoke-static {v1, v4, v0, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, Lb1d;->m:[Ljava/lang/Object;

    :cond_4c
    iget-object v0, p0, Lb1d;->i:[Lrx7;

    iget v1, p0, Lb1d;->j:I

    add-int/lit8 v3, v1, 0x1

    iput v3, p0, Lb1d;->j:I

    aput-object p1, v0, v1

    iget v0, p0, Lb1d;->l:I

    iget p1, p1, Lrx7;->b:I

    add-int/2addr v0, p1

    iput v0, p0, Lb1d;->l:I

    iget p1, p0, Lb1d;->n:I

    add-int/2addr p1, v2

    iput p1, p0, Lb1d;->n:I

    return-void
.end method
