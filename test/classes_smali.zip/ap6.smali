.class public final enum Lap6;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum E:Lap6;

.field public static final enum F:Lap6;

.field public static final enum G:Lap6;

.field public static final enum H:Lap6;

.field public static final enum I:Lap6;

.field public static final enum J:Lap6;

.field public static final enum K:Lap6;

.field public static final enum L:Lap6;

.field public static final enum M:Lap6;

.field public static final enum N:Lap6;

.field public static final synthetic O:[Lap6;


# direct methods
.method static constructor <clinit>()V
    .registers 12

    new-instance v0, Lap6;

    const-string v1, "HEADER"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lap6;->E:Lap6;

    new-instance v1, Lap6;

    const-string v2, "NEW_CHAT"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lap6;->F:Lap6;

    new-instance v2, Lap6;

    const-string v3, "MORE_TABS"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lap6;->G:Lap6;

    new-instance v3, Lap6;

    const-string v4, "CUSTOMIZE"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lap6;->H:Lap6;

    new-instance v4, Lap6;

    const-string v5, "LAUNCH_TAB_PICKER"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Lap6;->I:Lap6;

    new-instance v5, Lap6;

    const-string v6, "DONE"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lap6;->J:Lap6;

    new-instance v6, Lap6;

    const-string v7, "STARRED_SECTION_DIVIDER"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lap6;->K:Lap6;

    new-instance v7, Lap6;

    const-string v8, "STARRED_SECTION_HEADER"

    const/4 v9, 0x7

    invoke-direct {v7, v8, v9}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lap6;->L:Lap6;

    new-instance v8, Lap6;

    const-string v9, "RECENTS_SECTION_DIVIDER"

    const/16 v10, 0x8

    invoke-direct {v8, v9, v10}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lap6;->M:Lap6;

    new-instance v9, Lap6;

    const-string v10, "RECENTS_SECTION_HEADER"

    const/16 v11, 0x9

    invoke-direct {v9, v10, v11}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lap6;->N:Lap6;

    filled-new-array/range {v0 .. v9}, [Lap6;

    move-result-object v0

    sput-object v0, Lap6;->O:[Lap6;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lap6;
    .registers 2

    const-class v0, Lap6;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lap6;

    return-object p0
.end method

.method public static values()[Lap6;
    .registers 1

    sget-object v0, Lap6;->O:[Lap6;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lap6;

    return-object v0
.end method
