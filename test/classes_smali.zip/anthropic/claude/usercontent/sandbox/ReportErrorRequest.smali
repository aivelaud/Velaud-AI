.class public final Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lanthropic/claude/usercontent/sandbox/ReportErrorRequest$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u0000 #2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001#B\u001d\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\"\u0010\u0013\u001a\u00020\u0002H\u0017b\u0018\b\u0014\u0012\b\b\u0015\u0012\u0004\b\b(\u0016\u0012\n\b\u0017\u0012\u0006\b\n0\u00188\u0019J\u0014\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0096\u0082\u0004J\n\u0010\u001e\u001a\u00020\u001fH\u0096\u0080\u0004J\b\u0010 \u001a\u00020!H\u0016J\u001c\u0010\"\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u0006RG\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004\u0092\u0002,\b\u000b\u0012\b\b\f\u0012\u0004\b\u0003\u0010\u0002\u0012\b\b\r\u0012\u0004\b\b(\u000e\u0012\n\b\u000f\u0012\u0006\b\n0\u00108\u0011\u0012\b\b\u0012\u0012\u0004\b\u0003\u0010\u0000¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006$"
    }
    d2 = {
        "Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;",
        "Lcom/squareup/wire/Message;",
        "",
        "error",
        "Lanthropic/claude/usercontent/sandbox/SandboxError;",
        "unknownFields",
        "Lokio/ByteString;",
        "<init>",
        "(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;)V",
        "getError",
        "()Lanthropic/claude/usercontent/sandbox/SandboxError;",
        "Lcom/squareup/wire/WireField;",
        "tag",
        "adapter",
        "anthropic.claude.usercontent.sandbox.SandboxError#ADAPTER",
        "label",
        "Lcom/squareup/wire/WireField$Label;",
        "OMIT_IDENTITY",
        "schemaIndex",
        "newBuilder",
        "Lkotlin/Deprecated;",
        "message",
        "Shouldn\'t be used in Kotlin",
        "level",
        "Lkotlin/DeprecationLevel;",
        "HIDDEN",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "copy",
        "Companion",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final ADAPTER:Lcom/squareup/wire/ProtoAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/squareup/wire/ProtoAdapter<",
            "Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lanthropic/claude/usercontent/sandbox/ReportErrorRequest$Companion;

.field private static final serialVersionUID:J


# instance fields
.field private final error:Lanthropic/claude/usercontent/sandbox/SandboxError;
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "anthropic.claude.usercontent.sandbox.SandboxError#ADAPTER"
        label = .enum Lcom/squareup/wire/WireField$Label;->OMIT_IDENTITY:Lcom/squareup/wire/WireField$Label;
        schemaIndex = 0x0
        tag = 0x1
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest$Companion;-><init>(Lry5;)V

    sput-object v0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->Companion:Lanthropic/claude/usercontent/sandbox/ReportErrorRequest$Companion;

    sget-object v0, Lcom/squareup/wire/FieldEncoding;->LENGTH_DELIMITED:Lcom/squareup/wire/FieldEncoding;

    const-class v1, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;

    sget-object v2, Loze;->a:Lpze;

    invoke-virtual {v2, v1}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v1

    sget-object v2, Lcom/squareup/wire/Syntax;->PROTO_3:Lcom/squareup/wire/Syntax;

    new-instance v3, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest$Companion$ADAPTER$1;

    invoke-direct {v3, v0, v1, v2}, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest$Companion$ADAPTER$1;-><init>(Lcom/squareup/wire/FieldEncoding;Lky9;Lcom/squareup/wire/Syntax;)V

    sput-object v3, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 15
    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, v0, v0, v1, v0}, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;-><init>(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;ILry5;)V

    return-void
.end method

.method public constructor <init>(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;)V
    .registers 4

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    sget-object v0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    .line 17
    invoke-direct {p0, v0, p2}, Lcom/squareup/wire/Message;-><init>(Lcom/squareup/wire/ProtoAdapter;Lokio/ByteString;)V

    .line 18
    iput-object p1, p0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->error:Lanthropic/claude/usercontent/sandbox/SandboxError;

    return-void
.end method

.method public synthetic constructor <init>(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;ILry5;)V
    .registers 5

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_5

    const/4 p1, 0x0

    :cond_5
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_b

    sget-object p2, Lokio/ByteString;->H:Lokio/ByteString;

    :cond_b
    invoke-direct {p0, p1, p2}, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;-><init>(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;)V

    return-void
.end method

.method public static synthetic copy$default(Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;ILjava/lang/Object;)Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;
    .registers 5

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_6

    iget-object p1, p0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->error:Lanthropic/claude/usercontent/sandbox/SandboxError;

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_e

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p2

    :cond_e
    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->copy(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;)Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final copy(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;)Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;
    .registers 3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;

    invoke-direct {p0, p1, p2}, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;-><init>(Lanthropic/claude/usercontent/sandbox/SandboxError;Lokio/ByteString;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v1

    check-cast p1, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;

    invoke-virtual {p1}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v3

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b

    return v2

    :cond_1b
    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->error:Lanthropic/claude/usercontent/sandbox/SandboxError;

    iget-object p1, p1, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->error:Lanthropic/claude/usercontent/sandbox/SandboxError;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_26

    return v2

    :cond_26
    return v0
.end method

.method public final getError()Lanthropic/claude/usercontent/sandbox/SandboxError;
    .registers 1

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->error:Lanthropic/claude/usercontent/sandbox/SandboxError;

    return-object p0
.end method

.method public hashCode()I
    .registers 3

    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    if-nez v0, :cond_1b

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lokio/ByteString;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x25

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->error:Lanthropic/claude/usercontent/sandbox/SandboxError;

    if-eqz v1, :cond_17

    invoke-virtual {v1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->hashCode()I

    move-result v1

    goto :goto_18

    :cond_17
    const/4 v1, 0x0

    :goto_18
    add-int/2addr v0, v1

    iput v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    :cond_1b
    return v0
.end method

.method public bridge synthetic newBuilder()Lcom/squareup/wire/Message$Builder;
    .registers 1
    .annotation runtime Ln76;
    .end annotation

    .line 8
    invoke-virtual {p0}, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->newBuilder()Ljava/lang/Void;

    move-result-object p0

    check-cast p0, Lcom/squareup/wire/Message$Builder;

    return-object p0
.end method

.method public synthetic newBuilder()Ljava/lang/Void;
    .registers 2
    .annotation runtime Ln76;
    .end annotation

    new-instance p0, Ljava/lang/AssertionError;

    const-string v0, "Builders are deprecated and only available in a javaInterop build; see https://square.github.io/wire/wire_compiler/#kotlin"

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p0
.end method

.method public toString()Ljava/lang/String;
    .registers 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/ReportErrorRequest;->error:Lanthropic/claude/usercontent/sandbox/SandboxError;

    if-eqz p0, :cond_1a

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "error="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1a
    const/4 v4, 0x0

    const/16 v5, 0x38

    const-string v1, ", "

    const-string v2, "ReportErrorRequest{"

    const-string v3, "}"

    invoke-static/range {v0 .. v5}, Lsm4;->A0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/String;Ljava/lang/String;Lc98;I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
