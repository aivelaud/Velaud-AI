.class public final Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;
.super Lcom/squareup/wire/ProtoAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lanthropic/claude/usercontent/sandbox/SandboxError;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/ProtoAdapter<",
        "Lanthropic/claude/usercontent/sandbox/SandboxError;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00003\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\f2\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\n\u0010\rJ\u0017\u0010\u0010\u001a\u00020\u00022\u0006\u0010\u000f\u001a\u00020\u000eH\u0016¢\u0006\u0004\b\u0010\u0010\u0011J\u0017\u0010\u0012\u001a\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0012\u0010\u0013¨\u0006\u0014"
    }
    d2 = {
        "anthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1",
        "Lcom/squareup/wire/ProtoAdapter;",
        "Lanthropic/claude/usercontent/sandbox/SandboxError;",
        "value",
        "",
        "encodedSize",
        "(Lanthropic/claude/usercontent/sandbox/SandboxError;)I",
        "Lcom/squareup/wire/ProtoWriter;",
        "writer",
        "Lz2j;",
        "encode",
        "(Lcom/squareup/wire/ProtoWriter;Lanthropic/claude/usercontent/sandbox/SandboxError;)V",
        "Lcom/squareup/wire/ReverseProtoWriter;",
        "(Lcom/squareup/wire/ReverseProtoWriter;Lanthropic/claude/usercontent/sandbox/SandboxError;)V",
        "Lcom/squareup/wire/ProtoReader;",
        "reader",
        "decode",
        "(Lcom/squareup/wire/ProtoReader;)Lanthropic/claude/usercontent/sandbox/SandboxError;",
        "redact",
        "(Lanthropic/claude/usercontent/sandbox/SandboxError;)Lanthropic/claude/usercontent/sandbox/SandboxError;",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>(Lcom/squareup/wire/FieldEncoding;Lky9;Lcom/squareup/wire/Syntax;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/squareup/wire/FieldEncoding;",
            "Lky9;",
            "Lcom/squareup/wire/Syntax;",
            ")V"
        }
    .end annotation

    const/4 v5, 0x0

    const-string v6, "sandbox/sandbox.proto"

    const-string v3, "type.googleapis.com/anthropic.claude.usercontent.sandbox.SandboxError"

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, p3

    invoke-direct/range {v0 .. v6}, Lcom/squareup/wire/ProtoAdapter;-><init>(Lcom/squareup/wire/FieldEncoding;Lky9;Ljava/lang/String;Lcom/squareup/wire/Syntax;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public decode(Lcom/squareup/wire/ProtoReader;)Lanthropic/claude/usercontent/sandbox/SandboxError;
    .registers 13

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lcom/squareup/wire/ProtoReader;->beginMessage()J

    move-result-wide v0

    const/4 p0, 0x0

    move-object v2, p0

    move-object v3, v2

    move-object v4, v3

    :goto_b
    invoke-virtual {p1}, Lcom/squareup/wire/ProtoReader;->nextTag()I

    move-result v5

    const/4 v6, -0x1

    if-eq v5, v6, :cond_3e

    const/4 v6, 0x1

    if-eq v5, v6, :cond_37

    const/4 v6, 0x2

    if-eq v5, v6, :cond_30

    const/4 v6, 0x3

    if-eq v5, v6, :cond_29

    const/4 v6, 0x4

    if-eq v5, v6, :cond_22

    invoke-virtual {p1, v5}, Lcom/squareup/wire/ProtoReader;->readUnknownField(I)V

    goto :goto_b

    :cond_22
    sget-object v4, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v4, p1}, Lcom/squareup/wire/ProtoAdapter;->decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;

    move-result-object v4

    goto :goto_b

    :cond_29
    sget-object v3, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v3, p1}, Lcom/squareup/wire/ProtoAdapter;->decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_b

    :cond_30
    sget-object v2, Lanthropic/claude/usercontent/sandbox/RuntimeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v2, p1}, Lcom/squareup/wire/ProtoAdapter;->decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;

    move-result-object v2

    goto :goto_b

    :cond_37
    sget-object p0, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {p0, p1}, Lcom/squareup/wire/ProtoAdapter;->decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_b

    :cond_3e
    invoke-virtual {p1, v0, v1}, Lcom/squareup/wire/ProtoReader;->endMessageAndGetUnknownFields(J)Lokio/ByteString;

    move-result-object v10

    new-instance v5, Lanthropic/claude/usercontent/sandbox/SandboxError;

    move-object v6, p0

    check-cast v6, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    move-object v7, v2

    check-cast v7, Lanthropic/claude/usercontent/sandbox/RuntimeError;

    move-object v8, v3

    check-cast v8, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    move-object v9, v4

    check-cast v9, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    invoke-direct/range {v5 .. v10}, Lanthropic/claude/usercontent/sandbox/SandboxError;-><init>(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)V

    return-object v5
.end method

.method public bridge synthetic decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;
    .registers 2

    .line 84
    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;->decode(Lcom/squareup/wire/ProtoReader;)Lanthropic/claude/usercontent/sandbox/SandboxError;

    move-result-object p0

    return-object p0
.end method

.method public encode(Lcom/squareup/wire/ProtoWriter;Lanthropic/claude/usercontent/sandbox/SandboxError;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p0, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x1

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getUnsupported_imports()Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ProtoWriter;ILjava/lang/Object;)V

    sget-object p0, Lanthropic/claude/usercontent/sandbox/RuntimeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x2

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getRuntime_error()Lanthropic/claude/usercontent/sandbox/RuntimeError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ProtoWriter;ILjava/lang/Object;)V

    sget-object p0, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x3

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getFile_not_found()Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ProtoWriter;ILjava/lang/Object;)V

    sget-object p0, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x4

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getClaude_completion_error()Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ProtoWriter;ILjava/lang/Object;)V

    invoke-virtual {p2}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p0

    invoke-virtual {p1, p0}, Lcom/squareup/wire/ProtoWriter;->writeBytes(Lokio/ByteString;)V

    return-void
.end method

.method public bridge synthetic encode(Lcom/squareup/wire/ProtoWriter;Ljava/lang/Object;)V
    .registers 3

    .line 55
    check-cast p2, Lanthropic/claude/usercontent/sandbox/SandboxError;

    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;->encode(Lcom/squareup/wire/ProtoWriter;Lanthropic/claude/usercontent/sandbox/SandboxError;)V

    return-void
.end method

.method public encode(Lcom/squareup/wire/ReverseProtoWriter;Lanthropic/claude/usercontent/sandbox/SandboxError;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    invoke-virtual {p2}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p0

    invoke-virtual {p1, p0}, Lcom/squareup/wire/ReverseProtoWriter;->writeBytes(Lokio/ByteString;)V

    .line 57
    sget-object p0, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x4

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getClaude_completion_error()Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ReverseProtoWriter;ILjava/lang/Object;)V

    .line 58
    sget-object p0, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x3

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getFile_not_found()Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ReverseProtoWriter;ILjava/lang/Object;)V

    .line 59
    sget-object p0, Lanthropic/claude/usercontent/sandbox/RuntimeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x2

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getRuntime_error()Lanthropic/claude/usercontent/sandbox/RuntimeError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ReverseProtoWriter;ILjava/lang/Object;)V

    .line 60
    sget-object p0, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x1

    invoke-virtual {p2}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getUnsupported_imports()Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    move-result-object p2

    invoke-virtual {p0, p1, v0, p2}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ReverseProtoWriter;ILjava/lang/Object;)V

    return-void
.end method

.method public bridge synthetic encode(Lcom/squareup/wire/ReverseProtoWriter;Ljava/lang/Object;)V
    .registers 3

    .line 54
    check-cast p2, Lanthropic/claude/usercontent/sandbox/SandboxError;

    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;->encode(Lcom/squareup/wire/ReverseProtoWriter;Lanthropic/claude/usercontent/sandbox/SandboxError;)V

    return-void
.end method

.method public encodedSize(Lanthropic/claude/usercontent/sandbox/SandboxError;)I
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p0

    invoke-virtual {p0}, Lokio/ByteString;->e()I

    move-result p0

    sget-object v0, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v1, 0x1

    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getUnsupported_imports()Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/squareup/wire/ProtoAdapter;->encodedSizeWithTag(ILjava/lang/Object;)I

    move-result v0

    add-int/2addr v0, p0

    sget-object p0, Lanthropic/claude/usercontent/sandbox/RuntimeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v1, 0x2

    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getRuntime_error()Lanthropic/claude/usercontent/sandbox/RuntimeError;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcom/squareup/wire/ProtoAdapter;->encodedSizeWithTag(ILjava/lang/Object;)I

    move-result p0

    add-int/2addr p0, v0

    sget-object v0, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v1, 0x3

    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getFile_not_found()Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/squareup/wire/ProtoAdapter;->encodedSizeWithTag(ILjava/lang/Object;)I

    move-result v0

    add-int/2addr v0, p0

    sget-object p0, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v1, 0x4

    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getClaude_completion_error()Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    move-result-object p1

    invoke-virtual {p0, v1, p1}, Lcom/squareup/wire/ProtoAdapter;->encodedSizeWithTag(ILjava/lang/Object;)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public bridge synthetic encodedSize(Ljava/lang/Object;)I
    .registers 2

    .line 60
    check-cast p1, Lanthropic/claude/usercontent/sandbox/SandboxError;

    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;->encodedSize(Lanthropic/claude/usercontent/sandbox/SandboxError;)I

    move-result p0

    return p0
.end method

.method public redact(Lanthropic/claude/usercontent/sandbox/SandboxError;)Lanthropic/claude/usercontent/sandbox/SandboxError;
    .registers 9

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getUnsupported_imports()Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    move-result-object p0

    const/4 v0, 0x0

    if-eqz p0, :cond_14

    sget-object v1, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v1, p0}, Lcom/squareup/wire/ProtoAdapter;->redact(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    move-object v2, p0

    goto :goto_15

    :cond_14
    move-object v2, v0

    :goto_15
    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getRuntime_error()Lanthropic/claude/usercontent/sandbox/RuntimeError;

    move-result-object p0

    if-eqz p0, :cond_25

    sget-object v1, Lanthropic/claude/usercontent/sandbox/RuntimeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v1, p0}, Lcom/squareup/wire/ProtoAdapter;->redact(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lanthropic/claude/usercontent/sandbox/RuntimeError;

    move-object v3, p0

    goto :goto_26

    :cond_25
    move-object v3, v0

    :goto_26
    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getFile_not_found()Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    move-result-object p0

    if-eqz p0, :cond_36

    sget-object v1, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v1, p0}, Lcom/squareup/wire/ProtoAdapter;->redact(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    move-object v4, p0

    goto :goto_37

    :cond_36
    move-object v4, v0

    :goto_37
    invoke-virtual {p1}, Lanthropic/claude/usercontent/sandbox/SandboxError;->getClaude_completion_error()Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    move-result-object p0

    if-eqz p0, :cond_46

    sget-object v0, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v0, p0}, Lcom/squareup/wire/ProtoAdapter;->redact(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    move-object v0, p0

    check-cast v0, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    :cond_46
    move-object v5, v0

    sget-object v6, Lokio/ByteString;->H:Lokio/ByteString;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Lanthropic/claude/usercontent/sandbox/SandboxError;->copy(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)Lanthropic/claude/usercontent/sandbox/SandboxError;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic redact(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 79
    check-cast p1, Lanthropic/claude/usercontent/sandbox/SandboxError;

    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;->redact(Lanthropic/claude/usercontent/sandbox/SandboxError;)Lanthropic/claude/usercontent/sandbox/SandboxError;

    move-result-object p0

    return-object p0
.end method
