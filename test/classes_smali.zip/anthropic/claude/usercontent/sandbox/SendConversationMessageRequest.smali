.class public final Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$Companion;,
        Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\u0018\u0000 &2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0002&\'B%\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\"\u0010\u0018\u001a\u00020\u0002H\u0017b\u0018\b\u0019\u0012\b\b\u0003\u0012\u0004\b\b(\u001a\u0012\n\b\u001b\u0012\u0006\b\n0\u001c8\u001dJ\u0014\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010!H\u0096\u0082\u0004J\n\u0010\"\u001a\u00020#H\u0096\u0080\u0004J\b\u0010$\u001a\u00020\u0004H\u0016J$\u0010%\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\bRE\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004\u0092\u0002,\b\r\u0012\b\b\u000e\u0012\u0004\b\u0003\u0010\u0002\u0012\b\b\u000f\u0012\u0004\b\b(\u0010\u0012\n\b\u0011\u0012\u0006\b\n0\u00128\u0013\u0012\b\b\u0014\u0012\u0004\b\u0003\u0010\u0000¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fRE\u0010\u0005\u001a\u00020\u00068\u0006X\u0087\u0004\u0092\u0002,\b\r\u0012\b\b\u000e\u0012\u0004\b\u0003\u0010\u0004\u0012\b\b\u000f\u0012\u0004\b\b(\u0017\u0012\n\b\u0011\u0012\u0006\b\n0\u00128\u0013\u0012\b\b\u0014\u0012\u0004\b\u0003\u0010\u0002¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016¨\u0006("
    }
    d2 = {
        "Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;",
        "Lcom/squareup/wire/Message;",
        "",
        "message",
        "",
        "message_type",
        "Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;",
        "unknownFields",
        "Lokio/ByteString;",
        "<init>",
        "(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;)V",
        "getMessage",
        "()Ljava/lang/String;",
        "Lcom/squareup/wire/WireField;",
        "tag",
        "adapter",
        "com.squareup.wire.ProtoAdapter#STRING",
        "label",
        "Lcom/squareup/wire/WireField$Label;",
        "OMIT_IDENTITY",
        "schemaIndex",
        "getMessage_type",
        "()Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;",
        "anthropic.claude.usercontent.sandbox.SendConversationMessageRequest$MessageType#ADAPTER",
        "newBuilder",
        "Lkotlin/Deprecated;",
        "Shouldn\'t be used in Kotlin",
        "level",
        "Lkotlin/DeprecationLevel;",
        "HIDDEN",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "copy",
        "Companion",
        "MessageType",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final ADAPTER:Lcom/squareup/wire/ProtoAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/squareup/wire/ProtoAdapter<",
            "Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$Companion;

.field private static final serialVersionUID:J


# instance fields
.field private final message:Ljava/lang/String;
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "com.squareup.wire.ProtoAdapter#STRING"
        label = .enum Lcom/squareup/wire/WireField$Label;->OMIT_IDENTITY:Lcom/squareup/wire/WireField$Label;
        schemaIndex = 0x0
        tag = 0x1
    .end annotation
.end field

.field private final message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "anthropic.claude.usercontent.sandbox.SendConversationMessageRequest$MessageType#ADAPTER"
        label = .enum Lcom/squareup/wire/WireField$Label;->OMIT_IDENTITY:Lcom/squareup/wire/WireField$Label;
        schemaIndex = 0x1
        tag = 0x2
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$Companion;-><init>(Lry5;)V

    sput-object v0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->Companion:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$Companion;

    sget-object v0, Lcom/squareup/wire/FieldEncoding;->LENGTH_DELIMITED:Lcom/squareup/wire/FieldEncoding;

    const-class v1, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;

    sget-object v2, Loze;->a:Lpze;

    invoke-virtual {v2, v1}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v1

    sget-object v2, Lcom/squareup/wire/Syntax;->PROTO_3:Lcom/squareup/wire/Syntax;

    new-instance v3, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$Companion$ADAPTER$1;

    invoke-direct {v3, v0, v1, v2}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$Companion$ADAPTER$1;-><init>(Lcom/squareup/wire/FieldEncoding;Lky9;Lcom/squareup/wire/Syntax;)V

    sput-object v3, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    return-void
.end method

.method public constructor <init>()V
    .registers 7

    .line 22
    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v5}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;-><init>(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;ILry5;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    sget-object v0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    .line 24
    invoke-direct {p0, v0, p3}, Lcom/squareup/wire/Message;-><init>(Lcom/squareup/wire/ProtoAdapter;Lokio/ByteString;)V

    .line 25
    iput-object p1, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message:Ljava/lang/String;

    .line 26
    iput-object p2, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;ILry5;)V
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    const-string p1, ""

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    sget-object p2, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;->MESSAGE_TYPE_UNSPECIFIED:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    sget-object p3, Lokio/ByteString;->H:Lokio/ByteString;

    :cond_12
    invoke-direct {p0, p1, p2, p3}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;-><init>(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;)V

    return-void
.end method

.method public static synthetic copy$default(Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;ILjava/lang/Object;)Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget-object p1, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message:Ljava/lang/String;

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget-object p2, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_14

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p3

    :cond_14
    invoke-virtual {p0, p1, p2, p3}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->copy(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;)Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final copy(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;)Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;

    invoke-direct {p0, p1, p2, p3}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;-><init>(Ljava/lang/String;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;Lokio/ByteString;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v1

    check-cast p1, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;

    invoke-virtual {p1}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v3

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b

    return v2

    :cond_1b
    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message:Ljava/lang/String;

    iget-object v3, p1, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message:Ljava/lang/String;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_26

    return v2

    :cond_26
    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    iget-object p1, p1, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    if-eq p0, p1, :cond_2d

    return v2

    :cond_2d
    return v0
.end method

.method public final getMessage()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message:Ljava/lang/String;

    return-object p0
.end method

.method public final getMessage_type()Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;
    .registers 1

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    return-object p0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    if-nez v0, :cond_1f

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lokio/ByteString;->hashCode()I

    move-result v0

    const/16 v1, 0x25

    mul-int/2addr v0, v1

    iget-object v2, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Lwsg;->l(IILjava/lang/String;)I

    move-result v0

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    iput v1, p0, Lcom/squareup/wire/Message;->hashCode:I

    return v1

    :cond_1f
    return v0
.end method

.method public bridge synthetic newBuilder()Lcom/squareup/wire/Message$Builder;
    .registers 1
    .annotation runtime Ln76;
    .end annotation

    .line 8
    invoke-virtual {p0}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->newBuilder()Ljava/lang/Void;

    move-result-object p0

    check-cast p0, Lcom/squareup/wire/Message$Builder;

    return-object p0
.end method

.method public synthetic newBuilder()Ljava/lang/Void;
    .registers 2
    .annotation runtime Ln76;
    .end annotation

    new-instance p0, Ljava/lang/AssertionError;

    const-string v0, "Builders are deprecated and only available in a javaInterop build; see https://square.github.io/wire/wire_compiler/#kotlin"

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p0
.end method

.method public toString()Ljava/lang/String;
    .registers 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message:Ljava/lang/String;

    invoke-static {v1}, Lcom/squareup/wire/internal/Internal;->sanitize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "message="

    invoke-static {v2, v1, v0}, Lb27;->y(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest;->message_type:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "message_type="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/16 v5, 0x38

    const-string v1, ", "

    const-string v2, "SendConversationMessageRequest{"

    const-string v3, "}"

    invoke-static/range {v0 .. v5}, Lsm4;->A0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/String;Ljava/lang/String;Lc98;I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
