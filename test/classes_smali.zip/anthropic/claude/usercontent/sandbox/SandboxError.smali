.class public final Lanthropic/claude/usercontent/sandbox/SandboxError;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lanthropic/claude/usercontent/sandbox/SandboxError$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000`\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u0000 12\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u00011BA\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n\u0012\b\b\u0002\u0010\u000b\u001a\u00020\f¢\u0006\u0004\b\r\u0010\u000eJ\"\u0010!\u001a\u00020\u0002H\u0017b\u0018\b\"\u0012\b\b#\u0012\u0004\b\b($\u0012\n\b%\u0012\u0006\b\n0&8\'J\u0014\u0010(\u001a\u00020)2\b\u0010*\u001a\u0004\u0018\u00010+H\u0096\u0082\u0004J\n\u0010,\u001a\u00020-H\u0096\u0080\u0004J\b\u0010.\u001a\u00020/H\u0016J@\u00100\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n2\b\b\u0002\u0010\u000b\u001a\u00020\fRE\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004\u0092\u0002*\b\u0011\u0012\b\b\u0012\u0012\u0004\b\u0003\u0010\u0002\u0012\b\b\u0013\u0012\u0004\b\b(\u0014\u0012\b\b\u0015\u0012\u0004\b\b(\u0016\u0012\b\b\u0017\u0012\u0004\b\u0003\u0010\u0000¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010RE\u0010\u0005\u001a\u0004\u0018\u00010\u00068\u0006X\u0087\u0004\u0092\u0002*\b\u0011\u0012\b\b\u0012\u0012\u0004\b\u0003\u0010\u0004\u0012\b\b\u0013\u0012\u0004\b\b(\u001a\u0012\b\b\u0015\u0012\u0004\b\b(\u0016\u0012\b\b\u0017\u0012\u0004\b\u0003\u0010\u0002¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019RE\u0010\u0007\u001a\u0004\u0018\u00010\b8\u0006X\u0087\u0004\u0092\u0002*\b\u0011\u0012\b\b\u0012\u0012\u0004\b\u0003\u0010\u0006\u0012\b\b\u0013\u0012\u0004\b\b(\u001d\u0012\b\b\u0015\u0012\u0004\b\b(\u0016\u0012\b\b\u0017\u0012\u0004\b\u0003\u0010\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cRE\u0010\t\u001a\u0004\u0018\u00010\n8\u0006X\u0087\u0004\u0092\u0002*\b\u0011\u0012\b\b\u0012\u0012\u0004\b\u0003\u0010\b\u0012\b\b\u0013\u0012\u0004\b\b( \u0012\b\b\u0015\u0012\u0004\b\b(\u0016\u0012\b\b\u0017\u0012\u0004\b\u0003\u0010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001f¨\u00062"
    }
    d2 = {
        "Lanthropic/claude/usercontent/sandbox/SandboxError;",
        "Lcom/squareup/wire/Message;",
        "",
        "unsupported_imports",
        "Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;",
        "runtime_error",
        "Lanthropic/claude/usercontent/sandbox/RuntimeError;",
        "file_not_found",
        "Lanthropic/claude/usercontent/sandbox/FileNotFoundError;",
        "claude_completion_error",
        "Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;",
        "unknownFields",
        "Lokio/ByteString;",
        "<init>",
        "(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)V",
        "getUnsupported_imports",
        "()Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;",
        "Lcom/squareup/wire/WireField;",
        "tag",
        "adapter",
        "anthropic.claude.usercontent.sandbox.UnsupportedImportsError#ADAPTER",
        "oneofName",
        "error",
        "schemaIndex",
        "getRuntime_error",
        "()Lanthropic/claude/usercontent/sandbox/RuntimeError;",
        "anthropic.claude.usercontent.sandbox.RuntimeError#ADAPTER",
        "getFile_not_found",
        "()Lanthropic/claude/usercontent/sandbox/FileNotFoundError;",
        "anthropic.claude.usercontent.sandbox.FileNotFoundError#ADAPTER",
        "getClaude_completion_error",
        "()Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;",
        "anthropic.claude.usercontent.sandbox.ClaudeCompletionError#ADAPTER",
        "newBuilder",
        "Lkotlin/Deprecated;",
        "message",
        "Shouldn\'t be used in Kotlin",
        "level",
        "Lkotlin/DeprecationLevel;",
        "HIDDEN",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "copy",
        "Companion",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final ADAPTER:Lcom/squareup/wire/ProtoAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/squareup/wire/ProtoAdapter<",
            "Lanthropic/claude/usercontent/sandbox/SandboxError;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lanthropic/claude/usercontent/sandbox/SandboxError$Companion;

.field private static final serialVersionUID:J


# instance fields
.field private final claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "anthropic.claude.usercontent.sandbox.ClaudeCompletionError#ADAPTER"
        oneofName = "error"
        schemaIndex = 0x3
        tag = 0x4
    .end annotation
.end field

.field private final file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "anthropic.claude.usercontent.sandbox.FileNotFoundError#ADAPTER"
        oneofName = "error"
        schemaIndex = 0x2
        tag = 0x3
    .end annotation
.end field

.field private final runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "anthropic.claude.usercontent.sandbox.RuntimeError#ADAPTER"
        oneofName = "error"
        schemaIndex = 0x1
        tag = 0x2
    .end annotation
.end field

.field private final unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "anthropic.claude.usercontent.sandbox.UnsupportedImportsError#ADAPTER"
        oneofName = "error"
        schemaIndex = 0x0
        tag = 0x1
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion;-><init>(Lry5;)V

    sput-object v0, Lanthropic/claude/usercontent/sandbox/SandboxError;->Companion:Lanthropic/claude/usercontent/sandbox/SandboxError$Companion;

    sget-object v0, Lcom/squareup/wire/FieldEncoding;->LENGTH_DELIMITED:Lcom/squareup/wire/FieldEncoding;

    const-class v1, Lanthropic/claude/usercontent/sandbox/SandboxError;

    sget-object v2, Loze;->a:Lpze;

    invoke-virtual {v2, v1}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v1

    sget-object v2, Lcom/squareup/wire/Syntax;->PROTO_3:Lcom/squareup/wire/Syntax;

    new-instance v3, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;

    invoke-direct {v3, v0, v1, v2}, Lanthropic/claude/usercontent/sandbox/SandboxError$Companion$ADAPTER$1;-><init>(Lcom/squareup/wire/FieldEncoding;Lky9;Lcom/squareup/wire/Syntax;)V

    sput-object v3, Lanthropic/claude/usercontent/sandbox/SandboxError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    return-void
.end method

.method public constructor <init>()V
    .registers 9

    .line 36
    const/16 v6, 0x1f

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v7}, Lanthropic/claude/usercontent/sandbox/SandboxError;-><init>(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;ILry5;)V

    return-void
.end method

.method public constructor <init>(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)V
    .registers 7

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lanthropic/claude/usercontent/sandbox/SandboxError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-direct {p0, v0, p5}, Lcom/squareup/wire/Message;-><init>(Lcom/squareup/wire/ProtoAdapter;Lokio/ByteString;)V

    iput-object p1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    iput-object p2, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;

    iput-object p3, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    iput-object p4, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    const/4 p0, 0x0

    new-array p0, p0, [Ljava/lang/Object;

    invoke-static {p1, p2, p3, p4, p0}, Lcom/squareup/wire/internal/Internal;->countNonNull(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result p0

    const/4 p1, 0x1

    if-gt p0, p1, :cond_1b

    return-void

    :cond_1b
    const-string p0, "At most one of unsupported_imports, runtime_error, file_not_found, claude_completion_error may be non-null"

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public synthetic constructor <init>(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;ILry5;)V
    .registers 9

    and-int/lit8 p7, p6, 0x1

    const/4 v0, 0x0

    if-eqz p7, :cond_6

    move-object p1, v0

    :cond_6
    and-int/lit8 p7, p6, 0x2

    if-eqz p7, :cond_b

    move-object p2, v0

    :cond_b
    and-int/lit8 p7, p6, 0x4

    if-eqz p7, :cond_10

    move-object p3, v0

    :cond_10
    and-int/lit8 p7, p6, 0x8

    if-eqz p7, :cond_15

    move-object p4, v0

    :cond_15
    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_1b

    .line 34
    sget-object p5, Lokio/ByteString;->H:Lokio/ByteString;

    .line 35
    :cond_1b
    invoke-direct/range {p0 .. p5}, Lanthropic/claude/usercontent/sandbox/SandboxError;-><init>(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)V

    return-void
.end method

.method public static synthetic copy$default(Lanthropic/claude/usercontent/sandbox/SandboxError;Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;ILjava/lang/Object;)Lanthropic/claude/usercontent/sandbox/SandboxError;
    .registers 8

    and-int/lit8 p7, p6, 0x1

    if-eqz p7, :cond_6

    iget-object p1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    :cond_6
    and-int/lit8 p7, p6, 0x2

    if-eqz p7, :cond_c

    iget-object p2, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;

    :cond_c
    and-int/lit8 p7, p6, 0x4

    if-eqz p7, :cond_12

    iget-object p3, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    :cond_12
    and-int/lit8 p7, p6, 0x8

    if-eqz p7, :cond_18

    iget-object p4, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    :cond_18
    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_20

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p5

    :cond_20
    move-object p6, p4

    move-object p7, p5

    move-object p4, p2

    move-object p5, p3

    move-object p2, p0

    move-object p3, p1

    invoke-virtual/range {p2 .. p7}, Lanthropic/claude/usercontent/sandbox/SandboxError;->copy(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)Lanthropic/claude/usercontent/sandbox/SandboxError;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final copy(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)Lanthropic/claude/usercontent/sandbox/SandboxError;
    .registers 6

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Lanthropic/claude/usercontent/sandbox/SandboxError;

    invoke-direct/range {p0 .. p5}, Lanthropic/claude/usercontent/sandbox/SandboxError;-><init>(Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;Lanthropic/claude/usercontent/sandbox/RuntimeError;Lanthropic/claude/usercontent/sandbox/FileNotFoundError;Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;Lokio/ByteString;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lanthropic/claude/usercontent/sandbox/SandboxError;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v1

    check-cast p1, Lanthropic/claude/usercontent/sandbox/SandboxError;

    invoke-virtual {p1}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v3

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b

    return v2

    :cond_1b
    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    iget-object v3, p1, Lanthropic/claude/usercontent/sandbox/SandboxError;->unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_26

    return v2

    :cond_26
    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;

    iget-object v3, p1, Lanthropic/claude/usercontent/sandbox/SandboxError;->runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_31

    return v2

    :cond_31
    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    iget-object v3, p1, Lanthropic/claude/usercontent/sandbox/SandboxError;->file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    return v2

    :cond_3c
    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    iget-object p1, p1, Lanthropic/claude/usercontent/sandbox/SandboxError;->claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_47

    return v2

    :cond_47
    return v0
.end method

.method public final getClaude_completion_error()Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;
    .registers 1

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    return-object p0
.end method

.method public final getFile_not_found()Lanthropic/claude/usercontent/sandbox/FileNotFoundError;
    .registers 1

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    return-object p0
.end method

.method public final getRuntime_error()Lanthropic/claude/usercontent/sandbox/RuntimeError;
    .registers 1

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;

    return-object p0
.end method

.method public final getUnsupported_imports()Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;
    .registers 1

    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    return-object p0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    if-nez v0, :cond_41

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lokio/ByteString;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x25

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    const/4 v2, 0x0

    if-eqz v1, :cond_18

    invoke-virtual {v1}, Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;->hashCode()I

    move-result v1

    goto :goto_19

    :cond_18
    move v1, v2

    :goto_19
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x25

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;

    if-eqz v1, :cond_25

    invoke-virtual {v1}, Lanthropic/claude/usercontent/sandbox/RuntimeError;->hashCode()I

    move-result v1

    goto :goto_26

    :cond_25
    move v1, v2

    :goto_26
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x25

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    if-eqz v1, :cond_32

    invoke-virtual {v1}, Lanthropic/claude/usercontent/sandbox/FileNotFoundError;->hashCode()I

    move-result v1

    goto :goto_33

    :cond_32
    move v1, v2

    :goto_33
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x25

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    if-eqz v1, :cond_3e

    invoke-virtual {v1}, Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;->hashCode()I

    move-result v2

    :cond_3e
    add-int/2addr v0, v2

    iput v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    :cond_41
    return v0
.end method

.method public bridge synthetic newBuilder()Lcom/squareup/wire/Message$Builder;
    .registers 1
    .annotation runtime Ln76;
    .end annotation

    .line 8
    invoke-virtual {p0}, Lanthropic/claude/usercontent/sandbox/SandboxError;->newBuilder()Ljava/lang/Void;

    move-result-object p0

    check-cast p0, Lcom/squareup/wire/Message$Builder;

    return-object p0
.end method

.method public synthetic newBuilder()Ljava/lang/Void;
    .registers 2
    .annotation runtime Ln76;
    .end annotation

    new-instance p0, Ljava/lang/AssertionError;

    const-string v0, "Builders are deprecated and only available in a javaInterop build; see https://square.github.io/wire/wire_compiler/#kotlin"

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p0
.end method

.method public toString()Ljava/lang/String;
    .registers 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->unsupported_imports:Lanthropic/claude/usercontent/sandbox/UnsupportedImportsError;

    if-eqz v1, :cond_1a

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "unsupported_imports="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1a
    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->runtime_error:Lanthropic/claude/usercontent/sandbox/RuntimeError;

    if-eqz v1, :cond_2f

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "runtime_error="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2f
    iget-object v1, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->file_not_found:Lanthropic/claude/usercontent/sandbox/FileNotFoundError;

    if-eqz v1, :cond_44

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "file_not_found="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_44
    iget-object p0, p0, Lanthropic/claude/usercontent/sandbox/SandboxError;->claude_completion_error:Lanthropic/claude/usercontent/sandbox/ClaudeCompletionError;

    if-eqz p0, :cond_59

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "claude_completion_error="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_59
    const/4 v4, 0x0

    const/16 v5, 0x38

    const-string v1, ", "

    const-string v2, "SandboxError{"

    const-string v3, "}"

    invoke-static/range {v0 .. v5}, Lsm4;->A0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/String;Ljava/lang/String;Lc98;I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
