.class public final synthetic Lawf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:Lt7c;

.field public final synthetic F:Lq98;

.field public final synthetic G:Lq98;

.field public final synthetic H:Lq98;

.field public final synthetic I:Lq98;

.field public final synthetic J:I

.field public final synthetic K:J

.field public final synthetic L:J

.field public final synthetic M:Lc3k;

.field public final synthetic N:Ljs4;

.field public final synthetic O:I

.field public final synthetic P:I


# direct methods
.method public synthetic constructor <init>(Lt7c;Lq98;Lq98;Lq98;Lq98;IJJLc3k;Ljs4;II)V
    .registers 15

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lawf;->E:Lt7c;

    iput-object p2, p0, Lawf;->F:Lq98;

    iput-object p3, p0, Lawf;->G:Lq98;

    iput-object p4, p0, Lawf;->H:Lq98;

    iput-object p5, p0, Lawf;->I:Lq98;

    iput p6, p0, Lawf;->J:I

    iput-wide p7, p0, Lawf;->K:J

    iput-wide p9, p0, Lawf;->L:J

    iput-object p11, p0, Lawf;->M:Lc3k;

    iput-object p12, p0, Lawf;->N:Ljs4;

    iput p13, p0, Lawf;->O:I

    iput p14, p0, Lawf;->P:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 19

    move-object/from16 v0, p0

    move-object/from16 v12, p1

    check-cast v12, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v1, v0, Lawf;->O:I

    or-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Lupl;->D(I)I

    move-result v13

    iget-object v1, v0, Lawf;->E:Lt7c;

    move-object v2, v1

    iget-object v1, v0, Lawf;->F:Lq98;

    move-object v3, v2

    iget-object v2, v0, Lawf;->G:Lq98;

    move-object v4, v3

    iget-object v3, v0, Lawf;->H:Lq98;

    move-object v5, v4

    iget-object v4, v0, Lawf;->I:Lq98;

    move-object v6, v5

    iget v5, v0, Lawf;->J:I

    move-object v8, v6

    iget-wide v6, v0, Lawf;->K:J

    move-object v10, v8

    iget-wide v8, v0, Lawf;->L:J

    move-object v11, v10

    iget-object v10, v0, Lawf;->M:Lc3k;

    move-object v14, v11

    iget-object v11, v0, Lawf;->N:Ljs4;

    iget v0, v0, Lawf;->P:I

    move-object v15, v14

    move v14, v0

    move-object v0, v15

    invoke-static/range {v0 .. v14}, Lp8;->j(Lt7c;Lq98;Lq98;Lq98;Lq98;IJJLc3k;Ljs4;Lzu4;II)V

    sget-object v0, Lz2j;->a:Lz2j;

    return-object v0
.end method
