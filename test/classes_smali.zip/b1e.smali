.class public final Lb1e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:Ljava/util/HashMap;


# instance fields
.field public final a:Z

.field public final b:Ljava/io/File;

.field public final c:Ljava/util/concurrent/locks/Lock;

.field public d:Ljava/nio/channels/FileChannel;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lb1e;->e:Ljava/util/HashMap;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/io/File;Z)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p3, p0, Lb1e;->a:Z

    if-eqz p2, :cond_13

    new-instance p3, Ljava/io/File;

    const-string v0, ".lck"

    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p3, p2, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    goto :goto_14

    :cond_13
    const/4 p3, 0x0

    :goto_14
    iput-object p3, p0, Lb1e;->b:Ljava/io/File;

    sget-object p2, Lb1e;->e:Ljava/util/HashMap;

    monitor-enter p2

    :try_start_19
    invoke-virtual {p2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    if-nez p3, :cond_2a

    new-instance p3, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {p3}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    invoke-virtual {p2, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2a

    :catchall_28
    move-exception p0

    goto :goto_30

    :cond_2a
    :goto_2a
    check-cast p3, Ljava/util/concurrent/locks/Lock;
    :try_end_2c
    .catchall {:try_start_19 .. :try_end_2c} :catchall_28

    monitor-exit p2

    iput-object p3, p0, Lb1e;->c:Ljava/util/concurrent/locks/Lock;

    return-void

    :goto_30
    monitor-exit p2

    throw p0
.end method


# virtual methods
.method public final a(Z)V
    .registers 3

    iget-object v0, p0, Lb1e;->c:Ljava/util/concurrent/locks/Lock;

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    if-eqz p1, :cond_38

    iget-object p1, p0, Lb1e;->b:Ljava/io/File;

    if-eqz p1, :cond_26

    :try_start_b
    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_17

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    goto :goto_17

    :catch_15
    move-exception p1

    goto :goto_2e

    :cond_17
    :goto_17
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object p1

    invoke-virtual {p1}, Ljava/nio/channels/FileChannel;->lock()Ljava/nio/channels/FileLock;

    iput-object p1, p0, Lb1e;->d:Ljava/nio/channels/FileChannel;

    return-void

    :cond_26
    new-instance p1, Ljava/io/IOException;

    const-string v0, "No lock directory was provided."

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_2e
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_2e} :catch_15

    :goto_2e
    const/4 v0, 0x0

    iput-object v0, p0, Lb1e;->d:Ljava/nio/channels/FileChannel;

    const-string p0, "SupportSQLiteLock"

    const-string v0, "Unable to grab file lock."

    invoke-static {p0, v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_38
    return-void
.end method

.method public final b()V
    .registers 2

    :try_start_0
    iget-object v0, p0, Lb1e;->d:Ljava/nio/channels/FileChannel;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_7} :catch_7

    :catch_7
    :cond_7
    iget-object p0, p0, Lb1e;->c:Ljava/util/concurrent/locks/Lock;

    invoke-interface {p0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    return-void
.end method
