.class public abstract La4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lmtf;


# virtual methods
.method public final describeContents()I
    .registers 1

    const/4 p0, 0x0

    return p0
.end method
