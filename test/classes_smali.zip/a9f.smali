.class public final La9f;
.super Lb2c;
.source "SourceFile"


# instance fields
.field public final synthetic c:I

.field public final d:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, La9f;->c:I

    const/16 v0, 0x9

    const/16 v1, 0xa

    invoke-direct {p0, v0, v1}, Lb2c;-><init>(II)V

    iput-object p1, p0, La9f;->d:Landroid/content/Context;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;II)V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, La9f;->c:I

    .line 13
    invoke-direct {p0, p2, p3}, Lb2c;-><init>(II)V

    .line 14
    iput-object p1, p0, La9f;->d:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final a(Ln88;)V
    .registers 11

    iget v0, p0, La9f;->c:I

    const-string v1, "reschedule_needed"

    const/4 v2, 0x0

    const-string v3, "androidx.work.util.preferences"

    iget-object v4, p0, La9f;->d:Landroid/content/Context;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    packed-switch v0, :pswitch_data_8a

    const-string p0, "CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))"

    invoke-virtual {p1, p0}, Ln88;->j(Ljava/lang/String;)V

    invoke-virtual {v4, v3, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    const-string v3, "last_cancel_all_time_ms"

    if-nez v0, :cond_26

    invoke-interface {p0, v3}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5e

    :cond_26
    const-wide/16 v5, 0x0

    invoke-interface {p0, v3, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    invoke-interface {p0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_34

    const-wide/16 v5, 0x1

    :cond_34
    invoke-virtual {p1}, Ln88;->b()V

    :try_start_37
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    filled-new-array {v3, v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Ln88;->k([Ljava/lang/Object;)V

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    filled-new-array {v1, v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Ln88;->k([Ljava/lang/Object;)V

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p1}, Ln88;->l()V
    :try_end_5b
    .catchall {:try_start_37 .. :try_end_5b} :catchall_62

    invoke-virtual {p1}, Ln88;->f()V

    :cond_5e
    invoke-static {v4, p1}, Lpnl;->i(Landroid/content/Context;Ln88;)V

    return-void

    :catchall_62
    move-exception p0

    invoke-virtual {p1}, Ln88;->f()V

    throw p0

    :pswitch_67  #0x0
    iget p0, p0, Lb2c;->b:I

    const/16 v0, 0xa

    const/4 v5, 0x1

    if-lt p0, v0, :cond_7a

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {v1, p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p1, p0}, Ln88;->k([Ljava/lang/Object;)V

    goto :goto_89

    :cond_7a
    invoke-virtual {v4, v3, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v1, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_89
    return-void

    :pswitch_data_8a
    .packed-switch 0x0
        :pswitch_67  #00000000
    .end packed-switch
.end method
