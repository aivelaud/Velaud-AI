.class public final synthetic Laq7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lfo8;


# direct methods
.method public synthetic constructor <init>(Lfo8;I)V
    .registers 3

    iput p2, p0, Laq7;->E:I

    iput-object p1, p0, Laq7;->F:Lfo8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 5

    iget v0, p0, Laq7;->E:I

    sget-object v1, Lhsg;->G:Lhsg;

    iget-object p0, p0, Laq7;->F:Lfo8;

    packed-switch v0, :pswitch_data_3c

    sget-object v0, Lcom/anthropic/claude/core/events/EventQueueLimitsConfig;->Companion:Lcom/anthropic/claude/core/events/d;

    invoke-virtual {v0}, Lcom/anthropic/claude/core/events/d;->serializer()Lkotlinx/serialization/KSerializer;

    move-result-object v0

    const-string v2, "claudeai_android_event_queue_limits"

    invoke-interface {p0, v2, v0, v1}, Lfo8;->l(Ljava/lang/String;Lkotlinx/serialization/KSerializer;Lhsg;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/anthropic/claude/core/events/EventQueueLimitsConfig;

    if-eqz p0, :cond_1e

    invoke-virtual {p0}, Lcom/anthropic/claude/core/events/EventQueueLimitsConfig;->getAuthenticated()Lcom/anthropic/claude/core/events/EventQueueLimitsConfig$QueueLimits;

    move-result-object p0

    goto :goto_1f

    :cond_1e
    const/4 p0, 0x0

    :goto_1f
    return-object p0

    :pswitch_20  #0x0
    invoke-interface {p0}, Lfo8;->b()Z

    move-result v0

    if-nez v0, :cond_29

    sget-object p0, Lord;->a:Lord;

    goto :goto_3b

    :cond_29
    new-instance v0, Lnrd;

    sget-object v2, Lcom/anthropic/claude/configs/GrowthBookExposureSampleRateConfig;->Companion:Lyn8;

    invoke-virtual {v2}, Lyn8;->serializer()Lkotlinx/serialization/KSerializer;

    move-result-object v2

    const-string v3, "growthbook_exposure_sample_rate"

    invoke-interface {p0, v3, v2, v1}, Lfo8;->l(Ljava/lang/String;Lkotlinx/serialization/KSerializer;Lhsg;)Ljava/lang/Object;

    move-result-object p0

    invoke-direct {v0, p0}, Lnrd;-><init>(Ljava/lang/Object;)V

    move-object p0, v0

    :goto_3b
    return-object p0

    :pswitch_data_3c
    .packed-switch 0x0
        :pswitch_20  #00000000
    .end packed-switch
.end method
