.class public final Lb39;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# static fields
.field public static final H:Ljava/util/logging/Logger;


# instance fields
.field public final E:Lokio/BufferedSource;

.field public final F:La39;

.field public final G:Lr19;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lq29;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sput-object v0, Lb39;->H:Ljava/util/logging/Logger;

    return-void
.end method

.method public constructor <init>(Lokio/RealBufferedSource;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb39;->E:Lokio/BufferedSource;

    new-instance v0, La39;

    invoke-direct {v0, p1}, La39;-><init>(Lokio/BufferedSource;)V

    iput-object v0, p0, Lb39;->F:La39;

    new-instance p1, Lr19;

    invoke-direct {p1, v0}, Lr19;-><init>(La39;)V

    iput-object p1, p0, Lb39;->G:Lr19;

    return-void
.end method


# virtual methods
.method public final b(ZLx29;)Z
    .registers 16

    const/4 v0, 0x0

    :try_start_1
    iget-object v1, p0, Lb39;->E:Lokio/BufferedSource;

    const-wide/16 v2, 0x9

    invoke-interface {v1, v2, v3}, Lokio/BufferedSource;->J0(J)V
    :try_end_8
    .catch Ljava/io/EOFException; {:try_start_1 .. :try_end_8} :catch_34e

    iget-object v1, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-static {v1}, Lkck;->m(Lokio/BufferedSource;)I

    move-result v1

    const/16 v2, 0x4000

    if-gt v1, v2, :cond_345

    iget-object v3, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v3}, Lokio/BufferedSource;->readByte()B

    move-result v3

    and-int/lit16 v3, v3, 0xff

    iget-object v4, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v4}, Lokio/BufferedSource;->readByte()B

    move-result v4

    and-int/lit16 v5, v4, 0xff

    iget-object v6, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v6}, Lokio/BufferedSource;->readInt()I

    move-result v6

    const v7, 0x7fffffff

    and-int/2addr v7, v6

    const/16 v8, 0x8

    const/4 v9, 0x1

    if-eq v3, v8, :cond_42

    sget-object v10, Lb39;->H:Ljava/util/logging/Logger;

    sget-object v11, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    invoke-virtual {v10, v11}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    move-result v11

    if-eqz v11, :cond_42

    invoke-static {v9, v7, v1, v3, v5}, Lq29;->b(ZIIII)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    :cond_42
    const/4 v10, 0x4

    if-eqz p1, :cond_52

    if-ne v3, v10, :cond_48

    goto :goto_52

    :cond_48
    const-string p0, "Expected a SETTINGS frame but was "

    invoke-static {v3}, Lq29;->a(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lio/sentry/i2;->f(Ljava/lang/String;Ljava/lang/Object;)V

    return v0

    :cond_52
    :goto_52
    const/4 p1, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    packed-switch v3, :pswitch_data_350

    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    int-to-long p1, v1

    invoke-interface {p0, p1, p2}, Lokio/BufferedSource;->skip(J)V

    return v9

    :pswitch_5f  #0x8
    const-string p1, "TYPE_WINDOW_UPDATE length !=4: "

    if-ne v1, v10, :cond_bc

    :try_start_63
    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {p0}, Lokio/BufferedSource;->readInt()I

    move-result p0
    :try_end_69
    .catch Ljava/lang/Exception; {:try_start_63 .. :try_end_69} :catch_b9

    const-wide/32 v2, 0x7fffffff

    int-to-long p0, p0

    and-long/2addr p0, v2

    const-wide/16 v2, 0x0

    cmp-long v0, p0, v2

    if-eqz v0, :cond_b1

    sget-object v2, Lb39;->H:Ljava/util/logging/Logger;

    sget-object v3, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    invoke-virtual {v2, v3}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    move-result v3

    if-eqz v3, :cond_85

    invoke-static {v7, v1, p0, p1, v9}, Lq29;->c(IIJZ)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    :cond_85
    iget-object p2, p2, Lx29;->G:Ljava/lang/Object;

    check-cast p2, Ly29;

    if-nez v7, :cond_9a

    monitor-enter p2

    :try_start_8c
    iget-wide v0, p2, Ly29;->Z:J

    add-long/2addr v0, p0

    iput-wide v0, p2, Ly29;->Z:J

    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V
    :try_end_94
    .catchall {:try_start_8c .. :try_end_94} :catchall_96

    monitor-exit p2

    return v9

    :catchall_96
    move-exception v0

    move-object p0, v0

    monitor-exit p2

    throw p0

    :cond_9a
    invoke-virtual {p2, v7}, Ly29;->d(I)Lf39;

    move-result-object p2

    if-eqz p2, :cond_301

    monitor-enter p2

    :try_start_a1
    iget-wide v1, p2, Lf39;->I:J

    add-long/2addr v1, p0

    iput-wide v1, p2, Lf39;->I:J

    if-lez v0, :cond_ab

    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V
    :try_end_ab
    .catchall {:try_start_a1 .. :try_end_ab} :catchall_ad

    :cond_ab
    monitor-exit p2

    return v9

    :catchall_ad
    move-exception v0

    move-object p0, v0

    monitor-exit p2

    throw p0

    :cond_b1
    :try_start_b1
    new-instance p0, Ljava/io/IOException;

    const-string p1, "windowSizeIncrement was 0"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :catch_b9
    move-exception v0

    move-object p0, v0

    goto :goto_ce

    :cond_bc
    new-instance p0, Ljava/io/IOException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_ce
    .catch Ljava/lang/Exception; {:try_start_b1 .. :try_end_ce} :catch_b9

    :goto_ce
    sget-object p1, Lb39;->H:Ljava/util/logging/Logger;

    invoke-static {v9, v7, v1, v8, v5}, Lq29;->b(ZIIII)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    throw p0

    :pswitch_d8  #0x7
    if-lt v1, v8, :cond_16f

    if-nez v7, :cond_169

    iget-object v2, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v2}, Lokio/BufferedSource;->readInt()I

    move-result v2

    iget-object v3, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v3}, Lokio/BufferedSource;->readInt()I

    move-result v3

    sub-int/2addr v1, v8

    sget-object v4, Lm17;->F:Loo8;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lm17;->values()[Lm17;

    move-result-object v4

    array-length v5, v4

    move v6, v0

    :goto_f4
    if-ge v6, v5, :cond_101

    aget-object v7, v4, v6

    iget v8, v7, Lm17;->E:I

    if-ne v8, v3, :cond_fe

    move-object p1, v7

    goto :goto_101

    :cond_fe
    add-int/lit8 v6, v6, 0x1

    goto :goto_f4

    :cond_101
    :goto_101
    if-eqz p1, :cond_15f

    sget-object p1, Lokio/ByteString;->H:Lokio/ByteString;

    if-lez v1, :cond_10e

    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    int-to-long v3, v1

    invoke-interface {p0, v3, v4}, Lokio/BufferedSource;->v(J)Lokio/ByteString;

    move-result-object p1

    :cond_10e
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lokio/ByteString;->e()I

    iget-object p0, p2, Lx29;->G:Ljava/lang/Object;

    check-cast p0, Ly29;

    monitor-enter p0

    :try_start_119
    iget-object p1, p0, Ly29;->F:Ljava/util/LinkedHashMap;

    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object p1

    new-array v1, v0, [Lf39;

    invoke-interface {p1, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    iput-boolean v9, p0, Ly29;->J:Z
    :try_end_127
    .catchall {:try_start_119 .. :try_end_127} :catchall_15b

    monitor-exit p0

    check-cast p1, [Lf39;

    array-length p0, p1

    :goto_12b
    if-ge v0, p0, :cond_301

    aget-object v1, p1, v0

    iget v3, v1, Lf39;->E:I

    if-le v3, v2, :cond_158

    invoke-virtual {v1}, Lf39;->h()Z

    move-result v3

    if-eqz v3, :cond_158

    sget-object v3, Lm17;->K:Lm17;

    monitor-enter v1

    :try_start_13c
    invoke-virtual {v1}, Lf39;->g()Lm17;

    move-result-object v4

    if-nez v4, :cond_14b

    iput-object v3, v1, Lf39;->P:Lm17;

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V
    :try_end_147
    .catchall {:try_start_13c .. :try_end_147} :catchall_148

    goto :goto_14b

    :catchall_148
    move-exception v0

    move-object p0, v0

    goto :goto_156

    :cond_14b
    :goto_14b
    monitor-exit v1

    iget-object v3, p2, Lx29;->G:Ljava/lang/Object;

    check-cast v3, Ly29;

    iget v1, v1, Lf39;->E:I

    invoke-virtual {v3, v1}, Ly29;->e(I)Lf39;

    goto :goto_158

    :goto_156
    monitor-exit v1

    throw p0

    :cond_158
    :goto_158
    add-int/lit8 v0, v0, 0x1

    goto :goto_12b

    :catchall_15b
    move-exception v0

    move-object p1, v0

    monitor-exit p0

    throw p1

    :cond_15f
    const-string p0, "TYPE_GOAWAY unexpected error code: "

    invoke-static {v3, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_169
    const-string p0, "TYPE_GOAWAY streamId != 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_16f
    const-string p0, "TYPE_GOAWAY length < 8: "

    invoke-static {v1, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :pswitch_179  #0x6
    if-ne v1, v8, :cond_1de

    if-nez v7, :cond_1d8

    iget-object p1, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {p1}, Lokio/BufferedSource;->readInt()I

    move-result p1

    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {p0}, Lokio/BufferedSource;->readInt()I

    move-result p0

    and-int/lit8 v1, v4, 0x1

    if-eqz v1, :cond_18e

    move v0, v9

    :cond_18e
    iget-object v1, p2, Lx29;->G:Ljava/lang/Object;

    check-cast v1, Ly29;

    if-eqz v0, :cond_1b5

    monitor-enter v1

    const-wide/16 v2, 0x1

    if-eq p1, v9, :cond_1ac

    if-eq p1, v12, :cond_1a6

    const/4 p0, 0x3

    if-eq p1, p0, :cond_19f

    goto :goto_1b1

    :cond_19f
    :try_start_19f
    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    goto :goto_1b1

    :catchall_1a3
    move-exception v0

    move-object p0, v0

    goto :goto_1b3

    :cond_1a6
    iget-wide p0, v1, Ly29;->S:J

    add-long/2addr p0, v2

    iput-wide p0, v1, Ly29;->S:J

    goto :goto_1b1

    :cond_1ac
    iget-wide p0, v1, Ly29;->Q:J

    add-long/2addr p0, v2

    iput-wide p0, v1, Ly29;->Q:J
    :try_end_1b1
    .catchall {:try_start_19f .. :try_end_1b1} :catchall_1a3

    :goto_1b1
    monitor-exit v1

    return v9

    :goto_1b3
    monitor-exit v1

    throw p0

    :cond_1b5
    iget-object v2, v1, Ly29;->L:Lg0i;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p2, Lx29;->G:Ljava/lang/Object;

    check-cast v1, Ly29;

    iget-object v1, v1, Ly29;->G:Ljava/lang/String;

    const-string v3, " ping"

    invoke-static {v0, v1, v3}, Lb40;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object p2, p2, Lx29;->G:Ljava/lang/Object;

    check-cast p2, Ly29;

    new-instance v6, Lyp6;

    invoke-direct {v6, p2, p1, p0, v9}, Lyp6;-><init>(Ljava/lang/Object;III)V

    const/4 v7, 0x6

    const-wide/16 v4, 0x0

    invoke-static/range {v2 .. v7}, Lg0i;->b(Lg0i;Ljava/lang/String;JLa98;I)V

    return v9

    :cond_1d8
    const-string p0, "TYPE_PING streamId != 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_1de
    const-string p0, "TYPE_PING length != 8: "

    invoke-static {v1, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :pswitch_1e8  #0x5
    invoke-virtual {p0, p2, v1, v5, v7}, Lb39;->j(Lx29;III)V

    return v9

    :pswitch_1ec  #0x4
    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    if-nez v7, :cond_28a

    and-int/lit8 p1, v4, 0x1

    if-eqz p1, :cond_1fe

    if-nez v1, :cond_1f8

    goto/16 :goto_301

    :cond_1f8
    const-string p0, "FRAME_SIZE_ERROR ack frame should be empty!"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_1fe
    rem-int/lit8 p1, v1, 0x6

    if-nez p1, :cond_280

    new-instance p1, Lrqg;

    invoke-direct {p1}, Lrqg;-><init>()V

    invoke-static {v0, v1}, Lylk;->f0(II)Ltj9;

    move-result-object v1

    const/4 v3, 0x6

    invoke-static {v1, v3}, Lylk;->b0(Ltj9;I)Lrj9;

    move-result-object v1

    iget v3, v1, Lrj9;->E:I

    iget v4, v1, Lrj9;->F:I

    iget v1, v1, Lrj9;->G:I

    if-lez v1, :cond_21a

    if-le v3, v4, :cond_21e

    :cond_21a
    if-gez v1, :cond_260

    if-gt v4, v3, :cond_260

    :cond_21e
    :goto_21e
    invoke-interface {p0}, Lokio/BufferedSource;->readShort()S

    move-result v5

    sget-object v6, Lkck;->a:[B

    const v6, 0xffff

    and-int/2addr v5, v6

    invoke-interface {p0}, Lokio/BufferedSource;->readInt()I

    move-result v6

    if-eq v5, v12, :cond_24e

    if-eq v5, v10, :cond_245

    if-eq v5, v11, :cond_233

    goto :goto_259

    :cond_233
    if-lt v6, v2, :cond_23b

    const v7, 0xffffff

    if-gt v6, v7, :cond_23b

    goto :goto_259

    :cond_23b
    const-string p0, "PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: "

    invoke-static {v6, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_245
    if-ltz v6, :cond_248

    goto :goto_259

    :cond_248
    const-string p0, "PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_24e
    if-eqz v6, :cond_259

    if-ne v6, v9, :cond_253

    goto :goto_259

    :cond_253
    const-string p0, "PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_259
    :goto_259
    invoke-virtual {p1, v5, v6}, Lrqg;->b(II)V

    if-eq v3, v4, :cond_260

    add-int/2addr v3, v1

    goto :goto_21e

    :cond_260
    iget-object p0, p2, Lx29;->G:Ljava/lang/Object;

    check-cast p0, Ly29;

    iget-object v0, p0, Ly29;->L:Lg0i;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p0, p0, Ly29;->G:Ljava/lang/String;

    const-string v2, " applyAndAckSettings"

    invoke-static {v1, p0, v2}, Lb40;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v4, Lhx3;

    const/4 p0, 0x7

    invoke-direct {v4, p2, p0, p1}, Lhx3;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    invoke-static/range {v0 .. v5}, Lg0i;->b(Lg0i;Ljava/lang/String;JLa98;I)V

    return v9

    :cond_280
    const-string p0, "TYPE_SETTINGS length % 6 != 0: "

    invoke-static {v1, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_28a
    const-string p0, "TYPE_SETTINGS streamId != 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :pswitch_290  #0x3
    if-ne v1, v10, :cond_312

    if-eqz v7, :cond_30c

    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {p0}, Lokio/BufferedSource;->readInt()I

    move-result p0

    sget-object v1, Lm17;->F:Loo8;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lm17;->values()[Lm17;

    move-result-object v1

    array-length v2, v1

    move v3, v0

    :goto_2a5
    if-ge v3, v2, :cond_2b2

    aget-object v4, v1, v3

    iget v5, v4, Lm17;->E:I

    if-ne v5, p0, :cond_2af

    move-object p1, v4

    goto :goto_2b2

    :cond_2af
    add-int/lit8 v3, v3, 0x1

    goto :goto_2a5

    :cond_2b2
    :goto_2b2
    if-eqz p1, :cond_302

    iget-object p0, p2, Lx29;->G:Ljava/lang/Object;

    check-cast p0, Ly29;

    if-eqz v7, :cond_2e7

    and-int/lit8 p2, v6, 0x1

    if-nez p2, :cond_2e7

    iget-object v0, p0, Ly29;->M:Lg0i;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Ly29;->G:Ljava/lang/String;

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x5b

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "] onReset"

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v4, Lt29;

    invoke-direct {v4, p0, v7, p1, v9}, Lt29;-><init>(Ly29;ILjava/lang/Object;I)V

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    invoke-static/range {v0 .. v5}, Lg0i;->b(Lg0i;Ljava/lang/String;JLa98;I)V

    return v9

    :cond_2e7
    invoke-virtual {p0, v7}, Ly29;->e(I)Lf39;

    move-result-object p0

    if-eqz p0, :cond_301

    monitor-enter p0

    :try_start_2ee
    invoke-virtual {p0}, Lf39;->g()Lm17;

    move-result-object p2

    if-nez p2, :cond_2fd

    iput-object p1, p0, Lf39;->P:Lm17;

    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_2f9
    .catchall {:try_start_2ee .. :try_end_2f9} :catchall_2fa

    goto :goto_2fd

    :catchall_2fa
    move-exception v0

    move-object p1, v0

    goto :goto_2ff

    :cond_2fd
    :goto_2fd
    monitor-exit p0

    return v9

    :goto_2ff
    monitor-exit p0

    throw p1

    :cond_301
    :goto_301
    return v9

    :cond_302
    const-string p1, "TYPE_RST_STREAM unexpected error code: "

    invoke-static {p0, p1}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_30c
    const-string p0, "TYPE_RST_STREAM streamId == 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_312
    const-string p0, "TYPE_RST_STREAM length: "

    const-string p1, " != 4"

    invoke-static {v1, p0, p1}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :pswitch_31e  #0x2
    if-ne v1, v11, :cond_331

    if-eqz v7, :cond_32b

    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {p0}, Lokio/BufferedSource;->readInt()I

    invoke-interface {p0}, Lokio/BufferedSource;->readByte()B

    return v9

    :cond_32b
    const-string p0, "TYPE_PRIORITY streamId == 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :cond_331
    const-string p0, "TYPE_PRIORITY length: "

    const-string p1, " != 5"

    invoke-static {v1, p0, p1}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return v0

    :pswitch_33d  #0x1
    invoke-virtual {p0, p2, v1, v5, v7}, Lb39;->f(Lx29;III)V

    return v9

    :pswitch_341  #0x0
    invoke-virtual {p0, p2, v1, v5, v7}, Lb39;->d(Lx29;III)V

    return v9

    :cond_345
    const-string p0, "FRAME_SIZE_ERROR: "

    invoke-static {v1, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    :catch_34e
    return v0

    nop

    :pswitch_data_350
    .packed-switch 0x0
        :pswitch_341  #00000000
        :pswitch_33d  #00000001
        :pswitch_31e  #00000002
        :pswitch_290  #00000003
        :pswitch_1ec  #00000004
        :pswitch_1e8  #00000005
        :pswitch_179  #00000006
        :pswitch_d8  #00000007
        :pswitch_5f  #00000008
    .end packed-switch
.end method

.method public final close()V
    .registers 1

    iget-object p0, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {p0}, Ljava/io/Closeable;->close()V

    return-void
.end method

.method public final d(Lx29;III)V
    .registers 23

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    move/from16 v3, p4

    if-eqz v3, :cond_133

    and-int/lit8 v4, v2, 0x1

    const/4 v6, 0x1

    if-eqz v4, :cond_11

    move v4, v6

    goto :goto_13

    :cond_11
    move v4, v6

    const/4 v6, 0x0

    :goto_13
    and-int/lit8 v7, v2, 0x20

    if-nez v7, :cond_12d

    and-int/lit8 v7, v2, 0x8

    if-eqz v7, :cond_28

    iget-object v7, v0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v7}, Lokio/BufferedSource;->readByte()B

    move-result v7

    sget-object v8, Lkck;->a:[B

    and-int/lit16 v7, v7, 0xff

    :goto_25
    move/from16 v8, p2

    goto :goto_2a

    :cond_28
    const/4 v7, 0x0

    goto :goto_25

    :goto_2a
    invoke-static {v8, v2, v7}, Lvi9;->X(III)I

    move-result v2

    iget-object v8, v0, Lb39;->E:Lokio/BufferedSource;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v9, v1, Lx29;->G:Ljava/lang/Object;

    check-cast v9, Ly29;

    if-eqz v3, :cond_3f

    and-int/lit8 v10, v3, 0x1

    if-nez v10, :cond_3f

    move v10, v4

    goto :goto_40

    :cond_3f
    const/4 v10, 0x0

    :goto_40
    if-eqz v10, :cond_7d

    new-instance v4, Lokio/Buffer;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    int-to-long v10, v2

    invoke-interface {v8, v10, v11}, Lokio/BufferedSource;->J0(J)V

    invoke-interface {v8, v4, v10, v11}, Lokio/Source;->B0(Lokio/Buffer;J)J

    iget-object v12, v9, Ly29;->M:Lg0i;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v9, Ly29;->G:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x5b

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "] onData"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    new-instance v16, Ls29;

    move v5, v2

    move-object v2, v9

    move-object/from16 v1, v16

    invoke-direct/range {v1 .. v6}, Ls29;-><init>(Ly29;ILokio/Buffer;IZ)V

    const/16 v17, 0x6

    const-wide/16 v14, 0x0

    invoke-static/range {v12 .. v17}, Lg0i;->b(Lg0i;Ljava/lang/String;JLa98;I)V

    goto/16 :goto_126

    :cond_7d
    invoke-virtual {v9, v3}, Ly29;->d(I)Lf39;

    move-result-object v9

    if-nez v9, :cond_99

    iget-object v4, v1, Lx29;->G:Ljava/lang/Object;

    check-cast v4, Ly29;

    sget-object v5, Lm17;->H:Lm17;

    invoke-virtual {v4, v3, v5}, Ly29;->l(ILm17;)V

    iget-object v1, v1, Lx29;->G:Ljava/lang/Object;

    check-cast v1, Ly29;

    int-to-long v2, v2

    invoke-virtual {v1, v2, v3}, Ly29;->j(J)V

    invoke-interface {v8, v2, v3}, Lokio/BufferedSource;->skip(J)V

    goto/16 :goto_126

    :cond_99
    sget-object v1, Lmck;->a:Ljava/util/TimeZone;

    iget-object v1, v9, Lf39;->L:Ld39;

    int-to-long v2, v2

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-wide v10, v2

    :goto_a2
    const-wide/16 v12, 0x0

    cmp-long v14, v10, v12

    iget-object v15, v1, Ld39;->K:Lf39;

    if-lez v14, :cond_10e

    monitor-enter v15

    :try_start_ab
    iget-boolean v14, v1, Ld39;->F:Z

    iget-object v5, v1, Ld39;->H:Lokio/Buffer;

    move-wide/from16 p1, v12

    iget-wide v12, v5, Lokio/Buffer;->F:J

    add-long/2addr v12, v10

    iget-wide v4, v1, Ld39;->E:J
    :try_end_b6
    .catchall {:try_start_ab .. :try_end_b6} :catchall_10b

    cmp-long v4, v12, v4

    if-lez v4, :cond_bc

    const/4 v4, 0x1

    goto :goto_bd

    :cond_bc
    const/4 v4, 0x0

    :goto_bd
    monitor-exit v15

    if-eqz v4, :cond_cb

    invoke-interface {v8, v10, v11}, Lokio/BufferedSource;->skip(J)V

    iget-object v1, v1, Ld39;->K:Lf39;

    sget-object v2, Lm17;->J:Lm17;

    invoke-virtual {v1, v2}, Lf39;->f(Lm17;)V

    goto :goto_11e

    :cond_cb
    if-eqz v14, :cond_d1

    invoke-interface {v8, v10, v11}, Lokio/BufferedSource;->skip(J)V

    goto :goto_11e

    :cond_d1
    iget-object v4, v1, Ld39;->G:Lokio/Buffer;

    invoke-interface {v8, v4, v10, v11}, Lokio/Source;->B0(Lokio/Buffer;J)J

    move-result-wide v4

    const-wide/16 v12, -0x1

    cmp-long v12, v4, v12

    if-eqz v12, :cond_107

    sub-long/2addr v10, v4

    iget-object v4, v1, Ld39;->K:Lf39;

    monitor-enter v4

    :try_start_e1
    iget-boolean v5, v1, Ld39;->J:Z

    if-eqz v5, :cond_ed

    iget-object v5, v1, Ld39;->G:Lokio/Buffer;

    invoke-virtual {v5}, Lokio/Buffer;->b()V

    goto :goto_102

    :catchall_eb
    move-exception v0

    goto :goto_105

    :cond_ed
    iget-object v5, v1, Ld39;->H:Lokio/Buffer;

    iget-wide v12, v5, Lokio/Buffer;->F:J

    cmp-long v12, v12, p1

    if-nez v12, :cond_f7

    const/4 v12, 0x1

    goto :goto_f8

    :cond_f7
    const/4 v12, 0x0

    :goto_f8
    iget-object v13, v1, Ld39;->G:Lokio/Buffer;

    invoke-virtual {v5, v13}, Lokio/Buffer;->f0(Lokio/Source;)J

    if-eqz v12, :cond_102

    invoke-virtual {v4}, Ljava/lang/Object;->notifyAll()V
    :try_end_102
    .catchall {:try_start_e1 .. :try_end_102} :catchall_eb

    :cond_102
    :goto_102
    monitor-exit v4

    const/4 v4, 0x1

    goto :goto_a2

    :goto_105
    monitor-exit v4

    throw v0

    :cond_107
    invoke-static {}, Le97;->q()V

    return-void

    :catchall_10b
    move-exception v0

    monitor-exit v15

    throw v0

    :cond_10e
    sget-object v4, Lmck;->a:Ljava/util/TimeZone;

    iget-object v4, v15, Lf39;->F:Ly29;

    invoke-virtual {v4, v2, v3}, Ly29;->j(J)V

    iget-object v1, v1, Ld39;->K:Lf39;

    iget-object v1, v1, Lf39;->F:Ly29;

    iget-object v1, v1, Ly29;->U:Lsz7;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_11e
    if-eqz v6, :cond_126

    sget-object v1, Lrs8;->F:Lrs8;

    const/4 v4, 0x1

    invoke-virtual {v9, v1, v4}, Lf39;->j(Lrs8;Z)V

    :cond_126
    :goto_126
    iget-object v0, v0, Lb39;->E:Lokio/BufferedSource;

    int-to-long v1, v7

    invoke-interface {v0, v1, v2}, Lokio/BufferedSource;->skip(J)V

    return-void

    :cond_12d
    const-string v0, "PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA"

    invoke-static {v0}, Lmf6;->d(Ljava/lang/String;)V

    return-void

    :cond_133
    const-string v0, "PROTOCOL_ERROR: TYPE_DATA streamId == 0"

    invoke-static {v0}, Lmf6;->d(Ljava/lang/String;)V

    return-void
.end method

.method public final e(IIII)Ljava/util/List;
    .registers 7

    iget-object v0, p0, Lb39;->F:La39;

    iput p1, v0, La39;->H:I

    iput p2, v0, La39;->I:I

    iput p3, v0, La39;->F:I

    iput p4, v0, La39;->G:I

    iget-object p0, p0, Lb39;->G:Lr19;

    iget-object p1, p0, Lr19;->d:Lokio/RealBufferedSource;

    :cond_e
    :goto_e
    invoke-virtual {p1}, Lokio/RealBufferedSource;->H()Z

    move-result p2

    if-nez p2, :cond_11e

    invoke-virtual {p1}, Lokio/RealBufferedSource;->readByte()B

    move-result p2

    sget-object p3, Lkck;->a:[B

    and-int/lit16 p3, p2, 0xff

    const/4 p4, 0x0

    const/16 v0, 0x80

    if-eq p3, v0, :cond_118

    and-int/lit16 v1, p2, 0x80

    if-ne v1, v0, :cond_5f

    const/16 p2, 0x7f

    invoke-virtual {p0, p3, p2}, Lr19;->f(II)I

    move-result p2

    add-int/lit8 p3, p2, -0x1

    if-ltz p3, :cond_3c

    sget-object v0, Lt19;->a:[Lns8;

    array-length v1, v0

    add-int/lit8 v1, v1, -0x1

    if-gt p3, v1, :cond_3c

    aget-object p2, v0, p3

    invoke-virtual {p0, p2}, Lr19;->a(Lns8;)V

    goto :goto_e

    :cond_3c
    sget-object v0, Lt19;->a:[Lns8;

    array-length v0, v0

    sub-int/2addr p3, v0

    iget v0, p0, Lr19;->f:I

    add-int/lit8 v0, v0, 0x1

    add-int/2addr v0, p3

    if-ltz v0, :cond_55

    iget-object p3, p0, Lr19;->e:[Lns8;

    array-length v1, p3

    if-ge v0, v1, :cond_55

    aget-object p2, p3, v0

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p2}, Lr19;->a(Lns8;)V

    goto :goto_e

    :cond_55
    const-string p0, "Header index too large "

    invoke-static {p2, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return-object p4

    :cond_5f
    const/16 v0, 0x40

    if-ne p3, v0, :cond_79

    sget-object p2, Lt19;->a:[Lns8;

    invoke-virtual {p0}, Lr19;->e()Lokio/ByteString;

    move-result-object p2

    invoke-static {p2}, Lt19;->a(Lokio/ByteString;)V

    invoke-virtual {p0}, Lr19;->e()Lokio/ByteString;

    move-result-object p3

    new-instance p4, Lns8;

    invoke-direct {p4, p2, p3}, Lns8;-><init>(Lokio/ByteString;Lokio/ByteString;)V

    invoke-virtual {p0, p4}, Lr19;->d(Lns8;)V

    goto :goto_e

    :cond_79
    and-int/lit8 v1, p2, 0x40

    if-ne v1, v0, :cond_97

    const/16 p2, 0x3f

    invoke-virtual {p0, p3, p2}, Lr19;->f(II)I

    move-result p2

    add-int/lit8 p2, p2, -0x1

    invoke-virtual {p0, p2}, Lr19;->c(I)Lokio/ByteString;

    move-result-object p2

    invoke-virtual {p0}, Lr19;->e()Lokio/ByteString;

    move-result-object p3

    new-instance p4, Lns8;

    invoke-direct {p4, p2, p3}, Lns8;-><init>(Lokio/ByteString;Lokio/ByteString;)V

    invoke-virtual {p0, p4}, Lr19;->d(Lns8;)V

    goto/16 :goto_e

    :cond_97
    and-int/lit8 p2, p2, 0x20

    const/16 v0, 0x20

    if-ne p2, v0, :cond_e0

    const/16 p2, 0x1f

    invoke-virtual {p0, p3, p2}, Lr19;->f(II)I

    move-result p2

    iput p2, p0, Lr19;->a:I

    if-ltz p2, :cond_ca

    const/16 p3, 0x1000

    if-gt p2, p3, :cond_ca

    iget p3, p0, Lr19;->h:I

    if-ge p2, p3, :cond_e

    if-nez p2, :cond_c4

    iget-object p2, p0, Lr19;->e:[Lns8;

    invoke-static {p2, p4}, Lmr0;->D0([Ljava/lang/Object;Lund;)V

    iget-object p2, p0, Lr19;->e:[Lns8;

    array-length p2, p2

    add-int/lit8 p2, p2, -0x1

    iput p2, p0, Lr19;->f:I

    const/4 p2, 0x0

    iput p2, p0, Lr19;->g:I

    iput p2, p0, Lr19;->h:I

    goto/16 :goto_e

    :cond_c4
    sub-int/2addr p3, p2

    invoke-virtual {p0, p3}, Lr19;->b(I)I

    goto/16 :goto_e

    :cond_ca
    new-instance p1, Ljava/io/IOException;

    iget p0, p0, Lr19;->a:I

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Invalid dynamic table size update "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e0
    const/16 p2, 0x10

    if-eq p3, p2, :cond_101

    if-nez p3, :cond_e7

    goto :goto_101

    :cond_e7
    const/16 p2, 0xf

    invoke-virtual {p0, p3, p2}, Lr19;->f(II)I

    move-result p2

    add-int/lit8 p2, p2, -0x1

    invoke-virtual {p0, p2}, Lr19;->c(I)Lokio/ByteString;

    move-result-object p2

    invoke-virtual {p0}, Lr19;->e()Lokio/ByteString;

    move-result-object p3

    new-instance p4, Lns8;

    invoke-direct {p4, p2, p3}, Lns8;-><init>(Lokio/ByteString;Lokio/ByteString;)V

    invoke-virtual {p0, p4}, Lr19;->a(Lns8;)V

    goto/16 :goto_e

    :cond_101
    :goto_101
    sget-object p2, Lt19;->a:[Lns8;

    invoke-virtual {p0}, Lr19;->e()Lokio/ByteString;

    move-result-object p2

    invoke-static {p2}, Lt19;->a(Lokio/ByteString;)V

    invoke-virtual {p0}, Lr19;->e()Lokio/ByteString;

    move-result-object p3

    new-instance p4, Lns8;

    invoke-direct {p4, p2, p3}, Lns8;-><init>(Lokio/ByteString;Lokio/ByteString;)V

    invoke-virtual {p0, p4}, Lr19;->a(Lns8;)V

    goto/16 :goto_e

    :cond_118
    const-string p0, "index == 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return-object p4

    :cond_11e
    iget-object p1, p0, Lr19;->b:Ljava/util/ArrayList;

    invoke-static {p1}, Lsm4;->Z0(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p2

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    const-wide/16 p3, 0x0

    iput-wide p3, p0, Lr19;->c:J

    return-object p2
.end method

.method public final f(Lx29;III)V
    .registers 18

    move/from16 v0, p3

    move/from16 v1, p4

    if-eqz v1, :cond_e2

    and-int/lit8 v2, v0, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_e

    move v2, v4

    goto :goto_10

    :cond_e
    move v2, v4

    move v4, v3

    :goto_10
    and-int/lit8 v5, v0, 0x8

    if-eqz v5, :cond_1f

    iget-object v5, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v5}, Lokio/BufferedSource;->readByte()B

    move-result v5

    sget-object v6, Lkck;->a:[B

    and-int/lit16 v5, v5, 0xff

    goto :goto_20

    :cond_1f
    move v5, v3

    :goto_20
    and-int/lit8 v6, v0, 0x20

    if-eqz v6, :cond_31

    iget-object v6, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v6}, Lokio/BufferedSource;->readInt()I

    invoke-interface {v6}, Lokio/BufferedSource;->readByte()B

    sget-object v6, Lkck;->a:[B

    add-int/lit8 v6, p2, -0x5

    goto :goto_32

    :cond_31
    move v6, p2

    :goto_32
    invoke-static {v6, v0, v5}, Lvi9;->X(III)I

    move-result v6

    invoke-virtual {p0, v6, v5, v0, v1}, Lb39;->e(IIII)Ljava/util/List;

    move-result-object p0

    iget-object p1, p1, Lx29;->G:Ljava/lang/Object;

    check-cast p1, Ly29;

    if-eqz v1, :cond_45

    and-int/lit8 v0, v1, 0x1

    if-nez v0, :cond_45

    move v3, v2

    :cond_45
    const/16 v6, 0x5b

    if-eqz v3, :cond_70

    iget-object v7, p1, Ly29;->M:Lg0i;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p1, Ly29;->G:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] onHeaders"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    new-instance v11, Lt29;

    invoke-direct {v11, p1, v1, p0, v4}, Lt29;-><init>(Ly29;ILjava/util/List;Z)V

    const/4 v12, 0x6

    const-wide/16 v9, 0x0

    invoke-static/range {v7 .. v12}, Lg0i;->b(Lg0i;Ljava/lang/String;JLa98;I)V

    return-void

    :cond_70
    monitor-enter p1

    :try_start_71
    invoke-virtual {p1, v1}, Ly29;->d(I)Lf39;

    move-result-object v0

    if-nez v0, :cond_d6

    iget-boolean v0, p1, Ly29;->J:Z
    :try_end_79
    .catchall {:try_start_71 .. :try_end_79} :catchall_d3

    if-eqz v0, :cond_7d

    monitor-exit p1

    return-void

    :cond_7d
    :try_start_7d
    iget v0, p1, Ly29;->H:I
    :try_end_7f
    .catchall {:try_start_7d .. :try_end_7f} :catchall_d3

    if-gt v1, v0, :cond_83

    monitor-exit p1

    return-void

    :cond_83
    :try_start_83
    rem-int/lit8 v0, v1, 0x2

    iget v2, p1, Ly29;->I:I

    rem-int/lit8 v2, v2, 0x2
    :try_end_89
    .catchall {:try_start_83 .. :try_end_89} :catchall_d3

    if-ne v0, v2, :cond_8d

    monitor-exit p1

    return-void

    :cond_8d
    :try_start_8d
    invoke-static {p0}, Lmck;->i(Ljava/util/List;)Lrs8;

    move-result-object v5

    new-instance v0, Lf39;
    :try_end_93
    .catchall {:try_start_8d .. :try_end_93} :catchall_d3

    const/4 v3, 0x0

    move-object v2, p1

    :try_start_95
    invoke-direct/range {v0 .. v5}, Lf39;-><init>(ILy29;ZZLrs8;)V

    iput v1, v2, Ly29;->H:I

    iget-object p0, v2, Ly29;->F:Ljava/util/LinkedHashMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p0, v2, Ly29;->K:Lh0i;

    invoke-virtual {p0}, Lh0i;->d()Lg0i;

    move-result-object v7

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p1, v2, Ly29;->G:Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "] onStream"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    new-instance v11, Lhx3;

    const/4 p0, 0x6

    invoke-direct {v11, v2, p0, v0}, Lhx3;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    const/4 v12, 0x6

    const-wide/16 v9, 0x0

    invoke-static/range {v7 .. v12}, Lg0i;->b(Lg0i;Ljava/lang/String;JLa98;I)V
    :try_end_ce
    .catchall {:try_start_95 .. :try_end_ce} :catchall_d0

    monitor-exit v2

    return-void

    :catchall_d0
    move-exception v0

    :goto_d1
    move-object p0, v0

    goto :goto_e0

    :catchall_d3
    move-exception v0

    move-object v2, p1

    goto :goto_d1

    :cond_d6
    move-object v2, p1

    monitor-exit v2

    invoke-static {p0}, Lmck;->i(Ljava/util/List;)Lrs8;

    move-result-object p0

    invoke-virtual {v0, p0, v4}, Lf39;->j(Lrs8;Z)V

    return-void

    :goto_e0
    monitor-exit v2

    throw p0

    :cond_e2
    const-string p0, "PROTOCOL_ERROR: TYPE_HEADERS streamId == 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return-void
.end method

.method public final j(Lx29;III)V
    .registers 14

    if-eqz p4, :cond_77

    and-int/lit8 v0, p3, 0x8

    const/4 v1, 0x0

    if-eqz v0, :cond_12

    iget-object v0, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v0}, Lokio/BufferedSource;->readByte()B

    move-result v0

    sget-object v2, Lkck;->a:[B

    and-int/lit16 v0, v0, 0xff

    goto :goto_13

    :cond_12
    move v0, v1

    :goto_13
    iget-object v2, p0, Lb39;->E:Lokio/BufferedSource;

    invoke-interface {v2}, Lokio/BufferedSource;->readInt()I

    move-result v2

    const v3, 0x7fffffff

    and-int/2addr v2, v3

    add-int/lit8 p2, p2, -0x4

    invoke-static {p2, p3, v0}, Lvi9;->X(III)I

    move-result p2

    invoke-virtual {p0, p2, v0, p3, p4}, Lb39;->e(IIII)Ljava/util/List;

    move-result-object p0

    iget-object p1, p1, Lx29;->G:Ljava/lang/Object;

    check-cast p1, Ly29;

    monitor-enter p1

    :try_start_2c
    iget-object p2, p1, Ly29;->d0:Ljava/util/LinkedHashSet;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-interface {p2, p3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_42

    sget-object p0, Lm17;->H:Lm17;

    invoke-virtual {p1, v2, p0}, Ly29;->l(ILm17;)V
    :try_end_3d
    .catchall {:try_start_2c .. :try_end_3d} :catchall_3f

    monitor-exit p1

    return-void

    :catchall_3f
    move-exception v0

    move-object p0, v0

    goto :goto_75

    :cond_42
    :try_start_42
    iget-object p2, p1, Ly29;->d0:Ljava/util/LinkedHashSet;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-interface {p2, p3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_4b
    .catchall {:try_start_42 .. :try_end_4b} :catchall_3f

    monitor-exit p1

    iget-object v3, p1, Ly29;->M:Lg0i;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p3, p1, Ly29;->G:Ljava/lang/String;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p3, 0x5b

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, "] onRequest"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v7, Lt29;

    invoke-direct {v7, p1, v2, p0, v1}, Lt29;-><init>(Ly29;ILjava/lang/Object;I)V

    const/4 v8, 0x6

    const-wide/16 v5, 0x0

    invoke-static/range {v3 .. v8}, Lg0i;->b(Lg0i;Ljava/lang/String;JLa98;I)V

    return-void

    :goto_75
    monitor-exit p1

    throw p0

    :cond_77
    const-string p0, "PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0"

    invoke-static {p0}, Lmf6;->d(Ljava/lang/String;)V

    return-void
.end method
