.class public Lanl;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;
.implements Ljava/lang/Iterable;


# static fields
.field public static final G:Lanl;

.field public static final H:Lblf;


# instance fields
.field public E:I

.field public final F:[B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lanl;

    sget-object v1, Leql;->b:[B

    invoke-direct {v0, v1}, Lanl;-><init>([B)V

    sput-object v0, Lanl;->G:Lanl;

    new-instance v0, Lblf;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lblf;-><init>(I)V

    sput-object v0, Lanl;->H:Lblf;

    return-void
.end method

.method public constructor <init>([B)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lanl;->E:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lanl;->F:[B

    return-void
.end method

.method public static b(III)I
    .registers 6

    sub-int v0, p1, p0

    or-int v1, p0, p1

    or-int/2addr v1, v0

    sub-int v2, p2, p1

    or-int/2addr v1, v2

    if-gez v1, :cond_33

    if-ltz p0, :cond_27

    if-ge p1, p0, :cond_1b

    const-string p2, "Beginning index larger than ending index: "

    const-string v0, ", "

    invoke-static {p0, p1, p2, v0}, Lwsg;->p(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->j(Ljava/lang/String;)V

    :goto_19
    const/4 p0, 0x0

    return p0

    :cond_1b
    const-string p0, "End index: "

    const-string v0, " >= "

    invoke-static {p1, p2, p0, v0}, Lwsg;->p(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->j(Ljava/lang/String;)V

    goto :goto_19

    :cond_27
    const-string p1, "Beginning index: "

    const-string p2, " < 0"

    invoke-static {p0, p1, p2}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->j(Ljava/lang/String;)V

    goto :goto_19

    :cond_33
    return v0
.end method

.method public static c([BII)Lanl;
    .registers 6

    add-int v0, p1, p2

    array-length v1, p0

    invoke-static {p1, v0, v1}, Lanl;->b(III)I

    new-instance v0, Lanl;

    sget-object v1, Lanl;->H:Lblf;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-array v1, p2, [B

    const/4 v2, 0x0

    invoke-static {p0, p1, v1, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-direct {v0, v1}, Lanl;-><init>([B)V

    return-object v0
.end method


# virtual methods
.method public a(I)B
    .registers 2

    iget-object p0, p0, Lanl;->F:[B

    aget-byte p0, p0, p1

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 8

    if-ne p1, p0, :cond_3

    goto :goto_5e

    :cond_3
    instance-of v0, p1, Lanl;

    const/4 v1, 0x0

    if-nez v0, :cond_9

    goto :goto_58

    :cond_9
    invoke-virtual {p0}, Lanl;->h()I

    move-result v0

    move-object v2, p1

    check-cast v2, Lanl;

    invoke-virtual {v2}, Lanl;->h()I

    move-result v2

    if-eq v0, v2, :cond_17

    goto :goto_58

    :cond_17
    invoke-virtual {p0}, Lanl;->h()I

    move-result v0

    if-nez v0, :cond_1e

    goto :goto_5e

    :cond_1e
    instance-of v0, p1, Lanl;

    if-eqz v0, :cond_78

    check-cast p1, Lanl;

    iget v0, p0, Lanl;->E:I

    iget v2, p1, Lanl;->E:I

    if-eqz v0, :cond_2f

    if-eqz v2, :cond_2f

    if-eq v0, v2, :cond_2f

    goto :goto_58

    :cond_2f
    invoke-virtual {p0}, Lanl;->h()I

    move-result v0

    invoke-virtual {p1}, Lanl;->h()I

    move-result v2

    if-gt v0, v2, :cond_70

    invoke-virtual {p1}, Lanl;->h()I

    move-result v2

    if-gt v0, v2, :cond_60

    iget-object v2, p1, Lanl;->F:[B

    invoke-virtual {p0}, Lanl;->i()I

    move-result v3

    add-int/2addr v3, v0

    invoke-virtual {p0}, Lanl;->i()I

    move-result v0

    invoke-virtual {p1}, Lanl;->i()I

    move-result p1

    :goto_4e
    if-ge v0, v3, :cond_5e

    iget-object v4, p0, Lanl;->F:[B

    aget-byte v4, v4, v0

    aget-byte v5, v2, p1

    if-eq v4, v5, :cond_59

    :goto_58
    return v1

    :cond_59
    add-int/lit8 v0, v0, 0x1

    add-int/lit8 p1, p1, 0x1

    goto :goto_4e

    :cond_5e
    :goto_5e
    const/4 p0, 0x1

    return p0

    :cond_60
    invoke-virtual {p1}, Lanl;->h()I

    move-result p0

    const-string p1, "Ran off end of other: 0, "

    const-string v2, ", "

    invoke-static {v0, p0, p1, v2}, Lwsg;->p(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    return v1

    :cond_70
    invoke-virtual {p0}, Lanl;->h()I

    move-result p0

    invoke-static {v0, p0}, Lm1f;->p(II)V

    return v1

    :cond_78
    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public g(I)B
    .registers 2

    iget-object p0, p0, Lanl;->F:[B

    aget-byte p0, p0, p1

    return p0
.end method

.method public h()I
    .registers 1

    iget-object p0, p0, Lanl;->F:[B

    array-length p0, p0

    return p0
.end method

.method public final hashCode()I
    .registers 6

    iget v0, p0, Lanl;->E:I

    if-nez v0, :cond_22

    invoke-virtual {p0}, Lanl;->h()I

    move-result v0

    invoke-virtual {p0}, Lanl;->i()I

    move-result v1

    move v3, v0

    move v2, v1

    :goto_e
    add-int v4, v1, v0

    if-ge v2, v4, :cond_1c

    mul-int/lit8 v3, v3, 0x1f

    iget-object v4, p0, Lanl;->F:[B

    aget-byte v4, v4, v2

    add-int/2addr v3, v4

    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    :cond_1c
    if-nez v3, :cond_1f

    const/4 v3, 0x1

    :cond_1f
    iput v3, p0, Lanl;->E:I

    return v3

    :cond_22
    return v0
.end method

.method public i()I
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final synthetic iterator()Ljava/util/Iterator;
    .registers 2

    new-instance v0, Ly82;

    invoke-direct {v0, p0}, Ly82;-><init>(Lanl;)V

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lanl;->h()I

    move-result v1

    invoke-virtual {p0}, Lanl;->h()I

    move-result v2

    const/16 v3, 0x32

    if-gt v2, v3, :cond_1b

    invoke-static {p0}, Lclk;->k(Lanl;)Ljava/lang/String;

    move-result-object p0

    goto :goto_41

    :cond_1b
    const/4 v2, 0x0

    invoke-virtual {p0}, Lanl;->h()I

    move-result v3

    const/16 v4, 0x2f

    invoke-static {v2, v4, v3}, Lanl;->b(III)I

    move-result v2

    if-nez v2, :cond_2b

    sget-object p0, Lanl;->G:Lanl;

    goto :goto_37

    :cond_2b
    new-instance v3, Leml;

    iget-object v4, p0, Lanl;->F:[B

    invoke-virtual {p0}, Lanl;->i()I

    move-result p0

    invoke-direct {v3, v4, p0, v2}, Leml;-><init>([BII)V

    move-object p0, v3

    :goto_37
    invoke-static {p0}, Lclk;->k(Lanl;)Ljava/lang/String;

    move-result-object p0

    const-string v2, "..."

    invoke-virtual {p0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_41
    const-string v2, " size="

    const-string v3, " contents=\""

    const-string v4, "<ByteString@"

    invoke-static {v4, v0, v1, v2, v3}, Lb40;->s(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\">"

    invoke-static {v0, p0, v1}, Lb40;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
