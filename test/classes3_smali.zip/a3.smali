.class public final La3;
.super Ljava/io/FilterInputStream;
.source "SourceFile"


# instance fields
.field public E:I


# direct methods
.method public constructor <init>(ILjava/io/FileInputStream;)V
    .registers 3

    invoke-direct {p0, p2}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    iput p1, p0, La3;->E:I

    return-void
.end method


# virtual methods
.method public final available()I
    .registers 2

    invoke-super {p0}, Ljava/io/FilterInputStream;->available()I

    move-result v0

    iget p0, p0, La3;->E:I

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    return p0
.end method

.method public final read()I
    .registers 3

    .line 22
    iget v0, p0, La3;->E:I

    if-gtz v0, :cond_6

    const/4 p0, -0x1

    return p0

    .line 23
    :cond_6
    invoke-super {p0}, Ljava/io/FilterInputStream;->read()I

    move-result v0

    if-ltz v0, :cond_12

    .line 24
    iget v1, p0, La3;->E:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, La3;->E:I

    :cond_12
    return v0
.end method

.method public final read([BII)I
    .registers 5

    iget v0, p0, La3;->E:I

    if-gtz v0, :cond_6

    const/4 p0, -0x1

    return p0

    :cond_6
    invoke-static {p3, v0}, Ljava/lang/Math;->min(II)I

    move-result p3

    invoke-super {p0, p1, p2, p3}, Ljava/io/FilterInputStream;->read([BII)I

    move-result p1

    if-ltz p1, :cond_15

    iget p2, p0, La3;->E:I

    sub-int/2addr p2, p1

    iput p2, p0, La3;->E:I

    :cond_15
    return p1
.end method

.method public final skip(J)J
    .registers 5

    iget v0, p0, La3;->E:I

    int-to-long v0, v0

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p1

    invoke-super {p0, p1, p2}, Ljava/io/FilterInputStream;->skip(J)J

    move-result-wide p1

    long-to-int p1, p1

    if-ltz p1, :cond_13

    iget p2, p0, La3;->E:I

    sub-int/2addr p2, p1

    iput p2, p0, La3;->E:I

    :cond_13
    int-to-long p0, p1

    return-wide p0
.end method
