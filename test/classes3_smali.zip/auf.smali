.class public final Lauf;
.super Lduf;
.source "SourceFile"


# virtual methods
.method public final a(Lmn5;)Z
    .registers 2

    const/4 p0, 0x1

    return p0
.end method
