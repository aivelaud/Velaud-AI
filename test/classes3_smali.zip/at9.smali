.class public final Lat9;
.super Lct9;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lct9;

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lct9;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lat9;->a:Lct9;

    iput-object p2, p0, Lat9;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final fromJson(Lxu9;)Ljava/lang/Object;
    .registers 2

    iget-object p0, p0, Lat9;->a:Lct9;

    invoke-virtual {p0, p1}, Lct9;->fromJson(Lxu9;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final isLenient()Z
    .registers 1

    iget-object p0, p0, Lat9;->a:Lct9;

    invoke-virtual {p0}, Lct9;->isLenient()Z

    move-result p0

    return p0
.end method

.method public final toJson(Lew9;Ljava/lang/Object;)V
    .registers 5

    iget-object v0, p1, Lew9;->I:Ljava/lang/String;

    if-eqz v0, :cond_5

    goto :goto_7

    :cond_5
    const-string v0, ""

    :goto_7
    iget-object v1, p0, Lat9;->b:Ljava/lang/String;

    invoke-virtual {p1, v1}, Lew9;->S(Ljava/lang/String;)V

    :try_start_c
    iget-object p0, p0, Lat9;->a:Lct9;

    invoke-virtual {p0, p1, p2}, Lct9;->toJson(Lew9;Ljava/lang/Object;)V
    :try_end_11
    .catchall {:try_start_c .. :try_end_11} :catchall_15

    invoke-virtual {p1, v0}, Lew9;->S(Ljava/lang/String;)V

    return-void

    :catchall_15
    move-exception p0

    invoke-virtual {p1, v0}, Lew9;->S(Ljava/lang/String;)V

    throw p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lat9;->a:Lct9;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ".indent(\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lat9;->b:Ljava/lang/String;

    const-string v1, "\")"

    invoke-static {v0, p0, v1}, Lb40;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
