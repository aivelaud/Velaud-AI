.class public abstract Labl;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljs4;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lbt4;

    const/16 v1, 0x12

    invoke-direct {v0, v1}, Lbt4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x38834549

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Labl;->a:Ljs4;

    return-void
.end method

.method public static final a(Ljava/util/concurrent/Executor;Ljava/lang/String;La98;)Lug2;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Le16;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p0, p1, p2}, Le16;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v0}, Lrck;->z(Lsg2;)Lug2;

    move-result-object p0

    return-object p0
.end method

.method public static b(Lmu9;)Lqa;
    .registers 10

    const-string v1, "Unable to parse json into type DdActionTarget"

    const/4 v2, 0x0

    :try_start_3
    const-string v0, "selector"

    invoke-virtual {p0, v0}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object v0

    if-eqz v0, :cond_1a

    invoke-virtual {v0}, Lwt9;->m()Ljava/lang/String;

    move-result-object v0

    move-object v4, v0

    goto :goto_1b

    :catch_11
    move-exception v0

    move-object p0, v0

    goto :goto_65

    :catch_14
    move-exception v0

    move-object p0, v0

    goto :goto_69

    :catch_17
    move-exception v0

    move-object p0, v0

    goto :goto_6d

    :cond_1a
    move-object v4, v2

    :goto_1b
    const-string v0, "composed_path_selector"

    invoke-virtual {p0, v0}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object v0

    if-eqz v0, :cond_29

    invoke-virtual {v0}, Lwt9;->m()Ljava/lang/String;

    move-result-object v0

    move-object v5, v0

    goto :goto_2a

    :cond_29
    move-object v5, v2

    :goto_2a
    const-string v0, "width"

    invoke-virtual {p0, v0}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object v0

    if-eqz v0, :cond_3c

    invoke-virtual {v0}, Lwt9;->i()J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    move-object v6, v0

    goto :goto_3d

    :cond_3c
    move-object v6, v2

    :goto_3d
    const-string v0, "height"

    invoke-virtual {p0, v0}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object v0

    if-eqz v0, :cond_4f

    invoke-virtual {v0}, Lwt9;->i()J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    move-object v7, v0

    goto :goto_50

    :cond_4f
    move-object v7, v2

    :goto_50
    const-string v0, "permanent_id"

    invoke-virtual {p0, v0}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object p0

    if-eqz p0, :cond_5e

    invoke-virtual {p0}, Lwt9;->m()Ljava/lang/String;

    move-result-object p0

    move-object v8, p0

    goto :goto_5f

    :cond_5e
    move-object v8, v2

    :goto_5f
    new-instance v3, Lqa;

    invoke-direct/range {v3 .. v8}, Lqa;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;)V
    :try_end_64
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_64} :catch_17
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_64} :catch_14
    .catch Ljava/lang/NullPointerException; {:try_start_3 .. :try_end_64} :catch_11

    return-object v3

    :goto_65
    invoke-static {v1, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v2

    :goto_69
    invoke-static {v1, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v2

    :goto_6d
    invoke-static {v1, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v2
.end method

.method public static c(Lmu9;)Ls27;
    .registers 12

    const-string v0, "Unable to parse json into type Profiling"

    const/4 v1, 0x0

    :try_start_3
    const-string v2, "status"

    invoke-virtual {p0, v2}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object v2
    :try_end_9
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_9} :catch_37
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_9} :catch_35
    .catch Ljava/lang/NullPointerException; {:try_start_3 .. :try_end_9} :catch_33

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v5, "Array contains no element matching the predicate."

    if-eqz v2, :cond_39

    :try_start_f
    invoke-virtual {v2}, Lwt9;->m()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_39

    invoke-static {v3}, Ld07;->H(I)[I

    move-result-object v6

    array-length v7, v6

    move v8, v4

    :goto_1b
    if-ge v8, v7, :cond_2d

    aget v9, v6, v8

    invoke-static {v9}, Lb27;->g(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2a

    goto :goto_3a

    :cond_2a
    add-int/lit8 v8, v8, 0x1

    goto :goto_1b

    :cond_2d
    new-instance p0, Ljava/util/NoSuchElementException;

    invoke-direct {p0, v5}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw p0

    :catch_33
    move-exception p0

    goto :goto_6c

    :catch_35
    move-exception p0

    goto :goto_70

    :catch_37
    move-exception p0

    goto :goto_74

    :cond_39
    move v9, v4

    :goto_3a
    const-string v2, "error_reason"

    invoke-virtual {p0, v2}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object p0

    if-eqz p0, :cond_66

    invoke-virtual {p0}, Lwt9;->m()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_66

    invoke-static {v3}, Ld07;->H(I)[I

    move-result-object v2

    array-length v3, v2

    :goto_4d
    if-ge v4, v3, :cond_60

    aget v6, v2, v4

    invoke-static {v6}, Lb27;->o(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_5d

    move v4, v6

    goto :goto_66

    :cond_5d
    add-int/lit8 v4, v4, 0x1

    goto :goto_4d

    :cond_60
    new-instance p0, Ljava/util/NoSuchElementException;

    invoke-direct {p0, v5}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_66
    :goto_66
    new-instance p0, Ls27;

    invoke-direct {p0, v9, v4}, Ls27;-><init>(II)V
    :try_end_6b
    .catch Ljava/lang/IllegalStateException; {:try_start_f .. :try_end_6b} :catch_37
    .catch Ljava/lang/NumberFormatException; {:try_start_f .. :try_end_6b} :catch_35
    .catch Ljava/lang/NullPointerException; {:try_start_f .. :try_end_6b} :catch_33

    return-object p0

    :goto_6c
    invoke-static {v0, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1

    :goto_70
    invoke-static {v0, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1

    :goto_74
    invoke-static {v0, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1
.end method

.method public static d(Landroid/content/Context;)Lwzg;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lwzg;->c:Lwzg;

    if-nez v0, :cond_58

    sget-object v0, Lwzg;->d:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    :try_start_c
    sget-object v1, Lwzg;->c:Lwzg;
    :try_end_e
    .catchall {:try_start_c .. :try_end_e} :catchall_4e

    if-nez v1, :cond_50

    const/4 v1, 0x0

    :try_start_11
    invoke-static {}, Ltzg;->b()Liij;

    move-result-object v2

    if-nez v2, :cond_18

    goto :goto_46

    :cond_18
    sget-object v3, Liij;->J:Liij;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v2, Liij;->I:Lxvh;

    invoke-virtual {v2}, Lxvh;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Ljava/math/BigInteger;

    iget-object v3, v3, Liij;->I:Lxvh;

    invoke-virtual {v3}, Lxvh;->getValue()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v3, Ljava/math/BigInteger;

    invoke-virtual {v2, v3}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v2

    if-ltz v2, :cond_46

    new-instance v2, Luzg;

    invoke-direct {v2, p0}, Luzg;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Luzg;->e()Z

    move-result p0
    :try_end_42
    .catchall {:try_start_11 .. :try_end_42} :catchall_46

    if-nez p0, :cond_45

    goto :goto_46

    :cond_45
    move-object v1, v2

    :catchall_46
    :cond_46
    :goto_46
    :try_start_46
    new-instance p0, Lwzg;

    invoke-direct {p0, v1}, Lwzg;-><init>(Luzg;)V

    sput-object p0, Lwzg;->c:Lwzg;
    :try_end_4d
    .catchall {:try_start_46 .. :try_end_4d} :catchall_4e

    goto :goto_50

    :catchall_4e
    move-exception p0

    goto :goto_54

    :cond_50
    :goto_50
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    goto :goto_58

    :goto_54
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    throw p0

    :cond_58
    :goto_58
    sget-object p0, Lwzg;->c:Lwzg;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0
.end method

.method public static final e(Lgrd;)Ldnc;
    .registers 2

    const/16 v0, 0x10

    invoke-static {p0, v0}, La60;->O(Lp46;I)Ldnc;

    move-result-object p0

    return-object p0
.end method

.method public static final f(C)Z
    .registers 3

    const/16 v0, 0x30

    const/4 v1, 0x0

    if-gt v0, p0, :cond_b

    const/16 v0, 0x3a

    if-ge p0, v0, :cond_b

    const/4 p0, 0x1

    return p0

    :cond_b
    return v1
.end method

.method public static g(Lla5;Lq98;)Lug2;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Le16;

    const/4 v1, 0x3

    sget-object v2, Lxa5;->E:Lxa5;

    invoke-direct {v0, v1, p0, v2, p1}, Le16;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v0}, Lrck;->z(Lsg2;)Lug2;

    move-result-object p0

    return-object p0
.end method

.method public static final h(Lct2;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lvn3;)Ljava/lang/Object;
    .registers 7

    new-instance v0, Lcom/anthropic/claude/api/chat/MoveChatsRequest;

    invoke-static {p2}, Lcom/anthropic/claude/types/strings/ChatId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/ChatId;

    move-result-object p2

    invoke-static {p2}, Loz4;->H(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    const/4 v1, 0x0

    invoke-direct {v0, p2, p3, v1}, Lcom/anthropic/claude/api/chat/MoveChatsRequest;-><init>(Ljava/util/List;Ljava/lang/String;Lry5;)V

    invoke-interface {p0, p1, v0, p4}, Lct2;->f(Ljava/lang/String;Lcom/anthropic/claude/api/chat/MoveChatsRequest;La75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static final i(ILjava/lang/String;)Ljava/lang/String;
    .registers 9

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0xc

    add-int/2addr p0, v1

    if-lt v0, p0, :cond_6c

    const-string p0, "+-"

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {p0, v2}, Lcnh;->k0(Ljava/lang/CharSequence;C)Z

    move-result p0

    if-nez p0, :cond_17

    goto :goto_6c

    :cond_17
    const/16 p0, 0x2d

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1, p0, v3, v2}, Lcnh;->u0(Ljava/lang/CharSequence;CII)I

    move-result p0

    if-ge p0, v1, :cond_22

    goto :goto_6c

    :cond_22
    move v2, v0

    :goto_23
    add-int/lit8 v4, v2, 0x1

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x30

    if-ne v5, v6, :cond_2f

    move v2, v4

    goto :goto_23

    :cond_2f
    sub-int v2, p0, v2

    if-lt v2, v1, :cond_34

    goto :goto_6c

    :cond_34
    add-int/lit8 v1, p0, -0xa

    if-lt v1, v3, :cond_5f

    if-ne v1, v3, :cond_43

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p0

    invoke-virtual {p1, v0, p0}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    goto :goto_5a

    :cond_43
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    add-int/lit8 p0, p0, -0xb

    sub-int/2addr v4, p0

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v2, p1, v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p0

    invoke-virtual {v2, p1, v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    move-object p0, v2

    :goto_5a
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_5f
    const-string p0, "End index ("

    const-string p1, ") is less than start index (1)."

    invoke-static {v1, p0, p1}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lmf6;->j(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_6c
    :goto_6c
    return-object p1
.end method
