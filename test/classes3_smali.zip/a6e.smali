.class public final La6e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Lcom/anthropic/claude/api/chat/MessageFile;


# direct methods
.method public constructor <init>(Lcom/anthropic/claude/api/chat/MessageFile;Ljava/lang/String;)V
    .registers 3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La6e;->a:Ljava/lang/String;

    iput-object p1, p0, La6e;->b:Lcom/anthropic/claude/api/chat/MessageFile;

    return-void
.end method


# virtual methods
.method public final a()Lcom/anthropic/claude/api/chat/MessageFile;
    .registers 1

    iget-object p0, p0, La6e;->b:Lcom/anthropic/claude/api/chat/MessageFile;

    return-object p0
.end method

.method public final b()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, La6e;->a:Ljava/lang/String;

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La6e;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La6e;

    iget-object v1, p0, La6e;->a:Ljava/lang/String;

    iget-object v3, p1, La6e;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lcom/anthropic/claude/types/strings/ProjectId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object p0, p0, La6e;->b:Lcom/anthropic/claude/api/chat/MessageFile;

    iget-object p1, p1, La6e;->b:Lcom/anthropic/claude/api/chat/MessageFile;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_22

    return v2

    :cond_22
    return v0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, La6e;->a:Ljava/lang/String;

    invoke-static {v0}, Lcom/anthropic/claude/types/strings/ProjectId;->hashCode-impl(Ljava/lang/String;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, La6e;->b:Lcom/anthropic/claude/api/chat/MessageFile;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, La6e;->a:Ljava/lang/String;

    invoke-static {v0}, Lcom/anthropic/claude/types/strings/ProjectId;->toString-impl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "ProjectFileUpload(projectId="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", messageFile="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, La6e;->b:Lcom/anthropic/claude/api/chat/MessageFile;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
