.class public final Lba3;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lc98;


# instance fields
.field public final synthetic E:I

.field public F:I

.field public final synthetic G:Lj15;

.field public final synthetic H:Lq93;


# direct methods
.method public synthetic constructor <init>(Lj15;Lq93;La75;I)V
    .registers 5

    iput p4, p0, Lba3;->E:I

    iput-object p1, p0, Lba3;->G:Lj15;

    iput-object p2, p0, Lba3;->H:Lq93;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p3}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(La75;)La75;
    .registers 5

    iget v0, p0, Lba3;->E:I

    iget-object v1, p0, Lba3;->H:Lq93;

    iget-object p0, p0, Lba3;->G:Lj15;

    packed-switch v0, :pswitch_data_18

    new-instance v0, Lba3;

    const/4 v2, 0x1

    invoke-direct {v0, p0, v1, p1, v2}, Lba3;-><init>(Lj15;Lq93;La75;I)V

    return-object v0

    :pswitch_10  #0x0
    new-instance v0, Lba3;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, p1, v2}, Lba3;-><init>(Lj15;Lq93;La75;I)V

    return-object v0

    nop

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_10  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iget v0, p0, Lba3;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    check-cast p1, La75;

    packed-switch v0, :pswitch_data_20

    invoke-virtual {p0, p1}, Lba3;->create(La75;)La75;

    move-result-object p0

    check-cast p0, Lba3;

    invoke-virtual {p0, v1}, Lba3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_14  #0x0
    invoke-virtual {p0, p1}, Lba3;->create(La75;)La75;

    move-result-object p0

    check-cast p0, Lba3;

    invoke-virtual {p0, v1}, Lba3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_14  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    iget v0, p0, Lba3;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    iget-object v2, p0, Lba3;->H:Lq93;

    iget-object v3, p0, Lba3;->G:Lj15;

    const/4 v4, 0x0

    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v6, Lva5;->E:Lva5;

    const/4 v7, 0x1

    packed-switch v0, :pswitch_data_52

    iget v0, p0, Lba3;->F:I

    if-eqz v0, :cond_20

    if-ne v0, v7, :cond_1b

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_30

    :cond_1b
    invoke-static {v5}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_30

    :cond_20
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v3, Lj15;->f:Ly42;

    iget-object v0, v2, Lq93;->m:Ly42;

    iput v7, p0, Lba3;->F:I

    invoke-static {p1, v0, p0}, Lnfl;->q(Lvre;Ldbg;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_30

    move-object v1, v6

    :cond_30
    :goto_30
    return-object v1

    :pswitch_31  #0x0
    iget v0, p0, Lba3;->F:I

    if-eqz v0, :cond_40

    if-ne v0, v7, :cond_3b

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_50

    :cond_3b
    invoke-static {v5}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_50

    :cond_40
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v3, Lj15;->f:Ly42;

    iget-object v0, v2, Lq93;->m:Ly42;

    iput v7, p0, Lba3;->F:I

    invoke-static {p1, v0, p0}, Lnfl;->q(Lvre;Ldbg;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_50

    move-object v1, v6

    :cond_50
    :goto_50
    return-object v1

    nop

    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_31  #00000000
    .end packed-switch
.end method
