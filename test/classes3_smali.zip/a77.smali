.class public abstract synthetic La77;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:[I

.field public static final synthetic b:[I

.field public static final synthetic c:[I

.field public static final synthetic d:[I

.field public static final synthetic e:[I

.field public static final synthetic f:[I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    invoke-static {}, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;->values()[Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    const/4 v1, 0x1

    :try_start_8
    sget-object v2, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;->EMAIL:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aput v1, v0, v2
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_10} :catch_10

    :catch_10
    const/4 v2, 0x2

    :try_start_11
    sget-object v3, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;->SMS:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aput v2, v0, v3
    :try_end_19
    .catch Ljava/lang/NoSuchFieldError; {:try_start_11 .. :try_end_19} :catch_19

    :catch_19
    const/4 v3, 0x3

    :try_start_1a
    sget-object v4, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;->ALARM:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemNudgesItemMethod;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v3, v0, v4
    :try_end_22
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1a .. :try_end_22} :catch_22

    :catch_22
    sput-object v0, La77;->a:[I

    invoke-static {}, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;->values()[Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_2b
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;->EMAIL:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v1, v0, v4
    :try_end_33
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2b .. :try_end_33} :catch_33

    :catch_33
    :try_start_33
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;->SMS:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v2, v0, v4
    :try_end_3b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_33 .. :try_end_3b} :catch_3b

    :catch_3b
    :try_start_3b
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;->ALARM:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v3, v0, v4
    :try_end_43
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3b .. :try_end_43} :catch_43

    :catch_43
    :try_start_43
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;->NOTIFICATION:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemNudgesItemMethod;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    const/4 v5, 0x4

    aput v5, v0, v4
    :try_end_4c
    .catch Ljava/lang/NoSuchFieldError; {:try_start_43 .. :try_end_4c} :catch_4c

    :catch_4c
    sput-object v0, La77;->b:[I

    invoke-static {}, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;->values()[Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_55
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;->CONFIRMED:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v1, v0, v4
    :try_end_5d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_55 .. :try_end_5d} :catch_5d

    :catch_5d
    :try_start_5d
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;->TENTATIVE:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v2, v0, v4
    :try_end_65
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5d .. :try_end_65} :catch_65

    :catch_65
    :try_start_65
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;->CANCELLED:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemStatus;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v3, v0, v4
    :try_end_6d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_65 .. :try_end_6d} :catch_6d

    :catch_6d
    sput-object v0, La77;->c:[I

    invoke-static {}, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;->values()[Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_76
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;->BUSY:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v1, v0, v4
    :try_end_7e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_76 .. :try_end_7e} :catch_7e

    :catch_7e
    :try_start_7e
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;->FREE:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v2, v0, v4
    :try_end_86
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7e .. :try_end_86} :catch_86

    :catch_86
    :try_start_86
    sget-object v4, Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;->TENTATIVE:Lcom/anthropic/claude/tool/model/EventUpdateV0InputEventUpdatesItemAvailability;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v3, v0, v4
    :try_end_8e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_86 .. :try_end_8e} :catch_8e

    :catch_8e
    sput-object v0, La77;->d:[I

    invoke-static {}, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;->values()[Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_97
    sget-object v4, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;->CONFIRMED:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v1, v0, v4
    :try_end_9f
    .catch Ljava/lang/NoSuchFieldError; {:try_start_97 .. :try_end_9f} :catch_9f

    :catch_9f
    :try_start_9f
    sget-object v4, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;->TENTATIVE:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v2, v0, v4
    :try_end_a7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9f .. :try_end_a7} :catch_a7

    :catch_a7
    :try_start_a7
    sget-object v4, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;->CANCELLED:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemStatus;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v3, v0, v4
    :try_end_af
    .catch Ljava/lang/NoSuchFieldError; {:try_start_a7 .. :try_end_af} :catch_af

    :catch_af
    sput-object v0, La77;->e:[I

    invoke-static {}, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;->values()[Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_b8
    sget-object v4, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;->BUSY:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aput v1, v0, v4
    :try_end_c0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b8 .. :try_end_c0} :catch_c0

    :catch_c0
    :try_start_c0
    sget-object v1, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;->FREE:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aput v2, v0, v1
    :try_end_c8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c0 .. :try_end_c8} :catch_c8

    :catch_c8
    :try_start_c8
    sget-object v1, Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;->TENTATIVE:Lcom/anthropic/claude/tool/model/EventCreateV1InputNewEventsItemAvailability;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aput v3, v0, v1
    :try_end_d0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c8 .. :try_end_d0} :catch_d0

    :catch_d0
    sput-object v0, La77;->f:[I

    return-void
.end method
