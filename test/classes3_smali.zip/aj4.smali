.class public final synthetic Laj4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lcom/anthropic/claude/code/remote/h;


# direct methods
.method public synthetic constructor <init>(Lcom/anthropic/claude/code/remote/h;I)V
    .registers 3

    iput p2, p0, Laj4;->E:I

    iput-object p1, p0, Laj4;->F:Lcom/anthropic/claude/code/remote/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 15

    iget v0, p0, Laj4;->E:I

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lz2j;->a:Lz2j;

    iget-object v6, p0, Laj4;->F:Lcom/anthropic/claude/code/remote/h;

    packed-switch v0, :pswitch_data_246

    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->m2:Ltad;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, v0}, Ltad;->setValue(Ljava/lang/Object;)V

    return-object v5

    :pswitch_15  #0x13
    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->n2:Ltad;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p0, v0}, Ltad;->setValue(Ljava/lang/Object;)V

    return-object v5

    :pswitch_1d  #0x12
    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->o2:Ltad;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p0, v0}, Ltad;->setValue(Ljava/lang/Object;)V

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->N1()Z

    return-object v5

    :pswitch_28  #0x11
    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->Q2:Ltad;

    invoke-virtual {p0, v4}, Ltad;->setValue(Ljava/lang/Object;)V

    return-object v5

    :pswitch_2e  #0x10
    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->P2:Ltad;

    invoke-virtual {p0, v4}, Ltad;->setValue(Ljava/lang/Object;)V

    return-object v5

    :pswitch_34  #0xf
    invoke-virtual {v6, v4}, Lcom/anthropic/claude/code/remote/h;->V1(Lk79;)V

    return-object v5

    :pswitch_38  #0xe
    invoke-virtual {v6, v4}, Lcom/anthropic/claude/code/remote/h;->h2(Ljava/lang/String;)V

    return-object v5

    :pswitch_3c  #0xd
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->K0()Lmnd;

    move-result-object p0

    if-nez p0, :cond_43

    goto :goto_91

    :cond_43
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->e0()V

    iget-object v0, v6, Lcom/anthropic/claude/code/remote/h;->n:Let3;

    new-instance v1, Lcom/anthropic/claude/analytics/events/CodeEvents$PlanRejected;

    iget-object v2, v6, Lcom/anthropic/claude/code/remote/h;->o:Ljava/lang/String;

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->Q0()Ljava/lang/String;

    move-result-object v3

    const-string v7, ""

    if-nez v3, :cond_55

    move-object v3, v7

    :cond_55
    invoke-direct {v1, v2, v3}, Lcom/anthropic/claude/analytics/events/CodeEvents$PlanRejected;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v2, Lcom/anthropic/claude/analytics/events/CodeEvents$PlanRejected;->Companion:Lr74;

    invoke-virtual {v2}, Lr74;->serializer()Lkotlinx/serialization/KSerializer;

    move-result-object v2

    check-cast v2, Lpeg;

    invoke-interface {v0, v1, v2}, Let3;->f(Lcom/anthropic/claude/analytics/events/AnalyticsEvent;Lpeg;)V

    iget-object p0, p0, Lmnd;->b:Ljava/lang/String;

    iput-object p0, v6, Lcom/anthropic/claude/code/remote/h;->F2:Ljava/lang/String;

    invoke-virtual {v6, v4}, Lcom/anthropic/claude/code/remote/h;->e2(Lmnd;)V

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->h0()V

    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->x2:Ltad;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, v0}, Ltad;->setValue(Ljava/lang/Object;)V

    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->W2:Lafd;

    iget-object v0, p0, Lafd;->c:Ljava/lang/Object;

    check-cast v0, Lo8i;

    invoke-virtual {v0}, Lo8i;->d()Lw4i;

    move-result-object v1

    iget-object v1, v1, Lw4i;->G:Ljava/lang/CharSequence;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lafd;->b(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_8b

    goto :goto_91

    :cond_8b
    invoke-static {v0, v7}, Lgml;->k(Lo8i;Ljava/lang/String;)V

    invoke-virtual {p0, v1, v7}, Lafd;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_91
    return-object v5

    :pswitch_92  #0xc
    iget-object v9, p0, Laj4;->F:Lcom/anthropic/claude/code/remote/h;

    invoke-virtual {v9}, Lcom/anthropic/claude/code/remote/h;->L0()Z

    move-result p0

    const/4 v12, 0x0

    if-eqz p0, :cond_9f

    sget-object p0, Lcom/anthropic/claude/sessions/types/PermissionMode;->Auto:Lcom/anthropic/claude/sessions/types/PermissionMode;

    move-object v11, p0

    goto :goto_a0

    :cond_9f
    move-object v11, v12

    :goto_a0
    invoke-virtual {v9}, Lcom/anthropic/claude/code/remote/h;->K0()Lmnd;

    move-result-object v10

    if-nez v10, :cond_a7

    goto :goto_c1

    :cond_a7
    iget-object p0, v9, Lcom/anthropic/claude/code/remote/h;->v2:Ljava/lang/String;

    if-eqz p0, :cond_ac

    goto :goto_c1

    :cond_ac
    iget-object p0, v10, Lmnd;->b:Ljava/lang/String;

    iput-object p0, v9, Lcom/anthropic/claude/code/remote/h;->v2:Ljava/lang/String;

    invoke-virtual {v9, v12}, Lcom/anthropic/claude/code/remote/h;->e2(Lmnd;)V

    invoke-virtual {v9}, Lcom/anthropic/claude/code/remote/h;->h0()V

    iget-object p0, v9, Lhlf;->a:Lt65;

    new-instance v8, Lgv3;

    const/4 v13, 0x7

    invoke-direct/range {v8 .. v13}, Lgv3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;La75;I)V

    invoke-static {p0, v12, v12, v8, v1}, Lao9;->S(Lua5;Lla5;Lxa5;Lq98;I)Lpfh;

    :goto_c1
    return-object v5

    :pswitch_c2  #0xb
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->M0()Ljava/util/List;

    move-result-object p0

    check-cast p0, Ljava/util/Collection;

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result p0

    iget-object v0, v6, Lcom/anthropic/claude/code/remote/h;->M2:Lgl4;

    iget-object v0, v0, Lgl4;->m:Lq7h;

    invoke-virtual {v0}, Lq7h;->isEmpty()Z

    move-result v0

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->N0()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_dc

    move v1, v3

    goto :goto_dd

    :cond_dc
    move v1, v2

    :goto_dd
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->d1()Z

    move-result v4

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->v1()Z

    move-result v5

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->K0()Lmnd;

    move-result-object v7

    if-eqz v7, :cond_ed

    move v7, v3

    goto :goto_ee

    :cond_ed
    move v7, v2

    :goto_ee
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->s0()Lwz0;

    move-result-object v8

    if-eqz v8, :cond_f6

    move v8, v3

    goto :goto_f7

    :cond_f6
    move v8, v2

    :goto_f7
    iget-object v6, v6, Lcom/anthropic/claude/code/remote/h;->s2:Lsgd;

    iget-object v6, v6, Lsgd;->m:Lq7h;

    invoke-virtual {v6}, Lq7h;->isEmpty()Z

    move-result v6

    if-eqz p0, :cond_110

    if-eqz v0, :cond_110

    if-nez v1, :cond_110

    if-nez v4, :cond_110

    if-nez v5, :cond_110

    if-nez v7, :cond_110

    if-nez v8, :cond_110

    if-eqz v6, :cond_110

    goto :goto_111

    :cond_110
    move v2, v3

    :goto_111
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_116  #0xa
    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->V0:Lo8i;

    invoke-virtual {p0}, Lo8i;->d()Lw4i;

    move-result-object p0

    iget-object p0, p0, Lw4i;->G:Ljava/lang/CharSequence;

    invoke-static {p0}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result p0

    xor-int/2addr p0, v3

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_128  #0x9
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->u1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    invoke-static {p0}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object p0

    return-object p0

    :pswitch_135  #0x8
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->e0()V

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->U0()Ljava/lang/String;

    move-result-object p0

    iput-object p0, v6, Lcom/anthropic/claude/code/remote/h;->D2:Ljava/lang/String;

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->c0()V

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->m1()Z

    move-result p0

    if-nez p0, :cond_194

    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->d:Lrig;

    iget-object p0, p0, Lrig;->j:Ljava/lang/String;

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->Q0()Ljava/lang/String;

    move-result-object v0

    if-nez p0, :cond_155

    if-nez v0, :cond_15c

    move v2, v3

    goto :goto_15c

    :cond_155
    if-nez v0, :cond_158

    goto :goto_15c

    :cond_158
    invoke-static {p0, v0}, Lcom/anthropic/claude/types/strings/SessionId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    :cond_15c
    :goto_15c
    if-eqz v2, :cond_194

    iget-object p0, v6, Lcom/anthropic/claude/code/remote/h;->U0:Lohg;

    iget-object v0, p0, Lohg;->j:Lkhh;

    invoke-virtual {v0}, Lkhh;->getValue()Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_169

    goto :goto_194

    :cond_169
    const-string v2, "pending"

    invoke-virtual {v0, v4, v2}, Lkhh;->n(Ljava/lang/Object;Ljava/lang/Object;)Z

    iget-object v0, p0, Lohg;->b:Lua5;

    new-instance v2, Lkhg;

    invoke-direct {v2, p0, v4, v3}, Lkhg;-><init>(Lohg;La75;I)V

    invoke-static {v0, v4, v4, v2, v1}, Lao9;->S(Lua5;Lla5;Lxa5;Lq98;I)Lpfh;

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->Q0()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_194

    iget-object v0, v6, Lcom/anthropic/claude/code/remote/h;->n:Let3;

    new-instance v1, Lcom/anthropic/claude/analytics/events/CodeEvents$TurnInterrupted;

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->t0()Lcom/anthropic/claude/analytics/events/CodeEvents$CodeSurface;

    move-result-object v2

    invoke-direct {v1, p0, v2}, Lcom/anthropic/claude/analytics/events/CodeEvents$TurnInterrupted;-><init>(Ljava/lang/String;Lcom/anthropic/claude/analytics/events/CodeEvents$CodeSurface;)V

    sget-object p0, Lcom/anthropic/claude/analytics/events/CodeEvents$TurnInterrupted;->Companion:Lsc4;

    invoke-virtual {p0}, Lsc4;->serializer()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    check-cast p0, Lpeg;

    invoke-interface {v0, v1, p0}, Let3;->f(Lcom/anthropic/claude/analytics/events/AnalyticsEvent;Lpeg;)V

    :cond_194
    :goto_194
    return-object v5

    :pswitch_195  #0x7
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->v0()Lhd5;

    move-result-object p0

    invoke-virtual {p0}, Lhd5;->a()Lcom/anthropic/claude/sessions/types/PermissionMode;

    move-result-object p0

    return-object p0

    :pswitch_19e  #0x6
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->v0()Lhd5;

    move-result-object p0

    invoke-virtual {p0}, Lhd5;->a()Lcom/anthropic/claude/sessions/types/PermissionMode;

    move-result-object p0

    return-object p0

    :pswitch_1a7  #0x5
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->v0()Lhd5;

    move-result-object p0

    iget-boolean v0, p0, Lhd5;->c:Z

    if-eqz v0, :cond_1bf

    iget-boolean v0, p0, Lhd5;->a:Z

    if-eqz v0, :cond_1b6

    sget-object v4, Lcom/anthropic/claude/sessions/types/PermissionMode;->Auto:Lcom/anthropic/claude/sessions/types/PermissionMode;

    goto :goto_1bc

    :cond_1b6
    iget-boolean p0, p0, Lhd5;->b:Z

    if-eqz p0, :cond_1bc

    sget-object v4, Lcom/anthropic/claude/sessions/types/PermissionMode;->BypassPermissions:Lcom/anthropic/claude/sessions/types/PermissionMode;

    :cond_1bc
    :goto_1bc
    if-eqz v4, :cond_1bf

    move v2, v3

    :cond_1bf
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_1c4  #0x4
    sget p0, Lcom/anthropic/claude/code/remote/h;->G3:I

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->W0()Lrng;

    move-result-object p0

    iget-boolean p0, p0, Lrng;->K:Z

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_1d1  #0x3
    invoke-virtual {v6, v4}, Lcom/anthropic/claude/code/remote/h;->G1(Ljava/lang/String;)V

    return-object v5

    :pswitch_1d5  #0x2
    new-instance p0, Luvi;

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->q1()Z

    move-result v0

    iget-object v1, v6, Lcom/anthropic/claude/code/remote/h;->t3:Ltad;

    invoke-virtual {v1}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    if-eqz v5, :cond_1e7

    move v5, v3

    goto :goto_1e8

    :cond_1e7
    move v5, v2

    :goto_1e8
    iget-object v7, v6, Lcom/anthropic/claude/code/remote/h;->s3:Ltad;

    invoke-virtual {v7}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Long;

    if-eqz v7, :cond_1f4

    move v7, v3

    goto :goto_1f5

    :cond_1f4
    move v7, v2

    :goto_1f5
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->T0()Lrlh;

    move-result-object v8

    if-eqz v8, :cond_1fd

    move v8, v3

    goto :goto_1fe

    :cond_1fd
    move v8, v2

    :goto_1fe
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->C0()Ltgg;

    move-result-object v9

    instance-of v10, v9, Lfwb;

    if-eqz v10, :cond_209

    move-object v4, v9

    check-cast v4, Lfwb;

    :cond_209
    if-eqz v4, :cond_213

    invoke-virtual {v4}, Lfwb;->e()Z

    move-result v4

    if-ne v4, v3, :cond_213

    move v4, v3

    goto :goto_214

    :cond_213
    move v4, v2

    :goto_214
    sget-object v9, Lcom/anthropic/claude/code/remote/i;->b:Lz0f;

    if-nez v0, :cond_221

    if-nez v8, :cond_221

    if-nez v5, :cond_21e

    if-eqz v7, :cond_221

    :cond_21e
    if-eqz v4, :cond_221

    move v2, v3

    :cond_221
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v1}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->C0()Ltgg;

    move-result-object v2

    invoke-direct {p0, v0, v1, v2}, Luvi;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0

    :pswitch_233  #0x1
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->q1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_23c  #0x0
    invoke-virtual {v6}, Lcom/anthropic/claude/code/remote/h;->q1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_246
    .packed-switch 0x0
        :pswitch_23c  #00000000
        :pswitch_233  #00000001
        :pswitch_1d5  #00000002
        :pswitch_1d1  #00000003
        :pswitch_1c4  #00000004
        :pswitch_1a7  #00000005
        :pswitch_19e  #00000006
        :pswitch_195  #00000007
        :pswitch_135  #00000008
        :pswitch_128  #00000009
        :pswitch_116  #0000000a
        :pswitch_c2  #0000000b
        :pswitch_92  #0000000c
        :pswitch_3c  #0000000d
        :pswitch_38  #0000000e
        :pswitch_34  #0000000f
        :pswitch_2e  #00000010
        :pswitch_28  #00000011
        :pswitch_1d  #00000012
        :pswitch_15  #00000013
    .end packed-switch
.end method
