.class public final Lba1;
.super La4;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lba1;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final E:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Llmk;

    const/16 v1, 0x13

    invoke-direct {v0, v1}, Llmk;-><init>(I)V

    sput-object v0, Lba1;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Z)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lba1;->E:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Lba1;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    check-cast p1, Lba1;

    iget-boolean p0, p0, Lba1;->E:Z

    iget-boolean p1, p1, Lba1;->E:Z

    if-ne p0, p1, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    return v1
.end method

.method public final hashCode()I
    .registers 1

    iget-boolean p0, p0, Lba1;->E:Z

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 5

    const/16 p2, 0x4f45

    invoke-static {p1, p2}, Lupl;->V(Landroid/os/Parcel;I)I

    move-result p2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p1, v1, v0}, Lupl;->U(Landroid/os/Parcel;II)V

    iget-boolean p0, p0, Lba1;->E:Z

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeInt(I)V

    invoke-static {p1, p2}, Lupl;->W(Landroid/os/Parcel;I)V

    return-void
.end method
