.class public final synthetic Lah4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:Lcom/anthropic/claude/code/remote/a;

.field public final synthetic F:Lcom/anthropic/claude/sessions/types/SessionResource;

.field public final synthetic G:La98;

.field public final synthetic H:Lc98;

.field public final synthetic I:La98;

.field public final synthetic J:Li3h;

.field public final synthetic K:Z

.field public final synthetic L:Z

.field public final synthetic M:Z

.field public final synthetic N:Ljava/lang/String;

.field public final synthetic O:La98;

.field public final synthetic P:Z

.field public final synthetic Q:La98;

.field public final synthetic R:Lc98;

.field public final synthetic S:Lu9j;

.field public final synthetic T:La98;

.field public final synthetic U:La98;

.field public final synthetic V:La98;

.field public final synthetic W:Z

.field public final synthetic X:La98;

.field public final synthetic Y:La98;

.field public final synthetic Z:Z

.field public final synthetic a0:Z

.field public final synthetic b0:Z

.field public final synthetic c0:Ljava/lang/String;

.field public final synthetic d0:Z


# direct methods
.method public synthetic constructor <init>(Lcom/anthropic/claude/code/remote/a;Lcom/anthropic/claude/sessions/types/SessionResource;La98;Lc98;La98;Li3h;ZZZLjava/lang/String;La98;ZLa98;Lc98;Lu9j;La98;La98;La98;ZLa98;La98;ZZZLjava/lang/String;Z)V
    .registers 27

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lah4;->E:Lcom/anthropic/claude/code/remote/a;

    iput-object p2, p0, Lah4;->F:Lcom/anthropic/claude/sessions/types/SessionResource;

    iput-object p3, p0, Lah4;->G:La98;

    iput-object p4, p0, Lah4;->H:Lc98;

    iput-object p5, p0, Lah4;->I:La98;

    iput-object p6, p0, Lah4;->J:Li3h;

    iput-boolean p7, p0, Lah4;->K:Z

    iput-boolean p8, p0, Lah4;->L:Z

    iput-boolean p9, p0, Lah4;->M:Z

    iput-object p10, p0, Lah4;->N:Ljava/lang/String;

    iput-object p11, p0, Lah4;->O:La98;

    iput-boolean p12, p0, Lah4;->P:Z

    iput-object p13, p0, Lah4;->Q:La98;

    iput-object p14, p0, Lah4;->R:Lc98;

    iput-object p15, p0, Lah4;->S:Lu9j;

    move-object/from16 p1, p16

    iput-object p1, p0, Lah4;->T:La98;

    move-object/from16 p1, p17

    iput-object p1, p0, Lah4;->U:La98;

    move-object/from16 p1, p18

    iput-object p1, p0, Lah4;->V:La98;

    move/from16 p1, p19

    iput-boolean p1, p0, Lah4;->W:Z

    move-object/from16 p1, p20

    iput-object p1, p0, Lah4;->X:La98;

    move-object/from16 p1, p21

    iput-object p1, p0, Lah4;->Y:La98;

    move/from16 p1, p22

    iput-boolean p1, p0, Lah4;->Z:Z

    move/from16 p1, p23

    iput-boolean p1, p0, Lah4;->a0:Z

    move/from16 p1, p24

    iput-boolean p1, p0, Lah4;->b0:Z

    move-object/from16 p1, p25

    iput-object p1, p0, Lah4;->c0:Ljava/lang/String;

    move/from16 p1, p26

    iput-boolean p1, p0, Lah4;->d0:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 30

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v3, v2, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eq v3, v6, :cond_17

    move v3, v4

    goto :goto_18

    :cond_17
    move v3, v5

    :goto_18
    and-int/2addr v2, v4

    check-cast v1, Leb8;

    invoke-virtual {v1, v2, v3}, Leb8;->W(IZ)Z

    move-result v2

    if-eqz v2, :cond_655

    iget-object v2, v0, Lah4;->E:Lcom/anthropic/claude/code/remote/a;

    invoke-virtual {v2}, Lcom/anthropic/claude/code/remote/a;->a0()Lui9;

    move-result-object v3

    iget-object v7, v2, Lcom/anthropic/claude/code/remote/a;->t:Lcom/anthropic/claude/code/remote/CodeSessionListScope;

    sget-object v8, Lcom/anthropic/claude/code/remote/b;->a:Ljava/util/List;

    iget-object v8, v0, Lah4;->F:Lcom/anthropic/claude/sessions/types/SessionResource;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getPending_action()Lcom/anthropic/claude/sessions/types/RequiresActionDetails;

    move-result-object v9

    const/16 v22, 0x0

    if-eqz v9, :cond_47

    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getSession_status()Lcom/anthropic/claude/sessions/types/SessionStatus;

    move-result-object v10

    sget-object v11, Lcom/anthropic/claude/sessions/types/SessionStatus;->REQUIRES_ACTION:Lcom/anthropic/claude/sessions/types/SessionStatus;

    if-ne v10, v11, :cond_47

    invoke-virtual {v9}, Lcom/anthropic/claude/sessions/types/RequiresActionDetails;->isToolPermission()Z

    move-result v10

    if-eqz v10, :cond_47

    goto :goto_49

    :cond_47
    move-object/from16 v9, v22

    :goto_49
    sget-object v10, Luwa;->G:Lqu1;

    invoke-static {v10, v5}, Lw12;->d(Lmu;Z)Lnlb;

    move-result-object v10

    iget-wide v11, v1, Leb8;->T:J

    invoke-static {v11, v12}, Ljava/lang/Long;->hashCode(J)I

    move-result v11

    invoke-virtual {v1}, Leb8;->l()Lnhd;

    move-result-object v12

    sget-object v13, Lq7c;->E:Lq7c;

    invoke-static {v1, v13}, Lezg;->l0(Lzu4;Lt7c;)Lt7c;

    move-result-object v13

    sget-object v14, Lru4;->e:Lqu4;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v14, Lqu4;->b:Lhw4;

    invoke-virtual {v1}, Leb8;->k0()V

    iget-boolean v15, v1, Leb8;->S:Z

    if-eqz v15, :cond_71

    invoke-virtual {v1, v14}, Leb8;->k(La98;)V

    goto :goto_74

    :cond_71
    invoke-virtual {v1}, Leb8;->t0()V

    :goto_74
    sget-object v14, Lqu4;->f:Lja0;

    invoke-static {v1, v14, v10}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v10, Lqu4;->e:Lja0;

    invoke-static {v1, v10, v12}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    sget-object v11, Lqu4;->g:Lja0;

    invoke-static {v1, v11, v10}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v10, Lqu4;->h:Lay;

    invoke-static {v1, v10}, Lr1i;->u(Lzu4;Lc98;)V

    sget-object v10, Lqu4;->d:Lja0;

    invoke-static {v1, v10, v13}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v10, Lcom/anthropic/claude/code/remote/CodeSessionListScope$DramaticShrimp;->INSTANCE:Lcom/anthropic/claude/code/remote/CodeSessionListScope$DramaticShrimp;

    invoke-static {v7, v10}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    sget-object v11, Lzyg;->H:Lzyg;

    move v14, v10

    iget-object v10, v0, Lah4;->G:La98;

    iget-object v15, v0, Lah4;->H:Lc98;

    iget-object v12, v0, Lah4;->I:La98;

    iget-object v13, v0, Lah4;->J:Li3h;

    iget-boolean v6, v0, Lah4;->Z:Z

    move-object/from16 v17, v12

    sget-object v12, Lxu4;->a:Lmx8;

    if-nez v14, :cond_ae

    instance-of v7, v7, Lcom/anthropic/claude/code/remote/CodeSessionListScope$Scheduled;

    if-eqz v7, :cond_b5

    :cond_ae
    move-object v7, v1

    move-object v1, v8

    move-object v5, v12

    move-object v8, v13

    move-object v4, v15

    goto/16 :goto_222

    :cond_b5
    const v7, -0x482c78dc

    invoke-virtual {v1, v7}, Leb8;->g0(I)V

    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getTitle()Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_c8

    invoke-static {v7}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v14

    if-nez v14, :cond_c8

    goto :goto_ca

    :cond_c8
    move-object/from16 v7, v22

    :goto_ca
    if-nez v7, :cond_f9

    const v7, 0x5ee0f26

    invoke-virtual {v1, v7}, Leb8;->g0(I)V

    sget-object v7, Lzk4;->a:Lfih;

    invoke-virtual {v1, v7}, Leb8;->j(Ldge;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lyk4;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    move-result v7

    if-eqz v7, :cond_ed

    if-ne v7, v4, :cond_e9

    const v7, 0x7f120ae0

    goto :goto_f0

    :cond_e9
    invoke-static {}, Le97;->d()V

    return-object v22

    :cond_ed
    const v7, 0x7f120adf

    :goto_f0
    invoke-static {v7, v1}, Lmhl;->Z(ILzu4;)Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x0

    :goto_f5
    invoke-virtual {v1, v14}, Leb8;->q(Z)V

    goto :goto_101

    :cond_f9
    const/4 v14, 0x0

    const v5, 0x5ee0c5d

    invoke-virtual {v1, v5}, Leb8;->g0(I)V

    goto :goto_f5

    :goto_101
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getSession_status()Lcom/anthropic/claude/sessions/types/SessionStatus;

    move-result-object v5

    sget-object v14, Lcom/anthropic/claude/sessions/types/SessionStatus;->PENDING:Lcom/anthropic/claude/sessions/types/SessionStatus;

    if-ne v5, v14, :cond_10f

    sget-object v5, Ljmg;->F:Ljmg;

    goto :goto_11c

    :cond_10f
    invoke-static {v8, v3}, Lcom/anthropic/claude/code/remote/b;->d(Lcom/anthropic/claude/sessions/types/SessionResource;Lui9;)Lbjg;

    move-result-object v5

    sget-object v4, Lbjg;->G:Lbjg;

    if-ne v5, v4, :cond_11a

    sget-object v5, Ljmg;->G:Ljmg;

    goto :goto_11c

    :cond_11a
    sget-object v5, Ljmg;->E:Ljmg;

    :goto_11c
    invoke-virtual {v2, v8}, Lcom/anthropic/claude/code/remote/a;->i0(Lcom/anthropic/claude/sessions/types/SessionResource;)Z

    move-result v4

    if-eqz v6, :cond_125

    move-object/from16 v6, v17

    goto :goto_127

    :cond_125
    move-object/from16 v6, v22

    :goto_127
    sget v17, Ltng;->b:I

    move/from16 p1, v4

    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getUpdated_at()Lui9;

    move-result-object v4

    move-object/from16 p2, v5

    invoke-virtual {v3, v4}, Lui9;->a(Lui9;)J

    move-result-wide v4

    move-object/from16 v26, v6

    move-object/from16 v25, v7

    sget-wide v6, Ltng;->a:J

    invoke-static {v4, v5, v6, v7}, Lgr6;->d(JJ)I

    move-result v4

    if-gez v4, :cond_143

    move-object v4, v8

    goto :goto_145

    :cond_143
    move-object/from16 v4, v22

    :goto_145
    if-eqz v4, :cond_154

    invoke-virtual {v4}, Lcom/anthropic/claude/sessions/types/SessionResource;->getTask_summary()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_154

    invoke-static {v4}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_154

    goto :goto_156

    :cond_154
    move-object/from16 v4, v22

    :goto_156
    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getUpdated_at()Lui9;

    move-result-object v5

    invoke-static {v5, v3, v11, v1}, Lxjl;->o(Lui9;Lui9;Lzyg;Lzu4;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getPost_turn_summary()Lcom/anthropic/claude/sessions/types/PostTurnSummary;

    move-result-object v6

    if-eqz v6, :cond_192

    invoke-virtual {v8}, Lcom/anthropic/claude/sessions/types/SessionResource;->getSession_status()Lcom/anthropic/claude/sessions/types/SessionStatus;

    move-result-object v7

    if-ne v7, v14, :cond_16c

    move-object/from16 v6, v22

    :cond_16c
    if-eqz v6, :cond_192

    invoke-static {v8, v3}, Lcom/anthropic/claude/code/remote/b;->c(Lcom/anthropic/claude/sessions/types/SessionResource;Lui9;)Z

    move-result v3

    if-nez v3, :cond_175

    goto :goto_177

    :cond_175
    move-object/from16 v6, v22

    :goto_177
    if-eqz v6, :cond_192

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/PostTurnSummary;->getStatus_category()Lcom/anthropic/claude/sessions/types/SummaryStatusCategory;

    move-result-object v3

    sget-object v7, Lcom/anthropic/claude/sessions/types/SummaryStatusCategory;->WAITING:Lcom/anthropic/claude/sessions/types/SummaryStatusCategory;

    if-ne v3, v7, :cond_183

    move-object/from16 v6, v22

    :cond_183
    if-eqz v6, :cond_192

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/PostTurnSummary;->getNeeds_action()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_192

    invoke-static {v3}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_192

    goto :goto_194

    :cond_192
    move-object/from16 v3, v22

    :goto_194
    invoke-virtual {v1, v2}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v6

    invoke-virtual {v1, v8}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v7

    or-int/2addr v6, v7

    invoke-virtual {v1, v15}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v7

    or-int/2addr v6, v7

    invoke-virtual {v1}, Leb8;->R()Ljava/lang/Object;

    move-result-object v7

    if-nez v6, :cond_1aa

    if-ne v7, v12, :cond_1b3

    :cond_1aa
    new-instance v7, Lxg4;

    const/4 v6, 0x2

    invoke-direct {v7, v2, v8, v15, v6}, Lxg4;-><init>(Lcom/anthropic/claude/code/remote/a;Lcom/anthropic/claude/sessions/types/SessionResource;Lc98;I)V

    invoke-virtual {v1, v7}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_1b3
    check-cast v7, La98;

    if-eqz v9, :cond_1c8

    new-instance v3, Llt;

    const/16 v6, 0x1a

    invoke-direct {v3, v9, v6, v7}, Llt;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    new-instance v6, Ljs4;

    const v7, -0x7087966

    const/4 v9, 0x1

    invoke-direct {v6, v7, v9, v3}, Ljs4;-><init>(IZLr98;)V

    goto :goto_1de

    :cond_1c8
    const/4 v9, 0x1

    if-eqz v3, :cond_1dc

    new-instance v6, Lre;

    const/16 v7, 0xf

    invoke-direct {v6, v3, v7}, Lre;-><init>(Ljava/lang/String;I)V

    new-instance v3, Ljs4;

    const v7, 0x6b022d43

    invoke-direct {v3, v7, v9, v6}, Ljs4;-><init>(IZLr98;)V

    move-object v6, v3

    goto :goto_1de

    :cond_1dc
    move-object/from16 v6, v22

    :goto_1de
    new-instance v16, Leh4;

    iget-boolean v3, v0, Lah4;->a0:Z

    iget-boolean v7, v0, Lah4;->b0:Z

    iget-object v9, v0, Lah4;->c0:Ljava/lang/String;

    iget-boolean v11, v0, Lah4;->d0:Z

    move/from16 v18, v3

    move/from16 v19, v7

    move-object/from16 v20, v9

    move/from16 v21, v11

    move-object/from16 v17, v13

    invoke-direct/range {v16 .. v21}, Leh4;-><init>(Li3h;ZZLjava/lang/String;Z)V

    move-object/from16 v3, v16

    const v7, 0x7785eda1

    invoke-static {v7, v3, v1}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v11

    const/16 v19, 0x0

    const/16 v20, 0xa0

    move-object v3, v12

    const/4 v12, 0x0

    const/16 v18, 0x6000

    move/from16 v9, p1

    move-object/from16 v17, v1

    move-object v13, v4

    move-object v14, v5

    move-object/from16 v16, v6

    move-object v1, v8

    move-object v4, v15

    move-object/from16 v7, v25

    move-object/from16 v15, v26

    move-object/from16 v8, p2

    move-object v5, v3

    invoke-static/range {v7 .. v20}, Lhgg;->b(Ljava/lang/String;Ljmg;ZLa98;Lq98;Lt7c;Ljava/lang/String;Ljava/lang/String;La98;Lq98;Lzu4;III)V

    move-object/from16 v7, v17

    const/4 v14, 0x0

    invoke-virtual {v7, v14}, Leb8;->q(Z)V

    goto/16 :goto_52d

    :goto_222
    const v9, -0x484629b4

    invoke-virtual {v7, v9}, Leb8;->g0(I)V

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getSession_status()Lcom/anthropic/claude/sessions/types/SessionStatus;

    move-result-object v9

    sget-object v12, Lcom/anthropic/claude/sessions/types/SessionStatus;->PENDING:Lcom/anthropic/claude/sessions/types/SessionStatus;

    sget-object v13, Lgth;->a:Lgth;

    sget-object v14, Lhth;->a:Lhth;

    sget-object v15, Lcth;->a:Lcth;

    move/from16 v18, v6

    sget-object v6, Ldth;->a:Ldth;

    if-ne v9, v12, :cond_23f

    move-object v12, v15

    goto :goto_28f

    :cond_23f
    invoke-static {v1, v3}, Lcom/anthropic/claude/code/remote/b;->d(Lcom/anthropic/claude/sessions/types/SessionResource;Lui9;)Lbjg;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    if-eqz v9, :cond_28e

    const/4 v12, 0x1

    if-eq v9, v12, :cond_28c

    const/4 v12, 0x2

    if-eq v9, v12, :cond_25d

    const/4 v12, 0x3

    if-eq v9, v12, :cond_28e

    const/4 v12, 0x4

    if-eq v9, v12, :cond_28e

    const/4 v12, 0x5

    if-ne v9, v12, :cond_259

    goto :goto_28e

    :cond_259
    invoke-static {}, Le97;->d()V

    return-object v22

    :cond_25d
    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getPending_action()Lcom/anthropic/claude/sessions/types/RequiresActionDetails;

    move-result-object v9

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getSession_status()Lcom/anthropic/claude/sessions/types/SessionStatus;

    move-result-object v12

    move-object/from16 v16, v9

    sget-object v9, Lcom/anthropic/claude/sessions/types/SessionStatus;->REQUIRES_ACTION:Lcom/anthropic/claude/sessions/types/SessionStatus;

    if-ne v12, v9, :cond_26e

    move-object/from16 v9, v16

    goto :goto_270

    :cond_26e
    move-object/from16 v9, v22

    :goto_270
    if-nez v9, :cond_274

    :cond_272
    move-object v12, v6

    goto :goto_28f

    :cond_274
    invoke-virtual {v9}, Lcom/anthropic/claude/sessions/types/RequiresActionDetails;->isAskUserQuestion()Z

    move-result v12

    if-eqz v12, :cond_280

    new-instance v12, Lfth;

    invoke-direct {v12, v9}, Lfth;-><init>(Lcom/anthropic/claude/sessions/types/RequiresActionDetails;)V

    goto :goto_28f

    :cond_280
    invoke-virtual {v9}, Lcom/anthropic/claude/sessions/types/RequiresActionDetails;->isToolPermission()Z

    move-result v12

    if-eqz v12, :cond_272

    new-instance v12, Leth;

    invoke-direct {v12, v9}, Leth;-><init>(Lcom/anthropic/claude/sessions/types/RequiresActionDetails;)V

    goto :goto_28f

    :cond_28c
    move-object v12, v14

    goto :goto_28f

    :cond_28e
    :goto_28e
    move-object v12, v13

    :goto_28f
    invoke-virtual {v2}, Lcom/anthropic/claude/code/remote/a;->g0()Z

    move-result v9

    if-nez v9, :cond_29a

    :goto_295
    move-object/from16 v16, v10

    :cond_297
    move-object/from16 v9, v22

    goto :goto_2b4

    :cond_29a
    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getLinkedProjectId-v-f-JkQ()Ljava/lang/String;

    move-result-object v9

    if-nez v9, :cond_2a1

    goto :goto_295

    :cond_2a1
    move-object/from16 v16, v10

    iget-object v10, v2, Lcom/anthropic/claude/code/remote/a;->r:Lsbe;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v10, v10, Lsbe;->h:Lj4e;

    invoke-interface {v10, v9}, Lj4e;->b(Ljava/lang/String;)Lcom/anthropic/claude/api/project/Project;

    move-result-object v9

    if-eqz v9, :cond_297

    invoke-virtual {v9}, Lcom/anthropic/claude/api/project/Project;->getName()Ljava/lang/String;

    move-result-object v9

    :goto_2b4
    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getTitle()Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_2c1

    invoke-static {v10}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v19

    if-nez v19, :cond_2c1

    goto :goto_2c3

    :cond_2c1
    move-object/from16 v10, v22

    :goto_2c3
    if-nez v10, :cond_2f3

    const v10, 0x5ed6f66

    invoke-virtual {v7, v10}, Leb8;->g0(I)V

    sget-object v10, Lzk4;->a:Lfih;

    invoke-virtual {v7, v10}, Leb8;->j(Ldge;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lyk4;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    if-eqz v10, :cond_2e7

    const/4 v0, 0x1

    if-ne v10, v0, :cond_2e3

    const v0, 0x7f120ae0

    goto :goto_2ea

    :cond_2e3
    invoke-static {}, Le97;->d()V

    return-object v22

    :cond_2e7
    const v0, 0x7f120adf

    :goto_2ea
    invoke-static {v0, v7}, Lmhl;->Z(ILzu4;)Ljava/lang/String;

    move-result-object v10

    const/4 v0, 0x0

    invoke-virtual {v7, v0}, Leb8;->q(Z)V

    goto :goto_301

    :cond_2f3
    move-object/from16 p1, v10

    const/4 v0, 0x0

    const v10, 0x5ed6c9d

    invoke-virtual {v7, v10}, Leb8;->g0(I)V

    invoke-virtual {v7, v0}, Leb8;->q(Z)V

    move-object/from16 v10, p1

    :goto_301
    invoke-virtual {v12, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_30a

    sget-object v0, Lith;->E:Lith;

    goto :goto_332

    :cond_30a
    instance-of v0, v12, Lfth;

    if-eqz v0, :cond_311

    sget-object v0, Lith;->F:Lith;

    goto :goto_332

    :cond_311
    instance-of v0, v12, Leth;

    if-eqz v0, :cond_318

    sget-object v0, Lith;->G:Lith;

    goto :goto_332

    :cond_318
    invoke-virtual {v12, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_321

    sget-object v0, Lith;->H:Lith;

    goto :goto_332

    :cond_321
    invoke-virtual {v12, v15}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_32a

    sget-object v0, Lith;->I:Lith;

    goto :goto_332

    :cond_32a
    invoke-virtual {v12, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_651

    sget-object v0, Lith;->J:Lith;

    :goto_332
    invoke-virtual {v2, v1}, Lcom/anthropic/claude/code/remote/a;->i0(Lcom/anthropic/claude/sessions/types/SessionResource;)Z

    move-result v19

    invoke-virtual {v7, v2}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v20

    invoke-virtual {v7, v1}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v21

    or-int v20, v20, v21

    invoke-virtual {v7, v4}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v21

    or-int v20, v20, v21

    move-object/from16 p1, v0

    invoke-virtual {v7}, Leb8;->R()Ljava/lang/Object;

    move-result-object v0

    if-nez v20, :cond_354

    if-ne v0, v5, :cond_351

    goto :goto_354

    :cond_351
    move-object/from16 p2, v10

    goto :goto_35f

    :cond_354
    :goto_354
    new-instance v0, Lxg4;

    move-object/from16 p2, v10

    const/4 v10, 0x1

    invoke-direct {v0, v2, v1, v4, v10}, Lxg4;-><init>(Lcom/anthropic/claude/code/remote/a;Lcom/anthropic/claude/sessions/types/SessionResource;Lc98;I)V

    invoke-virtual {v7, v0}, Leb8;->q0(Ljava/lang/Object;)V

    :goto_35f
    check-cast v0, La98;

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getUpdated_at()Lui9;

    move-result-object v10

    invoke-static {v10, v3, v11, v7}, Lxjl;->o(Lui9;Lui9;Lzyg;Lzu4;)Ljava/lang/String;

    move-result-object v10

    if-eqz v18, :cond_36c

    goto :goto_36e

    :cond_36c
    move-object/from16 v17, v22

    :goto_36e
    invoke-virtual {v12, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3ad

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getPost_turn_summary()Lcom/anthropic/claude/sessions/types/PostTurnSummary;

    move-result-object v6

    if-eqz v6, :cond_38b

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/PostTurnSummary;->getNeeds_action()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_38b

    invoke-static {v6}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_387

    goto :goto_389

    :cond_387
    move-object/from16 v6, v22

    :goto_389
    if-nez v6, :cond_3a0

    :cond_38b
    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getPost_turn_summary()Lcom/anthropic/claude/sessions/types/PostTurnSummary;

    move-result-object v6

    if-eqz v6, :cond_39e

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/PostTurnSummary;->getStatus_detail()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_39e

    invoke-static {v6}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_39e

    goto :goto_3a0

    :cond_39e
    move-object/from16 v6, v22

    :cond_3a0
    :goto_3a0
    if-eqz v6, :cond_3a9

    new-instance v11, Lbth;

    invoke-direct {v11, v6}, Lbth;-><init>(Ljava/lang/String;)V

    goto/16 :goto_449

    :cond_3a9
    :goto_3a9
    move-object/from16 v11, v22

    goto/16 :goto_449

    :cond_3ad
    instance-of v6, v12, Lfth;

    if-eqz v6, :cond_40a

    check-cast v12, Lfth;

    iget-object v6, v12, Lfth;->a:Lcom/anthropic/claude/sessions/types/RequiresActionDetails;

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/RequiresActionDetails;->getAskUserQuestion()Lcom/anthropic/claude/sessions/types/AskUserQuestionInput;

    move-result-object v11

    if-eqz v11, :cond_3db

    invoke-virtual {v11}, Lcom/anthropic/claude/sessions/types/AskUserQuestionInput;->getQuestions()Ljava/util/List;

    move-result-object v11

    if-eqz v11, :cond_3db

    invoke-static {v11}, Lsm4;->v0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/anthropic/claude/sessions/types/AskUserQuestionQuestion;

    if-eqz v11, :cond_3db

    invoke-virtual {v11}, Lcom/anthropic/claude/sessions/types/AskUserQuestionQuestion;->getQuestion()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_3db

    invoke-static {v11}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_3d6

    goto :goto_3d8

    :cond_3d6
    move-object/from16 v11, v22

    :goto_3d8
    if-eqz v11, :cond_3db

    goto :goto_401

    :cond_3db
    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/RequiresActionDetails;->getAction_description()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_3e7

    move-object v11, v6

    goto :goto_3e9

    :cond_3e7
    move-object/from16 v11, v22

    :goto_3e9
    if-nez v11, :cond_401

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getPost_turn_summary()Lcom/anthropic/claude/sessions/types/PostTurnSummary;

    move-result-object v6

    if-eqz v6, :cond_3ff

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/PostTurnSummary;->getNeeds_action()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_3ff

    invoke-static {v6}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_3ff

    move-object v11, v6

    goto :goto_401

    :cond_3ff
    move-object/from16 v11, v22

    :cond_401
    :goto_401
    if-eqz v11, :cond_3a9

    new-instance v6, Lbth;

    invoke-direct {v6, v11}, Lbth;-><init>(Ljava/lang/String;)V

    :goto_408
    move-object v11, v6

    goto :goto_449

    :cond_40a
    instance-of v6, v12, Leth;

    if-eqz v6, :cond_431

    check-cast v12, Leth;

    iget-object v6, v12, Leth;->a:Lcom/anthropic/claude/sessions/types/RequiresActionDetails;

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/RequiresActionDetails;->getAction_description()Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_41d

    goto :goto_41f

    :cond_41d
    move-object/from16 v11, v22

    :goto_41f
    if-eqz v11, :cond_427

    new-instance v6, Lbth;

    invoke-direct {v6, v11}, Lbth;-><init>(Ljava/lang/String;)V

    goto :goto_408

    :cond_427
    new-instance v11, Lath;

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/RequiresActionDetails;->getDisplayName()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v11, v6}, Lath;-><init>(Ljava/lang/String;)V

    goto :goto_449

    :cond_431
    invoke-virtual {v12, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3a9

    invoke-virtual {v12, v15}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3a9

    invoke-virtual {v12, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_445

    goto/16 :goto_3a9

    :cond_445
    invoke-static {}, Le97;->d()V

    return-object v22

    :goto_449
    instance-of v6, v11, Lbth;

    if-eqz v6, :cond_472

    const v6, 0x634adec9

    invoke-virtual {v7, v6}, Leb8;->g0(I)V

    check-cast v11, Lbth;

    iget-object v6, v11, Lbth;->a:Ljava/lang/String;

    invoke-virtual {v7, v6}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v11

    invoke-virtual {v7}, Leb8;->R()Ljava/lang/Object;

    move-result-object v12

    if-nez v11, :cond_463

    if-ne v12, v5, :cond_46a

    :cond_463
    invoke-static {v6}, Lqf9;->c(Ljava/lang/String;)Lkd0;

    move-result-object v12

    invoke-virtual {v7, v12}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_46a
    check-cast v12, Lkd0;

    const/4 v14, 0x0

    invoke-virtual {v7, v14}, Leb8;->q(Z)V

    :goto_470
    move-object v15, v12

    goto :goto_4a3

    :cond_472
    instance-of v6, v11, Lath;

    if-eqz v6, :cond_495

    const v6, 0x5e0ab9ec

    invoke-virtual {v7, v6}, Leb8;->g0(I)V

    new-instance v12, Lkd0;

    check-cast v11, Lath;

    iget-object v6, v11, Lath;->a:Ljava/lang/String;

    filled-new-array {v6}, [Ljava/lang/Object;

    move-result-object v6

    const v11, 0x7f1209c5

    invoke-static {v11, v6, v7}, Lmhl;->a0(I[Ljava/lang/Object;Lzu4;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v12, v6}, Lkd0;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x0

    invoke-virtual {v7, v14}, Leb8;->q(Z)V

    goto :goto_470

    :cond_495
    const/4 v14, 0x0

    if-nez v11, :cond_648

    const v6, 0x634e4f9e

    invoke-virtual {v7, v6}, Leb8;->g0(I)V

    invoke-virtual {v7, v14}, Leb8;->q(Z)V

    move-object/from16 v15, v22

    :goto_4a3
    sget v6, Ltng;->b:I

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getUpdated_at()Lui9;

    move-result-object v6

    invoke-virtual {v3, v6}, Lui9;->a(Lui9;)J

    move-result-wide v11

    sget-wide v13, Ltng;->a:J

    invoke-static {v11, v12, v13, v14}, Lgr6;->d(JJ)I

    move-result v3

    if-gez v3, :cond_4b7

    move-object v3, v1

    goto :goto_4b9

    :cond_4b7
    move-object/from16 v3, v22

    :goto_4b9
    if-eqz v3, :cond_4c8

    invoke-virtual {v3}, Lcom/anthropic/claude/sessions/types/SessionResource;->getTask_summary()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_4c8

    invoke-static {v3}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_4c8

    goto :goto_4ca

    :cond_4c8
    move-object/from16 v3, v22

    :goto_4ca
    if-eqz v8, :cond_4e5

    const v6, -0x48315519

    invoke-virtual {v7, v6}, Leb8;->g0(I)V

    new-instance v6, Lhf;

    const/16 v9, 0x1d

    invoke-direct {v6, v9, v8}, Lhf;-><init>(ILjava/lang/Object;)V

    const v8, 0x26d416cd

    invoke-static {v8, v6, v7}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v6

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Leb8;->q(Z)V

    goto :goto_50b

    :cond_4e5
    const/4 v8, 0x0

    if-eqz v9, :cond_500

    const v6, -0x482fcce0

    invoke-virtual {v7, v6}, Leb8;->g0(I)V

    new-instance v6, Lre;

    const/16 v11, 0x10

    invoke-direct {v6, v9, v11}, Lre;-><init>(Ljava/lang/String;I)V

    const v9, -0x2e5cccbc

    invoke-static {v9, v6, v7}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v6

    invoke-virtual {v7, v8}, Leb8;->q(Z)V

    goto :goto_50b

    :cond_500
    const v6, -0x482e6b49

    invoke-virtual {v7, v6}, Leb8;->g0(I)V

    invoke-virtual {v7, v8}, Leb8;->q(Z)V

    move-object/from16 v6, v22

    :goto_50b
    const/16 v20, 0x0

    const/16 v21, 0x20

    const/4 v12, 0x0

    move/from16 v9, v19

    const/16 v19, 0x0

    move-object v11, v0

    move-object/from16 v18, v7

    move v0, v8

    move-object v13, v10

    move-object/from16 v10, v16

    move-object/from16 v14, v17

    move-object/from16 v8, p1

    move-object/from16 v7, p2

    move-object/from16 v16, v3

    move-object/from16 v17, v6

    invoke-static/range {v7 .. v21}, Lhgg;->l(Ljava/lang/String;Lith;ZLa98;La98;Lt7c;Ljava/lang/String;La98;Lkd0;Ljava/lang/String;Lq98;Lzu4;III)V

    move-object/from16 v7, v18

    invoke-virtual {v7, v0}, Leb8;->q(Z)V

    :goto_52d
    invoke-static {v1}, Lcom/anthropic/claude/code/remote/b;->b(Lcom/anthropic/claude/sessions/types/SessionResource;)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v0, p0

    iget-object v3, v0, Lah4;->S:Lu9j;

    invoke-virtual {v7, v3}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v6

    invoke-virtual {v7}, Leb8;->R()Ljava/lang/Object;

    move-result-object v8

    if-nez v6, :cond_541

    if-ne v8, v5, :cond_54a

    :cond_541
    new-instance v8, Lfh4;

    const/4 v14, 0x0

    invoke-direct {v8, v3, v14}, Lfh4;-><init>(Lu9j;I)V

    invoke-virtual {v7, v8}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_54a
    move-object/from16 v16, v8

    check-cast v16, Lc98;

    invoke-virtual {v2}, Lcom/anthropic/claude/code/remote/a;->g0()Z

    move-result v3

    if-eqz v3, :cond_55f

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->isCoworkRemote()Z

    move-result v3

    if-eqz v3, :cond_55f

    iget-object v3, v0, Lah4;->V:La98;

    move-object/from16 v19, v3

    goto :goto_561

    :cond_55f
    move-object/from16 v19, v22

    :goto_561
    invoke-virtual {v7, v2}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v3

    invoke-virtual {v7, v1}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v3, v6

    invoke-virtual {v7, v4}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v3, v6

    invoke-virtual {v7}, Leb8;->R()Ljava/lang/Object;

    move-result-object v6

    if-nez v3, :cond_577

    if-ne v6, v5, :cond_580

    :cond_577
    new-instance v6, Lxg4;

    const/4 v12, 0x3

    invoke-direct {v6, v2, v1, v4, v12}, Lxg4;-><init>(Lcom/anthropic/claude/code/remote/a;Lcom/anthropic/claude/sessions/types/SessionResource;Lc98;I)V

    invoke-virtual {v7, v6}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_580
    check-cast v6, La98;

    invoke-virtual {v2}, Lcom/anthropic/claude/code/remote/a;->g0()Z

    move-result v3

    if-eqz v3, :cond_591

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->isCoworkRemote()Z

    move-result v3

    if-eqz v3, :cond_591

    move-object/from16 v20, v6

    goto :goto_593

    :cond_591
    move-object/from16 v20, v22

    :goto_593
    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getLinkedProjectId-v-f-JkQ()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_59c

    const/16 v21, 0x1

    goto :goto_59e

    :cond_59c
    const/16 v21, 0x0

    :goto_59e
    iget-boolean v3, v0, Lah4;->W:Z

    if-eqz v3, :cond_5a5

    iget-object v6, v0, Lah4;->X:La98;

    goto :goto_5a7

    :cond_5a5
    move-object/from16 v6, v22

    :goto_5a7
    if-eqz v3, :cond_5d4

    const v8, -0x4802a00f

    invoke-virtual {v7, v8}, Leb8;->g0(I)V

    invoke-virtual {v7, v2}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v8

    invoke-virtual {v7, v1}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v8, v9

    invoke-virtual {v7, v4}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v8, v9

    invoke-virtual {v7}, Leb8;->R()Ljava/lang/Object;

    move-result-object v9

    if-nez v8, :cond_5c5

    if-ne v9, v5, :cond_5cd

    :cond_5c5
    new-instance v9, Loh4;

    invoke-direct {v9, v2, v1, v4}, Loh4;-><init>(Lcom/anthropic/claude/code/remote/a;Lcom/anthropic/claude/sessions/types/SessionResource;Lc98;)V

    invoke-virtual {v7, v9}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_5cd
    check-cast v9, Lfz9;

    const/4 v14, 0x0

    invoke-virtual {v7, v14}, Leb8;->q(Z)V

    goto :goto_5e0

    :cond_5d4
    const/4 v14, 0x0

    const v4, -0x48025f09

    invoke-virtual {v7, v4}, Leb8;->g0(I)V

    invoke-virtual {v7, v14}, Leb8;->q(Z)V

    move-object/from16 v9, v22

    :goto_5e0
    check-cast v9, La98;

    iget-object v4, v2, Lcom/anthropic/claude/code/remote/a;->k:Ltoi;

    iget-object v4, v4, Ltoi;->H:Lghh;

    invoke-interface {v4}, Lghh;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-nez v4, :cond_5f5

    :goto_5f2
    move-object/from16 v24, v22

    goto :goto_61c

    :cond_5f5
    if-nez v3, :cond_5f8

    goto :goto_5f2

    :cond_5f8
    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SessionResource;->getId-Ocx55TE()Ljava/lang/String;

    move-result-object v1

    iget-object v2, v2, Lcom/anthropic/claude/code/remote/a;->C:Ltad;

    invoke-virtual {v2}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/anthropic/claude/types/strings/SessionId;

    if-eqz v2, :cond_60b

    invoke-virtual {v2}, Lcom/anthropic/claude/types/strings/SessionId;->unbox-impl()Ljava/lang/String;

    move-result-object v2

    goto :goto_60d

    :cond_60b
    move-object/from16 v2, v22

    :goto_60d
    if-nez v2, :cond_611

    const/4 v5, 0x0

    goto :goto_615

    :cond_611
    invoke-static {v1, v2}, Lcom/anthropic/claude/types/strings/SessionId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    :goto_615
    if-eqz v5, :cond_618

    goto :goto_5f2

    :cond_618
    iget-object v1, v0, Lah4;->Y:La98;

    move-object/from16 v24, v1

    :goto_61c
    const/16 v26, 0x0

    move-object/from16 v17, v7

    iget-boolean v7, v0, Lah4;->K:Z

    iget-boolean v8, v0, Lah4;->L:Z

    move-object/from16 v23, v9

    iget-boolean v9, v0, Lah4;->M:Z

    iget-object v11, v0, Lah4;->N:Ljava/lang/String;

    iget-object v12, v0, Lah4;->O:La98;

    iget-boolean v13, v0, Lah4;->P:Z

    iget-object v14, v0, Lah4;->Q:La98;

    iget-object v15, v0, Lah4;->R:Lc98;

    iget-object v1, v0, Lah4;->T:La98;

    iget-object v0, v0, Lah4;->U:La98;

    move-object/from16 v18, v0

    move-object/from16 v22, v6

    move-object/from16 v25, v17

    move-object/from16 v17, v1

    invoke-static/range {v7 .. v26}, Lcom/anthropic/claude/code/remote/c;->m(ZZZLjava/lang/String;Ljava/lang/String;La98;ZLa98;Lc98;Lc98;La98;La98;La98;La98;ZLa98;La98;La98;Lzu4;I)V

    move-object/from16 v7, v25

    const/4 v0, 0x1

    invoke-virtual {v7, v0}, Leb8;->q(Z)V

    goto :goto_659

    :cond_648
    const v0, 0x5e0aa31c

    const/4 v14, 0x0

    invoke-static {v7, v0, v14}, Lwsg;->w(Leb8;IZ)Lkotlin/NoWhenBranchMatchedException;

    move-result-object v0

    throw v0

    :cond_651
    invoke-static {}, Le97;->d()V

    return-object v22

    :cond_655
    move-object v7, v1

    invoke-virtual {v7}, Leb8;->Z()V

    :goto_659
    sget-object v0, Lz2j;->a:Lz2j;

    return-object v0
.end method
