.class public final Lb2f;
.super Lc75;
.source "SourceFile"


# instance fields
.field public synthetic E:Ljava/lang/Object;

.field public final synthetic F:Lo09;

.field public G:I


# direct methods
.method public constructor <init>(Lo09;Lc75;)V
    .registers 3

    iput-object p1, p0, Lb2f;->F:Lo09;

    invoke-direct {p0, p2}, Lc75;-><init>(La75;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lb2f;->E:Ljava/lang/Object;

    iget p1, p0, Lb2f;->G:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lb2f;->G:I

    iget-object p1, p0, Lb2f;->F:Lo09;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lo09;->b(FLc75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
