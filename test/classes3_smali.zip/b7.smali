.class public abstract Lb7;
.super Landroid/webkit/WebViewClient;
.source "SourceFile"


# static fields
.field public static final synthetic d:I

.field public static final synthetic e:I


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    .line 12
    const/4 v0, 0x0

    iput v0, p0, Lb7;->a:I

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method

.method public constructor <init>(Lptf;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, Lb7;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    iput-object p1, p0, Lb7;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a()Lqzj;
    .registers 1

    iget-object p0, p0, Lb7;->b:Ljava/lang/Object;

    check-cast p0, Lqzj;

    if-eqz p0, :cond_7

    return-object p0

    :cond_7
    const-string p0, "state"

    invoke-static {p0}, Lbo9;->z0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public b(Landroid/net/Uri;)Landroid/webkit/WebResourceResponse;
    .registers 2

    const/4 p0, 0x0

    return-object p0
.end method

.method public abstract c(Landroid/net/Uri;)Z
.end method

.method public doUpdateVisitedHistory(Landroid/webkit/WebView;Ljava/lang/String;Z)V
    .registers 6

    iget v0, p0, Lb7;->a:I

    packed-switch v0, :pswitch_data_42

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->doUpdateVisitedHistory(Landroid/webkit/WebView;Ljava/lang/String;Z)V

    return-void

    :pswitch_9  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->doUpdateVisitedHistory(Landroid/webkit/WebView;Ljava/lang/String;Z)V

    iget-object p2, p0, Lb7;->c:Ljava/lang/Object;

    check-cast p2, Ldzj;

    const/4 p3, 0x0

    const-string v0, "navigator"

    if-eqz p2, :cond_3d

    invoke-virtual {p1}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v1

    iget-object p2, p2, Ldzj;->b:Ltad;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {p2, v1}, Ltad;->setValue(Ljava/lang/Object;)V

    iget-object p0, p0, Lb7;->c:Ljava/lang/Object;

    check-cast p0, Ldzj;

    if-eqz p0, :cond_39

    invoke-virtual {p1}, Landroid/webkit/WebView;->canGoForward()Z

    move-result p1

    iget-object p0, p0, Ldzj;->c:Ltad;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void

    :cond_39
    invoke-static {v0}, Lbo9;->z0(Ljava/lang/String;)V

    throw p3

    :cond_3d
    invoke-static {v0}, Lbo9;->z0(Ljava/lang/String;)V

    throw p3

    nop

    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_9  #00000000
    .end packed-switch
.end method

.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .registers 4

    iget v0, p0, Lb7;->a:I

    packed-switch v0, :pswitch_data_1c

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    return-void

    :pswitch_9  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    invoke-virtual {p0}, Lb7;->a()Lqzj;

    move-result-object p0

    sget-object p1, Lxpa;->a:Lxpa;

    iget-object p0, p0, Lqzj;->c:Ltad;

    invoke-virtual {p0, p1}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void

    nop

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_9  #00000000
    .end packed-switch
.end method

.method public onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .registers 5

    iget v0, p0, Lb7;->a:I

    packed-switch v0, :pswitch_data_2e

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V

    return-void

    :pswitch_9  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V

    invoke-virtual {p0}, Lb7;->a()Lqzj;

    move-result-object p1

    sget-object p3, Lzpa;->a:Lzpa;

    iget-object p1, p1, Lqzj;->c:Ltad;

    invoke-virtual {p1, p3}, Ltad;->setValue(Ljava/lang/Object;)V

    invoke-virtual {p0}, Lb7;->a()Lqzj;

    move-result-object p1

    iget-object p1, p1, Lqzj;->d:Lq7h;

    invoke-virtual {p1}, Lq7h;->clear()V

    invoke-virtual {p0}, Lb7;->a()Lqzj;

    move-result-object p0

    iget-object p0, p0, Lqzj;->a:Ltad;

    invoke-virtual {p0, p2}, Ltad;->setValue(Ljava/lang/Object;)V

    return-void

    nop

    :pswitch_data_2e
    .packed-switch 0x0
        :pswitch_9  #00000000
    .end packed-switch
.end method

.method public onReceivedError(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;Landroid/webkit/WebResourceError;)V
    .registers 5

    iget v0, p0, Lb7;->a:I

    packed-switch v0, :pswitch_data_20

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onReceivedError(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;Landroid/webkit/WebResourceError;)V

    return-void

    :pswitch_9  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onReceivedError(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;Landroid/webkit/WebResourceError;)V

    if-eqz p3, :cond_1f

    invoke-virtual {p0}, Lb7;->a()Lqzj;

    move-result-object p0

    iget-object p0, p0, Lqzj;->d:Lq7h;

    new-instance p1, Lpyj;

    invoke-direct {p1, p2, p3}, Lpyj;-><init>(Landroid/webkit/WebResourceRequest;Landroid/webkit/WebResourceError;)V

    invoke-virtual {p0, p1}, Lq7h;->add(Ljava/lang/Object;)Z

    :cond_1f
    return-void

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_9  #00000000
    .end packed-switch
.end method

.method public onRenderProcessGone(Landroid/webkit/WebView;Landroid/webkit/RenderProcessGoneDetail;)Z
    .registers 13

    iget v0, p0, Lb7;->a:I

    packed-switch v0, :pswitch_data_96

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onRenderProcessGone(Landroid/webkit/WebView;Landroid/webkit/RenderProcessGoneDetail;)Z

    move-result p0

    return p0

    :pswitch_a  #0x1
    iget-object v0, p0, Lb7;->b:Ljava/lang/Object;

    check-cast v0, Lptf;

    const/4 v1, 0x0

    if-eqz p2, :cond_16

    invoke-virtual {p2}, Landroid/webkit/RenderProcessGoneDetail;->didCrash()Z

    move-result v2

    goto :goto_17

    :cond_16
    move v2, v1

    :goto_17
    iget-object v3, v0, Lptf;->c:Ldk0;

    invoke-virtual {v3}, Ldk0;->b()Z

    move-result v3

    iget-object v4, v0, Lptf;->b:Let3;

    new-instance v5, Lcom/anthropic/claude/analytics/events/WebViewEvents$WebViewRenderProcessGone;

    iget-object v6, v0, Lptf;->a:Lcom/anthropic/claude/analytics/events/WebViewEvents$WebViewKind;

    if-eqz p2, :cond_2a

    invoke-virtual {p2}, Landroid/webkit/RenderProcessGoneDetail;->didCrash()Z

    move-result v7

    goto :goto_2b

    :cond_2a
    move v7, v1

    :goto_2b
    const/4 v8, 0x0

    if-eqz p2, :cond_37

    invoke-virtual {p2}, Landroid/webkit/RenderProcessGoneDetail;->rendererPriorityAtExit()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    goto :goto_38

    :cond_37
    move-object v9, v8

    :goto_38
    iget-object v0, v0, Lptf;->c:Ldk0;

    invoke-virtual {v0}, Ldk0;->b()Z

    move-result v0

    invoke-direct {v5, v6, v7, v9, v0}, Lcom/anthropic/claude/analytics/events/WebViewEvents$WebViewRenderProcessGone;-><init>(Lcom/anthropic/claude/analytics/events/WebViewEvents$WebViewKind;ZLjava/lang/Integer;Z)V

    sget-object v0, Lcom/anthropic/claude/analytics/events/WebViewEvents$WebViewRenderProcessGone;->Companion:Luyj;

    invoke-virtual {v0}, Luyj;->serializer()Lkotlinx/serialization/KSerializer;

    move-result-object v0

    check-cast v0, Lpeg;

    invoke-interface {v4, v5, v0}, Let3;->f(Lcom/anthropic/claude/analytics/events/AnalyticsEvent;Lpeg;)V

    if-nez v2, :cond_50

    if-eqz v3, :cond_82

    :cond_50
    new-instance v0, Lcom/anthropic/claude/core/telemetry/SilentException;

    if-eqz p2, :cond_5d

    invoke-virtual {p2}, Landroid/webkit/RenderProcessGoneDetail;->rendererPriorityAtExit()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    goto :goto_5e

    :cond_5d
    move-object p2, v8

    :goto_5e
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "WebView render process gone: didCrash="

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v4, ", rendererPriority="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {v0, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    if-eqz v2, :cond_7c

    sget-object p2, Lhsg;->G:Lhsg;

    goto :goto_7e

    :cond_7c
    sget-object p2, Lhsg;->F:Lhsg;

    :goto_7e
    const/4 v3, 0x6

    invoke-static {v0, p2, v1, v8, v3}, Lcom/anthropic/claude/core/telemetry/SilentException;->a(Lcom/anthropic/claude/core/telemetry/SilentException;Lhsg;ZLjava/util/List;I)V

    :cond_82
    if-eqz p1, :cond_87

    invoke-virtual {p1}, Landroid/webkit/WebView;->destroy()V

    :cond_87
    iget-object p0, p0, Lb7;->c:Ljava/lang/Object;

    check-cast p0, Lq98;

    if-eqz p0, :cond_94

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_94
    const/4 p0, 0x1

    return p0

    :pswitch_data_96
    .packed-switch 0x1
        :pswitch_a  #00000001
    .end packed-switch
.end method

.method public shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;
    .registers 4

    iget v0, p0, Lb7;->a:I

    packed-switch v0, :pswitch_data_36

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x1
    if-eqz p2, :cond_1a

    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lb7;->b(Landroid/net/Uri;)Landroid/webkit/WebResourceResponse;

    move-result-object p1

    if-eqz p1, :cond_1a

    goto :goto_35

    :cond_1a
    const/4 p1, 0x0

    if-eqz p2, :cond_2b

    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p2}, Lb7;->c(Landroid/net/Uri;)Z

    move-result p0

    if-eqz p0, :cond_2b

    goto :goto_35

    :cond_2b
    new-instance p0, Landroid/webkit/WebResourceResponse;

    const-string p2, "text/plain"

    const-string v0, "UTF-8"

    invoke-direct {p0, p2, v0, p1}, Landroid/webkit/WebResourceResponse;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/io/InputStream;)V

    move-object p1, p0

    :goto_35
    return-object p1

    :pswitch_data_36
    .packed-switch 0x1
        :pswitch_a  #00000001
    .end packed-switch
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z
    .registers 4

    iget v0, p0, Lb7;->a:I

    packed-switch v0, :pswitch_data_c

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z

    move-result p0

    return p0

    :pswitch_a  #0x1
    const/4 p0, 0x1

    return p0

    :pswitch_data_c
    .packed-switch 0x1
        :pswitch_a  #00000001
    .end packed-switch
.end method
