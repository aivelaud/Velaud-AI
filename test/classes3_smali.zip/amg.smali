.class public final Lamg;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lgmg;


# instance fields
.field public final a:Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;


# direct methods
.method public constructor <init>(Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lamg;->a:Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;

    return-void
.end method


# virtual methods
.method public final a()Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;
    .registers 1

    iget-object p0, p0, Lamg;->a:Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lamg;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lamg;

    iget-object p0, p0, Lamg;->a:Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;

    iget-object p1, p1, Lamg;->a:Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_17

    return v2

    :cond_17
    return v0
.end method

.method public final hashCode()I
    .registers 1

    iget-object p0, p0, Lamg;->a:Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;

    invoke-virtual {p0}, Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;->hashCode()I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "CatchUpTruncated(truncated="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lamg;->a:Lcom/anthropic/claude/sessions/types/StreamCatchUpTruncatedV2;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
