.class public final Lagd;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/String;)Lcom/anthropic/claude/sessions/types/PermissionMode;
    .registers 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_54

    goto :goto_4f

    :sswitch_b
    const-string v0, "dontAsk"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_14

    goto :goto_4f

    :cond_14
    sget-object p0, Lcom/anthropic/claude/sessions/types/PermissionMode;->DontAsk:Lcom/anthropic/claude/sessions/types/PermissionMode;

    return-object p0

    :sswitch_17
    const-string v0, "default"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_20

    goto :goto_4f

    :cond_20
    sget-object p0, Lcom/anthropic/claude/sessions/types/PermissionMode;->Default:Lcom/anthropic/claude/sessions/types/PermissionMode;

    return-object p0

    :sswitch_23
    const-string v0, "acceptEdits"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2c

    goto :goto_4f

    :cond_2c
    sget-object p0, Lcom/anthropic/claude/sessions/types/PermissionMode;->AcceptEdits:Lcom/anthropic/claude/sessions/types/PermissionMode;

    return-object p0

    :sswitch_2f
    const-string v0, "plan"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_38

    goto :goto_4f

    :cond_38
    sget-object p0, Lcom/anthropic/claude/sessions/types/PermissionMode;->Plan:Lcom/anthropic/claude/sessions/types/PermissionMode;

    return-object p0

    :sswitch_3b
    const-string v0, "auto"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_44

    goto :goto_4f

    :cond_44
    sget-object p0, Lcom/anthropic/claude/sessions/types/PermissionMode;->Auto:Lcom/anthropic/claude/sessions/types/PermissionMode;

    return-object p0

    :sswitch_47
    const-string v0, "bypassPermissions"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_51

    :goto_4f
    const/4 p0, 0x0

    return-object p0

    :cond_51
    sget-object p0, Lcom/anthropic/claude/sessions/types/PermissionMode;->BypassPermissions:Lcom/anthropic/claude/sessions/types/PermissionMode;

    return-object p0

    :sswitch_data_54
    .sparse-switch
        -0x5b597184 -> :sswitch_47
        0x2dddaf -> :sswitch_3b
        0x348b29 -> :sswitch_2f
        0x24039381 -> :sswitch_23
        0x5c13d641 -> :sswitch_17
        0x6d9ce928 -> :sswitch_b
    .end sparse-switch
.end method


# virtual methods
.method public final serializer()Lkotlinx/serialization/KSerializer;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/serialization/KSerializer;"
        }
    .end annotation

    sget-object p0, Lhgd;->d:Lhgd;

    return-object p0
.end method
