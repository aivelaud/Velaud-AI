.class public final Laxh;
.super Ln5a;
.source "SourceFile"

# interfaces
.implements La98;


# static fields
.field public static final G:Laxh;

.field public static final H:Laxh;

.field public static final I:Laxh;

.field public static final J:Laxh;

.field public static final K:Laxh;

.field public static final L:Laxh;

.field public static final M:Laxh;

.field public static final N:Laxh;

.field public static final O:Laxh;

.field public static final P:Laxh;

.field public static final Q:Laxh;

.field public static final R:Laxh;

.field public static final S:Laxh;

.field public static final T:Laxh;

.field public static final U:Laxh;

.field public static final V:Laxh;

.field public static final W:Laxh;

.field public static final X:Laxh;

.field public static final Y:Laxh;

.field public static final Z:Laxh;

.field public static final a0:Laxh;


# instance fields
.field public final synthetic F:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 3

    new-instance v0, Laxh;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->G:Laxh;

    new-instance v0, Laxh;

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->H:Laxh;

    new-instance v0, Laxh;

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->I:Laxh;

    new-instance v0, Laxh;

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->J:Laxh;

    new-instance v0, Laxh;

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->K:Laxh;

    new-instance v0, Laxh;

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->L:Laxh;

    new-instance v0, Laxh;

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->M:Laxh;

    new-instance v0, Laxh;

    const/4 v2, 0x7

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->N:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0x8

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->O:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0x9

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->P:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0xa

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->Q:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0xb

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->R:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0xc

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->S:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0xd

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->T:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0xe

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->U:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0xf

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->V:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0x10

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->W:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0x11

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->X:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0x12

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->Y:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0x13

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->Z:Laxh;

    new-instance v0, Laxh;

    const/16 v2, 0x14

    invoke-direct {v0, v1, v2}, Laxh;-><init>(II)V

    sput-object v0, Laxh;->a0:Laxh;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/16 v0, 0x18

    iput v0, p0, Laxh;->F:I

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Ln5a;-><init>(I)V

    return-void
.end method

.method public synthetic constructor <init>(II)V
    .registers 3

    .line 9
    iput p2, p0, Laxh;->F:I

    invoke-direct {p0, p1}, Ln5a;-><init>(I)V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 10
    iput p1, p0, Laxh;->F:I

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Ln5a;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 4

    iget p0, p0, Laxh;->F:I

    const-string v0, "Thread was unable to set its own interrupted state"

    const/4 v1, 0x1

    packed-switch p0, :pswitch_data_7e

    const-string p0, "Problem retrieving system value for screen_brightness"

    return-object p0

    :pswitch_b  #0x17
    const/4 p0, 0x0

    throw p0

    :pswitch_d  #0x16
    const-class p0, Lxs5;

    invoke-virtual {p0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p0

    const-string v0, "You\'re trying to create an DatadogTracer instance, but provided "

    const-string v1, " writer wrapper is not supported."

    invoke-static {v0, p0, v1}, Lb40;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_1c  #0x15
    sget-object p0, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-class v0, Lbah;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "Error serializing %s model"

    invoke-static {p0, v1, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_33  #0x14
    const-string p0, "Write operation ignored, session is expired or RUM feature is disabled."

    return-object p0

    :pswitch_36  #0x13
    const-string p0, "Write operation failed, but no onError callback was provided."

    return-object p0

    :pswitch_39  #0x12
    const-string p0, "Write operation failed."

    return-object p0

    :pswitch_3c  #0x11
    const-string p0, "Error while trying to setup the UploadWorker"

    return-object p0

    :pswitch_3f  #0x10
    const-string p0, "UploadWorker was scheduled."

    return-object p0

    :pswitch_42  #0xf
    const-string p0, "Error cancelling the UploadWorker"

    return-object p0

    :pswitch_45  #0xe
    const-string p0, "Can\'t wipe data from a null directory"

    return-object p0

    :pswitch_48  #0xd
    const-string p0, "Wrapped Window.Callback failed processing event"

    return-object p0

    :pswitch_4b  #0xc
    const-string p0, "Received null MotionEvent"

    return-object p0

    :pswitch_4e  #0xb
    const-string p0, "Error processing MotionEvent"

    return-object p0

    :pswitch_51  #0xa
    const-string p0, "Received null KeyEvent"

    return-object p0

    :pswitch_54  #0x9
    const-string p0, "Trying to send \'view ended\' more than once"

    return-object p0

    :pswitch_57  #0x8
    const-string p0, "Datadog has not been initialized."

    return-object p0

    :pswitch_5a  #0x7
    new-instance p0, Ljava/util/Timer;

    const-class v0, Lxgi;

    sget-object v2, Loze;->a:Lpze;

    invoke-virtual {v2, v0}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v0

    invoke-interface {v0}, Lky9;->d()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, v1}, Ljava/util/Timer;-><init>(Ljava/lang/String;Z)V

    return-object p0

    :pswitch_6c  #0x6
    const-string p0, "Thread tried to sleep for a negative amount of time"

    return-object p0

    :pswitch_6f  #0x5
    return-object v0

    :pswitch_70  #0x4
    const-string p0, "Uncaught exception during the task execution"

    return-object p0

    :pswitch_73  #0x3
    return-object v0

    :pswitch_74  #0x2
    const-string p0, "GlobalDatadogTracer class exists in the runtime classpath, but there is an error invoking getOrNull method"

    return-object p0

    :pswitch_77  #0x1
    const-string p0, "Max number of telemetry events per session reached, rejecting."

    return-object p0

    :pswitch_7a  #0x0
    const-string p0, "Failed to deserialize TLV data length"

    return-object p0

    nop

    :pswitch_data_7e
    .packed-switch 0x0
        :pswitch_7a  #00000000
        :pswitch_77  #00000001
        :pswitch_74  #00000002
        :pswitch_73  #00000003
        :pswitch_70  #00000004
        :pswitch_6f  #00000005
        :pswitch_6c  #00000006
        :pswitch_5a  #00000007
        :pswitch_57  #00000008
        :pswitch_54  #00000009
        :pswitch_51  #0000000a
        :pswitch_4e  #0000000b
        :pswitch_4b  #0000000c
        :pswitch_48  #0000000d
        :pswitch_45  #0000000e
        :pswitch_42  #0000000f
        :pswitch_3f  #00000010
        :pswitch_3c  #00000011
        :pswitch_39  #00000012
        :pswitch_36  #00000013
        :pswitch_33  #00000014
        :pswitch_1c  #00000015
        :pswitch_d  #00000016
        :pswitch_b  #00000017
    .end packed-switch
.end method
