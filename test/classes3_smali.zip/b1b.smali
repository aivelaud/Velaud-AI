.class public final synthetic Lb1b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 10
    iput p1, p0, Lb1b;->E:I

    iput-object p2, p0, Lb1b;->F:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lio/sentry/android/core/a;Lio/sentry/z1;)V
    .registers 3

    const/16 p2, 0x11

    iput p2, p0, Lb1b;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb1b;->F:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lio/sentry/android/core/g0;Lio/sentry/android/core/f0;)V
    .registers 3

    .line 11
    const/16 p1, 0x15

    iput p1, p0, Lb1b;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lb1b;->F:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 33

    move-object/from16 v0, p0

    iget v1, v0, Lb1b;->E:I

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    packed-switch v1, :pswitch_data_6b6

    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lin;

    iget-object v1, v0, Lin;->I:Ljava/lang/Object;

    check-cast v1, Lio/sentry/n5;

    iget-object v0, v0, Lin;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/SentryAndroidOptions;

    invoke-virtual {v0}, Lio/sentry/w6;->getShutdownTimeoutMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lio/sentry/n5;->a(J)V

    return-void

    :pswitch_1f  #0x1c
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/logger/c;

    iget-object v1, v0, Lio/sentry/logger/c;->H:Lio/sentry/n5;

    iget-object v0, v0, Lio/sentry/logger/c;->E:Lio/sentry/android/core/SentryAndroidOptions;

    invoke-virtual {v0}, Lio/sentry/w6;->getShutdownTimeoutMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lio/sentry/n5;->a(J)V

    return-void

    :pswitch_2f  #0x1b
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/replay/screenshot/h;

    iget-object v1, v0, Lio/sentry/android/replay/screenshot/h;->g:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v1

    if-nez v1, :cond_52

    iget-object v1, v0, Lio/sentry/android/replay/screenshot/h;->g:Landroid/graphics/Bitmap;

    monitor-enter v1

    :try_start_3e
    iget-object v2, v0, Lio/sentry/android/replay/screenshot/h;->g:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v2

    if-nez v2, :cond_4e

    iget-object v2, v0, Lio/sentry/android/replay/screenshot/h;->g:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V
    :try_end_4b
    .catchall {:try_start_3e .. :try_end_4b} :catchall_4c

    goto :goto_4e

    :catchall_4c
    move-exception v0

    goto :goto_50

    :cond_4e
    :goto_4e
    monitor-exit v1

    goto :goto_52

    :goto_50
    monitor-exit v1

    throw v0

    :cond_52
    :goto_52
    iget-object v0, v0, Lio/sentry/android/replay/screenshot/h;->j:Lio/sentry/android/replay/util/c;

    invoke-virtual {v0}, Lio/sentry/android/replay/util/c;->close()V

    return-void

    :pswitch_58  #0x1a
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/replay/v;

    iget-object v1, v0, Lio/sentry/android/replay/v;->E:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_65

    goto :goto_9f

    :cond_65
    :try_start_65
    sget-object v1, Lio/sentry/android/replay/c0;->b:Lj9a;

    invoke-interface {v1}, Lj9a;->getValue()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_9f

    sget-object v2, Lio/sentry/android/replay/c0;->c:Lj9a;

    invoke-interface {v2}, Lj9a;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/reflect/Field;

    if-eqz v2, :cond_9f

    invoke-virtual {v2, v1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v3, Ljava/util/ArrayList;

    iget-object v4, v0, Lio/sentry/android/replay/v;->F:Lio/sentry/util/a;

    invoke-virtual {v4}, Lio/sentry/util/a;->b()V
    :try_end_85
    .catchall {:try_start_65 .. :try_end_85} :catchall_99

    :try_start_85
    iget-object v0, v0, Lio/sentry/android/replay/v;->H:Lio/sentry/android/replay/t;

    invoke-virtual {v0, v3}, Lio/sentry/android/replay/t;->addAll(Ljava/util/Collection;)Z
    :try_end_8a
    .catchall {:try_start_85 .. :try_end_8a} :catchall_91

    :try_start_8a
    invoke-static {v4, v5}, Lr1i;->m(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    invoke-virtual {v2, v1, v0}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_90
    .catchall {:try_start_8a .. :try_end_90} :catchall_99

    goto :goto_9f

    :catchall_91
    move-exception v0

    move-object v1, v0

    :try_start_93
    throw v1
    :try_end_94
    .catchall {:try_start_93 .. :try_end_94} :catchall_94

    :catchall_94
    move-exception v0

    :try_start_95
    invoke-static {v4, v1}, Lr1i;->m(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw v0
    :try_end_99
    .catchall {:try_start_95 .. :try_end_99} :catchall_99

    :catchall_99
    move-exception v0

    const-string v1, "WindowManagerSpy"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_9f
    :goto_9f
    return-void

    :pswitch_a0  #0x19
    sget-object v18, Lyv6;->E:Lyv6;

    const-string v1, ""

    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/replay/ReplayIntegration;

    const-string v7, "options"

    iget-object v8, v0, Lio/sentry/android/replay/ReplayIntegration;->H:Lio/sentry/android/core/SentryAndroidOptions;

    if-eqz v8, :cond_3af

    invoke-virtual {v8}, Lio/sentry/w6;->findPersistingScopeObserver()Lio/sentry/cache/f;

    move-result-object v8

    if-eqz v8, :cond_3ab

    iget-object v9, v0, Lio/sentry/android/replay/ReplayIntegration;->H:Lio/sentry/android/core/SentryAndroidOptions;

    if-eqz v9, :cond_3a5

    const-string v10, "replay.json"

    const-class v11, Ljava/lang/String;

    invoke-virtual {v8, v9, v10, v11}, Lio/sentry/cache/f;->b(Lio/sentry/w6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    if-nez v9, :cond_c6

    goto/16 :goto_3ab

    :cond_c6
    move-object v10, v7

    new-instance v7, Lio/sentry/protocol/w;

    invoke-direct {v7, v9}, Lio/sentry/protocol/w;-><init>(Ljava/lang/String;)V

    sget-object v11, Lio/sentry/protocol/w;->F:Lio/sentry/protocol/w;

    invoke-virtual {v7, v11}, Lio/sentry/protocol/w;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_d9

    invoke-virtual {v0, v1}, Lio/sentry/android/replay/ReplayIntegration;->K(Ljava/lang/String;)V

    goto/16 :goto_3ae

    :cond_d9
    iget-object v11, v0, Lio/sentry/android/replay/ReplayIntegration;->H:Lio/sentry/android/core/SentryAndroidOptions;

    if-eqz v11, :cond_3a0

    invoke-virtual {v11}, Lio/sentry/w6;->getCacheDirPath()Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_108

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    if-nez v12, :cond_ea

    goto :goto_108

    :cond_ea
    new-instance v12, Ljava/io/File;

    invoke-virtual {v11}, Lio/sentry/w6;->getCacheDirPath()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v14, Ljava/lang/StringBuilder;

    const-string v15, "replay_"

    invoke-direct {v14, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v14, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-direct {v12, v13, v14}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v12}, Ljava/io/File;->mkdirs()Z

    goto :goto_116

    :cond_108
    :goto_108
    invoke-virtual {v11}, Lio/sentry/w6;->getLogger()Lio/sentry/y0;

    move-result-object v12

    sget-object v13, Lio/sentry/t5;->WARNING:Lio/sentry/t5;

    const-string v14, "SentryOptions.cacheDirPath is not set, session replay is no-op"

    new-array v15, v4, [Ljava/lang/Object;

    invoke-interface {v12, v13, v14, v15}, Lio/sentry/y0;->i(Lio/sentry/t5;Ljava/lang/String;[Ljava/lang/Object;)V

    move-object v12, v5

    :goto_116
    new-instance v13, Ljava/io/File;

    const-string v14, ".ongoing_segment"

    invoke-direct {v13, v12, v14}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v13}, Ljava/io/File;->exists()Z

    move-result v14

    if-nez v14, :cond_139

    invoke-virtual {v11}, Lio/sentry/w6;->getLogger()Lio/sentry/y0;

    move-result-object v2

    sget-object v3, Lio/sentry/t5;->DEBUG:Lio/sentry/t5;

    const-string v4, "No ongoing segment found for replay: %s"

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v6

    invoke-interface {v2, v3, v4, v6}, Lio/sentry/y0;->i(Lio/sentry/t5;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {v12}, Lio/sentry/util/b;->d(Ljava/io/File;)Z

    move-object/from16 v16, v5

    goto/16 :goto_324

    :cond_139
    new-instance v14, Ljava/util/LinkedHashMap;

    invoke-direct {v14}, Ljava/util/LinkedHashMap;-><init>()V

    sget-object v15, Lyq2;->a:Ljava/nio/charset/Charset;

    move-object/from16 v16, v5

    new-instance v5, Ljava/io/InputStreamReader;

    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, v13}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v5, v2, v15}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    new-instance v2, Ljava/io/BufferedReader;

    const/16 v13, 0x2000

    invoke-direct {v2, v5, v13}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    :try_start_153
    new-instance v5, Lzm4;

    invoke-direct {v5, v3, v2}, Lzm4;-><init>(ILjava/lang/Object;)V

    new-instance v13, Lc35;

    invoke-direct {v13, v5}, Lc35;-><init>(Lodg;)V

    invoke-virtual {v13}, Lc35;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_161
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_18b

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    const-string v15, "="

    filled-new-array {v15}, [Ljava/lang/String;

    move-result-object v15

    invoke-static {v13, v15, v3, v3}, Lcnh;->M0(Ljava/lang/CharSequence;[Ljava/lang/String;II)Ljava/util/List;

    move-result-object v13

    invoke-interface {v13, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-interface {v13, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-interface {v14, v15, v13}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_186
    .catchall {:try_start_153 .. :try_end_186} :catchall_187

    goto :goto_161

    :catchall_187
    move-exception v0

    move-object v1, v0

    goto/16 :goto_39a

    :cond_18b
    invoke-interface {v2}, Ljava/io/Closeable;->close()V

    const-string v2, "config.height"

    invoke-virtual {v14, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_19d

    invoke-static {v2}, Ljnh;->h0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    goto :goto_19f

    :cond_19d
    move-object/from16 v2, v16

    :goto_19f
    const-string v3, "config.width"

    invoke-virtual {v14, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    if-eqz v3, :cond_1ae

    invoke-static {v3}, Ljnh;->h0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_1b0

    :cond_1ae
    move-object/from16 v3, v16

    :goto_1b0
    const-string v5, "config.frame-rate"

    invoke-virtual {v14, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    if-eqz v5, :cond_1bf

    invoke-static {v5}, Ljnh;->h0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    goto :goto_1c1

    :cond_1bf
    move-object/from16 v5, v16

    :goto_1c1
    const-string v13, "config.bit-rate"

    invoke-virtual {v14, v13}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    if-eqz v13, :cond_1d0

    invoke-static {v13}, Ljnh;->h0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v13

    goto :goto_1d2

    :cond_1d0
    move-object/from16 v13, v16

    :goto_1d2
    const-string v15, "segment.id"

    invoke-virtual {v14, v15}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    if-eqz v15, :cond_1e1

    invoke-static {v15}, Ljnh;->h0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v15

    goto :goto_1e3

    :cond_1e1
    move-object/from16 v15, v16

    :goto_1e3
    :try_start_1e3
    const-string v4, "segment.timestamp"

    invoke-virtual {v14, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-nez v4, :cond_1ee

    move-object v4, v1

    :cond_1ee
    invoke-static {v4}, Lio/sentry/p;->h(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v4
    :try_end_1f2
    .catchall {:try_start_1e3 .. :try_end_1f2} :catchall_1f3

    goto :goto_1f5

    :catchall_1f3
    move-object/from16 v4, v16

    :goto_1f5
    :try_start_1f5
    const-string v6, "replay.type"

    invoke-virtual {v14, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    if-nez v6, :cond_200

    move-object v6, v1

    :cond_200
    invoke-static {v6}, Lio/sentry/x6;->valueOf(Ljava/lang/String;)Lio/sentry/x6;

    move-result-object v6
    :try_end_204
    .catchall {:try_start_1f5 .. :try_end_204} :catchall_205

    goto :goto_207

    :catchall_205
    move-object/from16 v6, v16

    :goto_207
    if-eqz v2, :cond_310

    if-eqz v3, :cond_310

    if-eqz v5, :cond_310

    if-eqz v13, :cond_310

    if-eqz v15, :cond_310

    move-object/from16 p0, v2

    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    move-result v2

    move-object/from16 v21, v3

    const/4 v3, -0x1

    if-eq v2, v3, :cond_310

    if-eqz v4, :cond_310

    if-nez v6, :cond_222

    goto/16 :goto_310

    :cond_222
    new-instance v22, Lio/sentry/android/replay/y;

    invoke-virtual/range {v21 .. v21}, Ljava/lang/Integer;->intValue()I

    move-result v23

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Integer;->intValue()I

    move-result v24

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v27

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v28

    const/high16 v25, 0x3f800000  # 1.0f

    const/high16 v26, 0x3f800000  # 1.0f

    invoke-direct/range {v22 .. v28}, Lio/sentry/android/replay/y;-><init>(IIFFII)V

    new-instance v2, Lio/sentry/android/replay/l;

    invoke-direct {v2, v11, v7}, Lio/sentry/android/replay/l;-><init>(Lio/sentry/w6;Lio/sentry/protocol/w;)V

    iget-object v3, v2, Lio/sentry/android/replay/l;->M:Ljava/util/ArrayList;

    invoke-virtual {v2}, Lio/sentry/android/replay/l;->e()Ljava/io/File;

    move-result-object v13

    move-object/from16 p0, v4

    if-eqz v13, :cond_252

    new-instance v4, Lio/sentry/android/replay/h;

    invoke-direct {v4, v2}, Lio/sentry/android/replay/h;-><init>(Lio/sentry/android/replay/l;)V

    invoke-virtual {v13, v4}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    :cond_252
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_26e

    invoke-virtual {v11}, Lio/sentry/w6;->getLogger()Lio/sentry/y0;

    move-result-object v2

    sget-object v3, Lio/sentry/t5;->DEBUG:Lio/sentry/t5;

    const-string v4, "No frames found for replay: %s, deleting the replay"

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v3, v4, v5}, Lio/sentry/y0;->i(Lio/sentry/t5;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {v12}, Lio/sentry/util/b;->d(Ljava/io/File;)Z

    :goto_26a
    move-object/from16 v5, v16

    goto/16 :goto_324

    :cond_26e
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v12, 0x1

    if-le v4, v12, :cond_27e

    new-instance v4, Lio/sentry/android/replay/i;

    const/4 v12, 0x0

    invoke-direct {v4, v12}, Lio/sentry/android/replay/i;-><init>(I)V

    invoke-static {v3, v4}, Lwm4;->a0(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_27e
    sget-object v4, Lio/sentry/x6;->SESSION:Lio/sentry/x6;

    if-ne v6, v4, :cond_289

    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    move-result v12

    move/from16 v25, v12

    goto :goto_28b

    :cond_289
    const/16 v25, 0x0

    :goto_28b
    if-ne v6, v4, :cond_290

    move-object/from16 v24, p0

    goto :goto_29f

    :cond_290
    invoke-static {v3}, Lsm4;->t0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lio/sentry/android/replay/m;

    iget-wide v12, v4, Lio/sentry/android/replay/m;->b:J

    new-instance v4, Ljava/util/Date;

    invoke-direct {v4, v12, v13}, Ljava/util/Date;-><init>(J)V

    move-object/from16 v24, v4

    :goto_29f
    invoke-static {v3}, Lsm4;->C0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lio/sentry/android/replay/m;

    iget-wide v3, v3, Lio/sentry/android/replay/m;->b:J

    invoke-virtual/range {v24 .. v24}, Ljava/util/Date;->getTime()J

    move-result-wide v12

    sub-long/2addr v3, v12

    const/16 v12, 0x3e8

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    div-int/2addr v12, v5

    int-to-long v12, v12

    add-long v26, v3, v12

    const-string v3, "replay.recording"

    invoke-virtual {v14, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    if-eqz v3, :cond_2ec

    new-instance v4, Ljava/io/StringReader;

    invoke-direct {v4, v3}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Lio/sentry/w6;->getSerializer()Lio/sentry/l1;

    move-result-object v3

    const-class v5, Lio/sentry/d4;

    invoke-interface {v3, v4, v5}, Lio/sentry/l1;->b(Ljava/io/Reader;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lio/sentry/d4;

    if-eqz v3, :cond_2d6

    iget-object v4, v3, Lio/sentry/d4;->F:Ljava/util/List;

    goto :goto_2d8

    :cond_2d6
    move-object/from16 v4, v16

    :goto_2d8
    if-eqz v4, :cond_2e7

    new-instance v4, Ljava/util/LinkedList;

    iget-object v3, v3, Lio/sentry/d4;->F:Ljava/util/List;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v3, Ljava/util/Collection;

    invoke-direct {v4, v3}, Ljava/util/LinkedList;-><init>(Ljava/util/Collection;)V

    goto :goto_2e9

    :cond_2e7
    move-object/from16 v4, v16

    :goto_2e9
    if-eqz v4, :cond_2ec

    goto :goto_2ee

    :cond_2ec
    move-object/from16 v4, v18

    :goto_2ee
    new-instance v21, Lio/sentry/android/replay/f;

    const-string v3, "replay.screen-at-start"

    invoke-virtual {v14, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v29, v3

    check-cast v29, Ljava/lang/String;

    check-cast v4, Ljava/lang/Iterable;

    new-instance v3, Lio/sentry/android/replay/i;

    const/4 v12, 0x1

    invoke-direct {v3, v12}, Lio/sentry/android/replay/i;-><init>(I)V

    invoke-static {v4, v3}, Lsm4;->S0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v30

    move-object/from16 v23, v2

    move-object/from16 v28, v6

    invoke-direct/range {v21 .. v30}, Lio/sentry/android/replay/f;-><init>(Lio/sentry/android/replay/y;Lio/sentry/android/replay/l;Ljava/util/Date;IJLio/sentry/x6;Ljava/lang/String;Ljava/util/List;)V

    move-object/from16 v5, v21

    goto :goto_324

    :cond_310
    :goto_310
    invoke-virtual {v11}, Lio/sentry/w6;->getLogger()Lio/sentry/y0;

    move-result-object v2

    sget-object v3, Lio/sentry/t5;->DEBUG:Lio/sentry/t5;

    const-string v4, "Incorrect segment values found for replay: %s, deleting the replay"

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v3, v4, v5}, Lio/sentry/y0;->i(Lio/sentry/t5;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {v12}, Lio/sentry/util/b;->d(Ljava/io/File;)Z

    goto/16 :goto_26a

    :goto_324
    if-nez v5, :cond_32b

    invoke-virtual {v0, v1}, Lio/sentry/android/replay/ReplayIntegration;->K(Ljava/lang/String;)V

    goto/16 :goto_3ae

    :cond_32b
    iget-object v1, v0, Lio/sentry/android/replay/ReplayIntegration;->H:Lio/sentry/android/core/SentryAndroidOptions;

    if-eqz v1, :cond_394

    const-string v2, "breadcrumbs.json"

    const-class v3, Ljava/util/List;

    invoke-virtual {v8, v1, v2, v3}, Lio/sentry/cache/f;->b(Lio/sentry/w6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Ljava/util/List;

    if-eqz v2, :cond_344

    check-cast v1, Ljava/util/List;

    move-object/from16 v31, v16

    move-object/from16 v16, v1

    move-object/from16 v1, v31

    goto :goto_346

    :cond_344
    move-object/from16 v1, v16

    :goto_346
    iget-object v2, v0, Lio/sentry/android/replay/ReplayIntegration;->I:Lio/sentry/n4;

    iget-object v3, v0, Lio/sentry/android/replay/ReplayIntegration;->H:Lio/sentry/android/core/SentryAndroidOptions;

    if-eqz v3, :cond_390

    iget-wide v10, v5, Lio/sentry/android/replay/f;->e:J

    iget-object v6, v5, Lio/sentry/android/replay/f;->c:Ljava/util/Date;

    iget v8, v5, Lio/sentry/android/replay/f;->d:I

    iget-object v1, v5, Lio/sentry/android/replay/f;->a:Lio/sentry/android/replay/y;

    move-object v4, v9

    iget v9, v1, Lio/sentry/android/replay/y;->b:I

    move-wide v11, v10

    iget v10, v1, Lio/sentry/android/replay/y;->a:I

    iget v13, v1, Lio/sentry/android/replay/y;->e:I

    iget v14, v1, Lio/sentry/android/replay/y;->f:I

    move-wide/from16 v19, v11

    iget-object v12, v5, Lio/sentry/android/replay/f;->b:Lio/sentry/android/replay/l;

    iget-object v11, v5, Lio/sentry/android/replay/f;->f:Lio/sentry/x6;

    iget-object v15, v5, Lio/sentry/android/replay/f;->g:Ljava/lang/String;

    new-instance v1, Ljava/util/LinkedList;

    iget-object v5, v5, Lio/sentry/android/replay/f;->h:Ljava/util/List;

    check-cast v5, Ljava/util/Collection;

    invoke-direct {v1, v5}, Ljava/util/LinkedList;-><init>(Ljava/util/Collection;)V

    move-object/from16 v17, v1

    move-object v1, v4

    move-wide/from16 v4, v19

    invoke-static/range {v2 .. v18}, Lio/sentry/android/replay/capture/h;->a(Lio/sentry/f1;Lio/sentry/w6;JLjava/util/Date;Lio/sentry/protocol/w;IIILio/sentry/x6;Lio/sentry/android/replay/l;IILjava/lang/String;Ljava/util/List;Ljava/util/Deque;Ljava/util/List;)Lio/sentry/android/replay/capture/k;

    move-result-object v2

    instance-of v3, v2, Lio/sentry/android/replay/capture/i;

    if-eqz v3, :cond_38c

    new-instance v3, Lio/sentry/android/replay/o;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-static {v3}, Lio/sentry/util/c;->a(Ljava/lang/Object;)Lio/sentry/l0;

    move-result-object v3

    check-cast v2, Lio/sentry/android/replay/capture/i;

    iget-object v4, v0, Lio/sentry/android/replay/ReplayIntegration;->I:Lio/sentry/n4;

    invoke-virtual {v2, v4, v3}, Lio/sentry/android/replay/capture/i;->a(Lio/sentry/f1;Lio/sentry/l0;)V

    :cond_38c
    invoke-virtual {v0, v1}, Lio/sentry/android/replay/ReplayIntegration;->K(Ljava/lang/String;)V

    goto :goto_3ae

    :cond_390
    invoke-static {v10}, Lbo9;->z0(Ljava/lang/String;)V

    throw v1

    :cond_394
    move-object/from16 v1, v16

    invoke-static {v10}, Lbo9;->z0(Ljava/lang/String;)V

    throw v1

    :goto_39a
    :try_start_39a
    throw v1
    :try_end_39b
    .catchall {:try_start_39a .. :try_end_39b} :catchall_39b

    :catchall_39b
    move-exception v0

    invoke-static {v2, v1}, La60;->s(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_3a0
    move-object v1, v5

    invoke-static {v10}, Lbo9;->z0(Ljava/lang/String;)V

    throw v1

    :cond_3a5
    move-object v1, v5

    move-object v10, v7

    invoke-static {v10}, Lbo9;->z0(Ljava/lang/String;)V

    throw v1

    :cond_3ab
    :goto_3ab
    invoke-virtual {v0, v1}, Lio/sentry/android/replay/ReplayIntegration;->K(Ljava/lang/String;)V

    :goto_3ae
    return-void

    :cond_3af
    move-object v1, v5

    move-object v10, v7

    invoke-static {v10}, Lbo9;->z0(Ljava/lang/String;)V

    throw v1

    :pswitch_3b5  #0x18
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/ndk/c;

    iget-object v0, v0, Lio/sentry/android/ndk/c;->b:Lio/sentry/ndk/NativeScope;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lio/sentry/ndk/NativeScope;->nativeClearAttachments()V

    return-void

    :pswitch_3c2  #0x17
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;

    iget-object v1, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->G:Lio/sentry/android/core/SentryAndroidOptions;

    invoke-virtual {v0, v1}, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->d(Lio/sentry/android/core/SentryAndroidOptions;)V

    return-void

    :pswitch_3cc  #0x16
    move-object v1, v5

    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/p1;

    iget-object v0, v0, Lio/sentry/android/core/p1;->g:Ld1c;

    :goto_3d3
    iget-object v2, v0, Ld1c;->d:Ljava/lang/Object;

    check-cast v2, Lssg;

    if-eqz v2, :cond_3ec

    iget-object v3, v2, Lssg;->c:Ljava/lang/Object;

    check-cast v3, Lssg;

    iput-object v3, v0, Ld1c;->d:Ljava/lang/Object;

    iget-object v3, v0, Ld1c;->c:Ljava/lang/Object;

    check-cast v3, Lio/sentry/android/core/r0;

    iget-object v4, v3, Lio/sentry/android/core/r0;->a:Ljava/lang/Object;

    check-cast v4, Lssg;

    iput-object v4, v2, Lssg;->c:Ljava/lang/Object;

    iput-object v2, v3, Lio/sentry/android/core/r0;->a:Ljava/lang/Object;

    goto :goto_3d3

    :cond_3ec
    iput-object v1, v0, Ld1c;->e:Ljava/lang/Object;

    const/4 v12, 0x0

    iput v12, v0, Ld1c;->a:I

    iput v12, v0, Ld1c;->b:I

    return-void

    :pswitch_3f4  #0x15
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/f0;

    if-eqz v0, :cond_401

    sget-object v1, Landroidx/lifecycle/ProcessLifecycleOwner;->M:Landroidx/lifecycle/ProcessLifecycleOwner;

    iget-object v1, v1, Landroidx/lifecycle/ProcessLifecycleOwner;->J:Lkha;

    invoke-virtual {v1, v0}, Lkha;->c(Lgha;)V

    :cond_401
    return-void

    :pswitch_402  #0x14
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/s;

    const/4 v1, 0x0

    const/4 v12, 0x1

    invoke-virtual {v0, v1, v12}, Lio/sentry/android/core/s;->a(Ljava/util/List;Z)Lqfh;

    return-void

    :pswitch_40c  #0x13
    move v12, v6

    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/h;

    invoke-virtual {v0, v12}, Lio/sentry/android/core/h;->i(Z)V

    return-void

    :pswitch_415  #0x12
    move v12, v6

    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/c;

    iget-object v0, v0, Lio/sentry/android/core/c;->a:Lio/sentry/util/i;

    invoke-virtual {v0}, Lio/sentry/util/i;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/core/app/FrameMetricsAggregator;

    iget-object v0, v0, Landroidx/core/app/FrameMetricsAggregator;->a:Ldyl;

    iget-object v1, v0, Ldyl;->G:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v12

    :goto_42d
    if-ltz v2, :cond_452

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/ref/WeakReference;

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/Activity;

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_44f

    invoke-virtual {v4}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v3

    iget-object v4, v0, Ldyl;->H:Ljava/lang/Object;

    check-cast v4, Lf88;

    invoke-virtual {v3, v4}, Landroid/view/Window;->removeOnFrameMetricsAvailableListener(Landroid/view/Window$OnFrameMetricsAvailableListener;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_44f
    add-int/lit8 v2, v2, -0x1

    goto :goto_42d

    :cond_452
    return-void

    :pswitch_453  #0x11
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/android/core/a;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iput-wide v1, v0, Lio/sentry/android/core/a;->L:J

    iget-object v0, v0, Lio/sentry/android/core/a;->M:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v12, 0x0

    invoke-virtual {v0, v12}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void

    :pswitch_464  #0x10
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lio/sentry/ShutdownHookIntegration;

    iget-object v1, v0, Lio/sentry/ShutdownHookIntegration;->E:Ljava/lang/Runtime;

    iget-object v0, v0, Lio/sentry/ShutdownHookIntegration;->F:Ljava/lang/Thread;

    invoke-virtual {v1, v0}, Ljava/lang/Runtime;->removeShutdownHook(Ljava/lang/Thread;)Z

    return-void

    :pswitch_470  #0xf
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lh6k;

    const-string v1, "FirebaseMessaging"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Service took too long to process intent: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, v0, Lh6k;->a:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " finishing."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, v0, Lh6k;->b:Ld0i;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ld0i;->d(Ljava/lang/Object;)V

    return-void

    :pswitch_499  #0xe
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lpce;

    new-instance v1, Lmyj;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v0, v1}, Lpce;->h(Ljava/lang/Object;)V

    return-void

    :pswitch_4a6  #0xd
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Ljjj;

    iget-object v1, v0, Lhjj;->E:Landroid/view/Choreographer;

    invoke-static {v1, v0}, Lp4h;->k(Landroid/view/Choreographer;Landroid/view/Choreographer$VsyncCallback;)V

    return-void

    :pswitch_4b0  #0xc
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lfwh;

    iget-object v0, v0, Lfwh;->a:Ldwh;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v2, v1, Landroid/view/ViewGroup;

    if-eqz v2, :cond_4c3

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_4c3
    return-void

    :pswitch_4c4  #0xb
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, La1f;

    iget-object v0, v0, La1f;->F:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;

    iget v1, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:I

    if-ne v1, v3, :cond_4d6

    if-nez v1, :cond_4d3

    goto :goto_4d6

    :cond_4d3
    const/4 v12, 0x0

    iput v12, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:I

    :cond_4d6
    :goto_4d6
    return-void

    :pswitch_4d7  #0xa
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Ljt5;

    iget-object v1, v0, Ljt5;->H:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayDeque;

    monitor-enter v1

    :try_start_4e0
    iget-object v2, v0, Ljt5;->E:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    iget-object v3, v0, Ljt5;->F:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v0, Ljt5;->H:Ljava/lang/Object;

    check-cast v5, Ljava/util/ArrayDeque;

    invoke-virtual {v5}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_4f9
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_510

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v0, Ljt5;->G:Ljava/lang/Object;

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_4f9

    :cond_510
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    monitor-exit v1

    return-void

    :catchall_51d
    move-exception v0

    monitor-exit v1
    :try_end_51f
    .catchall {:try_start_4e0 .. :try_end_51f} :catchall_51d

    throw v0

    :pswitch_520  #0x9
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lquf;

    iget-boolean v0, v1, Lquf;->R:Z

    if-nez v0, :cond_541

    iget-boolean v0, v1, Lquf;->S:Z

    if-eqz v0, :cond_52e

    goto :goto_541

    :cond_52e
    const/4 v12, 0x1

    iput-boolean v12, v1, Lquf;->R:Z

    iget-object v0, v1, Lquf;->T:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, v1, Lquf;->U:Ljava/lang/String;

    const-string v4, "text/html"

    const-string v5, "UTF-8"

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v6}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_541
    :goto_541
    return-void

    :pswitch_542  #0x8
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lunf;

    iget-boolean v1, v0, Lunf;->K:Z

    if-eqz v1, :cond_54b

    goto :goto_59b

    :cond_54b
    iget-object v1, v0, Lunf;->H:Lr95;

    invoke-virtual {v1}, Lr95;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v1

    iget-object v0, v0, Lunf;->E:Li61;

    iget-object v3, v0, Li61;->G:Ljava/lang/Object;

    check-cast v3, Linf;

    iget-object v4, v3, Linf;->N:Ljava/util/WeakHashMap;

    iget-object v5, v0, Li61;->H:Ljava/lang/Object;

    check-cast v5, Landroid/app/Activity;

    invoke-virtual {v4, v5}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v4, v3, Linf;->L:Lnof;

    iget-object v5, v0, Li61;->I:Ljava/lang/Object;

    check-cast v5, Lnof;

    if-eq v4, v5, :cond_56f

    goto :goto_59b

    :cond_56f
    invoke-interface {v5}, Lnof;->c()Lafi;

    move-result-object v4

    iget-wide v6, v4, Lafi;->b:J

    sub-long/2addr v1, v6

    iget-object v4, v3, Linf;->G:Lfi8;

    iget-boolean v0, v0, Li61;->F:Z

    iget-object v4, v4, Lfi8;->F:Ljava/lang/Object;

    check-cast v4, Ltnf;

    iget-object v4, v4, Ltnf;->E:Lam9;

    invoke-static {v4}, Lli8;->a(Lam9;)Lvnf;

    move-result-object v4

    instance-of v6, v4, Lah;

    if-eqz v6, :cond_58b

    check-cast v4, Lah;

    goto :goto_58c

    :cond_58b
    const/4 v4, 0x0

    :goto_58c
    if-nez v4, :cond_590

    :goto_58e
    const/4 v1, 0x0

    goto :goto_599

    :cond_590
    new-instance v6, Loof;

    invoke-direct {v6, v5, v1, v2, v0}, Loof;-><init>(Lnof;JZ)V

    invoke-interface {v4, v6}, Lah;->y(Loof;)V

    goto :goto_58e

    :goto_599
    iput-object v1, v3, Linf;->L:Lnof;

    :goto_59b
    return-void

    :pswitch_59c  #0x7
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Linf;

    if-eqz v0, :cond_5a5

    invoke-virtual {v0}, Linf;->a()V

    :cond_5a5
    return-void

    :pswitch_5a6  #0x6
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lyif;

    invoke-static {v0}, Lyif;->a(Lyif;)V

    return-void

    :pswitch_5ae  #0x5
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Ln5f;

    iget-boolean v1, v0, Ln5f;->d:Z

    iget-object v2, v0, Ln5f;->a:Landroid/view/View;

    if-nez v1, :cond_5b9

    goto :goto_5cf

    :cond_5b9
    const/4 v12, 0x0

    iput-boolean v12, v0, Ln5f;->d:Z

    invoke-virtual {v2}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-nez v1, :cond_5c3

    goto :goto_5cf

    :cond_5c3
    new-instance v1, Lmz7;

    invoke-direct {v1, v0}, Lmz7;-><init>(Ln5f;)V

    const/4 v12, 0x1

    invoke-virtual {v2, v1, v12}, Landroid/view/View;->startActionMode(Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;

    move-result-object v1

    iput-object v1, v0, Ln5f;->c:Landroid/view/ActionMode;

    :goto_5cf
    return-void

    :pswitch_5d0  #0x4
    move v12, v6

    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lvpd;

    iget v1, v0, Lvpd;->m:I

    sub-int/2addr v1, v12

    iput v1, v0, Lvpd;->m:I

    return-void

    :pswitch_5db  #0x3
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lejc;

    iget-object v1, v0, Lejc;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcy5;

    if-eqz v1, :cond_68a

    iget-object v0, v0, Lejc;->c:Lfjc;

    invoke-virtual {v0}, Lfjc;->c()I

    move-result v0

    iget-object v2, v1, Lcy5;->a:Ldy5;

    monitor-enter v2

    :try_start_5f2
    iget v1, v2, Ldy5;->n:I

    if-eqz v1, :cond_600

    iget-boolean v3, v2, Ldy5;->e:Z
    :try_end_5f8
    .catchall {:try_start_5f2 .. :try_end_5f8} :catchall_5fd

    if-nez v3, :cond_600

    monitor-exit v2

    goto/16 :goto_68a

    :catchall_5fd
    move-exception v0

    goto/16 :goto_688

    :cond_600
    if-ne v1, v0, :cond_609

    :try_start_602
    iget-object v1, v2, Ldy5;->o:Ljava/lang/String;
    :try_end_604
    .catchall {:try_start_602 .. :try_end_604} :catchall_5fd

    if-eqz v1, :cond_609

    monitor-exit v2

    goto/16 :goto_68a

    :cond_609
    :try_start_609
    iput v0, v2, Ldy5;->n:I

    const/4 v12, 0x1

    if-eq v0, v12, :cond_686

    if-eqz v0, :cond_686

    const/16 v1, 0x8

    if-ne v0, v1, :cond_616

    goto/16 :goto_686

    :cond_616
    iget-object v1, v2, Ldy5;->o:Ljava/lang/String;

    if-nez v1, :cond_647

    iget-object v1, v2, Ldy5;->a:Landroid/content/Context;

    sget-object v3, Lpej;->a:Ljava/lang/String;

    if-eqz v1, :cond_639

    const-string v3, "phone"

    invoke-virtual {v1, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/TelephonyManager;

    if-eqz v1, :cond_639

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getNetworkCountryIso()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_639

    invoke-static {v1}, Lqll;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_645

    :cond_639
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lqll;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_645
    iput-object v1, v2, Ldy5;->o:Ljava/lang/String;

    :cond_647
    invoke-virtual {v2, v0}, Ldy5;->a(I)J

    move-result-wide v0

    iput-wide v0, v2, Ldy5;->l:J

    iget-object v0, v2, Ldy5;->d:Liwh;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget v3, v2, Ldy5;->g:I

    if-lez v3, :cond_661

    iget-wide v3, v2, Ldy5;->h:J

    sub-long v3, v0, v3

    long-to-int v12, v3

    move v5, v12

    goto :goto_662

    :cond_661
    const/4 v5, 0x0

    :goto_662
    iget-wide v3, v2, Ldy5;->i:J

    iget-wide v6, v2, Ldy5;->l:J

    invoke-virtual/range {v2 .. v7}, Ldy5;->b(JIJ)V

    iput-wide v0, v2, Ldy5;->h:J

    const-wide/16 v0, 0x0

    iput-wide v0, v2, Ldy5;->i:J

    iput-wide v0, v2, Ldy5;->k:J

    iput-wide v0, v2, Ldy5;->j:J

    iget-object v0, v2, Ldy5;->f:Lm4h;

    iget-object v1, v0, Lm4h;->e:Ljava/io/Serializable;

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v3, -0x1

    iput v3, v0, Lm4h;->a:I

    const/4 v12, 0x0

    iput v12, v0, Lm4h;->b:I

    iput v12, v0, Lm4h;->c:I
    :try_end_684
    .catchall {:try_start_609 .. :try_end_684} :catchall_5fd

    monitor-exit v2

    goto :goto_68a

    :cond_686
    :goto_686
    monitor-exit v2

    goto :goto_68a

    :goto_688
    :try_start_688
    monitor-exit v2
    :try_end_689
    .catchall {:try_start_688 .. :try_end_689} :catchall_5fd

    throw v0

    :cond_68a
    :goto_68a
    return-void

    :pswitch_68b  #0x2
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Llmb;

    iget-object v0, v0, Llmb;->P:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->stop()V

    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    return-void

    :pswitch_698  #0x1
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Lxcb;

    invoke-virtual {v0}, Lxcb;->getCallbacks()Lmbb;

    move-result-object v0

    iget-object v0, v0, Lmbb;->o:Ls98;

    if-eqz v0, :cond_6ac

    const-string v1, "WebViewError"

    const-string v2, "MCP app wrapper never signalled ready"

    const/4 v3, 0x0

    invoke-interface {v0, v1, v3, v2}, Ls98;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6ac
    return-void

    :pswitch_6ad  #0x0
    iget-object v0, v0, Lb1b;->F:Ljava/lang/Object;

    check-cast v0, Ld1b;

    invoke-virtual {v0}, Ld1b;->c()V

    return-void

    nop

    :pswitch_data_6b6
    .packed-switch 0x0
        :pswitch_6ad  #00000000
        :pswitch_698  #00000001
        :pswitch_68b  #00000002
        :pswitch_5db  #00000003
        :pswitch_5d0  #00000004
        :pswitch_5ae  #00000005
        :pswitch_5a6  #00000006
        :pswitch_59c  #00000007
        :pswitch_542  #00000008
        :pswitch_520  #00000009
        :pswitch_4d7  #0000000a
        :pswitch_4c4  #0000000b
        :pswitch_4b0  #0000000c
        :pswitch_4a6  #0000000d
        :pswitch_499  #0000000e
        :pswitch_470  #0000000f
        :pswitch_464  #00000010
        :pswitch_453  #00000011
        :pswitch_415  #00000012
        :pswitch_40c  #00000013
        :pswitch_402  #00000014
        :pswitch_3f4  #00000015
        :pswitch_3cc  #00000016
        :pswitch_3c2  #00000017
        :pswitch_3b5  #00000018
        :pswitch_a0  #00000019
        :pswitch_58  #0000001a
        :pswitch_2f  #0000001b
        :pswitch_1f  #0000001c
    .end packed-switch
.end method
