.class public final La11;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public F:I

.field public final synthetic G:Loyg;


# direct methods
.method public synthetic constructor <init>(Loyg;La75;I)V
    .registers 4

    iput p3, p0, La11;->E:I

    iput-object p1, p0, La11;->G:Loyg;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 4

    iget p1, p0, La11;->E:I

    iget-object p0, p0, La11;->G:Loyg;

    packed-switch p1, :pswitch_data_78

    new-instance p1, La11;

    const/16 v0, 0xe

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_f  #0xd
    new-instance p1, La11;

    const/16 v0, 0xd

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_17  #0xc
    new-instance p1, La11;

    const/16 v0, 0xc

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_1f  #0xb
    new-instance p1, La11;

    const/16 v0, 0xb

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_27  #0xa
    new-instance p1, La11;

    const/16 v0, 0xa

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_2f  #0x9
    new-instance p1, La11;

    const/16 v0, 0x9

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_37  #0x8
    new-instance p1, La11;

    const/16 v0, 0x8

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_3f  #0x7
    new-instance p1, La11;

    const/4 v0, 0x7

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_46  #0x6
    new-instance p1, La11;

    const/4 v0, 0x6

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_4d  #0x5
    new-instance p1, La11;

    const/4 v0, 0x5

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_54  #0x4
    new-instance p1, La11;

    const/4 v0, 0x4

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_5b  #0x3
    new-instance p1, La11;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_62  #0x2
    new-instance p1, La11;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_69  #0x1
    new-instance p1, La11;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    :pswitch_70  #0x0
    new-instance p1, La11;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, La11;-><init>(Loyg;La75;I)V

    return-object p1

    nop

    :pswitch_data_78
    .packed-switch 0x0
        :pswitch_70  #00000000
        :pswitch_69  #00000001
        :pswitch_62  #00000002
        :pswitch_5b  #00000003
        :pswitch_54  #00000004
        :pswitch_4d  #00000005
        :pswitch_46  #00000006
        :pswitch_3f  #00000007
        :pswitch_37  #00000008
        :pswitch_2f  #00000009
        :pswitch_27  #0000000a
        :pswitch_1f  #0000000b
        :pswitch_17  #0000000c
        :pswitch_f  #0000000d
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget v0, p0, La11;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    check-cast p1, Lua5;

    check-cast p2, La75;

    packed-switch v0, :pswitch_data_b0

    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0xd
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_21  #0xc
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2c  #0xb
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_37  #0xa
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_42  #0x9
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_4d  #0x8
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_58  #0x7
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_63  #0x6
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_6e  #0x5
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_79  #0x4
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_84  #0x3
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_8f  #0x2
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_9a  #0x1
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_a5  #0x0
    invoke-virtual {p0, p1, p2}, La11;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La11;

    invoke-virtual {p0, v1}, La11;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_b0
    .packed-switch 0x0
        :pswitch_a5  #00000000
        :pswitch_9a  #00000001
        :pswitch_8f  #00000002
        :pswitch_84  #00000003
        :pswitch_79  #00000004
        :pswitch_6e  #00000005
        :pswitch_63  #00000006
        :pswitch_58  #00000007
        :pswitch_4d  #00000008
        :pswitch_42  #00000009
        :pswitch_37  #0000000a
        :pswitch_2c  #0000000b
        :pswitch_21  #0000000c
        :pswitch_16  #0000000d
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    iget v0, p0, La11;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    iget-object v2, p0, La11;->G:Loyg;

    const/4 v3, 0x0

    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v5, Lva5;->E:Lva5;

    const/4 v6, 0x1

    packed-switch v0, :pswitch_data_1b4

    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_1e

    if-ne v0, v6, :cond_19

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_2a

    :cond_19
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_2a

    :cond_1e
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->e(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_2a

    move-object v1, v5

    :cond_2a
    :goto_2a
    return-object v1

    :pswitch_2b  #0xd
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_3a

    if-ne v0, v6, :cond_35

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_46

    :cond_35
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_46

    :cond_3a
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-static {v2, p0}, Lik5;->t(Loyg;Lc75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_46

    move-object v1, v5

    :cond_46
    :goto_46
    return-object v1

    :pswitch_47  #0xc
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_56

    if-ne v0, v6, :cond_51

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_62

    :cond_51
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_62

    :cond_56
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->e(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_62

    move-object v1, v5

    :cond_62
    :goto_62
    return-object v1

    :pswitch_63  #0xb
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_72

    if-ne v0, v6, :cond_6d

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_7e

    :cond_6d
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_7e

    :cond_72
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->g(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_7e

    move-object v1, v5

    :cond_7e
    :goto_7e
    return-object v1

    :pswitch_7f  #0xa
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_8e

    if-ne v0, v6, :cond_89

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_9a

    :cond_89
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_9a

    :cond_8e
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->e(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_9a

    move-object v1, v5

    :cond_9a
    :goto_9a
    return-object v1

    :pswitch_9b  #0x9
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_aa

    if-ne v0, v6, :cond_a5

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_b6

    :cond_a5
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_b6

    :cond_aa
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->h(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_b6

    move-object v1, v5

    :cond_b6
    :goto_b6
    return-object v1

    :pswitch_b7  #0x8
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_c6

    if-ne v0, v6, :cond_c1

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_d2

    :cond_c1
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_d2

    :cond_c6
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->e(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_d2

    move-object v1, v5

    :cond_d2
    :goto_d2
    return-object v1

    :pswitch_d3  #0x7
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_e2

    if-ne v0, v6, :cond_dd

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_ee

    :cond_dd
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_ee

    :cond_e2
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->g(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_ee

    move-object v1, v5

    :cond_ee
    :goto_ee
    return-object v1

    :pswitch_ef  #0x6
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_fe

    if-ne v0, v6, :cond_f9

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_10a

    :cond_f9
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_10a

    :cond_fe
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->b(Lc75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_10a

    move-object v1, v5

    :cond_10a
    :goto_10a
    return-object v1

    :pswitch_10b  #0x5
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_11a

    if-ne v0, v6, :cond_115

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_126

    :cond_115
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_126

    :cond_11a
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->h(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_126

    move-object v1, v5

    :cond_126
    :goto_126
    return-object v1

    :pswitch_127  #0x4
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_136

    if-ne v0, v6, :cond_131

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_142

    :cond_131
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_142

    :cond_136
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->b(Lc75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_142

    move-object v1, v5

    :cond_142
    :goto_142
    return-object v1

    :pswitch_143  #0x3
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_152

    if-ne v0, v6, :cond_14d

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_15e

    :cond_14d
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_15e

    :cond_152
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->e(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_15e

    move-object v1, v5

    :cond_15e
    :goto_15e
    return-object v1

    :pswitch_15f  #0x2
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_16e

    if-ne v0, v6, :cond_169

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_17a

    :cond_169
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_17a

    :cond_16e
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->g(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_17a

    move-object v1, v5

    :cond_17a
    :goto_17a
    return-object v1

    :pswitch_17b  #0x1
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_18a

    if-ne v0, v6, :cond_185

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_196

    :cond_185
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_196

    :cond_18a
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->e(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_196

    move-object v1, v5

    :cond_196
    :goto_196
    return-object v1

    :pswitch_197  #0x0
    iget v0, p0, La11;->F:I

    if-eqz v0, :cond_1a6

    if-ne v0, v6, :cond_1a1

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_1b2

    :cond_1a1
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_1b2

    :cond_1a6
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, La11;->F:I

    invoke-virtual {v2, p0}, Loyg;->e(Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_1b2

    move-object v1, v5

    :cond_1b2
    :goto_1b2
    return-object v1

    nop

    :pswitch_data_1b4
    .packed-switch 0x0
        :pswitch_197  #00000000
        :pswitch_17b  #00000001
        :pswitch_15f  #00000002
        :pswitch_143  #00000003
        :pswitch_127  #00000004
        :pswitch_10b  #00000005
        :pswitch_ef  #00000006
        :pswitch_d3  #00000007
        :pswitch_b7  #00000008
        :pswitch_9b  #00000009
        :pswitch_7f  #0000000a
        :pswitch_63  #0000000b
        :pswitch_47  #0000000c
        :pswitch_2b  #0000000d
    .end packed-switch
.end method
