.class public final Lae2;
.super Lc75;
.source "SourceFile"


# instance fields
.field public E:Lcom/anthropic/claude/tool/model/EventDeleteV0Input;

.field public synthetic F:Ljava/lang/Object;

.field public final synthetic G:Lxs5;

.field public H:I


# direct methods
.method public constructor <init>(Lxs5;Lc75;)V
    .registers 3

    iput-object p1, p0, Lae2;->G:Lxs5;

    invoke-direct {p0, p2}, Lc75;-><init>(La75;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lae2;->F:Ljava/lang/Object;

    iget p1, p0, Lae2;->H:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lae2;->H:I

    iget-object p1, p0, Lae2;->G:Lxs5;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lxs5;->r(Lcom/anthropic/claude/tool/model/EventDeleteV0Input;Lc75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
