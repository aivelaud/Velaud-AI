.class public final synthetic Laq1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lpad;


# direct methods
.method public synthetic constructor <init>(Lpad;I)V
    .registers 3

    iput p2, p0, Laq1;->E:I

    iput-object p1, p0, Laq1;->F:Lpad;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iget v0, p0, Laq1;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    iget-object p0, p0, Laq1;->F:Lpad;

    packed-switch v0, :pswitch_data_38

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-virtual {p0, p1}, Lpad;->i(F)V

    return-object v1

    :pswitch_13  #0x1
    check-cast p1, Ld76;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lpad;->h()F

    move-result p0

    invoke-static {p0}, Llab;->C(F)I

    move-result p0

    int-to-long p0, p0

    const-wide v0, 0xffffffffL

    and-long/2addr p0, v0

    new-instance v0, Lqj9;

    invoke-direct {v0, p0, p1}, Lqj9;-><init>(J)V

    return-object v0

    :pswitch_2d  #0x0
    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-virtual {p0, p1}, Lpad;->i(F)V

    return-object v1

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_2d  #00000000
        :pswitch_13  #00000001
    .end packed-switch
.end method
