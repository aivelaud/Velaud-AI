.class public final Laid;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;
.implements Liz9;


# instance fields
.field public final E:[Lrui;

.field public F:I

.field public G:Z


# direct methods
.method public constructor <init>(Loui;[Lrui;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Laid;->E:[Lrui;

    const/4 v0, 0x1

    iput-boolean v0, p0, Laid;->G:Z

    const/4 v0, 0x0

    aget-object p2, p2, v0

    iget-object v1, p1, Loui;->c:[Ljava/lang/Object;

    iget p1, p1, Loui;->a:I

    invoke-static {p1}, Ljava/lang/Integer;->bitCount(I)I

    move-result p1

    mul-int/lit8 p1, p1, 0x2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v1, p2, Lrui;->E:[Ljava/lang/Object;

    iput p1, p2, Lrui;->F:I

    iput v0, p2, Lrui;->G:I

    iput v0, p0, Laid;->F:I

    invoke-virtual {p0}, Laid;->a()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 10

    iget v0, p0, Laid;->F:I

    iget-object v1, p0, Laid;->E:[Lrui;

    aget-object v2, v1, v0

    iget v3, v2, Lrui;->G:I

    iget v2, v2, Lrui;->F:I

    if-ge v3, v2, :cond_d

    return-void

    :cond_d
    :goto_d
    const/4 v2, 0x0

    const/4 v3, -0x1

    if-ge v3, v0, :cond_52

    invoke-virtual {p0, v0}, Laid;->c(I)I

    move-result v4

    if-ne v4, v3, :cond_29

    aget-object v5, v1, v0

    iget v6, v5, Lrui;->G:I

    iget-object v7, v5, Lrui;->E:[Ljava/lang/Object;

    array-length v8, v7

    if-ge v6, v8, :cond_29

    array-length v4, v7

    add-int/lit8 v6, v6, 0x1

    iput v6, v5, Lrui;->G:I

    invoke-virtual {p0, v0}, Laid;->c(I)I

    move-result v4

    :cond_29
    if-eq v4, v3, :cond_2e

    iput v4, p0, Laid;->F:I

    return-void

    :cond_2e
    if-lez v0, :cond_3d

    add-int/lit8 v3, v0, -0x1

    aget-object v3, v1, v3

    iget v4, v3, Lrui;->G:I

    iget-object v5, v3, Lrui;->E:[Ljava/lang/Object;

    array-length v5, v5

    add-int/lit8 v4, v4, 0x1

    iput v4, v3, Lrui;->G:I

    :cond_3d
    aget-object v3, v1, v0

    sget-object v4, Loui;->d:Loui;

    iget-object v4, v4, Loui;->c:[Ljava/lang/Object;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v4, v3, Lrui;->E:[Ljava/lang/Object;

    iput v2, v3, Lrui;->F:I

    iput v2, v3, Lrui;->G:I

    add-int/lit8 v0, v0, -0x1

    goto :goto_d

    :cond_52
    iput-boolean v2, p0, Laid;->G:Z

    return-void
.end method

.method public final c(I)I
    .registers 7

    iget-object v0, p0, Laid;->E:[Lrui;

    aget-object v1, v0, p1

    iget v2, v1, Lrui;->G:I

    iget v3, v1, Lrui;->F:I

    if-ge v2, v3, :cond_b

    return p1

    :cond_b
    iget-object v1, v1, Lrui;->E:[Ljava/lang/Object;

    array-length v3, v1

    if-ge v2, v3, :cond_4c

    array-length v3, v1

    aget-object v1, v1, v2

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v1, Loui;

    iget-object v2, v1, Loui;->c:[Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ne p1, v3, :cond_2d

    add-int/lit8 v1, p1, 0x1

    aget-object v0, v0, v1

    array-length v1, v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v2, v0, Lrui;->E:[Ljava/lang/Object;

    iput v1, v0, Lrui;->F:I

    iput v4, v0, Lrui;->G:I

    goto :goto_45

    :cond_2d
    add-int/lit8 v3, p1, 0x1

    aget-object v0, v0, v3

    iget v1, v1, Loui;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->bitCount(I)I

    move-result v1

    mul-int/lit8 v1, v1, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v2, v0, Lrui;->E:[Ljava/lang/Object;

    iput v1, v0, Lrui;->F:I

    iput v4, v0, Lrui;->G:I

    :goto_45
    add-int/lit8 p1, p1, 0x1

    invoke-virtual {p0, p1}, Laid;->c(I)I

    move-result p0

    return p0

    :cond_4c
    const/4 p0, -0x1

    return p0
.end method

.method public final hasNext()Z
    .registers 1

    iget-boolean p0, p0, Laid;->G:Z

    return p0
.end method

.method public final next()Ljava/lang/Object;
    .registers 3

    iget-boolean v0, p0, Laid;->G:Z

    if-eqz v0, :cond_12

    iget-object v0, p0, Laid;->E:[Lrui;

    iget v1, p0, Laid;->F:I

    aget-object v0, v0, v1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0}, Laid;->a()V

    return-object v0

    :cond_12
    invoke-static {}, Lgdg;->d()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final remove()V
    .registers 2

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Operation is not supported for read-only collection"

    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
