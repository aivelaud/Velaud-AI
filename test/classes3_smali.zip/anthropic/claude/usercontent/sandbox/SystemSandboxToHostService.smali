.class public final Lanthropic/claude/usercontent/sandbox/SystemSandboxToHostService;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0007"
    }
    d2 = {
        "Lanthropic/claude/usercontent/sandbox/SystemSandboxToHostService;",
        "",
        "<init>",
        "()V",
        "ReadyForContent",
        "",
        "OpenExternal",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lanthropic/claude/usercontent/sandbox/SystemSandboxToHostService;

.field public static final OpenExternal:Ljava/lang/String; = "anthropic.claude.usercontent.sandbox.OpenExternal"

.field public static final ReadyForContent:Ljava/lang/String; = "anthropic.claude.usercontent.sandbox.ReadyForContent"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lanthropic/claude/usercontent/sandbox/SystemSandboxToHostService;

    invoke-direct {v0}, Lanthropic/claude/usercontent/sandbox/SystemSandboxToHostService;-><init>()V

    sput-object v0, Lanthropic/claude/usercontent/sandbox/SystemSandboxToHostService;->INSTANCE:Lanthropic/claude/usercontent/sandbox/SystemSandboxToHostService;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
