.class public final Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u0005J\u0018\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u000b2\b\b\u0002\u0010\n\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000¨\u0006\f"
    }
    d2 = {
        "Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;",
        "",
        "<init>",
        "()V",
        "RenderMcpApp",
        "",
        "BridgeToSandbox",
        "Lanthropic/claude/usercontent/sandbox/wire_format/Request;",
        "payload",
        "Lanthropic/claude/usercontent/mcpapp/RenderMcpAppRequest;",
        "requestId",
        "Lanthropic/claude/usercontent/mcpapp/JsonRpcEnvelope;",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final BridgeToSandbox:Ljava/lang/String; = "anthropic.claude.usercontent.mcpapp.BridgeToSandbox"

.field public static final INSTANCE:Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;

.field public static final RenderMcpApp:Ljava/lang/String; = "anthropic.claude.usercontent.mcpapp.RenderMcpApp"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;

    invoke-direct {v0}, Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;-><init>()V

    sput-object v0, Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;->INSTANCE:Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic BridgeToSandbox$default(Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;Lanthropic/claude/usercontent/mcpapp/JsonRpcEnvelope;Ljava/lang/String;ILjava/lang/Object;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    invoke-static {}, Lw10;->M()Lgfj;

    move-result-object p2

    invoke-virtual {p2}, Lgfj;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_c
    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;->BridgeToSandbox(Lanthropic/claude/usercontent/mcpapp/JsonRpcEnvelope;Ljava/lang/String;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic RenderMcpApp$default(Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;Lanthropic/claude/usercontent/mcpapp/RenderMcpAppRequest;Ljava/lang/String;ILjava/lang/Object;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    invoke-static {}, Lw10;->M()Lgfj;

    move-result-object p2

    invoke-virtual {p2}, Lgfj;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_c
    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/mcpapp/McpAppRuntimeHostToSandboxService;->RenderMcpApp(Lanthropic/claude/usercontent/mcpapp/RenderMcpAppRequest;Ljava/lang/String;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final BridgeToSandbox(Lanthropic/claude/usercontent/mcpapp/JsonRpcEnvelope;Ljava/lang/String;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;
    .registers 11

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lanthropic/claude/usercontent/sandbox/wire_format/Request;

    sget-object p0, Lcom/squareup/wire/AnyMessage;->Companion:Lcom/squareup/wire/AnyMessage$Companion;

    invoke-virtual {p0, p1}, Lcom/squareup/wire/AnyMessage$Companion;->pack(Lcom/squareup/wire/Message;)Lcom/squareup/wire/AnyMessage;

    move-result-object v4

    const/16 v6, 0x10

    const/4 v7, 0x0

    const-string v1, "request"

    const-string v3, "anthropic.claude.usercontent.mcpapp.BridgeToSandbox"

    const/4 v5, 0x0

    move-object v2, p2

    invoke-direct/range {v0 .. v7}, Lanthropic/claude/usercontent/sandbox/wire_format/Request;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/squareup/wire/AnyMessage;Lokio/ByteString;ILry5;)V

    return-object v0
.end method

.method public final RenderMcpApp(Lanthropic/claude/usercontent/mcpapp/RenderMcpAppRequest;Ljava/lang/String;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;
    .registers 11

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lanthropic/claude/usercontent/sandbox/wire_format/Request;

    sget-object p0, Lcom/squareup/wire/AnyMessage;->Companion:Lcom/squareup/wire/AnyMessage$Companion;

    invoke-virtual {p0, p1}, Lcom/squareup/wire/AnyMessage$Companion;->pack(Lcom/squareup/wire/Message;)Lcom/squareup/wire/AnyMessage;

    move-result-object v4

    const/16 v6, 0x10

    const/4 v7, 0x0

    const-string v1, "request"

    const-string v3, "anthropic.claude.usercontent.mcpapp.RenderMcpApp"

    const/4 v5, 0x0

    move-object v2, p2

    invoke-direct/range {v0 .. v7}, Lanthropic/claude/usercontent/sandbox/wire_format/Request;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/squareup/wire/AnyMessage;Lokio/ByteString;ILry5;)V

    return-object v0
.end method
