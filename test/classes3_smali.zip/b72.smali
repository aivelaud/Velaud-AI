.class public final Lb72;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc72;


# static fields
.field public static final a:Lb72;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lb72;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lb72;->a:Lb72;

    return-void
.end method


# virtual methods
.method public final a(Lzu4;)F
    .registers 3

    check-cast p1, Leb8;

    const p0, -0x6fa97cf0

    invoke-virtual {p1, p0}, Leb8;->g0(I)V

    const/16 p0, 0x14

    invoke-static {p0, p1}, Ld52;->C(ILzu4;)F

    move-result p0

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Leb8;->q(Z)V

    return p0
.end method

.method public final b(Lzu4;)Liai;
    .registers 3

    check-cast p1, Leb8;

    const p0, -0x198c36e8

    invoke-virtual {p1, p0}, Leb8;->g0(I)V

    invoke-static {p1}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object p0

    iget-object p0, p0, Lkx3;->e:Lhk0;

    iget-object p0, p0, Lhk0;->E:Ljava/lang/Object;

    check-cast p0, Ljx3;

    iget-object p0, p0, Ljx3;->M:Ljava/lang/Object;

    check-cast p0, Liai;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Leb8;->q(Z)V

    return-object p0
.end method

.method public final c(Lzu4;)F
    .registers 3

    check-cast p1, Leb8;

    const p0, 0x4890ca63

    invoke-virtual {p1, p0}, Leb8;->g0(I)V

    const/16 p0, 0x24

    invoke-static {p0, p1}, Ld52;->C(ILzu4;)F

    move-result p0

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Leb8;->q(Z)V

    return p0
.end method

.method public final d()F
    .registers 1

    const/high16 p0, 0x42200000  # 40.0f

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of p0, p1, Lb72;

    if-nez p0, :cond_a

    const/4 p0, 0x0

    return p0

    :cond_a
    return v0
.end method

.method public final hashCode()I
    .registers 1

    const p0, -0xd65d667

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    const-string p0, "Small"

    return-object p0
.end method
