.class public final Layk;
.super Ln7l;
.source "SourceFile"


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    packed-switch p1, :pswitch_data_24

    :pswitch_3  #0x8, 0x9
    invoke-static {}, Lrll;->q()Lrll;

    move-result-object p1

    invoke-direct {p0, p1}, Ln7l;-><init>(Le8l;)V

    return-void

    :pswitch_b  #0xa
    invoke-static {}, Lfql;->q()Lfql;

    move-result-object p1

    invoke-direct {p0, p1}, Ln7l;-><init>(Le8l;)V

    return-void

    :pswitch_13  #0x7
    invoke-static {}, Lrnl;->q()Lrnl;

    move-result-object p1

    invoke-direct {p0, p1}, Ln7l;-><init>(Le8l;)V

    return-void

    :pswitch_1b  #0x6
    invoke-static {}, Lhnl;->q()Lhnl;

    move-result-object p1

    invoke-direct {p0, p1}, Ln7l;-><init>(Le8l;)V

    return-void

    nop

    :pswitch_data_24
    .packed-switch 0x6
        :pswitch_1b  #00000006
        :pswitch_13  #00000007
        :pswitch_3  #00000008
        :pswitch_3  #00000009
        :pswitch_b  #0000000a
    .end packed-switch
.end method
