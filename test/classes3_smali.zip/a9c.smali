.class public final La9c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Ljava/util/ArrayDeque;

.field public c:Z

.field public final synthetic d:Lb9c;


# direct methods
.method public constructor <init>(Lb9c;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La9c;->d:Lb9c;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La9c;->a:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, La9c;->b:Ljava/util/ArrayDeque;

    return-void
.end method


# virtual methods
.method public final a(Lct9;)V
    .registers 2

    iget-object p0, p0, La9c;->b:Ljava/util/ArrayDeque;

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->getLast()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lz8c;

    iput-object p1, p0, Lz8c;->d:Lct9;

    return-void
.end method

.method public final b(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
    .registers 5

    iget-boolean v0, p0, La9c;->c:Z

    if-eqz v0, :cond_5

    goto :goto_1a

    :cond_5
    const/4 v0, 0x1

    iput-boolean v0, p0, La9c;->c:Z

    iget-object p0, p0, La9c;->b:Ljava/util/ArrayDeque;

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->size()I

    move-result v1

    if-ne v1, v0, :cond_1b

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lz8c;

    iget-object v0, v0, Lz8c;->b:Ljava/lang/String;

    if-nez v0, :cond_1b

    :goto_1a
    return-object p1

    :cond_1b
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->descendingIterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_28
    :goto_28
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lz8c;

    const-string v2, "\nfor "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v1, Lz8c;->a:Ljava/lang/reflect/Type;

    iget-object v1, v1, Lz8c;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    if-eqz v1, :cond_28

    const/16 v2, 0x20

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_28

    :cond_4b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object p0
.end method

.method public final c(Z)V
    .registers 8

    iget-object v0, p0, La9c;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeLast()Ljava/lang/Object;

    iget-object v0, p0, La9c;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_e

    goto :goto_52

    :cond_e
    iget-object v0, p0, La9c;->d:Lb9c;

    iget-object v0, v0, Lb9c;->b:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    if-eqz p1, :cond_52

    iget-object p1, p0, La9c;->d:Lb9c;

    iget-object p1, p1, Lb9c;->c:Ljava/util/LinkedHashMap;

    monitor-enter p1

    :try_start_1c
    iget-object v0, p0, La9c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_23
    if-ge v1, v0, :cond_4e

    iget-object v2, p0, La9c;->a:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lz8c;

    iget-object v3, p0, La9c;->d:Lb9c;

    iget-object v3, v3, Lb9c;->c:Ljava/util/LinkedHashMap;

    iget-object v4, v2, Lz8c;->c:Ljava/lang/Object;

    iget-object v5, v2, Lz8c;->d:Lct9;

    invoke-interface {v3, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lct9;

    if-eqz v3, :cond_4b

    iput-object v3, v2, Lz8c;->d:Lct9;

    iget-object v4, p0, La9c;->d:Lb9c;

    iget-object v4, v4, Lb9c;->c:Ljava/util/LinkedHashMap;

    iget-object v2, v2, Lz8c;->c:Ljava/lang/Object;

    invoke-interface {v4, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4b

    :catchall_49
    move-exception p0

    goto :goto_50

    :cond_4b
    :goto_4b
    add-int/lit8 v1, v1, 0x1

    goto :goto_23

    :cond_4e
    monitor-exit p1

    return-void

    :goto_50
    monitor-exit p1
    :try_end_51
    .catchall {:try_start_1c .. :try_end_51} :catchall_49

    throw p0

    :cond_52
    :goto_52
    return-void
.end method

.method public final d(Ljava/lang/reflect/Type;Ljava/lang/String;Ljava/lang/Object;)Lct9;
    .registers 10

    iget-object v0, p0, La9c;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_7
    iget-object v3, p0, La9c;->b:Ljava/util/ArrayDeque;

    if-ge v2, v1, :cond_25

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lz8c;

    iget-object v5, v4, Lz8c;->c:Ljava/lang/Object;

    invoke-virtual {v5, p3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_22

    invoke-virtual {v3, v4}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    iget-object p0, v4, Lz8c;->d:Lct9;

    if-eqz p0, :cond_21

    return-object p0

    :cond_21
    return-object v4

    :cond_22
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_25
    new-instance p0, Lz8c;

    invoke-direct {p0, p1, p2, p3}, Lz8c;-><init>(Ljava/lang/reflect/Type;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3, p0}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    const/4 p0, 0x0

    return-object p0
.end method
