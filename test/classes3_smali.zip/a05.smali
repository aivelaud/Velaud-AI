.class public final La05;
.super Lc75;
.source "SourceFile"


# instance fields
.field public E:Lh05;

.field public F:Lvec;

.field public G:Lqz4;

.field public synthetic H:Ljava/lang/Object;

.field public final synthetic I:Lcom/anthropic/claude/connector/auth/b;

.field public J:I


# direct methods
.method public constructor <init>(Lcom/anthropic/claude/connector/auth/b;Lc75;)V
    .registers 3

    iput-object p1, p0, La05;->I:Lcom/anthropic/claude/connector/auth/b;

    invoke-direct {p0, p2}, Lc75;-><init>(La75;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, La05;->H:Ljava/lang/Object;

    iget p1, p0, La05;->J:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La05;->J:I

    iget-object p1, p0, La05;->I:Lcom/anthropic/claude/connector/auth/b;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lcom/anthropic/claude/connector/auth/b;->d(Lh05;Lc75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
