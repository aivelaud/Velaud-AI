.class public final Laak;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public E:Lixe;

.field public F:Lpng;

.field public G:Lexe;

.field public H:Lhxe;

.field public I:Ljava/util/List;

.field public J:Ljava/util/List;

.field public K:Lixe;

.field public L:Lixe;

.field public M:Lexe;

.field public N:Lexe;

.field public O:Lexe;

.field public P:Lixe;

.field public Q:Lixe;

.field public R:Lcp2;

.field public S:Lpe9;

.field public T:Lexe;

.field public U:Lcp2;

.field public V:Ljava/lang/Object;

.field public W:Long;

.field public X:Ljava/lang/Object;

.field public Y:Ljava/lang/Object;

.field public Z:Ljava/lang/Object;

.field public a0:Ljava/lang/Object;

.field public b0:Ljava/lang/Object;

.field public c0:Ljava/util/Iterator;

.field public d0:Long;

.field public e0:I

.field public f0:I

.field public g0:I

.field public h0:I

.field public i0:Z

.field public j0:Z

.field public k0:J

.field public l0:J

.field public m0:I

.field public synthetic n0:Ljava/lang/Object;

.field public final synthetic o0:Leak;

.field public final synthetic p0:Lnlh;

.field public final synthetic q0:Z

.field public final synthetic r0:Ljava/lang/String;

.field public final synthetic s0:Z


# direct methods
.method public constructor <init>(Leak;Lnlh;ZLjava/lang/String;ZLa75;)V
    .registers 7

    iput-object p1, p0, Laak;->o0:Leak;

    iput-object p2, p0, Laak;->p0:Lnlh;

    iput-boolean p3, p0, Laak;->q0:Z

    iput-object p4, p0, Laak;->r0:Ljava/lang/String;

    iput-boolean p5, p0, Laak;->s0:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Lavh;-><init>(ILa75;)V

    return-void
.end method

.method public static final d(Lo1e;Leak;Lnlh;Ljava/util/List;Lixe;Lcom/anthropic/claude/sessions/types/ControlRequestBody;Llq4;Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;Lc75;)Ljava/lang/Object;
    .registers 14

    instance-of v0, p8, Lx9k;

    if-eqz v0, :cond_13

    move-object v0, p8

    check-cast v0, Lx9k;

    iget v1, v0, Lx9k;->M:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lx9k;->M:I

    goto :goto_18

    :cond_13
    new-instance v0, Lx9k;

    invoke-direct {v0, p8}, Lc75;-><init>(La75;)V

    :goto_18
    iget-object p8, v0, Lx9k;->L:Ljava/lang/Object;

    iget v1, v0, Lx9k;->M:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_45

    if-ne v1, v2, :cond_3f

    iget-object p0, v0, Lx9k;->K:Ljava/util/Iterator;

    iget-object p1, v0, Lx9k;->J:Ljava/lang/String;

    iget-object p7, v0, Lx9k;->I:Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;

    iget-object p6, v0, Lx9k;->H:Llq4;

    iget-object p2, v0, Lx9k;->G:Lixe;

    iget-object p3, v0, Lx9k;->F:Ljava/util/List;

    check-cast p3, Ljava/util/List;

    iget-object p4, v0, Lx9k;->E:Lo1e;

    :try_start_32
    invoke-static {p8}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_35
    .catch Ljava/util/concurrent/CancellationException; {:try_start_32 .. :try_end_35} :catch_18e
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_35} :catch_3b

    move-object v4, p2

    move-object p2, p1

    move-object p1, p4

    move-object p4, v4

    goto/16 :goto_9c

    :catch_3b
    move-exception p0

    move-object p1, p4

    goto/16 :goto_126

    :cond_3f
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-object v3

    :cond_45
    invoke-static {p8}, Lw10;->P(Ljava/lang/Object;)V

    invoke-virtual {p7}, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;->getSubtype()Ljava/lang/String;

    move-result-object p8

    const-string v1, "success"

    invoke-static {p8, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p8

    if-eqz p8, :cond_56

    move-object p8, p7

    goto :goto_57

    :cond_56
    move-object p8, v3

    :goto_57
    if-eqz p8, :cond_83

    invoke-virtual {p8}, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;->getResponse()Lkotlinx/serialization/json/JsonElement;

    move-result-object p8

    if-eqz p8, :cond_83

    :try_start_5f
    iget-object p1, p1, Leak;->e:Lxs9;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lcom/anthropic/claude/sessions/types/ConversationRewoundPayload;->Companion:Ld85;

    invoke-virtual {v1}, Ld85;->serializer()Lkotlinx/serialization/KSerializer;

    move-result-object v1

    check-cast v1, Lu86;

    invoke-virtual {p1, v1, p8}, Lxs9;->a(Lu86;Lkotlinx/serialization/json/JsonElement;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/anthropic/claude/sessions/types/ConversationRewoundPayload;
    :try_end_72
    .catchall {:try_start_5f .. :try_end_72} :catchall_73

    goto :goto_7a

    :catchall_73
    move-exception p1

    new-instance p8, Lbgf;

    invoke-direct {p8, p1}, Lbgf;-><init>(Ljava/lang/Throwable;)V

    move-object p1, p8

    :goto_7a
    nop

    instance-of p8, p1, Lbgf;

    if-eqz p8, :cond_80

    move-object p1, v3

    :cond_80
    check-cast p1, Lcom/anthropic/claude/sessions/types/ConversationRewoundPayload;

    goto :goto_84

    :cond_83
    move-object p1, v3

    :goto_84
    invoke-static {p5, p1}, Lsig;->a(Lcom/anthropic/claude/sessions/types/ControlRequestBody;Lcom/anthropic/claude/sessions/types/ConversationRewoundPayload;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_190

    :try_start_8a
    invoke-virtual {p2}, Lnlh;->c()Lhhg;

    move-result-object p2

    invoke-virtual {p2, p1}, Lhhg;->d(Ljava/lang/String;)Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2
    :try_end_98
    .catch Ljava/util/concurrent/CancellationException; {:try_start_8a .. :try_end_98} :catch_18e
    .catch Ljava/lang/Exception; {:try_start_8a .. :try_end_98} :catch_122

    move-object v4, p1

    move-object p1, p0

    move-object p0, p2

    move-object p2, v4

    :cond_9c
    :goto_9c
    :try_start_9c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p5

    if-eqz p5, :cond_c8

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Long;

    iput-object p1, v0, Lx9k;->E:Lo1e;

    move-object p8, p3

    check-cast p8, Ljava/util/List;

    iput-object p8, v0, Lx9k;->F:Ljava/util/List;

    iput-object p4, v0, Lx9k;->G:Lixe;

    iput-object p6, v0, Lx9k;->H:Llq4;

    iput-object p7, v0, Lx9k;->I:Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;

    iput-object p2, v0, Lx9k;->J:Ljava/lang/String;

    iput-object p0, v0, Lx9k;->K:Ljava/util/Iterator;

    iput v2, v0, Lx9k;->M:I

    iget-object p8, p1, Lo1e;->J:Ly42;

    invoke-interface {p8, v0, p5}, Ldbg;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p5
    :try_end_c1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_9c .. :try_end_c1} :catch_18e
    .catch Ljava/lang/Exception; {:try_start_9c .. :try_end_c1} :catch_c6

    sget-object p8, Lva5;->E:Lva5;

    if-ne p5, p8, :cond_9c

    return-object p8

    :catch_c6
    move-exception p0

    goto :goto_126

    :cond_c8
    :try_start_c8
    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 p5, 0x0

    :goto_cd
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p8

    if-eqz p8, :cond_e7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p8

    check-cast p8, Lcom/anthropic/claude/sessions/types/SdkEvent;

    invoke-static {p8}, Lolk;->h(Lcom/anthropic/claude/sessions/types/SdkEvent;)Ljava/lang/String;

    move-result-object p8

    invoke-static {p8, p2}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p8

    if-eqz p8, :cond_e4

    goto :goto_e8

    :cond_e4
    add-int/lit8 p5, p5, 0x1

    goto :goto_cd

    :cond_e7
    const/4 p5, -0x1

    :goto_e8
    if-ltz p5, :cond_190

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result p0

    invoke-interface {p3, p5, p0}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->clear()V

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result p0

    invoke-interface {p3, p0}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    move-result-object p0

    :cond_fd
    invoke-interface {p0}, Ljava/util/ListIterator;->hasPrevious()Z

    move-result p2

    if-eqz p2, :cond_10f

    invoke-interface {p0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    move-result-object p2

    move-object p3, p2

    check-cast p3, Lcom/anthropic/claude/sessions/types/SdkEvent;

    instance-of p3, p3, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;

    if-eqz p3, :cond_fd

    goto :goto_110

    :cond_10f
    move-object p2, v3

    :goto_110
    instance-of p0, p2, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;

    if-eqz p0, :cond_117

    check-cast p2, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;

    goto :goto_118

    :cond_117
    move-object p2, v3

    :goto_118
    if-eqz p2, :cond_11e

    invoke-virtual {p2}, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;->getUuid()Ljava/lang/String;

    move-result-object v3

    :cond_11e
    iput-object v3, p4, Lixe;->E:Ljava/lang/Object;
    :try_end_120
    .catch Ljava/util/concurrent/CancellationException; {:try_start_c8 .. :try_end_120} :catch_18e
    .catch Ljava/lang/Exception; {:try_start_c8 .. :try_end_120} :catch_c6

    goto/16 :goto_190

    :catch_122
    move-exception p1

    move-object v4, p1

    move-object p1, p0

    move-object p0, v4

    :goto_126
    sget-object p2, Lmta;->a:Llta;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Llta;->b()Z

    move-result p2

    if-nez p2, :cond_132

    goto :goto_190

    :cond_132
    invoke-static {p1}, Lp8;->I(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    sget-object p2, Llta;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_141
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_157

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    move-object p5, p4

    check-cast p5, Lmta;

    check-cast p5, Ls40;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_141

    :cond_157
    invoke-virtual {p3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_190

    sget-object p2, Lmta;->a:Llta;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    sget-object p2, Loze;->a:Lpze;

    invoke-virtual {p2, p0}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object p0

    invoke-interface {p0}, Lky9;->f()Ljava/lang/String;

    move-result-object p0

    const-string p2, "inline rewind fold threw: "

    invoke-static {p2, p0}, Lb40;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_17a
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_190

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lmta;

    check-cast p3, Ls40;

    sget-object p4, Lfta;->I:Lfta;

    invoke-virtual {p3, p4, p1, p0}, Ls40;->b(Lfta;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_17a

    :catch_18e
    move-exception p0

    throw p0

    :cond_190
    :goto_190
    invoke-virtual {p6, p7}, Lrs9;->b0(Ljava/lang/Object;)Z

    sget-object p0, Lz2j;->a:Lz2j;

    return-object p0
.end method

.method public static final n(Lexe;Lixe;Lo1e;ZLeak;Ljava/lang/String;)V
    .registers 21

    move-object/from16 v6, p1

    iget-boolean v0, p0, Lexe;->E:Z

    if-nez v0, :cond_49

    iget-object v0, v6, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lhs9;

    const/4 v1, 0x1

    if-eqz v0, :cond_14

    invoke-interface {v0}, Lhs9;->b()Z

    move-result v0

    if-ne v0, v1, :cond_14

    goto :goto_49

    :cond_14
    iput-boolean v1, p0, Lexe;->E:Z

    invoke-static {}, Lti6;->j()Ljava/lang/String;

    move-result-object v10

    sget-object v0, Lcom/anthropic/claude/sessions/types/ControlRequestBody;->Companion:Lcom/anthropic/claude/sessions/types/o;

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v14, 0x0

    if-eqz p3, :cond_22

    goto :goto_23

    :cond_22
    move-object v2, v14

    :goto_23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v11, Lcom/anthropic/claude/sessions/types/ControlRequestBody$Initialize;

    invoke-direct {v11, v14, v2, v1, v14}, Lcom/anthropic/claude/sessions/types/ControlRequestBody$Initialize;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ILry5;)V

    new-instance v3, Lcom/anthropic/claude/sessions/types/StdinMessage$ControlRequest;

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x0

    move-object v7, v3

    invoke-direct/range {v7 .. v13}, Lcom/anthropic/claude/sessions/types/StdinMessage$ControlRequest;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/anthropic/claude/sessions/types/ControlRequestBody;ILry5;)V

    new-instance v0, Ly9k;

    const/4 v5, 0x0

    move-object v4, p0

    move-object/from16 v1, p4

    move-object/from16 v2, p5

    invoke-direct/range {v0 .. v5}, Ly9k;-><init>(Leak;Ljava/lang/String;Lcom/anthropic/claude/sessions/types/StdinMessage$ControlRequest;Lexe;La75;)V

    const/4 v1, 0x3

    move-object/from16 v2, p2

    invoke-static {v2, v14, v14, v0, v1}, Lao9;->S(Lua5;Lla5;Lxa5;Lq98;I)Lpfh;

    move-result-object v0

    iput-object v0, v6, Lixe;->E:Ljava/lang/Object;

    :cond_49
    :goto_49
    return-void
.end method

.method public static final q(Lexe;Lhxe;Lo1e;Lpng;Laak;)Ljava/lang/Object;
    .registers 7

    const/4 v0, 0x0

    iput-boolean v0, p0, Lexe;->E:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p1, Lhxe;->E:J

    new-instance p0, Lnmg;

    invoke-virtual {p3}, Lpng;->g()Lrlh;

    move-result-object p1

    invoke-direct {p0, p1}, Lnmg;-><init>(Lrlh;)V

    iget-object p1, p2, Lo1e;->J:Ly42;

    invoke-interface {p1, p4, p0}, Ldbg;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 10

    new-instance v0, Laak;

    iget-object v4, p0, Laak;->r0:Ljava/lang/String;

    iget-boolean v5, p0, Laak;->s0:Z

    iget-object v1, p0, Laak;->o0:Leak;

    iget-object v2, p0, Laak;->p0:Lnlh;

    iget-boolean v3, p0, Laak;->q0:Z

    move-object v6, p2

    invoke-direct/range {v0 .. v6}, Laak;-><init>(Leak;Lnlh;ZLjava/lang/String;ZLa75;)V

    iput-object p1, v0, Laak;->n0:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lo1e;

    check-cast p2, La75;

    invoke-virtual {p0, p1, p2}, Laak;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Laak;

    sget-object p1, Lz2j;->a:Lz2j;

    invoke-virtual {p0, p1}, Laak;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 214

    move-object/from16 v5, p0

    sget-object v10, Lyv6;->E:Lyv6;

    sget-object v11, Lfta;->I:Lfta;

    iget-boolean v12, v5, Laak;->q0:Z

    iget-object v13, v5, Laak;->r0:Ljava/lang/String;

    iget-object v14, v5, Laak;->o0:Leak;

    iget-object v15, v5, Laak;->p0:Lnlh;

    iget-object v0, v5, Laak;->n0:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lo1e;

    sget-object v2, Lva5;->E:Lva5;

    iget v0, v5, Laak;->m0:I

    const-wide/16 v18, 0x3e8

    const/4 v3, 0x0

    packed-switch v0, :pswitch_data_7746

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Le97;->j(Ljava/lang/String;)V

    return-object v3

    :pswitch_23  #0x2a
    iget-object v0, v5, Laak;->J:Ljava/util/List;

    check-cast v0, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    check-cast v0, Ljava/util/List;

    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V

    goto/32 :goto_75ec

    :pswitch_31  #0x29
    iget v0, v5, Laak;->g0:I

    move-object/from16 v29, v10

    iget-wide v9, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v3, v5, Laak;->i0:Z

    iget v6, v5, Laak;->e0:I

    iget-object v8, v5, Laak;->P:Lixe;

    iget-object v7, v5, Laak;->O:Lexe;

    move-object/from16 v35, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v36, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->E:Lixe;

    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V

    move/from16 v58, v0

    move v0, v6

    move-object/from16 v51, v13

    move-object/from16 v52, v14

    move-object/from16 v32, v15

    move-object/from16 v15, v43

    move-object/from16 v6, v44

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move v14, v3

    move-object v13, v8

    move-object/from16 v44, v11

    move-object/from16 v3, v35

    move-object/from16 v8, v38

    move-object/from16 v35, v40

    move-object v11, v7

    move-object/from16 v7, v42

    move-object/from16 v208, v39

    move/from16 v39, v12

    move-object/from16 v12, v36

    move-object/from16 v36, v41

    move-wide/from16 v209, v9

    move-object/from16 v9, v37

    move-wide/from16 v37, v209

    move-object/from16 v10, v208

    goto/32 :goto_7715

    :pswitch_b1  #0x28
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v0, v5, Laak;->h0:I

    iget-wide v3, v5, Laak;->l0:J

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v8, v5, Laak;->f0:I

    iget-boolean v9, v5, Laak;->i0:Z

    iget v10, v5, Laak;->e0:I

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V

    move/from16 v16, v12

    move v12, v9

    move-object/from16 v9, v39

    move/from16 v39, v16

    move-object/from16 v53, v2

    move-wide/from16 v16, v3

    move-object/from16 v51, v13

    move-object/from16 v52, v14

    move-object/from16 v32, v15

    move/from16 v20, v36

    move-object/from16 v3, v38

    move-object/from16 v4, v42

    move-object/from16 v36, v44

    move-object/from16 v2, v45

    move-object/from16 v15, v46

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move v13, v8

    move v14, v10

    move-object/from16 v44, v11

    move-object/from16 v10, v37

    move-object/from16 v8, v40

    move-object v11, v1

    move-wide/from16 v37, v6

    move-object/from16 v1, v35

    move-object/from16 v7, v41

    move-object/from16 v41, v43

    move-object/from16 v6, v47

    goto/32 :goto_7691

    :pswitch_141  #0x27
    move-object/from16 v35, v1

    iget v0, v5, Laak;->g0:I

    iget-wide v3, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v6, v5, Laak;->i0:Z

    iget v7, v5, Laak;->e0:I

    iget-object v8, v5, Laak;->J:Ljava/util/List;

    check-cast v8, Ljava/util/List;

    iget-object v8, v5, Laak;->I:Ljava/util/List;

    check-cast v8, Ljava/util/List;

    iget-object v8, v5, Laak;->E:Lixe;

    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V

    move v12, v1

    move-object/from16 v1, v35

    goto/32 :goto_7591

    :pswitch_160  #0x26
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Long;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/util/Iterator;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    iget-object v0, v5, Laak;->X:Ljava/lang/Object;

    check-cast v0, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1c8
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1cb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1c8 .. :try_end_1cb} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1c8 .. :try_end_1cb} :catch_21c
    .catchall {:try_start_1c8 .. :try_end_1cb} :catchall_218

    move/from16 v205, v3

    move/from16 v206, v4

    move-wide/from16 v201, v6

    move/from16 v203, v8

    move/from16 v204, v9

    move-object/from16 v20, v10

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v4, v35

    move-wide/from16 v199, v36

    move-object/from16 v3, v39

    move-object/from16 v10, v40

    move-object/from16 v6, v44

    move-object/from16 v15, v46

    move-object/from16 v36, v48

    move-object/from16 v14, v49

    move-object/from16 v9, v50

    move-object/from16 v8, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v7, v1

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v51, v13

    move-object/from16 v12, v41

    move-object/from16 v13, v42

    move-object/from16 v11, v43

    move-object/from16 v41, v47

    move-object v1, v0

    move-object/from16 v0, v38

    goto/32 :goto_6a85

    :catchall_218
    move-exception v0

    goto/32 :goto_772a

    :catch_21c
    move-exception v0

    move/from16 v17, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v17

    move/from16 v37, v9

    move-object/from16 v32, v15

    move-object/from16 v33, v39

    move-object/from16 v52, v41

    move-object/from16 v38, v42

    move-object/from16 v17, v45

    move-object/from16 v15, v46

    move-object/from16 v41, v47

    move-object/from16 v36, v48

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v48, v3

    move/from16 v45, v4

    move-wide/from16 v46, v6

    move-object v4, v11

    move/from16 v39, v12

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v12, v43

    move-object/from16 v6, v44

    move-object/from16 v14, v49

    move-object/from16 v11, v50

    :goto_25e
    const/4 v7, 0x1

    move-object/from16 v43, v40

    goto/32 :goto_7437

    :catch_264
    move-exception v0

    goto/32 :goto_7729

    :pswitch_268  #0x25
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lcig;

    iget-object v10, v5, Laak;->W:Long;

    check-cast v10, Luuc;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Lcp2;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object v0, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_2c3
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_2c6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c3 .. :try_end_2c6} :catch_264
    .catch Ljava/lang/Exception; {:try_start_2c3 .. :try_end_2c6} :catch_30e
    .catchall {:try_start_2c3 .. :try_end_2c6} :catchall_218

    move/from16 v85, v3

    move/from16 v86, v4

    move-wide/from16 v81, v6

    move/from16 v83, v8

    move/from16 v84, v9

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v3, v35

    move-object/from16 v15, v39

    move-object/from16 v4, v40

    move-object/from16 v13, v41

    move-object/from16 v6, v43

    move-object/from16 v14, v44

    move-object/from16 v41, v46

    move-object/from16 v9, v49

    move-object/from16 v8, v50

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v7, v1

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v1, v38

    move-object/from16 v12, v45

    move-object/from16 v11, v48

    move-wide/from16 v37, v36

    move-object/from16 v36, v47

    goto/32 :goto_651f

    :catch_30e
    move-exception v0

    move/from16 v17, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v17

    move/from16 v37, v9

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v32, v15

    move-object/from16 v33, v38

    move-object/from16 v52, v40

    move-object/from16 v38, v41

    move-object/from16 v17, v44

    move-object/from16 v15, v45

    move-object/from16 v41, v46

    move-object/from16 v36, v47

    move-object/from16 v14, v48

    move-object/from16 v9, v50

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v48, v3

    move/from16 v45, v4

    move-wide/from16 v46, v6

    move-object v4, v11

    move-object/from16 v6, v43

    move-object/from16 v11, v49

    const/4 v7, 0x1

    move-object/from16 v43, v39

    move/from16 v39, v12

    move-object/from16 v12, v42

    goto/32 :goto_7437

    :pswitch_356  #0x24
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Exception;

    iget-object v4, v5, Laak;->X:Ljava/lang/Object;

    check-cast v4, Lcig;

    iget-object v4, v5, Laak;->W:Long;

    check-cast v4, Luuc;

    iget-object v4, v5, Laak;->V:Ljava/lang/Object;

    check-cast v4, Lcp2;

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_3ac
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_3af
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3ac .. :try_end_3af} :catch_264
    .catch Ljava/lang/Exception; {:try_start_3ac .. :try_end_3af} :catch_3ea
    .catchall {:try_start_3ac .. :try_end_3af} :catchall_218

    move/from16 v17, v8

    move-object/from16 v33, v10

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v13, v39

    move-object/from16 v15, v42

    move-object/from16 v48, v44

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v1, v35

    move-object/from16 v12, v40

    move/from16 v208, v3

    move-object v3, v2

    move/from16 v2, v36

    move-wide/from16 v35, v6

    move-object/from16 v6, v38

    move/from16 v7, v208

    goto/32 :goto_6821

    :catch_3ea
    move-exception v0

    move/from16 v17, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v17

    move-object/from16 v17, v39

    move/from16 v39, v12

    move-object/from16 v12, v17

    move-object/from16 v33, v4

    move-object v4, v11

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v32, v15

    move/from16 v48, v36

    move-object/from16 v52, v37

    move-object/from16 v17, v41

    move-object/from16 v15, v42

    move-object/from16 v41, v43

    move-object/from16 v36, v44

    :goto_40c
    move-object/from16 v14, v45

    move-object/from16 v11, v46

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v45, v3

    move/from16 v37, v9

    move-object/from16 v43, v10

    move-object/from16 v9, v47

    move-wide/from16 v46, v6

    move-object/from16 v6, v40

    :goto_42e
    const/4 v7, 0x1

    goto/32 :goto_7437

    :pswitch_432  #0x23
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v3, v5, Laak;->l0:J

    iget-wide v6, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->c0:Ljava/util/Iterator;

    check-cast v0, Lomg;

    iget-object v0, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v0, Lxmg;

    iget-object v0, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v0, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    iget-object v0, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v0, Lcom/anthropic/claude/api/result/ApiResult;

    iget-object v0, v5, Laak;->X:Ljava/lang/Object;

    check-cast v0, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v10, v5, Laak;->U:Lcp2;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_49e
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_4a1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_49e .. :try_end_4a1} :catch_52b
    .catch Ljava/lang/Exception; {:try_start_49e .. :try_end_4a1} :catch_4e0
    .catchall {:try_start_49e .. :try_end_4a1} :catchall_218

    move/from16 v27, v8

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move/from16 v33, v36

    move-object/from16 v13, v37

    move-object/from16 v37, v38

    move-object/from16 v20, v41

    move-object/from16 v15, v44

    move-object/from16 v14, v47

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object/from16 v44, v11

    move-object/from16 v1, v42

    move-wide/from16 v41, v6

    move-object/from16 v7, v39

    move-object/from16 v6, v40

    move/from16 v39, v12

    move-wide v11, v3

    move-object v3, v2

    move-object/from16 v2, v35

    move-object/from16 v35, v10

    move-object/from16 v10, v43

    goto/16 :goto_6071

    :catch_4e0
    move-exception v0

    move-object/from16 v59, v2

    move-wide/from16 v195, v3

    move-wide/from16 v197, v6

    move/from16 v17, v8

    move/from16 v20, v9

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move/from16 v16, v36

    move-object/from16 v4, v37

    move-object/from16 v3, v38

    move-object/from16 v7, v39

    move-object/from16 v6, v40

    move-object/from16 v13, v41

    move-object/from16 v10, v43

    move-object/from16 v15, v44

    move-object/from16 v14, v47

    move-object/from16 v9, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v1, v35

    move-object/from16 v12, v42

    move-object/from16 v47, v45

    move-object/from16 v11, v48

    move-object/from16 v48, v46

    goto/32 :goto_6790

    :catch_52b
    move-exception v0

    move-object v3, v2

    move/from16 v33, v8

    move/from16 v27, v9

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v13, v37

    move-object/from16 v37, v39

    move-object/from16 v16, v40

    move-object/from16 v17, v41

    move-object/from16 v10, v43

    move-object/from16 v15, v44

    move-object/from16 v14, v47

    move-object/from16 v9, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v1, v35

    move-object/from16 v12, v42

    move-object/from16 v47, v45

    move-object/from16 v11, v48

    move/from16 v42, v36

    move-object/from16 v48, v46

    goto/32 :goto_68af

    :pswitch_56f  #0x22
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v3, v5, Laak;->l0:J

    iget v0, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    check-cast v10, Ldng;

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Lxmg;

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/api/result/ApiResult;

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_5e1
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_5e4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5e1 .. :try_end_5e4} :catch_66c
    .catch Ljava/lang/Exception; {:try_start_5e1 .. :try_end_5e4} :catch_625
    .catchall {:try_start_5e1 .. :try_end_5e4} :catchall_218

    move-object/from16 v16, v41

    move/from16 v41, v36

    move-object/from16 v36, v16

    move/from16 v33, v8

    move/from16 v27, v9

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v20, v37

    move-object/from16 v16, v38

    move-object/from16 v17, v43

    move-object/from16 v14, v49

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-wide/from16 v37, v6

    move-object/from16 v51, v13

    move-object/from16 v13, v39

    move-object/from16 v1, v44

    move-wide v6, v3

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v4, v40

    move-object/from16 v11, v50

    move-object v3, v2

    goto/16 :goto_5e25

    :catch_625
    move-exception v0

    move-object/from16 v59, v2

    move-wide/from16 v195, v3

    move-wide/from16 v197, v6

    move/from16 v17, v8

    move/from16 v20, v9

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move/from16 v16, v36

    move-object/from16 v4, v39

    move-object/from16 v3, v40

    move-object/from16 v7, v41

    move-object/from16 v6, v42

    move-object/from16 v10, v45

    move-object/from16 v15, v46

    move-object/from16 v14, v49

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move/from16 v39, v12

    move-object/from16 v51, v13

    move-object/from16 v1, v35

    move-object/from16 v13, v43

    move-object/from16 v12, v44

    move-object/from16 v44, v11

    move-object/from16 v11, v50

    goto/32 :goto_6790

    :catch_66c
    move-exception v0

    move-object v3, v2

    move/from16 v33, v8

    move/from16 v27, v9

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v38, v40

    move-object/from16 v37, v41

    move-object/from16 v16, v42

    move-object/from16 v17, v43

    move-object/from16 v10, v45

    move-object/from16 v15, v46

    move-object/from16 v14, v49

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object/from16 v51, v13

    move-object/from16 v1, v35

    move/from16 v42, v36

    move-object/from16 v13, v39

    move/from16 v39, v12

    move-object/from16 v12, v44

    move-object/from16 v44, v11

    move-object/from16 v11, v50

    goto/32 :goto_68af

    :pswitch_6ae  #0x21
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v3, v5, Laak;->l0:J

    iget v0, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    check-cast v10, Lrmg;

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Lxmg;

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/api/result/ApiResult;

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_720
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_723
    .catch Ljava/util/concurrent/CancellationException; {:try_start_720 .. :try_end_723} :catch_66c
    .catch Ljava/lang/Exception; {:try_start_720 .. :try_end_723} :catch_625
    .catchall {:try_start_720 .. :try_end_723} :catchall_218

    move/from16 v33, v8

    move/from16 v27, v9

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v20, v37

    move-object/from16 v16, v38

    move-object/from16 v17, v43

    move-object/from16 v14, v49

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-wide/from16 v37, v6

    move-object/from16 v51, v13

    move-object/from16 v1, v35

    move-object/from16 v13, v39

    move-object/from16 v35, v40

    move-object/from16 v7, v41

    move-object/from16 v6, v42

    move-wide/from16 v41, v3

    move/from16 v39, v12

    move-object/from16 v12, v44

    move-object v3, v2

    move-object/from16 v44, v11

    move-object/from16 v11, v50

    goto/16 :goto_5c1b

    :pswitch_765  #0x20
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v3, v5, Laak;->l0:J

    iget v0, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    check-cast v10, Lqmg;

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Lxmg;

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/api/result/ApiResult;

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_7d7
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_7da
    .catch Ljava/util/concurrent/CancellationException; {:try_start_7d7 .. :try_end_7da} :catch_66c
    .catch Ljava/lang/Exception; {:try_start_7d7 .. :try_end_7da} :catch_625
    .catchall {:try_start_7d7 .. :try_end_7da} :catchall_218

    move-object/from16 v16, v41

    move/from16 v41, v36

    move-object/from16 v36, v16

    move/from16 v33, v8

    move/from16 v27, v9

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v20, v37

    move-object/from16 v16, v38

    move-object/from16 v14, v49

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-wide/from16 v37, v6

    move-object/from16 v51, v13

    move-object/from16 v13, v39

    move-object/from16 v1, v44

    move-wide v6, v3

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v12, v40

    move-object/from16 v3, v43

    move-object/from16 v11, v50

    goto/16 :goto_5961

    :pswitch_81a  #0x1f
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v3, v5, Laak;->l0:J

    iget v0, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    check-cast v10, Lgng;

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Lxmg;

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/api/result/ApiResult;

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_88c
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_88f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_88c .. :try_end_88f} :catch_66c
    .catch Ljava/lang/Exception; {:try_start_88c .. :try_end_88f} :catch_625
    .catchall {:try_start_88c .. :try_end_88f} :catchall_218

    move/from16 v33, v9

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v20, v37

    move-object/from16 v16, v38

    move-object/from16 v37, v41

    move-object/from16 v14, v49

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v51, v13

    move/from16 v38, v36

    move-object/from16 v13, v39

    move-object/from16 v36, v42

    move-wide/from16 v41, v6

    move/from16 v39, v12

    move-object/from16 v12, v44

    move-wide v6, v3

    move v4, v8

    move-object/from16 v44, v11

    move-object/from16 v3, v40

    move-object/from16 v11, v50

    move-object v8, v1

    move-object/from16 v1, v43

    :goto_8ca
    const/4 v15, 0x1

    goto/16 :goto_56bc

    :pswitch_8cd  #0x1e
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v3, v5, Laak;->l0:J

    iget v0, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Lxmg;

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/api/result/ApiResult;

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_93b
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_93e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_93b .. :try_end_93e} :catch_66c
    .catch Ljava/lang/Exception; {:try_start_93b .. :try_end_93e} :catch_625
    .catchall {:try_start_93b .. :try_end_93e} :catchall_218

    move-object/from16 v59, v2

    move-wide/from16 v156, v3

    move-wide/from16 v158, v6

    move/from16 v160, v8

    move/from16 v161, v9

    move-object/from16 p1, v10

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v4, v35

    move/from16 v155, v36

    move-object/from16 v154, v37

    move-object/from16 v16, v38

    move-object/from16 v2, v39

    move-object/from16 v7, v41

    move-object/from16 v6, v42

    move-object/from16 v10, v45

    move-object/from16 v15, v46

    move-object/from16 v14, v49

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move/from16 v39, v12

    move-object/from16 v51, v13

    move-object/from16 v13, v40

    move-object/from16 v1, v43

    move-object/from16 v12, v44

    move-object/from16 v44, v11

    move-object/from16 v11, v50

    goto/16 :goto_55c0

    :pswitch_987  #0x1d
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v3, v5, Laak;->l0:J

    iget v0, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v1, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lcig;

    iget-object v10, v5, Laak;->W:Long;

    check-cast v10, Luuc;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Lcp2;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_9e3
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_9e6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_9e3 .. :try_end_9e6} :catch_a7f
    .catch Ljava/lang/Exception; {:try_start_9e3 .. :try_end_9e6} :catch_a34
    .catchall {:try_start_9e3 .. :try_end_9e6} :catchall_218

    move-wide/from16 v147, v3

    move-wide/from16 v149, v6

    move/from16 v151, v8

    move/from16 v152, v9

    move-object/from16 v153, v10

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v4, v35

    move/from16 v146, v36

    move-object/from16 v145, v37

    move-object/from16 v144, v38

    move-object/from16 v143, v39

    move-object/from16 v142, v40

    move-object/from16 v13, v42

    move-object/from16 v10, v44

    move-object/from16 v15, v45

    move-object/from16 v14, v48

    move-object/from16 v9, v50

    const/4 v7, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object v1, v2

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v12, v43

    move-object/from16 v11, v49

    move v2, v0

    move-object/from16 v0, p1

    :goto_a2c
    move-object/from16 v141, v41

    move-object/from16 v6, v46

    move-object/from16 v3, v47

    goto/16 :goto_53ee

    :catch_a34
    move-exception v0

    move-object/from16 v59, v2

    move-wide/from16 v195, v3

    move-wide/from16 v197, v6

    move/from16 v17, v8

    move/from16 v20, v9

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move/from16 v16, v36

    move-object/from16 v4, v38

    move-object/from16 v3, v39

    move-object/from16 v7, v40

    move-object/from16 v6, v41

    move-object/from16 v13, v42

    move-object/from16 v10, v44

    move-object/from16 v15, v45

    move-object/from16 v14, v48

    move-object/from16 v9, v50

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v1, v35

    move-object/from16 v12, v43

    move-object/from16 v48, v47

    move-object/from16 v11, v49

    :goto_a7a
    move-object/from16 v47, v46

    goto/32 :goto_6790

    :catch_a7f
    move-exception v0

    move-object v3, v2

    move/from16 v33, v8

    move/from16 v27, v9

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v13, v38

    move-object/from16 v38, v39

    move-object/from16 v37, v40

    move-object/from16 v16, v41

    move-object/from16 v17, v42

    move-object/from16 v10, v44

    move-object/from16 v15, v45

    move-object/from16 v14, v48

    move-object/from16 v9, v50

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v1, v35

    move/from16 v42, v36

    move-object/from16 v12, v43

    move-object/from16 v48, v47

    move-object/from16 v11, v49

    :goto_ac0
    move-object/from16 v47, v46

    goto/32 :goto_68af

    :pswitch_ac5  #0x1c
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lcig;

    iget-object v10, v5, Laak;->W:Long;

    check-cast v10, Luuc;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Lcp2;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object v0, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_b20
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_b23
    .catch Ljava/util/concurrent/CancellationException; {:try_start_b20 .. :try_end_b23} :catch_264
    .catch Ljava/lang/Exception; {:try_start_b20 .. :try_end_b23} :catch_30e
    .catchall {:try_start_b20 .. :try_end_b23} :catchall_218

    move-object/from16 v59, v2

    move/from16 v140, v3

    move/from16 v17, v4

    move-wide/from16 v138, v6

    move/from16 v20, v8

    move/from16 v27, v9

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v32, v15

    move-object/from16 v7, v35

    move-wide/from16 v136, v36

    move-object/from16 v6, v38

    move-object/from16 v4, v39

    move-object/from16 v3, v40

    move-object/from16 v2, v41

    move-object/from16 v15, v45

    move-object/from16 v14, v48

    move-object/from16 v9, v50

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v8, v1

    move-object v13, v10

    move/from16 v39, v12

    move-object/from16 v1, v42

    move-object/from16 v12, v43

    move-object/from16 v10, v44

    move-object/from16 v44, v11

    move-object/from16 v11, v49

    goto/16 :goto_5339

    :pswitch_b69  #0x1b
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkEvent;

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lcig;

    iget-object v10, v5, Laak;->W:Long;

    check-cast v10, Luuc;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Lcp2;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object v0, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_bd0
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_bd3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_bd0 .. :try_end_bd3} :catch_264
    .catch Ljava/lang/Exception; {:try_start_bd0 .. :try_end_bd3} :catch_30e
    .catchall {:try_start_bd0 .. :try_end_bd3} :catchall_218

    move/from16 v85, v3

    move/from16 v86, v4

    move-wide/from16 v81, v6

    move/from16 v83, v8

    move/from16 v84, v9

    move-object/from16 v51, v13

    move-object/from16 v58, v14

    move-object/from16 v33, v15

    move-object/from16 v4, v35

    move-object/from16 v15, v39

    move-object/from16 v13, v41

    move-object/from16 v6, v43

    move-object/from16 v14, v44

    move-object/from16 v41, v46

    move-object/from16 v9, v49

    move-object/from16 v8, v50

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x1

    const-wide/16 v56, 0x0

    move-object v7, v1

    move-object v1, v2

    move-object/from16 v35, v10

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v2, v40

    move-object/from16 v10, v42

    move-object/from16 v12, v45

    move-object/from16 v11, v48

    move-wide/from16 v48, v36

    move-object/from16 v36, v47

    goto/16 :goto_4ff0

    :pswitch_c1d  #0x1a
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->d0:Long;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    iget-object v0, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    iget-object v1, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v52, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v53, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_c93
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_c96
    .catch Ljava/util/concurrent/CancellationException; {:try_start_c93 .. :try_end_c96} :catch_264
    .catch Ljava/lang/Exception; {:try_start_c93 .. :try_end_c96} :catch_cdb
    .catchall {:try_start_c93 .. :try_end_c96} :catchall_218

    move/from16 v32, v9

    move-object/from16 v17, v10

    move-object/from16 v58, v14

    move-object/from16 p1, v15

    move-object/from16 v30, v41

    move-object/from16 v27, v42

    move-object/from16 v41, v49

    move-object/from16 v15, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x1

    const-wide/16 v56, 0x0

    move-object v10, v1

    move-object/from16 v51, v13

    move-object/from16 v1, v35

    move-object/from16 v35, v39

    move-object v13, v2

    move/from16 v39, v12

    move-object/from16 v2, v40

    move/from16 v208, v4

    move v4, v3

    move-object/from16 v3, v48

    move-wide/from16 v48, v36

    move/from16 v37, v208

    move-object/from16 v208, v11

    move v11, v8

    move-wide v8, v6

    move-object/from16 v6, v38

    move-object/from16 v7, v44

    move-object/from16 v44, v208

    goto/16 :goto_4db8

    :catch_cdb
    move-exception v0

    move/from16 v17, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v17

    move-object/from16 v17, v51

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v14, v17

    move/from16 v37, v9

    move/from16 v39, v12

    move-object/from16 v32, v15

    move-object/from16 v33, v41

    move-object/from16 v38, v44

    move-object/from16 v12, v45

    move-object/from16 v17, v47

    move-object/from16 v15, v48

    move-object/from16 v41, v49

    move-object/from16 v36, v50

    move-object/from16 v9, v53

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v48, v3

    move/from16 v45, v4

    move-object v4, v11

    move-object/from16 v11, v52

    move-object/from16 v52, v43

    move-object/from16 v43, v42

    move-wide/from16 v208, v6

    move-object/from16 v6, v46

    :goto_d21
    move-wide/from16 v46, v208

    goto/16 :goto_42e

    :pswitch_d25  #0x19
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->d0:Long;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    iget-object v0, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    iget-object v1, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v52, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v53, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_d9b
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_d9e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_d9b .. :try_end_d9e} :catch_264
    .catch Ljava/lang/Exception; {:try_start_d9b .. :try_end_d9e} :catch_cdb
    .catchall {:try_start_d9b .. :try_end_d9e} :catchall_218

    move-object/from16 v17, v10

    move-object/from16 v58, v14

    move-object/from16 p1, v15

    move-object/from16 v30, v42

    move-object/from16 v15, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x1

    const-wide/16 v56, 0x0

    move-object v10, v1

    move-object/from16 v51, v13

    move-object/from16 v1, v35

    move-object/from16 v35, v39

    move v13, v4

    move/from16 v39, v12

    move-object v4, v2

    move-object/from16 v2, v40

    move/from16 v208, v8

    move v8, v3

    move-object/from16 v3, v48

    move-wide/from16 v209, v36

    move/from16 v37, v208

    move-object/from16 v208, v44

    move-object/from16 v44, v11

    move-wide v11, v6

    move-object/from16 v7, v41

    move-object/from16 v6, v208

    move-object/from16 v41, v49

    move-wide/from16 v48, v209

    goto/16 :goto_4c61

    :pswitch_de1  #0x18
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->d0:Long;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    iget-object v0, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    iget-object v1, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v52, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v53, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_e57
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_e5a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_e57 .. :try_end_e5a} :catch_264
    .catch Ljava/lang/Exception; {:try_start_e57 .. :try_end_e5a} :catch_cdb
    .catchall {:try_start_e57 .. :try_end_e5a} :catchall_218

    move/from16 v32, v9

    move-object/from16 v17, v10

    move-object/from16 v58, v14

    move-object/from16 p1, v15

    move-object/from16 v33, v42

    move-object/from16 v30, v44

    move-object/from16 v15, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x1

    const-wide/16 v56, 0x0

    move-object v10, v1

    move-object/from16 v44, v11

    move-object/from16 v51, v13

    move-object/from16 v1, v35

    move-object/from16 v35, v43

    move v11, v8

    move-wide v8, v6

    move-object v6, v2

    move v7, v4

    move-object/from16 v2, v40

    move v4, v3

    move-object/from16 v3, v39

    move/from16 v39, v12

    goto/16 :goto_4ac0

    :pswitch_e92  #0x17
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->d0:Long;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->c0:Ljava/util/Iterator;

    iget-object v0, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Iterable;

    iget-object v0, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v52, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v53, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v54, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v55, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_f0a
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_f0d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_f0a .. :try_end_f0d} :catch_264
    .catch Ljava/lang/Exception; {:try_start_f0a .. :try_end_f0d} :catch_f5a
    .catchall {:try_start_f0a .. :try_end_f0d} :catchall_218

    move/from16 v127, v3

    move/from16 v124, v4

    move-wide/from16 v122, v6

    move/from16 v125, v8

    move/from16 v126, v9

    move-object/from16 v58, v14

    move-object/from16 p1, v15

    move-object/from16 v9, v35

    move-wide/from16 v32, v36

    move-object/from16 v17, v38

    move-object/from16 v20, v39

    move-object/from16 v27, v40

    move-object/from16 v30, v41

    move-object/from16 v4, v42

    move-object/from16 v7, v43

    move-object/from16 v6, v44

    move-object/from16 v3, v47

    move-object/from16 v8, v48

    move-object/from16 v14, v49

    move-object/from16 v15, v50

    move-object/from16 v41, v51

    move-object/from16 v36, v52

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v44, v11

    move/from16 v39, v12

    move-object/from16 v51, v13

    move-object/from16 v13, v53

    move-object/from16 v12, v54

    move-object v11, v1

    move-object/from16 v1, v46

    goto/16 :goto_4859

    :catch_f5a
    move-exception v0

    move/from16 v17, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v17

    move/from16 v37, v9

    move/from16 v39, v12

    move-object/from16 v32, v15

    move-object/from16 v33, v43

    move-object/from16 v43, v44

    move-object/from16 v38, v46

    move-object/from16 v12, v47

    move-object/from16 v17, v49

    move-object/from16 v15, v50

    move-object/from16 v41, v51

    move-object/from16 v36, v52

    move-object/from16 v9, v55

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-wide/from16 v46, v6

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v52, v45

    move-object/from16 v6, v48

    move-object/from16 v14, v53

    const/4 v7, 0x1

    move/from16 v48, v3

    move/from16 v45, v4

    move-object v4, v11

    move-object/from16 v11, v54

    goto/32 :goto_7437

    :pswitch_fa2  #0x16
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->d0:Long;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkMessageContent;

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v1, Lnlh;

    iget-object v0, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Iterable;

    iget-object v0, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v52, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v53, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v54, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_101a
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_101d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_101a .. :try_end_101d} :catch_264
    .catch Ljava/lang/Exception; {:try_start_101a .. :try_end_101d} :catch_1066
    .catchall {:try_start_101a .. :try_end_101d} :catchall_218

    move-object/from16 p1, v43

    move/from16 v43, v9

    move-object/from16 v9, p1

    move-object/from16 v30, v10

    move-object/from16 v58, v14

    move-object/from16 p1, v15

    move-object/from16 v17, v38

    move-object/from16 v20, v39

    move-object/from16 v27, v40

    move-object/from16 v15, v49

    move-object/from16 v14, v52

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move v10, v4

    move/from16 v39, v12

    move-object/from16 v4, v42

    move/from16 v208, v3

    move-object v3, v0

    move/from16 v209, v8

    move-object v8, v1

    move-wide/from16 v0, v36

    move-object/from16 v37, v41

    move-object/from16 v36, v51

    move-object/from16 v51, v13

    move/from16 v13, v209

    move-wide/from16 v209, v6

    move/from16 v7, v208

    move-object/from16 v6, v44

    move-object/from16 v44, v11

    move-wide/from16 v11, v209

    goto/16 :goto_45dc

    :catch_1066
    move-exception v0

    move/from16 v17, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v17

    move/from16 v37, v9

    move/from16 v39, v12

    move-object/from16 v32, v15

    move-object/from16 v33, v42

    move-object/from16 v38, v45

    move-object/from16 v12, v46

    move-object/from16 v17, v48

    move-object/from16 v15, v49

    move-object/from16 v41, v50

    move-object/from16 v36, v51

    move-object/from16 v9, v54

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v48, v3

    move/from16 v45, v4

    move-object v4, v11

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v14, v52

    move-object/from16 v11, v53

    move-object/from16 v52, v44

    move-wide/from16 v208, v6

    move-object/from16 v6, v47

    goto/16 :goto_d21

    :pswitch_10aa  #0x15
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Llq4;

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/ControlRequestBody;

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1116
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1119
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1116 .. :try_end_1119} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1116 .. :try_end_1119} :catch_21c
    .catchall {:try_start_1116 .. :try_end_1119} :catchall_218

    move/from16 v52, v3

    move-object/from16 v58, v14

    move-object/from16 v3, v35

    move-object/from16 v20, v40

    move-object/from16 v32, v44

    move-object/from16 v16, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    const/16 v34, 0x0

    const-wide/16 v56, 0x0

    move-object v14, v2

    move/from16 v49, v4

    move-object/from16 v40, v11

    move-object/from16 v4, v48

    move-object v2, v0

    move-object/from16 v48, v1

    move-wide/from16 v0, v36

    move-object/from16 v37, v38

    move-object/from16 v38, v39

    move/from16 v39, v12

    move-object/from16 v12, v43

    move-object/from16 v43, v15

    move-object/from16 v15, v51

    move-object/from16 v51, v13

    const/4 v13, 0x6

    goto/16 :goto_3fde

    :pswitch_1158  #0x14
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v1, Leak;

    iget-object v0, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v0, Lnlh;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v1, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v1, v5, Laak;->V:Ljava/lang/Object;

    check-cast v1, Lcp2;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v52, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v53, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v54, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_11ca
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_11cd
    .catch Ljava/util/concurrent/CancellationException; {:try_start_11ca .. :try_end_11cd} :catch_264
    .catch Ljava/lang/Exception; {:try_start_11ca .. :try_end_11cd} :catch_1066
    .catchall {:try_start_11ca .. :try_end_11cd} :catchall_218

    move-object/from16 v22, v0

    move-object/from16 v59, v2

    move/from16 v110, v3

    move/from16 v111, v4

    move-wide/from16 v112, v6

    move/from16 v114, v8

    move/from16 v115, v9

    move-object/from16 v58, v14

    move-object/from16 v33, v15

    move-object/from16 p1, v38

    move-object/from16 v0, v40

    move-object/from16 v38, v42

    move-object/from16 v3, v44

    move-object/from16 v2, v45

    move-object/from16 v9, v49

    move-object/from16 v27, v51

    move-object/from16 v8, v52

    move-object/from16 v7, v53

    move-object/from16 v15, v54

    const-wide/16 v25, 0x0

    const/16 v30, 0x1

    move-object/from16 v40, v11

    move-object/from16 v51, v13

    move-object/from16 v42, v39

    move-object v11, v1

    move-object v13, v10

    move/from16 v39, v12

    move-object/from16 v1, v35

    move-wide/from16 v35, v36

    move-object/from16 v37, v41

    move-object/from16 v12, v46

    move-object/from16 v10, v47

    move-object/from16 v41, v50

    move-object/from16 v4, v43

    move-object/from16 v6, v48

    goto/16 :goto_3ef6

    :pswitch_1213  #0x13
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkEvent;

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lcig;

    iget-object v10, v5, Laak;->W:Long;

    check-cast v10, Luuc;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Lcp2;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object v0, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1272
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1275
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1272 .. :try_end_1275} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1272 .. :try_end_1275} :catch_30e
    .catchall {:try_start_1272 .. :try_end_1275} :catchall_218

    move/from16 v85, v3

    move/from16 v86, v4

    move-wide/from16 v81, v6

    move/from16 v83, v8

    move/from16 v84, v9

    move-object/from16 v51, v13

    move-object/from16 v4, v35

    move-object/from16 v13, v41

    move-object/from16 v6, v43

    move-object/from16 v41, v46

    move-object/from16 v9, v49

    move-object/from16 v8, v50

    const/16 v3, 0x13

    const-wide/16 v25, 0x0

    const/16 v30, 0x1

    move-object v7, v1

    move-object/from16 v49, v15

    move-object/from16 v1, v38

    move-object/from16 v15, v39

    move/from16 v39, v12

    move-wide/from16 v37, v36

    move-object/from16 v36, v47

    move-object v12, v2

    move-object/from16 v47, v10

    move-object/from16 v2, v40

    move-object/from16 v10, v42

    move-object/from16 v40, v11

    move-object/from16 v42, v14

    move-object/from16 v14, v44

    move-object/from16 v11, v48

    goto/16 :goto_3dac

    :pswitch_12b1  #0x12
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->c0:Ljava/util/Iterator;

    check-cast v10, Long;

    iget-object v10, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v10, Ljava/util/Iterator;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    iget-object v0, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v0, Lcom/anthropic/claude/sessions/types/SdkEvent;

    iget-object v0, v5, Laak;->X:Ljava/lang/Object;

    check-cast v0, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_131d
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1320
    .catch Ljava/util/concurrent/CancellationException; {:try_start_131d .. :try_end_1320} :catch_264
    .catch Ljava/lang/Exception; {:try_start_131d .. :try_end_1320} :catch_21c
    .catchall {:try_start_131d .. :try_end_1320} :catchall_218

    move/from16 v25, v12

    move-object v12, v2

    move-object/from16 v2, v39

    move/from16 v39, v25

    move-object/from16 v25, v42

    move-object/from16 v42, v14

    move-object/from16 v14, v49

    move-object/from16 v49, v15

    move-object/from16 v15, v25

    move/from16 v108, v3

    move/from16 v109, v4

    move-wide/from16 v104, v6

    move/from16 v106, v8

    move/from16 v107, v9

    move-object/from16 v4, v35

    move-wide/from16 v102, v36

    move-object/from16 v3, v41

    move-object/from16 v6, v44

    move-object/from16 v41, v47

    move-object/from16 v36, v48

    move-object/from16 v9, v50

    move-object/from16 v8, v51

    const-wide/16 v25, 0x0

    const/16 v30, 0x1

    move-object v7, v1

    move-object/from16 v35, v10

    move-object/from16 v51, v13

    move-object/from16 v10, v40

    move-object/from16 v13, v45

    move-object v1, v0

    move-object/from16 v40, v11

    move-object/from16 v0, v38

    move-object/from16 v11, v43

    goto/16 :goto_3b7b

    :pswitch_1361  #0x11
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_13c1
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_13c4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_13c1 .. :try_end_13c4} :catch_264
    .catch Ljava/lang/Exception; {:try_start_13c1 .. :try_end_13c4} :catch_21c
    .catchall {:try_start_13c1 .. :try_end_13c4} :catchall_218

    move/from16 v33, v4

    move-object/from16 v27, v39

    move-object/from16 v52, v41

    move-object/from16 v4, v42

    move-object/from16 v41, v47

    const-wide/16 v25, 0x0

    const/16 v30, 0x1

    move-object/from16 v47, v0

    move/from16 v39, v12

    move-object/from16 v42, v14

    move-object/from16 v14, v49

    move-object v12, v10

    move-object/from16 v49, v15

    move-object/from16 v10, v43

    move-object/from16 v43, v40

    move-object/from16 v40, v11

    move-object/from16 v11, v50

    move/from16 v208, v8

    move-object v8, v1

    move-wide/from16 v0, v36

    move-wide/from16 v36, v6

    move v6, v9

    move-object/from16 v7, v44

    move-object/from16 v9, v51

    move-object/from16 v51, v13

    move-object v13, v2

    move/from16 v2, v208

    goto/16 :goto_3aa3

    :pswitch_13f8  #0x10
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkEvent;

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lcig;

    iget-object v10, v5, Laak;->W:Long;

    check-cast v10, Luuc;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Lcp2;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object v0, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_145b
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_145e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_145b .. :try_end_145e} :catch_264
    .catch Ljava/lang/Exception; {:try_start_145b .. :try_end_145e} :catch_30e
    .catchall {:try_start_145b .. :try_end_145e} :catchall_218

    move/from16 v85, v3

    move/from16 v86, v4

    move-wide/from16 v81, v6

    move/from16 v83, v8

    move/from16 v84, v9

    move-object/from16 v51, v13

    move-object/from16 v4, v35

    move-object/from16 v27, v39

    move-object/from16 v13, v41

    move-object/from16 v6, v43

    move-object/from16 v41, v46

    move-object/from16 v9, v49

    move-object/from16 v8, v50

    const-wide/16 v25, 0x0

    move-object v7, v1

    move-object v3, v2

    move/from16 v39, v12

    move-object/from16 v49, v15

    move-object/from16 v1, v38

    move-object/from16 v2, v40

    move-object/from16 v15, v44

    move-object/from16 v12, v45

    move-object/from16 v40, v11

    move-wide/from16 v37, v36

    move-object/from16 v11, v42

    move-object/from16 v36, v47

    move-object/from16 v42, v14

    move-object/from16 v14, v48

    goto/16 :goto_38a9

    :pswitch_1496  #0xf
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_14f6
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_14f9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_14f6 .. :try_end_14f9} :catch_264
    .catch Ljava/lang/Exception; {:try_start_14f6 .. :try_end_14f9} :catch_21c
    .catchall {:try_start_14f6 .. :try_end_14f9} :catchall_218

    move/from16 v54, v3

    move/from16 v33, v8

    move-object/from16 v27, v39

    move-object/from16 v52, v41

    move-object/from16 v41, v47

    const/16 v3, 0xf

    const-wide/16 v25, 0x0

    move-object/from16 v47, v0

    move-object v8, v1

    move/from16 v39, v12

    move-wide/from16 v0, v36

    move-object v12, v2

    move-wide/from16 v36, v6

    move v6, v9

    move-object/from16 v2, v42

    move-object/from16 v7, v44

    move-object/from16 v9, v51

    move-object/from16 v51, v13

    move-object/from16 v42, v14

    move-object/from16 v14, v49

    move-object v13, v10

    move-object/from16 v49, v15

    move-object/from16 v10, v43

    move-object/from16 v43, v40

    move-object/from16 v40, v11

    move-object/from16 v11, v50

    goto/16 :goto_360b

    :pswitch_152b  #0xe
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->X:Ljava/lang/Object;

    check-cast v1, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_158b
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_158e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_158b .. :try_end_158e} :catch_264
    .catch Ljava/lang/Exception; {:try_start_158b .. :try_end_158e} :catch_21c
    .catchall {:try_start_158b .. :try_end_158e} :catchall_218

    move-object/from16 v25, v13

    move v13, v9

    move-object/from16 v9, v51

    move-object/from16 v51, v25

    move-object/from16 v25, v15

    move-object v15, v10

    move-object/from16 v10, v43

    move-object/from16 v43, v25

    move-object/from16 v27, v0

    move-object/from16 v33, v39

    move-object/from16 v52, v40

    const-wide/16 v25, 0x0

    move-object/from16 v40, v11

    move/from16 v39, v12

    move-object/from16 v11, v50

    move-object v12, v2

    move v2, v4

    move-object/from16 v4, v42

    move-object/from16 v42, v14

    move-object/from16 v14, v49

    move/from16 v208, v8

    move-object v8, v1

    move-wide/from16 v0, v36

    move-wide/from16 v36, v6

    move/from16 v6, v208

    move-object/from16 v7, v44

    goto/16 :goto_345a

    :pswitch_15bf  #0xd
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->c0:Ljava/util/Iterator;

    check-cast v0, Lcom/anthropic/claude/sessions/api/WsUpgradeRejectedException;

    iget-object v0, v5, Laak;->b0:Ljava/lang/Object;

    check-cast v0, Lhak;

    iget-object v0, v5, Laak;->a0:Ljava/lang/Object;

    check-cast v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketUpgradeFailedException;

    iget-object v0, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v0, Lpt6;

    iget-object v0, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v0, Lcom/anthropic/claude/sessions/types/SdkEvent;

    iget-object v0, v5, Laak;->X:Ljava/lang/Object;

    check-cast v0, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    iget-object v0, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v42, v0

    check-cast v42, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v43, v0

    check-cast v43, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1625
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1628
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1625 .. :try_end_1628} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1625 .. :try_end_1628} :catch_162e
    .catchall {:try_start_1625 .. :try_end_1628} :catchall_218

    move/from16 v45, v3

    move/from16 v3, v36

    goto/16 :goto_3285

    :catch_162e
    move-exception v0

    move/from16 v17, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v17

    move-object/from16 v17, v39

    move/from16 v39, v12

    move-object/from16 v12, v17

    move-object/from16 v33, v4

    move-object v4, v11

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v32, v15

    move/from16 v48, v36

    move-object/from16 v52, v37

    move-object/from16 v17, v41

    move-object/from16 v41, v42

    move-object/from16 v36, v43

    move-object/from16 v15, v44

    goto/16 :goto_40c

    :pswitch_1652  #0xc
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->Z:Ljava/lang/Object;

    check-cast v0, Lpt6;

    iget-object v0, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v0, Lcom/anthropic/claude/sessions/types/SdkEvent;

    iget-object v0, v5, Laak;->X:Ljava/lang/Object;

    check-cast v0, Lcig;

    iget-object v0, v5, Laak;->W:Long;

    check-cast v0, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    iget-object v0, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v42, v0

    check-cast v42, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v43, v0

    check-cast v43, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_16ac
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_16af
    .catch Ljava/util/concurrent/CancellationException; {:try_start_16ac .. :try_end_16af} :catch_264
    .catch Ljava/lang/Exception; {:try_start_16ac .. :try_end_16af} :catch_162e
    .catchall {:try_start_16ac .. :try_end_16af} :catchall_218

    move/from16 v48, v36

    goto/16 :goto_302a

    :pswitch_16b3  #0xb
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lcig;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_170f
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1712
    .catch Ljava/util/concurrent/CancellationException; {:try_start_170f .. :try_end_1712} :catch_264
    .catch Ljava/lang/Exception; {:try_start_170f .. :try_end_1712} :catch_21c
    .catchall {:try_start_170f .. :try_end_1712} :catchall_218

    move-object/from16 v27, v0

    move/from16 v85, v3

    move/from16 v86, v4

    move-wide/from16 v81, v6

    move/from16 v83, v8

    move/from16 v84, v9

    move-object/from16 v8, v35

    move-object/from16 v0, v38

    move-object/from16 v7, v41

    move-object/from16 v6, v42

    move-object/from16 v41, v47

    const-wide/16 v25, 0x0

    move-object v4, v1

    move-object v3, v2

    move-object/from16 v42, v14

    move-wide/from16 v37, v36

    move-object/from16 v1, v39

    move-object/from16 v2, v44

    move-object/from16 v36, v48

    move-object/from16 v14, v49

    move/from16 v39, v12

    move-object/from16 v49, v15

    move-object/from16 v15, v40

    move-object/from16 v12, v51

    move-object/from16 v40, v11

    move-object/from16 v51, v13

    move-object/from16 v13, v50

    goto/16 :goto_2db8

    :pswitch_1748  #0xa
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Lu6g;

    iget-object v10, v5, Laak;->W:Long;

    check-cast v10, Luuc;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Lcp2;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object v0, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_17a3
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_17a6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_17a3 .. :try_end_17a6} :catch_264
    .catch Ljava/lang/Exception; {:try_start_17a3 .. :try_end_17a6} :catch_30e
    .catchall {:try_start_17a3 .. :try_end_17a6} :catchall_218

    move-object/from16 v59, v2

    move/from16 v93, v3

    move/from16 v94, v4

    move-wide/from16 v89, v6

    move/from16 v91, v8

    move/from16 v92, v9

    move-object/from16 v27, v10

    move-object/from16 v51, v13

    move-object/from16 v6, v35

    move-wide/from16 v87, v36

    move-object/from16 v4, v38

    move-object/from16 v3, v39

    move-object/from16 v13, v40

    move-object/from16 v2, v41

    move-object/from16 v7, v43

    move-object/from16 v41, v46

    move-object/from16 v36, v47

    move-object/from16 v9, v50

    const-wide/16 v25, 0x0

    move-object v8, v1

    move-object/from16 v40, v11

    move/from16 v39, v12

    move-object/from16 v12, v42

    move-object/from16 v1, v44

    move-object/from16 v11, v49

    move-object/from16 v42, v14

    move-object/from16 v49, v15

    move-object/from16 v15, v45

    move-object/from16 v14, v48

    goto/16 :goto_2d13

    :pswitch_17e1  #0x9
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-wide v0, v5, Laak;->l0:J

    iget v3, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v4, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v10, v5, Laak;->Y:Ljava/lang/Object;

    check-cast v10, Lcom/anthropic/claude/sessions/types/SdkControlRequestEvent;

    iget-object v10, v5, Laak;->X:Ljava/lang/Object;

    check-cast v10, Ljava/util/Iterator;

    move-wide/from16 v36, v0

    iget-object v1, v5, Laak;->W:Long;

    check-cast v1, Luuc;

    iget-object v0, v5, Laak;->V:Ljava/lang/Object;

    check-cast v0, Lcp2;

    iget-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1841
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1844
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1841 .. :try_end_1844} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1841 .. :try_end_1844} :catch_21c
    .catchall {:try_start_1841 .. :try_end_1844} :catchall_218

    move-object/from16 v54, v40

    move-object/from16 v40, v11

    move-object/from16 v11, v49

    move-object/from16 v49, v15

    move-object/from16 v15, v54

    move/from16 v75, v3

    move/from16 v76, v4

    move-wide/from16 v77, v6

    move/from16 v79, v8

    move/from16 v80, v9

    move-object/from16 v58, v14

    move-object/from16 v54, v35

    move-object/from16 v4, v41

    move-object/from16 v3, v44

    move-object/from16 v14, v45

    move-object/from16 v41, v47

    move-object/from16 v9, v50

    move-object/from16 v8, v51

    move-object v6, v0

    move-object v7, v1

    move-object/from16 v35, v10

    move-object/from16 v51, v13

    move-object/from16 v0, v38

    move-object/from16 v1, v39

    move-object/from16 v13, v42

    move-object/from16 v10, v43

    move/from16 v39, v12

    move-wide/from16 v37, v36

    move-object/from16 v12, v46

    move-object/from16 v36, v48

    goto/16 :goto_2a94

    :pswitch_1880  #0x8
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->U:Lcp2;

    check-cast v0, Lcom/anthropic/claude/sessions/types/PermissionMode;

    iget-object v0, v5, Laak;->S:Lpe9;

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_18cc
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_18cf
    .catch Ljava/util/concurrent/CancellationException; {:try_start_18cc .. :try_end_18cf} :catch_264
    .catch Ljava/lang/Exception; {:try_start_18cc .. :try_end_18cf} :catch_3ea
    .catchall {:try_start_18cc .. :try_end_18cf} :catchall_218

    move-object/from16 v27, v40

    move-object/from16 v40, v11

    move-object/from16 v11, v27

    move-object/from16 v27, v39

    move/from16 v39, v12

    move-object/from16 v12, v27

    move-object/from16 v27, v10

    move-object/from16 v51, v13

    move-object/from16 v52, v14

    move-object/from16 v10, v42

    move v13, v8

    move v14, v9

    move-object/from16 v9, v41

    move-object/from16 v41, v43

    move-object/from16 v8, v45

    move-object/from16 v45, v15

    move-object v15, v2

    move/from16 v2, v36

    move-object/from16 v36, v44

    goto/16 :goto_2789

    :pswitch_18f4  #0x7
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->T:Lexe;

    iget-object v4, v5, Laak;->S:Lpe9;

    iget-object v10, v5, Laak;->R:Lcp2;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1940
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1943
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1940 .. :try_end_1943} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1940 .. :try_end_1943} :catch_1977
    .catchall {:try_start_1940 .. :try_end_1943} :catchall_218

    move/from16 v70, v3

    move-wide/from16 v71, v6

    move/from16 v73, v8

    move/from16 v74, v9

    move-object/from16 v51, v13

    move-object/from16 v52, v14

    move/from16 v69, v36

    move-object/from16 v14, v37

    move-object/from16 v3, v38

    move-object/from16 v13, v39

    move-object/from16 v9, v42

    move-object/from16 v36, v45

    move-object/from16 v8, v46

    move-object/from16 v7, v47

    move-object/from16 v6, v48

    move/from16 v39, v12

    move-object/from16 v45, v15

    move-object/from16 v12, v40

    move-object v15, v10

    move-object/from16 v40, v11

    move-object/from16 v11, v41

    move-object/from16 v10, v43

    move-object/from16 v41, v44

    move-object/from16 v44, v2

    move-object v2, v1

    move-object/from16 v1, v35

    goto/16 :goto_26f8

    :catch_1977
    move-exception v0

    move v4, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v4

    move-object/from16 v33, v10

    move-object v4, v11

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v32, v15

    move-object/from16 v52, v38

    move-object/from16 v38, v39

    move-object/from16 v17, v42

    move-object/from16 v15, v43

    move-object/from16 v14, v46

    move-object/from16 v11, v47

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-wide/from16 v46, v6

    move/from16 v39, v12

    move-object/from16 v43, v37

    move-object/from16 v12, v40

    move-object/from16 v6, v41

    move-object/from16 v41, v44

    const/4 v7, 0x1

    move/from16 v37, v9

    move-object/from16 v9, v48

    move/from16 v48, v36

    move-object/from16 v36, v45

    move/from16 v45, v3

    goto/32 :goto_7437

    :pswitch_19be  #0x6
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget-boolean v0, v5, Laak;->j0:Z

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v4, v5, Laak;->W:Long;

    iget-object v10, v5, Laak;->V:Ljava/lang/Object;

    check-cast v10, Ljava/util/Iterator;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->U:Lcp2;

    check-cast v1, Ljava/lang/Iterable;

    iget-object v1, v5, Laak;->T:Lexe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->S:Lpe9;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->R:Lcp2;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->Q:Lixe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v42, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v43, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->K:Lixe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->J:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->I:Ljava/util/List;

    check-cast v1, Ljava/util/List;

    move-object/from16 v48, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v49, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v50, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v51, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1a1c
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1a1f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1a1c .. :try_end_1a1f} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1a1c .. :try_end_1a1f} :catch_1a56
    .catchall {:try_start_1a1c .. :try_end_1a1f} :catchall_218

    move/from16 v27, v0

    move/from16 v64, v3

    move-wide/from16 v65, v6

    move/from16 v67, v8

    move/from16 v68, v9

    move-object/from16 v52, v14

    move-object/from16 p1, v35

    move/from16 v63, v36

    move-object/from16 v0, v37

    move-object/from16 v37, v38

    move-object/from16 v14, v40

    move-object/from16 v9, v45

    move-object/from16 v36, v48

    move-object/from16 v8, v49

    move-object/from16 v7, v50

    move-object/from16 v6, v51

    move-object v3, v1

    move-object/from16 v38, v10

    move-object/from16 v40, v11

    move-object/from16 v51, v13

    move-object/from16 v45, v15

    move-object/from16 v15, v39

    move-object/from16 v13, v42

    move-object/from16 v11, v44

    move-object/from16 v10, v46

    move/from16 v39, v12

    move-object/from16 v12, v43

    goto/16 :goto_2584

    :catch_1a56
    move-exception v0

    move v4, v8

    move-object v8, v1

    move-object/from16 v1, v35

    move/from16 v35, v4

    move-object/from16 v4, v48

    move/from16 v48, v36

    move-object/from16 v36, v4

    move/from16 v37, v9

    move-object v4, v11

    move-object/from16 v32, v15

    move-object/from16 v33, v39

    move-object/from16 v52, v41

    move-object/from16 v38, v42

    move-object/from16 v17, v45

    move-object/from16 v15, v46

    move-object/from16 v41, v47

    move-object/from16 v11, v50

    move-object/from16 v9, v51

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v45, v3

    move-wide/from16 v46, v6

    move/from16 v39, v12

    move-object/from16 v51, v13

    move-object v13, v14

    move-object/from16 v12, v43

    move-object/from16 v6, v44

    move-object/from16 v14, v49

    goto/16 :goto_25e

    :pswitch_1a9b  #0x5
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->S:Lpe9;

    check-cast v0, Ljava/lang/String;

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    iget-object v0, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v42, v0

    check-cast v42, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v43, v0

    check-cast v43, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1ae5
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1ae8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1ae5 .. :try_end_1ae8} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1ae5 .. :try_end_1ae8} :catch_162e
    .catchall {:try_start_1ae5 .. :try_end_1ae8} :catchall_218

    move-object/from16 v0, v42

    move/from16 v42, v3

    move-object/from16 v3, v35

    move-object/from16 v35, v0

    move-object/from16 v0, v40

    move-object/from16 v40, v11

    move-object v11, v0

    move-object/from16 v0, p1

    move/from16 v27, v8

    move-object/from16 v48, v10

    move-object/from16 v10, v44

    move-object/from16 v8, v45

    move-object/from16 v45, v15

    move-object v15, v2

    const/4 v2, 0x5

    move-object/from16 v208, v4

    move-object v4, v1

    move-object v1, v13

    move-wide/from16 v209, v6

    move-object/from16 v6, v208

    move/from16 v7, v36

    move-object/from16 v36, v43

    move/from16 v43, v9

    move-object/from16 v9, v39

    move/from16 v39, v12

    move-wide/from16 v12, v209

    goto/16 :goto_23ac

    :pswitch_1b19  #0x4
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->S:Lpe9;

    check-cast v0, Ljava/lang/String;

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    iget-object v0, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v42, v0

    check-cast v42, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v43, v0

    check-cast v43, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1b63
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1b66
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1b63 .. :try_end_1b66} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1b63 .. :try_end_1b66} :catch_162e
    .catchall {:try_start_1b63 .. :try_end_1b66} :catchall_218

    move-object/from16 v0, v40

    move-object/from16 v40, v11

    move-object v11, v0

    move-object/from16 v0, p1

    move-object/from16 v48, v10

    move-object/from16 v10, v44

    move-object/from16 v208, v4

    move-object v4, v1

    move-object v1, v13

    move-object/from16 v209, v15

    move-object v15, v2

    move-object/from16 v2, v43

    move/from16 v43, v3

    move-object/from16 v3, v41

    move-object/from16 v41, v39

    move/from16 v39, v12

    move-wide v12, v6

    move v7, v8

    move-object/from16 v8, v45

    move-object/from16 v6, v208

    move-object/from16 v45, v209

    goto/16 :goto_21cf

    :pswitch_1b8c  #0x3
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v0, v5, Laak;->S:Lpe9;

    check-cast v0, Ljava/lang/String;

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    iget-object v0, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v42, v0

    check-cast v42, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v43, v0

    check-cast v43, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1bd6
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1bd9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1bd6 .. :try_end_1bd9} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1bd6 .. :try_end_1bd9} :catch_162e
    .catchall {:try_start_1bd6 .. :try_end_1bd9} :catchall_218

    move-object/from16 v0, v40

    move-object/from16 v40, v11

    move-object v11, v0

    move-object/from16 v0, v39

    move/from16 v39, v12

    move-object v12, v0

    move-object/from16 v0, p1

    move-wide/from16 v208, v6

    move-object v6, v1

    move-object v7, v10

    move-object v1, v13

    move-object/from16 v10, v44

    move/from16 v44, v3

    move v13, v8

    move-object/from16 v3, v41

    move-object/from16 v8, v45

    move-object/from16 v45, v15

    move-object v15, v2

    move-object/from16 v2, v43

    move/from16 v43, v9

    move-object v9, v4

    move-object/from16 v4, v35

    move-object/from16 v35, v42

    move-wide/from16 v41, v208

    goto/16 :goto_1fde

    :pswitch_1c03  #0x2
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    iget-object v0, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v42, v0

    check-cast v42, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v43, v0

    check-cast v43, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1c49
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1c4c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1c49 .. :try_end_1c4c} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1c49 .. :try_end_1c4c} :catch_162e
    .catchall {:try_start_1c49 .. :try_end_1c4c} :catchall_218

    move-object/from16 v0, v40

    move-object/from16 v40, v11

    move-object v11, v0

    move-object/from16 v0, v39

    move/from16 v39, v12

    move-object v12, v0

    move v0, v3

    move-object/from16 v3, v35

    move-object/from16 v35, v42

    move-object/from16 v42, v14

    move-object/from16 v14, v37

    move-object/from16 v37, v41

    move-object/from16 v41, v13

    move v13, v9

    move-object/from16 v208, v4

    move-object v4, v1

    move-object v1, v2

    move/from16 v2, v36

    move-object/from16 v36, v43

    move-object/from16 v43, v15

    move-object v15, v10

    move-object/from16 v10, v44

    move-wide/from16 v209, v6

    move-object/from16 v6, v208

    move v7, v8

    move-wide/from16 v8, v209

    goto/16 :goto_1e93

    :pswitch_1c7a  #0x1
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    iget v1, v5, Laak;->g0:I

    iget-wide v6, v5, Laak;->k0:J

    iget v3, v5, Laak;->f0:I

    iget-boolean v8, v5, Laak;->i0:Z

    iget v9, v5, Laak;->e0:I

    iget-object v4, v5, Laak;->R:Lcp2;

    iget-object v10, v5, Laak;->Q:Lixe;

    move/from16 v36, v1

    iget-object v1, v5, Laak;->P:Lixe;

    move-object/from16 v37, v1

    iget-object v1, v5, Laak;->O:Lexe;

    move-object/from16 v38, v1

    iget-object v1, v5, Laak;->N:Lexe;

    move-object/from16 v39, v1

    iget-object v1, v5, Laak;->M:Lexe;

    move-object/from16 v40, v1

    iget-object v1, v5, Laak;->L:Lixe;

    move-object/from16 v41, v1

    iget-object v1, v5, Laak;->K:Lixe;

    iget-object v0, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v42, v0

    check-cast v42, Ljava/util/List;

    iget-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v43, v0

    check-cast v43, Ljava/util/List;

    move-object/from16 v44, v1

    iget-object v1, v5, Laak;->H:Lhxe;

    move-object/from16 v45, v1

    iget-object v1, v5, Laak;->G:Lexe;

    move-object/from16 v46, v1

    iget-object v1, v5, Laak;->F:Lpng;

    move-object/from16 v47, v1

    iget-object v1, v5, Laak;->E:Lixe;

    :try_start_1cc0
    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_1cc3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1cc0 .. :try_end_1cc3} :catch_264
    .catch Ljava/lang/Exception; {:try_start_1cc0 .. :try_end_1cc3} :catch_162e
    .catchall {:try_start_1cc0 .. :try_end_1cc3} :catchall_218

    move-object/from16 p1, v37

    move/from16 v37, v3

    move-object/from16 v3, v35

    move-object/from16 v35, v42

    move-object/from16 v42, v14

    move-object/from16 v14, p1

    move-object/from16 p1, v38

    move/from16 v38, v8

    move-object/from16 v8, v41

    move-object/from16 v41, v13

    move-object/from16 v13, p1

    move-object/from16 p1, v40

    move-object/from16 v40, v11

    move-object/from16 v11, p1

    move-object/from16 p1, v39

    move/from16 v39, v12

    move-object/from16 v12, p1

    move-wide/from16 v59, v6

    move-object/from16 p1, v43

    move-object/from16 v7, v45

    move-object/from16 v6, v46

    move/from16 v45, v9

    move-object/from16 v43, v15

    move-object v9, v4

    move-object v15, v10

    move-object/from16 v10, v44

    move-object v4, v1

    move-object/from16 v1, v47

    :goto_1cf8
    move-object/from16 v44, v2

    const/4 v2, 0x1

    goto/16 :goto_1e25

    :pswitch_1cfd  #0x0
    move-object/from16 v35, v1

    move-object/from16 v29, v10

    invoke-static/range {p1 .. p1}, Lw10;->P(Ljava/lang/Object;)V

    new-instance v0, Lixe;

    invoke-direct {v0}, Lixe;-><init>()V

    invoke-static {v14}, Leak;->c(Leak;)Llg0;

    move-result-object v1

    invoke-virtual {v1}, Llg0;->b()Z

    move-result v1

    new-instance v3, Lpng;

    invoke-direct {v3}, Lpng;-><init>()V

    iget-object v4, v15, Lnlh;->k:La1f;

    iget-object v4, v4, La1f;->F:Ljava/lang/Object;

    check-cast v4, Lrig;

    const/4 v6, 0x0

    iput-boolean v6, v4, Lrig;->s:Z

    iget-object v4, v15, Lnlh;->k:La1f;

    iget-object v4, v4, La1f;->F:Ljava/lang/Object;

    check-cast v4, Lrig;

    iput-boolean v6, v4, Lrig;->t:Z

    new-instance v4, Lexe;

    invoke-direct {v4}, Lexe;-><init>()V

    new-instance v6, Lhxe;

    invoke-direct {v6}, Lhxe;-><init>()V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    new-instance v8, Lixe;

    invoke-direct {v8}, Lixe;-><init>()V

    new-instance v9, Lixe;

    invoke-direct {v9}, Lixe;-><init>()V

    new-instance v10, Lexe;

    invoke-direct {v10}, Lexe;-><init>()V

    new-instance v36, Lexe;

    invoke-direct/range {v36 .. v36}, Lexe;-><init>()V

    new-instance v37, Lexe;

    invoke-direct/range {v37 .. v37}, Lexe;-><init>()V

    new-instance v38, Lixe;

    invoke-direct/range {v38 .. v38}, Lixe;-><init>()V

    move/from16 p1, v1

    iget-object v1, v15, Lnlh;->i:Ly42;

    invoke-virtual {v1}, Ly42;->m()Ljava/lang/Object;

    :goto_1d5b
    iget-object v1, v15, Lnlh;->j:Ly42;

    invoke-virtual {v1}, Ly42;->m()Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lvp2;

    if-nez v1, :cond_1d68

    goto/32 :goto_7734

    :cond_1d68
    move-object v1, v10

    move-object v10, v8

    move-object v8, v9

    move-object v9, v1

    move-object v1, v0

    move-object/from16 v44, v2

    move-object/from16 v40, v11

    move/from16 v39, v12

    move-object/from16 v41, v13

    move-object/from16 v42, v14

    move-object/from16 v43, v15

    move-object/from16 v12, v36

    move-object/from16 v11, v37

    move-object/from16 v13, v38

    const/4 v2, 0x0

    const/4 v15, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    move/from16 v14, p1

    move-object/from16 p1, v7

    move-object v7, v6

    move-object v6, v4

    move-object v4, v3

    move-object/from16 v3, v35

    move-object/from16 v35, v29

    :goto_1d90
    iget-object v0, v1, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lmog;

    if-eqz v0, :cond_1d99

    invoke-virtual {v0}, Lmog;->s()V

    :cond_1d99
    move/from16 v36, v2

    new-instance v2, Lixe;

    invoke-direct {v2}, Lixe;-><init>()V

    move-object/from16 v45, v2

    move-object/from16 v46, v13

    move/from16 v37, v14

    move/from16 v38, v15

    const/4 v2, 0x0

    const/4 v14, -0x1

    const/4 v15, 0x6

    invoke-static {v14, v15, v2}, Loz4;->c(IILp42;)Ly42;

    move-result-object v13

    :try_start_1daf
    new-instance v0, Lhng;

    sget-object v2, Laz4;->a:Laz4;

    invoke-direct {v0, v2}, Lhng;-><init>(Lez4;)V

    iput-object v3, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->E:Lixe;

    iput-object v4, v5, Laak;->F:Lpng;

    iput-object v6, v5, Laak;->G:Lexe;

    iput-object v7, v5, Laak;->H:Lhxe;
    :try_end_1dc0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1daf .. :try_end_1dc0} :catch_73c4
    .catch Ljava/lang/Exception; {:try_start_1daf .. :try_end_1dc0} :catch_7429
    .catchall {:try_start_1daf .. :try_end_1dc0} :catchall_73bb

    :try_start_1dc0
    move-object/from16 v2, p1

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v2, v35

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->J:Ljava/util/List;
    :try_end_1dcc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1dc0 .. :try_end_1dcc} :catch_7432
    .catch Ljava/lang/Exception; {:try_start_1dc0 .. :try_end_1dcc} :catch_7430
    .catchall {:try_start_1dc0 .. :try_end_1dcc} :catchall_742b

    :try_start_1dcc
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v8, v5, Laak;->L:Lixe;

    iput-object v9, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v11, v5, Laak;->O:Lexe;
    :try_end_1dd6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1dcc .. :try_end_1dd6} :catch_73c4
    .catch Ljava/lang/Exception; {:try_start_1dcc .. :try_end_1dd6} :catch_7429
    .catchall {:try_start_1dcc .. :try_end_1dd6} :catchall_73bb

    move-object/from16 v2, v46

    :try_start_1dd8
    iput-object v2, v5, Laak;->P:Lixe;
    :try_end_1dda
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1dd8 .. :try_end_1dda} :catch_73c4
    .catch Ljava/lang/Exception; {:try_start_1dd8 .. :try_end_1dda} :catch_73f9
    .catchall {:try_start_1dd8 .. :try_end_1dda} :catchall_73bb

    move-object/from16 v14, v45

    :try_start_1ddc
    iput-object v14, v5, Laak;->Q:Lixe;

    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_1de0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1ddc .. :try_end_1de0} :catch_73c4
    .catch Ljava/lang/Exception; {:try_start_1ddc .. :try_end_1de0} :catch_73c9
    .catchall {:try_start_1ddc .. :try_end_1de0} :catchall_73bb

    move/from16 v15, v38

    :try_start_1de2
    iput v15, v5, Laak;->e0:I
    :try_end_1de4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1de2 .. :try_end_1de4} :catch_73c4
    .catch Ljava/lang/Exception; {:try_start_1de2 .. :try_end_1de4} :catch_73c0
    .catchall {:try_start_1de2 .. :try_end_1de4} :catchall_73bb

    move-object/from16 v38, v1

    move/from16 v1, v37

    :try_start_1de8
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_1dea
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1de8 .. :try_end_1dea} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_1de8 .. :try_end_1dea} :catch_73b7
    .catchall {:try_start_1de8 .. :try_end_1dea} :catchall_6fe1

    move/from16 v37, v1

    move/from16 v1, v36

    :try_start_1dee
    iput v1, v5, Laak;->f0:I
    :try_end_1df0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1dee .. :try_end_1df0} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_1dee .. :try_end_1df0} :catch_73a1
    .catchall {:try_start_1dee .. :try_end_1df0} :catchall_6fe1

    move/from16 v36, v1

    move-object/from16 v46, v2

    move-wide/from16 v1, v56

    :try_start_1df6
    iput-wide v1, v5, Laak;->k0:J
    :try_end_1df8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1df6 .. :try_end_1df8} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_1df6 .. :try_end_1df8} :catch_738d
    .catchall {:try_start_1df6 .. :try_end_1df8} :catchall_6fe1

    move-wide/from16 v47, v1

    move/from16 v1, v58

    :try_start_1dfc
    iput v1, v5, Laak;->g0:I
    :try_end_1dfe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1dfc .. :try_end_1dfe} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_1dfc .. :try_end_1dfe} :catch_7366
    .catchall {:try_start_1dfc .. :try_end_1dfe} :catchall_6fe1

    const/4 v2, 0x1

    :try_start_1dff
    iput v2, v5, Laak;->m0:I

    invoke-virtual {v3, v5, v0}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1e05
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1dff .. :try_end_1e05} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_1dff .. :try_end_1e05} :catch_731e
    .catchall {:try_start_1dff .. :try_end_1e05} :catchall_6fe1

    move-object/from16 v2, v44

    if-ne v0, v2, :cond_1e0b

    goto/16 :goto_7700

    :cond_1e0b
    move/from16 v44, v36

    move/from16 v36, v1

    move-object v1, v4

    move-object/from16 v4, v38

    move/from16 v38, v37

    move/from16 v37, v44

    move-object/from16 v44, v11

    move-object v11, v9

    move-object v9, v13

    move-object/from16 v13, v44

    move/from16 v45, v15

    move-wide/from16 v59, v47

    move-object v15, v14

    move-object/from16 v14, v46

    goto/16 :goto_1cf8

    :goto_1e25
    :try_start_1e25
    invoke-virtual {v1, v2}, Lpng;->a(Z)Z

    move-result v0
    :try_end_1e29
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e25 .. :try_end_1e29} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e25 .. :try_end_1e29} :catch_72c4
    .catchall {:try_start_1e25 .. :try_end_1e29} :catchall_1eb0

    if-eqz v0, :cond_1f2a

    :try_start_1e2b
    iput-object v3, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v4, v5, Laak;->E:Lixe;

    iput-object v1, v5, Laak;->F:Lpng;

    iput-object v6, v5, Laak;->G:Lexe;

    iput-object v7, v5, Laak;->H:Lhxe;
    :try_end_1e35
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e2b .. :try_end_1e35} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e2b .. :try_end_1e35} :catch_1f26
    .catchall {:try_start_1e2b .. :try_end_1e35} :catchall_1eb0

    :try_start_1e35
    move-object/from16 v0, p1

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v0, v35

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->J:Ljava/util/List;
    :try_end_1e41
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e35 .. :try_end_1e41} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e35 .. :try_end_1e41} :catch_1f28
    .catchall {:try_start_1e35 .. :try_end_1e41} :catchall_1eb0

    :try_start_1e41
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v8, v5, Laak;->L:Lixe;

    iput-object v11, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v14, v5, Laak;->P:Lixe;

    iput-object v15, v5, Laak;->Q:Lixe;

    iput-object v9, v5, Laak;->R:Lcp2;
    :try_end_1e51
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e41 .. :try_end_1e51} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e41 .. :try_end_1e51} :catch_1f26
    .catchall {:try_start_1e41 .. :try_end_1e51} :catchall_1eb0

    move/from16 v2, v45

    :try_start_1e53
    iput v2, v5, Laak;->e0:I
    :try_end_1e55
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e53 .. :try_end_1e55} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e53 .. :try_end_1e55} :catch_1f22
    .catchall {:try_start_1e53 .. :try_end_1e55} :catchall_1eb0

    move/from16 v45, v2

    move/from16 v2, v38

    :try_start_1e59
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_1e5b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e59 .. :try_end_1e5b} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e59 .. :try_end_1e5b} :catch_1f10
    .catchall {:try_start_1e59 .. :try_end_1e5b} :catchall_1eb0

    move/from16 v38, v2

    move/from16 v2, v37

    :try_start_1e5f
    iput v2, v5, Laak;->f0:I
    :try_end_1e61
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e5f .. :try_end_1e61} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e5f .. :try_end_1e61} :catch_1f04
    .catchall {:try_start_1e5f .. :try_end_1e61} :catchall_1eb0

    move-object/from16 v37, v8

    move-object/from16 v46, v9

    move-wide/from16 v8, v59

    :try_start_1e67
    iput-wide v8, v5, Laak;->k0:J
    :try_end_1e69
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e67 .. :try_end_1e69} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e67 .. :try_end_1e69} :catch_1efe
    .catchall {:try_start_1e67 .. :try_end_1e69} :catchall_1eb0

    move/from16 v47, v2

    move/from16 v2, v36

    :try_start_1e6d
    iput v2, v5, Laak;->g0:I

    const/4 v0, 0x2

    iput v0, v5, Laak;->m0:I

    invoke-static {v6, v7, v3, v1, v5}, Laak;->q(Lexe;Lhxe;Lo1e;Lpng;Laak;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1e76
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1e6d .. :try_end_1e76} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1e6d .. :try_end_1e76} :catch_1eb4
    .catchall {:try_start_1e6d .. :try_end_1e76} :catchall_1eb0

    move-object/from16 v36, v1

    move-object/from16 v1, v44

    if-ne v0, v1, :cond_1e7f

    :goto_1e7c
    move-object v2, v1

    goto/16 :goto_7700

    :cond_1e7f
    move-object/from16 v0, v46

    move-object/from16 v46, v6

    move-object v6, v0

    move/from16 v0, v45

    move-object/from16 v45, v7

    move/from16 v7, v38

    move-object/from16 v38, v13

    move v13, v0

    move/from16 v0, v47

    move-object/from16 v47, v36

    move-object/from16 v36, p1

    :goto_1e93
    move-object/from16 v44, v37

    move/from16 v37, v2

    move-object/from16 v2, v44

    move-object/from16 v44, v1

    move-wide/from16 v61, v8

    move-object/from16 v1, v43

    move-object/from16 v8, v45

    move-object v9, v6

    move/from16 v43, v13

    move-object/from16 v13, v38

    move-object/from16 v6, v47

    move/from16 v47, v0

    move/from16 v38, v7

    move-object/from16 v7, v46

    goto/16 :goto_1f49

    :catchall_1eb0
    move-exception v0

    move-object v1, v4

    goto/16 :goto_772a

    :catch_1eb4
    move-exception v0

    :goto_1eb5
    move-object/from16 v36, v1

    move-object/from16 v1, v44

    :goto_1eb9
    move-object/from16 v17, v11

    move-object v11, v6

    move-object/from16 v6, v17

    move/from16 v48, v2

    move-object/from16 v52, v14

    move-object/from16 v17, v37

    move-object/from16 v51, v41

    move-object/from16 v32, v43

    move/from16 v37, v45

    move-object/from16 v33, v46

    move/from16 v45, v47

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v2, v1

    move-object v1, v3

    move-object v14, v7

    move-wide/from16 v46, v8

    move-object/from16 v43, v15

    move-object/from16 v41, v35

    move-object/from16 v9, v36

    move/from16 v35, v38

    const/4 v7, 0x1

    move-object/from16 v36, p1

    move-object v8, v4

    move-object v15, v10

    move-object/from16 v38, v13

    move-object/from16 v4, v40

    :goto_1ef6
    move-object/from16 v13, v42

    goto/16 :goto_7437

    :catch_1efa
    move-exception v0

    move-object v1, v4

    goto/16 :goto_7729

    :catch_1efe
    move-exception v0

    move/from16 v47, v2

    move/from16 v2, v36

    goto :goto_1eb5

    :catch_1f04
    move-exception v0

    move/from16 v47, v2

    move-object/from16 v37, v8

    move-object/from16 v46, v9

    move/from16 v2, v36

    move-wide/from16 v8, v59

    goto :goto_1eb5

    :catch_1f10
    move-exception v0

    move/from16 v38, v2

    :goto_1f13
    move-object/from16 v46, v9

    move/from16 v2, v36

    move/from16 v47, v37

    move-object/from16 v36, v1

    move-object/from16 v37, v8

    move-object/from16 v1, v44

    move-wide/from16 v8, v59

    goto :goto_1eb9

    :catch_1f22
    move-exception v0

    move/from16 v45, v2

    goto :goto_1f13

    :catch_1f26
    move-exception v0

    goto :goto_1f13

    :catch_1f28
    move-exception v0

    goto :goto_1f13

    :cond_1f2a
    move-object/from16 v46, v9

    move/from16 v2, v36

    move/from16 v47, v37

    move-object/from16 v36, v1

    move-object/from16 v37, v8

    move-wide/from16 v8, v59

    move-object/from16 v1, v37

    move/from16 v37, v2

    move-object v2, v1

    move-wide/from16 v61, v8

    move-object/from16 v1, v43

    move/from16 v43, v45

    move-object/from16 v9, v46

    move-object v8, v7

    move-object v7, v6

    move-object/from16 v6, v36

    move-object/from16 v36, p1

    :goto_1f49
    :try_start_1f49
    iget-object v0, v1, Lnlh;->k:La1f;

    iget-object v0, v0, La1f;->F:Ljava/lang/Object;

    check-cast v0, Lrig;
    :try_end_1f4f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f49 .. :try_end_1f4f} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f49 .. :try_end_1f4f} :catch_72b4
    .catchall {:try_start_1f49 .. :try_end_1f4f} :catchall_1eb0

    move-object/from16 v45, v9

    const/4 v9, 0x0

    :try_start_1f52
    iput-boolean v9, v0, Lrig;->s:Z
    :try_end_1f54
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f52 .. :try_end_1f54} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f52 .. :try_end_1f54} :catch_72a4
    .catchall {:try_start_1f52 .. :try_end_1f54} :catchall_1eb0

    :try_start_1f54
    iget-object v0, v1, Lnlh;->k:La1f;

    iget-object v0, v0, La1f;->F:Ljava/lang/Object;

    check-cast v0, Lrig;

    iput-boolean v9, v0, Lrig;->t:Z
    :try_end_1f5c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f54 .. :try_end_1f5c} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f54 .. :try_end_1f5c} :catch_7264
    .catchall {:try_start_1f54 .. :try_end_1f5c} :catchall_1eb0

    :try_start_1f5c
    iget-object v0, v2, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;
    :try_end_1f60
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f5c .. :try_end_1f60} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f5c .. :try_end_1f60} :catch_7234
    .catchall {:try_start_1f5c .. :try_end_1f60} :catchall_1eb0

    if-eqz v39, :cond_2148

    if-eqz v0, :cond_2148

    :try_start_1f64
    iput-object v3, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v4, v5, Laak;->E:Lixe;

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v7, v5, Laak;->G:Lexe;

    iput-object v8, v5, Laak;->H:Lhxe;
    :try_end_1f6e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f64 .. :try_end_1f6e} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f64 .. :try_end_1f6e} :catch_2128
    .catchall {:try_start_1f64 .. :try_end_1f6e} :catchall_1eb0

    :try_start_1f6e
    move-object/from16 v9, v36

    check-cast v9, Ljava/util/List;

    iput-object v9, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v9, v35

    check-cast v9, Ljava/util/List;

    iput-object v9, v5, Laak;->J:Ljava/util/List;
    :try_end_1f7a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f6e .. :try_end_1f7a} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f6e .. :try_end_1f7a} :catch_2138
    .catchall {:try_start_1f6e .. :try_end_1f7a} :catchall_1eb0

    :try_start_1f7a
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v11, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v14, v5, Laak;->P:Lixe;

    iput-object v15, v5, Laak;->Q:Lixe;
    :try_end_1f88
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f7a .. :try_end_1f88} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f7a .. :try_end_1f88} :catch_2128
    .catchall {:try_start_1f7a .. :try_end_1f88} :catchall_1eb0

    move-object/from16 v9, v45

    :try_start_1f8a
    iput-object v9, v5, Laak;->R:Lcp2;
    :try_end_1f8c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f8a .. :try_end_1f8c} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f8a .. :try_end_1f8c} :catch_2124
    .catchall {:try_start_1f8a .. :try_end_1f8c} :catchall_1eb0

    move-object/from16 v45, v1

    const/4 v1, 0x0

    :try_start_1f8f
    iput-object v1, v5, Laak;->S:Lpe9;
    :try_end_1f91
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f8f .. :try_end_1f91} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f8f .. :try_end_1f91} :catch_210e
    .catchall {:try_start_1f8f .. :try_end_1f91} :catchall_1eb0

    move/from16 v1, v43

    :try_start_1f93
    iput v1, v5, Laak;->e0:I
    :try_end_1f95
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f93 .. :try_end_1f95} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f93 .. :try_end_1f95} :catch_2120
    .catchall {:try_start_1f93 .. :try_end_1f95} :catchall_1eb0

    move/from16 v43, v1

    move/from16 v1, v38

    :try_start_1f99
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_1f9b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f99 .. :try_end_1f9b} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f99 .. :try_end_1f9b} :catch_211c
    .catchall {:try_start_1f99 .. :try_end_1f9b} :catchall_1eb0

    move/from16 v38, v1

    const/4 v1, 0x0

    :try_start_1f9e
    iput v1, v5, Laak;->f0:I
    :try_end_1fa0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f9e .. :try_end_1fa0} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1f9e .. :try_end_1fa0} :catch_210e
    .catchall {:try_start_1f9e .. :try_end_1fa0} :catchall_1eb0

    move-object v1, v14

    move-object/from16 v46, v15

    move-wide/from16 v14, v61

    :try_start_1fa5
    iput-wide v14, v5, Laak;->k0:J
    :try_end_1fa7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1fa5 .. :try_end_1fa7} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1fa5 .. :try_end_1fa7} :catch_210a
    .catchall {:try_start_1fa5 .. :try_end_1fa7} :catchall_1eb0

    move-object/from16 p1, v1

    move/from16 v1, v37

    :try_start_1fab
    iput v1, v5, Laak;->g0:I
    :try_end_1fad
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1fab .. :try_end_1fad} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1fab .. :try_end_1fad} :catch_2106
    .catchall {:try_start_1fab .. :try_end_1fad} :catchall_1eb0

    move/from16 v37, v1

    const/4 v1, 0x3

    :try_start_1fb0
    iput v1, v5, Laak;->m0:I
    :try_end_1fb2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1fb0 .. :try_end_1fb2} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1fb0 .. :try_end_1fb2} :catch_20fc
    .catchall {:try_start_1fb0 .. :try_end_1fb2} :catchall_1eb0

    move-object/from16 v1, v41

    move-wide/from16 v208, v14

    move-object/from16 v14, v42

    move-wide/from16 v41, v208

    :try_start_1fba
    invoke-static {v14, v1, v0, v5}, Leak;->j(Leak;Ljava/lang/String;Ljava/lang/String;Lc75;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1fbe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1fba .. :try_end_1fbe} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_1fba .. :try_end_1fbe} :catch_20bf
    .catchall {:try_start_1fba .. :try_end_1fbe} :catchall_1eb0

    move-object/from16 v15, v44

    if-ne v0, v15, :cond_1fc5

    :goto_1fc2
    move-object v2, v15

    goto/16 :goto_7700

    :cond_1fc5
    move-object/from16 v44, v46

    move-object/from16 v46, v7

    move-object/from16 v7, v44

    move/from16 v44, v38

    move-object/from16 v38, v13

    move/from16 v13, v44

    move-object/from16 v47, v6

    const/16 v44, 0x0

    move-object v6, v4

    move-object v4, v3

    move-object v3, v2

    move-object/from16 v2, v36

    move/from16 v36, v37

    move-object/from16 v37, p1

    :goto_1fde
    :try_start_1fde
    check-cast v0, Lv9k;
    :try_end_1fe0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1fde .. :try_end_1fe0} :catch_20b5
    .catch Ljava/lang/Exception; {:try_start_1fde .. :try_end_1fe0} :catch_20b9
    .catchall {:try_start_1fde .. :try_end_1fe0} :catchall_20aa

    move-object/from16 p1, v4

    :try_start_1fe2
    move-object v4, v2

    check-cast v4, Ljava/util/Collection;

    invoke-virtual {v0}, Lv9k;->a()Ljava/util/List;

    move-result-object v48
    :try_end_1fe9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1fe2 .. :try_end_1fe9} :catch_20b5
    .catch Ljava/lang/Exception; {:try_start_1fe2 .. :try_end_1fe9} :catch_20af
    .catchall {:try_start_1fe2 .. :try_end_1fe9} :catchall_20aa

    move-object/from16 v49, v6

    :try_start_1feb
    move-object/from16 v6, v48

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v4, v6}, Lxm4;->b0(Ljava/util/Collection;Ljava/lang/Iterable;)V

    invoke-virtual {v0}, Lv9k;->b()Ljava/lang/String;

    move-result-object v4
    :try_end_1ff6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1feb .. :try_end_1ff6} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_1feb .. :try_end_1ff6} :catch_20a6
    .catchall {:try_start_1feb .. :try_end_1ff6} :catchall_1ffb

    if-eqz v4, :cond_2044

    :try_start_1ff8
    iput-object v4, v3, Lixe;->E:Ljava/lang/Object;
    :try_end_1ffa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1ff8 .. :try_end_1ffa} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_1ff8 .. :try_end_1ffa} :catch_2000
    .catchall {:try_start_1ff8 .. :try_end_1ffa} :catchall_1ffb

    goto :goto_2044

    :catchall_1ffb
    move-exception v0

    :goto_1ffc
    move-object/from16 v1, v49

    goto/16 :goto_772a

    :catch_2000
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 v17, v3

    move-object/from16 v33, v9

    move-object v6, v11

    move/from16 v48, v36

    move-object/from16 v52, v37

    move-object/from16 v4, v40

    move/from16 v37, v43

    move-object/from16 v32, v45

    move-object/from16 v11, v46

    move-object/from16 v9, v47

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v1, p1

    move-object/from16 v36, v2

    move-object/from16 v43, v7

    move-object v2, v15

    move-wide/from16 v46, v41

    move/from16 v45, v44

    const/4 v7, 0x1

    move-object v15, v10

    move-object/from16 v41, v35

    :goto_2037
    move/from16 v35, v13

    move-object v13, v14

    move-object v14, v8

    :goto_203b
    move-object/from16 v8, v49

    goto/16 :goto_7437

    :catch_203f
    move-exception v0

    :goto_2040
    move-object/from16 v1, v49

    goto/16 :goto_7729

    :cond_2044
    :goto_2044
    :try_start_2044
    new-instance v4, Lpe9;

    invoke-virtual {v0}, Lv9k;->c()Lpg0;

    move-result-object v0

    move-object/from16 v6, v35

    check-cast v6, Ljava/util/Collection;
    :try_end_204e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2044 .. :try_end_204e} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_2044 .. :try_end_204e} :catch_20a6
    .catchall {:try_start_2044 .. :try_end_204e} :catchall_1ffb

    move-object/from16 v48, v3

    :try_start_2050
    move-object v3, v2

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v6, v3}, Lsm4;->K0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-direct {v4, v2, v0, v3}, Lpe9;-><init>(Ljava/util/List;Lpg0;Ljava/util/List;)V
    :try_end_205a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2050 .. :try_end_205a} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_2050 .. :try_end_205a} :catch_206e
    .catchall {:try_start_2050 .. :try_end_205a} :catchall_1ffb

    move-object v0, v4

    move-object v6, v9

    move-object v9, v12

    move-object/from16 v4, v35

    move/from16 v27, v36

    move-object/from16 v3, v48

    move-object/from16 v35, p1

    move-object/from16 v36, v2

    move-object/from16 v48, v7

    move v7, v13

    move-wide/from16 v12, v41

    goto/16 :goto_23be

    :catch_206e
    move-exception v0

    :goto_206f
    move-object/from16 v51, v1

    move-object/from16 v33, v9

    move-object v6, v11

    move-object/from16 v52, v37

    move-object/from16 v4, v40

    move/from16 v37, v43

    move-object/from16 v32, v45

    move-object/from16 v11, v46

    move-object/from16 v9, v47

    move-object/from16 v17, v48

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v1, p1

    move-object/from16 v43, v7

    move/from16 v48, v36

    move-wide/from16 v46, v41

    move/from16 v45, v44

    const/4 v7, 0x1

    move-object/from16 v36, v2

    move-object v2, v15

    move-object/from16 v41, v35

    move-object v15, v10

    goto :goto_2037

    :catch_20a6
    move-exception v0

    move-object/from16 v48, v3

    goto :goto_206f

    :catchall_20aa
    move-exception v0

    move-object/from16 v49, v6

    goto/16 :goto_1ffc

    :catch_20af
    move-exception v0

    move-object/from16 v48, v3

    :goto_20b2
    move-object/from16 v49, v6

    goto :goto_206f

    :catch_20b5
    move-exception v0

    move-object/from16 v49, v6

    goto :goto_2040

    :catch_20b9
    move-exception v0

    move-object/from16 v48, v3

    move-object/from16 p1, v4

    goto :goto_20b2

    :catch_20bf
    move-exception v0

    :goto_20c0
    move-object/from16 v15, v44

    :goto_20c2
    move-object/from16 v52, p1

    move-object/from16 v51, v1

    move-object/from16 v17, v2

    move-object v1, v3

    move-object/from16 v33, v9

    move-object v2, v15

    move/from16 v48, v37

    move/from16 v37, v43

    move-object/from16 v32, v45

    move-object/from16 v43, v46

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v45, 0x0

    const-wide/16 v56, 0x0

    move-object v9, v6

    move-object v15, v10

    move-object v6, v11

    move-wide/from16 v46, v41

    move-object v11, v7

    move-object/from16 v41, v35

    move/from16 v35, v38

    const/4 v7, 0x1

    move-object/from16 v38, v13

    move-object v13, v14

    move-object v14, v8

    :goto_20f7
    move-object v8, v4

    :goto_20f8
    move-object/from16 v4, v40

    goto/16 :goto_7437

    :catch_20fc
    move-exception v0

    :goto_20fd
    move-object/from16 v1, v41

    move-wide/from16 v208, v14

    move-object/from16 v14, v42

    move-wide/from16 v41, v208

    goto :goto_20c0

    :catch_2106
    move-exception v0

    move/from16 v37, v1

    goto :goto_20fd

    :catch_210a
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_20fd

    :catch_210e
    move-exception v0

    :goto_210f
    move-object/from16 p1, v14

    move-object/from16 v46, v15

    move-object/from16 v1, v41

    move-object/from16 v14, v42

    move-object/from16 v15, v44

    :goto_2119
    move-wide/from16 v41, v61

    goto :goto_20c2

    :catch_211c
    move-exception v0

    move/from16 v38, v1

    goto :goto_210f

    :catch_2120
    move-exception v0

    move/from16 v43, v1

    goto :goto_210f

    :catch_2124
    move-exception v0

    move-object/from16 v45, v1

    goto :goto_210f

    :catch_2128
    move-exception v0

    move-object/from16 p1, v14

    move-object/from16 v46, v15

    move-object/from16 v14, v42

    move-object/from16 v15, v44

    move-object/from16 v9, v45

    move-object/from16 v45, v1

    move-object/from16 v1, v41

    goto :goto_2119

    :catch_2138
    move-exception v0

    move-object/from16 p1, v14

    move-object/from16 v46, v15

    move-object/from16 v14, v42

    move-object/from16 v15, v44

    move-object/from16 v9, v45

    move-object/from16 v45, v1

    move-object/from16 v1, v41

    goto :goto_2119

    :cond_2148
    move-object/from16 p1, v14

    move-object/from16 v46, v15

    move-object/from16 v14, v42

    move-object/from16 v15, v44

    move-object/from16 v9, v45

    move-object/from16 v45, v1

    move-object/from16 v1, v41

    move-wide/from16 v41, v61

    if-eqz v39, :cond_2331

    :try_start_215a
    iput-object v3, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v4, v5, Laak;->E:Lixe;

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v7, v5, Laak;->G:Lexe;

    iput-object v8, v5, Laak;->H:Lhxe;
    :try_end_2164
    .catch Ljava/util/concurrent/CancellationException; {:try_start_215a .. :try_end_2164} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_215a .. :try_end_2164} :catch_2325
    .catchall {:try_start_215a .. :try_end_2164} :catchall_1eb0

    :try_start_2164
    move-object/from16 v0, v36

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v0, v35

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->J:Ljava/util/List;
    :try_end_2170
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2164 .. :try_end_2170} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2164 .. :try_end_2170} :catch_2329
    .catchall {:try_start_2164 .. :try_end_2170} :catchall_1eb0

    :try_start_2170
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v11, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;
    :try_end_217a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2170 .. :try_end_217a} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2170 .. :try_end_217a} :catch_2325
    .catchall {:try_start_2170 .. :try_end_217a} :catchall_1eb0

    move-object/from16 v44, v13

    move-object/from16 v13, p1

    :try_start_217e
    iput-object v13, v5, Laak;->P:Lixe;
    :try_end_2180
    .catch Ljava/util/concurrent/CancellationException; {:try_start_217e .. :try_end_2180} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_217e .. :try_end_2180} :catch_231d
    .catchall {:try_start_217e .. :try_end_2180} :catchall_1eb0

    move-object/from16 p1, v13

    move-object/from16 v13, v46

    :try_start_2184
    iput-object v13, v5, Laak;->Q:Lixe;

    iput-object v9, v5, Laak;->R:Lcp2;
    :try_end_2188
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2184 .. :try_end_2188} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2184 .. :try_end_2188} :catch_2319
    .catchall {:try_start_2184 .. :try_end_2188} :catchall_1eb0

    move-object/from16 v46, v9

    const/4 v9, 0x0

    :try_start_218b
    iput-object v9, v5, Laak;->S:Lpe9;
    :try_end_218d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_218b .. :try_end_218d} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_218b .. :try_end_218d} :catch_2307
    .catchall {:try_start_218b .. :try_end_218d} :catchall_1eb0

    move/from16 v9, v43

    :try_start_218f
    iput v9, v5, Laak;->e0:I
    :try_end_2191
    .catch Ljava/util/concurrent/CancellationException; {:try_start_218f .. :try_end_2191} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_218f .. :try_end_2191} :catch_2315
    .catchall {:try_start_218f .. :try_end_2191} :catchall_1eb0

    move/from16 v43, v9

    move/from16 v9, v38

    :try_start_2195
    iput-boolean v9, v5, Laak;->i0:Z
    :try_end_2197
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2195 .. :try_end_2197} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2195 .. :try_end_2197} :catch_2311
    .catchall {:try_start_2195 .. :try_end_2197} :catchall_1eb0

    move/from16 v38, v9

    const/4 v9, 0x0

    :try_start_219a
    iput v9, v5, Laak;->f0:I
    :try_end_219c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_219a .. :try_end_219c} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_219a .. :try_end_219c} :catch_2307
    .catchall {:try_start_219a .. :try_end_219c} :catchall_1eb0

    move-object v9, v12

    move-object/from16 v48, v13

    move-wide/from16 v12, v41

    :try_start_21a1
    iput-wide v12, v5, Laak;->k0:J
    :try_end_21a3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21a1 .. :try_end_21a3} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_21a1 .. :try_end_21a3} :catch_2303
    .catchall {:try_start_21a1 .. :try_end_21a3} :catchall_1eb0

    move-object/from16 v41, v9

    move/from16 v9, v37

    :try_start_21a7
    iput v9, v5, Laak;->g0:I
    :try_end_21a9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21a7 .. :try_end_21a9} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_21a7 .. :try_end_21a9} :catch_22ff
    .catchall {:try_start_21a7 .. :try_end_21a9} :catchall_1eb0

    move/from16 v37, v9

    const/4 v9, 0x4

    :try_start_21ac
    iput v9, v5, Laak;->m0:I

    invoke-virtual {v14, v1, v5}, Leak;->l(Ljava/lang/String;Lc75;)Ljava/lang/Object;

    move-result-object v0
    :try_end_21b2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21ac .. :try_end_21b2} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_21ac .. :try_end_21b2} :catch_22c3
    .catchall {:try_start_21ac .. :try_end_21b2} :catchall_1eb0

    if-ne v0, v15, :cond_21b6

    goto/16 :goto_1fc2

    :cond_21b6
    move-object/from16 v47, v6

    move-object/from16 v42, v35

    move/from16 v9, v43

    move-object/from16 v6, v46

    const/16 v43, 0x0

    move-object/from16 v35, v3

    move-object/from16 v46, v7

    move/from16 v7, v38

    move-object/from16 v38, v44

    move-object v3, v2

    move-object/from16 v2, v36

    move/from16 v36, v37

    move-object/from16 v37, p1

    :goto_21cf
    :try_start_21cf
    check-cast v0, Lw9k;

    invoke-interface {v2}, Ljava/util/List;->clear()V
    :try_end_21d4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21cf .. :try_end_21d4} :catch_22bf
    .catch Ljava/lang/Exception; {:try_start_21cf .. :try_end_21d4} :catch_22b9
    .catchall {:try_start_21cf .. :try_end_21d4} :catchall_22b4

    move-object/from16 p1, v4

    :try_start_21d6
    move-object v4, v2

    check-cast v4, Ljava/util/Collection;
    :try_end_21d9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21d6 .. :try_end_21d9} :catch_2266
    .catch Ljava/lang/Exception; {:try_start_21d6 .. :try_end_21d9} :catch_22ae
    .catchall {:try_start_21d6 .. :try_end_21d9} :catchall_2220

    move-object/from16 v44, v6

    :try_start_21db
    iget-object v6, v0, Lw9k;->a:Ljava/util/List;

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v4, v6}, Lxm4;->b0(Ljava/util/Collection;Ljava/lang/Iterable;)V

    iget-object v4, v0, Lw9k;->f:Ljava/util/List;

    iget-object v6, v0, Lw9k;->a:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    invoke-static {v6, v4}, Lsm4;->r0(ILjava/util/List;)Ljava/util/List;

    move-result-object v4
    :try_end_21ee
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21db .. :try_end_21ee} :catch_2266
    .catch Ljava/lang/Exception; {:try_start_21db .. :try_end_21ee} :catch_226f
    .catchall {:try_start_21db .. :try_end_21ee} :catchall_2220

    :try_start_21ee
    invoke-virtual {v0}, Lw9k;->c()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v10, Lixe;->E:Ljava/lang/Object;

    invoke-virtual {v0}, Lw9k;->b()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v3, Lixe;->E:Ljava/lang/Object;

    invoke-virtual {v0}, Lw9k;->a()Z

    move-result v6

    iput-boolean v6, v11, Lexe;->E:Z

    new-instance v6, Lpe9;
    :try_end_2202
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21ee .. :try_end_2202} :catch_2266
    .catch Ljava/lang/Exception; {:try_start_21ee .. :try_end_2202} :catch_226b
    .catchall {:try_start_21ee .. :try_end_2202} :catchall_2220

    move-object/from16 v49, v3

    :try_start_2204
    invoke-virtual {v0}, Lw9k;->d()Lpg0;

    move-result-object v3

    iget-object v0, v0, Lw9k;->f:Ljava/util/List;

    invoke-direct {v6, v2, v3, v0}, Lpe9;-><init>(Ljava/util/List;Lpg0;Ljava/util/List;)V
    :try_end_220d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2204 .. :try_end_220d} :catch_2266
    .catch Ljava/lang/Exception; {:try_start_2204 .. :try_end_220d} :catch_2225
    .catchall {:try_start_2204 .. :try_end_220d} :catchall_2220

    move-object v0, v6

    move/from16 v27, v36

    move-object/from16 v6, v44

    move-object/from16 v3, v49

    move-object/from16 v49, p1

    move-object/from16 v36, v2

    move/from16 v44, v43

    move/from16 v43, v9

    move-object/from16 v9, v41

    goto/16 :goto_23be

    :catchall_2220
    move-exception v0

    :goto_2221
    move-object/from16 v1, p1

    goto/16 :goto_772a

    :catch_2225
    move-exception v0

    :goto_2226
    move-object/from16 v51, v1

    move-object v6, v11

    move-object/from16 v1, v35

    move-object/from16 v52, v37

    move-object/from16 v33, v44

    move-object/from16 v32, v45

    move-object/from16 v11, v46

    move-object/from16 v17, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v35, v7

    move/from16 v37, v9

    move/from16 v45, v43

    move-object/from16 v9, v47

    move-object/from16 v43, v48

    const/4 v7, 0x1

    move-wide/from16 v46, v12

    move-object v13, v14

    move/from16 v48, v36

    move-object/from16 v12, v41

    move-object/from16 v36, v2

    move-object/from16 v41, v4

    move-object v14, v8

    move-object v2, v15

    move-object/from16 v4, v40

    :goto_2261
    move-object/from16 v8, p1

    :goto_2263
    move-object v15, v10

    goto/16 :goto_7437

    :catch_2266
    move-exception v0

    :goto_2267
    move-object/from16 v1, p1

    goto/16 :goto_7729

    :catch_226b
    move-exception v0

    move-object/from16 v49, v3

    goto :goto_2226

    :catch_226f
    move-exception v0

    move-object/from16 v49, v3

    :goto_2272
    move-object/from16 v51, v1

    move-object v6, v11

    move-object/from16 v1, v35

    move-object/from16 v52, v37

    move-object/from16 v4, v40

    move-object/from16 v33, v44

    move-object/from16 v32, v45

    move-object/from16 v11, v46

    move-object/from16 v17, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v35, v7

    move/from16 v37, v9

    move/from16 v45, v43

    move-object/from16 v9, v47

    move-object/from16 v43, v48

    const/4 v7, 0x1

    move-wide/from16 v46, v12

    move-object v13, v14

    move/from16 v48, v36

    move-object/from16 v12, v41

    move-object/from16 v41, v42

    move-object/from16 v36, v2

    move-object v14, v8

    move-object v2, v15

    goto :goto_2261

    :catch_22ae
    move-exception v0

    move-object/from16 v49, v3

    :goto_22b1
    move-object/from16 v44, v6

    goto :goto_2272

    :catchall_22b4
    move-exception v0

    move-object/from16 p1, v4

    goto/16 :goto_2221

    :catch_22b9
    move-exception v0

    move-object/from16 v49, v3

    move-object/from16 p1, v4

    goto :goto_22b1

    :catch_22bf
    move-exception v0

    move-object/from16 p1, v4

    goto :goto_2267

    :catch_22c3
    move-exception v0

    :goto_22c4
    move-object/from16 v9, v48

    move/from16 v48, v37

    move/from16 v37, v43

    move-object/from16 v43, v9

    move-object/from16 v52, p1

    move-object/from16 v51, v1

    move-object/from16 v17, v2

    move-object v1, v3

    move-object v9, v6

    move-object v6, v11

    move-object v2, v15

    move-object/from16 v32, v45

    move-object/from16 v33, v46

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v45, 0x0

    const-wide/16 v56, 0x0

    move-object v11, v7

    move-object v15, v10

    move-wide/from16 v46, v12

    move-object v13, v14

    move-object/from16 v12, v41

    const/4 v7, 0x1

    move-object v14, v8

    move-object/from16 v41, v35

    move/from16 v35, v38

    move-object/from16 v38, v44

    goto/16 :goto_20f7

    :catch_22ff
    move-exception v0

    move/from16 v37, v9

    goto :goto_22c4

    :catch_2303
    move-exception v0

    move-object/from16 v41, v9

    goto :goto_22c4

    :catch_2307
    move-exception v0

    :goto_2308
    move-object/from16 v48, v13

    :goto_230a
    move-wide/from16 v208, v41

    move-object/from16 v41, v12

    move-wide/from16 v12, v208

    goto :goto_22c4

    :catch_2311
    move-exception v0

    move/from16 v38, v9

    goto :goto_2308

    :catch_2315
    move-exception v0

    move/from16 v43, v9

    goto :goto_2308

    :catch_2319
    move-exception v0

    move-object/from16 v46, v9

    goto :goto_2308

    :catch_231d
    move-exception v0

    move-object/from16 p1, v13

    :goto_2320
    move-object/from16 v48, v46

    move-object/from16 v46, v9

    goto :goto_230a

    :catch_2325
    move-exception v0

    move-object/from16 v44, v13

    goto :goto_2320

    :catch_2329
    move-exception v0

    move-object/from16 v44, v13

    move-object/from16 v48, v46

    move-object/from16 v46, v9

    goto :goto_230a

    :cond_2331
    move-object/from16 v44, v13

    move-object/from16 v48, v46

    move-object/from16 v46, v9

    move-wide/from16 v208, v41

    move-object/from16 v41, v12

    move-wide/from16 v12, v208

    :try_start_233d
    iput-object v3, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v4, v5, Laak;->E:Lixe;

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v7, v5, Laak;->G:Lexe;

    iput-object v8, v5, Laak;->H:Lhxe;
    :try_end_2347
    .catch Ljava/util/concurrent/CancellationException; {:try_start_233d .. :try_end_2347} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_233d .. :try_end_2347} :catch_71f3
    .catchall {:try_start_233d .. :try_end_2347} :catchall_1eb0

    :try_start_2347
    move-object/from16 v0, v36

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v0, v35

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->J:Ljava/util/List;
    :try_end_2353
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2347 .. :try_end_2353} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2347 .. :try_end_2353} :catch_7213
    .catchall {:try_start_2347 .. :try_end_2353} :catchall_1eb0

    :try_start_2353
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v11, v5, Laak;->M:Lexe;
    :try_end_2359
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2353 .. :try_end_2359} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2353 .. :try_end_2359} :catch_71f3
    .catchall {:try_start_2353 .. :try_end_2359} :catchall_1eb0

    move-object/from16 v9, v41

    :try_start_235b
    iput-object v9, v5, Laak;->N:Lexe;
    :try_end_235d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_235b .. :try_end_235d} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_235b .. :try_end_235d} :catch_71ed
    .catchall {:try_start_235b .. :try_end_235d} :catchall_1eb0

    move-object/from16 v41, v2

    move-object/from16 v2, v44

    :try_start_2361
    iput-object v2, v5, Laak;->O:Lexe;
    :try_end_2363
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2361 .. :try_end_2363} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2361 .. :try_end_2363} :catch_71e7
    .catchall {:try_start_2361 .. :try_end_2363} :catchall_1eb0

    move-object/from16 v44, v2

    move-object/from16 v2, p1

    :try_start_2367
    iput-object v2, v5, Laak;->P:Lixe;
    :try_end_2369
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2367 .. :try_end_2369} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2367 .. :try_end_2369} :catch_71e1
    .catchall {:try_start_2367 .. :try_end_2369} :catchall_1eb0

    move-object/from16 p1, v2

    move-object/from16 v2, v48

    :try_start_236d
    iput-object v2, v5, Laak;->Q:Lixe;
    :try_end_236f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_236d .. :try_end_236f} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_236d .. :try_end_236f} :catch_71db
    .catchall {:try_start_236d .. :try_end_236f} :catchall_1eb0

    move-object/from16 v48, v2

    move-object/from16 v2, v46

    :try_start_2373
    iput-object v2, v5, Laak;->R:Lcp2;
    :try_end_2375
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2373 .. :try_end_2375} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2373 .. :try_end_2375} :catch_71d5
    .catchall {:try_start_2373 .. :try_end_2375} :catchall_1eb0

    move-object/from16 v46, v2

    const/4 v2, 0x0

    :try_start_2378
    iput-object v2, v5, Laak;->S:Lpe9;
    :try_end_237a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2378 .. :try_end_237a} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2378 .. :try_end_237a} :catch_717b
    .catchall {:try_start_2378 .. :try_end_237a} :catchall_1eb0

    move/from16 v2, v43

    :try_start_237c
    iput v2, v5, Laak;->e0:I
    :try_end_237e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_237c .. :try_end_237e} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_237c .. :try_end_237e} :catch_71cf
    .catchall {:try_start_237c .. :try_end_237e} :catchall_1eb0

    move/from16 v43, v2

    move/from16 v2, v38

    :try_start_2382
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_2384
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2382 .. :try_end_2384} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2382 .. :try_end_2384} :catch_71c9
    .catchall {:try_start_2382 .. :try_end_2384} :catchall_1eb0

    move/from16 v38, v2

    const/4 v2, 0x0

    :try_start_2387
    iput v2, v5, Laak;->f0:I

    iput-wide v12, v5, Laak;->k0:J
    :try_end_238b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2387 .. :try_end_238b} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2387 .. :try_end_238b} :catch_717b
    .catchall {:try_start_2387 .. :try_end_238b} :catchall_1eb0

    move/from16 v2, v37

    :try_start_238d
    iput v2, v5, Laak;->g0:I
    :try_end_238f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_238d .. :try_end_238f} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_238d .. :try_end_238f} :catch_71c3
    .catchall {:try_start_238d .. :try_end_238f} :catchall_1eb0

    move/from16 v37, v2

    const/4 v2, 0x5

    :try_start_2392
    iput v2, v5, Laak;->m0:I

    invoke-static {v14, v1, v5}, Leak;->k(Leak;Ljava/lang/String;Lc75;)Ljava/lang/Object;

    move-result-object v0
    :try_end_2398
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2392 .. :try_end_2398} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2392 .. :try_end_2398} :catch_717b
    .catchall {:try_start_2392 .. :try_end_2398} :catchall_1eb0

    if-ne v0, v15, :cond_239c

    goto/16 :goto_1fc2

    :cond_239c
    move-object/from16 v47, v6

    move/from16 v27, v38

    move-object/from16 v38, v44

    move-object/from16 v6, v46

    const/16 v42, 0x0

    move-object/from16 v46, v7

    move/from16 v7, v37

    move-object/from16 v37, p1

    :goto_23ac
    :try_start_23ac
    check-cast v0, Lpe9;
    :try_end_23ae
    .catch Ljava/util/concurrent/CancellationException; {:try_start_23ac .. :try_end_23ae} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_23ac .. :try_end_23ae} :catch_7139
    .catchall {:try_start_23ac .. :try_end_23ae} :catchall_1eb0

    move/from16 v44, v27

    move/from16 v27, v7

    move/from16 v7, v44

    move-object/from16 v49, v4

    move-object/from16 v4, v35

    move/from16 v44, v42

    move-object/from16 v35, v3

    move-object/from16 v3, v41

    :goto_23be
    :try_start_23be
    iget-object v2, v3, Lixe;->E:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;
    :try_end_23c2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_23be .. :try_end_23c2} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_23be .. :try_end_23c2} :catch_7133
    .catchall {:try_start_23be .. :try_end_23c2} :catchall_1ffb

    if-nez v2, :cond_242b

    :try_start_23c4
    iget-object v2, v0, Lpe9;->a:Ljava/util/List;

    invoke-static {v2}, Lsm4;->l0(Ljava/util/List;)Ll9b;

    move-result-object v2

    invoke-virtual {v2}, Ll9b;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_23ce
    move-object/from16 v41, v2

    check-cast v41, Lygf;

    invoke-virtual/range {v41 .. v41}, Lygf;->hasNext()Z

    move-result v42

    if-eqz v42, :cond_242a

    invoke-virtual/range {v41 .. v41}, Lygf;->next()Ljava/lang/Object;

    move-result-object v41

    check-cast v41, Lcom/anthropic/claude/sessions/types/SdkEvent;

    invoke-static/range {v41 .. v41}, Lolk;->h(Lcom/anthropic/claude/sessions/types/SdkEvent;)Ljava/lang/String;

    move-result-object v41
    :try_end_23e2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_23c4 .. :try_end_23e2} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_23c4 .. :try_end_23e2} :catch_23e7
    .catchall {:try_start_23c4 .. :try_end_23e2} :catchall_1ffb

    if-eqz v41, :cond_23ce

    move-object/from16 v2, v41

    goto :goto_242b

    :catch_23e7
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 v17, v3

    move-object/from16 v41, v4

    move-object/from16 v33, v6

    move-object v6, v11

    move-object v2, v15

    move-object/from16 v1, v35

    move-object/from16 v52, v37

    move-object/from16 v4, v40

    :goto_23f8
    move/from16 v37, v43

    move-object/from16 v32, v45

    move-object/from16 v11, v46

    move-object/from16 v43, v48

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move/from16 v35, v7

    move-object v15, v10

    move/from16 v48, v27

    move/from16 v45, v44

    const/4 v7, 0x1

    move-object/from16 v208, v14

    move-object v14, v8

    move-object/from16 v8, v49

    move-wide/from16 v209, v12

    move-object v12, v9

    move-object/from16 v13, v208

    move-object/from16 v9, v47

    move-wide/from16 v46, v209

    goto/16 :goto_7437

    :cond_242a
    const/4 v2, 0x0

    :cond_242b
    :goto_242b
    if-eqz v2, :cond_2459

    :try_start_242d
    invoke-virtual/range {v45 .. v45}, Lnlh;->i()Lq98;

    move-result-object v41
    :try_end_2431
    .catch Ljava/util/concurrent/CancellationException; {:try_start_242d .. :try_end_2431} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_242d .. :try_end_2431} :catch_2455
    .catchall {:try_start_242d .. :try_end_2431} :catchall_1ffb

    move-object/from16 v51, v1

    :try_start_2433
    invoke-static/range {v51 .. v51}, Lcom/anthropic/claude/types/strings/SessionId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/SessionId;

    move-result-object v1
    :try_end_2437
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2433 .. :try_end_2437} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_2433 .. :try_end_2437} :catch_2451
    .catchall {:try_start_2433 .. :try_end_2437} :catchall_1ffb

    move-object/from16 v42, v3

    :try_start_2439
    move-object/from16 v3, v41

    check-cast v3, Llp4;

    invoke-virtual {v3, v1, v2}, Llp4;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2440
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2439 .. :try_end_2440} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_2439 .. :try_end_2440} :catch_2441
    .catchall {:try_start_2439 .. :try_end_2440} :catchall_1ffb

    goto :goto_245d

    :catch_2441
    move-exception v0

    :goto_2442
    move-object/from16 v41, v4

    move-object/from16 v33, v6

    move-object v6, v11

    move-object v2, v15

    move-object/from16 v1, v35

    move-object/from16 v52, v37

    move-object/from16 v4, v40

    move-object/from16 v17, v42

    goto :goto_23f8

    :catch_2451
    move-exception v0

    :goto_2452
    move-object/from16 v42, v3

    goto :goto_2442

    :catch_2455
    move-exception v0

    move-object/from16 v51, v1

    goto :goto_2452

    :cond_2459
    move-object/from16 v51, v1

    move-object/from16 v42, v3

    :goto_245d
    :try_start_245d
    new-instance v1, Lexe;

    invoke-direct {v1}, Lexe;-><init>()V

    invoke-virtual/range {v45 .. v45}, Lnlh;->c()Lhhg;

    move-result-object v2

    iget-object v3, v0, Lpe9;->a:Ljava/util/List;

    move-object/from16 p1, v1

    invoke-virtual {v0}, Lpe9;->a()Lpg0;

    move-result-object v1
    :try_end_246e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_245d .. :try_end_246e} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_245d .. :try_end_246e} :catch_711a
    .catchall {:try_start_245d .. :try_end_246e} :catchall_1ffb

    move-object/from16 v41, v4

    const/4 v4, 0x4

    :try_start_2471
    invoke-static {v2, v3, v1, v4}, Lhhg;->q(Lhhg;Ljava/util/List;Lpg0;I)Ldla;

    move-result-object v1

    iget-boolean v2, v5, Laak;->s0:Z

    invoke-virtual {v1}, Ldla;->iterator()Ljava/util/Iterator;

    move-result-object v1
    :try_end_247b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2471 .. :try_end_247b} :catch_203f
    .catch Ljava/lang/Exception; {:try_start_2471 .. :try_end_247b} :catch_70dc
    .catchall {:try_start_2471 .. :try_end_247b} :catchall_1ffb

    move/from16 v67, v7

    move-wide/from16 v65, v12

    move-object/from16 v52, v14

    move-object/from16 v53, v15

    move/from16 v63, v27

    move-object/from16 v4, v37

    move-object/from16 v13, v38

    move/from16 v68, v43

    move/from16 v64, v44

    move-object/from16 v7, v46

    move-object/from16 v14, v48

    move-object/from16 v3, v49

    move/from16 v27, v2

    move-object v15, v6

    move-object v12, v9

    move-object/from16 v9, v42

    move-object/from16 v6, v47

    move-object v2, v0

    move-object/from16 v0, p1

    move-object/from16 p1, v1

    move-object/from16 v1, v35

    :goto_24a2
    :try_start_24a2
    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v35
    :try_end_24a6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_24a2 .. :try_end_24a6} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_24a2 .. :try_end_24a6} :catch_70ac
    .catchall {:try_start_24a2 .. :try_end_24a6} :catchall_7047

    if-eqz v35, :cond_2663

    :try_start_24a8
    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v35

    move-object/from16 v37, v2

    move-object/from16 v2, v35

    check-cast v2, Long;
    :try_end_24b2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_24a8 .. :try_end_24b2} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_24a8 .. :try_end_24b2} :catch_2659
    .catchall {:try_start_24a8 .. :try_end_24b2} :catchall_24bf

    move-object/from16 v35, v15

    :try_start_24b4
    instance-of v15, v2, Lmng;
    :try_end_24b6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_24b4 .. :try_end_24b6} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_24b4 .. :try_end_24b6} :catch_2649
    .catchall {:try_start_24b4 .. :try_end_24b6} :catchall_24bf

    if-eqz v15, :cond_24fe

    const/4 v15, 0x0

    :try_start_24b9
    iput-object v15, v10, Lixe;->E:Ljava/lang/Object;

    const/4 v15, 0x0

    iput-boolean v15, v11, Lexe;->E:Z
    :try_end_24be
    .catch Ljava/util/concurrent/CancellationException; {:try_start_24b9 .. :try_end_24be} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_24b9 .. :try_end_24be} :catch_24c3
    .catchall {:try_start_24b9 .. :try_end_24be} :catchall_24bf

    goto :goto_24fe

    :catchall_24bf
    move-exception v0

    move-object v1, v3

    goto/16 :goto_772a

    :catch_24c3
    move-exception v0

    move-object/from16 v17, v9

    move-object v15, v10

    move-object/from16 v38, v13

    move-object/from16 v43, v14

    move-object/from16 v33, v35

    move-object/from16 v32, v45

    move-object/from16 v13, v52

    move-object/from16 v2, v53

    move/from16 v48, v63

    move/from16 v45, v64

    move-wide/from16 v46, v65

    move/from16 v35, v67

    move/from16 v37, v68

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v52, v4

    move-object v9, v6

    move-object v14, v8

    move-object v6, v11

    move-object/from16 v4, v40

    :goto_24f6
    move-object v8, v3

    move-object v11, v7

    goto/16 :goto_42e

    :catch_24fa
    move-exception v0

    move-object v1, v3

    goto/16 :goto_7729

    :cond_24fe
    :goto_24fe
    :try_start_24fe
    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->E:Lixe;

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v7, v5, Laak;->G:Lexe;

    iput-object v8, v5, Laak;->H:Lhxe;
    :try_end_2508
    .catch Ljava/util/concurrent/CancellationException; {:try_start_24fe .. :try_end_2508} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_24fe .. :try_end_2508} :catch_2649
    .catchall {:try_start_24fe .. :try_end_2508} :catchall_24bf

    :try_start_2508
    move-object/from16 v15, v36

    check-cast v15, Ljava/util/List;

    iput-object v15, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v15, v41

    check-cast v15, Ljava/util/List;

    iput-object v15, v5, Laak;->J:Ljava/util/List;
    :try_end_2514
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2508 .. :try_end_2514} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2508 .. :try_end_2514} :catch_265f
    .catchall {:try_start_2508 .. :try_end_2514} :catchall_24bf

    :try_start_2514
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v9, v5, Laak;->L:Lixe;

    iput-object v11, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v4, v5, Laak;->P:Lixe;

    iput-object v14, v5, Laak;->Q:Lixe;
    :try_end_2522
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2514 .. :try_end_2522} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2514 .. :try_end_2522} :catch_2649
    .catchall {:try_start_2514 .. :try_end_2522} :catchall_24bf

    move-object/from16 v15, v35

    :try_start_2524
    iput-object v15, v5, Laak;->R:Lcp2;
    :try_end_2526
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2524 .. :try_end_2526} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2524 .. :try_end_2526} :catch_2659
    .catchall {:try_start_2524 .. :try_end_2526} :catchall_24bf

    move-object/from16 v35, v15

    move-object/from16 v15, v37

    :try_start_252a
    iput-object v15, v5, Laak;->S:Lpe9;

    iput-object v0, v5, Laak;->T:Lexe;

    move-object/from16 v37, v15

    const/4 v15, 0x0

    iput-object v15, v5, Laak;->U:Lcp2;

    move-object/from16 v15, p1

    iput-object v15, v5, Laak;->V:Ljava/lang/Object;

    iput-object v2, v5, Laak;->W:Long;
    :try_end_2539
    .catch Ljava/util/concurrent/CancellationException; {:try_start_252a .. :try_end_2539} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_252a .. :try_end_2539} :catch_2649
    .catchall {:try_start_252a .. :try_end_2539} :catchall_24bf

    move-object/from16 v38, v15

    move/from16 v15, v68

    :try_start_253d
    iput v15, v5, Laak;->e0:I
    :try_end_253f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_253d .. :try_end_253f} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_253d .. :try_end_253f} :catch_2639
    .catchall {:try_start_253d .. :try_end_253f} :catchall_24bf

    move/from16 v42, v15

    move/from16 v15, v67

    :try_start_2543
    iput-boolean v15, v5, Laak;->i0:Z
    :try_end_2545
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2543 .. :try_end_2545} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2543 .. :try_end_2545} :catch_262d
    .catchall {:try_start_2543 .. :try_end_2545} :catchall_24bf

    move/from16 v43, v15

    move/from16 v15, v64

    :try_start_2549
    iput v15, v5, Laak;->f0:I
    :try_end_254b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2549 .. :try_end_254b} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2549 .. :try_end_254b} :catch_2621
    .catchall {:try_start_2549 .. :try_end_254b} :catchall_24bf

    move-object/from16 v44, v14

    move/from16 v46, v15

    move-wide/from16 v14, v65

    :try_start_2551
    iput-wide v14, v5, Laak;->k0:J
    :try_end_2553
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2551 .. :try_end_2553} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2551 .. :try_end_2553} :catch_2619
    .catchall {:try_start_2551 .. :try_end_2553} :catchall_24bf

    move-wide/from16 v47, v14

    move/from16 v14, v63

    :try_start_2557
    iput v14, v5, Laak;->g0:I

    move/from16 v15, v27

    iput-boolean v15, v5, Laak;->j0:Z

    move/from16 v27, v15

    const/4 v15, 0x6

    iput v15, v5, Laak;->m0:I

    invoke-virtual {v1, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15
    :try_end_2566
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2557 .. :try_end_2566} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2557 .. :try_end_2566} :catch_25e1
    .catchall {:try_start_2557 .. :try_end_2566} :catchall_24bf

    move-object/from16 p1, v2

    move-object/from16 v2, v53

    if-ne v15, v2, :cond_256e

    goto/16 :goto_7700

    :cond_256e
    move/from16 v63, v14

    move-object/from16 v15, v35

    move/from16 v68, v42

    move/from16 v67, v43

    move-object/from16 v14, v44

    move/from16 v64, v46

    move-wide/from16 v65, v47

    move-object/from16 v47, v41

    move-object/from16 v41, v4

    move-object/from16 v4, p1

    move-object/from16 p1, v1

    :goto_2584
    :try_start_2584
    instance-of v1, v4, Lgng;

    if-eqz v1, :cond_25c3

    const/4 v1, 0x1

    iput-boolean v1, v12, Lexe;->E:Z

    goto :goto_25c3

    :catch_258c
    move-exception v0

    move-object/from16 v1, p1

    move-object/from16 v17, v9

    move-object/from16 v38, v13

    move-object/from16 v43, v14

    move-object/from16 v33, v15

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    move-object/from16 v13, v52

    move/from16 v48, v63

    move/from16 v45, v64

    move/from16 v35, v67

    move/from16 v37, v68

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v9, v6

    move-object v14, v8

    move-object v15, v10

    move-object v6, v11

    move-object/from16 v52, v41

    move-object/from16 v41, v47

    move-wide/from16 v46, v65

    goto/16 :goto_24f6

    :cond_25c3
    :goto_25c3
    instance-of v1, v4, Lzmg;

    if-eqz v1, :cond_25ca

    const/4 v1, 0x1

    iput-boolean v1, v0, Lexe;->E:Z

    :cond_25ca
    instance-of v1, v4, Lrmg;

    if-eqz v1, :cond_25d3

    if-nez v27, :cond_25d3

    const/4 v1, 0x1

    iput-boolean v1, v13, Lexe;->E:Z
    :try_end_25d3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2584 .. :try_end_25d3} :catch_24fa
    .catch Ljava/lang/Exception; {:try_start_2584 .. :try_end_25d3} :catch_258c
    .catchall {:try_start_2584 .. :try_end_25d3} :catchall_24bf

    :cond_25d3
    move-object/from16 v1, p1

    move-object/from16 v53, v2

    move-object/from16 v2, v37

    move-object/from16 p1, v38

    move-object/from16 v4, v41

    move-object/from16 v41, v47

    goto/16 :goto_24a2

    :catch_25e1
    move-exception v0

    move-object/from16 v2, v53

    :goto_25e4
    move-object/from16 v17, v9

    move-object v15, v10

    move-object/from16 v38, v13

    move-object/from16 v33, v35

    move/from16 v37, v42

    move/from16 v35, v43

    move-object/from16 v43, v44

    move-object/from16 v32, v45

    move/from16 v45, v46

    move-wide/from16 v46, v47

    move-object/from16 v13, v52

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v52, v4

    move-object v9, v6

    move-object v6, v11

    move/from16 v48, v14

    move-object/from16 v4, v40

    move-object v11, v7

    move-object v14, v8

    const/4 v7, 0x1

    move-object v8, v3

    goto/16 :goto_7437

    :catch_2619
    move-exception v0

    move-wide/from16 v47, v14

    move-object/from16 v2, v53

    move/from16 v14, v63

    goto :goto_25e4

    :catch_2621
    move-exception v0

    move-object/from16 v44, v14

    move/from16 v46, v15

    move-object/from16 v2, v53

    move/from16 v14, v63

    :goto_262a
    move-wide/from16 v47, v65

    goto :goto_25e4

    :catch_262d
    move-exception v0

    move-object/from16 v44, v14

    move/from16 v43, v15

    move-object/from16 v2, v53

    move/from16 v14, v63

    move/from16 v46, v64

    goto :goto_262a

    :catch_2639
    move-exception v0

    move-object/from16 v44, v14

    move/from16 v42, v15

    move-object/from16 v2, v53

    move/from16 v14, v63

    move/from16 v46, v64

    move-wide/from16 v47, v65

    move/from16 v43, v67

    goto :goto_25e4

    :catch_2649
    move-exception v0

    move-object/from16 v44, v14

    :goto_264c
    move-object/from16 v2, v53

    move/from16 v14, v63

    move/from16 v46, v64

    move-wide/from16 v47, v65

    move/from16 v43, v67

    move/from16 v42, v68

    goto :goto_25e4

    :catch_2659
    move-exception v0

    move-object/from16 v44, v14

    move-object/from16 v35, v15

    goto :goto_264c

    :catch_265f
    move-exception v0

    move-object/from16 v44, v14

    goto :goto_264c

    :cond_2663
    move-object/from16 v37, v2

    move-object/from16 v44, v14

    move-object/from16 v35, v15

    move-object/from16 v2, v53

    move/from16 v14, v63

    move/from16 v46, v64

    move-wide/from16 v47, v65

    move/from16 v43, v67

    move/from16 v42, v68

    :try_start_2675
    new-instance v15, Lvmg;
    :try_end_2677
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2675 .. :try_end_2677} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_2675 .. :try_end_2677} :catch_7099
    .catchall {:try_start_2675 .. :try_end_2677} :catchall_7047

    :try_start_2677
    iget-boolean v2, v11, Lexe;->E:Z
    :try_end_2679
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2677 .. :try_end_2679} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_2677 .. :try_end_2679} :catch_708f
    .catchall {:try_start_2677 .. :try_end_2679} :catchall_7047

    move/from16 v27, v14

    const/4 v14, 0x0

    :try_start_267c
    invoke-direct {v15, v2, v14}, Lvmg;-><init>(ZZ)V

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->E:Lixe;

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v7, v5, Laak;->G:Lexe;

    iput-object v8, v5, Laak;->H:Lhxe;
    :try_end_2689
    .catch Ljava/util/concurrent/CancellationException; {:try_start_267c .. :try_end_2689} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_267c .. :try_end_2689} :catch_7063
    .catchall {:try_start_267c .. :try_end_2689} :catchall_7047

    :try_start_2689
    move-object/from16 v2, v36

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v2, v41

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->J:Ljava/util/List;
    :try_end_2695
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2689 .. :try_end_2695} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_2689 .. :try_end_2695} :catch_706f
    .catchall {:try_start_2689 .. :try_end_2695} :catchall_7047

    :try_start_2695
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v9, v5, Laak;->L:Lixe;

    iput-object v11, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v4, v5, Laak;->P:Lixe;
    :try_end_26a1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2695 .. :try_end_26a1} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_2695 .. :try_end_26a1} :catch_7063
    .catchall {:try_start_2695 .. :try_end_26a1} :catchall_7047

    move-object/from16 v14, v44

    :try_start_26a3
    iput-object v14, v5, Laak;->Q:Lixe;
    :try_end_26a5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26a3 .. :try_end_26a5} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_26a3 .. :try_end_26a5} :catch_705d
    .catchall {:try_start_26a3 .. :try_end_26a5} :catchall_7047

    move-object/from16 v2, v35

    :try_start_26a7
    iput-object v2, v5, Laak;->R:Lcp2;
    :try_end_26a9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26a7 .. :try_end_26a9} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_26a7 .. :try_end_26a9} :catch_705f
    .catchall {:try_start_26a7 .. :try_end_26a9} :catchall_7047

    move-object/from16 v35, v2

    move-object/from16 v2, v37

    :try_start_26ad
    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v0, v5, Laak;->T:Lexe;

    move-object/from16 v37, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->U:Lcp2;

    iput-object v2, v5, Laak;->V:Ljava/lang/Object;

    iput-object v2, v5, Laak;->W:Long;
    :try_end_26ba
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26ad .. :try_end_26ba} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_26ad .. :try_end_26ba} :catch_705d
    .catchall {:try_start_26ad .. :try_end_26ba} :catchall_7047

    move/from16 v2, v42

    :try_start_26bc
    iput v2, v5, Laak;->e0:I
    :try_end_26be
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26bc .. :try_end_26be} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_26bc .. :try_end_26be} :catch_7059
    .catchall {:try_start_26bc .. :try_end_26be} :catchall_7047

    move/from16 v42, v2

    move/from16 v2, v43

    :try_start_26c2
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_26c4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26c2 .. :try_end_26c4} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_26c2 .. :try_end_26c4} :catch_7055
    .catchall {:try_start_26c2 .. :try_end_26c4} :catchall_7047

    move/from16 v43, v2

    move/from16 v2, v46

    :try_start_26c8
    iput v2, v5, Laak;->f0:I
    :try_end_26ca
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26c8 .. :try_end_26ca} :catch_7051
    .catch Ljava/lang/Exception; {:try_start_26c8 .. :try_end_26ca} :catch_704b
    .catchall {:try_start_26c8 .. :try_end_26ca} :catchall_7047

    move/from16 v46, v2

    move-object/from16 v38, v3

    move-wide/from16 v2, v47

    :try_start_26d0
    iput-wide v2, v5, Laak;->k0:J
    :try_end_26d2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26d0 .. :try_end_26d2} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_26d0 .. :try_end_26d2} :catch_7043
    .catchall {:try_start_26d0 .. :try_end_26d2} :catchall_6fe1

    move-wide/from16 v47, v2

    move/from16 v2, v27

    :try_start_26d6
    iput v2, v5, Laak;->g0:I
    :try_end_26d8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26d6 .. :try_end_26d8} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_26d6 .. :try_end_26d8} :catch_6fe6
    .catchall {:try_start_26d6 .. :try_end_26d8} :catchall_6fe1

    const/4 v3, 0x7

    :try_start_26d9
    iput v3, v5, Laak;->m0:I
    :try_end_26db
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26d9 .. :try_end_26db} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_26d9 .. :try_end_26db} :catch_7026
    .catchall {:try_start_26d9 .. :try_end_26db} :catchall_6fe1

    :try_start_26db
    invoke-virtual {v1, v5, v15}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_26df
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26db .. :try_end_26df} :catch_7021
    .catch Ljava/lang/Exception; {:try_start_26db .. :try_end_26df} :catch_6fe6
    .catchall {:try_start_26db .. :try_end_26df} :catchall_6fe1

    move-object/from16 v15, v53

    if-ne v3, v15, :cond_26e5

    goto/16 :goto_1fc2

    :cond_26e5
    move/from16 v69, v2

    move-object v3, v4

    move-object/from16 v44, v15

    move-object/from16 v15, v35

    move-object/from16 v4, v37

    move-object/from16 v2, v38

    move/from16 v74, v42

    move/from16 v73, v43

    move/from16 v70, v46

    move-wide/from16 v71, v47

    :goto_26f8
    :try_start_26f8
    iget-boolean v0, v0, Lexe;->E:Z
    :try_end_26fa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26f8 .. :try_end_26fa} :catch_2832
    .catch Ljava/lang/Exception; {:try_start_26f8 .. :try_end_26fa} :catch_6f9b
    .catchall {:try_start_26f8 .. :try_end_26fa} :catchall_2829

    if-nez v0, :cond_2865

    :try_start_26fc
    iget-object v0, v4, Lpe9;->c:Ljava/util/List;
    :try_end_26fe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26fc .. :try_end_26fe} :catch_2832
    .catch Ljava/lang/Exception; {:try_start_26fc .. :try_end_26fe} :catch_285d
    .catchall {:try_start_26fc .. :try_end_26fe} :catchall_2829

    move-object/from16 v27, v15

    :try_start_2700
    iget-object v15, v4, Lpe9;->a:Ljava/util/List;

    invoke-static {v0, v15}, Loml;->i(Ljava/util/List;Ljava/util/List;)Lcom/anthropic/claude/sessions/types/PermissionMode;

    move-result-object v0

    if-eqz v0, :cond_283c

    new-instance v15, Lzmg;

    invoke-direct {v15, v0}, Lzmg;-><init>(Lcom/anthropic/claude/sessions/types/PermissionMode;)V

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->E:Lixe;

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v7, v5, Laak;->G:Lexe;

    iput-object v8, v5, Laak;->H:Lhxe;
    :try_end_2717
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2700 .. :try_end_2717} :catch_2832
    .catch Ljava/lang/Exception; {:try_start_2700 .. :try_end_2717} :catch_282e
    .catchall {:try_start_2700 .. :try_end_2717} :catchall_2829

    :try_start_2717
    move-object/from16 v0, v36

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v0, v41

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->J:Ljava/util/List;
    :try_end_2723
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2717 .. :try_end_2723} :catch_2832
    .catch Ljava/lang/Exception; {:try_start_2717 .. :try_end_2723} :catch_2836
    .catchall {:try_start_2717 .. :try_end_2723} :catchall_2829

    :try_start_2723
    iput-object v10, v5, Laak;->K:Lixe;

    iput-object v9, v5, Laak;->L:Lixe;

    iput-object v11, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v3, v5, Laak;->P:Lixe;

    iput-object v14, v5, Laak;->Q:Lixe;
    :try_end_2731
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2723 .. :try_end_2731} :catch_2832
    .catch Ljava/lang/Exception; {:try_start_2723 .. :try_end_2731} :catch_282e
    .catchall {:try_start_2723 .. :try_end_2731} :catchall_2829

    move-object/from16 v35, v2

    move-object/from16 v2, v27

    :try_start_2735
    iput-object v2, v5, Laak;->R:Lcp2;

    iput-object v4, v5, Laak;->S:Lpe9;
    :try_end_2739
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2735 .. :try_end_2739} :catch_27e0
    .catch Ljava/lang/Exception; {:try_start_2735 .. :try_end_2739} :catch_2825
    .catchall {:try_start_2735 .. :try_end_2739} :catchall_27a5

    move-object/from16 v27, v2

    const/4 v2, 0x0

    :try_start_273c
    iput-object v2, v5, Laak;->T:Lexe;

    iput-object v2, v5, Laak;->U:Lcp2;
    :try_end_2740
    .catch Ljava/util/concurrent/CancellationException; {:try_start_273c .. :try_end_2740} :catch_27e0
    .catch Ljava/lang/Exception; {:try_start_273c .. :try_end_2740} :catch_2815
    .catchall {:try_start_273c .. :try_end_2740} :catchall_27a5

    move/from16 v2, v74

    :try_start_2742
    iput v2, v5, Laak;->e0:I
    :try_end_2744
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2742 .. :try_end_2744} :catch_27e0
    .catch Ljava/lang/Exception; {:try_start_2742 .. :try_end_2744} :catch_2805
    .catchall {:try_start_2742 .. :try_end_2744} :catchall_27a5

    move/from16 v37, v2

    move/from16 v2, v73

    :try_start_2748
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_274a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2748 .. :try_end_274a} :catch_27e0
    .catch Ljava/lang/Exception; {:try_start_2748 .. :try_end_274a} :catch_27f9
    .catchall {:try_start_2748 .. :try_end_274a} :catchall_27a5

    move/from16 v38, v2

    move/from16 v2, v70

    :try_start_274e
    iput v2, v5, Laak;->f0:I
    :try_end_2750
    .catch Ljava/util/concurrent/CancellationException; {:try_start_274e .. :try_end_2750} :catch_27e0
    .catch Ljava/lang/Exception; {:try_start_274e .. :try_end_2750} :catch_27ed
    .catchall {:try_start_274e .. :try_end_2750} :catchall_27a5

    move/from16 v43, v2

    move-object/from16 v42, v3

    move-wide/from16 v2, v71

    :try_start_2756
    iput-wide v2, v5, Laak;->k0:J
    :try_end_2758
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2756 .. :try_end_2758} :catch_27e0
    .catch Ljava/lang/Exception; {:try_start_2756 .. :try_end_2758} :catch_27e5
    .catchall {:try_start_2756 .. :try_end_2758} :catchall_27a5

    move-wide/from16 v46, v2

    move/from16 v2, v69

    :try_start_275c
    iput v2, v5, Laak;->g0:I

    const/16 v0, 0x8

    iput v0, v5, Laak;->m0:I

    invoke-virtual {v1, v5, v15}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_2766
    .catch Ljava/util/concurrent/CancellationException; {:try_start_275c .. :try_end_2766} :catch_27e0
    .catch Ljava/lang/Exception; {:try_start_275c .. :try_end_2766} :catch_27aa
    .catchall {:try_start_275c .. :try_end_2766} :catchall_27a5

    move-object/from16 v15, v44

    if-ne v0, v15, :cond_276c

    goto/16 :goto_1fc2

    :cond_276c
    move-object/from16 v0, v35

    move-object/from16 v35, v1

    move-object v1, v0

    move/from16 v0, v38

    move-object/from16 v38, v13

    move v13, v0

    move-object v0, v4

    move-object/from16 v4, v27

    move/from16 v3, v43

    move-object/from16 v27, v14

    move/from16 v14, v37

    move-object/from16 v37, v42

    move-wide/from16 v208, v46

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v6, v208

    :goto_2789
    move/from16 v69, v2

    move/from16 v70, v3

    move-wide/from16 v71, v6

    move/from16 v73, v13

    move/from16 v74, v14

    move-object/from16 v14, v27

    move-object/from16 v3, v37

    move-object/from16 v13, v38

    move-object/from16 v7, v46

    move-object/from16 v6, v47

    move-object v2, v1

    move-object/from16 v27, v4

    move-object/from16 v1, v35

    move-object v4, v0

    goto/16 :goto_284e

    :catchall_27a5
    move-exception v0

    :goto_27a6
    move-object/from16 v1, v35

    goto/16 :goto_772a

    :catch_27aa
    move-exception v0

    move-object/from16 v15, v44

    :goto_27ad
    move/from16 v48, v2

    move-object/from16 v17, v9

    move-object v2, v15

    move-object/from16 v33, v27

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v9, v6

    move-object v15, v10

    move-object v6, v11

    move/from16 v45, v43

    move-object v11, v7

    move-object/from16 v43, v14

    const/4 v7, 0x1

    move-object v14, v8

    move-object/from16 v8, v35

    move/from16 v35, v38

    :goto_27d8
    move-object/from16 v38, v13

    move-object/from16 v13, v52

    :goto_27dc
    move-object/from16 v52, v42

    goto/16 :goto_7437

    :catch_27e0
    move-exception v0

    :goto_27e1
    move-object/from16 v1, v35

    goto/16 :goto_7729

    :catch_27e5
    move-exception v0

    move-wide/from16 v46, v2

    move-object/from16 v15, v44

    move/from16 v2, v69

    goto :goto_27ad

    :catch_27ed
    move-exception v0

    move/from16 v43, v2

    move-object/from16 v42, v3

    move-object/from16 v15, v44

    move/from16 v2, v69

    :goto_27f6
    move-wide/from16 v46, v71

    goto :goto_27ad

    :catch_27f9
    move-exception v0

    move/from16 v38, v2

    move-object/from16 v42, v3

    move-object/from16 v15, v44

    move/from16 v2, v69

    move/from16 v43, v70

    goto :goto_27f6

    :catch_2805
    move-exception v0

    move/from16 v37, v2

    move-object/from16 v42, v3

    move-object/from16 v15, v44

    move/from16 v2, v69

    move/from16 v43, v70

    move-wide/from16 v46, v71

    move/from16 v38, v73

    goto :goto_27ad

    :catch_2815
    move-exception v0

    :goto_2816
    move-object/from16 v42, v3

    :goto_2818
    move-object/from16 v15, v44

    move/from16 v2, v69

    move/from16 v43, v70

    move-wide/from16 v46, v71

    move/from16 v38, v73

    move/from16 v37, v74

    goto :goto_27ad

    :catch_2825
    move-exception v0

    move-object/from16 v27, v2

    goto :goto_2816

    :catchall_2829
    move-exception v0

    move-object/from16 v35, v2

    goto/16 :goto_27a6

    :catch_282e
    move-exception v0

    move-object/from16 v35, v2

    goto :goto_2816

    :catch_2832
    move-exception v0

    move-object/from16 v35, v2

    goto :goto_27e1

    :catch_2836
    move-exception v0

    move-object/from16 v35, v2

    move-object/from16 v42, v3

    goto :goto_2818

    :cond_283c
    move-object/from16 v35, v2

    move-object/from16 v42, v3

    move-object/from16 v15, v44

    move/from16 v2, v69

    move/from16 v43, v70

    move-wide/from16 v46, v71

    move/from16 v38, v73

    move/from16 v37, v74

    move-object/from16 v2, v35

    :goto_284e
    move-object/from16 p1, v1

    move-object/from16 v42, v3

    move-object/from16 v1, v27

    move-object/from16 v3, v45

    move-wide/from16 v46, v71

    move/from16 v38, v73

    move/from16 v37, v74

    goto :goto_287f

    :catch_285d
    move-exception v0

    move-object/from16 v35, v2

    move-object/from16 v42, v3

    move-object/from16 v27, v15

    goto :goto_2818

    :cond_2865
    move-object/from16 v35, v2

    move-object/from16 v27, v15

    move-object/from16 v15, v44

    move/from16 v2, v69

    move/from16 v43, v70

    move-object/from16 v2, v35

    move-object/from16 v42, v3

    move-wide/from16 v46, v71

    move/from16 v38, v73

    move/from16 v37, v74

    move-object/from16 p1, v1

    move-object/from16 v1, v27

    move-object/from16 v3, v45

    :goto_287f
    :try_start_287f
    iget-object v0, v3, Lnlh;->c:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->clear()V

    invoke-virtual {v3}, Lnlh;->k()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    invoke-virtual {v3}, Lnlh;->e()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    invoke-virtual {v3}, Lnlh;->c()Lhhg;

    move-result-object v0

    invoke-virtual {v0}, Lhhg;->i()Ljava/util/LinkedHashSet;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_289e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v27
    :try_end_28a2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_287f .. :try_end_28a2} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_287f .. :try_end_28a2} :catch_6f91
    .catchall {:try_start_287f .. :try_end_28a2} :catchall_28c4

    if-eqz v27, :cond_2914

    :try_start_28a4
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v27
    :try_end_28a8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_28a4 .. :try_end_28a8} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_28a4 .. :try_end_28a8} :catch_2910
    .catchall {:try_start_28a4 .. :try_end_28a8} :catchall_28c4

    move-object/from16 v35, v6

    :try_start_28aa
    move-object/from16 v6, v27

    check-cast v6, Ljava/lang/String;
    :try_end_28ae
    .catch Ljava/util/concurrent/CancellationException; {:try_start_28aa .. :try_end_28ae} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_28aa .. :try_end_28ae} :catch_290c
    .catchall {:try_start_28aa .. :try_end_28ae} :catchall_28c4

    move-object/from16 v27, v7

    :try_start_28b0
    invoke-virtual {v3}, Lnlh;->g()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v43
    :try_end_28b8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_28b0 .. :try_end_28b8} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_28b0 .. :try_end_28b8} :catch_2908
    .catchall {:try_start_28b0 .. :try_end_28b8} :catchall_28c4

    if-nez v43, :cond_28ff

    move-object/from16 v43, v8

    :try_start_28bc
    invoke-static {}, Llab;->c()Llq4;

    move-result-object v8

    invoke-virtual {v7, v6, v8}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_28c3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_28bc .. :try_end_28c3} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_28bc .. :try_end_28c3} :catch_28c8
    .catchall {:try_start_28bc .. :try_end_28c3} :catchall_28c4

    goto :goto_2901

    :catchall_28c4
    move-exception v0

    move-object v1, v2

    goto/16 :goto_772a

    :catch_28c8
    move-exception v0

    :goto_28c9
    move-object/from16 v4, v43

    move-object/from16 v43, v14

    move-object v14, v4

    move-object/from16 v33, v1

    move-object v8, v2

    move-object/from16 v32, v3

    move-object/from16 v17, v9

    move-object v6, v11

    move-object v2, v15

    move-object/from16 v11, v27

    move-object/from16 v9, v35

    move/from16 v35, v38

    move-object/from16 v4, v40

    move/from16 v48, v69

    move/from16 v45, v70

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v1, p1

    move-object v15, v10

    goto/16 :goto_27d8

    :catch_28fb
    move-exception v0

    move-object v1, v2

    goto/16 :goto_7729

    :cond_28ff
    move-object/from16 v43, v8

    :goto_2901
    move-object/from16 v7, v27

    move-object/from16 v6, v35

    move-object/from16 v8, v43

    goto :goto_289e

    :catch_2908
    move-exception v0

    :goto_2909
    move-object/from16 v43, v8

    goto :goto_28c9

    :catch_290c
    move-exception v0

    :goto_290d
    move-object/from16 v27, v7

    goto :goto_2909

    :catch_2910
    move-exception v0

    move-object/from16 v35, v6

    goto :goto_290d

    :cond_2914
    move-object/from16 v35, v6

    move-object/from16 v27, v7

    move-object/from16 v43, v8

    const v0, 0x7fffffff

    const/4 v6, 0x6

    const/4 v7, 0x0

    :try_start_291f
    invoke-static {v0, v6, v7}, Loz4;->c(IILp42;)Ly42;

    move-result-object v0
    :try_end_2923
    .catch Ljava/util/concurrent/CancellationException; {:try_start_291f .. :try_end_2923} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_291f .. :try_end_2923} :catch_6f8b
    .catchall {:try_start_291f .. :try_end_2923} :catchall_28c4

    move-object/from16 v33, v9

    const/4 v8, -0x1

    :try_start_2926
    invoke-static {v8, v6, v7}, Loz4;->c(IILp42;)Ly42;

    move-result-object v9

    new-instance v7, Lmog;

    invoke-static/range {v52 .. v52}, Leak;->d(Leak;)Lxs9;

    move-result-object v6
    :try_end_2930
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2926 .. :try_end_2930} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2926 .. :try_end_2930} :catch_6f6d
    .catchall {:try_start_2926 .. :try_end_2930} :catchall_28c4

    :try_start_2930
    new-instance v8, Ljfh;
    :try_end_2932
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2930 .. :try_end_2932} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2930 .. :try_end_2932} :catch_6f48
    .catchall {:try_start_2930 .. :try_end_2932} :catchall_28c4

    move-object/from16 v45, v10

    move-object/from16 v48, v11

    move-object/from16 v10, v52

    const/16 v11, 0x12

    :try_start_293a
    invoke-direct {v8, v9, v11, v10}, Ljfh;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    :try_end_293d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_293a .. :try_end_293d} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_293a .. :try_end_293d} :catch_6f31
    .catchall {:try_start_293a .. :try_end_293d} :catchall_28c4

    :try_start_293d
    new-instance v11, Ljfh;
    :try_end_293f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_293d .. :try_end_293f} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_293d .. :try_end_293f} :catch_6eea
    .catchall {:try_start_293d .. :try_end_293f} :catchall_28c4

    move-object/from16 v49, v9

    const/16 v9, 0x13

    :try_start_2943
    invoke-direct {v11, v1, v9, v10}, Ljfh;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V
    :try_end_2946
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2943 .. :try_end_2946} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2943 .. :try_end_2946} :catch_6f1c
    .catchall {:try_start_2943 .. :try_end_2946} :catchall_28c4

    :try_start_2946
    invoke-direct {v7, v6, v0, v8, v11}, Lmog;-><init>(Lxs9;Ly42;La98;La98;)V

    invoke-static {v10}, Leak;->e(Leak;)Luuc;

    move-result-object v6

    invoke-virtual {v6}, Luuc;->b()Ltuc;

    move-result-object v6

    sget-object v8, Lgr6;->F:Luwa;
    :try_end_2953
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2946 .. :try_end_2953} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2946 .. :try_end_2953} :catch_6eea
    .catchall {:try_start_2946 .. :try_end_2953} :catchall_28c4

    const-wide/16 v8, 0x0

    :try_start_2955
    invoke-virtual {v6, v8, v9}, Ltuc;->c(J)V
    :try_end_2958
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2955 .. :try_end_2958} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2955 .. :try_end_2958} :catch_6efe
    .catchall {:try_start_2955 .. :try_end_2958} :catchall_28c4

    :try_start_2958
    sget-object v8, Lkr6;->I:Lkr6;

    const/16 v9, 0x1e

    invoke-static {v9, v8}, Letf;->l0(ILkr6;)J

    move-result-wide v52
    :try_end_2960
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2958 .. :try_end_2960} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2958 .. :try_end_2960} :catch_6eea
    .catchall {:try_start_2958 .. :try_end_2960} :catchall_28c4

    :try_start_2960
    invoke-static/range {v52 .. v53}, Lmck;->c(J)I

    move-result v8

    iput v8, v6, Ltuc;->A:I

    new-instance v8, Luuc;

    invoke-direct {v8, v6}, Luuc;-><init>(Ltuc;)V
    :try_end_296b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2960 .. :try_end_296b} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2960 .. :try_end_296b} :catch_6efa
    .catchall {:try_start_2960 .. :try_end_296b} :catchall_28c4

    :try_start_296b
    const-string v6, "v1/sessions/ws/%s/subscribe"

    filled-new-array/range {v51 .. v51}, [Ljava/lang/Object;

    move-result-object v11
    :try_end_2971
    .catch Ljava/util/concurrent/CancellationException; {:try_start_296b .. :try_end_2971} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_296b .. :try_end_2971} :catch_6eea
    .catchall {:try_start_296b .. :try_end_2971} :catchall_28c4

    const/4 v9, 0x1

    :try_start_2972
    invoke-static {v11, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v11
    :try_end_2976
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2972 .. :try_end_2976} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2972 .. :try_end_2976} :catch_6eee
    .catchall {:try_start_2972 .. :try_end_2976} :catchall_28c4

    :try_start_2976
    invoke-static {v6, v11}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v10}, Leak;->a(Leak;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v10}, Leak;->f(Leak;)Ljava/lang/String;

    move-result-object v11
    :try_end_2982
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2976 .. :try_end_2982} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2976 .. :try_end_2982} :catch_6eea
    .catchall {:try_start_2976 .. :try_end_2982} :catchall_28c4

    move-object/from16 v52, v1

    :try_start_2984
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "?organization_uuid="

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "&replay=false"

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v6, Ls6f;

    invoke-direct {v6}, Ls6f;-><init>()V

    invoke-virtual {v6, v1}, Ls6f;->f(Ljava/lang/String;)V
    :try_end_29a8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2984 .. :try_end_29a8} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_2984 .. :try_end_29a8} :catch_6e94
    .catchall {:try_start_2984 .. :try_end_29a8} :catchall_28c4

    :try_start_29a8
    new-instance v1, Lt6f;

    invoke-direct {v1, v6}, Lt6f;-><init>(Ls6f;)V
    :try_end_29ad
    .catch Ljava/util/concurrent/CancellationException; {:try_start_29a8 .. :try_end_29ad} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_29a8 .. :try_end_29ad} :catch_6ece
    .catchall {:try_start_29a8 .. :try_end_29ad} :catchall_28c4

    :try_start_29ad
    invoke-virtual {v8, v1, v7}, Luuc;->c(Lt6f;Lell;)Lgre;

    move-result-object v1

    iput-object v1, v7, Lmog;->i:Lgre;

    iput-object v7, v2, Lixe;->E:Ljava/lang/Object;

    iget-object v1, v10, Leak;->h:Lov5;

    invoke-interface {v1}, Lov5;->c()J

    move-result-wide v6

    const-wide/16 v8, 0x3a98

    add-long/2addr v6, v8

    iget-object v1, v4, Lpe9;->c:Ljava/util/List;
    :try_end_29c0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_29ad .. :try_end_29c0} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_29ad .. :try_end_29c0} :catch_6e94
    .catchall {:try_start_29ad .. :try_end_29c0} :catchall_28c4

    :try_start_29c0
    sget-object v4, Lhw6;->E:Lhw6;

    invoke-static {v1, v4}, Lh32;->f(Ljava/util/List;Ljava/util/Set;)Lxgf;

    move-result-object v1
    :try_end_29c6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_29c0 .. :try_end_29c6} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_29c0 .. :try_end_29c6} :catch_6ece
    .catchall {:try_start_29c0 .. :try_end_29c6} :catchall_28c4

    :try_start_29c6
    invoke-virtual {v1}, Lxgf;->iterator()Ljava/util/Iterator;

    move-result-object v1
    :try_end_29ca
    .catch Ljava/util/concurrent/CancellationException; {:try_start_29c6 .. :try_end_29ca} :catch_28fb
    .catch Ljava/lang/Exception; {:try_start_29c6 .. :try_end_29ca} :catch_6e94
    .catchall {:try_start_29c6 .. :try_end_29ca} :catchall_28c4

    move-object/from16 v58, v10

    move-object v10, v12

    move-object/from16 v59, v15

    move-object/from16 v9, v27

    move-object/from16 v8, v35

    move/from16 v80, v37

    move/from16 v79, v38

    move-object/from16 v4, v42

    move-object/from16 v11, v43

    move-object/from16 v12, v45

    move-wide/from16 v77, v46

    move/from16 v75, v69

    move/from16 v76, v70

    move-wide/from16 v37, v6

    move-object v15, v14

    move-object/from16 v14, v33

    move-object/from16 v6, p1

    move-object/from16 p1, v1

    move-object v7, v2

    move-object/from16 v2, v49

    move-object/from16 v1, v52

    move-object/from16 v49, v3

    move-object/from16 v3, v48

    :goto_29f5
    :try_start_29f5
    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v27
    :try_end_29f9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_29f5 .. :try_end_29f9} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_29f5 .. :try_end_29f9} :catch_6e75
    .catchall {:try_start_29f5 .. :try_end_29f9} :catchall_2adb

    if-eqz v27, :cond_2b4f

    :try_start_29fb
    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v27

    move-object/from16 v33, v2

    move-object/from16 v2, v27

    check-cast v2, Lcom/anthropic/claude/sessions/types/SdkControlRequestEvent;

    invoke-virtual/range {v49 .. v49}, Lnlh;->b()Lq98;

    move-result-object v27

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v7, v5, Laak;->E:Lixe;

    iput-object v8, v5, Laak;->F:Lpng;

    iput-object v9, v5, Laak;->G:Lexe;

    iput-object v11, v5, Laak;->H:Lhxe;
    :try_end_2a13
    .catch Ljava/util/concurrent/CancellationException; {:try_start_29fb .. :try_end_2a13} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_29fb .. :try_end_2a13} :catch_2b45
    .catchall {:try_start_29fb .. :try_end_2a13} :catchall_2adb

    move-object/from16 v54, v6

    :try_start_2a15
    move-object/from16 v6, v36

    check-cast v6, Ljava/util/List;

    iput-object v6, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v6, v41

    check-cast v6, Ljava/util/List;

    iput-object v6, v5, Laak;->J:Ljava/util/List;
    :try_end_2a21
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a15 .. :try_end_2a21} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a15 .. :try_end_2a21} :catch_2b3d
    .catchall {:try_start_2a15 .. :try_end_2a21} :catchall_2adb

    :try_start_2a21
    iput-object v12, v5, Laak;->K:Lixe;

    iput-object v14, v5, Laak;->L:Lixe;

    iput-object v3, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v4, v5, Laak;->P:Lixe;

    iput-object v15, v5, Laak;->Q:Lixe;

    iput-object v1, v5, Laak;->R:Lcp2;

    const/4 v6, 0x0

    iput-object v6, v5, Laak;->S:Lpe9;

    iput-object v6, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v6, v33

    iput-object v6, v5, Laak;->V:Ljava/lang/Object;
    :try_end_2a3c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a21 .. :try_end_2a3c} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a21 .. :try_end_2a3c} :catch_2b39
    .catchall {:try_start_2a21 .. :try_end_2a3c} :catchall_2adb

    move-object/from16 v33, v1

    const/4 v1, 0x0

    :try_start_2a3f
    iput-object v1, v5, Laak;->W:Long;

    move-object/from16 v1, p1

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v35, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;
    :try_end_2a4a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a3f .. :try_end_2a4a} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a3f .. :try_end_2a4a} :catch_2b26
    .catchall {:try_start_2a3f .. :try_end_2a4a} :catchall_2adb

    move/from16 v1, v80

    :try_start_2a4c
    iput v1, v5, Laak;->e0:I
    :try_end_2a4e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a4c .. :try_end_2a4e} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a4c .. :try_end_2a4e} :catch_2b13
    .catchall {:try_start_2a4c .. :try_end_2a4e} :catchall_2adb

    move/from16 v42, v1

    move/from16 v1, v79

    :try_start_2a52
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_2a54
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a52 .. :try_end_2a54} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a52 .. :try_end_2a54} :catch_2b05
    .catchall {:try_start_2a52 .. :try_end_2a54} :catchall_2adb

    move/from16 v43, v1

    move/from16 v1, v76

    :try_start_2a58
    iput v1, v5, Laak;->f0:I
    :try_end_2a5a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a58 .. :try_end_2a5a} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a58 .. :try_end_2a5a} :catch_2af7
    .catchall {:try_start_2a58 .. :try_end_2a5a} :catchall_2adb

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    move-wide/from16 v3, v77

    :try_start_2a60
    iput-wide v3, v5, Laak;->k0:J
    :try_end_2a62
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a60 .. :try_end_2a62} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a60 .. :try_end_2a62} :catch_2aed
    .catchall {:try_start_2a60 .. :try_end_2a62} :catchall_2adb

    move/from16 v46, v1

    move/from16 v1, v75

    :try_start_2a66
    iput v1, v5, Laak;->g0:I
    :try_end_2a68
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a66 .. :try_end_2a68} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a66 .. :try_end_2a68} :catch_2ae7
    .catchall {:try_start_2a66 .. :try_end_2a68} :catchall_2adb

    move-wide/from16 v47, v3

    move-wide/from16 v3, v37

    :try_start_2a6c
    iput-wide v3, v5, Laak;->l0:J
    :try_end_2a6e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a6c .. :try_end_2a6e} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a6c .. :try_end_2a6e} :catch_2ae3
    .catchall {:try_start_2a6c .. :try_end_2a6e} :catchall_2adb

    move/from16 v37, v1

    const/16 v1, 0x9

    :try_start_2a72
    iput v1, v5, Laak;->m0:I
    :try_end_2a74
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a72 .. :try_end_2a74} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a72 .. :try_end_2a74} :catch_2add
    .catchall {:try_start_2a72 .. :try_end_2a74} :catchall_2adb

    :try_start_2a74
    move-object/from16 v1, v27

    check-cast v1, Lfo;

    invoke-virtual {v1, v2, v5}, Lfo;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_2a7c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2a74 .. :try_end_2a7c} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2a74 .. :try_end_2a7c} :catch_2a9d
    .catchall {:try_start_2a74 .. :try_end_2a7c} :catchall_2adb

    move-object/from16 v2, v59

    if-ne v1, v2, :cond_2a82

    goto/16 :goto_7700

    :cond_2a82
    move-object/from16 v1, v33

    move/from16 v75, v37

    move/from16 v80, v42

    move/from16 v79, v43

    move/from16 v76, v46

    move-wide/from16 v77, v47

    move-wide/from16 v37, v3

    move-object/from16 v3, v45

    move-object/from16 v4, v53

    :goto_2a94
    move-object/from16 v59, v2

    move-object v2, v6

    move-object/from16 p1, v35

    move-object/from16 v6, v54

    goto/16 :goto_29f5

    :catch_2a9d
    move-exception v0

    goto :goto_2ade

    :goto_2a9f
    move-object v1, v7

    goto/16 :goto_772a

    :goto_2aa2
    move-object/from16 v38, v13

    move-object/from16 v17, v14

    move-object/from16 v4, v40

    move/from16 v35, v43

    move-object/from16 v6, v45

    move/from16 v45, v46

    move-wide/from16 v46, v47

    move-object/from16 v32, v49

    move-object/from16 v52, v53

    move-object/from16 v1, v54

    move-object/from16 v13, v58

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v14, v11

    move-object/from16 v43, v15

    move/from16 v48, v37

    move/from16 v37, v42

    move-object v11, v9

    move-object v15, v12

    move-object v9, v8

    move-object v12, v10

    :goto_2ad5
    move-object v8, v7

    goto/16 :goto_42e

    :goto_2ad8
    move-object v1, v7

    goto/16 :goto_7729

    :catchall_2adb
    move-exception v0

    goto :goto_2a9f

    :catch_2add
    move-exception v0

    :goto_2ade
    move-object/from16 v2, v59

    goto :goto_2aa2

    :catch_2ae1
    move-exception v0

    goto :goto_2ad8

    :catch_2ae3
    move-exception v0

    move/from16 v37, v1

    goto :goto_2ade

    :catch_2ae7
    move-exception v0

    move/from16 v37, v1

    move-wide/from16 v47, v3

    goto :goto_2ade

    :catch_2aed
    move-exception v0

    move/from16 v46, v1

    move-wide/from16 v47, v3

    move-object/from16 v2, v59

    move/from16 v37, v75

    goto :goto_2aa2

    :catch_2af7
    move-exception v0

    move/from16 v46, v1

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    move-object/from16 v2, v59

    move/from16 v37, v75

    :goto_2b02
    move-wide/from16 v47, v77

    goto :goto_2aa2

    :catch_2b05
    move-exception v0

    move/from16 v43, v1

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    move-object/from16 v2, v59

    move/from16 v37, v75

    move/from16 v46, v76

    goto :goto_2b02

    :catch_2b13
    move-exception v0

    move/from16 v42, v1

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    move-object/from16 v2, v59

    move/from16 v37, v75

    move/from16 v46, v76

    move-wide/from16 v47, v77

    move/from16 v43, v79

    goto/16 :goto_2aa2

    :catch_2b26
    move-exception v0

    :goto_2b27
    move-object/from16 v45, v3

    move-object/from16 v53, v4

    :goto_2b2b
    move-object/from16 v2, v59

    move/from16 v37, v75

    move/from16 v46, v76

    move-wide/from16 v47, v77

    move/from16 v43, v79

    move/from16 v42, v80

    goto/16 :goto_2aa2

    :catch_2b39
    move-exception v0

    move-object/from16 v33, v1

    goto :goto_2b27

    :catch_2b3d
    move-exception v0

    move-object/from16 v33, v1

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    goto :goto_2b2b

    :catch_2b45
    move-exception v0

    move-object/from16 v33, v1

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    move-object/from16 v54, v6

    goto :goto_2b2b

    :cond_2b4f
    move-object/from16 v33, v1

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    move-object/from16 v54, v6

    move-wide/from16 v3, v37

    move/from16 v37, v75

    move/from16 v46, v76

    move-wide/from16 v47, v77

    move/from16 v43, v79

    move/from16 v42, v80

    move-object v6, v2

    move-object/from16 v2, v59

    :try_start_2b66
    iget-boolean v1, v5, Laak;->s0:Z

    move/from16 v55, v1

    iget-object v1, v5, Laak;->o0:Leak;

    move-object/from16 v56, v1

    iget-object v1, v5, Laak;->r0:Ljava/lang/String;
    :try_end_2b70
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2b66 .. :try_end_2b70} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2b66 .. :try_end_2b70} :catch_6e70
    .catchall {:try_start_2b66 .. :try_end_2b70} :catchall_2adb

    move-object/from16 v57, v1

    move-object/from16 v52, v13

    :try_start_2b74
    invoke-static/range {v52 .. v57}, Laak;->n(Lexe;Lixe;Lo1e;ZLeak;Ljava/lang/String;)V
    :try_end_2b77
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2b74 .. :try_end_2b77} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2b74 .. :try_end_2b77} :catch_6e37
    .catchall {:try_start_2b74 .. :try_end_2b77} :catchall_2adb

    move-object/from16 p1, v0

    move-object/from16 v59, v2

    move-object v0, v6

    move-object/from16 v1, v33

    move/from16 v85, v37

    move/from16 v84, v42

    move/from16 v83, v43

    move-object/from16 v6, v45

    move/from16 v86, v46

    move-wide/from16 v81, v47

    move-object/from16 v13, v52

    move-object/from16 v2, v53

    move-wide/from16 v37, v3

    move-object/from16 v4, v54

    :goto_2b92
    :try_start_2b92
    new-instance v3, Lu6g;
    :try_end_2b94
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2b92 .. :try_end_2b94} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2b92 .. :try_end_2b94} :catch_6e33
    .catchall {:try_start_2b92 .. :try_end_2b94} :catchall_6c8c

    move-object/from16 v27, v1

    :try_start_2b96
    invoke-interface {v5}, La75;->getContext()Lla5;

    move-result-object v1

    invoke-direct {v3, v1}, Lu6g;-><init>(Lla5;)V

    iget-object v1, v15, Lixe;->E:Ljava/lang/Object;
    :try_end_2b9f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2b96 .. :try_end_2b9f} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2b96 .. :try_end_2b9f} :catch_6e06
    .catchall {:try_start_2b96 .. :try_end_2b9f} :catchall_6c8c

    if-nez v1, :cond_2c2d

    :try_start_2ba1
    invoke-interface {v0}, Lvre;->g()Ltfg;

    move-result-object v1
    :try_end_2ba5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2ba1 .. :try_end_2ba5} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2ba1 .. :try_end_2ba5} :catch_2c25
    .catchall {:try_start_2ba1 .. :try_end_2ba5} :catchall_2adb

    move-object/from16 v33, v15

    :try_start_2ba7
    new-instance v15, Lz9k;

    invoke-direct {v15}, Lz9k;-><init>()V

    invoke-virtual {v3, v1, v15}, Lu6g;->h(Ltfg;Lq98;)V
    :try_end_2baf
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2ba7 .. :try_end_2baf} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2ba7 .. :try_end_2baf} :catch_2c1d
    .catchall {:try_start_2ba7 .. :try_end_2baf} :catchall_2adb

    move-object/from16 v15, v58

    :try_start_2bb1
    iget-object v1, v15, Leak;->h:Lov5;

    invoke-interface {v1}, Lov5;->c()J

    move-result-wide v42
    :try_end_2bb7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2bb1 .. :try_end_2bb7} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2bb1 .. :try_end_2bb7} :catch_2c12
    .catchall {:try_start_2bb1 .. :try_end_2bb7} :catchall_2adb

    sub-long v42, v37, v42

    const-wide/16 v25, 0x0

    cmp-long v1, v42, v25

    move-object/from16 v35, v2

    if-gez v1, :cond_2bc6

    move-wide/from16 v1, v25

    :goto_2bc3
    move-object/from16 v42, v15

    goto :goto_2bc9

    :cond_2bc6
    move-wide/from16 v1, v42

    goto :goto_2bc3

    :goto_2bc9
    :try_start_2bc9
    new-instance v15, Lml;
    :try_end_2bcb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2bc9 .. :try_end_2bcb} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2bc9 .. :try_end_2bcb} :catch_2c0d
    .catchall {:try_start_2bc9 .. :try_end_2bcb} :catchall_2adb

    move-object/from16 v43, v13

    const/4 v13, 0x7

    :try_start_2bce
    invoke-direct {v15, v13}, Lml;-><init>(I)V

    invoke-static {v3, v1, v2, v15}, Lao9;->V(Lu6g;JLc98;)V
    :try_end_2bd4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2bce .. :try_end_2bd4} :catch_2ae1
    .catch Ljava/lang/Exception; {:try_start_2bce .. :try_end_2bd4} :catch_2bd6
    .catchall {:try_start_2bce .. :try_end_2bd4} :catchall_2adb

    goto/16 :goto_2c38

    :catch_2bd6
    move-exception v0

    :goto_2bd7
    move-object v1, v4

    move-object v15, v12

    move-object/from16 v17, v14

    move-wide/from16 v56, v25

    move-object/from16 v52, v35

    move-object/from16 v4, v40

    move-object/from16 v38, v43

    move-object/from16 v32, v49

    move-object/from16 v2, v59

    move-wide/from16 v46, v81

    move/from16 v35, v83

    move/from16 v37, v84

    move/from16 v48, v85

    move/from16 v45, v86

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v12, v10

    move-object v14, v11

    move/from16 v26, v13

    move-object/from16 v43, v33

    move-object/from16 v13, v42

    move-object v11, v9

    move-object/from16 v33, v27

    move-object v9, v8

    goto/16 :goto_2ad5

    :catch_2c0d
    move-exception v0

    move-object/from16 v43, v13

    const/4 v13, 0x7

    goto :goto_2bd7

    :catch_2c12
    move-exception v0

    move-object/from16 v35, v2

    move-object/from16 v43, v13

    move-object/from16 v42, v15

    :goto_2c19
    const/4 v13, 0x7

    const-wide/16 v25, 0x0

    goto :goto_2bd7

    :catch_2c1d
    move-exception v0

    move-object/from16 v35, v2

    move-object/from16 v43, v13

    :goto_2c22
    move-object/from16 v42, v58

    goto :goto_2c19

    :catch_2c25
    move-exception v0

    move-object/from16 v35, v2

    move-object/from16 v43, v13

    move-object/from16 v33, v15

    goto :goto_2c22

    :cond_2c2d
    move-object/from16 v35, v2

    move-object/from16 v43, v13

    move-object/from16 v33, v15

    move-object/from16 v42, v58

    const/4 v13, 0x7

    const-wide/16 v25, 0x0

    :goto_2c38
    :try_start_2c38
    invoke-interface/range {p1 .. p1}, Lvre;->i()Ltfg;

    move-result-object v1

    new-instance v2, Lok;
    :try_end_2c3e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c38 .. :try_end_2c3e} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c38 .. :try_end_2c3e} :catch_6dd5
    .catchall {:try_start_2c38 .. :try_end_2c3e} :catchall_6c8c

    const/16 v15, 0xf

    :try_start_2c40
    invoke-direct {v2, v15}, Lok;-><init>(I)V
    :try_end_2c43
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c40 .. :try_end_2c43} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c40 .. :try_end_2c43} :catch_6de5
    .catchall {:try_start_2c40 .. :try_end_2c43} :catchall_6c8c

    :try_start_2c43
    invoke-virtual {v3, v1, v2}, Lu6g;->h(Ltfg;Lq98;)V
    :try_end_2c46
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c43 .. :try_end_2c46} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c43 .. :try_end_2c46} :catch_6dd5
    .catchall {:try_start_2c43 .. :try_end_2c46} :catchall_6c8c

    move-object/from16 v1, v49

    :try_start_2c48
    iget-object v2, v1, Lnlh;->i:Ly42;

    invoke-virtual {v2}, Ly42;->g()Ltfg;

    move-result-object v2

    new-instance v15, Lll;
    :try_end_2c50
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c48 .. :try_end_2c50} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c48 .. :try_end_2c50} :catch_6da5
    .catchall {:try_start_2c48 .. :try_end_2c50} :catchall_6c8c

    const/16 v13, 0xe

    :try_start_2c52
    invoke-direct {v15, v13}, Lll;-><init>(I)V
    :try_end_2c55
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c52 .. :try_end_2c55} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c52 .. :try_end_2c55} :catch_6d81
    .catchall {:try_start_2c52 .. :try_end_2c55} :catchall_6c8c

    :try_start_2c55
    invoke-virtual {v3, v2, v15}, Lu6g;->h(Ltfg;Lq98;)V

    iget-object v2, v1, Lnlh;->j:Ly42;

    invoke-virtual {v2}, Ly42;->g()Ltfg;

    move-result-object v2

    new-instance v13, Lok;
    :try_end_2c60
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c55 .. :try_end_2c60} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c55 .. :try_end_2c60} :catch_6d3c
    .catchall {:try_start_2c55 .. :try_end_2c60} :catchall_6c8c

    const/16 v15, 0x10

    :try_start_2c62
    invoke-direct {v13, v15}, Lok;-><init>(I)V
    :try_end_2c65
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c62 .. :try_end_2c65} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c62 .. :try_end_2c65} :catch_6d5f
    .catchall {:try_start_2c62 .. :try_end_2c65} :catchall_6c8c

    :try_start_2c65
    invoke-virtual {v3, v2, v13}, Lu6g;->h(Ltfg;Lq98;)V

    iput-object v4, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v7, v5, Laak;->E:Lixe;

    iput-object v8, v5, Laak;->F:Lpng;

    iput-object v9, v5, Laak;->G:Lexe;

    iput-object v11, v5, Laak;->H:Lhxe;
    :try_end_2c72
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c65 .. :try_end_2c72} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c65 .. :try_end_2c72} :catch_6d3c
    .catchall {:try_start_2c65 .. :try_end_2c72} :catchall_6c8c

    :try_start_2c72
    move-object/from16 v2, v36

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v2, v41

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->J:Ljava/util/List;
    :try_end_2c7e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c72 .. :try_end_2c7e} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c72 .. :try_end_2c7e} :catch_6d40
    .catchall {:try_start_2c72 .. :try_end_2c7e} :catchall_6c8c

    :try_start_2c7e
    iput-object v12, v5, Laak;->K:Lixe;

    iput-object v14, v5, Laak;->L:Lixe;

    iput-object v6, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;
    :try_end_2c86
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c7e .. :try_end_2c86} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c7e .. :try_end_2c86} :catch_6d3c
    .catchall {:try_start_2c7e .. :try_end_2c86} :catchall_6c8c

    move-object/from16 v2, v43

    :try_start_2c88
    iput-object v2, v5, Laak;->O:Lexe;
    :try_end_2c8a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c88 .. :try_end_2c8a} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c88 .. :try_end_2c8a} :catch_6d2c
    .catchall {:try_start_2c88 .. :try_end_2c8a} :catchall_6c8c

    move-object/from16 v13, v35

    :try_start_2c8c
    iput-object v13, v5, Laak;->P:Lixe;
    :try_end_2c8e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c8c .. :try_end_2c8e} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c8c .. :try_end_2c8e} :catch_6d1e
    .catchall {:try_start_2c8c .. :try_end_2c8e} :catchall_6c8c

    move-object/from16 v15, v33

    :try_start_2c90
    iput-object v15, v5, Laak;->Q:Lixe;
    :try_end_2c92
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c90 .. :try_end_2c92} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c90 .. :try_end_2c92} :catch_6d18
    .catchall {:try_start_2c90 .. :try_end_2c92} :catchall_6c8c

    move-object/from16 v43, v2

    move-object/from16 v2, v27

    :try_start_2c96
    iput-object v2, v5, Laak;->R:Lcp2;
    :try_end_2c98
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c96 .. :try_end_2c98} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c96 .. :try_end_2c98} :catch_6d12
    .catchall {:try_start_2c96 .. :try_end_2c98} :catchall_6c8c

    move-object/from16 v27, v2

    const/4 v2, 0x0

    :try_start_2c9b
    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v2, v5, Laak;->T:Lexe;

    move-object/from16 v2, p1

    iput-object v2, v5, Laak;->U:Lcp2;

    iput-object v0, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v33, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v2, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->c0:Ljava/util/Iterator;

    iput-object v2, v5, Laak;->d0:Long;
    :try_end_2cb8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2c9b .. :try_end_2cb8} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2c9b .. :try_end_2cb8} :catch_6cfc
    .catchall {:try_start_2c9b .. :try_end_2cb8} :catchall_6c8c

    move/from16 v2, v84

    :try_start_2cba
    iput v2, v5, Laak;->e0:I
    :try_end_2cbc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2cba .. :try_end_2cbc} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2cba .. :try_end_2cbc} :catch_6ce6
    .catchall {:try_start_2cba .. :try_end_2cbc} :catchall_6c8c

    move/from16 v35, v2

    move/from16 v2, v83

    :try_start_2cc0
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_2cc2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2cc0 .. :try_end_2cc2} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2cc0 .. :try_end_2cc2} :catch_6cce
    .catchall {:try_start_2cc0 .. :try_end_2cc2} :catchall_6c8c

    move/from16 v45, v2

    move/from16 v2, v86

    :try_start_2cc6
    iput v2, v5, Laak;->f0:I
    :try_end_2cc8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2cc6 .. :try_end_2cc8} :catch_6cca
    .catch Ljava/lang/Exception; {:try_start_2cc6 .. :try_end_2cc8} :catch_6c90
    .catchall {:try_start_2cc6 .. :try_end_2cc8} :catchall_6c8c

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v6, v81

    :try_start_2cce
    iput-wide v6, v5, Laak;->k0:J
    :try_end_2cd0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2cce .. :try_end_2cd0} :catch_6c67
    .catch Ljava/lang/Exception; {:try_start_2cce .. :try_end_2cd0} :catch_6c7a
    .catchall {:try_start_2cce .. :try_end_2cd0} :catchall_6c22

    move/from16 v48, v2

    move/from16 v2, v85

    :try_start_2cd4
    iput v2, v5, Laak;->g0:I
    :try_end_2cd6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2cd4 .. :try_end_2cd6} :catch_6c67
    .catch Ljava/lang/Exception; {:try_start_2cd4 .. :try_end_2cd6} :catch_6c72
    .catchall {:try_start_2cd4 .. :try_end_2cd6} :catchall_6c22

    move-wide/from16 v52, v6

    move-wide/from16 v6, v37

    :try_start_2cda
    iput-wide v6, v5, Laak;->l0:J
    :try_end_2cdc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2cda .. :try_end_2cdc} :catch_6c67
    .catch Ljava/lang/Exception; {:try_start_2cda .. :try_end_2cdc} :catch_6c6c
    .catchall {:try_start_2cda .. :try_end_2cdc} :catchall_6c22

    move/from16 v37, v2

    const/16 v2, 0xa

    :try_start_2ce0
    iput v2, v5, Laak;->m0:I

    invoke-virtual {v3, v5}, Lu6g;->e(Lavh;)Ljava/lang/Object;

    move-result-object v2
    :try_end_2ce6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2ce0 .. :try_end_2ce6} :catch_6c67
    .catch Ljava/lang/Exception; {:try_start_2ce0 .. :try_end_2ce6} :catch_6c27
    .catchall {:try_start_2ce0 .. :try_end_2ce6} :catchall_6c22

    move-object/from16 v3, v59

    if-ne v2, v3, :cond_2ced

    :goto_2cea
    move-object v2, v3

    goto/16 :goto_7700

    :cond_2ced
    move-object/from16 v49, v1

    move-object/from16 p1, v2

    move-object/from16 v59, v3

    move-wide/from16 v87, v6

    move-object v1, v14

    move-object v3, v15

    move/from16 v92, v35

    move/from16 v93, v37

    move-object/from16 v2, v43

    move/from16 v91, v45

    move-object/from16 v7, v47

    move/from16 v94, v48

    move-wide/from16 v89, v52

    move-object v6, v4

    move-object v14, v11

    move-object v15, v12

    move-object/from16 v4, v27

    move-object/from16 v27, v0

    move-object v11, v9

    move-object v12, v10

    move-object/from16 v0, v33

    move-object v9, v8

    move-object/from16 v8, v46

    :goto_2d13
    :try_start_2d13
    move-object/from16 v10, p1

    check-cast v10, Lcig;
    :try_end_2d17
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d13 .. :try_end_2d17} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d13 .. :try_end_2d17} :catch_6bee
    .catchall {:try_start_2d13 .. :try_end_2d17} :catchall_2e20

    move-object/from16 v33, v4

    :try_start_2d19
    instance-of v4, v10, Lbig;
    :try_end_2d1b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d19 .. :try_end_2d1b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d19 .. :try_end_2d1b} :catch_6bbc
    .catchall {:try_start_2d19 .. :try_end_2d1b} :catchall_2e20

    if-eqz v4, :cond_2eb0

    :try_start_2d1d
    new-instance v4, Lhng;

    move-object/from16 p1, v10

    sget-object v10, Lzy4;->a:Lzy4;

    invoke-direct {v4, v10}, Lhng;-><init>(Lez4;)V

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_2d30
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d1d .. :try_end_2d30} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d1d .. :try_end_2d30} :catch_2e87
    .catchall {:try_start_2d1d .. :try_end_2d30} :catchall_2e20

    :try_start_2d30
    move-object/from16 v10, v36

    check-cast v10, Ljava/util/List;

    iput-object v10, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v10, v41

    check-cast v10, Ljava/util/List;

    iput-object v10, v5, Laak;->J:Ljava/util/List;
    :try_end_2d3c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d30 .. :try_end_2d3c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d30 .. :try_end_2d3c} :catch_2e9d
    .catchall {:try_start_2d30 .. :try_end_2d3c} :catchall_2e20

    :try_start_2d3c
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v2, v5, Laak;->O:Lexe;

    iput-object v13, v5, Laak;->P:Lixe;

    iput-object v3, v5, Laak;->Q:Lixe;
    :try_end_2d4a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d3c .. :try_end_2d4a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d3c .. :try_end_2d4a} :catch_2e87
    .catchall {:try_start_2d3c .. :try_end_2d4a} :catchall_2e20

    move-object/from16 v10, v33

    :try_start_2d4c
    iput-object v10, v5, Laak;->R:Lcp2;
    :try_end_2d4e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d4c .. :try_end_2d4e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d4c .. :try_end_2d4e} :catch_2e95
    .catchall {:try_start_2d4c .. :try_end_2d4e} :catchall_2e20

    move-object/from16 v33, v10

    const/4 v10, 0x0

    :try_start_2d51
    iput-object v10, v5, Laak;->S:Lpe9;

    iput-object v10, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v10, v27

    iput-object v10, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v27, v10

    const/4 v10, 0x0

    iput-object v10, v5, Laak;->W:Long;

    move-object/from16 v10, p1

    iput-object v10, v5, Laak;->X:Ljava/lang/Object;
    :try_end_2d64
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d51 .. :try_end_2d64} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d51 .. :try_end_2d64} :catch_2e87
    .catchall {:try_start_2d51 .. :try_end_2d64} :catchall_2e20

    move-object/from16 v35, v3

    move/from16 v3, v92

    :try_start_2d68
    iput v3, v5, Laak;->e0:I
    :try_end_2d6a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d68 .. :try_end_2d6a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d68 .. :try_end_2d6a} :catch_2e7b
    .catchall {:try_start_2d68 .. :try_end_2d6a} :catchall_2e20

    move/from16 v37, v3

    move/from16 v3, v91

    :try_start_2d6e
    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_2d70
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d6e .. :try_end_2d70} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d6e .. :try_end_2d70} :catch_2e6d
    .catchall {:try_start_2d6e .. :try_end_2d70} :catchall_2e20

    move/from16 v38, v3

    move/from16 v3, v94

    :try_start_2d74
    iput v3, v5, Laak;->f0:I
    :try_end_2d76
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d74 .. :try_end_2d76} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d74 .. :try_end_2d76} :catch_2e61
    .catchall {:try_start_2d74 .. :try_end_2d76} :catchall_2e20

    move-object/from16 v43, v2

    move/from16 v45, v3

    move-wide/from16 v2, v89

    :try_start_2d7c
    iput-wide v2, v5, Laak;->k0:J
    :try_end_2d7e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d7c .. :try_end_2d7e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d7c .. :try_end_2d7e} :catch_2e59
    .catchall {:try_start_2d7c .. :try_end_2d7e} :catchall_2e20

    move-wide/from16 v46, v2

    move/from16 v2, v93

    :try_start_2d82
    iput v2, v5, Laak;->g0:I
    :try_end_2d84
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d82 .. :try_end_2d84} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d82 .. :try_end_2d84} :catch_2e55
    .catchall {:try_start_2d82 .. :try_end_2d84} :catchall_2e20

    move/from16 v48, v2

    move-wide/from16 v2, v87

    :try_start_2d88
    iput-wide v2, v5, Laak;->l0:J

    move-wide/from16 v52, v2

    const/16 v2, 0xb

    iput v2, v5, Laak;->m0:I

    invoke-virtual {v6, v5, v4}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_2d94
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2d88 .. :try_end_2d94} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2d88 .. :try_end_2d94} :catch_2e24
    .catchall {:try_start_2d88 .. :try_end_2d94} :catchall_2e20

    move-object/from16 v3, v59

    if-ne v2, v3, :cond_2d9a

    goto/16 :goto_2cea

    :cond_2d9a
    move-object v2, v7

    move-object v4, v8

    move-object v7, v13

    move/from16 v84, v37

    move/from16 v83, v38

    move/from16 v86, v45

    move-wide/from16 v81, v46

    move/from16 v85, v48

    move-wide/from16 v37, v52

    move-object/from16 v45, v1

    move-object v8, v6

    move-object v13, v11

    move-object/from16 v46, v15

    move-object/from16 v1, v33

    move-object/from16 v15, v35

    move-object/from16 v6, v43

    move-object/from16 v43, v12

    move-object v12, v9

    :goto_2db8
    :try_start_2db8
    check-cast v10, Lbig;

    invoke-virtual {v10}, Lbig;->a()J

    move-result-wide v9

    new-instance v11, Ljava/lang/Long;

    invoke-direct {v11, v9, v10}, Ljava/lang/Long;-><init>(J)V

    iput-object v11, v15, Lixe;->E:Ljava/lang/Object;

    iget-boolean v9, v5, Laak;->s0:Z

    iget-object v10, v5, Laak;->o0:Leak;

    iget-object v11, v5, Laak;->r0:Ljava/lang/String;

    invoke-static/range {v6 .. v11}, Laak;->n(Lexe;Lixe;Lo1e;ZLeak;Ljava/lang/String;)V
    :try_end_2dce
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2db8 .. :try_end_2dce} :catch_1efa
    .catch Ljava/lang/Exception; {:try_start_2db8 .. :try_end_2dce} :catch_2de6
    .catchall {:try_start_2db8 .. :try_end_2dce} :catchall_1eb0

    move-object/from16 p1, v0

    move-object/from16 v59, v3

    move-object v9, v13

    move-object v11, v14

    move-object/from16 v0, v27

    move-object/from16 v58, v42

    move-object/from16 v10, v43

    move-object/from16 v14, v45

    move-object v13, v6

    move-object v6, v2

    move-object v2, v7

    move-object v7, v4

    move-object v4, v8

    move-object v8, v12

    move-object/from16 v12, v46

    goto/16 :goto_2b92

    :catch_2de6
    move-exception v0

    move-object/from16 v33, v1

    move-object/from16 v38, v6

    move-object/from16 v52, v7

    move-object v1, v8

    move-object v9, v12

    move-object v11, v13

    move-wide/from16 v56, v25

    move-object/from16 v13, v42

    move-object/from16 v12, v43

    move-object/from16 v17, v45

    move-object/from16 v32, v49

    move/from16 v35, v83

    move/from16 v37, v84

    move/from16 v48, v85

    move/from16 v45, v86

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v6, v2

    move-object v2, v3

    move-object v8, v4

    move-object/from16 v43, v15

    move-object/from16 v4, v40

    move-object/from16 v15, v46

    move-wide/from16 v46, v81

    goto/16 :goto_7437

    :catchall_2e20
    move-exception v0

    move-object v1, v8

    goto/16 :goto_772a

    :catch_2e24
    move-exception v0

    :goto_2e25
    move-object/from16 v3, v59

    :goto_2e27
    move-object/from16 v2, v43

    :goto_2e29
    move-object/from16 v43, v35

    move/from16 v35, v38

    move-object/from16 v38, v2

    move-object/from16 v17, v1

    move-object v2, v3

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v52, v13

    move-wide/from16 v56, v25

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-object/from16 v32, v49

    :goto_2e3e
    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    goto/16 :goto_7437

    :catch_2e51
    move-exception v0

    move-object v1, v8

    goto/16 :goto_7729

    :catch_2e55
    move-exception v0

    move/from16 v48, v2

    goto :goto_2e25

    :catch_2e59
    move-exception v0

    move-wide/from16 v46, v2

    move-object/from16 v3, v59

    move/from16 v48, v93

    goto :goto_2e27

    :catch_2e61
    move-exception v0

    move-object/from16 v43, v2

    move/from16 v45, v3

    move-object/from16 v3, v59

    move-wide/from16 v46, v89

    move/from16 v48, v93

    goto :goto_2e29

    :catch_2e6d
    move-exception v0

    move-object/from16 v43, v2

    move/from16 v38, v3

    move-object/from16 v3, v59

    move-wide/from16 v46, v89

    :goto_2e76
    move/from16 v48, v93

    move/from16 v45, v94

    goto :goto_2e29

    :catch_2e7b
    move-exception v0

    move-object/from16 v43, v2

    move/from16 v37, v3

    move-object/from16 v3, v59

    move-wide/from16 v46, v89

    move/from16 v38, v91

    goto :goto_2e76

    :catch_2e87
    move-exception v0

    move-object/from16 v43, v2

    move-object/from16 v35, v3

    :goto_2e8c
    move-object/from16 v3, v59

    move-wide/from16 v46, v89

    move/from16 v38, v91

    move/from16 v37, v92

    goto :goto_2e76

    :catch_2e95
    move-exception v0

    move-object/from16 v43, v2

    move-object/from16 v35, v3

    move-object/from16 v33, v10

    goto :goto_2e8c

    :catch_2e9d
    move-exception v0

    move-object/from16 v43, v2

    move-object/from16 v35, v3

    move-object/from16 v3, v59

    move-wide/from16 v46, v89

    move/from16 v38, v91

    move/from16 v37, v92

    move/from16 v48, v93

    move/from16 v45, v94

    goto/16 :goto_2e27

    :cond_2eb0
    move-object/from16 v43, v2

    move-object/from16 v35, v3

    move-object/from16 v3, v59

    move-wide/from16 v52, v87

    move-wide/from16 v46, v89

    move/from16 v38, v91

    move/from16 v37, v92

    move/from16 v48, v93

    move/from16 v45, v94

    :try_start_2ec2
    sget-object v2, Lwhg;->a:Lwhg;

    invoke-static {v10, v2}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2
    :try_end_2ec8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2ec2 .. :try_end_2ec8} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2ec2 .. :try_end_2ec8} :catch_6bab
    .catchall {:try_start_2ec2 .. :try_end_2ec8} :catchall_2e20

    if-eqz v2, :cond_2f73

    :try_start_2eca
    sget-object v0, Lmta;->a:Llta;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Llta;->b()Z

    move-result v0

    if-nez v0, :cond_2edb

    move-object/from16 v59, v3

    move-object/from16 v3, v40

    goto/16 :goto_2f5b

    :cond_2edb
    invoke-static {v6}, Lp8;->I(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Llta;->a()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v2

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2eec
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2f34

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    move-object/from16 v27, v10

    check-cast v27, Lmta;

    move-object/from16 p1, v2

    move-object/from16 v2, v27

    check-cast v2, Ls40;
    :try_end_2f00
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2eca .. :try_end_2f00} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2eca .. :try_end_2f00} :catch_2f2e
    .catchall {:try_start_2eca .. :try_end_2f00} :catchall_2e20

    move-object/from16 v59, v3

    move-object/from16 v3, v40

    :try_start_2f04
    invoke-virtual {v2, v3, v0}, Ls40;->a(Lfta;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2f0d

    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2f0d
    move-object/from16 v2, p1

    move-object/from16 v40, v3

    move-object/from16 v3, v59

    goto :goto_2eec

    :catch_2f14
    move-exception v0

    :goto_2f15
    move-object/from16 v2, v43

    move-object/from16 v43, v35

    move/from16 v35, v38

    move-object/from16 v38, v2

    move-object/from16 v17, v1

    move-object v4, v3

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v52, v13

    move-wide/from16 v56, v25

    move-object/from16 v13, v42

    move-object/from16 v32, v49

    move-object/from16 v2, v59

    goto/16 :goto_2e3e

    :catch_2f2e
    move-exception v0

    move-object/from16 v59, v3

    move-object/from16 v3, v40

    goto :goto_2f15

    :cond_2f34
    move-object/from16 v59, v3

    move-object/from16 v3, v40

    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2f5b

    sget-object v2, Lmta;->a:Llta;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "WS handshake timed out after 15000ms; reconnecting"

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2f49
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2f5b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lmta;

    check-cast v10, Ls40;

    invoke-virtual {v10, v3, v0, v2}, Ls40;->b(Lfta;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2f49

    :cond_2f5b
    :goto_2f5b
    iget-object v0, v8, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lmog;

    if-eqz v0, :cond_2f64

    invoke-virtual {v0}, Lmog;->r()V
    :try_end_2f64
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2f04 .. :try_end_2f64} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2f04 .. :try_end_2f64} :catch_2f14
    .catchall {:try_start_2f04 .. :try_end_2f64} :catchall_2e20

    :cond_2f64
    move-object/from16 v40, v3

    move-object v10, v12

    move-object/from16 v52, v35

    move-object/from16 v4, v43

    move/from16 v3, v48

    move-object/from16 v2, v59

    move-object/from16 v35, v13

    goto/16 :goto_3324

    :cond_2f73
    move-object/from16 v59, v3

    move-object/from16 v3, v40

    :try_start_2f77
    instance-of v2, v10, Laig;
    :try_end_2f79
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2f77 .. :try_end_2f79} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2f77 .. :try_end_2f79} :catch_6b7d
    .catchall {:try_start_2f77 .. :try_end_2f79} :catchall_2e20

    if-eqz v2, :cond_5250

    :try_start_2f7b
    move-object v2, v10

    check-cast v2, Laig;

    invoke-virtual {v2}, Laig;->a()Lcom/anthropic/claude/sessions/types/SdkEvent;

    move-result-object v2
    :try_end_2f82
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2f7b .. :try_end_2f82} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2f7b .. :try_end_2f82} :catch_5224
    .catchall {:try_start_2f7b .. :try_end_2f82} :catchall_2e20

    if-nez v2, :cond_3372

    :try_start_2f84
    move-object v0, v10

    check-cast v0, Laig;

    iget-object v0, v0, Laig;->b:Ljava/lang/Throwable;

    instance-of v2, v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketClosedException;
    :try_end_2f8b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2f84 .. :try_end_2f8b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2f84 .. :try_end_2f8b} :catch_335e
    .catchall {:try_start_2f84 .. :try_end_2f8b} :catchall_2e20

    if-eqz v2, :cond_2f90

    :try_start_2f8d
    check-cast v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketClosedException;

    goto :goto_2f91

    :cond_2f90
    const/4 v0, 0x0

    :goto_2f91
    if-eqz v0, :cond_2fa5

    sget-object v2, Lpt6;->F:Li14;

    iget v4, v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketClosedException;->E:I

    iget-object v0, v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketClosedException;->F:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x3f0

    if-ne v4, v2, :cond_2fa5

    invoke-static {v0}, Li14;->v(Ljava/lang/String;)Lpt6;

    move-result-object v0
    :try_end_2fa4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2f8d .. :try_end_2fa4} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2f8d .. :try_end_2fa4} :catch_2f14
    .catchall {:try_start_2f8d .. :try_end_2fa4} :catchall_2e20

    goto :goto_2fa6

    :cond_2fa5
    const/4 v0, 0x0

    :goto_2fa6
    if-eqz v0, :cond_30b8

    :try_start_2fa8
    new-instance v2, Lumg;

    invoke-direct {v2, v0}, Lumg;-><init>(Lpt6;)V

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_2fb7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2fa8 .. :try_end_2fb7} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2fa8 .. :try_end_2fb7} :catch_30a0
    .catchall {:try_start_2fa8 .. :try_end_2fb7} :catchall_2e20

    :try_start_2fb7
    move-object/from16 v0, v36

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v0, v41

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->J:Ljava/util/List;
    :try_end_2fc3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2fb7 .. :try_end_2fc3} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2fb7 .. :try_end_2fc3} :catch_30ac
    .catchall {:try_start_2fb7 .. :try_end_2fc3} :catchall_2e20

    :try_start_2fc3
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;
    :try_end_2fcb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2fc3 .. :try_end_2fcb} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2fc3 .. :try_end_2fcb} :catch_30a0
    .catchall {:try_start_2fc3 .. :try_end_2fcb} :catchall_2e20

    move-object/from16 v4, v43

    :try_start_2fcd
    iput-object v4, v5, Laak;->O:Lexe;

    iput-object v13, v5, Laak;->P:Lixe;
    :try_end_2fd1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2fcd .. :try_end_2fd1} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2fcd .. :try_end_2fd1} :catch_3096
    .catchall {:try_start_2fcd .. :try_end_2fd1} :catchall_2e20

    move-object/from16 v10, v35

    :try_start_2fd3
    iput-object v10, v5, Laak;->Q:Lixe;
    :try_end_2fd5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2fd3 .. :try_end_2fd5} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2fd3 .. :try_end_2fd5} :catch_309c
    .catchall {:try_start_2fd3 .. :try_end_2fd5} :catchall_2e20

    move-object/from16 v35, v10

    move-object/from16 v10, v33

    :try_start_2fd9
    iput-object v10, v5, Laak;->R:Lcp2;
    :try_end_2fdb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2fd9 .. :try_end_2fdb} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2fd9 .. :try_end_2fdb} :catch_3098
    .catchall {:try_start_2fd9 .. :try_end_2fdb} :catchall_2e20

    move-object/from16 v33, v10

    const/4 v10, 0x0

    :try_start_2fde
    iput-object v10, v5, Laak;->S:Lpe9;

    iput-object v10, v5, Laak;->T:Lexe;

    iput-object v10, v5, Laak;->U:Lcp2;

    iput-object v10, v5, Laak;->V:Ljava/lang/Object;

    iput-object v10, v5, Laak;->W:Long;

    iput-object v10, v5, Laak;->X:Ljava/lang/Object;

    iput-object v10, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v10, v5, Laak;->Z:Ljava/lang/Object;
    :try_end_2fee
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2fde .. :try_end_2fee} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2fde .. :try_end_2fee} :catch_3096
    .catchall {:try_start_2fde .. :try_end_2fee} :catchall_2e20

    move/from16 v10, v37

    :try_start_2ff0
    iput v10, v5, Laak;->e0:I
    :try_end_2ff2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2ff0 .. :try_end_2ff2} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2ff0 .. :try_end_2ff2} :catch_3092
    .catchall {:try_start_2ff0 .. :try_end_2ff2} :catchall_2e20

    move/from16 v37, v10

    move/from16 v10, v38

    :try_start_2ff6
    iput-boolean v10, v5, Laak;->i0:Z
    :try_end_2ff8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2ff6 .. :try_end_2ff8} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2ff6 .. :try_end_2ff8} :catch_3082
    .catchall {:try_start_2ff6 .. :try_end_2ff8} :catchall_2e20

    move/from16 v38, v10

    move/from16 v10, v45

    :try_start_2ffc
    iput v10, v5, Laak;->f0:I
    :try_end_2ffe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2ffc .. :try_end_2ffe} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_2ffc .. :try_end_2ffe} :catch_306e
    .catchall {:try_start_2ffc .. :try_end_2ffe} :catchall_2e20

    move-object/from16 v43, v12

    move-object/from16 v40, v13

    move-wide/from16 v12, v46

    :try_start_3004
    iput-wide v12, v5, Laak;->k0:J
    :try_end_3006
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3004 .. :try_end_3006} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3004 .. :try_end_3006} :catch_306a
    .catchall {:try_start_3004 .. :try_end_3006} :catchall_2e20

    move-wide/from16 v46, v12

    move/from16 v12, v48

    :try_start_300a
    iput v12, v5, Laak;->g0:I
    :try_end_300c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_300a .. :try_end_300c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_300a .. :try_end_300c} :catch_3066
    .catchall {:try_start_300a .. :try_end_300c} :catchall_2e20

    move/from16 v48, v12

    move-wide/from16 v12, v52

    :try_start_3010
    iput-wide v12, v5, Laak;->l0:J

    const/16 v0, 0xc

    iput v0, v5, Laak;->m0:I

    invoke-virtual {v6, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_301a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3010 .. :try_end_301a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3010 .. :try_end_301a} :catch_3039
    .catchall {:try_start_3010 .. :try_end_301a} :catchall_2e20

    move-object/from16 v2, v59

    if-ne v0, v2, :cond_3020

    goto/16 :goto_7700

    :cond_3020
    move-object/from16 v35, v6

    move-object v1, v8

    move v3, v10

    move/from16 v9, v37

    move/from16 v8, v38

    move-wide/from16 v6, v46

    :goto_302a
    iget-object v0, v1, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lmog;

    if-eqz v0, :cond_3033

    invoke-virtual {v0}, Lmog;->s()V

    :cond_3033
    move-object/from16 v0, v35

    move/from16 v4, v48

    goto/16 :goto_759b

    :catch_3039
    move-exception v0

    :goto_303a
    move-object/from16 v2, v59

    :goto_303c
    move-object/from16 v17, v1

    move-object v1, v6

    move-object v6, v7

    move/from16 v45, v10

    move-wide/from16 v56, v25

    move-object/from16 v52, v40

    move-object/from16 v13, v42

    move-object/from16 v12, v43

    :goto_304a
    move-object/from16 v32, v49

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v43, v35

    move/from16 v35, v38

    move-object/from16 v38, v4

    :goto_3063
    move-object v4, v3

    goto/16 :goto_7437

    :catch_3066
    move-exception v0

    move/from16 v48, v12

    goto :goto_303a

    :catch_306a
    move-exception v0

    move-wide/from16 v46, v12

    goto :goto_303a

    :catch_306e
    move-exception v0

    move-object/from16 v43, v12

    move-object/from16 v40, v13

    move-object/from16 v2, v59

    move-object/from16 v17, v1

    move-object v1, v6

    move-object v6, v7

    move/from16 v45, v10

    :goto_307b
    move-wide/from16 v56, v25

    move-object/from16 v52, v40

    move-object/from16 v13, v42

    goto :goto_304a

    :catch_3082
    move-exception v0

    move/from16 v38, v10

    :goto_3085
    move-object/from16 v43, v12

    move-object/from16 v40, v13

    move/from16 v10, v45

    move-object/from16 v2, v59

    :goto_308d
    move-object/from16 v17, v1

    move-object v1, v6

    move-object v6, v7

    goto :goto_307b

    :catch_3092
    move-exception v0

    move/from16 v37, v10

    goto :goto_3085

    :catch_3096
    move-exception v0

    goto :goto_3085

    :catch_3098
    move-exception v0

    move-object/from16 v33, v10

    goto :goto_3085

    :catch_309c
    move-exception v0

    move-object/from16 v35, v10

    goto :goto_3085

    :catch_30a0
    move-exception v0

    move-object/from16 v40, v13

    move-object/from16 v4, v43

    move/from16 v10, v45

    move-object/from16 v2, v59

    move-object/from16 v43, v12

    goto :goto_308d

    :catch_30ac
    move-exception v0

    move-object/from16 v40, v13

    move-object/from16 v4, v43

    move/from16 v10, v45

    move-object/from16 v2, v59

    move-object/from16 v43, v12

    goto :goto_303c

    :cond_30b8
    move-object v0, v10

    move-object/from16 v40, v13

    move-object/from16 v2, v35

    move-object/from16 v4, v43

    move/from16 v10, v45

    move-object/from16 v43, v12

    move-wide/from16 v12, v52

    move-object/from16 v53, v59

    :try_start_30c7
    check-cast v0, Laig;

    iget-object v0, v0, Laig;->b:Ljava/lang/Throwable;

    move-wide/from16 v54, v12

    instance-of v12, v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketUpgradeFailedException;
    :try_end_30cf
    .catch Ljava/util/concurrent/CancellationException; {:try_start_30c7 .. :try_end_30cf} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_30c7 .. :try_end_30cf} :catch_330a
    .catchall {:try_start_30c7 .. :try_end_30cf} :catchall_2e20

    if-eqz v12, :cond_3100

    :try_start_30d1
    check-cast v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketUpgradeFailedException;
    :try_end_30d3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_30d1 .. :try_end_30d3} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_30d1 .. :try_end_30d3} :catch_30d4
    .catchall {:try_start_30d1 .. :try_end_30d3} :catchall_2e20

    goto :goto_3101

    :catch_30d4
    move-exception v0

    move-object/from16 v17, v1

    move-object v1, v6

    move-object v6, v7

    move/from16 v45, v10

    move-wide/from16 v56, v25

    move/from16 v35, v38

    move-object/from16 v52, v40

    move-object/from16 v13, v42

    move-object/from16 v12, v43

    move-object/from16 v32, v49

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v43, v2

    move-object/from16 v38, v4

    move-object/from16 v2, v53

    goto/16 :goto_3063

    :cond_3100
    const/4 v0, 0x0

    :goto_3101
    if-eqz v0, :cond_3316

    :try_start_3103
    invoke-static/range {v42 .. v42}, Leak;->b(Leak;)Lpt3;

    move-result-object v12

    invoke-static {v0, v12}, Lnok;->e(Lcom/anthropic/claude/sessions/api/SessionWebSocketUpgradeFailedException;Lpt3;)Lhak;

    move-result-object v12

    instance-of v13, v12, Lgak;

    if-eqz v13, :cond_3316

    sget-object v13, Lmta;->a:Llta;
    :try_end_3111
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3103 .. :try_end_3111} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3103 .. :try_end_3111} :catch_330a
    .catchall {:try_start_3103 .. :try_end_3111} :catchall_2e20

    :try_start_3111
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Llta;->b()Z

    move-result v13
    :try_end_3118
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3111 .. :try_end_3118} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3111 .. :try_end_3118} :catch_3310
    .catchall {:try_start_3111 .. :try_end_3118} :catchall_2e20

    if-nez v13, :cond_3122

    move-object/from16 v52, v2

    move/from16 v45, v10

    move-object/from16 p1, v12

    goto/16 :goto_31db

    :cond_3122
    :try_start_3122
    invoke-static {v6}, Lp8;->I(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-static {}, Llta;->a()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v27

    move-object/from16 p1, v12

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual/range {v27 .. v27}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v27

    :goto_3135
    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->hasNext()Z

    move-result v35
    :try_end_3139
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3122 .. :try_end_3139} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3122 .. :try_end_3139} :catch_330a
    .catchall {:try_start_3122 .. :try_end_3139} :catchall_2e20

    if-eqz v35, :cond_3187

    move/from16 v45, v10

    :try_start_313d
    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    move-object/from16 v35, v10

    check-cast v35, Lmta;
    :try_end_3145
    .catch Ljava/util/concurrent/CancellationException; {:try_start_313d .. :try_end_3145} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_313d .. :try_end_3145} :catch_3183
    .catchall {:try_start_313d .. :try_end_3145} :catchall_2e20

    move-object/from16 v52, v2

    :try_start_3147
    move-object/from16 v2, v35

    check-cast v2, Ls40;

    invoke-virtual {v2, v3, v13}, Ls40;->a(Lfta;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_3154

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_3154
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3147 .. :try_end_3154} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3147 .. :try_end_3154} :catch_3159
    .catchall {:try_start_3147 .. :try_end_3154} :catchall_2e20

    :cond_3154
    move/from16 v10, v45

    move-object/from16 v2, v52

    goto :goto_3135

    :catch_3159
    move-exception v0

    :goto_315a
    move-object/from16 v17, v1

    move-object v1, v6

    move-object v6, v7

    move-wide/from16 v56, v25

    move/from16 v35, v38

    move-object/from16 v13, v42

    move-object/from16 v12, v43

    move-object/from16 v32, v49

    move-object/from16 v43, v52

    move-object/from16 v2, v53

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v38, v4

    move-object/from16 v52, v40

    goto/16 :goto_3063

    :catch_3183
    move-exception v0

    move-object/from16 v52, v2

    goto :goto_315a

    :cond_3187
    move-object/from16 v52, v2

    move/from16 v45, v10

    :try_start_318b
    invoke-virtual {v12}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2
    :try_end_318f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_318b .. :try_end_318f} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_318b .. :try_end_318f} :catch_32f8
    .catchall {:try_start_318b .. :try_end_318f} :catchall_2e20

    if-nez v2, :cond_31db

    :try_start_3191
    sget-object v2, Lmta;->a:Llta;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v0, v0, Lcom/anthropic/claude/sessions/api/SessionWebSocketUpgradeFailedException;->E:I

    move-object/from16 v2, p1

    check-cast v2, Lgak;

    iget-object v2, v2, Lgak;->a:Lot3;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-static {v2}, Loze;->a(Ljava/lang/Class;)Lky9;

    move-result-object v2

    invoke-interface {v2}, Lky9;->f()Ljava/lang/String;

    move-result-object v2

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v27, v12

    const-string v12, "WS upgrade rejected terminally: http="

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_31c9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_31db

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lmta;

    check-cast v10, Ls40;

    invoke-virtual {v10, v3, v13, v0}, Ls40;->b(Lfta;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_31da
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3191 .. :try_end_31da} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3191 .. :try_end_31da} :catch_3159
    .catchall {:try_start_3191 .. :try_end_31da} :catchall_2e20

    goto :goto_31c9

    :cond_31db
    :goto_31db
    :try_start_31db
    new-instance v0, Lcom/anthropic/claude/sessions/api/WsUpgradeRejectedException;

    move-object/from16 v12, p1

    check-cast v12, Lgak;

    iget-object v2, v12, Lgak;->a:Lot3;

    invoke-direct {v0, v2}, Lcom/anthropic/claude/sessions/api/WsUpgradeRejectedException;-><init>(Lot3;)V

    sget-object v2, Ll0i;->a:Ljava/util/List;

    const-string v57, "sessions/ws terminal upgrade rejection"

    sget-object v58, Lhsg;->F:Lhsg;

    const/16 v60, 0x0

    const/16 v61, 0x38

    const/16 v59, 0x0

    move-object/from16 v56, v0

    invoke-static/range {v56 .. v61}, Ll0i;->f(Ljava/lang/Throwable;Ljava/lang/String;Lhsg;Ljava/util/Map;Ljava/util/List;I)V

    new-instance v2, Lhng;

    new-instance v10, Lcz4;

    invoke-direct {v10, v0}, Lcz4;-><init>(Ljava/lang/Exception;)V

    invoke-direct {v2, v10}, Lhng;-><init>(Lez4;)V

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_320b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_31db .. :try_end_320b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_31db .. :try_end_320b} :catch_32f8
    .catchall {:try_start_31db .. :try_end_320b} :catchall_2e20

    :try_start_320b
    move-object/from16 v0, v36

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v0, v41

    check-cast v0, Ljava/util/List;

    iput-object v0, v5, Laak;->J:Ljava/util/List;
    :try_end_3217
    .catch Ljava/util/concurrent/CancellationException; {:try_start_320b .. :try_end_3217} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_320b .. :try_end_3217} :catch_32fe
    .catchall {:try_start_320b .. :try_end_3217} :catchall_2e20

    :try_start_3217
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;
    :try_end_321d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3217 .. :try_end_321d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3217 .. :try_end_321d} :catch_32f8
    .catchall {:try_start_3217 .. :try_end_321d} :catchall_2e20

    move-object/from16 v10, v43

    :try_start_321f
    iput-object v10, v5, Laak;->N:Lexe;

    iput-object v4, v5, Laak;->O:Lexe;
    :try_end_3223
    .catch Ljava/util/concurrent/CancellationException; {:try_start_321f .. :try_end_3223} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_321f .. :try_end_3223} :catch_32ee
    .catchall {:try_start_321f .. :try_end_3223} :catchall_2e20

    move-object/from16 v13, v40

    :try_start_3225
    iput-object v13, v5, Laak;->P:Lixe;
    :try_end_3227
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3225 .. :try_end_3227} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3225 .. :try_end_3227} :catch_32ea
    .catchall {:try_start_3225 .. :try_end_3227} :catchall_2e20

    move-object/from16 v12, v52

    :try_start_3229
    iput-object v12, v5, Laak;->Q:Lixe;
    :try_end_322b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3229 .. :try_end_322b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3229 .. :try_end_322b} :catch_32e6
    .catchall {:try_start_3229 .. :try_end_322b} :catchall_2e20

    move-object/from16 v40, v3

    move-object/from16 v3, v33

    :try_start_322f
    iput-object v3, v5, Laak;->R:Lcp2;
    :try_end_3231
    .catch Ljava/util/concurrent/CancellationException; {:try_start_322f .. :try_end_3231} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_322f .. :try_end_3231} :catch_32e2
    .catchall {:try_start_322f .. :try_end_3231} :catchall_2e20

    move-object/from16 v33, v3

    const/4 v3, 0x0

    :try_start_3234
    iput-object v3, v5, Laak;->S:Lpe9;

    iput-object v3, v5, Laak;->T:Lexe;

    iput-object v3, v5, Laak;->U:Lcp2;

    iput-object v3, v5, Laak;->V:Ljava/lang/Object;

    iput-object v3, v5, Laak;->W:Long;

    iput-object v3, v5, Laak;->X:Ljava/lang/Object;

    iput-object v3, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v3, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v3, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_324a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3234 .. :try_end_324a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3234 .. :try_end_324a} :catch_32e0
    .catchall {:try_start_3234 .. :try_end_324a} :catchall_2e20

    move/from16 v3, v37

    :try_start_324c
    iput v3, v5, Laak;->e0:I
    :try_end_324e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_324c .. :try_end_324e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_324c .. :try_end_324e} :catch_32dc
    .catchall {:try_start_324c .. :try_end_324e} :catchall_2e20

    move/from16 v37, v3

    move/from16 v3, v38

    :try_start_3252
    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_3254
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3252 .. :try_end_3254} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3252 .. :try_end_3254} :catch_32d8
    .catchall {:try_start_3252 .. :try_end_3254} :catchall_2e20

    move/from16 v38, v3

    move/from16 v3, v45

    :try_start_3258
    iput v3, v5, Laak;->f0:I
    :try_end_325a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3258 .. :try_end_325a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3258 .. :try_end_325a} :catch_32d0
    .catchall {:try_start_3258 .. :try_end_325a} :catchall_2e20

    move-object/from16 v52, v12

    move-object/from16 v35, v13

    move-wide/from16 v12, v46

    :try_start_3260
    iput-wide v12, v5, Laak;->k0:J
    :try_end_3262
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3260 .. :try_end_3262} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3260 .. :try_end_3262} :catch_32c4
    .catchall {:try_start_3260 .. :try_end_3262} :catchall_2e20

    move/from16 v45, v3

    move/from16 v3, v48

    :try_start_3266
    iput v3, v5, Laak;->g0:I
    :try_end_3268
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3266 .. :try_end_3268} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3266 .. :try_end_3268} :catch_32c0
    .catchall {:try_start_3266 .. :try_end_3268} :catchall_2e20

    move-wide/from16 v46, v12

    move-wide/from16 v12, v54

    :try_start_326c
    iput-wide v12, v5, Laak;->l0:J

    const/16 v0, 0xd

    iput v0, v5, Laak;->m0:I

    invoke-virtual {v6, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_3276
    .catch Ljava/util/concurrent/CancellationException; {:try_start_326c .. :try_end_3276} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_326c .. :try_end_3276} :catch_3295
    .catchall {:try_start_326c .. :try_end_3276} :catchall_2e20

    move-object/from16 v2, v53

    if-ne v0, v2, :cond_327c

    goto/16 :goto_7700

    :cond_327c
    move-object/from16 v35, v6

    move-object v1, v8

    move/from16 v9, v37

    move/from16 v8, v38

    move-wide/from16 v6, v46

    :goto_3285
    iget-object v0, v1, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lmog;

    if-eqz v0, :cond_328e

    invoke-virtual {v0}, Lmog;->s()V

    :cond_328e
    move v4, v3

    move-object/from16 v0, v35

    move/from16 v3, v45

    goto/16 :goto_759b

    :catch_3295
    move-exception v0

    :goto_3296
    move-object/from16 v2, v53

    :goto_3298
    move-object/from16 v17, v1

    move/from16 v48, v3

    :goto_329c
    move-object v1, v6

    move-object v6, v7

    move-object v12, v10

    :goto_329f
    move-wide/from16 v56, v25

    move-object/from16 v13, v42

    move-object/from16 v32, v49

    move-object/from16 v43, v52

    :goto_32a7
    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v52, v35

    move/from16 v35, v38

    move-object/from16 v38, v4

    goto/16 :goto_20f8

    :catch_32c0
    move-exception v0

    move-wide/from16 v46, v12

    goto :goto_3296

    :catch_32c4
    move-exception v0

    move/from16 v45, v3

    move-wide/from16 v46, v12

    :goto_32c9
    move/from16 v3, v48

    move-object/from16 v2, v53

    :goto_32cd
    move-object/from16 v17, v1

    goto :goto_329c

    :catch_32d0
    move-exception v0

    move/from16 v45, v3

    :goto_32d3
    move-object/from16 v52, v12

    :goto_32d5
    move-object/from16 v35, v13

    goto :goto_32c9

    :catch_32d8
    move-exception v0

    move/from16 v38, v3

    goto :goto_32d3

    :catch_32dc
    move-exception v0

    move/from16 v37, v3

    goto :goto_32d3

    :catch_32e0
    move-exception v0

    goto :goto_32d3

    :catch_32e2
    move-exception v0

    move-object/from16 v33, v3

    goto :goto_32d3

    :catch_32e6
    move-exception v0

    move-object/from16 v40, v3

    goto :goto_32d3

    :catch_32ea
    move-exception v0

    move-object/from16 v40, v3

    goto :goto_32d5

    :catch_32ee
    move-exception v0

    move-object/from16 v35, v40

    :goto_32f1
    move-object/from16 v2, v53

    move-object/from16 v40, v3

    move/from16 v3, v48

    goto :goto_32cd

    :catch_32f8
    move-exception v0

    :goto_32f9
    move-object/from16 v35, v40

    move-object/from16 v10, v43

    goto :goto_32f1

    :catch_32fe
    move-exception v0

    :goto_32ff
    move-object/from16 v35, v40

    move-object/from16 v10, v43

    move-object/from16 v2, v53

    move-object/from16 v40, v3

    move/from16 v3, v48

    goto :goto_3298

    :catch_330a
    move-exception v0

    move-object/from16 v52, v2

    move/from16 v45, v10

    goto :goto_32f9

    :catch_3310
    move-exception v0

    move-object/from16 v52, v2

    move/from16 v45, v10

    goto :goto_32ff

    :cond_3316
    move-object/from16 v52, v2

    move/from16 v45, v10

    move-object/from16 v35, v40

    move-object/from16 v10, v43

    move-object/from16 v2, v53

    move-object/from16 v40, v3

    move/from16 v3, v48

    :goto_3324
    iget-object v0, v8, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lmog;

    if-eqz v0, :cond_332d

    invoke-virtual {v0}, Lmog;->s()V

    :cond_332d
    move-object v0, v1

    move-object/from16 v16, v4

    move-object v1, v6

    move-object/from16 v20, v7

    move-object/from16 v17, v10

    move-wide/from16 v56, v25

    move-object/from16 v207, v35

    move/from16 v7, v38

    move-object/from16 v44, v40

    move-object/from16 v13, v42

    move-object/from16 v32, v49

    move-object/from16 v6, v52

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v4, v14

    move-object v10, v15

    move/from16 v12, v45

    move-object v14, v9

    move-object v15, v11

    :goto_3359
    move-object v11, v8

    move-wide/from16 v8, v46

    goto/16 :goto_74e4

    :catch_335e
    move-exception v0

    move-object/from16 v40, v3

    move-object v10, v12

    move-object/from16 v52, v35

    move-object/from16 v4, v43

    move/from16 v3, v48

    move-object/from16 v2, v59

    move-object/from16 v35, v13

    move-object/from16 v17, v1

    move-object v1, v6

    move-object v6, v7

    goto/16 :goto_329f

    :cond_3372
    move-object/from16 v40, v3

    move-object v10, v12

    move-object/from16 v4, v43

    move/from16 v3, v48

    move-wide/from16 v54, v52

    move-object/from16 v95, v59

    move-object v12, v2

    move-object/from16 v52, v35

    move-object/from16 v2, v49

    move-object/from16 v35, v13

    :try_start_3384
    iget-object v13, v2, Lnlh;->k:La1f;

    iget-object v13, v13, La1f;->F:Ljava/lang/Object;

    check-cast v13, Lrig;

    iget-boolean v13, v13, Lrig;->s:Z
    :try_end_338c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3384 .. :try_end_338c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3384 .. :try_end_338c} :catch_51f0
    .catchall {:try_start_3384 .. :try_end_338c} :catchall_2e20

    if-eqz v13, :cond_3545

    :try_start_338e
    invoke-virtual {v9, v12}, Lpng;->c(Lcom/anthropic/claude/sessions/types/SdkEvent;)Z

    move-result v13
    :try_end_3392
    .catch Ljava/util/concurrent/CancellationException; {:try_start_338e .. :try_end_3392} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_338e .. :try_end_3392} :catch_3513
    .catchall {:try_start_338e .. :try_end_3392} :catchall_2e20

    if-eqz v13, :cond_33bb

    :try_start_3394
    iget-object v13, v2, Lnlh;->k:La1f;

    iget-object v13, v13, La1f;->F:Ljava/lang/Object;

    check-cast v13, Lrig;
    :try_end_339a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3394 .. :try_end_339a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3394 .. :try_end_339a} :catch_33a4
    .catchall {:try_start_3394 .. :try_end_339a} :catchall_2e20

    move-object/from16 v43, v2

    const/4 v2, 0x0

    :try_start_339d
    iput-boolean v2, v13, Lrig;->s:Z
    :try_end_339f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_339d .. :try_end_339f} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_339d .. :try_end_339f} :catch_33a2
    .catchall {:try_start_339d .. :try_end_339f} :catchall_2e20

    const/4 v13, 0x1

    :goto_33a0
    const/4 v2, 0x1

    goto :goto_33c0

    :catch_33a2
    move-exception v0

    goto :goto_33a8

    :catch_33a4
    move-exception v0

    move-object/from16 v43, v2

    const/4 v2, 0x0

    :goto_33a8
    move-object/from16 v17, v1

    move/from16 v48, v3

    move-object v1, v6

    move-object v6, v7

    move-object v12, v10

    move-wide/from16 v56, v25

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v43, v52

    move-object/from16 v2, v95

    goto/16 :goto_32a7

    :cond_33bb
    move-object/from16 v43, v2

    move/from16 v13, v45

    goto :goto_33a0

    :goto_33c0
    :try_start_33c0
    invoke-virtual {v9, v2}, Lpng;->a(Z)Z

    move-result v45

    if-eqz v45, :cond_34f1

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_33d0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_33c0 .. :try_end_33d0} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_33c0 .. :try_end_33d0} :catch_34d1
    .catchall {:try_start_33c0 .. :try_end_33d0} :catchall_2e20

    :try_start_33d0
    move-object/from16 v2, v36

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v2, v41

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->J:Ljava/util/List;
    :try_end_33dc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_33d0 .. :try_end_33dc} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_33d0 .. :try_end_33dc} :catch_34eb
    .catchall {:try_start_33d0 .. :try_end_33dc} :catchall_2e20

    :try_start_33dc
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;

    iput-object v4, v5, Laak;->O:Lexe;
    :try_end_33e6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_33dc .. :try_end_33e6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_33dc .. :try_end_33e6} :catch_34d1
    .catchall {:try_start_33dc .. :try_end_33e6} :catchall_2e20

    move-object/from16 v2, v35

    :try_start_33e8
    iput-object v2, v5, Laak;->P:Lixe;
    :try_end_33ea
    .catch Ljava/util/concurrent/CancellationException; {:try_start_33e8 .. :try_end_33ea} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_33e8 .. :try_end_33ea} :catch_34e7
    .catchall {:try_start_33e8 .. :try_end_33ea} :catchall_2e20

    move-object/from16 v35, v2

    move-object/from16 v2, v52

    :try_start_33ee
    iput-object v2, v5, Laak;->Q:Lixe;
    :try_end_33f0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_33ee .. :try_end_33f0} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_33ee .. :try_end_33f0} :catch_34e3
    .catchall {:try_start_33ee .. :try_end_33f0} :catchall_2e20

    move-object/from16 v52, v2

    move-object/from16 v2, v33

    :try_start_33f4
    iput-object v2, v5, Laak;->R:Lcp2;
    :try_end_33f6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_33f4 .. :try_end_33f6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_33f4 .. :try_end_33f6} :catch_34df
    .catchall {:try_start_33f4 .. :try_end_33f6} :catchall_2e20

    move-object/from16 v33, v2

    const/4 v2, 0x0

    :try_start_33f9
    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v2, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v2, v27

    iput-object v2, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v27, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v12, v5, Laak;->Y:Ljava/lang/Object;
    :try_end_340c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_33f9 .. :try_end_340c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_33f9 .. :try_end_340c} :catch_34d1
    .catchall {:try_start_33f9 .. :try_end_340c} :catchall_2e20

    move/from16 v2, v37

    :try_start_340e
    iput v2, v5, Laak;->e0:I
    :try_end_3410
    .catch Ljava/util/concurrent/CancellationException; {:try_start_340e .. :try_end_3410} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_340e .. :try_end_3410} :catch_34c7
    .catchall {:try_start_340e .. :try_end_3410} :catchall_2e20

    move-object/from16 v37, v12

    move/from16 v12, v38

    :try_start_3414
    iput-boolean v12, v5, Laak;->i0:Z

    iput v13, v5, Laak;->f0:I
    :try_end_3418
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3414 .. :try_end_3418} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3414 .. :try_end_3418} :catch_34bf
    .catchall {:try_start_3414 .. :try_end_3418} :catchall_2e20

    move/from16 v48, v12

    move/from16 v38, v13

    move-wide/from16 v12, v46

    :try_start_341e
    iput-wide v12, v5, Laak;->k0:J

    iput v3, v5, Laak;->g0:I
    :try_end_3422
    .catch Ljava/util/concurrent/CancellationException; {:try_start_341e .. :try_end_3422} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_341e .. :try_end_3422} :catch_34b9
    .catchall {:try_start_341e .. :try_end_3422} :catchall_2e20

    move-wide/from16 v46, v12

    move-wide/from16 v12, v54

    :try_start_3426
    iput-wide v12, v5, Laak;->l0:J
    :try_end_3428
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3426 .. :try_end_3428} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3426 .. :try_end_3428} :catch_34b5
    .catchall {:try_start_3426 .. :try_end_3428} :catchall_2e20

    move/from16 v49, v3

    const/16 v3, 0xe

    :try_start_342c
    iput v3, v5, Laak;->m0:I

    invoke-static {v11, v14, v6, v9, v5}, Laak;->q(Lexe;Lhxe;Lo1e;Lpng;Laak;)Ljava/lang/Object;

    move-result-object v3
    :try_end_3432
    .catch Ljava/util/concurrent/CancellationException; {:try_start_342c .. :try_end_3432} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_342c .. :try_end_3432} :catch_3483
    .catchall {:try_start_342c .. :try_end_3432} :catchall_2e20

    move-wide/from16 v54, v12

    move-object/from16 v12, v95

    if-ne v3, v12, :cond_343b

    :goto_3438
    move-object v2, v12

    goto/16 :goto_7700

    :cond_343b
    move-object/from16 v45, v1

    move v13, v2

    move/from16 v2, v38

    move/from16 v3, v49

    move-object/from16 v38, v0

    move-wide/from16 v0, v54

    move-object/from16 v208, v35

    move-object/from16 v35, v6

    move/from16 v6, v48

    move-object/from16 v48, v36

    move-wide/from16 v209, v46

    move-object/from16 v46, v15

    move-object/from16 v15, v37

    move-object/from16 v47, v41

    move-wide/from16 v36, v209

    move-object/from16 v41, v208

    :goto_345a
    move/from16 p1, v2

    move/from16 v96, v3

    move-object/from16 v53, v12

    move-object v12, v15

    move-object/from16 v3, v41

    move-object/from16 v2, v45

    move-object/from16 v15, v46

    move-object/from16 v41, v47

    move-object/from16 v47, v27

    move-wide/from16 v45, v36

    move-object/from16 v36, v48

    move-object/from16 v27, v52

    move-object/from16 v208, v33

    move/from16 v33, v6

    move-object/from16 v6, v35

    move/from16 v35, v13

    move-wide/from16 v209, v0

    move-object/from16 v1, v208

    move-object/from16 v0, v38

    move-wide/from16 v37, v209

    goto/16 :goto_3554

    :catch_3483
    move-exception v0

    :goto_3484
    move-object/from16 v12, v95

    :goto_3486
    move-object/from16 v17, v1

    move/from16 v37, v2

    :goto_348a
    move-object v1, v6

    move-object v6, v7

    move-object v2, v12

    move-wide/from16 v56, v25

    move/from16 v45, v38

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v43, v52

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v38, v4

    move-object v12, v10

    move-object/from16 v52, v35

    move-object/from16 v4, v40

    :goto_34af
    move/from16 v35, v48

    move/from16 v48, v49

    goto/16 :goto_7437

    :catch_34b5
    move-exception v0

    move/from16 v49, v3

    goto :goto_3484

    :catch_34b9
    move-exception v0

    move/from16 v49, v3

    move-wide/from16 v46, v12

    goto :goto_3484

    :catch_34bf
    move-exception v0

    move/from16 v49, v3

    move/from16 v48, v12

    move/from16 v38, v13

    goto :goto_3484

    :catch_34c7
    move-exception v0

    move/from16 v49, v3

    :goto_34ca
    move/from16 v48, v38

    move-object/from16 v12, v95

    move/from16 v38, v13

    goto :goto_3486

    :catch_34d1
    move-exception v0

    :goto_34d2
    move/from16 v49, v3

    move/from16 v2, v37

    move/from16 v48, v38

    move-object/from16 v12, v95

    move/from16 v38, v13

    move-object/from16 v17, v1

    goto :goto_348a

    :catch_34df
    move-exception v0

    move-object/from16 v33, v2

    goto :goto_34d2

    :catch_34e3
    move-exception v0

    move-object/from16 v52, v2

    goto :goto_34d2

    :catch_34e7
    move-exception v0

    move-object/from16 v35, v2

    goto :goto_34d2

    :catch_34eb
    move-exception v0

    move/from16 v49, v3

    move/from16 v2, v37

    goto :goto_34ca

    :cond_34f1
    move/from16 v49, v3

    move/from16 v2, v37

    move/from16 v48, v38

    move-object/from16 v37, v12

    move/from16 v38, v13

    move-object/from16 v3, v35

    move/from16 p1, v38

    :goto_34ff
    move-wide/from16 v45, v46

    move/from16 v96, v49

    move-wide/from16 v37, v54

    move-object/from16 v53, v95

    move/from16 v35, v2

    move-object/from16 v47, v27

    move-object/from16 v27, v52

    move-object v2, v1

    move-object/from16 v1, v33

    move/from16 v33, v48

    goto :goto_3554

    :catch_3513
    move-exception v0

    move-object/from16 v43, v2

    move/from16 v49, v3

    move/from16 v2, v37

    move/from16 v48, v38

    move-object/from16 v12, v95

    move-object/from16 v17, v1

    move-object/from16 v38, v4

    move-object v1, v6

    move-object v6, v7

    move-object v2, v12

    move-wide/from16 v56, v25

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v43, v52

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    :goto_3540
    move-object v12, v10

    move-object/from16 v52, v35

    goto/16 :goto_34af

    :cond_3545
    move-object/from16 v43, v2

    move/from16 v49, v3

    move/from16 v2, v37

    move/from16 v48, v38

    move-object/from16 v37, v12

    move-object/from16 v3, v35

    move/from16 p1, v45

    goto :goto_34ff

    :goto_3554
    :try_start_3554
    instance-of v13, v12, Lcom/anthropic/claude/sessions/types/SdkStreamEvent;
    :try_end_3556
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3554 .. :try_end_3556} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3554 .. :try_end_3556} :catch_51bf
    .catchall {:try_start_3554 .. :try_end_3556} :catchall_2e20

    if-eqz v13, :cond_399b

    move-object/from16 v13, v43

    move-object/from16 v43, v12

    :try_start_355c
    iget-object v12, v13, Lnlh;->k:La1f;

    iget-object v12, v12, La1f;->F:Ljava/lang/Object;

    check-cast v12, Lrig;

    iget-boolean v12, v12, Lrig;->s:Z
    :try_end_3564
    .catch Ljava/util/concurrent/CancellationException; {:try_start_355c .. :try_end_3564} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_355c .. :try_end_3564} :catch_3960
    .catchall {:try_start_355c .. :try_end_3564} :catchall_2e20

    if-nez v12, :cond_36c1

    if-nez p1, :cond_36c1

    :try_start_3568
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v48
    :try_end_356c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3568 .. :try_end_356c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3568 .. :try_end_356c} :catch_36d8
    .catchall {:try_start_3568 .. :try_end_356c} :catchall_2e20

    sub-long v48, v48, v45

    cmp-long v12, v48, v18

    if-ltz v12, :cond_36c1

    move-object/from16 v49, v13

    :try_start_3574
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v12

    move-wide/from16 v45, v12

    sget-object v12, Lpmg;->a:Lpmg;

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_3586
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3574 .. :try_end_3586} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3574 .. :try_end_3586} :catch_369f
    .catchall {:try_start_3574 .. :try_end_3586} :catchall_2e20

    :try_start_3586
    move-object/from16 v13, v36

    check-cast v13, Ljava/util/List;

    iput-object v13, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v13, v41

    check-cast v13, Ljava/util/List;

    iput-object v13, v5, Laak;->J:Ljava/util/List;
    :try_end_3592
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3586 .. :try_end_3592} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3586 .. :try_end_3592} :catch_36b1
    .catchall {:try_start_3586 .. :try_end_3592} :catchall_2e20

    :try_start_3592
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;

    iput-object v4, v5, Laak;->O:Lexe;

    iput-object v3, v5, Laak;->P:Lixe;
    :try_end_359e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3592 .. :try_end_359e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3592 .. :try_end_359e} :catch_369f
    .catchall {:try_start_3592 .. :try_end_359e} :catchall_2e20

    move-object/from16 v13, v27

    :try_start_35a0
    iput-object v13, v5, Laak;->Q:Lixe;

    iput-object v1, v5, Laak;->R:Lcp2;
    :try_end_35a4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35a0 .. :try_end_35a4} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35a0 .. :try_end_35a4} :catch_369b
    .catchall {:try_start_35a0 .. :try_end_35a4} :catchall_2e20

    move-object/from16 v27, v1

    const/4 v1, 0x0

    :try_start_35a7
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v1, v47

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v47, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v1, v43

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;
    :try_end_35bc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35a7 .. :try_end_35bc} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35a7 .. :try_end_35bc} :catch_3693
    .catchall {:try_start_35a7 .. :try_end_35bc} :catchall_2e20

    move-object/from16 v43, v13

    move/from16 v13, v35

    :try_start_35c0
    iput v13, v5, Laak;->e0:I
    :try_end_35c2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35c0 .. :try_end_35c2} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35c0 .. :try_end_35c2} :catch_368b
    .catchall {:try_start_35c0 .. :try_end_35c2} :catchall_2e20

    move/from16 v35, v13

    move/from16 v13, v33

    :try_start_35c6
    iput-boolean v13, v5, Laak;->i0:Z
    :try_end_35c8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35c6 .. :try_end_35c8} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35c6 .. :try_end_35c8} :catch_367b
    .catchall {:try_start_35c6 .. :try_end_35c8} :catchall_2e20

    move/from16 v33, v13

    move/from16 v13, p1

    :try_start_35cc
    iput v13, v5, Laak;->f0:I
    :try_end_35ce
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35cc .. :try_end_35ce} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35cc .. :try_end_35ce} :catch_3675
    .catchall {:try_start_35cc .. :try_end_35ce} :catchall_2e20

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-wide/from16 v3, v45

    :try_start_35d4
    iput-wide v3, v5, Laak;->k0:J
    :try_end_35d6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35d4 .. :try_end_35d6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35d4 .. :try_end_35d6} :catch_366d
    .catchall {:try_start_35d4 .. :try_end_35d6} :catchall_2e20

    move-wide/from16 v45, v3

    move/from16 v3, v96

    :try_start_35da
    iput v3, v5, Laak;->g0:I
    :try_end_35dc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35da .. :try_end_35dc} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35da .. :try_end_35dc} :catch_3669
    .catchall {:try_start_35da .. :try_end_35dc} :catchall_2e20

    move/from16 v54, v3

    move-wide/from16 v3, v37

    :try_start_35e0
    iput-wide v3, v5, Laak;->l0:J
    :try_end_35e2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35e0 .. :try_end_35e2} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35e0 .. :try_end_35e2} :catch_3663
    .catchall {:try_start_35e0 .. :try_end_35e2} :catchall_2e20

    move-wide/from16 v37, v3

    const/16 v3, 0xf

    :try_start_35e6
    iput v3, v5, Laak;->m0:I

    invoke-virtual {v6, v5, v12}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4
    :try_end_35ec
    .catch Ljava/util/concurrent/CancellationException; {:try_start_35e6 .. :try_end_35ec} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_35e6 .. :try_end_35ec} :catch_3631
    .catchall {:try_start_35e6 .. :try_end_35ec} :catchall_2e20

    move-object/from16 v12, v53

    if-ne v4, v12, :cond_35f2

    goto/16 :goto_3438

    :cond_35f2
    move/from16 v4, v35

    move-object/from16 v35, v6

    move v6, v4

    move v4, v13

    move-object v13, v1

    move-wide/from16 v208, v37

    move-object/from16 v38, v0

    move-wide/from16 v0, v208

    move-wide/from16 v208, v45

    move-object/from16 v45, v2

    move-object/from16 v46, v15

    move-object/from16 v2, v48

    move-object/from16 v48, v36

    move-wide/from16 v36, v208

    :goto_360b
    move-object/from16 p1, v13

    move-object v13, v2

    move-object/from16 v2, v27

    move-object/from16 v27, p1

    move-wide/from16 v97, v0

    move/from16 p1, v4

    move v1, v6

    move-object/from16 v6, v35

    move-wide/from16 v99, v36

    move-object/from16 v0, v38

    move-object/from16 v15, v45

    move-object/from16 v3, v46

    move-object/from16 v36, v48

    :goto_3623
    move-object/from16 v53, v12

    move-object/from16 v12, v43

    move-object/from16 v4, v52

    move/from16 v101, v54

    move/from16 v35, v33

    move-object/from16 v33, v47

    goto/16 :goto_36fc

    :catch_3631
    move-exception v0

    move-object/from16 v12, v53

    :goto_3634
    move-object/from16 v17, v2

    move/from16 v23, v3

    move-object v1, v6

    move-object v6, v7

    move-object v2, v12

    move-wide/from16 v56, v25

    move/from16 v37, v35

    move-object/from16 v4, v40

    move-wide/from16 v46, v45

    move-object/from16 v38, v48

    move-object/from16 v32, v49

    move/from16 v48, v54

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v12, v10

    :goto_3659
    move/from16 v45, v13

    move/from16 v35, v33

    move-object/from16 v13, v42

    :goto_365f
    move-object/from16 v33, v27

    goto/16 :goto_7437

    :catch_3663
    move-exception v0

    :goto_3664
    move-object/from16 v12, v53

    :goto_3666
    const/16 v3, 0xf

    goto :goto_3634

    :catch_3669
    move-exception v0

    move/from16 v54, v3

    goto :goto_3664

    :catch_366d
    move-exception v0

    move-wide/from16 v45, v3

    :goto_3670
    move-object/from16 v12, v53

    move/from16 v54, v96

    goto :goto_3666

    :catch_3675
    move-exception v0

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    goto :goto_3670

    :catch_367b
    move-exception v0

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move/from16 v33, v13

    :goto_3682
    move-object/from16 v12, v53

    move/from16 v54, v96

    const/16 v3, 0xf

    move/from16 v13, p1

    goto :goto_3634

    :catch_368b
    move-exception v0

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move/from16 v35, v13

    goto :goto_3682

    :catch_3693
    move-exception v0

    :goto_3694
    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-object/from16 v43, v13

    goto :goto_3682

    :catch_369b
    move-exception v0

    move-object/from16 v27, v1

    goto :goto_3694

    :catch_369f
    move-exception v0

    move/from16 v13, p1

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-object/from16 v43, v27

    move-object/from16 v12, v53

    move/from16 v54, v96

    const/16 v3, 0xf

    :goto_36ae
    move-object/from16 v27, v1

    goto :goto_3634

    :catch_36b1
    move-exception v0

    move/from16 v13, p1

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-object/from16 v43, v27

    move-object/from16 v12, v53

    move/from16 v54, v96

    const/16 v3, 0xf

    goto :goto_36ae

    :cond_36c1
    move-object/from16 v12, v27

    move-object/from16 v27, v1

    move-object/from16 v1, v43

    move-object/from16 v43, v12

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-object/from16 v49, v13

    move-object/from16 v12, v53

    move/from16 v54, v96

    const/16 v3, 0xf

    move/from16 v13, p1

    goto :goto_36ea

    :catch_36d8
    move-exception v0

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-object/from16 v49, v13

    move-object/from16 v43, v27

    move-object/from16 v12, v53

    move/from16 v54, v96

    const/16 v3, 0xf

    move/from16 v13, p1

    goto :goto_36ae

    :goto_36ea
    move/from16 p1, v13

    move-object v3, v15

    move-wide/from16 v97, v37

    move-wide/from16 v99, v45

    move-object/from16 v13, v48

    move-object v15, v2

    move-object/from16 v2, v27

    move-object/from16 v27, v1

    move/from16 v1, v35

    goto/16 :goto_3623

    :goto_36fc
    if-eqz p1, :cond_3744

    :try_start_36fe
    move-object/from16 v37, v27

    check-cast v37, Lcom/anthropic/claude/sessions/types/SdkStreamEvent;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static/range {v37 .. v37}, Lpng;->d(Lcom/anthropic/claude/sessions/types/SdkStreamEvent;)Z

    move-result v37
    :try_end_3709
    .catch Ljava/util/concurrent/CancellationException; {:try_start_36fe .. :try_end_3709} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_36fe .. :try_end_3709} :catch_3742
    .catchall {:try_start_36fe .. :try_end_3709} :catchall_2e20

    if-eqz v37, :cond_3744

    move/from16 v37, v1

    const/4 v1, 0x0

    goto :goto_3748

    :goto_370f
    move/from16 v45, p1

    move/from16 v37, v1

    move-object/from16 v33, v2

    move-object/from16 v52, v4

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v43, v12

    move-object/from16 v38, v13

    move-object/from16 v17, v15

    move-wide/from16 v56, v25

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-object/from16 v32, v49

    move-object/from16 v2, v53

    move-wide/from16 v46, v99

    move/from16 v48, v101

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v15, v3

    move-object v12, v10

    goto/16 :goto_7437

    :catch_3742
    move-exception v0

    goto :goto_370f

    :cond_3744
    move/from16 v37, v1

    move/from16 v1, p1

    :goto_3748
    if-eqz v35, :cond_3938

    move/from16 p1, v1

    move-object/from16 v38, v2

    move-object/from16 v1, v49

    :try_start_3750
    iget-object v2, v1, Lnlh;->k:La1f;

    iget-object v2, v2, La1f;->F:Ljava/lang/Object;

    check-cast v2, Lrig;

    iget-boolean v2, v2, Lrig;->s:Z
    :try_end_3758
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3750 .. :try_end_3758} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3750 .. :try_end_3758} :catch_3934
    .catchall {:try_start_3750 .. :try_end_3758} :catchall_2e20

    if-nez v2, :cond_3931

    if-nez p1, :cond_3931

    :try_start_375c
    move-object/from16 v2, v27

    check-cast v2, Lcom/anthropic/claude/sessions/types/SdkStreamEvent;

    invoke-virtual {v9, v2}, Lpng;->e(Lcom/anthropic/claude/sessions/types/SdkStreamEvent;)Z

    move-result v2
    :try_end_3764
    .catch Ljava/util/concurrent/CancellationException; {:try_start_375c .. :try_end_3764} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_375c .. :try_end_3764} :catch_392d
    .catchall {:try_start_375c .. :try_end_3764} :catchall_2e20

    if-eqz v2, :cond_379c

    const/4 v2, 0x1

    :try_start_3767
    iput-boolean v2, v11, Lexe;->E:Z
    :try_end_3769
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3767 .. :try_end_3769} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3767 .. :try_end_3769} :catch_376a
    .catchall {:try_start_3767 .. :try_end_3769} :catchall_2e20

    goto :goto_379c

    :catch_376a
    move-exception v0

    move/from16 v45, p1

    move-object/from16 v32, v1

    move-object/from16 v52, v4

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v43, v12

    move-object/from16 v17, v15

    move-wide/from16 v56, v25

    move-object/from16 v33, v38

    move-object/from16 v4, v40

    move-wide/from16 v46, v99

    move/from16 v48, v101

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move v7, v2

    move-object v15, v3

    move-object v12, v10

    move-object/from16 v38, v13

    move-object/from16 v13, v42

    :goto_3798
    move-object/from16 v2, v53

    goto/16 :goto_7437

    :cond_379c
    :goto_379c
    :try_start_379c
    iget-boolean v2, v11, Lexe;->E:Z

    if-eqz v2, :cond_3931

    check-cast v27, Lcom/anthropic/claude/sessions/types/SdkStreamEvent;

    invoke-virtual/range {v27 .. v27}, Lcom/anthropic/claude/sessions/types/SdkStreamEvent;->getEvent()Lcom/anthropic/claude/sessions/types/SdkStreamEvent$Payload;

    move-result-object v2
    :try_end_37a6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_379c .. :try_end_37a6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_379c .. :try_end_37a6} :catch_392d
    .catchall {:try_start_379c .. :try_end_37a6} :catchall_2e20

    if-eqz v2, :cond_37dd

    :try_start_37a8
    invoke-virtual {v2}, Lcom/anthropic/claude/sessions/types/SdkStreamEvent$Payload;->getType()Ljava/lang/String;

    move-result-object v2
    :try_end_37ac
    .catch Ljava/util/concurrent/CancellationException; {:try_start_37a8 .. :try_end_37ac} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_37a8 .. :try_end_37ac} :catch_37ad
    .catchall {:try_start_37a8 .. :try_end_37ac} :catchall_2e20

    goto :goto_37de

    :catch_37ad
    move-exception v0

    move/from16 v45, p1

    move-object/from16 v32, v1

    move-object/from16 v52, v4

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v43, v12

    move-object/from16 v17, v15

    move-wide/from16 v56, v25

    move-object/from16 v33, v38

    move-object/from16 v4, v40

    :goto_37c0
    move-object/from16 v2, v53

    move-wide/from16 v46, v99

    move/from16 v48, v101

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v15, v3

    :goto_37d8
    move-object v12, v10

    move-object/from16 v38, v13

    goto/16 :goto_1ef6

    :cond_37dd
    const/4 v2, 0x0

    :goto_37de
    if-eqz v2, :cond_3801

    move-object/from16 v49, v1

    :try_start_37e2
    invoke-static {}, Leak;->h()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_37ea
    .catch Ljava/util/concurrent/CancellationException; {:try_start_37e2 .. :try_end_37ea} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_37e2 .. :try_end_37ea} :catch_37ed
    .catchall {:try_start_37e2 .. :try_end_37ea} :catchall_2e20

    if-nez v1, :cond_3813

    goto :goto_3803

    :catch_37ed
    move-exception v0

    move/from16 v45, p1

    move-object/from16 v52, v4

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v43, v12

    move-object/from16 v17, v15

    move-wide/from16 v56, v25

    move-object/from16 v33, v38

    move-object/from16 v4, v40

    move-object/from16 v32, v49

    goto :goto_37c0

    :cond_3801
    move-object/from16 v49, v1

    :goto_3803
    :try_start_3803
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    move-wide/from16 v45, v1

    iget-wide v1, v14, Lhxe;->E:J

    sub-long v1, v45, v1

    const-wide/16 v45, 0x64

    cmp-long v1, v1, v45

    if-ltz v1, :cond_3815

    :cond_3813
    const/4 v1, 0x1

    goto :goto_3816

    :cond_3815
    const/4 v1, 0x0

    :goto_3816
    if-eqz v1, :cond_391e

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_3822
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3803 .. :try_end_3822} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3803 .. :try_end_3822} :catch_390e
    .catchall {:try_start_3803 .. :try_end_3822} :catchall_2e20

    :try_start_3822
    move-object/from16 v2, v36

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v2, v41

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->J:Ljava/util/List;
    :try_end_382e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3822 .. :try_end_382e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3822 .. :try_end_382e} :catch_3914
    .catchall {:try_start_3822 .. :try_end_382e} :catchall_2e20

    :try_start_382e
    iput-object v3, v5, Laak;->K:Lixe;

    iput-object v15, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v4, v5, Laak;->P:Lixe;

    iput-object v12, v5, Laak;->Q:Lixe;
    :try_end_383c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_382e .. :try_end_383c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_382e .. :try_end_383c} :catch_390e
    .catchall {:try_start_382e .. :try_end_383c} :catchall_2e20

    move-object/from16 v2, v38

    :try_start_383e
    iput-object v2, v5, Laak;->R:Lcp2;
    :try_end_3840
    .catch Ljava/util/concurrent/CancellationException; {:try_start_383e .. :try_end_3840} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_383e .. :try_end_3840} :catch_3910
    .catchall {:try_start_383e .. :try_end_3840} :catchall_2e20

    move-object/from16 v38, v2

    const/4 v2, 0x0

    :try_start_3843
    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v2, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v2, v33

    iput-object v2, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v27, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;
    :try_end_3858
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3843 .. :try_end_3858} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3843 .. :try_end_3858} :catch_390e
    .catchall {:try_start_3843 .. :try_end_3858} :catchall_2e20

    move/from16 v2, v37

    :try_start_385a
    iput v2, v5, Laak;->e0:I
    :try_end_385c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_385a .. :try_end_385c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_385a .. :try_end_385c} :catch_3902
    .catchall {:try_start_385a .. :try_end_385c} :catchall_2e20

    move/from16 v37, v2

    move/from16 v2, v35

    :try_start_3860
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_3862
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3860 .. :try_end_3862} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3860 .. :try_end_3862} :catch_38fe
    .catchall {:try_start_3860 .. :try_end_3862} :catchall_2e20

    move/from16 v33, v2

    move/from16 v2, p1

    :try_start_3866
    iput v2, v5, Laak;->f0:I
    :try_end_3868
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3866 .. :try_end_3868} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3866 .. :try_end_3868} :catch_38f4
    .catchall {:try_start_3866 .. :try_end_3868} :catchall_2e20

    move/from16 p1, v2

    move-object/from16 v35, v3

    move-wide/from16 v2, v99

    :try_start_386e
    iput-wide v2, v5, Laak;->k0:J
    :try_end_3870
    .catch Ljava/util/concurrent/CancellationException; {:try_start_386e .. :try_end_3870} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_386e .. :try_end_3870} :catch_38ec
    .catchall {:try_start_386e .. :try_end_3870} :catchall_2e20

    move-wide/from16 v45, v2

    move/from16 v2, v101

    :try_start_3874
    iput v2, v5, Laak;->g0:I
    :try_end_3876
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3874 .. :try_end_3876} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3874 .. :try_end_3876} :catch_38e8
    .catchall {:try_start_3874 .. :try_end_3876} :catchall_2e20

    move/from16 v43, v2

    move-wide/from16 v2, v97

    :try_start_387a
    iput-wide v2, v5, Laak;->l0:J

    iput v1, v5, Laak;->h0:I

    const/16 v1, 0x10

    iput v1, v5, Laak;->m0:I

    invoke-static {v11, v14, v6, v9, v5}, Laak;->q(Lexe;Lhxe;Lo1e;Lpng;Laak;)Ljava/lang/Object;

    move-result-object v1
    :try_end_3886
    .catch Ljava/util/concurrent/CancellationException; {:try_start_387a .. :try_end_3886} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_387a .. :try_end_3886} :catch_38b7
    .catchall {:try_start_387a .. :try_end_3886} :catchall_2e20

    move-wide/from16 v47, v2

    move-object/from16 v3, v53

    if-ne v1, v3, :cond_388e

    goto/16 :goto_2cea

    :cond_388e
    move/from16 v86, p1

    move-object v2, v4

    move-object v4, v6

    move-object v6, v7

    move-object v7, v8

    move-object v8, v9

    move-object v9, v11

    move/from16 v83, v33

    move/from16 v84, v37

    move-object/from16 v1, v38

    move/from16 v85, v43

    move-wide/from16 v81, v45

    move-wide/from16 v37, v47

    move-object v11, v10

    move-object/from16 v10, v27

    move-object/from16 v27, v12

    move-object/from16 v12, v35

    :goto_38a9
    move-object/from16 p1, v0

    move-object/from16 v59, v3

    move-object v0, v10

    move-object v10, v11

    move-object v11, v14

    move-object v14, v15

    move-object/from16 v15, v27

    move-object/from16 v58, v42

    goto/16 :goto_2b92

    :catch_38b7
    move-exception v0

    :goto_38b8
    move-object/from16 v3, v53

    :goto_38ba
    move-object v2, v3

    move-object/from16 v52, v4

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v17, v15

    move-wide/from16 v56, v25

    move-object/from16 v15, v35

    move-object/from16 v4, v40

    move/from16 v48, v43

    move-wide/from16 v46, v45

    move-object/from16 v32, v49

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move/from16 v45, p1

    move-object/from16 v43, v12

    move/from16 v35, v33

    move-object/from16 v33, v38

    goto/16 :goto_37d8

    :catch_38e8
    move-exception v0

    move/from16 v43, v2

    goto :goto_38b8

    :catch_38ec
    move-exception v0

    move-wide/from16 v45, v2

    move-object/from16 v3, v53

    :goto_38f1
    move/from16 v43, v101

    goto :goto_38ba

    :catch_38f4
    move-exception v0

    move/from16 p1, v2

    :goto_38f7
    move-object/from16 v35, v3

    move-object/from16 v3, v53

    move-wide/from16 v45, v99

    goto :goto_38f1

    :catch_38fe
    move-exception v0

    move/from16 v33, v2

    goto :goto_38f7

    :catch_3902
    move-exception v0

    move/from16 v37, v2

    :goto_3905
    move/from16 v33, v35

    move-wide/from16 v45, v99

    move/from16 v43, v101

    move-object/from16 v35, v3

    goto :goto_38b8

    :catch_390e
    move-exception v0

    goto :goto_3905

    :catch_3910
    move-exception v0

    move-object/from16 v38, v2

    goto :goto_3905

    :catch_3914
    move-exception v0

    :goto_3915
    move/from16 v33, v35

    move-wide/from16 v45, v99

    move/from16 v43, v101

    move-object/from16 v35, v3

    goto :goto_38b8

    :cond_391e
    :goto_391e
    move-object/from16 v27, v33

    move/from16 v33, v35

    move-wide/from16 v47, v97

    move-wide/from16 v45, v99

    move/from16 v43, v101

    move-object/from16 v35, v3

    move-object/from16 v3, v53

    goto :goto_393d

    :catch_392d
    move-exception v0

    move-object/from16 v49, v1

    goto :goto_3905

    :cond_3931
    move-object/from16 v49, v1

    goto :goto_391e

    :catch_3934
    move-exception v0

    move-object/from16 v49, v1

    goto :goto_3915

    :cond_3938
    move/from16 p1, v1

    move-object/from16 v38, v2

    goto :goto_391e

    :goto_393d
    move/from16 v86, p1

    move-object/from16 p1, v0

    move-object/from16 v59, v3

    move-object v2, v4

    move-object v4, v6

    move-object v6, v7

    move-object v7, v8

    move-object v8, v9

    move-object v9, v11

    move-object v11, v14

    move-object v14, v15

    move-object/from16 v0, v27

    move/from16 v83, v33

    move/from16 v84, v37

    move-object/from16 v1, v38

    move-object/from16 v58, v42

    move/from16 v85, v43

    move-wide/from16 v81, v45

    move-wide/from16 v37, v47

    move-object v15, v12

    move-object/from16 v12, v35

    goto/16 :goto_2b92

    :catch_3960
    move-exception v0

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-object/from16 v49, v13

    move-object/from16 v43, v27

    move-object/from16 v3, v53

    move/from16 v54, v96

    const/16 v30, 0x1

    move/from16 v13, p1

    move-object/from16 v27, v1

    :goto_3973
    move-object/from16 v17, v2

    move-object v2, v3

    move-object v1, v6

    move-object v6, v7

    move-object v12, v10

    move-wide/from16 v56, v25

    move/from16 v7, v30

    move/from16 v37, v35

    move-object/from16 v4, v40

    move-wide/from16 v46, v45

    move-object/from16 v38, v48

    move-object/from16 v32, v49

    :goto_3987
    move/from16 v48, v54

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    goto/16 :goto_3659

    :cond_399b
    move/from16 v13, p1

    move-object/from16 v52, v3

    move-object/from16 v48, v4

    move-object/from16 v49, v43

    move-object/from16 v3, v53

    move/from16 v54, v96

    const/16 v30, 0x1

    move-object/from16 v43, v27

    move-object/from16 v27, v1

    move-object v1, v12

    if-eqz v39, :cond_39c7

    :try_start_39b0
    move-object/from16 v4, v36

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    instance-of v4, v1, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;

    if-eqz v4, :cond_39c7

    move-object v12, v1

    check-cast v12, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;

    invoke-virtual {v12}, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;->getUuid()Ljava/lang/String;

    move-result-object v4

    iput-object v4, v2, Lixe;->E:Ljava/lang/Object;
    :try_end_39c4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_39b0 .. :try_end_39c4} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_39b0 .. :try_end_39c4} :catch_39c5
    .catchall {:try_start_39b0 .. :try_end_39c4} :catchall_2e20

    goto :goto_39c7

    :catch_39c5
    move-exception v0

    goto :goto_3973

    :cond_39c7
    :goto_39c7
    :try_start_39c7
    invoke-static {v1}, Lolk;->h(Lcom/anthropic/claude/sessions/types/SdkEvent;)Ljava/lang/String;

    move-result-object v4
    :try_end_39cb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_39c7 .. :try_end_39cb} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_39c7 .. :try_end_39cb} :catch_51bb
    .catchall {:try_start_39c7 .. :try_end_39cb} :catchall_2e20

    if-eqz v4, :cond_39fc

    :try_start_39cd
    invoke-virtual/range {v49 .. v49}, Lnlh;->i()Lq98;

    move-result-object v12

    move-object/from16 p1, v12

    invoke-static/range {v51 .. v51}, Lcom/anthropic/claude/types/strings/SessionId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/SessionId;

    move-result-object v12
    :try_end_39d7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_39cd .. :try_end_39d7} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_39cd .. :try_end_39d7} :catch_39f8
    .catchall {:try_start_39cd .. :try_end_39d7} :catchall_2e20

    move-object/from16 v53, v3

    :try_start_39d9
    move-object/from16 v3, p1

    check-cast v3, Llp4;

    invoke-virtual {v3, v12, v4}, Llp4;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_39e0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_39d9 .. :try_end_39e0} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_39d9 .. :try_end_39e0} :catch_39e1
    .catchall {:try_start_39d9 .. :try_end_39e0} :catchall_2e20

    goto :goto_39fe

    :catch_39e1
    move-exception v0

    :goto_39e2
    move-object/from16 v17, v2

    move-object v1, v6

    move-object v6, v7

    move-object v12, v10

    move-wide/from16 v56, v25

    move/from16 v7, v30

    move/from16 v37, v35

    move-object/from16 v4, v40

    move-wide/from16 v46, v45

    move-object/from16 v38, v48

    move-object/from16 v32, v49

    move-object/from16 v2, v53

    goto :goto_3987

    :catch_39f8
    move-exception v0

    move-object/from16 v53, v3

    goto :goto_39e2

    :cond_39fc
    move-object/from16 v53, v3

    :goto_39fe
    :try_start_39fe
    instance-of v3, v1, Lcom/anthropic/claude/sessions/types/SdkControlRequestEvent;
    :try_end_3a00
    .catch Ljava/util/concurrent/CancellationException; {:try_start_39fe .. :try_end_3a00} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_39fe .. :try_end_3a00} :catch_5193
    .catchall {:try_start_39fe .. :try_end_3a00} :catchall_2e20

    if-eqz v3, :cond_3d01

    :try_start_3a02
    move-object v12, v1

    check-cast v12, Lcom/anthropic/claude/sessions/types/SdkControlRequestEvent;

    invoke-static {v12}, Lolk;->i(Lcom/anthropic/claude/sessions/types/SdkControlRequestEvent;)Z

    move-result v3

    if-nez v3, :cond_3d01

    invoke-virtual/range {v49 .. v49}, Lnlh;->b()Lq98;

    move-result-object v3

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_3a19
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a02 .. :try_end_3a19} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a02 .. :try_end_3a19} :catch_3cf5
    .catchall {:try_start_3a02 .. :try_end_3a19} :catchall_2e20

    :try_start_3a19
    move-object/from16 v4, v36

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v4, v41

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->J:Ljava/util/List;
    :try_end_3a25
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a19 .. :try_end_3a25} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a19 .. :try_end_3a25} :catch_3cfb
    .catchall {:try_start_3a19 .. :try_end_3a25} :catchall_2e20

    :try_start_3a25
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;
    :try_end_3a2d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a25 .. :try_end_3a2d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a25 .. :try_end_3a2d} :catch_3cf5
    .catchall {:try_start_3a25 .. :try_end_3a2d} :catchall_2e20

    move-object/from16 v4, v48

    :try_start_3a2f
    iput-object v4, v5, Laak;->O:Lexe;
    :try_end_3a31
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a2f .. :try_end_3a31} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a2f .. :try_end_3a31} :catch_3cf3
    .catchall {:try_start_3a2f .. :try_end_3a31} :catchall_2e20

    move-object/from16 v12, v52

    :try_start_3a33
    iput-object v12, v5, Laak;->P:Lixe;
    :try_end_3a35
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a33 .. :try_end_3a35} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a33 .. :try_end_3a35} :catch_3ce9
    .catchall {:try_start_3a33 .. :try_end_3a35} :catchall_2e20

    move-object/from16 p1, v3

    move-object/from16 v3, v43

    :try_start_3a39
    iput-object v3, v5, Laak;->Q:Lixe;
    :try_end_3a3b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a39 .. :try_end_3a3b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a39 .. :try_end_3a3b} :catch_3cef
    .catchall {:try_start_3a39 .. :try_end_3a3b} :catchall_2e20

    move-object/from16 v43, v3

    move-object/from16 v3, v27

    :try_start_3a3f
    iput-object v3, v5, Laak;->R:Lcp2;
    :try_end_3a41
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a3f .. :try_end_3a41} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a3f .. :try_end_3a41} :catch_3ceb
    .catchall {:try_start_3a3f .. :try_end_3a41} :catchall_2e20

    move-object/from16 v27, v3

    const/4 v3, 0x0

    :try_start_3a44
    iput-object v3, v5, Laak;->S:Lpe9;

    iput-object v3, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v3, v47

    iput-object v3, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v47, v3

    const/4 v3, 0x0

    iput-object v3, v5, Laak;->W:Long;

    iput-object v3, v5, Laak;->X:Ljava/lang/Object;

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;
    :try_end_3a57
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a44 .. :try_end_3a57} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a44 .. :try_end_3a57} :catch_3ce9
    .catchall {:try_start_3a44 .. :try_end_3a57} :catchall_2e20

    move/from16 v3, v35

    :try_start_3a59
    iput v3, v5, Laak;->e0:I
    :try_end_3a5b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a59 .. :try_end_3a5b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a59 .. :try_end_3a5b} :catch_3cdd
    .catchall {:try_start_3a59 .. :try_end_3a5b} :catchall_2e20

    move/from16 v35, v3

    move/from16 v3, v33

    :try_start_3a5f
    iput-boolean v3, v5, Laak;->i0:Z

    iput v13, v5, Laak;->f0:I
    :try_end_3a63
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a5f .. :try_end_3a63} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a5f .. :try_end_3a63} :catch_3cd7
    .catchall {:try_start_3a5f .. :try_end_3a63} :catchall_2e20

    move-object/from16 v52, v12

    move/from16 v33, v13

    move-wide/from16 v12, v45

    :try_start_3a69
    iput-wide v12, v5, Laak;->k0:J
    :try_end_3a6b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a69 .. :try_end_3a6b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a69 .. :try_end_3a6b} :catch_3cd3
    .catchall {:try_start_3a69 .. :try_end_3a6b} :catchall_2e20

    move-wide/from16 v45, v12

    move/from16 v12, v54

    :try_start_3a6f
    iput v12, v5, Laak;->g0:I
    :try_end_3a71
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a6f .. :try_end_3a71} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a6f .. :try_end_3a71} :catch_3ccf
    .catchall {:try_start_3a6f .. :try_end_3a71} :catchall_2e20

    move/from16 v54, v12

    move-wide/from16 v12, v37

    :try_start_3a75
    iput-wide v12, v5, Laak;->l0:J

    move-wide/from16 v37, v12

    const/16 v12, 0x11

    iput v12, v5, Laak;->m0:I
    :try_end_3a7d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a75 .. :try_end_3a7d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a75 .. :try_end_3a7d} :catch_3ccb
    .catchall {:try_start_3a75 .. :try_end_3a7d} :catchall_2e20

    :try_start_3a7d
    move-object/from16 v12, p1

    check-cast v12, Lfo;

    invoke-virtual {v12, v1, v5}, Lfo;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12
    :try_end_3a85
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3a7d .. :try_end_3a85} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3a7d .. :try_end_3a85} :catch_3c9b
    .catchall {:try_start_3a7d .. :try_end_3a85} :catchall_2e20

    move-object/from16 v13, v53

    if-ne v12, v13, :cond_3a8c

    :goto_3a89
    move-object v2, v13

    goto/16 :goto_7700

    :cond_3a8c
    move/from16 v12, v35

    move-object/from16 v35, v6

    move v6, v12

    move-object v12, v1

    move-object/from16 v48, v36

    move-wide/from16 v208, v37

    move-object/from16 v38, v0

    move-wide/from16 v0, v208

    move-wide/from16 v36, v45

    move-object/from16 v45, v2

    move v2, v3

    move-object/from16 v46, v15

    move/from16 v3, v54

    :goto_3aa3
    :try_start_3aa3
    invoke-virtual/range {v49 .. v49}, Lnlh;->c()Lhhg;

    move-result-object v15

    invoke-virtual {v15, v12}, Lhhg;->l(Lcom/anthropic/claude/sessions/types/SdkEvent;)Ljava/util/List;

    move-result-object v12

    check-cast v12, Ljava/lang/Iterable;

    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12
    :try_end_3ab1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3aa3 .. :try_end_3ab1} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3aa3 .. :try_end_3ab1} :catch_3c64
    .catchall {:try_start_3aa3 .. :try_end_3ab1} :catchall_2e20

    move-wide/from16 v102, v0

    move/from16 v106, v2

    move/from16 v108, v3

    move-object v15, v4

    move/from16 v107, v6

    move-object v6, v7

    move-object v7, v8

    move-object v8, v9

    move-object v9, v11

    move-object/from16 p1, v12

    move-object/from16 v53, v13

    move-object/from16 v2, v27

    move/from16 v109, v33

    move-object/from16 v4, v35

    move-wide/from16 v104, v36

    move-object/from16 v0, v38

    move-object/from16 v13, v45

    move-object/from16 v1, v47

    move-object/from16 v36, v48

    move-object/from16 v3, v52

    move-object v11, v10

    move-object/from16 v10, v43

    :goto_3ad7
    move-object/from16 v12, v46

    :try_start_3ad9
    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v27

    if-eqz v27, :cond_3c2c

    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v27

    move-object/from16 v33, v1

    move-object/from16 v1, v27

    check-cast v1, Long;

    iput-object v4, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v7, v5, Laak;->E:Lixe;

    iput-object v8, v5, Laak;->F:Lpng;

    iput-object v9, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_3af3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3ad9 .. :try_end_3af3} :catch_3c28
    .catch Ljava/lang/Exception; {:try_start_3ad9 .. :try_end_3af3} :catch_3c20
    .catchall {:try_start_3ad9 .. :try_end_3af3} :catchall_3c1b

    move-object/from16 v27, v7

    :try_start_3af5
    move-object/from16 v7, v36

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v7, v41

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->J:Ljava/util/List;
    :try_end_3b01
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3af5 .. :try_end_3b01} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3af5 .. :try_end_3b01} :catch_3c0b
    .catchall {:try_start_3af5 .. :try_end_3b01} :catchall_3b81

    :try_start_3b01
    iput-object v12, v5, Laak;->K:Lixe;

    iput-object v13, v5, Laak;->L:Lixe;

    iput-object v6, v5, Laak;->M:Lexe;

    iput-object v11, v5, Laak;->N:Lexe;

    iput-object v15, v5, Laak;->O:Lexe;

    iput-object v3, v5, Laak;->P:Lixe;

    iput-object v10, v5, Laak;->Q:Lixe;

    iput-object v2, v5, Laak;->R:Lcp2;

    const/4 v7, 0x0

    iput-object v7, v5, Laak;->S:Lpe9;

    iput-object v7, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v7, v33

    iput-object v7, v5, Laak;->V:Ljava/lang/Object;
    :try_end_3b1c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b01 .. :try_end_3b1c} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b01 .. :try_end_3b1c} :catch_3c07
    .catchall {:try_start_3b01 .. :try_end_3b1c} :catchall_3b81

    move-object/from16 v33, v2

    const/4 v2, 0x0

    :try_start_3b1f
    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 v2, p1

    iput-object v2, v5, Laak;->a0:Ljava/lang/Object;

    move-object/from16 v35, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_3b32
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b1f .. :try_end_3b32} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b1f .. :try_end_3b32} :catch_3bf9
    .catchall {:try_start_3b1f .. :try_end_3b32} :catchall_3b81

    move/from16 v2, v107

    :try_start_3b34
    iput v2, v5, Laak;->e0:I
    :try_end_3b36
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b34 .. :try_end_3b36} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b34 .. :try_end_3b36} :catch_3beb
    .catchall {:try_start_3b34 .. :try_end_3b36} :catchall_3b81

    move/from16 v37, v2

    move/from16 v2, v106

    :try_start_3b3a
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_3b3c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b3a .. :try_end_3b3c} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b3a .. :try_end_3b3c} :catch_3bdb
    .catchall {:try_start_3b3a .. :try_end_3b3c} :catchall_3b81

    move/from16 v38, v2

    move/from16 v2, v109

    :try_start_3b40
    iput v2, v5, Laak;->f0:I
    :try_end_3b42
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b40 .. :try_end_3b42} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b40 .. :try_end_3b42} :catch_3bcf
    .catchall {:try_start_3b40 .. :try_end_3b42} :catchall_3b81

    move/from16 v45, v2

    move-object/from16 v43, v3

    move-wide/from16 v2, v104

    :try_start_3b48
    iput-wide v2, v5, Laak;->k0:J
    :try_end_3b4a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b48 .. :try_end_3b4a} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b48 .. :try_end_3b4a} :catch_3bc5
    .catchall {:try_start_3b48 .. :try_end_3b4a} :catchall_3b81

    move-wide/from16 v46, v2

    move/from16 v2, v108

    :try_start_3b4e
    iput v2, v5, Laak;->g0:I
    :try_end_3b50
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b4e .. :try_end_3b50} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b4e .. :try_end_3b50} :catch_3bc1
    .catchall {:try_start_3b4e .. :try_end_3b50} :catchall_3b81

    move/from16 v48, v2

    move-wide/from16 v2, v102

    :try_start_3b54
    iput-wide v2, v5, Laak;->l0:J
    :try_end_3b56
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b54 .. :try_end_3b56} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b54 .. :try_end_3b56} :catch_3bbd
    .catchall {:try_start_3b54 .. :try_end_3b56} :catchall_3b81

    move-object/from16 v52, v12

    const/16 v12, 0x12

    :try_start_3b5a
    iput v12, v5, Laak;->m0:I

    invoke-virtual {v4, v5, v1}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_3b60
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3b5a .. :try_end_3b60} :catch_3bb8
    .catch Ljava/lang/Exception; {:try_start_3b5a .. :try_end_3b60} :catch_3b86
    .catchall {:try_start_3b5a .. :try_end_3b60} :catchall_3b81

    move-object/from16 v12, v53

    if-ne v1, v12, :cond_3b66

    goto/16 :goto_3438

    :cond_3b66
    move-wide/from16 v102, v2

    move-object v1, v7

    move-object/from16 v7, v27

    move-object/from16 v2, v33

    move/from16 v107, v37

    move/from16 v106, v38

    move-object/from16 v3, v43

    move/from16 v109, v45

    move-wide/from16 v104, v46

    move/from16 v108, v48

    move-object/from16 v46, v52

    :goto_3b7b
    move-object/from16 v53, v12

    move-object/from16 p1, v35

    goto/16 :goto_3ad7

    :catchall_3b81
    move-exception v0

    :goto_3b82
    move-object/from16 v1, v27

    goto/16 :goto_772a

    :catch_3b86
    move-exception v0

    :goto_3b87
    move-object/from16 v12, v53

    :goto_3b89
    move-object v1, v4

    move-object v2, v12

    move-object/from16 v17, v13

    move-wide/from16 v56, v25

    move/from16 v7, v30

    move/from16 v35, v38

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-object/from16 v32, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v12, v11

    move-object/from16 v38, v15

    move-object/from16 v15, v52

    move-object v11, v9

    move-object/from16 v52, v43

    move-object v9, v8

    move-object/from16 v43, v10

    move-object/from16 v8, v27

    goto/16 :goto_7437

    :catch_3bb8
    move-exception v0

    :goto_3bb9
    move-object/from16 v1, v27

    goto/16 :goto_7729

    :catch_3bbd
    move-exception v0

    :goto_3bbe
    move-object/from16 v52, v12

    goto :goto_3b87

    :catch_3bc1
    move-exception v0

    move/from16 v48, v2

    goto :goto_3bbe

    :catch_3bc5
    move-exception v0

    move-wide/from16 v46, v2

    move-object/from16 v52, v12

    move-object/from16 v12, v53

    :goto_3bcc
    move/from16 v48, v108

    goto :goto_3b89

    :catch_3bcf
    move-exception v0

    move/from16 v45, v2

    move-object/from16 v43, v3

    move-object/from16 v52, v12

    move-object/from16 v12, v53

    move-wide/from16 v46, v104

    goto :goto_3bcc

    :catch_3bdb
    move-exception v0

    move/from16 v38, v2

    move-object/from16 v43, v3

    move-object/from16 v52, v12

    move-object/from16 v12, v53

    move-wide/from16 v46, v104

    :goto_3be6
    move/from16 v48, v108

    move/from16 v45, v109

    goto :goto_3b89

    :catch_3beb
    move-exception v0

    move/from16 v37, v2

    move-object/from16 v43, v3

    move-object/from16 v52, v12

    move-object/from16 v12, v53

    move-wide/from16 v46, v104

    move/from16 v38, v106

    goto :goto_3be6

    :catch_3bf9
    move-exception v0

    :goto_3bfa
    move-object/from16 v43, v3

    :goto_3bfc
    move-object/from16 v52, v12

    move-object/from16 v12, v53

    move-wide/from16 v46, v104

    move/from16 v38, v106

    move/from16 v37, v107

    goto :goto_3be6

    :catch_3c07
    move-exception v0

    move-object/from16 v33, v2

    goto :goto_3bfa

    :catch_3c0b
    move-exception v0

    move-object/from16 v33, v2

    move-object/from16 v43, v3

    move-object/from16 v52, v12

    move-object/from16 v12, v53

    move-wide/from16 v46, v104

    move/from16 v38, v106

    move/from16 v37, v107

    goto :goto_3be6

    :catchall_3c1b
    move-exception v0

    move-object/from16 v27, v7

    goto/16 :goto_3b82

    :catch_3c20
    move-exception v0

    move-object/from16 v33, v2

    move-object/from16 v43, v3

    move-object/from16 v27, v7

    goto :goto_3bfc

    :catch_3c28
    move-exception v0

    move-object/from16 v27, v7

    goto :goto_3bb9

    :cond_3c2c
    move-object/from16 v33, v2

    move-object/from16 v43, v3

    move-object/from16 v27, v7

    move-object/from16 v52, v12

    move-wide/from16 v2, v102

    move-wide/from16 v46, v104

    move/from16 v38, v106

    move/from16 v37, v107

    move/from16 v48, v108

    move/from16 v45, v109

    move-object v7, v1

    move-object/from16 p1, v15

    move-object v15, v10

    move-object v10, v11

    move-object v11, v14

    move-object v14, v13

    move-object/from16 v13, p1

    move-object/from16 p1, v0

    move-object v0, v7

    move-object/from16 v7, v27

    move-object/from16 v1, v33

    move/from16 v84, v37

    move/from16 v83, v38

    move-object/from16 v58, v42

    move/from16 v86, v45

    move-wide/from16 v81, v46

    move/from16 v85, v48

    move-object/from16 v59, v53

    move-wide/from16 v37, v2

    move-object/from16 v2, v43

    goto/16 :goto_2b92

    :catch_3c64
    move-exception v0

    move-object v12, v13

    move-object/from16 v38, v4

    move-wide/from16 v56, v25

    move-object/from16 v1, v35

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-object/from16 v17, v45

    move-object/from16 v15, v46

    move-object/from16 v32, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move/from16 v35, v2

    move-object v2, v12

    move/from16 v45, v33

    move-wide/from16 v46, v36

    move-object/from16 v36, v48

    move/from16 v48, v3

    move/from16 v37, v6

    move-object v6, v7

    move-object v12, v10

    move-object/from16 v33, v27

    move/from16 v7, v30

    goto/16 :goto_7437

    :catch_3c9b
    move-exception v0

    goto :goto_3ccc

    :goto_3c9d
    move-object/from16 v17, v2

    move-object/from16 v38, v4

    move-object v1, v6

    move-object v6, v7

    move-object v2, v12

    move-wide/from16 v56, v25

    move/from16 v7, v30

    move/from16 v37, v35

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-wide/from16 v46, v45

    move-object/from16 v32, v49

    move/from16 v48, v54

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move/from16 v35, v3

    :goto_3cc6
    move-object v12, v10

    move/from16 v45, v33

    goto/16 :goto_365f

    :catch_3ccb
    move-exception v0

    :goto_3ccc
    move-object/from16 v12, v53

    goto :goto_3c9d

    :catch_3ccf
    move-exception v0

    move/from16 v54, v12

    goto :goto_3ccc

    :catch_3cd3
    move-exception v0

    move-wide/from16 v45, v12

    goto :goto_3ccc

    :catch_3cd7
    move-exception v0

    move-object/from16 v52, v12

    move/from16 v33, v13

    goto :goto_3ccc

    :catch_3cdd
    move-exception v0

    move/from16 v35, v3

    :goto_3ce0
    move-object/from16 v52, v12

    :goto_3ce2
    move/from16 v3, v33

    :goto_3ce4
    move-object/from16 v12, v53

    move/from16 v33, v13

    goto :goto_3c9d

    :catch_3ce9
    move-exception v0

    goto :goto_3ce0

    :catch_3ceb
    move-exception v0

    move-object/from16 v27, v3

    goto :goto_3ce0

    :catch_3cef
    move-exception v0

    move-object/from16 v43, v3

    goto :goto_3ce0

    :catch_3cf3
    move-exception v0

    goto :goto_3ce2

    :catch_3cf5
    move-exception v0

    move/from16 v3, v33

    move-object/from16 v4, v48

    goto :goto_3ce4

    :catch_3cfb
    move-exception v0

    move/from16 v3, v33

    move-object/from16 v4, v48

    goto :goto_3ce4

    :cond_3d01
    move/from16 v3, v33

    move-object/from16 v4, v48

    move-object/from16 v12, v53

    move/from16 v33, v13

    :try_start_3d09
    instance-of v13, v1, Lcom/anthropic/claude/sessions/types/SdkControlCancelRequestEvent;
    :try_end_3d0b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d09 .. :try_end_3d0b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d09 .. :try_end_3d0b} :catch_5169
    .catchall {:try_start_3d09 .. :try_end_3d0b} :catchall_2e20

    if-eqz v13, :cond_3e1b

    :try_start_3d0d
    invoke-virtual/range {v49 .. v49}, Lnlh;->j()Lq98;

    move-result-object v13

    check-cast v1, Lcom/anthropic/claude/sessions/types/SdkControlCancelRequestEvent;

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/SdkControlCancelRequestEvent;->getRequest_id()Ljava/lang/String;

    move-result-object v1

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_3d21
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d0d .. :try_end_3d21} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d0d .. :try_end_3d21} :catch_3df9
    .catchall {:try_start_3d0d .. :try_end_3d21} :catchall_2e20

    move-object/from16 p1, v13

    :try_start_3d23
    move-object/from16 v13, v36

    check-cast v13, Ljava/util/List;

    iput-object v13, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v13, v41

    check-cast v13, Ljava/util/List;

    iput-object v13, v5, Laak;->J:Ljava/util/List;
    :try_end_3d2f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d23 .. :try_end_3d2f} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d23 .. :try_end_3d2f} :catch_3e13
    .catchall {:try_start_3d23 .. :try_end_3d2f} :catchall_2e20

    :try_start_3d2f
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;

    iput-object v4, v5, Laak;->O:Lexe;
    :try_end_3d39
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d2f .. :try_end_3d39} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d2f .. :try_end_3d39} :catch_3df9
    .catchall {:try_start_3d2f .. :try_end_3d39} :catchall_2e20

    move-object/from16 v13, v52

    :try_start_3d3b
    iput-object v13, v5, Laak;->P:Lixe;
    :try_end_3d3d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d3b .. :try_end_3d3d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d3b .. :try_end_3d3d} :catch_3e0d
    .catchall {:try_start_3d3b .. :try_end_3d3d} :catchall_2e20

    move-object/from16 v52, v13

    move-object/from16 v13, v43

    :try_start_3d41
    iput-object v13, v5, Laak;->Q:Lixe;
    :try_end_3d43
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d41 .. :try_end_3d43} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d41 .. :try_end_3d43} :catch_3e07
    .catchall {:try_start_3d41 .. :try_end_3d43} :catchall_2e20

    move-object/from16 v43, v13

    move-object/from16 v13, v27

    :try_start_3d47
    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_3d49
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d47 .. :try_end_3d49} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d47 .. :try_end_3d49} :catch_3e01
    .catchall {:try_start_3d47 .. :try_end_3d49} :catchall_2e20

    move-object/from16 v27, v13

    const/4 v13, 0x0

    :try_start_3d4c
    iput-object v13, v5, Laak;->S:Lpe9;

    iput-object v13, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v13, v47

    iput-object v13, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v47, v13

    const/4 v13, 0x0

    iput-object v13, v5, Laak;->W:Long;

    iput-object v13, v5, Laak;->X:Ljava/lang/Object;

    iput-object v13, v5, Laak;->Y:Ljava/lang/Object;
    :try_end_3d5f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d4c .. :try_end_3d5f} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d4c .. :try_end_3d5f} :catch_3df9
    .catchall {:try_start_3d4c .. :try_end_3d5f} :catchall_2e20

    move/from16 v13, v35

    :try_start_3d61
    iput v13, v5, Laak;->e0:I

    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_3d65
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d61 .. :try_end_3d65} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d61 .. :try_end_3d65} :catch_3df5
    .catchall {:try_start_3d61 .. :try_end_3d65} :catchall_2e20

    move/from16 v35, v3

    move/from16 v3, v33

    :try_start_3d69
    iput v3, v5, Laak;->f0:I
    :try_end_3d6b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d69 .. :try_end_3d6b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d69 .. :try_end_3d6b} :catch_3def
    .catchall {:try_start_3d69 .. :try_end_3d6b} :catchall_2e20

    move/from16 v33, v3

    move-object/from16 v48, v4

    move-wide/from16 v3, v45

    :try_start_3d71
    iput-wide v3, v5, Laak;->k0:J
    :try_end_3d73
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d71 .. :try_end_3d73} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d71 .. :try_end_3d73} :catch_3deb
    .catchall {:try_start_3d71 .. :try_end_3d73} :catchall_2e20

    move-wide/from16 v45, v3

    move/from16 v3, v54

    :try_start_3d77
    iput v3, v5, Laak;->g0:I
    :try_end_3d79
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d77 .. :try_end_3d79} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d77 .. :try_end_3d79} :catch_3de7
    .catchall {:try_start_3d77 .. :try_end_3d79} :catchall_2e20

    move/from16 v54, v3

    move-wide/from16 v3, v37

    :try_start_3d7d
    iput-wide v3, v5, Laak;->l0:J
    :try_end_3d7f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d7d .. :try_end_3d7f} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d7d .. :try_end_3d7f} :catch_3de3
    .catchall {:try_start_3d7d .. :try_end_3d7f} :catchall_2e20

    move-wide/from16 v37, v3

    const/16 v3, 0x13

    :try_start_3d83
    iput v3, v5, Laak;->m0:I

    move-object/from16 v4, p1

    check-cast v4, Lfo;

    invoke-virtual {v4, v1, v5}, Lfo;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_3d8d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d83 .. :try_end_3d8d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3d83 .. :try_end_3d8d} :catch_3de1
    .catchall {:try_start_3d83 .. :try_end_3d8d} :catchall_2e20

    if-ne v1, v12, :cond_3d91

    goto/16 :goto_3438

    :cond_3d91
    move-object v4, v6

    move-object v6, v7

    move-object v7, v8

    move-object v8, v9

    move-object v9, v11

    move/from16 v84, v13

    move-object v11, v14

    move-object/from16 v1, v27

    move/from16 v86, v33

    move/from16 v83, v35

    move-wide/from16 v81, v45

    move-object/from16 v13, v48

    move/from16 v85, v54

    move-object v14, v2

    move-object/from16 v45, v15

    move-object/from16 v15, v43

    move-object/from16 v2, v52

    :goto_3dac
    move-object/from16 p1, v0

    move-object/from16 v59, v12

    move-object/from16 v58, v42

    move-object/from16 v12, v45

    move-object/from16 v0, v47

    goto/16 :goto_2b92

    :goto_3db8
    move-object/from16 v17, v2

    move/from16 v24, v3

    move-object v1, v6

    move-object v6, v7

    move-object v2, v12

    move/from16 v37, v13

    move-wide/from16 v56, v25

    move/from16 v7, v30

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-wide/from16 v46, v45

    move-object/from16 v38, v48

    move-object/from16 v32, v49

    move/from16 v48, v54

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    goto/16 :goto_3cc6

    :catch_3de1
    move-exception v0

    goto :goto_3db8

    :catch_3de3
    move-exception v0

    :goto_3de4
    const/16 v3, 0x13

    goto :goto_3db8

    :catch_3de7
    move-exception v0

    move/from16 v54, v3

    goto :goto_3de4

    :catch_3deb
    move-exception v0

    move-wide/from16 v45, v3

    goto :goto_3de4

    :catch_3def
    move-exception v0

    move/from16 v33, v3

    :goto_3df2
    move-object/from16 v48, v4

    goto :goto_3de4

    :catch_3df5
    move-exception v0

    move/from16 v35, v3

    goto :goto_3df2

    :catch_3df9
    move-exception v0

    move-object/from16 v48, v4

    :goto_3dfc
    move/from16 v13, v35

    move/from16 v35, v3

    goto :goto_3de4

    :catch_3e01
    move-exception v0

    move-object/from16 v48, v4

    move-object/from16 v27, v13

    goto :goto_3dfc

    :catch_3e07
    move-exception v0

    move-object/from16 v48, v4

    move-object/from16 v43, v13

    goto :goto_3dfc

    :catch_3e0d
    move-exception v0

    move-object/from16 v48, v4

    move-object/from16 v52, v13

    goto :goto_3dfc

    :catch_3e13
    move-exception v0

    move-object/from16 v48, v4

    move/from16 v13, v35

    move/from16 v35, v3

    goto :goto_3de4

    :cond_3e1b
    move-object/from16 v48, v4

    move/from16 v13, v35

    move/from16 v35, v3

    const/16 v3, 0x13

    :try_start_3e23
    instance-of v4, v1, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent;
    :try_end_3e25
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e23 .. :try_end_3e25} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e23 .. :try_end_3e25} :catch_5129
    .catchall {:try_start_3e23 .. :try_end_3e25} :catchall_2e20

    if-eqz v4, :cond_438e

    :try_start_3e27
    move-object v4, v1

    check-cast v4, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent;

    invoke-virtual {v4}, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent;->getResponse()Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;

    move-result-object v4

    if-eqz v4, :cond_434c

    invoke-virtual {v4}, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;->getRequest_id()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_434c

    invoke-virtual/range {v49 .. v49}, Lnlh;->j()Lq98;

    move-result-object v22

    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_3e44
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e27 .. :try_end_3e44} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e27 .. :try_end_3e44} :catch_4334
    .catchall {:try_start_3e27 .. :try_end_3e44} :catchall_2e20

    :try_start_3e44
    move-object/from16 v3, v36

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v3, v41

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->J:Ljava/util/List;
    :try_end_3e50
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e44 .. :try_end_3e50} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e44 .. :try_end_3e50} :catch_430c
    .catchall {:try_start_3e44 .. :try_end_3e50} :catchall_2e20

    :try_start_3e50
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;
    :try_end_3e58
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e50 .. :try_end_3e58} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e50 .. :try_end_3e58} :catch_42ea
    .catchall {:try_start_3e50 .. :try_end_3e58} :catchall_2e20

    move-object/from16 v3, v48

    :try_start_3e5a
    iput-object v3, v5, Laak;->O:Lexe;
    :try_end_3e5c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e5a .. :try_end_3e5c} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e5a .. :try_end_3e5c} :catch_42e6
    .catchall {:try_start_3e5a .. :try_end_3e5c} :catchall_2e20

    move-object/from16 v48, v2

    move-object/from16 v2, v52

    :try_start_3e60
    iput-object v2, v5, Laak;->P:Lixe;
    :try_end_3e62
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e60 .. :try_end_3e62} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e60 .. :try_end_3e62} :catch_42e2
    .catchall {:try_start_3e60 .. :try_end_3e62} :catchall_2e20

    move-object/from16 v52, v2

    move-object/from16 v2, v43

    :try_start_3e66
    iput-object v2, v5, Laak;->Q:Lixe;
    :try_end_3e68
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e66 .. :try_end_3e68} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e66 .. :try_end_3e68} :catch_42de
    .catchall {:try_start_3e66 .. :try_end_3e68} :catchall_2e20

    move-object/from16 v43, v2

    move-object/from16 v2, v27

    :try_start_3e6c
    iput-object v2, v5, Laak;->R:Lcp2;
    :try_end_3e6e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e6c .. :try_end_3e6e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e6c .. :try_end_3e6e} :catch_42da
    .catchall {:try_start_3e6c .. :try_end_3e6e} :catchall_2e20

    move-object/from16 v27, v2

    const/4 v2, 0x0

    :try_start_3e71
    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v2, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;
    :try_end_3e77
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e71 .. :try_end_3e77} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e71 .. :try_end_3e77} :catch_42b5
    .catchall {:try_start_3e71 .. :try_end_3e77} :catchall_2e20

    move-object/from16 v2, v47

    :try_start_3e79
    iput-object v2, v5, Laak;->V:Ljava/lang/Object;
    :try_end_3e7b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e79 .. :try_end_3e7b} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e79 .. :try_end_3e7b} :catch_428e
    .catchall {:try_start_3e79 .. :try_end_3e7b} :catchall_2e20

    move-object/from16 v47, v2

    const/4 v2, 0x0

    :try_start_3e7e
    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;
    :try_end_3e82
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e7e .. :try_end_3e82} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e7e .. :try_end_3e82} :catch_42b5
    .catchall {:try_start_3e7e .. :try_end_3e82} :catchall_2e20

    :try_start_3e82
    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;
    :try_end_3e84
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e82 .. :try_end_3e84} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e82 .. :try_end_3e84} :catch_428e
    .catchall {:try_start_3e82 .. :try_end_3e84} :catchall_2e20

    move-object/from16 v2, v49

    :try_start_3e86
    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;
    :try_end_3e88
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e86 .. :try_end_3e88} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e86 .. :try_end_3e88} :catch_427d
    .catchall {:try_start_3e86 .. :try_end_3e88} :catchall_2e20

    move-object/from16 v49, v10

    move-object/from16 v10, v42

    :try_start_3e8c
    iput-object v10, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v4, v5, Laak;->b0:Ljava/lang/Object;

    iput v13, v5, Laak;->e0:I
    :try_end_3e92
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e8c .. :try_end_3e92} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e8c .. :try_end_3e92} :catch_427b
    .catchall {:try_start_3e8c .. :try_end_3e92} :catchall_2e20

    move-object/from16 v42, v1

    move/from16 v1, v35

    :try_start_3e96
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_3e98
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e96 .. :try_end_3e98} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e96 .. :try_end_3e98} :catch_426c
    .catchall {:try_start_3e96 .. :try_end_3e98} :catchall_2e20

    move/from16 v35, v1

    move/from16 v1, v33

    :try_start_3e9c
    iput v1, v5, Laak;->f0:I
    :try_end_3e9e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3e9c .. :try_end_3e9e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3e9c .. :try_end_3e9e} :catch_4249
    .catchall {:try_start_3e9c .. :try_end_3e9e} :catchall_2e20

    move/from16 v55, v1

    move-object/from16 v33, v2

    move-wide/from16 v1, v45

    :try_start_3ea4
    iput-wide v1, v5, Laak;->k0:J
    :try_end_3ea6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3ea4 .. :try_end_3ea6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3ea4 .. :try_end_3ea6} :catch_4245
    .catchall {:try_start_3ea4 .. :try_end_3ea6} :catchall_2e20

    move-wide/from16 v45, v1

    move/from16 v1, v54

    :try_start_3eaa
    iput v1, v5, Laak;->g0:I
    :try_end_3eac
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3eaa .. :try_end_3eac} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3eaa .. :try_end_3eac} :catch_4241
    .catchall {:try_start_3eaa .. :try_end_3eac} :catchall_2e20

    move/from16 v54, v1

    move-wide/from16 v1, v37

    :try_start_3eb0
    iput-wide v1, v5, Laak;->l0:J

    move-wide/from16 v37, v1

    const/16 v1, 0x14

    iput v1, v5, Laak;->m0:I
    :try_end_3eb8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3eb0 .. :try_end_3eb8} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3eb0 .. :try_end_3eb8} :catch_421f
    .catchall {:try_start_3eb0 .. :try_end_3eb8} :catchall_2e20

    :try_start_3eb8
    move-object/from16 v1, v22

    check-cast v1, Lfo;

    invoke-virtual {v1, v4, v5}, Lfo;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_3ec0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3eb8 .. :try_end_3ec0} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_3eb8 .. :try_end_3ec0} :catch_4202
    .catchall {:try_start_3eb8 .. :try_end_3ec0} :catchall_2e20

    if-ne v1, v12, :cond_3ec4

    goto/16 :goto_3438

    :cond_3ec4
    move-object/from16 p1, v15

    move-object v15, v9

    move-object/from16 v9, p1

    move-object v2, v3

    move-object v1, v6

    move-object/from16 p1, v10

    move-object/from16 v58, p1

    move-object/from16 v59, v12

    move/from16 v115, v13

    move-object/from16 v22, v33

    move/from16 v114, v35

    move-wide/from16 v112, v45

    move-object/from16 v12, v49

    move-object/from16 v3, v52

    move/from16 v110, v54

    move/from16 v111, v55

    move-object v13, v4

    move-object v10, v7

    move-object v7, v11

    move-object v11, v8

    move-object v8, v14

    move-wide/from16 v208, v37

    move-object/from16 v37, v0

    move-object/from16 v38, v27

    move-object/from16 v27, v36

    move-wide/from16 v35, v208

    move-object/from16 v0, v47

    move-object/from16 v6, v48

    move-object/from16 v4, v43

    :goto_3ef6
    :try_start_3ef6
    invoke-virtual/range {v22 .. v22}, Lnlh;->f()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v14

    invoke-virtual {v14, v13}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lk7d;

    if-eqz v13, :cond_4185

    invoke-virtual {v13}, Lk7d;->a()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/anthropic/claude/sessions/types/ControlRequestBody;

    invoke-virtual {v13}, Lk7d;->b()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Llq4;

    move-object/from16 v43, v42

    check-cast v43, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent;

    invoke-virtual/range {v43 .. v43}, Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent;->getResponse()Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;

    move-result-object v43

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v11, v5, Laak;->E:Lixe;

    iput-object v15, v5, Laak;->F:Lpng;

    iput-object v7, v5, Laak;->G:Lexe;

    iput-object v8, v5, Laak;->H:Lhxe;
    :try_end_3f20
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3ef6 .. :try_end_3f20} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3ef6 .. :try_end_3f20} :catch_414c
    .catchall {:try_start_3ef6 .. :try_end_3f20} :catchall_4090

    move-object/from16 v45, v1

    :try_start_3f22
    move-object/from16 v1, v27

    check-cast v1, Ljava/util/List;

    iput-object v1, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v1, v41

    check-cast v1, Ljava/util/List;

    iput-object v1, v5, Laak;->J:Ljava/util/List;
    :try_end_3f2e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f22 .. :try_end_3f2e} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3f22 .. :try_end_3f2e} :catch_4126
    .catchall {:try_start_3f22 .. :try_end_3f2e} :catchall_4090

    :try_start_3f2e
    iput-object v9, v5, Laak;->K:Lixe;

    iput-object v6, v5, Laak;->L:Lixe;

    iput-object v10, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v2, v5, Laak;->O:Lexe;

    iput-object v3, v5, Laak;->P:Lixe;

    iput-object v4, v5, Laak;->Q:Lixe;
    :try_end_3f3c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f2e .. :try_end_3f3c} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3f2e .. :try_end_3f3c} :catch_40fc
    .catchall {:try_start_3f2e .. :try_end_3f3c} :catchall_4090

    move-object/from16 v1, v38

    :try_start_3f3e
    iput-object v1, v5, Laak;->R:Lcp2;
    :try_end_3f40
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f3e .. :try_end_3f40} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3f3e .. :try_end_3f40} :catch_4122
    .catchall {:try_start_3f3e .. :try_end_3f40} :catchall_4090

    move-object/from16 v38, v1

    const/4 v1, 0x0

    :try_start_3f43
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    move-object/from16 v1, v37

    iput-object v1, v5, Laak;->U:Lcp2;

    iput-object v0, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v37, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v1, v42

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v42, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v1, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->b0:Ljava/lang/Object;
    :try_end_3f61
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f43 .. :try_end_3f61} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3f43 .. :try_end_3f61} :catch_40fc
    .catchall {:try_start_3f43 .. :try_end_3f61} :catchall_4090

    move-object/from16 v32, v10

    move/from16 v10, v115

    :try_start_3f65
    iput v10, v5, Laak;->e0:I
    :try_end_3f67
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f65 .. :try_end_3f67} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3f65 .. :try_end_3f67} :catch_40d8
    .catchall {:try_start_3f65 .. :try_end_3f67} :catchall_4090

    move/from16 v46, v10

    move/from16 v10, v114

    :try_start_3f6b
    iput-boolean v10, v5, Laak;->i0:Z
    :try_end_3f6d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f6b .. :try_end_3f6d} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3f6b .. :try_end_3f6d} :catch_40b9
    .catchall {:try_start_3f6b .. :try_end_3f6d} :catchall_4090

    move/from16 v47, v10

    move/from16 v10, v111

    :try_start_3f71
    iput v10, v5, Laak;->f0:I
    :try_end_3f73
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f71 .. :try_end_3f73} :catch_40b4
    .catch Ljava/lang/Exception; {:try_start_3f71 .. :try_end_3f73} :catch_4095
    .catchall {:try_start_3f71 .. :try_end_3f73} :catchall_4090

    move/from16 v49, v10

    move-object/from16 v48, v11

    move-wide/from16 v10, v112

    :try_start_3f79
    iput-wide v10, v5, Laak;->k0:J
    :try_end_3f7b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f79 .. :try_end_3f7b} :catch_4035
    .catch Ljava/lang/Exception; {:try_start_3f79 .. :try_end_3f7b} :catch_4075
    .catchall {:try_start_3f79 .. :try_end_3f7b} :catchall_4001

    move-wide/from16 v54, v10

    move/from16 v10, v110

    :try_start_3f7f
    iput v10, v5, Laak;->g0:I
    :try_end_3f81
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f7f .. :try_end_3f81} :catch_4035
    .catch Ljava/lang/Exception; {:try_start_3f7f .. :try_end_3f81} :catch_4066
    .catchall {:try_start_3f7f .. :try_end_3f81} :catchall_4001

    move/from16 v52, v10

    move-wide/from16 v10, v35

    :try_start_3f85
    iput-wide v10, v5, Laak;->l0:J

    const/16 v1, 0x15

    iput v1, v5, Laak;->m0:I
    :try_end_3f8b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3f85 .. :try_end_3f8b} :catch_4035
    .catch Ljava/lang/Exception; {:try_start_3f85 .. :try_end_3f8b} :catch_403a
    .catchall {:try_start_3f85 .. :try_end_3f8b} :catchall_4001

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move-object v7, v13

    move-object/from16 v3, v22

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v8, v43

    move-object/from16 v1, v45

    const/4 v13, 0x6

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x0

    move-object/from16 v45, v2

    move-object v9, v5

    move-object v5, v6

    move-object v6, v14

    move-object/from16 v43, v33

    move-object/from16 v14, v59

    move-object/from16 v2, p1

    :try_start_3fbe
    invoke-static/range {v1 .. v9}, Laak;->d(Lo1e;Leak;Lnlh;Ljava/util/List;Lixe;Lcom/anthropic/claude/sessions/types/ControlRequestBody;Llq4;Lcom/anthropic/claude/sessions/types/SdkControlResponseEvent$Response;Lc75;)Ljava/lang/Object;

    move-result-object v2
    :try_end_3fc2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3fbe .. :try_end_3fc2} :catch_4035
    .catch Ljava/lang/Exception; {:try_start_3fbe .. :try_end_3fc2} :catch_4006
    .catchall {:try_start_3fbe .. :try_end_3fc2} :catchall_4001

    if-ne v2, v14, :cond_3fc7

    move-object v2, v14

    goto/16 :goto_7700

    :cond_3fc7
    move-object v2, v0

    move-object v3, v1

    move-wide v0, v10

    move-object/from16 v10, v42

    move-object/from16 v42, v45

    move/from16 v9, v46

    move/from16 v8, v47

    move-object/from16 v50, v53

    move-wide/from16 v6, v54

    move-object/from16 v45, v5

    move-object/from16 v46, v17

    move-object/from16 v47, v41

    move-object/from16 v41, v44

    :goto_3fde
    move-object/from16 v5, v46

    move/from16 v46, v9

    move-object v9, v15

    move-object v15, v5

    move-object v5, v12

    move-object v12, v10

    move-object v10, v5

    move-object v5, v2

    move-object/from16 v36, v4

    move-wide/from16 v54, v6

    move-object/from16 v4, v42

    move-object/from16 v2, v45

    move-object/from16 v11, v50

    move-object v6, v3

    move-object/from16 v3, v41

    move-object/from16 v41, v47

    move/from16 v47, v8

    move-object/from16 v7, v32

    move/from16 v96, v52

    move-object/from16 v8, v48

    goto/16 :goto_41d3

    :catchall_4001
    move-exception v0

    :goto_4002
    move-object/from16 v1, v48

    goto/16 :goto_772a

    :catch_4006
    move-exception v0

    :goto_4007
    move-object/from16 v36, v4

    move-object v2, v14

    move-object v9, v15

    move-object/from16 v14, v16

    move-object/from16 v15, v17

    move/from16 v7, v30

    move-object/from16 v6, v32

    move-object/from16 v33, v38

    move-object/from16 v4, v40

    move-object/from16 v32, v43

    move-object/from16 v38, v45

    move/from16 v37, v46

    move/from16 v35, v47

    move-object/from16 v8, v48

    move/from16 v45, v49

    move/from16 v48, v52

    move-object/from16 v11, v53

    move-wide/from16 v46, v54

    move-object/from16 v13, v58

    move-object/from16 v17, v5

    move-object/from16 v43, v20

    move-object/from16 v52, v44

    move-object/from16 v5, p0

    goto/16 :goto_7437

    :catch_4035
    move-exception v0

    :goto_4036
    move-object/from16 v1, v48

    goto/16 :goto_7729

    :catch_403a
    move-exception v0

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    :goto_4046
    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v1, v45

    move-object/from16 v14, v59

    :goto_4050
    const/4 v13, 0x6

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x0

    move-object/from16 v45, v2

    goto :goto_4007

    :catch_4066
    move-exception v0

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move/from16 v52, v10

    goto :goto_4046

    :catch_4075
    move-exception v0

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move-wide/from16 v54, v10

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v1, v45

    move-object/from16 v14, v59

    move/from16 v52, v110

    goto :goto_4050

    :catchall_4090
    move-exception v0

    move-object/from16 v48, v11

    goto/16 :goto_4002

    :catch_4095
    move-exception v0

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move/from16 v49, v10

    move-object/from16 v48, v11

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v1, v45

    move-object/from16 v14, v59

    move/from16 v52, v110

    :goto_40b1
    move-wide/from16 v54, v112

    goto :goto_4050

    :catch_40b4
    move-exception v0

    move-object/from16 v48, v11

    goto/16 :goto_4036

    :catch_40b9
    move-exception v0

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move/from16 v47, v10

    move-object/from16 v48, v11

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v1, v45

    move-object/from16 v14, v59

    move/from16 v52, v110

    move/from16 v49, v111

    goto :goto_40b1

    :catch_40d8
    move-exception v0

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move/from16 v46, v10

    move-object/from16 v48, v11

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v1, v45

    move-object/from16 v14, v59

    move/from16 v52, v110

    move/from16 v49, v111

    move-wide/from16 v54, v112

    move/from16 v47, v114

    goto/16 :goto_4050

    :catch_40fc
    move-exception v0

    :goto_40fd
    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move-object/from16 v32, v10

    move-object/from16 v48, v11

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v1, v45

    move-object/from16 v14, v59

    move/from16 v52, v110

    move/from16 v49, v111

    move-wide/from16 v54, v112

    move/from16 v47, v114

    move/from16 v46, v115

    goto/16 :goto_4050

    :catch_4122
    move-exception v0

    move-object/from16 v38, v1

    goto :goto_40fd

    :catch_4126
    move-exception v0

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move-object/from16 v32, v10

    move-object/from16 v48, v11

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v1, v45

    move-object/from16 v14, v59

    move/from16 v52, v110

    move/from16 v49, v111

    move-wide/from16 v54, v112

    move/from16 v47, v114

    move/from16 v46, v115

    goto/16 :goto_4050

    :catch_414c
    move-exception v0

    move-object/from16 v45, v2

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move-object/from16 v32, v10

    move-object/from16 v48, v11

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-object/from16 v14, v59

    move/from16 v52, v110

    move/from16 v49, v111

    move-wide/from16 v54, v112

    move/from16 v47, v114

    move/from16 v46, v115

    const/4 v13, 0x6

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x0

    goto/16 :goto_4007

    :cond_4185
    move-object/from16 v45, v2

    move-object/from16 v44, v3

    move-object/from16 v20, v4

    move-object v5, v6

    move-object/from16 v53, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v9

    move-object/from16 v32, v10

    move-object/from16 v48, v11

    move-wide/from16 v56, v25

    move-object/from16 v4, v27

    move-object/from16 v43, v33

    move-wide/from16 v10, v35

    move-object/from16 v14, v59

    move/from16 v52, v110

    move/from16 v49, v111

    move-wide/from16 v54, v112

    move/from16 v47, v114

    move/from16 v46, v115

    const/4 v13, 0x6

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x0

    move-object v6, v1

    move-object/from16 v36, v4

    move-object v2, v5

    move-object v9, v15

    move-object/from16 v15, v17

    move-object/from16 v4, v45

    move-object v5, v0

    move-wide v0, v10

    move-object v10, v12

    move-object/from16 v12, v42

    move-object/from16 v11, v53

    move-object/from16 v7, v32

    move-object/from16 v8, v48

    move/from16 v96, v52

    :goto_41d3
    move-object/from16 v52, v3

    move-object/from16 v17, v4

    move-object/from16 v42, v12

    move-object/from16 v32, v15

    move/from16 v4, v30

    move/from16 v13, v34

    move-object/from16 v27, v38

    move-object/from16 v12, v43

    move/from16 v15, v46

    move-wide/from16 v45, v54

    const/4 v3, 0x0

    move-object/from16 v30, v16

    move/from16 v55, v49

    move-object/from16 v49, v10

    move-object/from16 v10, v40

    move-object/from16 v208, v5

    move-object/from16 v5, p0

    move-object/from16 v209, v14

    move-object/from16 v14, v208

    move-wide/from16 v210, v0

    move-object/from16 v1, v209

    move-object/from16 v0, v37

    move-wide/from16 v37, v210

    goto/16 :goto_4383

    :catch_4202
    move-exception v0

    goto :goto_4220

    :goto_4204
    move/from16 v37, v2

    move-object/from16 v32, v12

    move-object/from16 v38, v17

    move-object/from16 v33, v27

    move-wide/from16 v46, v45

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    move/from16 v48, v54

    move/from16 v45, v55

    move-object/from16 v13, v58

    move-object v2, v1

    move-object v1, v6

    move-object v6, v7

    move v7, v4

    move-object v4, v10

    goto/16 :goto_7437

    :catch_421f
    move-exception v0

    :goto_4220
    move-object/from16 v17, v3

    move-object/from16 v58, v10

    move-object v1, v12

    move v2, v13

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move-object/from16 v12, v33

    move-object/from16 v10, v40

    const/4 v3, 0x0

    const/4 v13, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    goto :goto_4204

    :catch_4241
    move-exception v0

    move/from16 v54, v1

    goto :goto_4220

    :catch_4245
    move-exception v0

    move-wide/from16 v45, v1

    goto :goto_4220

    :catch_4249
    move-exception v0

    move/from16 v55, v1

    move-object/from16 v17, v3

    move-object/from16 v58, v10

    move-object v1, v12

    move-wide/from16 v56, v25

    move/from16 v4, v30

    :goto_4255
    move-object/from16 v10, v40

    :goto_4257
    const/4 v3, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v12, v2

    move v2, v13

    :goto_426a
    const/4 v13, 0x0

    goto :goto_4204

    :catch_426c
    move-exception v0

    move/from16 v35, v1

    :goto_426f
    move-object/from16 v17, v3

    move-object/from16 v58, v10

    move-object v1, v12

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    goto :goto_4255

    :catch_427b
    move-exception v0

    goto :goto_426f

    :catch_427d
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v49, v10

    move-object v1, v12

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v10, v40

    move-object/from16 v58, v42

    goto :goto_4257

    :catch_428e
    move-exception v0

    :goto_428f
    move-object/from16 v17, v3

    move-object v1, v12

    move v2, v13

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v58, v42

    move-object/from16 v12, v49

    const/4 v3, 0x0

    const/4 v13, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v49, v10

    move-object/from16 v10, v40

    goto/16 :goto_4204

    :catch_42b5
    move-exception v0

    move-object/from16 v17, v3

    move-object v1, v12

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v58, v42

    move-object/from16 v12, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object v3, v2

    :goto_42d4
    move-object/from16 v49, v10

    move v2, v13

    move-object/from16 v10, v40

    goto :goto_426a

    :catch_42da
    move-exception v0

    move-object/from16 v27, v2

    goto :goto_428f

    :catch_42de
    move-exception v0

    move-object/from16 v43, v2

    goto :goto_428f

    :catch_42e2
    move-exception v0

    move-object/from16 v52, v2

    goto :goto_428f

    :catch_42e6
    move-exception v0

    move-object/from16 v48, v2

    goto :goto_428f

    :catch_42ea
    move-exception v0

    move-object v1, v12

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v58, v42

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    const/4 v3, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    :goto_4301
    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v48, v2

    goto :goto_42d4

    :catch_430c
    move-exception v0

    move-object v1, v12

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v58, v42

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    const/4 v3, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v48, v2

    move-object/from16 v49, v10

    move v2, v13

    move-object/from16 v10, v40

    goto/16 :goto_426a

    :catch_4334
    move-exception v0

    move/from16 v24, v3

    move-object v1, v12

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v58, v42

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    const/4 v3, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    goto :goto_4301

    :cond_434c
    move/from16 v24, v3

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v58, v42

    move-object/from16 v17, v48

    const/4 v3, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v42, v1

    move-object/from16 v48, v2

    move-object v1, v12

    move v2, v13

    move-object/from16 v12, v49

    const/4 v13, 0x0

    move-object/from16 v49, v10

    move-object/from16 v10, v40

    move-object/from16 v30, v14

    move-object/from16 v32, v15

    move-object/from16 v20, v43

    move-object/from16 v14, v47

    move/from16 v96, v54

    move v15, v2

    move/from16 v47, v35

    move-object/from16 v2, v48

    :goto_4383
    move-object/from16 v48, v2

    move v2, v15

    move-object/from16 v15, v32

    move-object/from16 v32, v14

    :goto_438a
    move-object v14, v0

    move-object/from16 v0, v42

    goto :goto_43c1

    :cond_438e
    move/from16 v24, v3

    move-wide/from16 v56, v25

    move/from16 v4, v30

    move/from16 v55, v33

    move-object/from16 v58, v42

    move-object/from16 v17, v48

    const/4 v3, 0x0

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v42, v1

    move-object/from16 v48, v2

    move-object v1, v12

    move v2, v13

    move-object/from16 v12, v49

    const/4 v13, 0x0

    move-object/from16 v49, v10

    move-object/from16 v10, v40

    move-object/from16 v30, v14

    move-object/from16 v20, v43

    move-object/from16 v32, v47

    move/from16 v96, v54

    move/from16 v47, v35

    goto :goto_438a

    :goto_43c1
    :try_start_43c1
    new-instance v33, Ljava/util/ArrayList;

    invoke-direct/range {v33 .. v33}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v12}, Lnlh;->a()Z

    move-result v34
    :try_end_43ca
    .catch Ljava/util/concurrent/CancellationException; {:try_start_43c1 .. :try_end_43ca} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_43c1 .. :try_end_43ca} :catch_511c
    .catchall {:try_start_43c1 .. :try_end_43ca} :catchall_2e20

    if-eqz v34, :cond_4727

    :try_start_43cc
    instance-of v4, v0, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;

    if-eqz v4, :cond_4727

    move-object v4, v0

    check-cast v4, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;

    invoke-virtual {v4}, Lcom/anthropic/claude/sessions/types/SdkMessageEvent;->getMessage()Lcom/anthropic/claude/sessions/types/SdkMessage;

    move-result-object v4

    instance-of v13, v4, Lcom/anthropic/claude/sessions/types/SdkNonAssistantMessage;
    :try_end_43d9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_43cc .. :try_end_43d9} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_43cc .. :try_end_43d9} :catch_46ff
    .catchall {:try_start_43cc .. :try_end_43d9} :catchall_2e20

    if-eqz v13, :cond_43ff

    :try_start_43db
    check-cast v4, Lcom/anthropic/claude/sessions/types/SdkNonAssistantMessage;
    :try_end_43dd
    .catch Ljava/util/concurrent/CancellationException; {:try_start_43db .. :try_end_43dd} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_43db .. :try_end_43dd} :catch_43de
    .catchall {:try_start_43db .. :try_end_43dd} :catchall_2e20

    goto :goto_4400

    :catch_43de
    move-exception v0

    move/from16 v37, v2

    move-object v4, v10

    move-object/from16 v32, v12

    move-object/from16 v38, v17

    move-object/from16 v43, v20

    move-object/from16 v33, v27

    move-object/from16 v14, v30

    move/from16 v35, v47

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    move-object/from16 v13, v58

    move/from16 v48, v96

    move-object v2, v1

    move-object v1, v6

    move-object v6, v7

    move-wide/from16 v46, v45

    move/from16 v45, v55

    goto/16 :goto_42e

    :cond_43ff
    move-object v4, v3

    :goto_4400
    if-eqz v4, :cond_4727

    :try_start_4402
    invoke-virtual {v4}, Lcom/anthropic/claude/sessions/types/SdkNonAssistantMessage;->getContent()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_4727

    check-cast v4, Ljava/lang/Iterable;

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4
    :try_end_440e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4402 .. :try_end_440e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_4402 .. :try_end_440e} :catch_46ff
    .catchall {:try_start_4402 .. :try_end_440e} :catchall_2e20

    move-object/from16 v53, v1

    move/from16 v120, v2

    move-object/from16 v44, v10

    move-object v13, v11

    move-object/from16 p1, v12

    move-object v2, v14

    move-object/from16 v1, v17

    move-object/from16 v14, v30

    move-wide/from16 v116, v45

    move/from16 v119, v47

    move-object/from16 v3, v48

    move/from16 v118, v55

    move/from16 v121, v96

    move-object/from16 v30, v4

    move-object v4, v6

    move-object v10, v7

    move-object v11, v9

    move-object/from16 v17, p1

    move-object/from16 v7, v20

    move-object/from16 v9, v27

    move-object/from16 v27, v32

    move-object/from16 v12, v49

    move-object/from16 v6, v52

    move-object/from16 v20, v0

    move-object/from16 v0, v33

    move-wide/from16 v32, v37

    :goto_443d
    :try_start_443d
    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->hasNext()Z

    move-result v35

    if-eqz v35, :cond_46c5

    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v35

    move-object/from16 v37, v2

    move-object/from16 v2, v35

    check-cast v2, Lcom/anthropic/claude/sessions/types/SdkMessageContent;
    :try_end_444d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_443d .. :try_end_444d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_443d .. :try_end_444d} :catch_46b1
    .catchall {:try_start_443d .. :try_end_444d} :catchall_2e20

    move-object/from16 v35, v9

    :try_start_444f
    instance-of v9, v2, Lcom/anthropic/claude/sessions/types/SdkToolResultContent;

    if-eqz v9, :cond_469b

    invoke-virtual/range {v17 .. v17}, Lnlh;->k()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v9

    invoke-virtual {v9}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v9, Ljava/lang/Iterable;

    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_4464
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v38
    :try_end_4468
    .catch Ljava/util/concurrent/CancellationException; {:try_start_444f .. :try_end_4468} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_444f .. :try_end_4468} :catch_4677
    .catchall {:try_start_444f .. :try_end_4468} :catchall_2e20

    if-eqz v38, :cond_44b1

    :try_start_446a
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v38

    move-object/from16 v43, v38

    check-cast v43, Ljava/util/Map$Entry;

    move-object/from16 v45, v2

    invoke-interface/range {v43 .. v43}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v43, v45

    check-cast v43, Lcom/anthropic/claude/sessions/types/SdkToolResultContent;

    move-object/from16 v46, v9

    invoke-virtual/range {v43 .. v43}, Lcom/anthropic/claude/sessions/types/SdkToolResultContent;->getTool_use_id()Ljava/lang/String;

    move-result-object v9

    invoke-static {v2, v9}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2
    :try_end_4486
    .catch Ljava/util/concurrent/CancellationException; {:try_start_446a .. :try_end_4486} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_446a .. :try_end_4486} :catch_448e
    .catchall {:try_start_446a .. :try_end_4486} :catchall_2e20

    if-eqz v2, :cond_4489

    goto :goto_44b3

    :cond_4489
    move-object/from16 v2, v45

    move-object/from16 v9, v46

    goto :goto_4464

    :catch_448e
    move-exception v0

    move-object/from16 v32, p1

    move-object/from16 v38, v1

    move-object/from16 v17, v3

    move-object v1, v4

    move-object/from16 v52, v6

    move-object/from16 v43, v7

    :goto_449a
    move-object v6, v10

    move-object v9, v11

    move-object v11, v13

    move-object/from16 v33, v35

    move-object/from16 v4, v44

    move-object/from16 v2, v53

    move-object/from16 v13, v58

    move-wide/from16 v46, v116

    move/from16 v45, v118

    move/from16 v35, v119

    move/from16 v37, v120

    move/from16 v48, v121

    goto/16 :goto_42e

    :cond_44b1
    const/16 v38, 0x0

    :goto_44b3
    :try_start_44b3
    check-cast v38, Ljava/util/Map$Entry;

    if-eqz v38, :cond_467c

    invoke-virtual/range {v17 .. v17}, Lnlh;->e()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v2

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;
    :try_end_44c5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_44b3 .. :try_end_44c5} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_44b3 .. :try_end_44c5} :catch_4677
    .catchall {:try_start_44b3 .. :try_end_44c5} :catchall_2e20

    if-eqz v2, :cond_451a

    :try_start_44c7
    move-object v9, v0

    check-cast v9, Ljava/util/Collection;
    :try_end_44ca
    .catch Ljava/util/concurrent/CancellationException; {:try_start_44c7 .. :try_end_44ca} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_44c7 .. :try_end_44ca} :catch_4516
    .catchall {:try_start_44c7 .. :try_end_44ca} :catchall_2e20

    move-object/from16 v43, v7

    :try_start_44cc
    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    invoke-static {v7, v2}, Lao9;->j0(Ljava/lang/Object;Ljava/lang/Object;)Lk7d;

    move-result-object v2

    invoke-interface {v9, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    invoke-virtual/range {v17 .. v17}, Lnlh;->k()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v2

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {v17 .. v17}, Lnlh;->g()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v2

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {v17 .. v17}, Lnlh;->h()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v2

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {v17 .. v17}, Lnlh;->e()Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v2

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_4503
    .catch Ljava/util/concurrent/CancellationException; {:try_start_44cc .. :try_end_4503} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_44cc .. :try_end_4503} :catch_450b
    .catchall {:try_start_44cc .. :try_end_4503} :catchall_2e20

    move-object/from16 v47, v10

    move-object/from16 v9, v43

    move-object/from16 v2, v53

    goto/16 :goto_468d

    :catch_450b
    move-exception v0

    :goto_450c
    move-object/from16 v32, p1

    move-object/from16 v38, v1

    move-object/from16 v17, v3

    move-object v1, v4

    move-object/from16 v52, v6

    goto :goto_449a

    :catch_4516
    move-exception v0

    move-object/from16 v43, v7

    goto :goto_450c

    :cond_451a
    move-object/from16 v43, v7

    :try_start_451c
    invoke-virtual/range {v17 .. v17}, Lnlh;->j()Lq98;

    move-result-object v2

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v4, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v11, v5, Laak;->F:Lpng;

    iput-object v13, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_4531
    .catch Ljava/util/concurrent/CancellationException; {:try_start_451c .. :try_end_4531} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_451c .. :try_end_4531} :catch_4661
    .catchall {:try_start_451c .. :try_end_4531} :catchall_2e20

    :try_start_4531
    move-object/from16 v9, v36

    check-cast v9, Ljava/util/List;

    iput-object v9, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v9, v41

    check-cast v9, Ljava/util/List;

    iput-object v9, v5, Laak;->J:Ljava/util/List;
    :try_end_453d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4531 .. :try_end_453d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_4531 .. :try_end_453d} :catch_4667
    .catchall {:try_start_4531 .. :try_end_453d} :catchall_2e20

    :try_start_453d
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v3, v5, Laak;->L:Lixe;

    iput-object v10, v5, Laak;->M:Lexe;

    iput-object v12, v5, Laak;->N:Lexe;

    iput-object v1, v5, Laak;->O:Lexe;

    iput-object v6, v5, Laak;->P:Lixe;
    :try_end_4549
    .catch Ljava/util/concurrent/CancellationException; {:try_start_453d .. :try_end_4549} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_453d .. :try_end_4549} :catch_4661
    .catchall {:try_start_453d .. :try_end_4549} :catchall_2e20

    move-object/from16 v9, v43

    :try_start_454b
    iput-object v9, v5, Laak;->Q:Lixe;
    :try_end_454d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_454b .. :try_end_454d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_454b .. :try_end_454d} :catch_465d
    .catchall {:try_start_454b .. :try_end_454d} :catchall_2e20

    move-object/from16 v38, v1

    move-object/from16 v1, v35

    :try_start_4551
    iput-object v1, v5, Laak;->R:Lcp2;
    :try_end_4553
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4551 .. :try_end_4553} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_4551 .. :try_end_4553} :catch_4659
    .catchall {:try_start_4551 .. :try_end_4553} :catchall_2e20

    move-object/from16 v35, v1

    const/4 v1, 0x0

    :try_start_4556
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    move-object/from16 v1, v37

    iput-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v37, v1

    move-object/from16 v1, v27

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v27, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v1, v20

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v0, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 v20, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->a0:Ljava/lang/Object;

    move-object/from16 v1, v17

    iput-object v1, v5, Laak;->b0:Ljava/lang/Object;

    move-object/from16 v17, v1

    move-object/from16 v1, v30

    iput-object v1, v5, Laak;->c0:Ljava/util/Iterator;

    move-object/from16 v30, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->d0:Long;
    :try_end_4585
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4556 .. :try_end_4585} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_4556 .. :try_end_4585} :catch_464d
    .catchall {:try_start_4556 .. :try_end_4585} :catchall_2e20

    move/from16 v1, v120

    :try_start_4587
    iput v1, v5, Laak;->e0:I
    :try_end_4589
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4587 .. :try_end_4589} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_4587 .. :try_end_4589} :catch_4641
    .catchall {:try_start_4587 .. :try_end_4589} :catchall_2e20

    move/from16 v43, v1

    move/from16 v1, v119

    :try_start_458d
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_458f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_458d .. :try_end_458f} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_458d .. :try_end_458f} :catch_4637
    .catchall {:try_start_458d .. :try_end_458f} :catchall_2e20

    move/from16 v45, v1

    move/from16 v1, v118

    :try_start_4593
    iput v1, v5, Laak;->f0:I
    :try_end_4595
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4593 .. :try_end_4595} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_4593 .. :try_end_4595} :catch_462f
    .catchall {:try_start_4593 .. :try_end_4595} :catchall_2e20

    move/from16 v47, v1

    move-object/from16 v46, v2

    move-wide/from16 v1, v116

    :try_start_459b
    iput-wide v1, v5, Laak;->k0:J
    :try_end_459d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_459b .. :try_end_459d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_459b .. :try_end_459d} :catch_4627
    .catchall {:try_start_459b .. :try_end_459d} :catchall_2e20

    move-wide/from16 v48, v1

    move/from16 v1, v121

    :try_start_45a1
    iput v1, v5, Laak;->g0:I
    :try_end_45a3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_45a1 .. :try_end_45a3} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_45a1 .. :try_end_45a3} :catch_4623
    .catchall {:try_start_45a1 .. :try_end_45a3} :catchall_2e20

    move/from16 v50, v1

    move-wide/from16 v1, v32

    :try_start_45a7
    iput-wide v1, v5, Laak;->l0:J

    move-wide/from16 v32, v1

    const/16 v1, 0x16

    iput v1, v5, Laak;->m0:I
    :try_end_45af
    .catch Ljava/util/concurrent/CancellationException; {:try_start_45a7 .. :try_end_45af} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_45a7 .. :try_end_45af} :catch_461f
    .catchall {:try_start_45a7 .. :try_end_45af} :catchall_2e20

    :try_start_45af
    move-object/from16 v2, v46

    check-cast v2, Lfo;

    invoke-virtual {v2, v7, v5}, Lfo;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_45b7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_45af .. :try_end_45b7} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_45af .. :try_end_45b7} :catch_45fe
    .catchall {:try_start_45af .. :try_end_45b7} :catchall_2e20

    move-object/from16 v2, v53

    if-ne v1, v2, :cond_45bd

    goto/16 :goto_7700

    :cond_45bd
    move-object/from16 v1, v35

    move-object/from16 v35, v4

    move-object v4, v1

    move/from16 v1, v47

    move-object/from16 v47, v10

    move v10, v1

    move-object/from16 v54, v11

    move-object/from16 v46, v12

    move-object/from16 v53, v13

    move/from16 v13, v45

    move-wide/from16 v11, v48

    move/from16 v7, v50

    move-object/from16 v48, v3

    move-object/from16 v45, v38

    move-object/from16 v50, v41

    move-object v3, v0

    move-wide/from16 v0, v32

    :goto_45dc
    move-object/from16 v41, v35

    move-object/from16 v35, v4

    move-object/from16 v4, v41

    move/from16 v121, v7

    move/from16 v118, v10

    move-wide/from16 v116, v11

    move/from16 v119, v13

    move/from16 v120, v43

    move-object/from16 v12, v46

    move-object/from16 v41, v50

    move-object/from16 v13, v53

    move-object/from16 v11, v54

    move-object v10, v8

    move-object v8, v6

    move-wide v6, v0

    move-object v0, v3

    move-object/from16 v1, v45

    move-object/from16 v3, v48

    goto/16 :goto_4691

    :catch_45fe
    move-exception v0

    goto :goto_4620

    :goto_4600
    move-object/from16 v32, p1

    move-object/from16 v17, v3

    move-object v1, v4

    move-object/from16 v52, v6

    move-object v6, v10

    move-object/from16 v33, v35

    move/from16 v37, v43

    move-object/from16 v4, v44

    move/from16 v35, v45

    move/from16 v45, v47

    move-wide/from16 v46, v48

    move/from16 v48, v50

    const/4 v7, 0x1

    move-object/from16 v43, v9

    move-object v9, v11

    move-object v11, v13

    :goto_461b
    move-object/from16 v13, v58

    goto/16 :goto_7437

    :catch_461f
    move-exception v0

    :goto_4620
    move-object/from16 v2, v53

    goto :goto_4600

    :catch_4623
    move-exception v0

    move/from16 v50, v1

    goto :goto_4620

    :catch_4627
    move-exception v0

    move-wide/from16 v48, v1

    move-object/from16 v2, v53

    :goto_462c
    move/from16 v50, v121

    goto :goto_4600

    :catch_462f
    move-exception v0

    move/from16 v47, v1

    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    goto :goto_462c

    :catch_4637
    move-exception v0

    move/from16 v45, v1

    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    move/from16 v47, v118

    goto :goto_462c

    :catch_4641
    move-exception v0

    move/from16 v43, v1

    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    move/from16 v47, v118

    move/from16 v45, v119

    goto :goto_462c

    :catch_464d
    move-exception v0

    :goto_464e
    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    move/from16 v47, v118

    move/from16 v45, v119

    move/from16 v43, v120

    goto :goto_462c

    :catch_4659
    move-exception v0

    move-object/from16 v35, v1

    goto :goto_464e

    :catch_465d
    move-exception v0

    move-object/from16 v38, v1

    goto :goto_464e

    :catch_4661
    move-exception v0

    move-object/from16 v38, v1

    move-object/from16 v9, v43

    goto :goto_464e

    :catch_4667
    move-exception v0

    move-object/from16 v38, v1

    move-object/from16 v9, v43

    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    move/from16 v47, v118

    move/from16 v45, v119

    move/from16 v43, v120

    goto :goto_462c

    :catch_4677
    move-exception v0

    move-object/from16 v38, v1

    move-object v9, v7

    goto :goto_464e

    :cond_467c
    move-object/from16 v38, v1

    move-object v9, v7

    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    move/from16 v47, v118

    move/from16 v45, v119

    move/from16 v43, v120

    move/from16 v50, v121

    move-object/from16 v47, v10

    :goto_468d
    move-object v10, v8

    move-object v8, v6

    move-wide/from16 v6, v32

    :goto_4691
    move-wide/from16 v32, v6

    move-object v6, v8

    move-object v8, v10

    move-object/from16 v10, v47

    move-object v7, v9

    :goto_4698
    move-object/from16 v9, v35

    goto :goto_46ab

    :cond_469b
    move-object/from16 v38, v1

    move-object v9, v7

    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    move/from16 v47, v118

    move/from16 v45, v119

    move/from16 v43, v120

    move/from16 v50, v121

    goto :goto_4698

    :goto_46ab
    move-object/from16 v53, v2

    move-object/from16 v2, v37

    goto/16 :goto_443d

    :catch_46b1
    move-exception v0

    move-object/from16 v38, v1

    move-object/from16 v35, v9

    move-object/from16 v2, v53

    move-wide/from16 v48, v116

    move/from16 v47, v118

    move/from16 v45, v119

    move/from16 v43, v120

    move/from16 v50, v121

    move-object v9, v7

    goto/16 :goto_4600

    :cond_46c5
    move-object/from16 v38, v1

    move-object/from16 v37, v2

    move-object/from16 v35, v9

    move-wide/from16 v48, v116

    move/from16 v47, v118

    move/from16 v45, v119

    move/from16 v43, v120

    move/from16 v50, v121

    move-object v9, v7

    move-object/from16 v52, v6

    move-object v7, v10

    move-object/from16 v30, v14

    move-object/from16 v14, v37

    move-object/from16 v17, v38

    move/from16 v2, v43

    move/from16 v55, v47

    move/from16 v96, v50

    move-object v6, v4

    move-wide/from16 v37, v32

    move/from16 v47, v45

    move-wide/from16 v45, v48

    move-object/from16 v33, v0

    move-object/from16 v48, v3

    move-object/from16 v49, v12

    move-object/from16 v0, v20

    move-object/from16 v32, v27

    move-object/from16 v27, v35

    move-object/from16 v3, v53

    move-object/from16 v20, v9

    move-object v9, v11

    move-object v11, v13

    goto :goto_472c

    :catch_46ff
    move-exception v0

    move-object v3, v1

    move-object/from16 v44, v10

    move-object/from16 p1, v12

    move-object/from16 v32, p1

    move/from16 v37, v2

    move-object v2, v3

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v38, v17

    move-object/from16 v43, v20

    move-object/from16 v33, v27

    move-object/from16 v14, v30

    move-object/from16 v4, v44

    move/from16 v35, v47

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    move-object/from16 v13, v58

    move/from16 v48, v96

    const/4 v7, 0x1

    :goto_4721
    move-wide/from16 v46, v45

    move/from16 v45, v55

    goto/16 :goto_7437

    :cond_4727
    move-object v3, v1

    move-object/from16 v44, v10

    move-object/from16 p1, v12

    :goto_472c
    move-object v1, v6

    :try_start_472d
    invoke-virtual/range {p1 .. p1}, Lnlh;->c()Lhhg;

    move-result-object v4

    invoke-virtual {v4, v0}, Lhhg;->l(Lcom/anthropic/claude/sessions/types/SdkEvent;)Ljava/util/List;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, Lnlh;->l()Lc98;

    move-result-object v6

    check-cast v6, Lmff;

    invoke-virtual {v6, v4}, Lmff;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-object v6, v4

    check-cast v6, Ljava/lang/Iterable;

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6
    :try_end_4745
    .catch Ljava/util/concurrent/CancellationException; {:try_start_472d .. :try_end_4745} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_472d .. :try_end_4745} :catch_50f8
    .catchall {:try_start_472d .. :try_end_4745} :catchall_2e20

    move/from16 v126, v2

    move-object/from16 v53, v3

    move-object v10, v8

    move-object v12, v11

    move-object/from16 v13, v30

    move-object/from16 v30, v32

    move-wide/from16 v122, v45

    move/from16 v125, v47

    move-object/from16 v3, v49

    move-object/from16 v2, v52

    move/from16 v124, v55

    move/from16 v127, v96

    move-object v8, v7

    move-object v11, v9

    move-object/from16 v7, v27

    move-object/from16 v27, v0

    move-object v9, v1

    move-object v0, v4

    move-object v4, v14

    move-object/from16 v1, v17

    move-object/from16 v14, v48

    move-object/from16 v17, v6

    move-object/from16 v6, v20

    move-object/from16 v20, v33

    move-wide/from16 v32, v37

    :goto_4770
    :try_start_4770
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v35
    :try_end_4774
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4770 .. :try_end_4774} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4770 .. :try_end_4774} :catch_50cc
    .catchall {:try_start_4770 .. :try_end_4774} :catchall_478d

    if-eqz v35, :cond_491a

    :try_start_4776
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v35

    move-object/from16 v37, v4

    move-object/from16 v4, v35

    check-cast v4, Long;
    :try_end_4780
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4776 .. :try_end_4780} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4776 .. :try_end_4780} :catch_4900
    .catchall {:try_start_4776 .. :try_end_4780} :catchall_478d

    move-object/from16 v35, v7

    :try_start_4782
    instance-of v7, v4, Lmng;
    :try_end_4784
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4782 .. :try_end_4784} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4782 .. :try_end_4784} :catch_4904
    .catchall {:try_start_4782 .. :try_end_4784} :catchall_478d

    if-eqz v7, :cond_47ba

    const/4 v7, 0x0

    :try_start_4787
    iput-object v7, v15, Lixe;->E:Ljava/lang/Object;

    const/4 v7, 0x0

    iput-boolean v7, v8, Lexe;->E:Z
    :try_end_478c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4787 .. :try_end_478c} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4787 .. :try_end_478c} :catch_4791
    .catchall {:try_start_4787 .. :try_end_478c} :catchall_478d

    goto :goto_47ba

    :catchall_478d
    move-exception v0

    move-object v1, v10

    goto/16 :goto_772a

    :catch_4791
    move-exception v0

    move-object/from16 v32, p1

    move-object/from16 v38, v1

    move-object/from16 v52, v2

    move-object/from16 v43, v6

    move-object v6, v8

    move-object v1, v9

    move-object v8, v10

    move-object v9, v11

    move-object v11, v12

    move-object/from16 v17, v14

    move-object/from16 v33, v35

    move-object/from16 v4, v44

    move-object/from16 v2, v53

    move-wide/from16 v46, v122

    move/from16 v45, v124

    move/from16 v35, v125

    move/from16 v37, v126

    move/from16 v48, v127

    const/4 v7, 0x1

    :goto_47b2
    move-object v12, v3

    move-object v14, v13

    goto/16 :goto_461b

    :catch_47b6
    move-exception v0

    move-object v1, v10

    goto/16 :goto_7729

    :cond_47ba
    :goto_47ba
    :try_start_47ba
    iput-object v9, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v10, v5, Laak;->E:Lixe;

    iput-object v11, v5, Laak;->F:Lpng;

    iput-object v12, v5, Laak;->G:Lexe;

    iput-object v13, v5, Laak;->H:Lhxe;

    move-object/from16 v7, v36

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v7, v41

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->J:Ljava/util/List;

    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v14, v5, Laak;->L:Lixe;

    iput-object v8, v5, Laak;->M:Lexe;

    iput-object v3, v5, Laak;->N:Lexe;

    iput-object v1, v5, Laak;->O:Lexe;

    iput-object v2, v5, Laak;->P:Lixe;

    iput-object v6, v5, Laak;->Q:Lixe;
    :try_end_47de
    .catch Ljava/util/concurrent/CancellationException; {:try_start_47ba .. :try_end_47de} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_47ba .. :try_end_47de} :catch_4904
    .catchall {:try_start_47ba .. :try_end_47de} :catchall_478d

    move-object/from16 v7, v35

    :try_start_47e0
    iput-object v7, v5, Laak;->R:Lcp2;
    :try_end_47e2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_47e0 .. :try_end_47e2} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_47e0 .. :try_end_47e2} :catch_4900
    .catchall {:try_start_47e0 .. :try_end_47e2} :catchall_478d

    move-object/from16 v35, v1

    const/4 v1, 0x0

    :try_start_47e5
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    move-object/from16 v1, v37

    iput-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v37, v1

    move-object/from16 v1, v30

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v30, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v1, v27

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v27, v1

    move-object/from16 v1, v20

    iput-object v1, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v0, v5, Laak;->a0:Ljava/lang/Object;

    move-object/from16 v20, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->b0:Ljava/lang/Object;

    move-object/from16 v1, v17

    iput-object v1, v5, Laak;->c0:Ljava/util/Iterator;

    iput-object v4, v5, Laak;->d0:Long;
    :try_end_4811
    .catch Ljava/util/concurrent/CancellationException; {:try_start_47e5 .. :try_end_4811} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_47e5 .. :try_end_4811} :catch_48f2
    .catchall {:try_start_47e5 .. :try_end_4811} :catchall_478d

    move-object/from16 v17, v1

    move/from16 v1, v126

    :try_start_4815
    iput v1, v5, Laak;->e0:I
    :try_end_4817
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4815 .. :try_end_4817} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4815 .. :try_end_4817} :catch_48e4
    .catchall {:try_start_4815 .. :try_end_4817} :catchall_478d

    move/from16 v38, v1

    move/from16 v1, v125

    :try_start_481b
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_481d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_481b .. :try_end_481d} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_481b .. :try_end_481d} :catch_48d8
    .catchall {:try_start_481b .. :try_end_481d} :catchall_478d

    move/from16 v43, v1

    move/from16 v1, v124

    :try_start_4821
    iput v1, v5, Laak;->f0:I
    :try_end_4823
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4821 .. :try_end_4823} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4821 .. :try_end_4823} :catch_48ce
    .catchall {:try_start_4821 .. :try_end_4823} :catchall_478d

    move/from16 v46, v1

    move-object/from16 v45, v2

    move-wide/from16 v1, v122

    :try_start_4829
    iput-wide v1, v5, Laak;->k0:J
    :try_end_482b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4829 .. :try_end_482b} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4829 .. :try_end_482b} :catch_48c6
    .catchall {:try_start_4829 .. :try_end_482b} :catchall_478d

    move-wide/from16 v47, v1

    move/from16 v1, v127

    :try_start_482f
    iput v1, v5, Laak;->g0:I
    :try_end_4831
    .catch Ljava/util/concurrent/CancellationException; {:try_start_482f .. :try_end_4831} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_482f .. :try_end_4831} :catch_48c2
    .catchall {:try_start_482f .. :try_end_4831} :catchall_478d

    move/from16 v49, v1

    move-wide/from16 v1, v32

    :try_start_4835
    iput-wide v1, v5, Laak;->l0:J

    move-wide/from16 v32, v1

    const/16 v1, 0x17

    iput v1, v5, Laak;->m0:I

    invoke-virtual {v9, v5, v4}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_4841
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4835 .. :try_end_4841} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4835 .. :try_end_4841} :catch_4898
    .catchall {:try_start_4835 .. :try_end_4841} :catchall_478d

    move-object/from16 v2, v53

    if-ne v1, v2, :cond_4847

    goto/16 :goto_7700

    :cond_4847
    move-object/from16 v55, v11

    move-object/from16 v1, v35

    move/from16 v126, v38

    move/from16 v125, v43

    move/from16 v124, v46

    move-wide/from16 v122, v47

    move/from16 v127, v49

    move-object v11, v10

    move-object v10, v4

    move-object/from16 v4, v37

    :goto_4859
    :try_start_4859
    instance-of v10, v10, Lgng;
    :try_end_485b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4859 .. :try_end_485b} :catch_4887
    .catch Ljava/lang/Exception; {:try_start_4859 .. :try_end_485b} :catch_4895
    .catchall {:try_start_4859 .. :try_end_485b} :catchall_4861

    if-eqz v10, :cond_488b

    const/4 v10, 0x1

    :try_start_485e
    iput-boolean v10, v3, Lexe;->E:Z
    :try_end_4860
    .catch Ljava/util/concurrent/CancellationException; {:try_start_485e .. :try_end_4860} :catch_4887
    .catch Ljava/lang/Exception; {:try_start_485e .. :try_end_4860} :catch_4865
    .catchall {:try_start_485e .. :try_end_4860} :catchall_4861

    goto :goto_488c

    :catchall_4861
    move-exception v0

    move-object v1, v11

    goto/16 :goto_772a

    :catch_4865
    move-exception v0

    :goto_4866
    move-object/from16 v32, p1

    move-object/from16 v38, v1

    move-object/from16 v43, v6

    move-object/from16 v33, v7

    move-object v6, v8

    move-object v1, v9

    move v7, v10

    move-object v8, v11

    move-object v11, v12

    move-object/from16 v17, v14

    move-object/from16 v4, v44

    move-object/from16 v52, v45

    move-object/from16 v9, v55

    move-wide/from16 v46, v122

    move/from16 v45, v124

    move/from16 v35, v125

    move/from16 v37, v126

    move/from16 v48, v127

    goto/16 :goto_47b2

    :catch_4887
    move-exception v0

    move-object v1, v11

    goto/16 :goto_7729

    :cond_488b
    const/4 v10, 0x1

    :goto_488c
    move-object/from16 v53, v2

    move-object v10, v11

    move-object/from16 v2, v45

    move-object/from16 v11, v55

    goto/16 :goto_4770

    :catch_4895
    move-exception v0

    const/4 v10, 0x1

    goto :goto_4866

    :catch_4898
    move-exception v0

    :goto_4899
    move-object/from16 v2, v53

    :goto_489b
    const/16 v34, 0x1

    :goto_489d
    move-object/from16 v32, p1

    :goto_489f
    move-object/from16 v33, v7

    move-object v1, v9

    move-object v9, v11

    move-object v11, v12

    move-object/from16 v17, v14

    move/from16 v7, v34

    move/from16 v37, v38

    move-object/from16 v4, v44

    move-object/from16 v52, v45

    move/from16 v45, v46

    move-wide/from16 v46, v47

    move/from16 v48, v49

    :goto_48b4
    move-object v12, v3

    move-object v14, v13

    move-object/from16 v38, v35

    move/from16 v35, v43

    move-object/from16 v13, v58

    move-object/from16 v43, v6

    move-object v6, v8

    move-object v8, v10

    goto/16 :goto_7437

    :catch_48c2
    move-exception v0

    move/from16 v49, v1

    goto :goto_4899

    :catch_48c6
    move-exception v0

    move-wide/from16 v47, v1

    move-object/from16 v2, v53

    :goto_48cb
    move/from16 v49, v127

    goto :goto_489b

    :catch_48ce
    move-exception v0

    move/from16 v46, v1

    move-object/from16 v45, v2

    move-object/from16 v2, v53

    move-wide/from16 v47, v122

    goto :goto_48cb

    :catch_48d8
    move-exception v0

    move/from16 v43, v1

    move-object/from16 v45, v2

    move-object/from16 v2, v53

    move-wide/from16 v47, v122

    move/from16 v46, v124

    goto :goto_48cb

    :catch_48e4
    move-exception v0

    move/from16 v38, v1

    move-object/from16 v45, v2

    move-object/from16 v2, v53

    move-wide/from16 v47, v122

    move/from16 v46, v124

    move/from16 v43, v125

    goto :goto_48cb

    :catch_48f2
    move-exception v0

    :goto_48f3
    move-object/from16 v45, v2

    move-object/from16 v2, v53

    move-wide/from16 v47, v122

    move/from16 v46, v124

    move/from16 v43, v125

    move/from16 v38, v126

    goto :goto_48cb

    :catch_4900
    move-exception v0

    move-object/from16 v35, v1

    goto :goto_48f3

    :catch_4904
    move-exception v0

    move-object/from16 v45, v2

    move-object/from16 v7, v35

    move-object/from16 v2, v53

    move-wide/from16 v47, v122

    move/from16 v46, v124

    move/from16 v43, v125

    move/from16 v38, v126

    move/from16 v49, v127

    const/16 v34, 0x1

    move-object/from16 v35, v1

    goto :goto_489d

    :cond_491a
    move-object/from16 v35, v1

    move-object/from16 v45, v2

    move-object/from16 v37, v4

    move-object/from16 v2, v53

    move-wide/from16 v47, v122

    move/from16 v46, v124

    move/from16 v43, v125

    move/from16 v38, v126

    move/from16 v49, v127

    const/16 v34, 0x1

    :try_start_492e
    check-cast v20, Ljava/lang/Iterable;

    invoke-interface/range {v20 .. v20}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1
    :try_end_4934
    .catch Ljava/util/concurrent/CancellationException; {:try_start_492e .. :try_end_4934} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_492e .. :try_end_4934} :catch_50c5
    .catchall {:try_start_492e .. :try_end_4934} :catchall_478d

    move-object/from16 v20, v0

    move-object/from16 v17, v1

    move-object/from16 v53, v2

    move-object v4, v6

    move-object v1, v14

    move-object v2, v15

    move-wide/from16 v128, v32

    move-object/from16 v0, v37

    move/from16 v133, v38

    move/from16 v132, v43

    move-object/from16 v6, v45

    move/from16 v135, v46

    move-wide/from16 v130, v47

    move/from16 v134, v49

    move-object v14, v3

    move-object v15, v13

    move-object/from16 v3, v30

    move-object/from16 v13, v35

    :goto_4953
    :try_start_4953
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v30
    :try_end_4957
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4953 .. :try_end_4957} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4953 .. :try_end_4957} :catch_50ac
    .catchall {:try_start_4953 .. :try_end_4957} :catchall_478d

    if-eqz v30, :cond_4ec0

    :try_start_4959
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v30

    check-cast v30, Lk7d;

    invoke-virtual/range {v30 .. v30}, Lk7d;->a()Ljava/lang/Object;

    move-result-object v32

    move-object/from16 v33, v3

    move-object/from16 v3, v32

    check-cast v3, Ljava/lang/String;

    invoke-virtual/range {v30 .. v30}, Lk7d;->b()Ljava/lang/Object;

    move-result-object v30
    :try_end_496d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4959 .. :try_end_496d} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4959 .. :try_end_496d} :catch_4eb5
    .catchall {:try_start_4959 .. :try_end_496d} :catchall_478d

    move-object/from16 v32, v7

    :try_start_496f
    move-object/from16 v7, v30

    check-cast v7, Ljava/lang/String;
    :try_end_4973
    .catch Ljava/util/concurrent/CancellationException; {:try_start_496f .. :try_end_4973} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_496f .. :try_end_4973} :catch_4eac
    .catchall {:try_start_496f .. :try_end_4973} :catchall_478d

    move-object/from16 v30, v4

    :try_start_4975
    move-object/from16 v4, v20

    check-cast v4, Ljava/lang/Iterable;
    :try_end_4979
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4975 .. :try_end_4979} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4975 .. :try_end_4979} :catch_4ea1
    .catchall {:try_start_4975 .. :try_end_4979} :catchall_478d

    move-object/from16 v35, v6

    :try_start_497b
    instance-of v6, v4, Ljava/util/Collection;
    :try_end_497d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_497b .. :try_end_497d} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_497b .. :try_end_497d} :catch_4e5b
    .catchall {:try_start_497b .. :try_end_497d} :catchall_478d

    if-eqz v6, :cond_49b2

    :try_start_497f
    move-object v6, v4

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6
    :try_end_4986
    .catch Ljava/util/concurrent/CancellationException; {:try_start_497f .. :try_end_4986} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_497f .. :try_end_4986} :catch_498b
    .catchall {:try_start_497f .. :try_end_4986} :catchall_478d

    if-eqz v6, :cond_49b2

    :cond_4988
    const/4 v4, 0x0

    goto/16 :goto_49fc

    :catch_498b
    move-exception v0

    move-object/from16 v17, v1

    move-object v6, v8

    move-object v1, v9

    move-object v8, v10

    move-object v9, v11

    move-object v11, v12

    move-object/from16 v38, v13

    move-object v12, v14

    move-object v14, v15

    move-object/from16 v43, v30

    move-object/from16 v33, v32

    move/from16 v7, v34

    move-object/from16 v52, v35

    move-object/from16 v4, v44

    move-object/from16 v13, v58

    move-wide/from16 v46, v130

    move/from16 v35, v132

    move/from16 v37, v133

    move/from16 v48, v134

    move/from16 v45, v135

    move-object/from16 v32, p1

    move-object v15, v2

    goto/16 :goto_3798

    :cond_49b2
    :try_start_49b2
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_49b6
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6
    :try_end_49ba
    .catch Ljava/util/concurrent/CancellationException; {:try_start_49b2 .. :try_end_49ba} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_49b2 .. :try_end_49ba} :catch_4e5b
    .catchall {:try_start_49b2 .. :try_end_49ba} :catchall_478d

    if-eqz v6, :cond_4988

    :try_start_49bc
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Long;

    move-object/from16 v37, v4

    instance-of v4, v6, Lbng;

    if-eqz v4, :cond_49d5

    move-object v4, v6

    check-cast v4, Lbng;

    invoke-virtual {v4}, Lbng;->a()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_49f6

    :cond_49d5
    instance-of v4, v6, Lmmg;

    if-eqz v4, :cond_49e6

    move-object v4, v6

    check-cast v4, Lmmg;

    invoke-virtual {v4}, Lmmg;->a()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_49f6

    :cond_49e6
    instance-of v4, v6, Llng;

    if-eqz v4, :cond_49f9

    check-cast v6, Llng;

    invoke-virtual {v6}, Llng;->a()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4
    :try_end_49f4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_49bc .. :try_end_49f4} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_49bc .. :try_end_49f4} :catch_498b
    .catchall {:try_start_49bc .. :try_end_49f4} :catchall_478d

    if-eqz v4, :cond_49f9

    :cond_49f6
    move/from16 v4, v34

    goto :goto_49fc

    :cond_49f9
    move-object/from16 v4, v37

    goto :goto_49b6

    :goto_49fc
    if-nez v4, :cond_4e73

    :try_start_49fe
    const-string v6, "ExitPlanMode"

    invoke-static {v7, v6}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6
    :try_end_4a04
    .catch Ljava/util/concurrent/CancellationException; {:try_start_49fe .. :try_end_4a04} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_49fe .. :try_end_4a04} :catch_4e5b
    .catchall {:try_start_49fe .. :try_end_4a04} :catchall_478d

    if-eqz v6, :cond_4b8b

    :try_start_4a06
    new-instance v6, Lbng;

    const/4 v7, 0x0

    invoke-direct {v6, v3, v7}, Lbng;-><init>(Ljava/lang/String;Z)V

    iput-object v9, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v10, v5, Laak;->E:Lixe;

    iput-object v11, v5, Laak;->F:Lpng;

    iput-object v12, v5, Laak;->G:Lexe;

    iput-object v15, v5, Laak;->H:Lhxe;
    :try_end_4a16
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a06 .. :try_end_4a16} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a06 .. :try_end_4a16} :catch_4b87
    .catchall {:try_start_4a06 .. :try_end_4a16} :catchall_478d

    :try_start_4a16
    move-object/from16 v3, v36

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v3, v41

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->J:Ljava/util/List;
    :try_end_4a22
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a16 .. :try_end_4a22} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a16 .. :try_end_4a22} :catch_4b89
    .catchall {:try_start_4a16 .. :try_end_4a22} :catchall_478d

    :try_start_4a22
    iput-object v2, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v8, v5, Laak;->M:Lexe;

    iput-object v14, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;
    :try_end_4a2c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a22 .. :try_end_4a2c} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a22 .. :try_end_4a2c} :catch_4b87
    .catchall {:try_start_4a22 .. :try_end_4a2c} :catchall_478d

    move-object/from16 v3, v35

    :try_start_4a2e
    iput-object v3, v5, Laak;->P:Lixe;
    :try_end_4a30
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a2e .. :try_end_4a30} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a2e .. :try_end_4a30} :catch_4b6e
    .catchall {:try_start_4a2e .. :try_end_4a30} :catchall_478d

    move-object/from16 v7, v30

    :try_start_4a32
    iput-object v7, v5, Laak;->Q:Lixe;
    :try_end_4a34
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a32 .. :try_end_4a34} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a32 .. :try_end_4a34} :catch_4b62
    .catchall {:try_start_4a32 .. :try_end_4a34} :catchall_478d

    move-object/from16 v30, v13

    move-object/from16 v13, v32

    :try_start_4a38
    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_4a3a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a38 .. :try_end_4a3a} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a38 .. :try_end_4a3a} :catch_4b5e
    .catchall {:try_start_4a38 .. :try_end_4a3a} :catchall_478d

    move-object/from16 v35, v3

    const/4 v3, 0x0

    :try_start_4a3d
    iput-object v3, v5, Laak;->S:Lpe9;

    iput-object v3, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v3, v33

    iput-object v3, v5, Laak;->V:Ljava/lang/Object;
    :try_end_4a47
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a3d .. :try_end_4a47} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a3d .. :try_end_4a47} :catch_4b5a
    .catchall {:try_start_4a3d .. :try_end_4a47} :catchall_478d

    move-object/from16 v33, v7

    const/4 v7, 0x0

    :try_start_4a4a
    iput-object v7, v5, Laak;->W:Long;

    iput-object v7, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v7, v27

    iput-object v7, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v27, v7

    const/4 v7, 0x0

    iput-object v7, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 v7, v20

    iput-object v7, v5, Laak;->a0:Ljava/lang/Object;

    move-object/from16 v20, v7

    const/4 v7, 0x0

    iput-object v7, v5, Laak;->b0:Ljava/lang/Object;

    move-object/from16 v7, v17

    iput-object v7, v5, Laak;->c0:Ljava/util/Iterator;

    move-object/from16 v17, v7

    const/4 v7, 0x0

    iput-object v7, v5, Laak;->d0:Long;
    :try_end_4a69
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a4a .. :try_end_4a69} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a4a .. :try_end_4a69} :catch_4b4c
    .catchall {:try_start_4a4a .. :try_end_4a69} :catchall_478d

    move/from16 v7, v133

    :try_start_4a6b
    iput v7, v5, Laak;->e0:I
    :try_end_4a6d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a6b .. :try_end_4a6d} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a6b .. :try_end_4a6d} :catch_4b3e
    .catchall {:try_start_4a6b .. :try_end_4a6d} :catchall_478d

    move/from16 v32, v7

    move/from16 v7, v132

    :try_start_4a71
    iput-boolean v7, v5, Laak;->i0:Z
    :try_end_4a73
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a71 .. :try_end_4a73} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a71 .. :try_end_4a73} :catch_4b2e
    .catchall {:try_start_4a71 .. :try_end_4a73} :catchall_478d

    move/from16 v37, v7

    move/from16 v7, v135

    :try_start_4a77
    iput v7, v5, Laak;->f0:I
    :try_end_4a79
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a77 .. :try_end_4a79} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a77 .. :try_end_4a79} :catch_4b24
    .catchall {:try_start_4a77 .. :try_end_4a79} :catchall_478d

    move-object/from16 v43, v13

    move-object/from16 v38, v14

    move-wide/from16 v13, v130

    :try_start_4a7f
    iput-wide v13, v5, Laak;->k0:J
    :try_end_4a81
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a7f .. :try_end_4a81} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a7f .. :try_end_4a81} :catch_4b1c
    .catchall {:try_start_4a7f .. :try_end_4a81} :catchall_478d

    move-wide/from16 v45, v13

    move/from16 v13, v134

    :try_start_4a85
    iput v13, v5, Laak;->g0:I
    :try_end_4a87
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a85 .. :try_end_4a87} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a85 .. :try_end_4a87} :catch_4b18
    .catchall {:try_start_4a85 .. :try_end_4a87} :catchall_478d

    move/from16 v47, v13

    move-wide/from16 v13, v128

    :try_start_4a8b
    iput-wide v13, v5, Laak;->l0:J

    iput v4, v5, Laak;->h0:I

    const/16 v4, 0x18

    iput v4, v5, Laak;->m0:I

    invoke-virtual {v9, v5, v6}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4
    :try_end_4a97
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4a8b .. :try_end_4a97} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4a8b .. :try_end_4a97} :catch_4aeb
    .catchall {:try_start_4a8b .. :try_end_4a97} :catchall_478d

    move-object/from16 v6, v53

    if-ne v4, v6, :cond_4a9e

    move-object v2, v6

    goto/16 :goto_7700

    :cond_4a9e
    move-object/from16 v48, v2

    move-object/from16 v53, v11

    move-object/from16 v52, v12

    move-object/from16 v50, v36

    move/from16 v11, v37

    move-object/from16 v49, v41

    move-object/from16 v41, v43

    move/from16 v4, v47

    move-object v2, v0

    move-object/from16 v47, v1

    move-object v1, v9

    move-wide/from16 v36, v13

    move-object/from16 v0, v20

    move-wide/from16 v208, v45

    move-object/from16 v46, v8

    move-object/from16 v45, v38

    move-wide/from16 v8, v208

    move-object/from16 v38, v27

    :goto_4ac0
    move-object/from16 v20, v0

    move-object v0, v2

    move/from16 v134, v4

    move-object v13, v6

    move/from16 v135, v7

    move-wide/from16 v130, v8

    move/from16 v132, v11

    move/from16 v133, v32

    move-object/from16 v4, v33

    move-object/from16 v6, v35

    move-wide/from16 v128, v36

    move-object/from16 v27, v38

    move-object/from16 v7, v41

    move-object/from16 v14, v45

    move-object/from16 v8, v46

    move-object/from16 v2, v48

    move-object/from16 v41, v49

    move-object/from16 v36, v50

    move-object/from16 v12, v52

    move-object/from16 v11, v53

    move-object v9, v1

    :goto_4ae7
    move-object/from16 v1, v47

    goto/16 :goto_4e9b

    :catch_4aeb
    move-exception v0

    :goto_4aec
    move-object/from16 v6, v53

    :goto_4aee
    move-object/from16 v4, v43

    move-object/from16 v43, v33

    move-object/from16 v33, v4

    move-object/from16 v17, v1

    move-object v1, v9

    move-object v9, v11

    move-object v11, v12

    move-object v14, v15

    move-object/from16 v52, v35

    move/from16 v35, v37

    move-object/from16 v12, v38

    move-object/from16 v4, v44

    move/from16 v48, v47

    move-object/from16 v13, v58

    move-object v15, v2

    move-object v2, v6

    move-object v6, v8

    move-object v8, v10

    move-object/from16 v38, v30

    move/from16 v37, v32

    move-wide/from16 v46, v45

    move-object/from16 v32, p1

    move/from16 v45, v7

    move/from16 v7, v34

    goto/16 :goto_7437

    :catch_4b18
    move-exception v0

    move/from16 v47, v13

    goto :goto_4aec

    :catch_4b1c
    move-exception v0

    move-wide/from16 v45, v13

    move-object/from16 v6, v53

    :goto_4b21
    move/from16 v47, v134

    goto :goto_4aee

    :catch_4b24
    move-exception v0

    move-object/from16 v43, v13

    move-object/from16 v38, v14

    move-object/from16 v6, v53

    move-wide/from16 v45, v130

    goto :goto_4b21

    :catch_4b2e
    move-exception v0

    move/from16 v37, v7

    move-object/from16 v43, v13

    move-object/from16 v38, v14

    move-object/from16 v6, v53

    move-wide/from16 v45, v130

    :goto_4b39
    move/from16 v47, v134

    move/from16 v7, v135

    goto :goto_4aee

    :catch_4b3e
    move-exception v0

    move/from16 v32, v7

    move-object/from16 v43, v13

    move-object/from16 v38, v14

    move-object/from16 v6, v53

    move-wide/from16 v45, v130

    move/from16 v37, v132

    goto :goto_4b39

    :catch_4b4c
    move-exception v0

    :goto_4b4d
    move-object/from16 v43, v13

    move-object/from16 v38, v14

    :goto_4b51
    move-object/from16 v6, v53

    move-wide/from16 v45, v130

    move/from16 v37, v132

    move/from16 v32, v133

    goto :goto_4b39

    :catch_4b5a
    move-exception v0

    :goto_4b5b
    move-object/from16 v33, v7

    goto :goto_4b4d

    :catch_4b5e
    move-exception v0

    move-object/from16 v35, v3

    goto :goto_4b5b

    :catch_4b62
    move-exception v0

    move-object/from16 v35, v3

    move-object/from16 v33, v7

    move-object/from16 v30, v13

    move-object/from16 v38, v14

    move-object/from16 v43, v32

    goto :goto_4b51

    :catch_4b6e
    move-exception v0

    move-object/from16 v35, v3

    :goto_4b71
    move-object/from16 v38, v14

    move-object/from16 v33, v30

    move-object/from16 v43, v32

    move-object/from16 v6, v53

    move-wide/from16 v45, v130

    move/from16 v37, v132

    move/from16 v32, v133

    move/from16 v47, v134

    move/from16 v7, v135

    move-object/from16 v30, v13

    goto/16 :goto_4aee

    :catch_4b87
    move-exception v0

    goto :goto_4b71

    :catch_4b89
    move-exception v0

    goto :goto_4b71

    :cond_4b8b
    move-object/from16 v38, v14

    move-object/from16 v6, v30

    move-object/from16 v43, v32

    move-wide/from16 v48, v128

    move-wide/from16 v45, v130

    move/from16 v37, v132

    move/from16 v32, v133

    move/from16 v47, v134

    move-object v14, v7

    move-object/from16 v30, v13

    move-object v13, v3

    move-object/from16 v3, v33

    move/from16 v33, v4

    move-object/from16 v4, v35

    move/from16 v35, v135

    :try_start_4ba7
    const-string v7, "AskUserQuestion"

    invoke-static {v14, v7}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7
    :try_end_4bad
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4ba7 .. :try_end_4bad} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4ba7 .. :try_end_4bad} :catch_4e4b
    .catchall {:try_start_4ba7 .. :try_end_4bad} :catchall_478d

    if-eqz v7, :cond_4cfd

    :try_start_4baf
    new-instance v7, Lmmg;

    invoke-direct {v7, v13}, Lmmg;-><init>(Ljava/lang/String;)V

    iput-object v9, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v10, v5, Laak;->E:Lixe;

    iput-object v11, v5, Laak;->F:Lpng;

    iput-object v12, v5, Laak;->G:Lexe;

    iput-object v15, v5, Laak;->H:Lhxe;
    :try_end_4bbe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4baf .. :try_end_4bbe} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4baf .. :try_end_4bbe} :catch_4ce7
    .catchall {:try_start_4baf .. :try_end_4bbe} :catchall_478d

    :try_start_4bbe
    move-object/from16 v13, v36

    check-cast v13, Ljava/util/List;

    iput-object v13, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v13, v41

    check-cast v13, Ljava/util/List;

    iput-object v13, v5, Laak;->J:Ljava/util/List;
    :try_end_4bca
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4bbe .. :try_end_4bca} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4bbe .. :try_end_4bca} :catch_4cef
    .catchall {:try_start_4bbe .. :try_end_4bca} :catchall_478d

    :try_start_4bca
    iput-object v2, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v8, v5, Laak;->M:Lexe;
    :try_end_4bd0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4bca .. :try_end_4bd0} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4bca .. :try_end_4bd0} :catch_4ce7
    .catchall {:try_start_4bca .. :try_end_4bd0} :catchall_478d

    move-object/from16 v14, v38

    :try_start_4bd2
    iput-object v14, v5, Laak;->N:Lexe;
    :try_end_4bd4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4bd2 .. :try_end_4bd4} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4bd2 .. :try_end_4bd4} :catch_4cdf
    .catchall {:try_start_4bd2 .. :try_end_4bd4} :catchall_478d

    move-object/from16 v13, v30

    :try_start_4bd6
    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v4, v5, Laak;->P:Lixe;

    iput-object v6, v5, Laak;->Q:Lixe;
    :try_end_4bdc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4bd6 .. :try_end_4bdc} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4bd6 .. :try_end_4bdc} :catch_4cd5
    .catchall {:try_start_4bd6 .. :try_end_4bdc} :catchall_478d

    move-object/from16 v30, v6

    move-object/from16 v6, v43

    :try_start_4be0
    iput-object v6, v5, Laak;->R:Lcp2;
    :try_end_4be2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4be0 .. :try_end_4be2} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4be0 .. :try_end_4be2} :catch_4ccf
    .catchall {:try_start_4be0 .. :try_end_4be2} :catchall_478d

    move-object/from16 v38, v13

    const/4 v13, 0x0

    :try_start_4be5
    iput-object v13, v5, Laak;->S:Lpe9;

    iput-object v13, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    iput-object v3, v5, Laak;->V:Ljava/lang/Object;

    iput-object v13, v5, Laak;->W:Long;

    iput-object v13, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v13, v27

    iput-object v13, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v27, v13

    const/4 v13, 0x0

    iput-object v13, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 v13, v20

    iput-object v13, v5, Laak;->a0:Ljava/lang/Object;

    move-object/from16 v20, v13

    const/4 v13, 0x0

    iput-object v13, v5, Laak;->b0:Ljava/lang/Object;

    move-object/from16 v13, v17

    iput-object v13, v5, Laak;->c0:Ljava/util/Iterator;

    move-object/from16 v17, v13

    const/4 v13, 0x0

    iput-object v13, v5, Laak;->d0:Long;
    :try_end_4c0c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4be5 .. :try_end_4c0c} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4be5 .. :try_end_4c0c} :catch_4ccb
    .catchall {:try_start_4be5 .. :try_end_4c0c} :catchall_478d

    move/from16 v13, v32

    :try_start_4c0e
    iput v13, v5, Laak;->e0:I
    :try_end_4c10
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4c0e .. :try_end_4c10} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4c0e .. :try_end_4c10} :catch_4cc5
    .catchall {:try_start_4c0e .. :try_end_4c10} :catchall_478d

    move/from16 v32, v13

    move/from16 v13, v37

    :try_start_4c14
    iput-boolean v13, v5, Laak;->i0:Z
    :try_end_4c16
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4c14 .. :try_end_4c16} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4c14 .. :try_end_4c16} :catch_4cbd
    .catchall {:try_start_4c14 .. :try_end_4c16} :catchall_478d

    move/from16 v37, v13

    move/from16 v13, v35

    :try_start_4c1a
    iput v13, v5, Laak;->f0:I
    :try_end_4c1c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4c1a .. :try_end_4c1c} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4c1a .. :try_end_4c1c} :catch_4cb9
    .catchall {:try_start_4c1a .. :try_end_4c1c} :catchall_478d

    move-object/from16 v35, v3

    move-object/from16 v43, v4

    move-wide/from16 v3, v45

    :try_start_4c22
    iput-wide v3, v5, Laak;->k0:J
    :try_end_4c24
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4c22 .. :try_end_4c24} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4c22 .. :try_end_4c24} :catch_4cb5
    .catchall {:try_start_4c22 .. :try_end_4c24} :catchall_478d

    move-wide/from16 v45, v3

    move/from16 v3, v47

    :try_start_4c28
    iput v3, v5, Laak;->g0:I
    :try_end_4c2a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4c28 .. :try_end_4c2a} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4c28 .. :try_end_4c2a} :catch_4cb1
    .catchall {:try_start_4c28 .. :try_end_4c2a} :catchall_478d

    move/from16 v47, v3

    move-wide/from16 v3, v48

    :try_start_4c2e
    iput-wide v3, v5, Laak;->l0:J

    move-wide/from16 v48, v3

    move/from16 v3, v33

    iput v3, v5, Laak;->h0:I

    const/16 v3, 0x19

    iput v3, v5, Laak;->m0:I

    invoke-virtual {v9, v5, v7}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_4c3e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4c2e .. :try_end_4c3e} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4c2e .. :try_end_4c3e} :catch_4c8b
    .catchall {:try_start_4c2e .. :try_end_4c3e} :catchall_478d

    move-object/from16 v4, v53

    if-ne v3, v4, :cond_4c45

    move-object v2, v4

    goto/16 :goto_7700

    :cond_4c45
    move-object v3, v2

    move-object v7, v6

    move-object/from16 v53, v11

    move-object/from16 v52, v12

    move-object/from16 v50, v36

    move-object/from16 v6, v38

    move-wide/from16 v11, v45

    move-object v2, v0

    move-object/from16 v46, v8

    move-object/from16 v45, v14

    move-object/from16 v0, v20

    move-object/from16 v38, v27

    move/from16 v8, v47

    move-object/from16 v47, v1

    move-object v1, v9

    move/from16 v9, v32

    :goto_4c61
    move-object/from16 v20, v0

    move-object v0, v2

    move-object v2, v3

    move/from16 v134, v8

    move/from16 v133, v9

    move-wide/from16 v130, v11

    move/from16 v135, v13

    move-object/from16 v3, v35

    move/from16 v132, v37

    move-object/from16 v27, v38

    move-object/from16 v14, v45

    move-object/from16 v8, v46

    move-wide/from16 v128, v48

    move-object/from16 v36, v50

    move-object/from16 v12, v52

    move-object/from16 v11, v53

    move-object v9, v1

    move-object v13, v4

    move-object/from16 v4, v30

    move-object/from16 v1, v47

    move-object/from16 v30, v6

    :goto_4c87
    move-object/from16 v6, v43

    goto/16 :goto_4e9b

    :catch_4c8b
    move-exception v0

    :goto_4c8c
    move-object/from16 v4, v53

    move-object/from16 v17, v1

    move-object/from16 v33, v6

    move-object v6, v8

    move-object v1, v9

    move-object v8, v10

    move-object v9, v11

    move-object v11, v12

    move-object v12, v14

    move-object v14, v15

    move/from16 v7, v34

    move/from16 v35, v37

    move-object/from16 v52, v43

    move/from16 v48, v47

    move-object v15, v2

    move-object v2, v4

    move-object/from16 v43, v30

    move/from16 v37, v32

    move-object/from16 v4, v44

    move-wide/from16 v46, v45

    move-object/from16 v32, p1

    move/from16 v45, v13

    goto/16 :goto_461b

    :catch_4cb1
    move-exception v0

    move/from16 v47, v3

    goto :goto_4c8c

    :catch_4cb5
    move-exception v0

    move-wide/from16 v45, v3

    goto :goto_4c8c

    :catch_4cb9
    move-exception v0

    :goto_4cba
    move-object/from16 v43, v4

    goto :goto_4c8c

    :catch_4cbd
    move-exception v0

    move-object/from16 v43, v4

    move/from16 v37, v13

    :goto_4cc2
    move/from16 v13, v35

    goto :goto_4c8c

    :catch_4cc5
    move-exception v0

    move-object/from16 v43, v4

    move/from16 v32, v13

    goto :goto_4cc2

    :catch_4ccb
    move-exception v0

    move-object/from16 v43, v4

    goto :goto_4cc2

    :catch_4ccf
    move-exception v0

    move-object/from16 v43, v4

    move-object/from16 v38, v13

    goto :goto_4cc2

    :catch_4cd5
    move-exception v0

    move-object/from16 v30, v6

    move-object/from16 v38, v13

    move/from16 v13, v35

    :goto_4cdc
    move-object/from16 v6, v43

    goto :goto_4cba

    :catch_4cdf
    move-exception v0

    move-object/from16 v38, v30

    move/from16 v13, v35

    :goto_4ce4
    move-object/from16 v30, v6

    goto :goto_4cdc

    :catch_4ce7
    move-exception v0

    move/from16 v13, v35

    move-object/from16 v14, v38

    move-object/from16 v38, v30

    goto :goto_4ce4

    :catch_4cef
    move-exception v0

    move/from16 v13, v35

    move-object/from16 v14, v38

    move-object/from16 v38, v30

    move-object/from16 v30, v6

    move-object/from16 v6, v43

    move-object/from16 v43, v4

    goto :goto_4c8c

    :cond_4cfd
    move-object/from16 v7, v30

    move-object/from16 v14, v38

    move-object/from16 v30, v6

    move-object/from16 v6, v43

    move-object/from16 v43, v4

    move-object v4, v13

    move/from16 v13, v35

    move-object/from16 v35, v3

    :try_start_4d0c
    new-instance v3, Llng;

    invoke-direct {v3, v4}, Llng;-><init>(Ljava/lang/String;)V

    iput-object v9, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v10, v5, Laak;->E:Lixe;

    iput-object v11, v5, Laak;->F:Lpng;

    iput-object v12, v5, Laak;->G:Lexe;

    iput-object v15, v5, Laak;->H:Lhxe;
    :try_end_4d1b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d0c .. :try_end_4d1b} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d0c .. :try_end_4d1b} :catch_4e3d
    .catchall {:try_start_4d0c .. :try_end_4d1b} :catchall_478d

    :try_start_4d1b
    move-object/from16 v4, v36

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v4, v41

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->J:Ljava/util/List;
    :try_end_4d27
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d1b .. :try_end_4d27} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d1b .. :try_end_4d27} :catch_4e3f
    .catchall {:try_start_4d1b .. :try_end_4d27} :catchall_478d

    :try_start_4d27
    iput-object v2, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v8, v5, Laak;->M:Lexe;

    iput-object v14, v5, Laak;->N:Lexe;

    iput-object v7, v5, Laak;->O:Lexe;
    :try_end_4d31
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d27 .. :try_end_4d31} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d27 .. :try_end_4d31} :catch_4e3d
    .catchall {:try_start_4d27 .. :try_end_4d31} :catchall_478d

    move-object/from16 v4, v43

    :try_start_4d33
    iput-object v4, v5, Laak;->P:Lixe;
    :try_end_4d35
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d33 .. :try_end_4d35} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d33 .. :try_end_4d35} :catch_4e31
    .catchall {:try_start_4d33 .. :try_end_4d35} :catchall_478d

    move-object/from16 v43, v4

    move-object/from16 v4, v30

    :try_start_4d39
    iput-object v4, v5, Laak;->Q:Lixe;

    iput-object v6, v5, Laak;->R:Lcp2;
    :try_end_4d3d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d39 .. :try_end_4d3d} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d39 .. :try_end_4d3d} :catch_4e2b
    .catchall {:try_start_4d39 .. :try_end_4d3d} :catchall_478d

    move-object/from16 v30, v6

    const/4 v6, 0x0

    :try_start_4d40
    iput-object v6, v5, Laak;->S:Lpe9;

    iput-object v6, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v6, v35

    iput-object v6, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v35, v6

    const/4 v6, 0x0

    iput-object v6, v5, Laak;->W:Long;

    iput-object v6, v5, Laak;->X:Ljava/lang/Object;

    move-object/from16 v6, v27

    iput-object v6, v5, Laak;->Y:Ljava/lang/Object;
    :try_end_4d55
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d40 .. :try_end_4d55} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d40 .. :try_end_4d55} :catch_4e27
    .catchall {:try_start_4d40 .. :try_end_4d55} :catchall_478d

    move-object/from16 v27, v4

    const/4 v4, 0x0

    :try_start_4d58
    iput-object v4, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 v4, v20

    iput-object v4, v5, Laak;->a0:Ljava/lang/Object;

    move-object/from16 v20, v4

    const/4 v4, 0x0

    iput-object v4, v5, Laak;->b0:Ljava/lang/Object;

    move-object/from16 v4, v17

    iput-object v4, v5, Laak;->c0:Ljava/util/Iterator;

    move-object/from16 v17, v4

    const/4 v4, 0x0

    iput-object v4, v5, Laak;->d0:Long;
    :try_end_4d6c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d58 .. :try_end_4d6c} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d58 .. :try_end_4d6c} :catch_4e25
    .catchall {:try_start_4d58 .. :try_end_4d6c} :catchall_478d

    move/from16 v4, v32

    :try_start_4d6e
    iput v4, v5, Laak;->e0:I
    :try_end_4d70
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d6e .. :try_end_4d70} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d6e .. :try_end_4d70} :catch_4e1b
    .catchall {:try_start_4d6e .. :try_end_4d70} :catchall_478d

    move/from16 v32, v4

    move/from16 v4, v37

    :try_start_4d74
    iput-boolean v4, v5, Laak;->i0:Z

    iput v13, v5, Laak;->f0:I
    :try_end_4d78
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d74 .. :try_end_4d78} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d74 .. :try_end_4d78} :catch_4e15
    .catchall {:try_start_4d74 .. :try_end_4d78} :catchall_478d

    move/from16 v37, v13

    move-object/from16 v38, v14

    move-wide/from16 v13, v45

    :try_start_4d7e
    iput-wide v13, v5, Laak;->k0:J
    :try_end_4d80
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d7e .. :try_end_4d80} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d7e .. :try_end_4d80} :catch_4e11
    .catchall {:try_start_4d7e .. :try_end_4d80} :catchall_478d

    move-wide/from16 v45, v13

    move/from16 v13, v47

    :try_start_4d84
    iput v13, v5, Laak;->g0:I
    :try_end_4d86
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d84 .. :try_end_4d86} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d84 .. :try_end_4d86} :catch_4e0d
    .catchall {:try_start_4d84 .. :try_end_4d86} :catchall_478d

    move/from16 v47, v13

    move-wide/from16 v13, v48

    :try_start_4d8a
    iput-wide v13, v5, Laak;->l0:J

    move-wide/from16 v48, v13

    move/from16 v13, v33

    iput v13, v5, Laak;->h0:I

    const/16 v13, 0x1a

    iput v13, v5, Laak;->m0:I

    invoke-virtual {v9, v5, v3}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_4d9a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4d8a .. :try_end_4d9a} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4d8a .. :try_end_4d9a} :catch_4de2
    .catchall {:try_start_4d8a .. :try_end_4d9a} :catchall_478d

    move-object/from16 v13, v53

    if-ne v3, v13, :cond_4da0

    goto/16 :goto_3a89

    :cond_4da0
    move-object v3, v2

    move-object/from16 v53, v11

    move-object/from16 v52, v12

    move-object/from16 v50, v36

    move-object v2, v0

    move v11, v4

    move-object/from16 v0, v20

    move/from16 v4, v47

    move-object/from16 v47, v1

    move-object v1, v9

    move-wide/from16 v208, v45

    move-object/from16 v46, v8

    move-object/from16 v45, v38

    move-wide/from16 v8, v208

    :goto_4db8
    move-object/from16 v12, v30

    move-object/from16 v30, v7

    move-object v7, v12

    move-object/from16 v20, v0

    move-object v0, v2

    move-object v2, v3

    move/from16 v134, v4

    move-wide/from16 v130, v8

    move/from16 v132, v11

    move-object/from16 v4, v27

    move/from16 v133, v32

    move-object/from16 v3, v35

    move/from16 v135, v37

    move-object/from16 v14, v45

    move-object/from16 v8, v46

    move-wide/from16 v128, v48

    move-object/from16 v36, v50

    move-object/from16 v12, v52

    move-object/from16 v11, v53

    move-object v9, v1

    move-object/from16 v27, v6

    move-object/from16 v6, v43

    goto/16 :goto_4ae7

    :catch_4de2
    move-exception v0

    :goto_4de3
    move-object/from16 v13, v53

    :goto_4de5
    move-object/from16 v17, v1

    move/from16 v35, v4

    move-object v6, v8

    move-object v1, v9

    move-object v8, v10

    move-object v9, v11

    move-object v11, v12

    move-object v14, v15

    move-object/from16 v33, v30

    move-object/from16 v12, v38

    move-object/from16 v52, v43

    move-object/from16 v4, v44

    move/from16 v48, v47

    move-object v15, v2

    move-object/from16 v38, v7

    move-object v2, v13

    move-object/from16 v43, v27

    move/from16 v7, v34

    move-wide/from16 v46, v45

    move-object/from16 v13, v58

    move/from16 v45, v37

    move/from16 v37, v32

    move-object/from16 v32, p1

    goto/16 :goto_7437

    :catch_4e0d
    move-exception v0

    move/from16 v47, v13

    goto :goto_4de3

    :catch_4e11
    move-exception v0

    move-wide/from16 v45, v13

    goto :goto_4de3

    :catch_4e15
    move-exception v0

    move/from16 v37, v13

    move-object/from16 v38, v14

    goto :goto_4de3

    :catch_4e1b
    move-exception v0

    move/from16 v32, v4

    :goto_4e1e
    move-object/from16 v38, v14

    move/from16 v4, v37

    :goto_4e22
    move/from16 v37, v13

    goto :goto_4de3

    :catch_4e25
    move-exception v0

    goto :goto_4e1e

    :catch_4e27
    move-exception v0

    move-object/from16 v27, v4

    goto :goto_4e1e

    :catch_4e2b
    move-exception v0

    move-object/from16 v27, v4

    move-object/from16 v30, v6

    goto :goto_4e1e

    :catch_4e31
    move-exception v0

    move-object/from16 v43, v4

    :goto_4e34
    move-object/from16 v38, v14

    move-object/from16 v27, v30

    move/from16 v4, v37

    move-object/from16 v30, v6

    goto :goto_4e22

    :catch_4e3d
    move-exception v0

    goto :goto_4e34

    :catch_4e3f
    move-exception v0

    move-object/from16 v38, v14

    move-object/from16 v27, v30

    move/from16 v4, v37

    move-object/from16 v30, v6

    move/from16 v37, v13

    goto :goto_4de3

    :catch_4e4b
    move-exception v0

    move-object/from16 v27, v6

    move-object/from16 v7, v30

    move-object/from16 v30, v43

    move-object/from16 v13, v53

    move-object/from16 v43, v4

    move/from16 v4, v37

    move/from16 v37, v35

    goto :goto_4de5

    :catch_4e5b
    move-exception v0

    move-object v7, v13

    move-object/from16 v38, v14

    move-object/from16 v27, v30

    move-object/from16 v30, v32

    move-object/from16 v43, v35

    :goto_4e65
    move-object/from16 v13, v53

    move-wide/from16 v45, v130

    move/from16 v4, v132

    move/from16 v32, v133

    move/from16 v47, v134

    move/from16 v37, v135

    goto/16 :goto_4de5

    :cond_4e73
    move-object v7, v13

    move-object/from16 v38, v14

    move-object/from16 v6, v27

    move-object/from16 v27, v30

    move-object/from16 v30, v32

    move-object/from16 v43, v35

    move-object/from16 v13, v53

    move-wide/from16 v48, v128

    move-wide/from16 v45, v130

    move/from16 v4, v132

    move/from16 v32, v133

    move/from16 v47, v134

    move/from16 v37, v135

    move-object/from16 v35, v33

    move-object/from16 v3, v30

    move-object/from16 v30, v7

    move-object v7, v3

    move-object/from16 v4, v27

    move-object/from16 v3, v35

    move-object/from16 v27, v6

    goto/16 :goto_4c87

    :goto_4e9b
    move-object/from16 v53, v13

    move-object/from16 v13, v30

    goto/16 :goto_4953

    :catch_4ea1
    move-exception v0

    move-object/from16 v43, v6

    move-object v7, v13

    move-object/from16 v38, v14

    move-object/from16 v27, v30

    :goto_4ea9
    move-object/from16 v30, v32

    goto :goto_4e65

    :catch_4eac
    move-exception v0

    move-object/from16 v27, v4

    move-object/from16 v43, v6

    move-object v7, v13

    move-object/from16 v38, v14

    goto :goto_4ea9

    :catch_4eb5
    move-exception v0

    move-object/from16 v27, v4

    move-object/from16 v43, v6

    move-object/from16 v30, v7

    move-object v7, v13

    move-object/from16 v38, v14

    goto :goto_4e65

    :cond_4ec0
    move-object/from16 v35, v3

    move-object/from16 v43, v6

    move-object/from16 v30, v7

    move-object v7, v13

    move-object/from16 v38, v14

    move-object/from16 v6, v27

    move-object/from16 v13, v53

    move-wide/from16 v48, v128

    move-wide/from16 v45, v130

    move/from16 v32, v133

    move/from16 v47, v134

    move/from16 v37, v135

    move-object/from16 v27, v4

    move/from16 v4, v132

    :try_start_4edb
    instance-of v3, v6, Lcom/anthropic/claude/sessions/types/SdkResultEvent;
    :try_end_4edd
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4edb .. :try_end_4edd} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4edb .. :try_end_4edd} :catch_509d
    .catchall {:try_start_4edb .. :try_end_4edd} :catchall_478d

    if-eqz v3, :cond_4eeb

    :try_start_4edf
    invoke-virtual/range {p1 .. p1}, Lnlh;->d()Z

    move-result v3
    :try_end_4ee3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4edf .. :try_end_4ee3} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4edf .. :try_end_4ee3} :catch_4ee8
    .catchall {:try_start_4edf .. :try_end_4ee3} :catchall_478d

    if-nez v3, :cond_4eeb

    move/from16 v3, v34

    goto :goto_4eec

    :catch_4ee8
    move-exception v0

    goto/16 :goto_4de5

    :cond_4eeb
    const/4 v3, 0x0

    :goto_4eec
    :try_start_4eec
    instance-of v14, v6, Lcom/anthropic/claude/sessions/types/SdkResultEvent;
    :try_end_4eee
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4eec .. :try_end_4eee} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4eec .. :try_end_4eee} :catch_509d
    .catchall {:try_start_4eec .. :try_end_4eee} :catchall_478d

    if-eqz v14, :cond_4f2e

    move-object/from16 v14, p1

    move-object/from16 v53, v13

    :try_start_4ef4
    iget-object v13, v14, Lnlh;->k:La1f;

    iget-object v13, v13, La1f;->F:Ljava/lang/Object;

    check-cast v13, Lrig;
    :try_end_4efa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4ef4 .. :try_end_4efa} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4ef4 .. :try_end_4efa} :catch_4f02
    .catchall {:try_start_4ef4 .. :try_end_4efa} :catchall_478d

    move-object/from16 v33, v14

    const/4 v14, 0x0

    :try_start_4efd
    iput-boolean v14, v13, Lrig;->t:Z
    :try_end_4eff
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4efd .. :try_end_4eff} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4efd .. :try_end_4eff} :catch_4f00
    .catchall {:try_start_4efd .. :try_end_4eff} :catchall_478d

    goto :goto_4f32

    :catch_4f00
    move-exception v0

    goto :goto_4f05

    :catch_4f02
    move-exception v0

    move-object/from16 v33, v14

    :goto_4f05
    move-object/from16 v17, v1

    move/from16 v35, v4

    move-object v6, v8

    move-object v1, v9

    move-object v8, v10

    move-object v9, v11

    move-object v11, v12

    move-object v14, v15

    move-object/from16 v12, v38

    move-object/from16 v52, v43

    move-object/from16 v4, v44

    move/from16 v48, v47

    move-object/from16 v13, v58

    move-object v15, v2

    move-object/from16 v38, v7

    move-object/from16 v43, v27

    move/from16 v7, v34

    move-wide/from16 v46, v45

    move-object/from16 v2, v53

    move/from16 v45, v37

    move/from16 v37, v32

    move-object/from16 v32, v33

    move-object/from16 v33, v30

    goto/16 :goto_7437

    :cond_4f2e
    move-object/from16 v33, p1

    move-object/from16 v53, v13

    :goto_4f32
    if-eqz v4, :cond_4f3e

    :try_start_4f34
    invoke-virtual {v11, v6}, Lpng;->f(Lcom/anthropic/claude/sessions/types/SdkEvent;)Z

    move-result v6

    if-nez v6, :cond_4f3c

    if-eqz v3, :cond_4f3e

    :cond_4f3c
    const/4 v14, 0x0

    goto :goto_4f4e

    :cond_4f3e
    move-object/from16 v17, v1

    move-object/from16 v20, v2

    move-object/from16 v13, v27

    move-object/from16 v14, v38

    move-object/from16 v6, v43

    move-object/from16 v1, v53

    move-object/from16 v43, v30

    goto/16 :goto_5075

    :goto_4f4e
    invoke-virtual {v11, v14}, Lpng;->a(Z)Z

    move-result v6

    if-eqz v6, :cond_4f3e

    iput-object v9, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v10, v5, Laak;->E:Lixe;

    iput-object v11, v5, Laak;->F:Lpng;

    iput-object v12, v5, Laak;->G:Lexe;

    iput-object v15, v5, Laak;->H:Lhxe;
    :try_end_4f5e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f34 .. :try_end_4f5e} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f34 .. :try_end_4f5e} :catch_505d
    .catchall {:try_start_4f34 .. :try_end_4f5e} :catchall_478d

    :try_start_4f5e
    move-object/from16 v6, v36

    check-cast v6, Ljava/util/List;

    iput-object v6, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v6, v41

    check-cast v6, Ljava/util/List;

    iput-object v6, v5, Laak;->J:Ljava/util/List;
    :try_end_4f6a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f5e .. :try_end_4f6a} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f5e .. :try_end_4f6a} :catch_5067
    .catchall {:try_start_4f5e .. :try_end_4f6a} :catchall_478d

    :try_start_4f6a
    iput-object v2, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v8, v5, Laak;->M:Lexe;
    :try_end_4f70
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f6a .. :try_end_4f70} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f6a .. :try_end_4f70} :catch_505d
    .catchall {:try_start_4f6a .. :try_end_4f70} :catchall_478d

    move-object/from16 v14, v38

    :try_start_4f72
    iput-object v14, v5, Laak;->N:Lexe;

    iput-object v7, v5, Laak;->O:Lexe;
    :try_end_4f76
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f72 .. :try_end_4f76} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f72 .. :try_end_4f76} :catch_504f
    .catchall {:try_start_4f72 .. :try_end_4f76} :catchall_478d

    move-object/from16 v6, v43

    :try_start_4f78
    iput-object v6, v5, Laak;->P:Lixe;
    :try_end_4f7a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f78 .. :try_end_4f7a} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f78 .. :try_end_4f7a} :catch_5047
    .catchall {:try_start_4f78 .. :try_end_4f7a} :catchall_478d

    move-object/from16 v13, v27

    :try_start_4f7c
    iput-object v13, v5, Laak;->Q:Lixe;
    :try_end_4f7e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f7c .. :try_end_4f7e} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f7c .. :try_end_4f7e} :catch_503f
    .catchall {:try_start_4f7c .. :try_end_4f7e} :catchall_478d

    move-object/from16 v17, v1

    move-object/from16 v1, v30

    :try_start_4f82
    iput-object v1, v5, Laak;->R:Lcp2;
    :try_end_4f84
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f82 .. :try_end_4f84} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f82 .. :try_end_4f84} :catch_503b
    .catchall {:try_start_4f82 .. :try_end_4f84} :catchall_478d

    move-object/from16 v43, v1

    const/4 v1, 0x0

    :try_start_4f87
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v1, v35

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v35, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v1, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v1, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->c0:Ljava/util/Iterator;

    iput-object v1, v5, Laak;->d0:Long;
    :try_end_4fa4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4f87 .. :try_end_4fa4} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4f87 .. :try_end_4fa4} :catch_5039
    .catchall {:try_start_4f87 .. :try_end_4fa4} :catchall_478d

    move/from16 v1, v32

    :try_start_4fa6
    iput v1, v5, Laak;->e0:I

    iput-boolean v4, v5, Laak;->i0:Z
    :try_end_4faa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4fa6 .. :try_end_4faa} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4fa6 .. :try_end_4faa} :catch_5035
    .catchall {:try_start_4fa6 .. :try_end_4faa} :catchall_478d

    move/from16 v32, v1

    move/from16 v1, v37

    :try_start_4fae
    iput v1, v5, Laak;->f0:I
    :try_end_4fb0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4fae .. :try_end_4fb0} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4fae .. :try_end_4fb0} :catch_502f
    .catchall {:try_start_4fae .. :try_end_4fb0} :catchall_478d

    move/from16 v37, v1

    move-object/from16 v20, v2

    move-wide/from16 v1, v45

    :try_start_4fb6
    iput-wide v1, v5, Laak;->k0:J
    :try_end_4fb8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4fb6 .. :try_end_4fb8} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4fb6 .. :try_end_4fb8} :catch_502b
    .catchall {:try_start_4fb6 .. :try_end_4fb8} :catchall_478d

    move-wide/from16 v45, v1

    move/from16 v1, v47

    :try_start_4fbc
    iput v1, v5, Laak;->g0:I
    :try_end_4fbe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4fbc .. :try_end_4fbe} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4fbc .. :try_end_4fbe} :catch_5027
    .catchall {:try_start_4fbc .. :try_end_4fbe} :catchall_478d

    move/from16 v47, v1

    move-wide/from16 v1, v48

    :try_start_4fc2
    iput-wide v1, v5, Laak;->l0:J

    iput v3, v5, Laak;->h0:I

    const/16 v3, 0x1b

    iput v3, v5, Laak;->m0:I

    invoke-static {v12, v15, v9, v11, v5}, Laak;->q(Lexe;Lhxe;Lo1e;Lpng;Laak;)Ljava/lang/Object;

    move-result-object v3
    :try_end_4fce
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4fc2 .. :try_end_4fce} :catch_47b6
    .catch Ljava/lang/Exception; {:try_start_4fc2 .. :try_end_4fce} :catch_5000
    .catchall {:try_start_4fc2 .. :try_end_4fce} :catchall_478d

    move-wide/from16 v48, v1

    move-object/from16 v1, v53

    if-ne v3, v1, :cond_4fd6

    goto/16 :goto_1e7c

    :cond_4fd6
    move/from16 v83, v4

    move-object v2, v6

    move-object v6, v8

    move-object v4, v9

    move-object v8, v11

    move-object v9, v12

    move-object v11, v15

    move-object/from16 v12, v20

    move/from16 v84, v32

    move/from16 v86, v37

    move-object/from16 v38, v43

    move-wide/from16 v81, v45

    move/from16 v85, v47

    move-object v15, v13

    move-object v13, v7

    move-object v7, v10

    move-object v10, v14

    move-object/from16 v14, v17

    :goto_4ff0
    move-object/from16 p1, v0

    move-object/from16 v59, v1

    move-object/from16 v0, v35

    move-object/from16 v1, v38

    move-object/from16 v40, v44

    move-wide/from16 v37, v48

    move-object/from16 v49, v33

    goto/16 :goto_2b92

    :catch_5000
    move-exception v0

    :goto_5001
    move-object/from16 v1, v53

    :goto_5003
    move-object v2, v1

    move/from16 v35, v4

    move-object/from16 v52, v6

    move-object/from16 v38, v7

    move-object v6, v8

    move-object v1, v9

    move-object v8, v10

    move-object v9, v11

    move-object v11, v12

    move-object v12, v14

    move-object v14, v15

    move-object/from16 v15, v20

    move/from16 v7, v34

    move-object/from16 v4, v44

    move/from16 v48, v47

    move-wide/from16 v46, v45

    move/from16 v45, v37

    move/from16 v37, v32

    move-object/from16 v32, v33

    move-object/from16 v33, v43

    move-object/from16 v43, v13

    goto/16 :goto_461b

    :catch_5027
    move-exception v0

    move/from16 v47, v1

    goto :goto_5001

    :catch_502b
    move-exception v0

    move-wide/from16 v45, v1

    goto :goto_5001

    :catch_502f
    move-exception v0

    move/from16 v37, v1

    :goto_5032
    move-object/from16 v20, v2

    goto :goto_5001

    :catch_5035
    move-exception v0

    move/from16 v32, v1

    goto :goto_5032

    :catch_5039
    move-exception v0

    goto :goto_5032

    :catch_503b
    move-exception v0

    move-object/from16 v43, v1

    goto :goto_5032

    :catch_503f
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v20, v2

    :goto_5044
    move-object/from16 v43, v30

    goto :goto_5001

    :catch_5047
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v20, v2

    move-object/from16 v13, v27

    goto :goto_5044

    :catch_504f
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v20, v2

    move-object/from16 v13, v27

    :goto_5056
    move-object/from16 v6, v43

    move-object/from16 v1, v53

    :goto_505a
    move-object/from16 v43, v30

    goto :goto_5003

    :catch_505d
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v20, v2

    move-object/from16 v13, v27

    move-object/from16 v14, v38

    goto :goto_5056

    :catch_5067
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v20, v2

    move-object/from16 v13, v27

    move-object/from16 v14, v38

    move-object/from16 v6, v43

    move-object/from16 v1, v53

    goto :goto_505a

    :goto_5075
    move-object/from16 p1, v0

    move-object/from16 v59, v1

    move/from16 v83, v4

    move-object v2, v6

    move-object v6, v8

    move-object v4, v9

    move-object v8, v11

    move-object v9, v12

    move-object v11, v15

    move-object/from16 v12, v20

    move/from16 v84, v32

    move-object/from16 v0, v35

    move/from16 v86, v37

    move-object/from16 v1, v43

    move-object/from16 v40, v44

    move-wide/from16 v81, v45

    move/from16 v85, v47

    move-wide/from16 v37, v48

    move-object v15, v13

    move-object/from16 v49, v33

    move-object v13, v7

    move-object v7, v10

    move-object v10, v14

    :goto_5099
    move-object/from16 v14, v17

    goto/16 :goto_2b92

    :catch_509d
    move-exception v0

    move-object/from16 v33, p1

    move-object/from16 v17, v1

    move-object/from16 v20, v2

    move-object v1, v13

    move-object/from16 v13, v27

    move-object/from16 v14, v38

    move-object/from16 v6, v43

    goto :goto_505a

    :catch_50ac
    move-exception v0

    move-object/from16 v33, p1

    move-object/from16 v17, v1

    move-object/from16 v20, v2

    move-object/from16 v43, v7

    move-object v7, v13

    move-object/from16 v1, v53

    move-wide/from16 v45, v130

    move/from16 v32, v133

    move/from16 v47, v134

    move/from16 v37, v135

    move-object v13, v4

    move/from16 v4, v132

    goto/16 :goto_5003

    :catch_50c5
    move-exception v0

    move-object/from16 v32, p1

    move-object/from16 v53, v2

    goto/16 :goto_489f

    :catch_50cc
    move-exception v0

    move-object/from16 v32, p1

    move-object/from16 v35, v1

    move-object/from16 v45, v2

    move-wide/from16 v47, v122

    move/from16 v46, v124

    move/from16 v43, v125

    move/from16 v38, v126

    move/from16 v49, v127

    const/16 v34, 0x1

    move-object/from16 v33, v7

    move-object v1, v9

    move-object v9, v11

    move-object v11, v12

    move-object/from16 v17, v14

    move/from16 v7, v34

    move/from16 v37, v38

    move-object/from16 v4, v44

    move-object/from16 v52, v45

    move/from16 v45, v46

    move-wide/from16 v46, v47

    move/from16 v48, v49

    move-object/from16 v2, v53

    goto/16 :goto_48b4

    :catch_50f8
    move-exception v0

    move-object/from16 v32, p1

    move-object/from16 v53, v3

    const/16 v34, 0x1

    move/from16 v37, v2

    :goto_5101
    move-object v6, v7

    move-object/from16 v38, v17

    move-object/from16 v43, v20

    move-object/from16 v33, v27

    move-object/from16 v14, v30

    move/from16 v7, v34

    move-object/from16 v4, v44

    move/from16 v35, v47

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    move-object/from16 v2, v53

    move-object/from16 v13, v58

    move/from16 v48, v96

    goto/16 :goto_4721

    :catch_511c
    move-exception v0

    move-object/from16 v53, v1

    move/from16 v34, v4

    move-object/from16 v44, v10

    move-object/from16 v32, v12

    move/from16 v37, v2

    move-object v1, v6

    goto :goto_5101

    :catch_5129
    move-exception v0

    move/from16 v24, v3

    move-object/from16 v53, v12

    move-wide/from16 v56, v25

    move/from16 v34, v30

    move/from16 v55, v33

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v17, v48

    move-object/from16 v32, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v48, v2

    move-object/from16 v49, v10

    move v2, v13

    :goto_514f
    move/from16 v37, v2

    move-object v1, v6

    move-object v6, v7

    move-object/from16 v38, v17

    move-object/from16 v33, v27

    move/from16 v7, v34

    move-object/from16 v4, v44

    move-wide/from16 v46, v45

    move-object/from16 v17, v48

    move-object/from16 v12, v49

    move-object/from16 v2, v53

    move/from16 v48, v54

    move/from16 v45, v55

    goto/16 :goto_461b

    :catch_5169
    move-exception v0

    move-object/from16 v48, v2

    move-object/from16 v17, v4

    move-object/from16 v53, v12

    move-wide/from16 v56, v25

    move/from16 v34, v30

    move/from16 v55, v33

    move/from16 v2, v35

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v32, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move/from16 v35, v3

    move-object/from16 v49, v10

    goto :goto_514f

    :catch_5193
    move-exception v0

    :goto_5194
    move/from16 v55, v13

    move-wide/from16 v56, v25

    move/from16 v34, v30

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v17, v48

    move-object/from16 v32, v49

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v48, v2

    move-object/from16 v49, v10

    move/from16 v2, v35

    move/from16 v35, v33

    goto :goto_514f

    :catch_51bb
    move-exception v0

    move-object/from16 v53, v3

    goto :goto_5194

    :catch_51bf
    move-exception v0

    move/from16 v55, p1

    move-object/from16 v48, v2

    move-object/from16 v52, v3

    move-object/from16 v17, v4

    move-object/from16 v49, v10

    move-wide/from16 v56, v25

    move/from16 v2, v35

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v32, v43

    move/from16 v54, v96

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const/16 v34, 0x1

    move-object/from16 v43, v27

    move/from16 v35, v33

    move-object/from16 v27, v1

    goto/16 :goto_514f

    :catch_51f0
    move-exception v0

    move-object/from16 v32, v2

    move/from16 v49, v3

    move-wide/from16 v56, v25

    move/from16 v2, v37

    move/from16 v48, v38

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v13, v95

    const/4 v12, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v17, v1

    move/from16 v37, v2

    :goto_5216
    move-object/from16 v38, v4

    move-object v1, v6

    move-object v6, v7

    move v7, v12

    move-object v2, v13

    move-object/from16 v4, v44

    move-object/from16 v43, v52

    move-object/from16 v13, v58

    goto/16 :goto_3540

    :catch_5224
    move-exception v0

    move-object/from16 v44, v3

    move-object v10, v12

    move-wide/from16 v56, v25

    move-object/from16 v52, v35

    move/from16 v2, v37

    move-object/from16 v58, v42

    move-object/from16 v4, v43

    move-object/from16 v32, v49

    const/4 v12, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v35, v13

    move/from16 v49, v48

    move-object/from16 v13, v59

    move/from16 v48, v38

    move-object/from16 v17, v1

    goto :goto_5216

    :cond_5250
    move-object/from16 v44, v3

    move-object v3, v10

    move-object v10, v12

    move-wide/from16 v56, v25

    move/from16 v2, v37

    move-object/from16 v58, v42

    move-object/from16 v4, v43

    move-object/from16 v32, v49

    move-wide/from16 v54, v52

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move-object/from16 v52, v35

    move/from16 v49, v48

    move-object/from16 v35, v13

    move/from16 v48, v38

    move-object/from16 v13, v59

    :try_start_527a
    instance-of v12, v3, Lzhg;

    if-nez v12, :cond_6b66

    sget-object v12, Lyhg;->a:Lyhg;

    invoke-static {v3, v12}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12
    :try_end_5284
    .catch Ljava/util/concurrent/CancellationException; {:try_start_527a .. :try_end_5284} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_527a .. :try_end_5284} :catch_6b54
    .catchall {:try_start_527a .. :try_end_5284} :catchall_2e20

    if-eqz v12, :cond_698f

    if-eqz v39, :cond_5292

    if-nez v49, :cond_5292

    :try_start_528a
    iget-boolean v3, v7, Lexe;->E:Z

    if-eqz v3, :cond_5292

    iget-object v3, v15, Lixe;->E:Ljava/lang/Object;
    :try_end_5290
    .catch Ljava/util/concurrent/CancellationException; {:try_start_528a .. :try_end_5290} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_528a .. :try_end_5290} :catch_694b
    .catchall {:try_start_528a .. :try_end_5290} :catchall_2e20

    if-nez v3, :cond_52a5

    :cond_5292
    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v3, v13

    move-object/from16 v12, v35

    move/from16 v38, v48

    move-object/from16 v35, v52

    move-wide/from16 v52, v54

    const/16 v30, 0x1

    goto/16 :goto_6967

    :cond_52a5
    :try_start_52a5
    new-instance v3, Lvmg;
    :try_end_52a7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52a5 .. :try_end_52a7} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52a5 .. :try_end_52a7} :catch_6920
    .catchall {:try_start_52a5 .. :try_end_52a7} :catchall_2e20

    const/4 v12, 0x1

    :try_start_52a8
    invoke-direct {v3, v12, v12}, Lvmg;-><init>(ZZ)V
    :try_end_52ab
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52a8 .. :try_end_52ab} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52a8 .. :try_end_52ab} :catch_693a
    .catchall {:try_start_52a8 .. :try_end_52ab} :catchall_2e20

    :try_start_52ab
    iput-object v6, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_52b5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52ab .. :try_end_52b5} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52ab .. :try_end_52b5} :catch_6920
    .catchall {:try_start_52ab .. :try_end_52b5} :catchall_2e20

    :try_start_52b5
    move-object/from16 v12, v36

    check-cast v12, Ljava/util/List;

    iput-object v12, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v12, v41

    check-cast v12, Ljava/util/List;

    iput-object v12, v5, Laak;->J:Ljava/util/List;
    :try_end_52c1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52b5 .. :try_end_52c1} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52b5 .. :try_end_52c1} :catch_692b
    .catchall {:try_start_52b5 .. :try_end_52c1} :catchall_2e20

    :try_start_52c1
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v7, v5, Laak;->M:Lexe;

    iput-object v10, v5, Laak;->N:Lexe;

    iput-object v4, v5, Laak;->O:Lexe;
    :try_end_52cb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52c1 .. :try_end_52cb} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52c1 .. :try_end_52cb} :catch_6920
    .catchall {:try_start_52c1 .. :try_end_52cb} :catchall_2e20

    move-object/from16 v12, v35

    :try_start_52cd
    iput-object v12, v5, Laak;->P:Lixe;
    :try_end_52cf
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52cd .. :try_end_52cf} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52cd .. :try_end_52cf} :catch_6913
    .catchall {:try_start_52cd .. :try_end_52cf} :catchall_2e20

    move-object/from16 v17, v1

    move-object/from16 v1, v52

    :try_start_52d3
    iput-object v1, v5, Laak;->Q:Lixe;
    :try_end_52d5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52d3 .. :try_end_52d5} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52d3 .. :try_end_52d5} :catch_690f
    .catchall {:try_start_52d3 .. :try_end_52d5} :catchall_2e20

    move-object/from16 v35, v1

    move-object/from16 v1, v33

    :try_start_52d9
    iput-object v1, v5, Laak;->R:Lcp2;
    :try_end_52db
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52d9 .. :try_end_52db} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52d9 .. :try_end_52db} :catch_690b
    .catchall {:try_start_52d9 .. :try_end_52db} :catchall_2e20

    move-object/from16 v33, v1

    const/4 v1, 0x0

    :try_start_52de
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v1, v27

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v27, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    iput v2, v5, Laak;->e0:I
    :try_end_52f1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52de .. :try_end_52f1} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52de .. :try_end_52f1} :catch_6902
    .catchall {:try_start_52de .. :try_end_52f1} :catchall_2e20

    move/from16 v1, v48

    :try_start_52f3
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_52f5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52f3 .. :try_end_52f5} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52f3 .. :try_end_52f5} :catch_68fe
    .catchall {:try_start_52f3 .. :try_end_52f5} :catchall_2e20

    move/from16 v38, v1

    move/from16 v1, v45

    :try_start_52f9
    iput v1, v5, Laak;->f0:I
    :try_end_52fb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_52f9 .. :try_end_52fb} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_52f9 .. :try_end_52fb} :catch_68f8
    .catchall {:try_start_52f9 .. :try_end_52fb} :catchall_2e20

    move/from16 v45, v1

    move/from16 v37, v2

    move-wide/from16 v1, v46

    :try_start_5301
    iput-wide v1, v5, Laak;->k0:J
    :try_end_5303
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5301 .. :try_end_5303} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_5301 .. :try_end_5303} :catch_68f4
    .catchall {:try_start_5301 .. :try_end_5303} :catchall_2e20

    move-wide/from16 v46, v1

    const/4 v1, 0x1

    :try_start_5306
    iput v1, v5, Laak;->g0:I
    :try_end_5308
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5306 .. :try_end_5308} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_5306 .. :try_end_5308} :catch_68ed
    .catchall {:try_start_5306 .. :try_end_5308} :catchall_2e20

    move-wide/from16 v1, v54

    :try_start_530a
    iput-wide v1, v5, Laak;->l0:J

    move-wide/from16 v52, v1

    const/16 v1, 0x1c

    iput v1, v5, Laak;->m0:I

    invoke-virtual {v6, v5, v3}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_5316
    .catch Ljava/util/concurrent/CancellationException; {:try_start_530a .. :try_end_5316} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_530a .. :try_end_5316} :catch_68d2
    .catchall {:try_start_530a .. :try_end_5316} :catchall_2e20

    if-ne v1, v13, :cond_531a

    goto/16 :goto_3a89

    :cond_531a
    move-object v2, v4

    move-object v1, v10

    move-object v3, v12

    move-object/from16 v59, v13

    move-object/from16 v10, v17

    move-object/from16 v13, v27

    move-object/from16 v4, v35

    move/from16 v27, v37

    move/from16 v20, v38

    move/from16 v17, v45

    move-wide/from16 v138, v46

    move-wide/from16 v136, v52

    const/16 v140, 0x1

    move-object v12, v7

    move-object/from16 v47, v36

    move-object/from16 v46, v41

    move-object v7, v6

    move-object/from16 v6, v33

    :goto_5339
    :try_start_5339
    invoke-static/range {v58 .. v58}, Leak;->i(Leak;)Lapg;

    move-result-object v33
    :try_end_533d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5339 .. :try_end_533d} :catch_6896
    .catch Ljava/lang/Exception; {:try_start_5339 .. :try_end_533d} :catch_6778
    .catchall {:try_start_5339 .. :try_end_533d} :catchall_2e20

    move-object/from16 v34, v13

    :try_start_533f
    iget-object v13, v5, Laak;->r0:Ljava/lang/String;

    move-object/from16 v35, v13

    iget-object v13, v15, Lixe;->E:Ljava/lang/Object;

    check-cast v13, Ljava/lang/String;

    const/16 v36, 0xc8

    invoke-static/range {v36 .. v36}, Lin6;->h(I)Ljava/lang/Integer;

    move-result-object v36

    iput-object v7, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_5357
    .catch Ljava/util/concurrent/CancellationException; {:try_start_533f .. :try_end_5357} :catch_6784
    .catch Ljava/lang/Exception; {:try_start_533f .. :try_end_5357} :catch_6778
    .catchall {:try_start_533f .. :try_end_5357} :catchall_2e20

    move-object/from16 v37, v7

    :try_start_5359
    move-object/from16 v7, v47

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v7, v46

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->J:Ljava/util/List;
    :try_end_5365
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5359 .. :try_end_5365} :catch_6760
    .catch Ljava/lang/Exception; {:try_start_5359 .. :try_end_5365} :catch_6748
    .catchall {:try_start_5359 .. :try_end_5365} :catchall_2e20

    :try_start_5365
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v1, v5, Laak;->N:Lexe;

    iput-object v2, v5, Laak;->O:Lexe;

    iput-object v3, v5, Laak;->P:Lixe;

    iput-object v4, v5, Laak;->Q:Lixe;

    iput-object v6, v5, Laak;->R:Lcp2;

    const/4 v7, 0x0

    iput-object v7, v5, Laak;->S:Lpe9;

    iput-object v7, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;
    :try_end_537c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5365 .. :try_end_537c} :catch_6740
    .catch Ljava/lang/Exception; {:try_start_5365 .. :try_end_537c} :catch_6738
    .catchall {:try_start_5365 .. :try_end_537c} :catchall_2e20

    move-object/from16 v38, v3

    move-object/from16 v3, v34

    :try_start_5380
    iput-object v3, v5, Laak;->V:Ljava/lang/Object;

    iput-object v7, v5, Laak;->W:Long;

    iput-object v7, v5, Laak;->X:Ljava/lang/Object;
    :try_end_5386
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5380 .. :try_end_5386} :catch_6726
    .catch Ljava/lang/Exception; {:try_start_5380 .. :try_end_5386} :catch_6712
    .catchall {:try_start_5380 .. :try_end_5386} :catchall_2e20

    move/from16 v7, v27

    :try_start_5388
    iput v7, v5, Laak;->e0:I
    :try_end_538a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5388 .. :try_end_538a} :catch_670c
    .catch Ljava/lang/Exception; {:try_start_5388 .. :try_end_538a} :catch_6706
    .catchall {:try_start_5388 .. :try_end_538a} :catchall_2e20

    move-object/from16 v34, v3

    move/from16 v3, v20

    :try_start_538e
    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_5390
    .catch Ljava/util/concurrent/CancellationException; {:try_start_538e .. :try_end_5390} :catch_66ef
    .catch Ljava/lang/Exception; {:try_start_538e .. :try_end_5390} :catch_66d6
    .catchall {:try_start_538e .. :try_end_5390} :catchall_2e20

    move/from16 v20, v3

    move/from16 v3, v17

    :try_start_5394
    iput v3, v5, Laak;->f0:I
    :try_end_5396
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5394 .. :try_end_5396} :catch_66c4
    .catch Ljava/lang/Exception; {:try_start_5394 .. :try_end_5396} :catch_66af
    .catchall {:try_start_5394 .. :try_end_5396} :catchall_2e20

    move/from16 v27, v3

    move-object/from16 v17, v4

    move-wide/from16 v3, v138

    :try_start_539c
    iput-wide v3, v5, Laak;->k0:J
    :try_end_539e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_539c .. :try_end_539e} :catch_66a7
    .catch Ljava/lang/Exception; {:try_start_539c .. :try_end_539e} :catch_669f
    .catchall {:try_start_539c .. :try_end_539e} :catchall_2e20

    move-wide/from16 v48, v3

    move/from16 v3, v140

    :try_start_53a2
    iput v3, v5, Laak;->g0:I
    :try_end_53a4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_53a2 .. :try_end_53a4} :catch_668d
    .catch Ljava/lang/Exception; {:try_start_53a2 .. :try_end_53a4} :catch_6691
    .catchall {:try_start_53a2 .. :try_end_53a4} :catchall_2e20

    move/from16 v41, v3

    move-wide/from16 v3, v136

    :try_start_53a8
    iput-wide v3, v5, Laak;->l0:J
    :try_end_53aa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_53a8 .. :try_end_53aa} :catch_668d
    .catch Ljava/lang/Exception; {:try_start_53a8 .. :try_end_53aa} :catch_6689
    .catchall {:try_start_53a8 .. :try_end_53aa} :catchall_2e20

    move-object/from16 v43, v1

    const/16 v1, 0x1d

    :try_start_53ae
    iput v1, v5, Laak;->m0:I
    :try_end_53b0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_53ae .. :try_end_53b0} :catch_6681
    .catch Ljava/lang/Exception; {:try_start_53ae .. :try_end_53b0} :catch_6677
    .catchall {:try_start_53ae .. :try_end_53b0} :catchall_2e20

    move-wide/from16 v52, v3

    const/4 v3, 0x0

    move-object v1, v6

    const/16 v6, 0x14

    move-object v4, v13

    move-object v13, v0

    move-object/from16 v0, v33

    move-object/from16 v33, v1

    move-object/from16 v1, v35

    move/from16 v35, v41

    move-object/from16 v41, v2

    move-object v2, v4

    move-object/from16 v4, v36

    move/from16 v36, v7

    const/4 v7, 0x0

    :try_start_53c8
    invoke-static/range {v0 .. v6}, Lapg;->k(Lapg;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lc75;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_53cc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_53c8 .. :try_end_53cc} :catch_6659
    .catch Ljava/lang/Exception; {:try_start_53c8 .. :try_end_53cc} :catch_663a
    .catchall {:try_start_53c8 .. :try_end_53cc} :catchall_2e20

    move-object/from16 v1, v59

    if-ne v0, v1, :cond_53d2

    goto/16 :goto_1e7c

    :cond_53d2
    move-object/from16 v145, v13

    move-object/from16 v143, v17

    move/from16 v151, v20

    move/from16 v146, v27

    move-object/from16 v144, v33

    move-object/from16 v153, v34

    move/from16 v2, v35

    move/from16 v152, v36

    move-object/from16 v4, v37

    move-object/from16 v142, v38

    move-object/from16 v13, v43

    move-wide/from16 v149, v48

    move-wide/from16 v147, v52

    goto/16 :goto_a2c

    :goto_53ee
    :try_start_53ee
    check-cast v0, Lcom/anthropic/claude/api/result/ApiResult;

    instance-of v7, v0, Lqg0;
    :try_end_53f2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_53ee .. :try_end_53f2} :catch_661e
    .catch Ljava/lang/Exception; {:try_start_53ee .. :try_end_53f2} :catch_6600
    .catchall {:try_start_53ee .. :try_end_53f2} :catchall_2e20

    if-eqz v7, :cond_6350

    :try_start_53f4
    move-object v7, v0

    check-cast v7, Lqg0;

    invoke-virtual {v7}, Lqg0;->a()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/anthropic/claude/sessions/types/EventListResponse;

    invoke-virtual {v7}, Lcom/anthropic/claude/sessions/types/EventListResponse;->getData()Ljava/util/List;

    move-result-object v7

    check-cast v7, Ljava/util/Collection;
    :try_end_5403
    .catch Ljava/util/concurrent/CancellationException; {:try_start_53f4 .. :try_end_5403} :catch_634a
    .catch Ljava/lang/Exception; {:try_start_53f4 .. :try_end_5403} :catch_632e
    .catchall {:try_start_53f4 .. :try_end_5403} :catchall_2e20

    move-object/from16 v59, v1

    const/4 v1, 0x0

    :try_start_5406
    invoke-interface {v3, v1, v7}, Ljava/util/List;->addAll(ILjava/util/Collection;)Z

    move-object v1, v0

    check-cast v1, Lqg0;

    invoke-virtual {v1}, Lqg0;->a()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/anthropic/claude/sessions/types/EventListResponse;

    invoke-virtual {v1}, Lcom/anthropic/claude/sessions/types/EventListResponse;->getData()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {v1, v6}, Lsm4;->r0(ILjava/util/List;)Ljava/util/List;

    move-result-object v1
    :try_end_541e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5406 .. :try_end_541e} :catch_6312
    .catch Ljava/lang/Exception; {:try_start_5406 .. :try_end_541e} :catch_62f4
    .catchall {:try_start_5406 .. :try_end_541e} :catchall_2e20

    :try_start_541e
    move-object v6, v0

    check-cast v6, Lqg0;

    invoke-virtual {v6}, Lqg0;->a()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/anthropic/claude/sessions/types/EventListResponse;

    invoke-virtual {v6}, Lcom/anthropic/claude/sessions/types/EventListResponse;->getFirst_id()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v15, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lqg0;

    invoke-virtual {v0}, Lqg0;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/anthropic/claude/sessions/types/EventListResponse;

    invoke-virtual {v0}, Lcom/anthropic/claude/sessions/types/EventListResponse;->getHas_more()Z

    move-result v0

    iput-boolean v0, v12, Lexe;->E:Z

    invoke-virtual/range {v32 .. v32}, Lnlh;->c()Lhhg;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v0, v3, v6, v7}, Lhhg;->q(Lhhg;Ljava/util/List;Lpg0;I)Ldla;

    move-result-object v0

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ldla;->iterator()Ljava/util/Iterator;

    move-result-object v16
    :try_end_544e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_541e .. :try_end_544e} :catch_62f0
    .catch Ljava/lang/Exception; {:try_start_541e .. :try_end_544e} :catch_62ec
    .catchall {:try_start_541e .. :try_end_544e} :catchall_2e20

    :goto_544e
    :try_start_544e
    move-object/from16 v17, v16

    check-cast v17, Lcla;

    invoke-virtual/range {v17 .. v17}, Lcla;->hasNext()Z

    move-result v20
    :try_end_5456
    .catch Ljava/util/concurrent/CancellationException; {:try_start_544e .. :try_end_5456} :catch_62e8
    .catch Ljava/lang/Exception; {:try_start_544e .. :try_end_5456} :catch_62e4
    .catchall {:try_start_544e .. :try_end_5456} :catchall_2e20

    if-eqz v20, :cond_54ab

    :try_start_5458
    invoke-virtual/range {v17 .. v17}, Lcla;->next()Ljava/lang/Object;

    move-result-object v7
    :try_end_545c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5458 .. :try_end_545c} :catch_54a7
    .catch Ljava/lang/Exception; {:try_start_5458 .. :try_end_545c} :catch_54a3
    .catchall {:try_start_5458 .. :try_end_545c} :catchall_2e20

    move-object/from16 p1, v1

    :try_start_545e
    instance-of v1, v7, Lmng;

    if-eqz v1, :cond_5465

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_5465
    .catch Ljava/util/concurrent/CancellationException; {:try_start_545e .. :try_end_5465} :catch_5485
    .catch Ljava/lang/Exception; {:try_start_545e .. :try_end_5465} :catch_5469
    .catchall {:try_start_545e .. :try_end_5465} :catchall_2e20

    :cond_5465
    move-object/from16 v1, p1

    const/4 v7, 0x6

    goto :goto_544e

    :catch_5469
    move-exception v0

    :goto_546a
    move-object/from16 v47, p1

    move-object/from16 v48, v3

    move-object v1, v4

    :goto_546f
    move-object/from16 v6, v141

    move-object/from16 v7, v142

    move-object/from16 v3, v143

    move-object/from16 v4, v144

    move/from16 v16, v146

    move-wide/from16 v195, v147

    move-wide/from16 v197, v149

    move/from16 v17, v151

    move/from16 v20, v152

    :goto_5481
    const/16 v30, 0x1

    goto/16 :goto_6790

    :catch_5485
    move-exception v0

    :goto_5486
    move-object/from16 v47, p1

    move-object/from16 v48, v3

    move-object v1, v4

    move-object/from16 v17, v13

    move-object/from16 v3, v59

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v13, v144

    move/from16 v42, v146

    move-wide/from16 v6, v149

    move/from16 v33, v151

    move/from16 v27, v152

    :goto_549f
    const/16 v30, 0x1

    goto/16 :goto_68af

    :catch_54a3
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_546a

    :catch_54a7
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_5486

    :cond_54ab
    move-object/from16 p1, v1

    :try_start_54ad
    invoke-static {v6}, Lsm4;->D0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lmng;
    :try_end_54b3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_54ad .. :try_end_54b3} :catch_62e0
    .catch Ljava/lang/Exception; {:try_start_54ad .. :try_end_54b3} :catch_62dc
    .catchall {:try_start_54ad .. :try_end_54b3} :catchall_2e20

    if-eqz v1, :cond_54ba

    :try_start_54b5
    invoke-virtual {v1}, Lmng;->a()Ljava/lang/String;

    move-result-object v1

    goto :goto_54bb

    :cond_54ba
    const/4 v1, 0x0

    :goto_54bb
    if-eqz v1, :cond_54c3

    const/4 v7, 0x0

    iput-object v7, v15, Lixe;->E:Ljava/lang/Object;

    const/4 v7, 0x0

    iput-boolean v7, v12, Lexe;->E:Z
    :try_end_54c3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_54b5 .. :try_end_54c3} :catch_5485
    .catch Ljava/lang/Exception; {:try_start_54b5 .. :try_end_54c3} :catch_5469
    .catchall {:try_start_54b5 .. :try_end_54c3} :catchall_2e20

    :cond_54c3
    :try_start_54c3
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ldla;->iterator()Ljava/util/Iterator;

    move-result-object v7
    :try_end_54cc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_54c3 .. :try_end_54cc} :catch_62e0
    .catch Ljava/lang/Exception; {:try_start_54c3 .. :try_end_54cc} :catch_62dc
    .catchall {:try_start_54c3 .. :try_end_54cc} :catchall_2e20

    :goto_54cc
    :try_start_54cc
    move-object/from16 v16, v7

    check-cast v16, Lcla;

    invoke-virtual/range {v16 .. v16}, Lcla;->hasNext()Z

    move-result v17
    :try_end_54d4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_54cc .. :try_end_54d4} :catch_62d8
    .catch Ljava/lang/Exception; {:try_start_54cc .. :try_end_54d4} :catch_62d4
    .catchall {:try_start_54cc .. :try_end_54d4} :catchall_2e20

    if-eqz v17, :cond_5510

    move-object/from16 v17, v3

    :try_start_54d8
    invoke-virtual/range {v16 .. v16}, Lcla;->next()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v16, v7

    instance-of v7, v3, Lxmg;

    if-eqz v7, :cond_54e5

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_54e5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_54d8 .. :try_end_54e5} :catch_54f2
    .catch Ljava/lang/Exception; {:try_start_54d8 .. :try_end_54e5} :catch_54ea
    .catchall {:try_start_54d8 .. :try_end_54e5} :catchall_2e20

    :cond_54e5
    move-object/from16 v7, v16

    move-object/from16 v3, v17

    goto :goto_54cc

    :catch_54ea
    move-exception v0

    move-object/from16 v47, p1

    move-object v1, v4

    move-object/from16 v48, v17

    goto/16 :goto_546f

    :catch_54f2
    move-exception v0

    move-object/from16 v47, p1

    move-object v1, v4

    move-object/from16 v48, v17

    move-object/from16 v3, v59

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move/from16 v42, v146

    move-wide/from16 v6, v149

    move/from16 v33, v151

    move/from16 v27, v152

    const/16 v30, 0x1

    move-object/from16 v17, v13

    move-object/from16 v13, v144

    goto/16 :goto_68af

    :cond_5510
    move-object/from16 v17, v3

    :try_start_5512
    invoke-static {v6}, Lsm4;->O0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lxmg;

    const/4 v7, 0x3

    invoke-static {v3, v1, v7}, Lxmg;->a(Lxmg;Ljava/lang/String;I)Lxmg;

    move-result-object v1

    iput-object v4, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_5527
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5512 .. :try_end_5527} :catch_629b
    .catch Ljava/lang/Exception; {:try_start_5512 .. :try_end_5527} :catch_6295
    .catchall {:try_start_5512 .. :try_end_5527} :catchall_2e20

    :try_start_5527
    move-object/from16 v3, v17

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v3, p1

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->J:Ljava/util/List;
    :try_end_5533
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5527 .. :try_end_5533} :catch_62b9
    .catch Ljava/lang/Exception; {:try_start_5527 .. :try_end_5533} :catch_62a1
    .catchall {:try_start_5527 .. :try_end_5533} :catchall_2e20

    :try_start_5533
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v13, v5, Laak;->N:Lexe;
    :try_end_553b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5533 .. :try_end_553b} :catch_629b
    .catch Ljava/lang/Exception; {:try_start_5533 .. :try_end_553b} :catch_6295
    .catchall {:try_start_5533 .. :try_end_553b} :catchall_2e20

    move-object/from16 v3, v141

    :try_start_553d
    iput-object v3, v5, Laak;->O:Lexe;
    :try_end_553f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_553d .. :try_end_553f} :catch_628d
    .catch Ljava/lang/Exception; {:try_start_553d .. :try_end_553f} :catch_6285
    .catchall {:try_start_553d .. :try_end_553f} :catchall_2e20

    move-object/from16 v6, v142

    :try_start_5541
    iput-object v6, v5, Laak;->P:Lixe;
    :try_end_5543
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5541 .. :try_end_5543} :catch_627b
    .catch Ljava/lang/Exception; {:try_start_5541 .. :try_end_5543} :catch_6271
    .catchall {:try_start_5541 .. :try_end_5543} :catchall_2e20

    move-object/from16 v7, v143

    :try_start_5545
    iput-object v7, v5, Laak;->Q:Lixe;
    :try_end_5547
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5545 .. :try_end_5547} :catch_6265
    .catch Ljava/lang/Exception; {:try_start_5545 .. :try_end_5547} :catch_6259
    .catchall {:try_start_5545 .. :try_end_5547} :catchall_2e20

    move-object/from16 v16, v3

    move-object/from16 v3, v144

    :try_start_554b
    iput-object v3, v5, Laak;->R:Lcp2;
    :try_end_554d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_554b .. :try_end_554d} :catch_6255
    .catch Ljava/lang/Exception; {:try_start_554b .. :try_end_554d} :catch_6251
    .catchall {:try_start_554b .. :try_end_554d} :catchall_2e20

    move-object/from16 v20, v3

    const/4 v3, 0x0

    :try_start_5550
    iput-object v3, v5, Laak;->S:Lpe9;

    iput-object v3, v5, Laak;->T:Lexe;

    move-object/from16 v3, v145

    iput-object v3, v5, Laak;->U:Lcp2;

    move-object/from16 v27, v3

    move-object/from16 v3, v153

    iput-object v3, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v33, v3

    const/4 v3, 0x0

    iput-object v3, v5, Laak;->W:Long;

    iput-object v3, v5, Laak;->X:Ljava/lang/Object;

    iput-object v3, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v0, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v3, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->b0:Ljava/lang/Object;
    :try_end_556d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5550 .. :try_end_556d} :catch_6240
    .catch Ljava/lang/Exception; {:try_start_5550 .. :try_end_556d} :catch_622d
    .catchall {:try_start_5550 .. :try_end_556d} :catchall_2e20

    move/from16 v3, v152

    :try_start_556f
    iput v3, v5, Laak;->e0:I
    :try_end_5571
    .catch Ljava/util/concurrent/CancellationException; {:try_start_556f .. :try_end_5571} :catch_621d
    .catch Ljava/lang/Exception; {:try_start_556f .. :try_end_5571} :catch_620a
    .catchall {:try_start_556f .. :try_end_5571} :catchall_2e20

    move/from16 v35, v3

    move/from16 v3, v151

    :try_start_5575
    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_5577
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5575 .. :try_end_5577} :catch_61fe
    .catch Ljava/lang/Exception; {:try_start_5575 .. :try_end_5577} :catch_61f2
    .catchall {:try_start_5575 .. :try_end_5577} :catchall_2e20

    move/from16 v36, v3

    move/from16 v3, v146

    :try_start_557b
    iput v3, v5, Laak;->f0:I
    :try_end_557d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_557b .. :try_end_557d} :catch_61e6
    .catch Ljava/lang/Exception; {:try_start_557b .. :try_end_557d} :catch_61d8
    .catchall {:try_start_557b .. :try_end_557d} :catchall_2e20

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-wide/from16 v6, v149

    :try_start_5583
    iput-wide v6, v5, Laak;->k0:J

    iput v2, v5, Laak;->g0:I
    :try_end_5587
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5583 .. :try_end_5587} :catch_61d4
    .catch Ljava/lang/Exception; {:try_start_5583 .. :try_end_5587} :catch_61cc
    .catchall {:try_start_5583 .. :try_end_5587} :catchall_2e20

    move/from16 v41, v2

    move/from16 v42, v3

    move-wide/from16 v2, v147

    :try_start_558d
    iput-wide v2, v5, Laak;->l0:J
    :try_end_558f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_558d .. :try_end_558f} :catch_61b3
    .catch Ljava/lang/Exception; {:try_start_558d .. :try_end_558f} :catch_61c8
    .catchall {:try_start_558d .. :try_end_558f} :catchall_2e20

    move-wide/from16 v45, v2

    const/16 v2, 0x1e

    :try_start_5593
    iput v2, v5, Laak;->m0:I

    invoke-virtual {v4, v5, v1}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_5599
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5593 .. :try_end_5599} :catch_61b3
    .catch Ljava/lang/Exception; {:try_start_5593 .. :try_end_5599} :catch_6195
    .catchall {:try_start_5593 .. :try_end_5599} :catchall_2e20

    move-object/from16 v3, v59

    if-ne v1, v3, :cond_559f

    goto/16 :goto_2cea

    :cond_559f
    move-object/from16 v47, p1

    move-object/from16 p1, v0

    move-object/from16 v59, v3

    move-wide/from16 v158, v6

    move-object v1, v13

    move-object/from16 v6, v16

    move-object/from16 v48, v17

    move-object/from16 v2, v20

    move-object/from16 v16, v27

    move-object/from16 v154, v33

    move/from16 v161, v35

    move/from16 v160, v36

    move-object/from16 v7, v37

    move-object/from16 v13, v38

    move/from16 v0, v41

    move/from16 v155, v42

    move-wide/from16 v156, v45

    :goto_55c0
    :try_start_55c0
    iget-boolean v3, v1, Lexe;->E:Z

    if-nez v3, :cond_5b00

    move-object/from16 v3, p1

    check-cast v3, Ljava/lang/Iterable;

    move-object/from16 v17, v3

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_55d3
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v20
    :try_end_55d7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_55c0 .. :try_end_55d7} :catch_5ae9
    .catch Ljava/lang/Exception; {:try_start_55c0 .. :try_end_55d7} :catch_5ad0
    .catchall {:try_start_55c0 .. :try_end_55d7} :catchall_2e20

    if-eqz v20, :cond_5620

    move-object/from16 v20, v2

    :try_start_55db
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2
    :try_end_55df
    .catch Ljava/util/concurrent/CancellationException; {:try_start_55db .. :try_end_55df} :catch_561c
    .catch Ljava/lang/Exception; {:try_start_55db .. :try_end_55df} :catch_5618
    .catchall {:try_start_55db .. :try_end_55df} :catchall_2e20

    move-object/from16 v27, v13

    :try_start_55e1
    instance-of v13, v2, Lgng;

    if-eqz v13, :cond_55e8

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_55e8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_55e1 .. :try_end_55e8} :catch_5600
    .catch Ljava/lang/Exception; {:try_start_55e1 .. :try_end_55e8} :catch_55ed
    .catchall {:try_start_55e1 .. :try_end_55e8} :catchall_2e20

    :cond_55e8
    move-object/from16 v2, v20

    move-object/from16 v13, v27

    goto :goto_55d3

    :catch_55ed
    move-exception v0

    :goto_55ee
    move-object v13, v1

    move-object v1, v4

    move-object/from16 v4, v20

    move-object/from16 v3, v27

    move/from16 v16, v155

    move-wide/from16 v195, v156

    move-wide/from16 v197, v158

    move/from16 v17, v160

    move/from16 v20, v161

    goto/16 :goto_5481

    :catch_5600
    move-exception v0

    :goto_5601
    move-object/from16 v17, v1

    move-object v1, v4

    move-object/from16 v16, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v38, v27

    move-object/from16 v3, v59

    move/from16 v42, v155

    move-wide/from16 v6, v158

    move/from16 v33, v160

    move/from16 v27, v161

    goto/16 :goto_549f

    :catch_5618
    move-exception v0

    move-object/from16 v27, v13

    goto :goto_55ee

    :catch_561c
    move-exception v0

    move-object/from16 v27, v13

    goto :goto_5601

    :cond_5620
    move-object/from16 v20, v2

    move-object/from16 v27, v13

    :try_start_5624
    invoke-static {v3}, Lsm4;->D0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lgng;

    if-eqz v2, :cond_5846

    iput-object v4, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_5636
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5624 .. :try_end_5636} :catch_5805
    .catch Ljava/lang/Exception; {:try_start_5624 .. :try_end_5636} :catch_57f9
    .catchall {:try_start_5624 .. :try_end_5636} :catchall_2e20

    :try_start_5636
    move-object/from16 v3, v48

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v3, v47

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->J:Ljava/util/List;
    :try_end_5642
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5636 .. :try_end_5642} :catch_582b
    .catch Ljava/lang/Exception; {:try_start_5636 .. :try_end_5642} :catch_5811
    .catchall {:try_start_5636 .. :try_end_5642} :catchall_2e20

    :try_start_5642
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v1, v5, Laak;->N:Lexe;

    iput-object v6, v5, Laak;->O:Lexe;

    iput-object v7, v5, Laak;->P:Lixe;
    :try_end_564e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5642 .. :try_end_564e} :catch_5805
    .catch Ljava/lang/Exception; {:try_start_5642 .. :try_end_564e} :catch_57f9
    .catchall {:try_start_5642 .. :try_end_564e} :catchall_2e20

    move-object/from16 v3, v27

    :try_start_5650
    iput-object v3, v5, Laak;->Q:Lixe;
    :try_end_5652
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5650 .. :try_end_5652} :catch_57ef
    .catch Ljava/lang/Exception; {:try_start_5650 .. :try_end_5652} :catch_57e5
    .catchall {:try_start_5650 .. :try_end_5652} :catchall_2e20

    move-object/from16 v13, v20

    :try_start_5654
    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_5656
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5654 .. :try_end_5656} :catch_57e1
    .catch Ljava/lang/Exception; {:try_start_5654 .. :try_end_5656} :catch_57dd
    .catchall {:try_start_5654 .. :try_end_5656} :catchall_2e20

    move-object/from16 v17, v1

    const/4 v1, 0x0

    :try_start_5659
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    move-object/from16 v1, v16

    iput-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v16, v1

    move-object/from16 v1, v154

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v20, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v1, p1

    iput-object v1, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 v27, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_567d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5659 .. :try_end_567d} :catch_57cc
    .catch Ljava/lang/Exception; {:try_start_5659 .. :try_end_567d} :catch_57b9
    .catchall {:try_start_5659 .. :try_end_567d} :catchall_2e20

    move/from16 v1, v161

    :try_start_567f
    iput v1, v5, Laak;->e0:I
    :try_end_5681
    .catch Ljava/util/concurrent/CancellationException; {:try_start_567f .. :try_end_5681} :catch_57a8
    .catch Ljava/lang/Exception; {:try_start_567f .. :try_end_5681} :catch_5795
    .catchall {:try_start_567f .. :try_end_5681} :catchall_2e20

    move/from16 v33, v1

    move/from16 v1, v160

    :try_start_5685
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_5687
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5685 .. :try_end_5687} :catch_5789
    .catch Ljava/lang/Exception; {:try_start_5685 .. :try_end_5687} :catch_577d
    .catchall {:try_start_5685 .. :try_end_5687} :catchall_2e20

    move/from16 v35, v1

    move/from16 v1, v155

    :try_start_568b
    iput v1, v5, Laak;->f0:I
    :try_end_568d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_568b .. :try_end_568d} :catch_5771
    .catch Ljava/lang/Exception; {:try_start_568b .. :try_end_568d} :catch_5763
    .catchall {:try_start_568b .. :try_end_568d} :catchall_2e20

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-wide/from16 v6, v158

    :try_start_5693
    iput-wide v6, v5, Laak;->k0:J

    iput v0, v5, Laak;->g0:I
    :try_end_5697
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5693 .. :try_end_5697} :catch_5752
    .catch Ljava/lang/Exception; {:try_start_5693 .. :try_end_5697} :catch_5748
    .catchall {:try_start_5693 .. :try_end_5697} :catchall_2e20

    move-wide/from16 v41, v6

    move-wide/from16 v6, v156

    :try_start_569b
    iput-wide v6, v5, Laak;->l0:J
    :try_end_569d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_569b .. :try_end_569d} :catch_5744
    .catch Ljava/lang/Exception; {:try_start_569b .. :try_end_569d} :catch_5740
    .catchall {:try_start_569b .. :try_end_569d} :catchall_2e20

    move/from16 v38, v1

    const/16 v1, 0x1f

    :try_start_56a1
    iput v1, v5, Laak;->m0:I

    invoke-virtual {v4, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_56a7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_56a1 .. :try_end_56a7} :catch_5731
    .catch Ljava/lang/Exception; {:try_start_56a1 .. :try_end_56a7} :catch_5718
    .catchall {:try_start_56a1 .. :try_end_56a7} :catchall_2e20

    move-object/from16 v2, v59

    if-ne v1, v2, :cond_56ad

    goto/16 :goto_7700

    :cond_56ad
    move/from16 v1, v35

    move-object/from16 v35, v4

    move v4, v1

    move-object/from16 v45, v10

    move-object/from16 v46, v15

    move-object/from16 v1, v17

    move-object/from16 v10, v27

    goto/16 :goto_8ca

    :goto_56bc
    :try_start_56bc
    iput-boolean v15, v1, Lexe;->E:Z
    :try_end_56be
    .catch Ljava/util/concurrent/CancellationException; {:try_start_56bc .. :try_end_56be} :catch_56fe
    .catch Ljava/lang/Exception; {:try_start_56bc .. :try_end_56be} :catch_56e1
    .catchall {:try_start_56bc .. :try_end_56be} :catchall_2e20

    move-object/from16 v30, v3

    move-object v3, v1

    move-object v1, v12

    move-object/from16 v12, v30

    move-object/from16 v59, v2

    move/from16 v168, v4

    move-object v2, v10

    move/from16 v30, v15

    move-object/from16 v4, v35

    move-object/from16 v10, v45

    move-object/from16 v15, v46

    :goto_56d1
    move-wide/from16 v164, v6

    move-object/from16 v162, v20

    move/from16 v169, v33

    move-object/from16 v6, v36

    move-object/from16 v7, v37

    move/from16 v163, v38

    move-wide/from16 v166, v41

    goto/16 :goto_586a

    :catch_56e1
    move-exception v0

    move-object/from16 v59, v2

    move/from16 v17, v4

    move-wide/from16 v195, v6

    move-object v4, v13

    move/from16 v30, v15

    move/from16 v20, v33

    move-object/from16 v6, v36

    move-object/from16 v7, v37

    move/from16 v16, v38

    move-wide/from16 v197, v41

    move-object/from16 v10, v45

    move-object/from16 v15, v46

    move-object v13, v1

    move-object/from16 v1, v35

    goto/16 :goto_6790

    :catch_56fe
    move-exception v0

    move-object/from16 v17, v1

    move/from16 v30, v15

    move/from16 v27, v33

    move-object/from16 v1, v35

    move-object/from16 v16, v36

    move-wide/from16 v6, v41

    move-object/from16 v10, v45

    move-object/from16 v15, v46

    move/from16 v33, v4

    :goto_5711
    move/from16 v42, v38

    move-object/from16 v38, v3

    :goto_5715
    move-object v3, v2

    goto/16 :goto_68af

    :catch_5718
    move-exception v0

    :goto_5719
    move-object/from16 v2, v59

    :goto_571b
    const/16 v30, 0x1

    :goto_571d
    move-object v1, v4

    move-wide/from16 v195, v6

    move-object v4, v13

    move-object/from16 v13, v17

    move/from16 v20, v33

    move/from16 v17, v35

    move-object/from16 v6, v36

    move-object/from16 v7, v37

    move/from16 v16, v38

    move-wide/from16 v197, v41

    goto/16 :goto_6790

    :catch_5731
    move-exception v0

    :goto_5732
    move-object/from16 v2, v59

    :goto_5734
    const/16 v30, 0x1

    :goto_5736
    move-object v1, v4

    move/from16 v27, v33

    move/from16 v33, v35

    move-object/from16 v16, v36

    move-wide/from16 v6, v41

    goto :goto_5711

    :catch_5740
    move-exception v0

    move/from16 v38, v1

    goto :goto_5719

    :catch_5744
    move-exception v0

    move/from16 v38, v1

    goto :goto_5732

    :catch_5748
    move-exception v0

    move/from16 v38, v1

    move-wide/from16 v41, v6

    move-object/from16 v2, v59

    move-wide/from16 v6, v156

    goto :goto_571b

    :catch_5752
    move-exception v0

    move/from16 v38, v1

    move-wide/from16 v41, v6

    move-object/from16 v2, v59

    const/16 v30, 0x1

    move-object v1, v4

    move/from16 v27, v33

    move/from16 v33, v35

    move-object/from16 v16, v36

    goto :goto_5711

    :catch_5763
    move-exception v0

    move/from16 v38, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    :goto_576c
    move-wide/from16 v6, v156

    move-wide/from16 v41, v158

    goto :goto_571b

    :catch_5771
    move-exception v0

    move/from16 v38, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    :goto_577a
    move-wide/from16 v41, v158

    goto :goto_5734

    :catch_577d
    move-exception v0

    move/from16 v35, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    move/from16 v38, v155

    goto :goto_576c

    :catch_5789
    move-exception v0

    move/from16 v35, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    move/from16 v38, v155

    goto :goto_577a

    :catch_5795
    move-exception v0

    move/from16 v33, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    move/from16 v38, v155

    move-wide/from16 v6, v156

    move-wide/from16 v41, v158

    move/from16 v35, v160

    goto/16 :goto_571b

    :catch_57a8
    move-exception v0

    move/from16 v33, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    move/from16 v38, v155

    move-wide/from16 v41, v158

    move/from16 v35, v160

    goto/16 :goto_5734

    :catch_57b9
    move-exception v0

    :goto_57ba
    move-object/from16 v36, v6

    move-object/from16 v37, v7

    :goto_57be
    move-object/from16 v2, v59

    move/from16 v38, v155

    move-wide/from16 v6, v156

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    goto/16 :goto_571b

    :catch_57cc
    move-exception v0

    :goto_57cd
    move-object/from16 v36, v6

    move-object/from16 v37, v7

    :goto_57d1
    move-object/from16 v2, v59

    move/from16 v38, v155

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    goto/16 :goto_5734

    :catch_57dd
    move-exception v0

    move-object/from16 v17, v1

    goto :goto_57ba

    :catch_57e1
    move-exception v0

    move-object/from16 v17, v1

    goto :goto_57cd

    :catch_57e5
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    goto :goto_57be

    :catch_57ef
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    goto :goto_57d1

    :catch_57f9
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v3, v27

    goto :goto_57be

    :catch_5805
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v3, v27

    goto :goto_57d1

    :catch_5811
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v3, v27

    move-object/from16 v2, v59

    move/from16 v38, v155

    move-wide/from16 v6, v156

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    const/16 v30, 0x1

    goto :goto_5842

    :catch_582b
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v3, v27

    move-object/from16 v2, v59

    move/from16 v38, v155

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    goto/16 :goto_5734

    :goto_5842
    move-object/from16 v59, v2

    goto/16 :goto_571d

    :cond_5846
    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v3, v27

    move-object/from16 v20, v154

    move/from16 v38, v155

    move-wide/from16 v6, v156

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    const/16 v30, 0x1

    move-object/from16 v27, p1

    move-object v1, v12

    move-object/from16 v2, v27

    move/from16 v168, v35

    move-object v12, v3

    move-object/from16 v3, v17

    goto/16 :goto_56d1

    :goto_586a
    :try_start_586a
    move-object/from16 v17, v2

    check-cast v17, Ljava/lang/Iterable;

    move-object/from16 p1, v2

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_5879
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v20
    :try_end_587d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_586a .. :try_end_587d} :catch_5a3f
    .catch Ljava/lang/Exception; {:try_start_586a .. :try_end_587d} :catch_5a3b
    .catchall {:try_start_586a .. :try_end_587d} :catchall_2e20

    if-eqz v20, :cond_58c8

    move-object/from16 v20, v13

    :try_start_5881
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13
    :try_end_5885
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5881 .. :try_end_5885} :catch_58c4
    .catch Ljava/lang/Exception; {:try_start_5881 .. :try_end_5885} :catch_58c0
    .catchall {:try_start_5881 .. :try_end_5885} :catchall_2e20

    move-object/from16 v27, v12

    :try_start_5887
    instance-of v12, v13, Lqmg;

    if-eqz v12, :cond_588e

    invoke-virtual {v2, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_588e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5887 .. :try_end_588e} :catch_58a7
    .catch Ljava/lang/Exception; {:try_start_5887 .. :try_end_588e} :catch_5893
    .catchall {:try_start_5887 .. :try_end_588e} :catchall_2e20

    :cond_588e
    move-object/from16 v13, v20

    move-object/from16 v12, v27

    goto :goto_5879

    :catch_5893
    move-exception v0

    :goto_5894
    move-object v12, v1

    move-object v13, v3

    move-object v1, v4

    move-object/from16 v4, v20

    move-object/from16 v3, v27

    move/from16 v16, v163

    move-wide/from16 v195, v164

    move-wide/from16 v197, v166

    move/from16 v17, v168

    move/from16 v20, v169

    goto/16 :goto_6790

    :catch_58a7
    move-exception v0

    :goto_58a8
    move-object v12, v1

    move-object/from16 v17, v3

    move-object v1, v4

    move-object/from16 v16, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v38, v27

    move-object/from16 v3, v59

    move/from16 v42, v163

    move-wide/from16 v6, v166

    move/from16 v33, v168

    move/from16 v27, v169

    goto/16 :goto_68af

    :catch_58c0
    move-exception v0

    move-object/from16 v27, v12

    goto :goto_5894

    :catch_58c4
    move-exception v0

    move-object/from16 v27, v12

    goto :goto_58a8

    :cond_58c8
    move-object/from16 v27, v12

    move-object/from16 v20, v13

    :try_start_58cc
    invoke-static {v2}, Lsm4;->D0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lqmg;

    if-eqz v2, :cond_5a97

    iput-object v4, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_58de
    .catch Ljava/util/concurrent/CancellationException; {:try_start_58cc .. :try_end_58de} :catch_5a63
    .catch Ljava/lang/Exception; {:try_start_58cc .. :try_end_58de} :catch_5a57
    .catchall {:try_start_58cc .. :try_end_58de} :catchall_2e20

    :try_start_58de
    move-object/from16 v12, v48

    check-cast v12, Ljava/util/List;

    iput-object v12, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v12, v47

    check-cast v12, Ljava/util/List;

    iput-object v12, v5, Laak;->J:Ljava/util/List;
    :try_end_58ea
    .catch Ljava/util/concurrent/CancellationException; {:try_start_58de .. :try_end_58ea} :catch_5a87
    .catch Ljava/lang/Exception; {:try_start_58de .. :try_end_58ea} :catch_5a6f
    .catchall {:try_start_58de .. :try_end_58ea} :catchall_2e20

    :try_start_58ea
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v1, v5, Laak;->M:Lexe;

    iput-object v3, v5, Laak;->N:Lexe;

    iput-object v6, v5, Laak;->O:Lexe;

    iput-object v7, v5, Laak;->P:Lixe;
    :try_end_58f6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_58ea .. :try_end_58f6} :catch_5a63
    .catch Ljava/lang/Exception; {:try_start_58ea .. :try_end_58f6} :catch_5a57
    .catchall {:try_start_58ea .. :try_end_58f6} :catchall_2e20

    move-object/from16 v12, v27

    :try_start_58f8
    iput-object v12, v5, Laak;->Q:Lixe;
    :try_end_58fa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_58f8 .. :try_end_58fa} :catch_5a4d
    .catch Ljava/lang/Exception; {:try_start_58f8 .. :try_end_58fa} :catch_5a43
    .catchall {:try_start_58f8 .. :try_end_58fa} :catchall_2e20

    move-object/from16 v13, v20

    :try_start_58fc
    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_58fe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_58fc .. :try_end_58fe} :catch_5a3f
    .catch Ljava/lang/Exception; {:try_start_58fc .. :try_end_58fe} :catch_5a3b
    .catchall {:try_start_58fc .. :try_end_58fe} :catchall_2e20

    move-object/from16 v17, v1

    const/4 v1, 0x0

    :try_start_5901
    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    move-object/from16 v1, v16

    iput-object v1, v5, Laak;->U:Lcp2;

    move-object/from16 v16, v1

    move-object/from16 v1, v162

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v20, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v1, p1

    iput-object v1, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 p1, v1

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_5925
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5901 .. :try_end_5925} :catch_5a2a
    .catch Ljava/lang/Exception; {:try_start_5901 .. :try_end_5925} :catch_5a17
    .catchall {:try_start_5901 .. :try_end_5925} :catchall_2e20

    move/from16 v1, v169

    :try_start_5927
    iput v1, v5, Laak;->e0:I
    :try_end_5929
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5927 .. :try_end_5929} :catch_5a06
    .catch Ljava/lang/Exception; {:try_start_5927 .. :try_end_5929} :catch_59f3
    .catchall {:try_start_5927 .. :try_end_5929} :catchall_2e20

    move/from16 v27, v1

    move/from16 v1, v168

    :try_start_592d
    iput-boolean v1, v5, Laak;->i0:Z
    :try_end_592f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_592d .. :try_end_592f} :catch_59e7
    .catch Ljava/lang/Exception; {:try_start_592d .. :try_end_592f} :catch_59db
    .catchall {:try_start_592d .. :try_end_592f} :catchall_2e20

    move/from16 v33, v1

    move/from16 v1, v163

    :try_start_5933
    iput v1, v5, Laak;->f0:I
    :try_end_5935
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5933 .. :try_end_5935} :catch_59cf
    .catch Ljava/lang/Exception; {:try_start_5933 .. :try_end_5935} :catch_59c1
    .catchall {:try_start_5933 .. :try_end_5935} :catchall_2e20

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-wide/from16 v6, v166

    :try_start_593b
    iput-wide v6, v5, Laak;->k0:J

    iput v0, v5, Laak;->g0:I
    :try_end_593f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_593b .. :try_end_593f} :catch_59b6
    .catch Ljava/lang/Exception; {:try_start_593b .. :try_end_593f} :catch_59ac
    .catchall {:try_start_593b .. :try_end_593f} :catchall_2e20

    move-wide/from16 v37, v6

    move-wide/from16 v6, v164

    :try_start_5943
    iput-wide v6, v5, Laak;->l0:J
    :try_end_5945
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5943 .. :try_end_5945} :catch_59a8
    .catch Ljava/lang/Exception; {:try_start_5943 .. :try_end_5945} :catch_59a4
    .catchall {:try_start_5943 .. :try_end_5945} :catchall_2e20

    move/from16 v41, v1

    const/16 v1, 0x20

    :try_start_5949
    iput v1, v5, Laak;->m0:I

    invoke-virtual {v4, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_594f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5949 .. :try_end_594f} :catch_5990
    .catch Ljava/lang/Exception; {:try_start_5949 .. :try_end_594f} :catch_5977
    .catchall {:try_start_5949 .. :try_end_594f} :catchall_2e20

    move-object/from16 v2, v59

    if-ne v1, v2, :cond_5955

    goto/16 :goto_7700

    :cond_5955
    move-object/from16 v45, v10

    move-object/from16 v46, v15

    move-object/from16 v1, v17

    move-object/from16 v42, v35

    move-object/from16 v10, p1

    move-object/from16 v35, v4

    :goto_5961
    move-wide/from16 v164, v6

    move-object/from16 v4, v35

    move-object/from16 v6, v42

    move-object/from16 v15, v46

    move-object/from16 v162, v20

    move/from16 v169, v27

    move/from16 v168, v33

    move-object/from16 v7, v36

    move-wide/from16 v166, v37

    move/from16 v163, v41

    goto/16 :goto_5ab7

    :catch_5977
    move-exception v0

    :goto_5978
    move-object/from16 v2, v59

    :goto_597a
    move-object v1, v4

    move-wide/from16 v195, v6

    move-object v4, v13

    move/from16 v20, v27

    move-object/from16 v6, v35

    move-object/from16 v7, v36

    move-wide/from16 v197, v37

    move/from16 v16, v41

    move-object v13, v3

    move-object v3, v12

    move-object/from16 v12, v17

    move/from16 v17, v33

    goto/16 :goto_6790

    :catch_5990
    move-exception v0

    :goto_5991
    move-object/from16 v2, v59

    :goto_5993
    move-object v1, v4

    move-object/from16 v16, v35

    move-wide/from16 v6, v37

    :goto_5998
    move/from16 v42, v41

    move-object/from16 v38, v12

    move-object/from16 v12, v17

    move-object/from16 v37, v36

    move-object/from16 v17, v3

    goto/16 :goto_5715

    :catch_59a4
    move-exception v0

    move/from16 v41, v1

    goto :goto_5978

    :catch_59a8
    move-exception v0

    move/from16 v41, v1

    goto :goto_5991

    :catch_59ac
    move-exception v0

    move/from16 v41, v1

    move-wide/from16 v37, v6

    move-object/from16 v2, v59

    move-wide/from16 v6, v164

    goto :goto_597a

    :catch_59b6
    move-exception v0

    move/from16 v41, v1

    move-wide/from16 v37, v6

    move-object/from16 v2, v59

    move-object v1, v4

    move-object/from16 v16, v35

    goto :goto_5998

    :catch_59c1
    move-exception v0

    move/from16 v41, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v2, v59

    :goto_59ca
    move-wide/from16 v6, v164

    move-wide/from16 v37, v166

    goto :goto_597a

    :catch_59cf
    move-exception v0

    move/from16 v41, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v2, v59

    :goto_59d8
    move-wide/from16 v37, v166

    goto :goto_5993

    :catch_59db
    move-exception v0

    move/from16 v33, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v2, v59

    move/from16 v41, v163

    goto :goto_59ca

    :catch_59e7
    move-exception v0

    move/from16 v33, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v2, v59

    move/from16 v41, v163

    goto :goto_59d8

    :catch_59f3
    move-exception v0

    move/from16 v27, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v2, v59

    move/from16 v41, v163

    move-wide/from16 v6, v164

    move-wide/from16 v37, v166

    move/from16 v33, v168

    goto/16 :goto_597a

    :catch_5a06
    move-exception v0

    move/from16 v27, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v2, v59

    move/from16 v41, v163

    move-wide/from16 v37, v166

    move/from16 v33, v168

    goto/16 :goto_5993

    :catch_5a17
    move-exception v0

    :goto_5a18
    move-object/from16 v35, v6

    move-object/from16 v36, v7

    :goto_5a1c
    move-object/from16 v2, v59

    move/from16 v41, v163

    move-wide/from16 v6, v164

    move-wide/from16 v37, v166

    move/from16 v33, v168

    move/from16 v27, v169

    goto/16 :goto_597a

    :catch_5a2a
    move-exception v0

    :goto_5a2b
    move-object/from16 v35, v6

    move-object/from16 v36, v7

    :goto_5a2f
    move-object/from16 v2, v59

    move/from16 v41, v163

    move-wide/from16 v37, v166

    move/from16 v33, v168

    move/from16 v27, v169

    goto/16 :goto_5993

    :catch_5a3b
    move-exception v0

    move-object/from16 v17, v1

    goto :goto_5a18

    :catch_5a3f
    move-exception v0

    move-object/from16 v17, v1

    goto :goto_5a2b

    :catch_5a43
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    goto :goto_5a1c

    :catch_5a4d
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    goto :goto_5a2f

    :catch_5a57
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v12, v27

    goto :goto_5a1c

    :catch_5a63
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v12, v27

    goto :goto_5a2f

    :catch_5a6f
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v12, v27

    move-object/from16 v2, v59

    move/from16 v41, v163

    move-wide/from16 v6, v164

    move-wide/from16 v37, v166

    move/from16 v33, v168

    move/from16 v27, v169

    goto :goto_5a93

    :catch_5a87
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v12, v27

    goto :goto_5a2f

    :goto_5a93
    move-object/from16 v59, v2

    goto/16 :goto_597a

    :cond_5a97
    move-object/from16 v17, v1

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v12, v27

    move-object/from16 v2, v59

    move-object/from16 v20, v162

    move/from16 v41, v163

    move-wide/from16 v6, v164

    move-wide/from16 v37, v166

    move/from16 v33, v168

    move/from16 v27, v169

    move-object/from16 v45, v10

    move-object/from16 v6, v35

    move-object/from16 v10, p1

    move-object/from16 v7, v36

    :goto_5ab7
    move-object/from16 v59, v12

    move-object v12, v1

    move-object v1, v4

    move-object/from16 v4, v59

    move-object/from16 v59, v2

    move-object v2, v10

    move-object/from16 v10, v45

    move-object/from16 v170, v162

    move/from16 v171, v163

    move-wide/from16 v172, v164

    move-wide/from16 v174, v166

    move/from16 v176, v168

    move/from16 v177, v169

    goto/16 :goto_5b2e

    :catch_5ad0
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object v3, v13

    move/from16 v38, v155

    move-wide/from16 v6, v156

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    const/16 v30, 0x1

    move-object v13, v2

    move-object/from16 v2, v59

    goto/16 :goto_571d

    :catch_5ae9
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object v3, v13

    move/from16 v38, v155

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    const/16 v30, 0x1

    move-object v13, v2

    move-object/from16 v2, v59

    goto/16 :goto_5736

    :cond_5b00
    move-object/from16 v27, p1

    move-object/from16 v17, v1

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object v3, v13

    move-object/from16 v20, v154

    move/from16 v38, v155

    move-wide/from16 v6, v156

    move-wide/from16 v41, v158

    move/from16 v35, v160

    move/from16 v33, v161

    const/16 v30, 0x1

    move-object v13, v2

    move-object v1, v4

    move-wide/from16 v172, v6

    move-object/from16 v170, v20

    move-object/from16 v2, v27

    move/from16 v177, v33

    move/from16 v176, v35

    move-object/from16 v6, v36

    move-object/from16 v7, v37

    move/from16 v171, v38

    move-wide/from16 v174, v41

    move-object v4, v3

    move-object/from16 v3, v17

    :goto_5b2e
    :try_start_5b2e
    move-object/from16 v17, v2

    check-cast v17, Ljava/lang/Iterable;

    move-object/from16 p1, v2

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_5b3d
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v20
    :try_end_5b41
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5b2e .. :try_end_5b41} :catch_5cd5
    .catch Ljava/lang/Exception; {:try_start_5b2e .. :try_end_5b41} :catch_5cd1
    .catchall {:try_start_5b2e .. :try_end_5b41} :catchall_2e20

    if-eqz v20, :cond_5b88

    move-object/from16 v20, v13

    :try_start_5b45
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13
    :try_end_5b49
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5b45 .. :try_end_5b49} :catch_5b84
    .catch Ljava/lang/Exception; {:try_start_5b45 .. :try_end_5b49} :catch_5b80
    .catchall {:try_start_5b45 .. :try_end_5b49} :catchall_2e20

    move-object/from16 v27, v4

    :try_start_5b4b
    instance-of v4, v13, Lrmg;

    if-eqz v4, :cond_5b52

    invoke-virtual {v2, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_5b52
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5b4b .. :try_end_5b52} :catch_5b69
    .catch Ljava/lang/Exception; {:try_start_5b4b .. :try_end_5b52} :catch_5b57
    .catchall {:try_start_5b4b .. :try_end_5b52} :catchall_2e20

    :cond_5b52
    move-object/from16 v13, v20

    move-object/from16 v4, v27

    goto :goto_5b3d

    :catch_5b57
    move-exception v0

    :goto_5b58
    move-object v13, v3

    move-object/from16 v4, v20

    move-object/from16 v3, v27

    move/from16 v16, v171

    move-wide/from16 v195, v172

    move-wide/from16 v197, v174

    move/from16 v17, v176

    move/from16 v20, v177

    goto/16 :goto_6790

    :catch_5b69
    move-exception v0

    :goto_5b6a
    move-object/from16 v17, v3

    move-object/from16 v16, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v38, v27

    move-object/from16 v3, v59

    move/from16 v42, v171

    move-wide/from16 v6, v174

    move/from16 v33, v176

    move/from16 v27, v177

    goto/16 :goto_68af

    :catch_5b80
    move-exception v0

    move-object/from16 v27, v4

    goto :goto_5b58

    :catch_5b84
    move-exception v0

    move-object/from16 v27, v4

    goto :goto_5b6a

    :cond_5b88
    move-object/from16 v27, v4

    move-object/from16 v20, v13

    :try_start_5b8c
    invoke-static {v2}, Lsm4;->D0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lrmg;

    if-eqz v2, :cond_5d19

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_5b9e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5b8c .. :try_end_5b9e} :catch_5cf1
    .catch Ljava/lang/Exception; {:try_start_5b8c .. :try_end_5b9e} :catch_5ce9
    .catchall {:try_start_5b8c .. :try_end_5b9e} :catchall_2e20

    :try_start_5b9e
    move-object/from16 v4, v48

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v4, v47

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->J:Ljava/util/List;
    :try_end_5baa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5b9e .. :try_end_5baa} :catch_5d0d
    .catch Ljava/lang/Exception; {:try_start_5b9e .. :try_end_5baa} :catch_5cf9
    .catchall {:try_start_5b9e .. :try_end_5baa} :catchall_2e20

    :try_start_5baa
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v3, v5, Laak;->N:Lexe;

    iput-object v6, v5, Laak;->O:Lexe;

    iput-object v7, v5, Laak;->P:Lixe;
    :try_end_5bb6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5baa .. :try_end_5bb6} :catch_5cf1
    .catch Ljava/lang/Exception; {:try_start_5baa .. :try_end_5bb6} :catch_5ce9
    .catchall {:try_start_5baa .. :try_end_5bb6} :catchall_2e20

    move-object/from16 v4, v27

    :try_start_5bb8
    iput-object v4, v5, Laak;->Q:Lixe;
    :try_end_5bba
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5bb8 .. :try_end_5bba} :catch_5ce1
    .catch Ljava/lang/Exception; {:try_start_5bb8 .. :try_end_5bba} :catch_5cd9
    .catchall {:try_start_5bb8 .. :try_end_5bba} :catchall_2e20

    move-object/from16 v13, v20

    :try_start_5bbc
    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_5bbe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5bbc .. :try_end_5bbe} :catch_5cd5
    .catch Ljava/lang/Exception; {:try_start_5bbc .. :try_end_5bbe} :catch_5cd1
    .catchall {:try_start_5bbc .. :try_end_5bbe} :catchall_2e20

    move-object/from16 v17, v3

    const/4 v3, 0x0

    :try_start_5bc1
    iput-object v3, v5, Laak;->S:Lpe9;

    iput-object v3, v5, Laak;->T:Lexe;

    move-object/from16 v3, v16

    iput-object v3, v5, Laak;->U:Lcp2;

    move-object/from16 v16, v3

    move-object/from16 v3, v170

    iput-object v3, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v20, v3

    const/4 v3, 0x0

    iput-object v3, v5, Laak;->W:Long;

    iput-object v3, v5, Laak;->X:Ljava/lang/Object;

    iput-object v3, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v3, p1

    iput-object v3, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 p1, v3

    const/4 v3, 0x0

    iput-object v3, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_5be5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5bc1 .. :try_end_5be5} :catch_5cc2
    .catch Ljava/lang/Exception; {:try_start_5bc1 .. :try_end_5be5} :catch_5cb1
    .catchall {:try_start_5bc1 .. :try_end_5be5} :catchall_2e20

    move/from16 v3, v177

    :try_start_5be7
    iput v3, v5, Laak;->e0:I
    :try_end_5be9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5be7 .. :try_end_5be9} :catch_5ca3
    .catch Ljava/lang/Exception; {:try_start_5be7 .. :try_end_5be9} :catch_5c93
    .catchall {:try_start_5be7 .. :try_end_5be9} :catchall_2e20

    move/from16 v27, v3

    move/from16 v3, v176

    :try_start_5bed
    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_5bef
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5bed .. :try_end_5bef} :catch_5c89
    .catch Ljava/lang/Exception; {:try_start_5bed .. :try_end_5bef} :catch_5c7f
    .catchall {:try_start_5bed .. :try_end_5bef} :catchall_2e20

    move/from16 v33, v3

    move/from16 v3, v171

    :try_start_5bf3
    iput v3, v5, Laak;->f0:I
    :try_end_5bf5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5bf3 .. :try_end_5bf5} :catch_5c75
    .catch Ljava/lang/Exception; {:try_start_5bf3 .. :try_end_5bf5} :catch_5c69
    .catchall {:try_start_5bf3 .. :try_end_5bf5} :catchall_2e20

    move/from16 v36, v3

    move-object/from16 v35, v4

    move-wide/from16 v3, v174

    :try_start_5bfb
    iput-wide v3, v5, Laak;->k0:J

    iput v0, v5, Laak;->g0:I
    :try_end_5bff
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5bfb .. :try_end_5bff} :catch_5c65
    .catch Ljava/lang/Exception; {:try_start_5bfb .. :try_end_5bff} :catch_5c5d
    .catchall {:try_start_5bfb .. :try_end_5bff} :catchall_2e20

    move-wide/from16 v37, v3

    move-wide/from16 v3, v172

    :try_start_5c03
    iput-wide v3, v5, Laak;->l0:J
    :try_end_5c05
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5c03 .. :try_end_5c05} :catch_5c48
    .catch Ljava/lang/Exception; {:try_start_5c03 .. :try_end_5c05} :catch_5c59
    .catchall {:try_start_5c03 .. :try_end_5c05} :catchall_2e20

    move-wide/from16 v41, v3

    const/16 v3, 0x21

    :try_start_5c09
    iput v3, v5, Laak;->m0:I

    invoke-virtual {v1, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_5c0f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5c09 .. :try_end_5c0f} :catch_5c48
    .catch Ljava/lang/Exception; {:try_start_5c09 .. :try_end_5c0f} :catch_5c34
    .catchall {:try_start_5c09 .. :try_end_5c0f} :catchall_2e20

    move-object/from16 v3, v59

    if-ne v2, v3, :cond_5c15

    goto/16 :goto_2cea

    :cond_5c15
    move-object/from16 v45, v10

    move-object/from16 v46, v15

    move-object/from16 v10, p1

    :goto_5c1b
    move-object/from16 v53, v3

    move-object v3, v10

    move-object/from16 v10, v45

    move-object/from16 v15, v46

    :goto_5c22
    move-object/from16 v2, v17

    move-object/from16 v178, v20

    move/from16 v185, v27

    move/from16 v184, v33

    move-object/from16 v4, v35

    move/from16 v179, v36

    move-wide/from16 v182, v37

    move-wide/from16 v180, v41

    goto/16 :goto_5d31

    :catch_5c34
    move-exception v0

    :goto_5c35
    move-object/from16 v3, v59

    :goto_5c37
    move-object v4, v13

    move-object/from16 v13, v17

    move/from16 v20, v27

    move/from16 v17, v33

    move-object/from16 v3, v35

    move/from16 v16, v36

    move-wide/from16 v197, v37

    move-wide/from16 v195, v41

    goto/16 :goto_6790

    :catch_5c48
    move-exception v0

    :goto_5c49
    move-object/from16 v3, v59

    :goto_5c4b
    move-object/from16 v16, v6

    move/from16 v42, v36

    move-wide/from16 v208, v37

    move-object/from16 v37, v7

    move-object/from16 v38, v35

    move-wide/from16 v6, v208

    goto/16 :goto_68af

    :catch_5c59
    move-exception v0

    move-wide/from16 v41, v3

    goto :goto_5c35

    :catch_5c5d
    move-exception v0

    move-wide/from16 v37, v3

    move-object/from16 v3, v59

    move-wide/from16 v41, v172

    goto :goto_5c37

    :catch_5c65
    move-exception v0

    move-wide/from16 v37, v3

    goto :goto_5c49

    :catch_5c69
    move-exception v0

    move/from16 v36, v3

    move-object/from16 v35, v4

    move-object/from16 v3, v59

    :goto_5c70
    move-wide/from16 v41, v172

    move-wide/from16 v37, v174

    goto :goto_5c37

    :catch_5c75
    move-exception v0

    move/from16 v36, v3

    move-object/from16 v35, v4

    move-object/from16 v3, v59

    :goto_5c7c
    move-wide/from16 v37, v174

    goto :goto_5c4b

    :catch_5c7f
    move-exception v0

    move/from16 v33, v3

    move-object/from16 v35, v4

    move-object/from16 v3, v59

    move/from16 v36, v171

    goto :goto_5c70

    :catch_5c89
    move-exception v0

    move/from16 v33, v3

    move-object/from16 v35, v4

    move-object/from16 v3, v59

    move/from16 v36, v171

    goto :goto_5c7c

    :catch_5c93
    move-exception v0

    move/from16 v27, v3

    move-object/from16 v35, v4

    move-object/from16 v3, v59

    move/from16 v36, v171

    move-wide/from16 v41, v172

    move-wide/from16 v37, v174

    move/from16 v33, v176

    goto :goto_5c37

    :catch_5ca3
    move-exception v0

    move/from16 v27, v3

    move-object/from16 v35, v4

    move-object/from16 v3, v59

    move/from16 v36, v171

    move-wide/from16 v37, v174

    move/from16 v33, v176

    goto :goto_5c4b

    :catch_5cb1
    move-exception v0

    :goto_5cb2
    move-object/from16 v35, v4

    :goto_5cb4
    move-object/from16 v3, v59

    move/from16 v36, v171

    move-wide/from16 v41, v172

    move-wide/from16 v37, v174

    move/from16 v33, v176

    move/from16 v27, v177

    goto/16 :goto_5c37

    :catch_5cc2
    move-exception v0

    :goto_5cc3
    move-object/from16 v35, v4

    :goto_5cc5
    move-object/from16 v3, v59

    move/from16 v36, v171

    move-wide/from16 v37, v174

    move/from16 v33, v176

    move/from16 v27, v177

    goto/16 :goto_5c4b

    :catch_5cd1
    move-exception v0

    move-object/from16 v17, v3

    goto :goto_5cb2

    :catch_5cd5
    move-exception v0

    move-object/from16 v17, v3

    goto :goto_5cc3

    :catch_5cd9
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v35, v4

    move-object/from16 v13, v20

    goto :goto_5cb4

    :catch_5ce1
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v35, v4

    move-object/from16 v13, v20

    goto :goto_5cc5

    :catch_5ce9
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v13, v20

    move-object/from16 v35, v27

    goto :goto_5cb4

    :catch_5cf1
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v13, v20

    move-object/from16 v35, v27

    goto :goto_5cc5

    :catch_5cf9
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v13, v20

    move-object/from16 v35, v27

    move-object/from16 v3, v59

    move/from16 v36, v171

    move-wide/from16 v41, v172

    move-wide/from16 v37, v174

    move/from16 v33, v176

    move/from16 v27, v177

    goto :goto_5d15

    :catch_5d0d
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v13, v20

    move-object/from16 v35, v27

    goto :goto_5cc5

    :goto_5d15
    move-object/from16 v59, v3

    goto/16 :goto_5c37

    :cond_5d19
    move-object/from16 v17, v3

    move-object/from16 v13, v20

    move-object/from16 v35, v27

    move-object/from16 v20, v170

    move/from16 v36, v171

    move-wide/from16 v41, v172

    move-wide/from16 v37, v174

    move/from16 v33, v176

    move/from16 v27, v177

    move-object/from16 v3, p1

    move-object/from16 v53, v59

    goto/16 :goto_5c22

    :goto_5d31
    :try_start_5d31
    move-object/from16 v17, v3

    check-cast v17, Ljava/lang/Iterable;

    move-object/from16 p1, v3

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_5d40
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v20
    :try_end_5d44
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5d31 .. :try_end_5d44} :catch_5f0d
    .catch Ljava/lang/Exception; {:try_start_5d31 .. :try_end_5d44} :catch_5f09
    .catchall {:try_start_5d31 .. :try_end_5d44} :catchall_2e20

    if-eqz v20, :cond_5d8d

    move-object/from16 v20, v13

    :try_start_5d48
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13
    :try_end_5d4c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5d48 .. :try_end_5d4c} :catch_5d89
    .catch Ljava/lang/Exception; {:try_start_5d48 .. :try_end_5d4c} :catch_5d85
    .catchall {:try_start_5d48 .. :try_end_5d4c} :catchall_2e20

    move-object/from16 v27, v4

    :try_start_5d4e
    instance-of v4, v13, Ldng;

    if-eqz v4, :cond_5d55

    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_5d55
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5d4e .. :try_end_5d55} :catch_5d6e
    .catch Ljava/lang/Exception; {:try_start_5d4e .. :try_end_5d55} :catch_5d5a
    .catchall {:try_start_5d4e .. :try_end_5d55} :catchall_2e20

    :cond_5d55
    move-object/from16 v13, v20

    move-object/from16 v4, v27

    goto :goto_5d40

    :catch_5d5a
    move-exception v0

    :goto_5d5b
    move-object v13, v2

    move-object/from16 v4, v20

    move-object/from16 v3, v27

    move-object/from16 v59, v53

    move/from16 v16, v179

    move-wide/from16 v195, v180

    move-wide/from16 v197, v182

    move/from16 v17, v184

    move/from16 v20, v185

    goto/16 :goto_6790

    :catch_5d6e
    move-exception v0

    :goto_5d6f
    move-object/from16 v17, v2

    move-object/from16 v16, v6

    move-object/from16 v37, v7

    move-object/from16 v13, v20

    move-object/from16 v38, v27

    move-object/from16 v3, v53

    move/from16 v42, v179

    move-wide/from16 v6, v182

    move/from16 v33, v184

    move/from16 v27, v185

    goto/16 :goto_68af

    :catch_5d85
    move-exception v0

    move-object/from16 v27, v4

    goto :goto_5d5b

    :catch_5d89
    move-exception v0

    move-object/from16 v27, v4

    goto :goto_5d6f

    :cond_5d8d
    move-object/from16 v27, v4

    move-object/from16 v20, v13

    :try_start_5d91
    invoke-static {v3}, Lsm4;->D0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldng;

    if-eqz v3, :cond_5f55

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_5da3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5d91 .. :try_end_5da3} :catch_5f31
    .catch Ljava/lang/Exception; {:try_start_5d91 .. :try_end_5da3} :catch_5f25
    .catchall {:try_start_5d91 .. :try_end_5da3} :catchall_2e20

    :try_start_5da3
    move-object/from16 v4, v48

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v4, v47

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->J:Ljava/util/List;
    :try_end_5daf
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5da3 .. :try_end_5daf} :catch_5f49
    .catch Ljava/lang/Exception; {:try_start_5da3 .. :try_end_5daf} :catch_5f3d
    .catchall {:try_start_5da3 .. :try_end_5daf} :catchall_2e20

    :try_start_5daf
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v2, v5, Laak;->N:Lexe;

    iput-object v6, v5, Laak;->O:Lexe;

    iput-object v7, v5, Laak;->P:Lixe;
    :try_end_5dbb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5daf .. :try_end_5dbb} :catch_5f31
    .catch Ljava/lang/Exception; {:try_start_5daf .. :try_end_5dbb} :catch_5f25
    .catchall {:try_start_5daf .. :try_end_5dbb} :catchall_2e20

    move-object/from16 v4, v27

    :try_start_5dbd
    iput-object v4, v5, Laak;->Q:Lixe;
    :try_end_5dbf
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5dbd .. :try_end_5dbf} :catch_5f1b
    .catch Ljava/lang/Exception; {:try_start_5dbd .. :try_end_5dbf} :catch_5f11
    .catchall {:try_start_5dbd .. :try_end_5dbf} :catchall_2e20

    move-object/from16 v13, v20

    :try_start_5dc1
    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_5dc3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5dc1 .. :try_end_5dc3} :catch_5f0d
    .catch Ljava/lang/Exception; {:try_start_5dc1 .. :try_end_5dc3} :catch_5f09
    .catchall {:try_start_5dc1 .. :try_end_5dc3} :catchall_2e20

    move-object/from16 v17, v2

    const/4 v2, 0x0

    :try_start_5dc6
    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v2, v5, Laak;->T:Lexe;

    move-object/from16 v2, v16

    iput-object v2, v5, Laak;->U:Lcp2;

    move-object/from16 v16, v2

    move-object/from16 v2, v178

    iput-object v2, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v20, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v2, p1

    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 p1, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_5dea
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5dc6 .. :try_end_5dea} :catch_5ef8
    .catch Ljava/lang/Exception; {:try_start_5dc6 .. :try_end_5dea} :catch_5ee5
    .catchall {:try_start_5dc6 .. :try_end_5dea} :catchall_2e20

    move/from16 v2, v185

    :try_start_5dec
    iput v2, v5, Laak;->e0:I
    :try_end_5dee
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5dec .. :try_end_5dee} :catch_5ed5
    .catch Ljava/lang/Exception; {:try_start_5dec .. :try_end_5dee} :catch_5ec2
    .catchall {:try_start_5dec .. :try_end_5dee} :catchall_2e20

    move/from16 v27, v2

    move/from16 v2, v184

    :try_start_5df2
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_5df4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5df2 .. :try_end_5df4} :catch_5eb6
    .catch Ljava/lang/Exception; {:try_start_5df2 .. :try_end_5df4} :catch_5eaa
    .catchall {:try_start_5df2 .. :try_end_5df4} :catchall_2e20

    move/from16 v33, v2

    move/from16 v2, v179

    :try_start_5df8
    iput v2, v5, Laak;->f0:I
    :try_end_5dfa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5df8 .. :try_end_5dfa} :catch_5e9e
    .catch Ljava/lang/Exception; {:try_start_5df8 .. :try_end_5dfa} :catch_5e90
    .catchall {:try_start_5df8 .. :try_end_5dfa} :catchall_2e20

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-wide/from16 v6, v182

    :try_start_5e00
    iput-wide v6, v5, Laak;->k0:J

    iput v0, v5, Laak;->g0:I
    :try_end_5e04
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5e00 .. :try_end_5e04} :catch_5e86
    .catch Ljava/lang/Exception; {:try_start_5e00 .. :try_end_5e04} :catch_5e7c
    .catchall {:try_start_5e00 .. :try_end_5e04} :catchall_2e20

    move-wide/from16 v37, v6

    move-wide/from16 v6, v180

    :try_start_5e08
    iput-wide v6, v5, Laak;->l0:J
    :try_end_5e0a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5e08 .. :try_end_5e0a} :catch_5e78
    .catch Ljava/lang/Exception; {:try_start_5e08 .. :try_end_5e0a} :catch_5e74
    .catchall {:try_start_5e08 .. :try_end_5e0a} :catchall_2e20

    move/from16 v41, v2

    const/16 v2, 0x22

    :try_start_5e0e
    iput v2, v5, Laak;->m0:I

    invoke-virtual {v1, v5, v3}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_5e14
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5e0e .. :try_end_5e14} :catch_5e65
    .catch Ljava/lang/Exception; {:try_start_5e0e .. :try_end_5e14} :catch_5e4c
    .catchall {:try_start_5e0e .. :try_end_5e14} :catchall_2e20

    move-object/from16 v3, v53

    if-ne v2, v3, :cond_5e1a

    goto/16 :goto_2cea

    :cond_5e1a
    move-object/from16 v45, v10

    move-object/from16 v46, v15

    move-object/from16 v42, v35

    move-object/from16 v10, p1

    move-object/from16 v35, v1

    move-object v1, v12

    :goto_5e25
    move/from16 v2, v33

    move/from16 v33, v27

    move/from16 v27, v2

    move-object v12, v1

    move-object/from16 v53, v3

    move-wide/from16 v186, v6

    move-object v3, v13

    move-object/from16 v2, v35

    move-object/from16 v6, v42

    move-object/from16 v15, v46

    move-object v13, v4

    move-object/from16 v4, v17

    move-object/from16 v17, v10

    move-object/from16 v10, v45

    :goto_5e3e
    move-object/from16 v1, v16

    move-object/from16 v7, v36

    move-wide/from16 v188, v37

    move/from16 v16, v0

    move-object/from16 v0, v20

    move/from16 v20, v41

    goto/16 :goto_5f7e

    :catch_5e4c
    move-exception v0

    :goto_5e4d
    move-object/from16 v3, v53

    :goto_5e4f
    move-object/from16 v59, v3

    move-object v3, v4

    move-wide/from16 v195, v6

    move-object v4, v13

    move-object/from16 v13, v17

    move/from16 v20, v27

    move/from16 v17, v33

    move-object/from16 v6, v35

    move-object/from16 v7, v36

    move-wide/from16 v197, v37

    move/from16 v16, v41

    goto/16 :goto_6790

    :catch_5e65
    move-exception v0

    :goto_5e66
    move-object/from16 v3, v53

    :goto_5e68
    move-object/from16 v16, v35

    move-wide/from16 v6, v37

    :goto_5e6c
    move/from16 v42, v41

    move-object/from16 v38, v4

    move-object/from16 v37, v36

    goto/16 :goto_68af

    :catch_5e74
    move-exception v0

    move/from16 v41, v2

    goto :goto_5e4d

    :catch_5e78
    move-exception v0

    move/from16 v41, v2

    goto :goto_5e66

    :catch_5e7c
    move-exception v0

    move/from16 v41, v2

    move-wide/from16 v37, v6

    move-object/from16 v3, v53

    move-wide/from16 v6, v180

    goto :goto_5e4f

    :catch_5e86
    move-exception v0

    move/from16 v41, v2

    move-wide/from16 v37, v6

    move-object/from16 v3, v53

    move-object/from16 v16, v35

    goto :goto_5e6c

    :catch_5e90
    move-exception v0

    move/from16 v41, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v3, v53

    :goto_5e99
    move-wide/from16 v6, v180

    move-wide/from16 v37, v182

    goto :goto_5e4f

    :catch_5e9e
    move-exception v0

    move/from16 v41, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v3, v53

    :goto_5ea7
    move-wide/from16 v37, v182

    goto :goto_5e68

    :catch_5eaa
    move-exception v0

    move/from16 v33, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v3, v53

    move/from16 v41, v179

    goto :goto_5e99

    :catch_5eb6
    move-exception v0

    move/from16 v33, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v3, v53

    move/from16 v41, v179

    goto :goto_5ea7

    :catch_5ec2
    move-exception v0

    move/from16 v27, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v3, v53

    move/from16 v41, v179

    move-wide/from16 v6, v180

    move-wide/from16 v37, v182

    move/from16 v33, v184

    goto/16 :goto_5e4f

    :catch_5ed5
    move-exception v0

    move/from16 v27, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v3, v53

    move/from16 v41, v179

    move-wide/from16 v37, v182

    move/from16 v33, v184

    goto :goto_5e68

    :catch_5ee5
    move-exception v0

    :goto_5ee6
    move-object/from16 v35, v6

    move-object/from16 v36, v7

    :goto_5eea
    move-object/from16 v3, v53

    move/from16 v41, v179

    move-wide/from16 v6, v180

    move-wide/from16 v37, v182

    move/from16 v33, v184

    move/from16 v27, v185

    goto/16 :goto_5e4f

    :catch_5ef8
    move-exception v0

    :goto_5ef9
    move-object/from16 v35, v6

    move-object/from16 v36, v7

    :goto_5efd
    move-object/from16 v3, v53

    move/from16 v41, v179

    move-wide/from16 v37, v182

    move/from16 v33, v184

    move/from16 v27, v185

    goto/16 :goto_5e68

    :catch_5f09
    move-exception v0

    move-object/from16 v17, v2

    goto :goto_5ee6

    :catch_5f0d
    move-exception v0

    move-object/from16 v17, v2

    goto :goto_5ef9

    :catch_5f11
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    goto :goto_5eea

    :catch_5f1b
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    goto :goto_5efd

    :catch_5f25
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v4, v27

    goto :goto_5eea

    :catch_5f31
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v4, v27

    goto :goto_5efd

    :catch_5f3d
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v4, v27

    goto :goto_5eea

    :catch_5f49
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v4, v27

    goto :goto_5efd

    :cond_5f55
    move-object/from16 v17, v2

    move-object/from16 v35, v6

    move-object/from16 v36, v7

    move-object/from16 v13, v20

    move-object/from16 v4, v27

    move-object/from16 v20, v178

    move/from16 v41, v179

    move-wide/from16 v6, v180

    move-wide/from16 v37, v182

    move/from16 v33, v184

    move/from16 v27, v185

    move/from16 v2, v33

    move/from16 v33, v27

    move/from16 v27, v2

    move-object v2, v1

    move-wide/from16 v186, v6

    move-object v3, v13

    move-object/from16 v6, v35

    move-object v13, v4

    move-object/from16 v4, v17

    move-object/from16 v17, p1

    goto/16 :goto_5e3e

    :goto_5f7e
    :try_start_5f7e
    check-cast v17, Ljava/lang/Iterable;

    move-object/from16 v35, v1

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_5f8b
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v36
    :try_end_5f8f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5f7e .. :try_end_5f8f} :catch_6187
    .catch Ljava/lang/Exception; {:try_start_5f7e .. :try_end_5f8f} :catch_6177
    .catchall {:try_start_5f7e .. :try_end_5f8f} :catchall_2e20

    if-eqz v36, :cond_5fdc

    move-object/from16 v36, v3

    :try_start_5f93
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3
    :try_end_5f97
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5f93 .. :try_end_5f97} :catch_5fd8
    .catch Ljava/lang/Exception; {:try_start_5f93 .. :try_end_5f97} :catch_5fd4
    .catchall {:try_start_5f93 .. :try_end_5f97} :catchall_2e20

    move-object/from16 v37, v13

    :try_start_5f99
    instance-of v13, v3, Lomg;

    if-eqz v13, :cond_5fa0

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_5fa0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5f99 .. :try_end_5fa0} :catch_5fba
    .catch Ljava/lang/Exception; {:try_start_5f99 .. :try_end_5fa0} :catch_5fa5
    .catchall {:try_start_5f99 .. :try_end_5fa0} :catchall_2e20

    :cond_5fa0
    move-object/from16 v3, v36

    move-object/from16 v13, v37

    goto :goto_5f8b

    :catch_5fa5
    move-exception v0

    :goto_5fa6
    move-object v1, v2

    move-object v13, v4

    move/from16 v16, v20

    move/from16 v17, v27

    move/from16 v20, v33

    move-object/from16 v4, v36

    move-object/from16 v3, v37

    move-object/from16 v59, v53

    move-wide/from16 v195, v186

    move-wide/from16 v197, v188

    goto/16 :goto_6790

    :catch_5fba
    move-exception v0

    :goto_5fbb
    move/from16 v1, v33

    move/from16 v33, v27

    move/from16 v27, v1

    move-object v1, v2

    move-object/from16 v17, v4

    move-object/from16 v16, v6

    move/from16 v42, v20

    move-object/from16 v13, v36

    move-object/from16 v38, v37

    move-object/from16 v3, v53

    move-object/from16 v37, v7

    move-wide/from16 v6, v188

    goto/16 :goto_68af

    :catch_5fd4
    move-exception v0

    move-object/from16 v37, v13

    goto :goto_5fa6

    :catch_5fd8
    move-exception v0

    move-object/from16 v37, v13

    goto :goto_5fbb

    :cond_5fdc
    move-object/from16 v36, v3

    move-object/from16 v37, v13

    :try_start_5fe0
    invoke-static {v1}, Lsm4;->D0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lomg;

    if-eqz v1, :cond_6150

    iput-object v2, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_5ff2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5fe0 .. :try_end_5ff2} :catch_6134
    .catch Ljava/lang/Exception; {:try_start_5fe0 .. :try_end_5ff2} :catch_6132
    .catchall {:try_start_5fe0 .. :try_end_5ff2} :catchall_2e20

    :try_start_5ff2
    move-object/from16 v3, v48

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v3, v47

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->J:Ljava/util/List;
    :try_end_5ffe
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5ff2 .. :try_end_5ffe} :catch_6144
    .catch Ljava/lang/Exception; {:try_start_5ff2 .. :try_end_5ffe} :catch_6136
    .catchall {:try_start_5ff2 .. :try_end_5ffe} :catchall_2e20

    :try_start_5ffe
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v4, v5, Laak;->N:Lexe;

    iput-object v6, v5, Laak;->O:Lexe;

    iput-object v7, v5, Laak;->P:Lixe;
    :try_end_600a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_5ffe .. :try_end_600a} :catch_6134
    .catch Ljava/lang/Exception; {:try_start_5ffe .. :try_end_600a} :catch_6132
    .catchall {:try_start_5ffe .. :try_end_600a} :catchall_2e20

    move-object/from16 v3, v37

    :try_start_600c
    iput-object v3, v5, Laak;->Q:Lixe;
    :try_end_600e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_600c .. :try_end_600e} :catch_612a
    .catch Ljava/lang/Exception; {:try_start_600c .. :try_end_600e} :catch_6122
    .catchall {:try_start_600c .. :try_end_600e} :catchall_2e20

    move-object/from16 v13, v36

    :try_start_6010
    iput-object v13, v5, Laak;->R:Lcp2;
    :try_end_6012
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6010 .. :try_end_6012} :catch_611e
    .catch Ljava/lang/Exception; {:try_start_6010 .. :try_end_6012} :catch_611a
    .catchall {:try_start_6010 .. :try_end_6012} :catchall_2e20

    move-object/from16 v37, v3

    const/4 v3, 0x0

    :try_start_6015
    iput-object v3, v5, Laak;->S:Lpe9;

    iput-object v3, v5, Laak;->T:Lexe;

    move-object/from16 v3, v35

    iput-object v3, v5, Laak;->U:Lcp2;

    iput-object v0, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v35, v3

    const/4 v3, 0x0

    iput-object v3, v5, Laak;->W:Long;

    iput-object v3, v5, Laak;->X:Ljava/lang/Object;

    iput-object v3, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v3, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v3, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_6030
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6015 .. :try_end_6030} :catch_6110
    .catch Ljava/lang/Exception; {:try_start_6015 .. :try_end_6030} :catch_6104
    .catchall {:try_start_6015 .. :try_end_6030} :catchall_2e20

    move/from16 v3, v33

    :try_start_6032
    iput v3, v5, Laak;->e0:I
    :try_end_6034
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6032 .. :try_end_6034} :catch_6100
    .catch Ljava/lang/Exception; {:try_start_6032 .. :try_end_6034} :catch_60fc
    .catchall {:try_start_6032 .. :try_end_6034} :catchall_2e20

    move/from16 v17, v3

    move/from16 v3, v27

    :try_start_6038
    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_603a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6038 .. :try_end_603a} :catch_60f0
    .catch Ljava/lang/Exception; {:try_start_6038 .. :try_end_603a} :catch_60e2
    .catchall {:try_start_6038 .. :try_end_603a} :catchall_2e20

    move/from16 v27, v3

    move/from16 v3, v20

    :try_start_603e
    iput v3, v5, Laak;->f0:I
    :try_end_6040
    .catch Ljava/util/concurrent/CancellationException; {:try_start_603e .. :try_end_6040} :catch_60d8
    .catch Ljava/lang/Exception; {:try_start_603e .. :try_end_6040} :catch_60cc
    .catchall {:try_start_603e .. :try_end_6040} :catchall_2e20

    move/from16 v33, v3

    move-object/from16 v20, v4

    move-wide/from16 v3, v188

    :try_start_6046
    iput-wide v3, v5, Laak;->k0:J
    :try_end_6048
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6046 .. :try_end_6048} :catch_60c8
    .catch Ljava/lang/Exception; {:try_start_6046 .. :try_end_6048} :catch_60c4
    .catchall {:try_start_6046 .. :try_end_6048} :catchall_2e20

    move-wide/from16 v41, v3

    move/from16 v3, v16

    :try_start_604c
    iput v3, v5, Laak;->g0:I
    :try_end_604e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_604c .. :try_end_604e} :catch_60a4
    .catch Ljava/lang/Exception; {:try_start_604c .. :try_end_604e} :catch_60be
    .catchall {:try_start_604c .. :try_end_604e} :catchall_2e20

    move-wide/from16 v3, v186

    :try_start_6050
    iput-wide v3, v5, Laak;->l0:J
    :try_end_6052
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6050 .. :try_end_6052} :catch_60a4
    .catch Ljava/lang/Exception; {:try_start_6050 .. :try_end_6052} :catch_60ba
    .catchall {:try_start_6050 .. :try_end_6052} :catchall_2e20

    move-wide/from16 v45, v3

    const/16 v3, 0x23

    :try_start_6056
    iput v3, v5, Laak;->m0:I

    invoke-virtual {v2, v5, v1}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_605c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6056 .. :try_end_605c} :catch_60a4
    .catch Ljava/lang/Exception; {:try_start_6056 .. :try_end_605c} :catch_608d
    .catchall {:try_start_6056 .. :try_end_605c} :catchall_2e20

    move-object/from16 v3, v53

    if-ne v1, v3, :cond_6062

    goto/16 :goto_2cea

    :cond_6062
    move-object/from16 v49, v9

    move-object v1, v12

    move/from16 v9, v17

    move-object/from16 v208, v48

    move-object/from16 v48, v11

    move-wide/from16 v11, v45

    move-object/from16 v45, v47

    move-object/from16 v46, v208

    :goto_6071
    move-object/from16 v59, v3

    move-object v4, v7

    move/from16 v194, v9

    move-wide/from16 v16, v11

    move/from16 v193, v27

    move/from16 v192, v33

    move-object/from16 v7, v37

    move-wide/from16 v190, v41

    move-object/from16 v11, v48

    move-object/from16 v9, v49

    move-object v12, v1

    move-object v3, v2

    move-object v2, v13

    move-object/from16 v13, v20

    move-object/from16 v20, v35

    goto/16 :goto_6478

    :catch_608d
    move-exception v0

    :goto_608e
    move-object/from16 v3, v53

    :goto_6090
    move-object v1, v2

    move-object/from16 v59, v3

    move-object v4, v13

    move-object/from16 v13, v20

    move/from16 v16, v33

    move-object/from16 v3, v37

    move-wide/from16 v197, v41

    move-wide/from16 v195, v45

    move/from16 v20, v17

    move/from16 v17, v27

    goto/16 :goto_6790

    :catch_60a4
    move-exception v0

    :goto_60a5
    move-object/from16 v3, v53

    :goto_60a7
    move-object v1, v2

    move-object/from16 v16, v6

    move-object/from16 v38, v37

    move-object/from16 v37, v7

    move-wide/from16 v6, v41

    move/from16 v42, v33

    move/from16 v33, v27

    move/from16 v27, v17

    move-object/from16 v17, v20

    goto/16 :goto_68af

    :catch_60ba
    move-exception v0

    move-wide/from16 v45, v3

    goto :goto_608e

    :catch_60be
    move-exception v0

    :goto_60bf
    move-object/from16 v3, v53

    move-wide/from16 v45, v186

    goto :goto_6090

    :catch_60c4
    move-exception v0

    move-wide/from16 v41, v3

    goto :goto_60bf

    :catch_60c8
    move-exception v0

    move-wide/from16 v41, v3

    goto :goto_60a5

    :catch_60cc
    move-exception v0

    move/from16 v33, v3

    move-object/from16 v20, v4

    move-object/from16 v3, v53

    move-wide/from16 v45, v186

    move-wide/from16 v41, v188

    goto :goto_6090

    :catch_60d8
    move-exception v0

    move/from16 v33, v3

    move-object/from16 v20, v4

    move-object/from16 v3, v53

    move-wide/from16 v41, v188

    goto :goto_60a7

    :catch_60e2
    move-exception v0

    move/from16 v27, v3

    :goto_60e5
    move/from16 v33, v20

    move-object/from16 v3, v53

    move-wide/from16 v45, v186

    move-wide/from16 v41, v188

    :goto_60ed
    move-object/from16 v20, v4

    goto :goto_6090

    :catch_60f0
    move-exception v0

    move/from16 v27, v3

    :goto_60f3
    move/from16 v33, v20

    move-object/from16 v3, v53

    move-wide/from16 v41, v188

    :goto_60f9
    move-object/from16 v20, v4

    goto :goto_60a7

    :catch_60fc
    move-exception v0

    move/from16 v17, v3

    goto :goto_60e5

    :catch_6100
    move-exception v0

    move/from16 v17, v3

    goto :goto_60f3

    :catch_6104
    move-exception v0

    :goto_6105
    move/from16 v17, v33

    :goto_6107
    move-object/from16 v3, v53

    move-wide/from16 v45, v186

    move-wide/from16 v41, v188

    move/from16 v33, v20

    goto :goto_60ed

    :catch_6110
    move-exception v0

    :goto_6111
    move/from16 v17, v33

    :goto_6113
    move-object/from16 v3, v53

    move-wide/from16 v41, v188

    move/from16 v33, v20

    goto :goto_60f9

    :catch_611a
    move-exception v0

    move-object/from16 v37, v3

    goto :goto_6105

    :catch_611e
    move-exception v0

    move-object/from16 v37, v3

    goto :goto_6111

    :catch_6122
    move-exception v0

    move-object/from16 v37, v3

    :goto_6125
    move/from16 v17, v33

    move-object/from16 v13, v36

    goto :goto_6107

    :catch_612a
    move-exception v0

    move-object/from16 v37, v3

    :goto_612d
    move/from16 v17, v33

    move-object/from16 v13, v36

    goto :goto_6113

    :catch_6132
    move-exception v0

    goto :goto_6125

    :catch_6134
    move-exception v0

    goto :goto_612d

    :catch_6136
    move-exception v0

    move/from16 v17, v33

    move-object/from16 v13, v36

    move-object/from16 v3, v53

    move-wide/from16 v45, v186

    move-wide/from16 v41, v188

    move/from16 v33, v20

    goto :goto_60ed

    :catch_6144
    move-exception v0

    move/from16 v17, v33

    move-object/from16 v13, v36

    move-object/from16 v3, v53

    move-wide/from16 v41, v188

    move/from16 v33, v20

    goto :goto_60f9

    :cond_6150
    move/from16 v17, v33

    move-object/from16 v13, v36

    move-wide/from16 v45, v186

    move-wide/from16 v41, v188

    move/from16 v33, v20

    move-object/from16 v20, v4

    move-object v3, v2

    move-object v4, v7

    move-object v2, v13

    move/from16 v194, v17

    move-object/from16 v13, v20

    move/from16 v193, v27

    move/from16 v192, v33

    move-object/from16 v20, v35

    move-object/from16 v7, v37

    move-wide/from16 v190, v41

    move-wide/from16 v16, v45

    move-object/from16 v45, v47

    move-object/from16 v46, v48

    move-object/from16 v59, v53

    goto/16 :goto_6478

    :catch_6177
    move-exception v0

    move-object/from16 v37, v13

    move/from16 v17, v33

    move-wide/from16 v45, v186

    move-wide/from16 v41, v188

    move-object v13, v3

    move/from16 v33, v20

    move-object/from16 v3, v53

    goto/16 :goto_60ed

    :catch_6187
    move-exception v0

    move-object/from16 v37, v13

    move/from16 v17, v33

    move-wide/from16 v41, v188

    move-object v13, v3

    move/from16 v33, v20

    move-object/from16 v3, v53

    goto/16 :goto_60f9

    :catch_6195
    move-exception v0

    :goto_6196
    move-object/from16 v2, v59

    :goto_6198
    const/16 v30, 0x1

    move-object/from16 v47, p1

    :goto_619c
    move-object v1, v4

    move-wide/from16 v197, v6

    move-object/from16 v6, v16

    move-object/from16 v48, v17

    move-object/from16 v4, v20

    move/from16 v20, v35

    move/from16 v17, v36

    move-object/from16 v7, v37

    move-object/from16 v3, v38

    move/from16 v16, v42

    move-wide/from16 v195, v45

    goto/16 :goto_6790

    :catch_61b3
    move-exception v0

    :goto_61b4
    move-object/from16 v2, v59

    :goto_61b6
    const/16 v30, 0x1

    move-object/from16 v47, p1

    :goto_61ba
    move-object v3, v2

    move-object v1, v4

    move-object/from16 v48, v17

    move/from16 v27, v35

    move/from16 v33, v36

    :goto_61c2
    move-object/from16 v17, v13

    move-object/from16 v13, v20

    goto/16 :goto_68af

    :catch_61c8
    move-exception v0

    move-wide/from16 v45, v2

    goto :goto_6196

    :catch_61cc
    move-exception v0

    move/from16 v42, v3

    move-object/from16 v2, v59

    move-wide/from16 v45, v147

    goto :goto_6198

    :catch_61d4
    move-exception v0

    move/from16 v42, v3

    goto :goto_61b4

    :catch_61d8
    move-exception v0

    move/from16 v42, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    :goto_61e1
    move-wide/from16 v45, v147

    move-wide/from16 v6, v149

    goto :goto_6198

    :catch_61e6
    move-exception v0

    move/from16 v42, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    :goto_61ef
    move-wide/from16 v6, v149

    goto :goto_61b6

    :catch_61f2
    move-exception v0

    move/from16 v36, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    move/from16 v42, v146

    goto :goto_61e1

    :catch_61fe
    move-exception v0

    move/from16 v36, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    move/from16 v42, v146

    goto :goto_61ef

    :catch_620a
    move-exception v0

    move/from16 v35, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    move/from16 v42, v146

    move-wide/from16 v45, v147

    move-wide/from16 v6, v149

    move/from16 v36, v151

    goto/16 :goto_6198

    :catch_621d
    move-exception v0

    move/from16 v35, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    move/from16 v42, v146

    move-wide/from16 v6, v149

    move/from16 v36, v151

    goto :goto_61b6

    :catch_622d
    move-exception v0

    :goto_622e
    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    :goto_6234
    move/from16 v42, v146

    move-wide/from16 v45, v147

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    goto/16 :goto_6198

    :catch_6240
    move-exception v0

    :goto_6241
    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    :goto_6247
    move/from16 v42, v146

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    goto/16 :goto_61b6

    :catch_6251
    move-exception v0

    move-object/from16 v20, v3

    goto :goto_622e

    :catch_6255
    move-exception v0

    move-object/from16 v20, v3

    goto :goto_6241

    :catch_6259
    move-exception v0

    move-object/from16 v16, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    :goto_6262
    move-object/from16 v20, v144

    goto :goto_6234

    :catch_6265
    move-exception v0

    move-object/from16 v16, v3

    move-object/from16 v37, v6

    move-object/from16 v38, v7

    move-object/from16 v2, v59

    :goto_626e
    move-object/from16 v20, v144

    goto :goto_6247

    :catch_6271
    move-exception v0

    move-object/from16 v16, v3

    move-object/from16 v37, v6

    move-object/from16 v2, v59

    :goto_6278
    move-object/from16 v38, v143

    goto :goto_6262

    :catch_627b
    move-exception v0

    move-object/from16 v16, v3

    move-object/from16 v37, v6

    move-object/from16 v2, v59

    :goto_6282
    move-object/from16 v38, v143

    goto :goto_626e

    :catch_6285
    move-exception v0

    move-object/from16 v16, v3

    move-object/from16 v2, v59

    :goto_628a
    move-object/from16 v37, v142

    goto :goto_6278

    :catch_628d
    move-exception v0

    move-object/from16 v16, v3

    move-object/from16 v2, v59

    :goto_6292
    move-object/from16 v37, v142

    goto :goto_6282

    :catch_6295
    move-exception v0

    :goto_6296
    move-object/from16 v2, v59

    move-object/from16 v16, v141

    goto :goto_628a

    :catch_629b
    move-exception v0

    :goto_629c
    move-object/from16 v2, v59

    move-object/from16 v16, v141

    goto :goto_6292

    :catch_62a1
    move-exception v0

    :goto_62a2
    move-object/from16 v2, v59

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move/from16 v42, v146

    move-wide/from16 v45, v147

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    const/16 v30, 0x1

    goto :goto_62ce

    :catch_62b9
    move-exception v0

    :goto_62ba
    move-object/from16 v2, v59

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move/from16 v42, v146

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    goto/16 :goto_61b6

    :goto_62ce
    move-object/from16 v47, p1

    :goto_62d0
    move-object/from16 v59, v2

    goto/16 :goto_619c

    :catch_62d4
    move-exception v0

    :goto_62d5
    move-object/from16 v17, v3

    goto :goto_62a2

    :catch_62d8
    move-exception v0

    :goto_62d9
    move-object/from16 v17, v3

    goto :goto_62ba

    :catch_62dc
    move-exception v0

    :goto_62dd
    move-object/from16 v17, v3

    goto :goto_6296

    :catch_62e0
    move-exception v0

    :goto_62e1
    move-object/from16 v17, v3

    goto :goto_629c

    :catch_62e4
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_62d5

    :catch_62e8
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_62d9

    :catch_62ec
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_62dd

    :catch_62f0
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_62e1

    :catch_62f4
    move-exception v0

    move-object/from16 v17, v3

    move-object v1, v6

    move-object/from16 v2, v59

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move/from16 v42, v146

    move-wide/from16 v45, v147

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    const/16 v30, 0x1

    move-object/from16 v47, v1

    goto/16 :goto_619c

    :catch_6312
    move-exception v0

    move-object/from16 v17, v3

    move-object v1, v6

    move-object/from16 v2, v59

    :goto_6318
    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move/from16 v42, v146

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    const/16 v30, 0x1

    move-object/from16 v47, v1

    goto/16 :goto_61ba

    :catch_632e
    move-exception v0

    move-object v2, v1

    move-object/from16 v17, v3

    move-object v1, v6

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move/from16 v42, v146

    move-wide/from16 v45, v147

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    const/16 v30, 0x1

    move-object/from16 v47, v1

    goto :goto_62d0

    :catch_634a
    move-exception v0

    move-object v2, v1

    move-object/from16 v17, v3

    move-object v1, v6

    goto :goto_6318

    :cond_6350
    move-object v2, v1

    move-object/from16 v17, v3

    move-object v1, v6

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move-object/from16 v27, v145

    move/from16 v42, v146

    move-wide/from16 v45, v147

    move-wide/from16 v6, v149

    move/from16 v36, v151

    move/from16 v35, v152

    move-object/from16 v33, v153

    const/16 v30, 0x1

    :try_start_636c
    instance-of v3, v0, Lpg0;

    if-eqz v3, :cond_65ee

    sget-object v3, Lmta;->a:Llta;
    :try_end_6372
    .catch Ljava/util/concurrent/CancellationException; {:try_start_636c .. :try_end_6372} :catch_65dd
    .catch Ljava/lang/Exception; {:try_start_636c .. :try_end_6372} :catch_65d9
    .catchall {:try_start_636c .. :try_end_6372} :catchall_2e20

    :try_start_6372
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Llta;->b()Z

    move-result v3
    :try_end_6379
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6372 .. :try_end_6379} :catch_65e5
    .catch Ljava/lang/Exception; {:try_start_6372 .. :try_end_6379} :catch_65e1
    .catchall {:try_start_6372 .. :try_end_6379} :catchall_2e20

    if-nez v3, :cond_6385

    move-object/from16 p1, v1

    move-object/from16 v43, v4

    move-wide/from16 v48, v6

    move-object/from16 v7, v44

    goto/16 :goto_6456

    :cond_6385
    :try_start_6385
    invoke-static {v4}, Lp8;->I(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Llta;->a()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v41
    :try_end_638d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6385 .. :try_end_638d} :catch_65dd
    .catch Ljava/lang/Exception; {:try_start_6385 .. :try_end_638d} :catch_65d9
    .catchall {:try_start_6385 .. :try_end_638d} :catchall_2e20

    move-object/from16 p1, v1

    :try_start_638f
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual/range {v41 .. v41}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v41

    :goto_6398
    invoke-interface/range {v41 .. v41}, Ljava/util/Iterator;->hasNext()Z

    move-result v43
    :try_end_639c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_638f .. :try_end_639c} :catch_65c9
    .catch Ljava/lang/Exception; {:try_start_638f .. :try_end_639c} :catch_65c2
    .catchall {:try_start_638f .. :try_end_639c} :catchall_2e20

    if-eqz v43, :cond_640c

    move-object/from16 v43, v4

    :try_start_63a0
    invoke-interface/range {v41 .. v41}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v47, v4

    check-cast v47, Lmta;
    :try_end_63a8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_63a0 .. :try_end_63a8} :catch_6403
    .catch Ljava/lang/Exception; {:try_start_63a0 .. :try_end_63a8} :catch_63f9
    .catchall {:try_start_63a0 .. :try_end_63a8} :catchall_2e20

    move-wide/from16 v48, v6

    :try_start_63aa
    move-object/from16 v6, v47

    check-cast v6, Ls40;
    :try_end_63ae
    .catch Ljava/util/concurrent/CancellationException; {:try_start_63aa .. :try_end_63ae} :catch_63f5
    .catch Ljava/lang/Exception; {:try_start_63aa .. :try_end_63ae} :catch_63f1
    .catchall {:try_start_63aa .. :try_end_63ae} :catchall_2e20

    move-object/from16 v7, v44

    :try_start_63b0
    invoke-virtual {v6, v7, v3}, Ls40;->a(Lfta;Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_63b9

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_63b9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_63b0 .. :try_end_63b9} :catch_63df
    .catch Ljava/lang/Exception; {:try_start_63b0 .. :try_end_63b9} :catch_63c0
    .catchall {:try_start_63b0 .. :try_end_63b9} :catchall_2e20

    :cond_63b9
    move-object/from16 v44, v7

    move-object/from16 v4, v43

    move-wide/from16 v6, v48

    goto :goto_6398

    :catch_63c0
    move-exception v0

    :goto_63c1
    move-object/from16 v47, p1

    move-object/from16 v59, v2

    move-object/from16 v44, v7

    :goto_63c7
    move-object/from16 v6, v16

    move-object/from16 v4, v20

    move/from16 v20, v35

    move-object/from16 v7, v37

    move-object/from16 v3, v38

    move/from16 v16, v42

    move-object/from16 v1, v43

    move-wide/from16 v195, v45

    move-wide/from16 v197, v48

    move-object/from16 v48, v17

    move/from16 v17, v36

    goto/16 :goto_6790

    :catch_63df
    move-exception v0

    :goto_63e0
    move-object/from16 v47, p1

    move-object v3, v2

    move-object/from16 v44, v7

    :goto_63e5
    move/from16 v27, v35

    move/from16 v33, v36

    move-object/from16 v1, v43

    move-wide/from16 v6, v48

    :goto_63ed
    move-object/from16 v48, v17

    goto/16 :goto_61c2

    :catch_63f1
    move-exception v0

    move-object/from16 v7, v44

    goto :goto_63c1

    :catch_63f5
    move-exception v0

    move-object/from16 v7, v44

    goto :goto_63e0

    :catch_63f9
    move-exception v0

    move-wide/from16 v48, v6

    move-object/from16 v7, v44

    :goto_63fe
    move-object/from16 v47, p1

    move-object/from16 v59, v2

    goto :goto_63c7

    :catch_6403
    move-exception v0

    move-wide/from16 v48, v6

    move-object/from16 v7, v44

    :goto_6408
    move-object/from16 v47, p1

    move-object v3, v2

    goto :goto_63e5

    :cond_640c
    move-object/from16 v43, v4

    move-wide/from16 v48, v6

    move-object/from16 v7, v44

    :try_start_6412
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4
    :try_end_6416
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6412 .. :try_end_6416} :catch_65bd
    .catch Ljava/lang/Exception; {:try_start_6412 .. :try_end_6416} :catch_65b8
    .catchall {:try_start_6412 .. :try_end_6416} :catchall_2e20

    if-nez v4, :cond_6456

    :try_start_6418
    sget-object v4, Lmta;->a:Llta;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v4, v15, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lpg0;

    invoke-static {v0}, Lxjl;->p(Lpg0;)Ljava/lang/String;

    move-result-object v0

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v41, v1

    const-string v1, "loadOlder: listEvents beforeId="

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " failed: "

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual/range {v41 .. v41}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_6444
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6456

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lmta;

    check-cast v4, Ls40;

    invoke-virtual {v4, v7, v3, v0}, Ls40;->b(Lfta;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_6455
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6418 .. :try_end_6455} :catch_63df
    .catch Ljava/lang/Exception; {:try_start_6418 .. :try_end_6455} :catch_63c0
    .catchall {:try_start_6418 .. :try_end_6455} :catchall_2e20

    goto :goto_6444

    :cond_6456
    :goto_6456
    move-object/from16 v59, v2

    move-object/from16 v44, v7

    move-object/from16 v6, v16

    move-object/from16 v2, v20

    move-object/from16 v20, v27

    move-object/from16 v0, v33

    move/from16 v194, v35

    move/from16 v193, v36

    move-object/from16 v4, v37

    move-object/from16 v7, v38

    move/from16 v192, v42

    move-object/from16 v3, v43

    move-wide/from16 v190, v48

    move-wide/from16 v208, v45

    move-object/from16 v45, p1

    move-object/from16 v46, v17

    move-wide/from16 v16, v208

    :goto_6478
    :try_start_6478
    new-instance v1, Lvmg;
    :try_end_647a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6478 .. :try_end_647a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_6478 .. :try_end_647a} :catch_65b0
    .catchall {:try_start_6478 .. :try_end_647a} :catchall_2e20

    move-object/from16 v27, v2

    :try_start_647c
    iget-boolean v2, v12, Lexe;->E:Z
    :try_end_647e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_647c .. :try_end_647e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_647c .. :try_end_647e} :catch_65aa
    .catchall {:try_start_647c .. :try_end_647e} :catchall_2e20

    move-object/from16 v33, v7

    const/4 v7, 0x0

    :try_start_6481
    invoke-direct {v1, v2, v7}, Lvmg;-><init>(ZZ)V

    iput-object v3, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_648e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6481 .. :try_end_648e} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_6481 .. :try_end_648e} :catch_65a2
    .catchall {:try_start_6481 .. :try_end_648e} :catchall_2e20

    :try_start_648e
    move-object/from16 v2, v46

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v2, v45

    check-cast v2, Ljava/util/List;

    iput-object v2, v5, Laak;->J:Ljava/util/List;
    :try_end_649a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_648e .. :try_end_649a} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_648e .. :try_end_649a} :catch_65a4
    .catchall {:try_start_648e .. :try_end_649a} :catchall_2e20

    :try_start_649a
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v13, v5, Laak;->N:Lexe;

    iput-object v6, v5, Laak;->O:Lexe;

    iput-object v4, v5, Laak;->P:Lixe;
    :try_end_64a6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_649a .. :try_end_64a6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_649a .. :try_end_64a6} :catch_65a2
    .catchall {:try_start_649a .. :try_end_64a6} :catchall_2e20

    move-object/from16 v2, v33

    :try_start_64a8
    iput-object v2, v5, Laak;->Q:Lixe;
    :try_end_64aa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64a8 .. :try_end_64aa} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64a8 .. :try_end_64aa} :catch_659a
    .catchall {:try_start_64a8 .. :try_end_64aa} :catchall_2e20

    move-object/from16 v7, v27

    :try_start_64ac
    iput-object v7, v5, Laak;->R:Lcp2;
    :try_end_64ae
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64ac .. :try_end_64ae} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64ac .. :try_end_64ae} :catch_6596
    .catchall {:try_start_64ac .. :try_end_64ae} :catchall_2e20

    move-object/from16 v33, v2

    const/4 v2, 0x0

    :try_start_64b1
    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v2, v5, Laak;->T:Lexe;

    move-object/from16 v2, v20

    iput-object v2, v5, Laak;->U:Lcp2;

    iput-object v0, v5, Laak;->V:Ljava/lang/Object;

    move-object/from16 v20, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v2, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_64cc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64b1 .. :try_end_64cc} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64b1 .. :try_end_64cc} :catch_6586
    .catchall {:try_start_64b1 .. :try_end_64cc} :catchall_2e20

    move/from16 v2, v194

    :try_start_64ce
    iput v2, v5, Laak;->e0:I
    :try_end_64d0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64ce .. :try_end_64d0} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64ce .. :try_end_64d0} :catch_6576
    .catchall {:try_start_64ce .. :try_end_64d0} :catchall_2e20

    move/from16 v27, v2

    move/from16 v2, v193

    :try_start_64d4
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_64d6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64d4 .. :try_end_64d6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64d4 .. :try_end_64d6} :catch_6568
    .catchall {:try_start_64d4 .. :try_end_64d6} :catchall_2e20

    move/from16 v35, v2

    move/from16 v2, v192

    :try_start_64da
    iput v2, v5, Laak;->f0:I
    :try_end_64dc
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64da .. :try_end_64dc} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64da .. :try_end_64dc} :catch_655c
    .catchall {:try_start_64da .. :try_end_64dc} :catchall_2e20

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-wide/from16 v6, v190

    :try_start_64e2
    iput-wide v6, v5, Laak;->k0:J
    :try_end_64e4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64e2 .. :try_end_64e4} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64e2 .. :try_end_64e4} :catch_6558
    .catchall {:try_start_64e2 .. :try_end_64e4} :catchall_2e20

    move/from16 v38, v2

    const/4 v2, 0x0

    :try_start_64e7
    iput v2, v5, Laak;->g0:I
    :try_end_64e9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64e7 .. :try_end_64e9} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64e7 .. :try_end_64e9} :catch_6554
    .catchall {:try_start_64e7 .. :try_end_64e9} :catchall_2e20

    move-wide/from16 v41, v6

    move-wide/from16 v6, v16

    :try_start_64ed
    iput-wide v6, v5, Laak;->l0:J

    const/16 v2, 0x25

    iput v2, v5, Laak;->m0:I

    invoke-virtual {v3, v5, v1}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_64f7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_64ed .. :try_end_64f7} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_64ed .. :try_end_64f7} :catch_652e
    .catchall {:try_start_64ed .. :try_end_64f7} :catchall_2e20

    move-object/from16 v2, v59

    if-ne v1, v2, :cond_64fd

    goto/16 :goto_7700

    :cond_64fd
    move/from16 v84, v27

    move/from16 v83, v35

    move-object/from16 v1, v37

    move/from16 v86, v38

    move-wide/from16 v81, v41

    move-object/from16 v41, v45

    const/16 v85, 0x0

    move-wide/from16 v37, v6

    move-object v7, v8

    move-object v8, v9

    move-object v9, v11

    move-object v6, v12

    move-object/from16 v42, v13

    move-object v11, v14

    move-object v12, v15

    move-object/from16 v15, v33

    move-object/from16 v13, v36

    move-object/from16 v36, v46

    move-object v14, v10

    move-object v10, v0

    move-object/from16 v0, v20

    :goto_651f
    move-object/from16 p1, v0

    move-object/from16 v59, v2

    move-object v2, v4

    move-object v0, v10

    move-object/from16 v49, v32

    move-object/from16 v10, v42

    move-object/from16 v40, v44

    move-object v4, v3

    goto/16 :goto_2b92

    :catch_652e
    move-exception v0

    :goto_652f
    move-object/from16 v2, v59

    :goto_6531
    move/from16 v1, v38

    move-object/from16 v38, v36

    move-object/from16 v36, v46

    move-wide/from16 v46, v41

    move-object/from16 v41, v45

    move/from16 v45, v1

    move-object v1, v3

    move-object/from16 v52, v4

    move-object/from16 v17, v10

    move-object v6, v12

    move-object v12, v13

    move/from16 v7, v30

    move-object/from16 v43, v33

    move-object/from16 v33, v37

    move-object/from16 v4, v44

    move-object/from16 v13, v58

    const/16 v48, 0x0

    move/from16 v37, v27

    goto/16 :goto_7437

    :catch_6554
    move-exception v0

    :goto_6555
    move-wide/from16 v41, v6

    goto :goto_652f

    :catch_6558
    move-exception v0

    move/from16 v38, v2

    goto :goto_6555

    :catch_655c
    move-exception v0

    move/from16 v38, v2

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    move-wide/from16 v41, v190

    goto :goto_6531

    :catch_6568
    move-exception v0

    move/from16 v35, v2

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    move-wide/from16 v41, v190

    move/from16 v38, v192

    goto :goto_6531

    :catch_6576
    move-exception v0

    move/from16 v27, v2

    move-object/from16 v36, v6

    move-object/from16 v37, v7

    move-object/from16 v2, v59

    move-wide/from16 v41, v190

    move/from16 v38, v192

    move/from16 v35, v193

    goto :goto_6531

    :catch_6586
    move-exception v0

    :goto_6587
    move-object/from16 v36, v6

    move-object/from16 v37, v7

    :goto_658b
    move-object/from16 v2, v59

    move-wide/from16 v41, v190

    move/from16 v38, v192

    move/from16 v35, v193

    move/from16 v27, v194

    goto :goto_6531

    :catch_6596
    move-exception v0

    move-object/from16 v33, v2

    goto :goto_6587

    :catch_659a
    move-exception v0

    move-object/from16 v33, v2

    :goto_659d
    move-object/from16 v36, v6

    :goto_659f
    move-object/from16 v37, v27

    goto :goto_658b

    :catch_65a2
    move-exception v0

    goto :goto_659d

    :catch_65a4
    move-exception v0

    move-object/from16 v36, v6

    move-object/from16 v37, v27

    goto :goto_658b

    :catch_65aa
    move-exception v0

    move-object/from16 v36, v6

    move-object/from16 v33, v7

    goto :goto_659f

    :catch_65b0
    move-exception v0

    move-object/from16 v37, v2

    move-object/from16 v36, v6

    move-object/from16 v33, v7

    goto :goto_658b

    :catch_65b8
    move-exception v0

    move-object/from16 v44, v7

    goto/16 :goto_63fe

    :catch_65bd
    move-exception v0

    move-object/from16 v44, v7

    goto/16 :goto_6408

    :catch_65c2
    move-exception v0

    :goto_65c3
    move-object/from16 v43, v4

    move-wide/from16 v48, v6

    goto/16 :goto_63fe

    :catch_65c9
    move-exception v0

    :goto_65ca
    move-object/from16 v43, v4

    move-wide/from16 v48, v6

    move-object/from16 v47, p1

    move-object v3, v2

    move/from16 v27, v35

    move/from16 v33, v36

    move-object/from16 v1, v43

    goto/16 :goto_63ed

    :catch_65d9
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_65c3

    :catch_65dd
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_65ca

    :catch_65e1
    move-exception v0

    move-object/from16 p1, v1

    goto :goto_65c3

    :catch_65e5
    move-exception v0

    move-object/from16 p1, v1

    move-object/from16 v43, v4

    move-wide/from16 v48, v6

    goto/16 :goto_6408

    :cond_65ee
    move-object/from16 p1, v1

    move-object/from16 v43, v4

    move-wide/from16 v48, v6

    :try_start_65f4
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0
    :try_end_65fa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_65f4 .. :try_end_65fa} :catch_65fd
    .catch Ljava/lang/Exception; {:try_start_65f4 .. :try_end_65fa} :catch_65fa
    .catchall {:try_start_65f4 .. :try_end_65fa} :catchall_2e20

    :catch_65fa
    move-exception v0

    goto/16 :goto_63fe

    :catch_65fd
    move-exception v0

    goto/16 :goto_6408

    :catch_6600
    move-exception v0

    move-object v2, v1

    move-object/from16 v17, v3

    move-object/from16 v43, v4

    move-object/from16 p1, v6

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move/from16 v42, v146

    move-wide/from16 v45, v147

    move-wide/from16 v48, v149

    move/from16 v36, v151

    move/from16 v35, v152

    const/16 v30, 0x1

    goto/16 :goto_63fe

    :catch_661e
    move-exception v0

    move-object v2, v1

    move-object/from16 v17, v3

    move-object/from16 v43, v4

    move-object/from16 p1, v6

    move-object/from16 v16, v141

    move-object/from16 v37, v142

    move-object/from16 v38, v143

    move-object/from16 v20, v144

    move/from16 v42, v146

    move-wide/from16 v48, v149

    move/from16 v36, v151

    move/from16 v35, v152

    const/16 v30, 0x1

    goto/16 :goto_6408

    :catch_663a
    move-exception v0

    :goto_663b
    move-object/from16 v2, v59

    :goto_663d
    const/16 v30, 0x1

    :goto_663f
    move-object/from16 v3, v17

    move/from16 v17, v20

    move/from16 v16, v27

    move-object/from16 v4, v33

    move/from16 v20, v36

    move-object/from16 v1, v37

    move-object/from16 v7, v38

    move-object/from16 v6, v41

    move-object/from16 v13, v43

    move-wide/from16 v197, v48

    move-wide/from16 v195, v52

    move-object/from16 v48, v47

    goto/16 :goto_a7a

    :catch_6659
    move-exception v0

    :goto_665a
    move-object/from16 v2, v59

    :goto_665c
    const/16 v30, 0x1

    :goto_665e
    move-object v3, v2

    :goto_665f
    move/from16 v42, v27

    move-object/from16 v13, v33

    move/from16 v27, v36

    move-object/from16 v1, v37

    move-object/from16 v37, v38

    move-object/from16 v16, v41

    move-wide/from16 v6, v48

    move-object/from16 v38, v17

    move/from16 v33, v20

    move-object/from16 v17, v43

    move-object/from16 v48, v47

    goto/16 :goto_ac0

    :catch_6677
    move-exception v0

    :goto_6678
    move-object/from16 v41, v2

    move-wide/from16 v52, v3

    move-object/from16 v33, v6

    move/from16 v36, v7

    goto :goto_663b

    :catch_6681
    move-exception v0

    :goto_6682
    move-object/from16 v41, v2

    :goto_6684
    move-object/from16 v33, v6

    move/from16 v36, v7

    goto :goto_665a

    :catch_6689
    move-exception v0

    move-object/from16 v43, v1

    goto :goto_6678

    :catch_668d
    move-exception v0

    move-object/from16 v43, v1

    goto :goto_6682

    :catch_6691
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    :goto_6696
    move-object/from16 v33, v6

    move/from16 v36, v7

    move-object/from16 v2, v59

    move-wide/from16 v52, v136

    goto :goto_663d

    :catch_669f
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-wide/from16 v48, v3

    goto :goto_6696

    :catch_66a7
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-wide/from16 v48, v3

    goto :goto_6684

    :catch_66af
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move/from16 v27, v3

    move-object/from16 v17, v4

    move-object/from16 v33, v6

    move/from16 v36, v7

    move-object/from16 v2, v59

    move-wide/from16 v52, v136

    move-wide/from16 v48, v138

    goto/16 :goto_663d

    :catch_66c4
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move/from16 v27, v3

    move-object/from16 v17, v4

    move-object/from16 v33, v6

    move/from16 v36, v7

    move-object/from16 v2, v59

    move-wide/from16 v48, v138

    goto :goto_665c

    :catch_66d6
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move/from16 v20, v3

    :goto_66dd
    move-object/from16 v33, v6

    move/from16 v36, v7

    move/from16 v27, v17

    move-object/from16 v2, v59

    move-wide/from16 v52, v136

    move-wide/from16 v48, v138

    const/16 v30, 0x1

    :goto_66eb
    move-object/from16 v17, v4

    goto/16 :goto_663f

    :catch_66ef
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move/from16 v20, v3

    :goto_66f6
    move-object/from16 v33, v6

    move/from16 v36, v7

    move/from16 v27, v17

    move-object/from16 v2, v59

    move-wide/from16 v48, v138

    const/16 v30, 0x1

    :goto_6702
    move-object/from16 v17, v4

    goto/16 :goto_665e

    :catch_6706
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    goto :goto_66dd

    :catch_670c
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    goto :goto_66f6

    :catch_6712
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    :goto_6717
    move-object/from16 v33, v6

    :goto_6719
    move/from16 v36, v27

    move-object/from16 v2, v59

    move-wide/from16 v52, v136

    move-wide/from16 v48, v138

    const/16 v30, 0x1

    move/from16 v27, v17

    goto :goto_66eb

    :catch_6726
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    :goto_672b
    move-object/from16 v33, v6

    :goto_672d
    move/from16 v36, v27

    move-object/from16 v2, v59

    move-wide/from16 v48, v138

    const/16 v30, 0x1

    move/from16 v27, v17

    goto :goto_6702

    :catch_6738
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-object/from16 v38, v3

    goto :goto_6717

    :catch_6740
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-object/from16 v38, v3

    goto :goto_672b

    :catch_6748
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-object/from16 v38, v3

    move-object/from16 v33, v6

    move/from16 v36, v27

    move-object/from16 v2, v59

    move-wide/from16 v52, v136

    move-wide/from16 v48, v138

    const/16 v30, 0x1

    move/from16 v27, v17

    move-object/from16 v17, v4

    goto :goto_6774

    :catch_6760
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-object/from16 v38, v3

    move-object/from16 v33, v6

    move/from16 v36, v27

    move-object/from16 v2, v59

    move-wide/from16 v48, v138

    const/16 v30, 0x1

    move/from16 v27, v17

    goto :goto_6702

    :goto_6774
    move-object/from16 v59, v2

    goto/16 :goto_663f

    :catch_6778
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-object/from16 v38, v3

    move-object/from16 v33, v6

    move-object/from16 v37, v7

    goto :goto_6719

    :catch_6784
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-object/from16 v38, v3

    move-object/from16 v33, v6

    move-object/from16 v37, v7

    goto :goto_672d

    :goto_6790
    :try_start_6790
    new-instance v2, Lvmg;
    :try_end_6792
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6790 .. :try_end_6792} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_6790 .. :try_end_6792} :catch_688a
    .catchall {:try_start_6790 .. :try_end_6792} :catchall_2e20

    move-object/from16 v27, v4

    :try_start_6794
    iget-boolean v4, v12, Lexe;->E:Z
    :try_end_6796
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6794 .. :try_end_6796} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_6794 .. :try_end_6796} :catch_688e
    .catchall {:try_start_6794 .. :try_end_6796} :catchall_2e20

    move-object/from16 v33, v3

    const/4 v3, 0x0

    :try_start_6799
    invoke-direct {v2, v4, v3}, Lvmg;-><init>(ZZ)V

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v8, v5, Laak;->E:Lixe;

    iput-object v9, v5, Laak;->F:Lpng;

    iput-object v11, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_67a6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6799 .. :try_end_67a6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_6799 .. :try_end_67a6} :catch_6892
    .catchall {:try_start_6799 .. :try_end_67a6} :catchall_2e20

    :try_start_67a6
    move-object/from16 v3, v48

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v3, v47

    check-cast v3, Ljava/util/List;

    iput-object v3, v5, Laak;->J:Ljava/util/List;
    :try_end_67b2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67a6 .. :try_end_67b2} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67a6 .. :try_end_67b2} :catch_6894
    .catchall {:try_start_67a6 .. :try_end_67b2} :catchall_2e20

    :try_start_67b2
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v10, v5, Laak;->L:Lixe;

    iput-object v12, v5, Laak;->M:Lexe;

    iput-object v13, v5, Laak;->N:Lexe;

    iput-object v6, v5, Laak;->O:Lexe;

    iput-object v7, v5, Laak;->P:Lixe;
    :try_end_67be
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67b2 .. :try_end_67be} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67b2 .. :try_end_67be} :catch_6892
    .catchall {:try_start_67b2 .. :try_end_67be} :catchall_2e20

    move-object/from16 v3, v33

    :try_start_67c0
    iput-object v3, v5, Laak;->Q:Lixe;
    :try_end_67c2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67c0 .. :try_end_67c2} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67c0 .. :try_end_67c2} :catch_688e
    .catchall {:try_start_67c0 .. :try_end_67c2} :catchall_2e20

    move-object/from16 v4, v27

    :try_start_67c4
    iput-object v4, v5, Laak;->R:Lcp2;
    :try_end_67c6
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67c4 .. :try_end_67c6} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67c4 .. :try_end_67c6} :catch_688a
    .catchall {:try_start_67c4 .. :try_end_67c6} :catchall_2e20

    move-object/from16 v33, v3

    const/4 v3, 0x0

    :try_start_67c9
    iput-object v3, v5, Laak;->S:Lpe9;

    iput-object v3, v5, Laak;->T:Lexe;

    iput-object v3, v5, Laak;->U:Lcp2;

    iput-object v3, v5, Laak;->V:Ljava/lang/Object;

    iput-object v3, v5, Laak;->W:Long;

    iput-object v3, v5, Laak;->X:Ljava/lang/Object;

    iput-object v0, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v3, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v3, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v3, v5, Laak;->c0:Ljava/util/Iterator;
    :try_end_67df
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67c9 .. :try_end_67df} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67c9 .. :try_end_67df} :catch_6888
    .catchall {:try_start_67c9 .. :try_end_67df} :catchall_2e20

    move/from16 v3, v20

    :try_start_67e1
    iput v3, v5, Laak;->e0:I
    :try_end_67e3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67e1 .. :try_end_67e3} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67e1 .. :try_end_67e3} :catch_6884
    .catchall {:try_start_67e1 .. :try_end_67e3} :catchall_2e20

    move/from16 v20, v3

    move/from16 v3, v17

    :try_start_67e7
    iput-boolean v3, v5, Laak;->i0:Z
    :try_end_67e9
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67e7 .. :try_end_67e9} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67e7 .. :try_end_67e9} :catch_6880
    .catchall {:try_start_67e7 .. :try_end_67e9} :catchall_2e20

    move/from16 v17, v3

    move/from16 v3, v16

    :try_start_67ed
    iput v3, v5, Laak;->f0:I
    :try_end_67ef
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67ed .. :try_end_67ef} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67ed .. :try_end_67ef} :catch_6876
    .catchall {:try_start_67ed .. :try_end_67ef} :catchall_2e20

    move/from16 v16, v3

    move-object/from16 v27, v4

    move-wide/from16 v3, v197

    :try_start_67f5
    iput-wide v3, v5, Laak;->k0:J
    :try_end_67f7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67f5 .. :try_end_67f7} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67f5 .. :try_end_67f7} :catch_6872
    .catchall {:try_start_67f5 .. :try_end_67f7} :catchall_2e20

    move-wide/from16 v35, v3

    const/4 v4, 0x0

    :try_start_67fa
    iput v4, v5, Laak;->g0:I

    move-wide/from16 v3, v195

    iput-wide v3, v5, Laak;->l0:J

    const/16 v3, 0x24

    iput v3, v5, Laak;->m0:I

    invoke-virtual {v1, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_6808
    .catch Ljava/util/concurrent/CancellationException; {:try_start_67fa .. :try_end_6808} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_67fa .. :try_end_6808} :catch_684c
    .catchall {:try_start_67fa .. :try_end_6808} :catchall_2e20

    move-object/from16 v3, v59

    if-ne v2, v3, :cond_680e

    goto/16 :goto_2cea

    :cond_680e
    move-object/from16 v37, v7

    move-object/from16 v41, v10

    move-object/from16 v46, v11

    move-object/from16 v45, v14

    move/from16 v7, v16

    move-object/from16 v4, v27

    move-object/from16 v43, v47

    const/4 v2, 0x0

    move-object/from16 v47, v9

    move/from16 v9, v20

    :goto_6821
    :try_start_6821
    throw v0
    :try_end_6822
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6821 .. :try_end_6822} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_6821 .. :try_end_6822} :catch_6822
    .catchall {:try_start_6821 .. :try_end_6822} :catchall_2e20

    :catch_6822
    move-exception v0

    move-object/from16 v38, v6

    move-object v6, v12

    move-object v12, v13

    move-object/from16 v52, v37

    move-object/from16 v14, v45

    move-object/from16 v11, v46

    move-object/from16 v13, v58

    move/from16 v45, v7

    move/from16 v37, v9

    move/from16 v7, v30

    move-object/from16 v9, v47

    move-wide/from16 v46, v35

    move-object/from16 v36, v48

    move/from16 v48, v2

    move-object v2, v3

    move/from16 v35, v17

    move-object/from16 v17, v41

    move-object/from16 v41, v43

    move-object/from16 v43, v33

    move-object/from16 v33, v4

    :goto_6848
    move-object/from16 v4, v44

    goto/16 :goto_7437

    :catch_684c
    move-exception v0

    :goto_684d
    move-object/from16 v3, v59

    :goto_684f
    move-object v2, v3

    move-object/from16 v38, v6

    move-object/from16 v52, v7

    move-object v6, v12

    move-object v12, v13

    move/from16 v45, v16

    move/from16 v37, v20

    move/from16 v7, v30

    move-object/from16 v43, v33

    move-object/from16 v4, v44

    move-object/from16 v41, v47

    move-object/from16 v13, v58

    move-object/from16 v33, v27

    move-wide/from16 v46, v35

    move-object/from16 v36, v48

    const/16 v48, 0x0

    move/from16 v35, v17

    :goto_686e
    move-object/from16 v17, v10

    goto/16 :goto_7437

    :catch_6872
    move-exception v0

    move-wide/from16 v35, v3

    goto :goto_684d

    :catch_6876
    move-exception v0

    move/from16 v16, v3

    :goto_6879
    move-object/from16 v27, v4

    :goto_687b
    move-object/from16 v3, v59

    move-wide/from16 v35, v197

    goto :goto_684f

    :catch_6880
    move-exception v0

    move/from16 v17, v3

    goto :goto_6879

    :catch_6884
    move-exception v0

    move/from16 v20, v3

    goto :goto_6879

    :catch_6888
    move-exception v0

    goto :goto_6879

    :catch_688a
    move-exception v0

    move-object/from16 v33, v3

    goto :goto_6879

    :catch_688e
    move-exception v0

    move-object/from16 v33, v3

    goto :goto_687b

    :catch_6892
    move-exception v0

    goto :goto_687b

    :catch_6894
    move-exception v0

    goto :goto_687b

    :catch_6896
    move-exception v0

    move-object/from16 v43, v1

    move-object/from16 v41, v2

    move-object/from16 v38, v3

    move-object/from16 v33, v6

    move-object/from16 v37, v7

    move/from16 v36, v27

    move-object/from16 v3, v59

    move-wide/from16 v48, v138

    const/16 v30, 0x1

    move/from16 v27, v17

    move-object/from16 v17, v4

    goto/16 :goto_665f

    :goto_68af
    :try_start_68af
    throw v0
    :try_end_68b0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_68af .. :try_end_68b0} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_68af .. :try_end_68b0} :catch_68b0
    .catchall {:try_start_68af .. :try_end_68b0} :catchall_2e20

    :catch_68b0
    move-exception v0

    move-object v2, v3

    move/from16 v35, v33

    move-object/from16 v52, v37

    move-object/from16 v43, v38

    move/from16 v45, v42

    move-object/from16 v4, v44

    move-object/from16 v41, v47

    move-object/from16 v36, v48

    const/16 v48, 0x0

    move-wide/from16 v46, v6

    move-object v6, v12

    move-object/from16 v33, v13

    move-object/from16 v38, v16

    move-object/from16 v12, v17

    move/from16 v37, v27

    move/from16 v7, v30

    move-object/from16 v13, v58

    goto :goto_686e

    :catch_68d2
    move-exception v0

    :goto_68d3
    move-object/from16 v43, v7

    move-object v3, v13

    :goto_68d6
    const/16 v30, 0x1

    :goto_68d8
    move-object v2, v3

    move-object v1, v6

    move-object/from16 v52, v12

    move/from16 v7, v30

    move/from16 v48, v7

    :goto_68e0
    move-object/from16 v6, v43

    :goto_68e2
    move-object/from16 v13, v58

    move-object v12, v10

    move-object/from16 v43, v35

    move/from16 v35, v38

    move-object/from16 v38, v4

    goto/16 :goto_6848

    :catch_68ed
    move-exception v0

    move/from16 v30, v1

    move-object/from16 v43, v7

    move-object v3, v13

    goto :goto_68d8

    :catch_68f4
    move-exception v0

    move-wide/from16 v46, v1

    goto :goto_68d3

    :catch_68f8
    move-exception v0

    move/from16 v45, v1

    :goto_68fb
    move/from16 v37, v2

    goto :goto_68d3

    :catch_68fe
    move-exception v0

    move/from16 v38, v1

    goto :goto_68fb

    :catch_6902
    move-exception v0

    :goto_6903
    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v3, v13

    move/from16 v38, v48

    goto :goto_68d6

    :catch_690b
    move-exception v0

    move-object/from16 v33, v1

    goto :goto_6903

    :catch_690f
    move-exception v0

    move-object/from16 v35, v1

    goto :goto_6903

    :catch_6913
    move-exception v0

    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v3, v13

    :goto_691b
    move/from16 v38, v48

    move-object/from16 v35, v52

    goto :goto_68d6

    :catch_6920
    move-exception v0

    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v3, v13

    move-object/from16 v12, v35

    goto :goto_691b

    :catch_692b
    move-exception v0

    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v3, v13

    move-object/from16 v12, v35

    move/from16 v38, v48

    move-object/from16 v35, v52

    goto :goto_68d6

    :catch_693a
    move-exception v0

    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move/from16 v30, v12

    move-object v3, v13

    move-object/from16 v12, v35

    move/from16 v38, v48

    move-object/from16 v35, v52

    goto :goto_68d8

    :catch_694b
    move-exception v0

    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v3, v13

    move-object/from16 v12, v35

    move/from16 v38, v48

    move-object/from16 v35, v52

    const/16 v30, 0x1

    move-object v2, v3

    :goto_695c
    move-object v1, v6

    move-object/from16 v52, v12

    move/from16 v7, v30

    move-object/from16 v6, v43

    move/from16 v48, v49

    goto/16 :goto_68e2

    :goto_6967
    move-object/from16 p1, v0

    move-object/from16 v59, v3

    move-object v13, v4

    move-object v4, v6

    move-object v7, v8

    move-object v8, v9

    move-object v9, v11

    move-object v2, v12

    move-object v11, v14

    move-object v12, v15

    move-object/from16 v14, v17

    move-object/from16 v0, v27

    move-object/from16 v1, v33

    move-object/from16 v15, v35

    move/from16 v84, v37

    move/from16 v83, v38

    move-object/from16 v6, v43

    move-object/from16 v40, v44

    move/from16 v86, v45

    move-wide/from16 v81, v46

    move/from16 v85, v49

    move-wide/from16 v37, v52

    move-object/from16 v49, v32

    goto/16 :goto_2b92

    :cond_698f
    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v2, v13

    move-object/from16 v12, v35

    move/from16 v38, v48

    move-object/from16 v35, v52

    move-wide/from16 v52, v54

    const/16 v30, 0x1

    :try_start_69a0
    instance-of v1, v3, Lxhg;

    if-eqz v1, :cond_6b4e

    invoke-virtual/range {v32 .. v32}, Lnlh;->c()Lhhg;

    move-result-object v1

    check-cast v3, Lxhg;

    iget-object v3, v3, Lxhg;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v1, Lhhg;->i:Ljava/util/Set;

    invoke-interface {v7, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_69bd

    move-object/from16 v1, v29

    goto :goto_69c1

    :cond_69bd
    invoke-virtual {v1, v3}, Lhhg;->h(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    :goto_69c1
    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1
    :try_end_69c7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_69a0 .. :try_end_69c7} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_69a0 .. :try_end_69c7} :catch_6b4b
    .catchall {:try_start_69a0 .. :try_end_69c7} :catchall_2e20

    move-object/from16 p1, v1

    move-object/from16 v59, v2

    move-object v13, v4

    move-object v4, v6

    move-object v7, v8

    move-object v8, v9

    move-object v9, v11

    move-object/from16 v2, v17

    move-object/from16 v1, v27

    move-object/from16 v3, v33

    move/from16 v204, v37

    move/from16 v203, v38

    move-object/from16 v6, v43

    move/from16 v206, v45

    move-wide/from16 v201, v46

    move/from16 v205, v49

    move-wide/from16 v199, v52

    move-object v11, v10

    move-object/from16 v10, v35

    :goto_69e7
    :try_start_69e7
    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_6b1a

    invoke-interface/range {p1 .. p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v17, v1

    move-object/from16 v1, v16

    check-cast v1, Long;

    iput-object v4, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v7, v5, Laak;->E:Lixe;

    iput-object v8, v5, Laak;->F:Lpng;

    iput-object v9, v5, Laak;->G:Lexe;

    iput-object v14, v5, Laak;->H:Lhxe;
    :try_end_6a01
    .catch Ljava/util/concurrent/CancellationException; {:try_start_69e7 .. :try_end_6a01} :catch_6b16
    .catch Ljava/lang/Exception; {:try_start_69e7 .. :try_end_6a01} :catch_6b0e
    .catchall {:try_start_69e7 .. :try_end_6a01} :catchall_6b0a

    move-object/from16 v16, v7

    :try_start_6a03
    move-object/from16 v7, v36

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v7, v41

    check-cast v7, Ljava/util/List;

    iput-object v7, v5, Laak;->J:Ljava/util/List;
    :try_end_6a0f
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a03 .. :try_end_6a0f} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a03 .. :try_end_6a0f} :catch_6afc
    .catchall {:try_start_6a03 .. :try_end_6a0f} :catchall_6a8d

    :try_start_6a0f
    iput-object v15, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v6, v5, Laak;->M:Lexe;

    iput-object v11, v5, Laak;->N:Lexe;

    iput-object v13, v5, Laak;->O:Lexe;

    iput-object v12, v5, Laak;->P:Lixe;

    iput-object v10, v5, Laak;->Q:Lixe;

    iput-object v3, v5, Laak;->R:Lcp2;

    const/4 v7, 0x0

    iput-object v7, v5, Laak;->S:Lpe9;

    iput-object v7, v5, Laak;->T:Lexe;

    iput-object v0, v5, Laak;->U:Lcp2;

    move-object/from16 v7, v17

    iput-object v7, v5, Laak;->V:Ljava/lang/Object;
    :try_end_6a2a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a0f .. :try_end_6a2a} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a0f .. :try_end_6a2a} :catch_6af8
    .catchall {:try_start_6a0f .. :try_end_6a2a} :catchall_6a8d

    move-object/from16 v17, v2

    const/4 v2, 0x0

    :try_start_6a2d
    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Y:Ljava/lang/Object;

    move-object/from16 v2, p1

    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;

    move-object/from16 v20, v2

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->b0:Ljava/lang/Object;
    :try_end_6a3e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a2d .. :try_end_6a3e} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a2d .. :try_end_6a3e} :catch_6aec
    .catchall {:try_start_6a2d .. :try_end_6a3e} :catchall_6a8d

    move/from16 v2, v204

    :try_start_6a40
    iput v2, v5, Laak;->e0:I
    :try_end_6a42
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a40 .. :try_end_6a42} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a40 .. :try_end_6a42} :catch_6ae0
    .catchall {:try_start_6a40 .. :try_end_6a42} :catchall_6a8d

    move/from16 v27, v2

    move/from16 v2, v203

    :try_start_6a46
    iput-boolean v2, v5, Laak;->i0:Z
    :try_end_6a48
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a46 .. :try_end_6a48} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a46 .. :try_end_6a48} :catch_6ad2
    .catchall {:try_start_6a46 .. :try_end_6a48} :catchall_6a8d

    move/from16 v33, v2

    move/from16 v2, v206

    :try_start_6a4c
    iput v2, v5, Laak;->f0:I
    :try_end_6a4e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a4c .. :try_end_6a4e} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a4c .. :try_end_6a4e} :catch_6ac8
    .catchall {:try_start_6a4c .. :try_end_6a4e} :catchall_6a8d

    move/from16 v37, v2

    move-object/from16 v35, v3

    move-wide/from16 v2, v201

    :try_start_6a54
    iput-wide v2, v5, Laak;->k0:J
    :try_end_6a56
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a54 .. :try_end_6a56} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a54 .. :try_end_6a56} :catch_6ac0
    .catchall {:try_start_6a54 .. :try_end_6a56} :catchall_6a8d

    move-wide/from16 v42, v2

    move/from16 v2, v205

    :try_start_6a5a
    iput v2, v5, Laak;->g0:I
    :try_end_6a5c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a5a .. :try_end_6a5c} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a5a .. :try_end_6a5c} :catch_6abc
    .catchall {:try_start_6a5a .. :try_end_6a5c} :catchall_6a8d

    move/from16 v38, v2

    move-wide/from16 v2, v199

    :try_start_6a60
    iput-wide v2, v5, Laak;->l0:J

    move-wide/from16 v45, v2

    const/16 v2, 0x26

    iput v2, v5, Laak;->m0:I

    invoke-virtual {v4, v5, v1}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_6a6c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a60 .. :try_end_6a6c} :catch_6ab7
    .catch Ljava/lang/Exception; {:try_start_6a60 .. :try_end_6a6c} :catch_6a92
    .catchall {:try_start_6a60 .. :try_end_6a6c} :catchall_6a8d

    move-object/from16 v2, v59

    if-ne v1, v2, :cond_6a72

    goto/16 :goto_7700

    :cond_6a72
    move-object v1, v7

    move-object/from16 v7, v16

    move/from16 v204, v27

    move/from16 v203, v33

    move-object/from16 v3, v35

    move/from16 v206, v37

    move/from16 v205, v38

    move-wide/from16 v201, v42

    move-wide/from16 v199, v45

    move-object/from16 v45, v17

    :goto_6a85
    move-object/from16 v59, v2

    move-object/from16 p1, v20

    move-object/from16 v2, v45

    goto/16 :goto_69e7

    :catchall_6a8d
    move-exception v0

    :goto_6a8e
    move-object/from16 v1, v16

    goto/16 :goto_772a

    :catch_6a92
    move-exception v0

    :goto_6a93
    move-object/from16 v2, v59

    :goto_6a95
    move-object/from16 v1, v35

    move/from16 v35, v33

    move-object/from16 v33, v1

    move-object v1, v4

    move-object/from16 v52, v12

    move/from16 v7, v30

    move/from16 v45, v37

    move/from16 v48, v38

    move-wide/from16 v46, v42

    move-object/from16 v4, v44

    move-object/from16 v43, v10

    move-object v12, v11

    move-object/from16 v38, v13

    move/from16 v37, v27

    move-object/from16 v13, v58

    move-object v11, v9

    move-object v9, v8

    move-object/from16 v8, v16

    goto/16 :goto_7437

    :catch_6ab7
    move-exception v0

    :goto_6ab8
    move-object/from16 v1, v16

    goto/16 :goto_7729

    :catch_6abc
    move-exception v0

    move/from16 v38, v2

    goto :goto_6a93

    :catch_6ac0
    move-exception v0

    move-wide/from16 v42, v2

    move-object/from16 v2, v59

    :goto_6ac5
    move/from16 v38, v205

    goto :goto_6a95

    :catch_6ac8
    move-exception v0

    move/from16 v37, v2

    move-object/from16 v35, v3

    move-object/from16 v2, v59

    move-wide/from16 v42, v201

    goto :goto_6ac5

    :catch_6ad2
    move-exception v0

    move/from16 v33, v2

    move-object/from16 v35, v3

    move-object/from16 v2, v59

    move-wide/from16 v42, v201

    :goto_6adb
    move/from16 v38, v205

    move/from16 v37, v206

    goto :goto_6a95

    :catch_6ae0
    move-exception v0

    move/from16 v27, v2

    move-object/from16 v35, v3

    move-object/from16 v2, v59

    move-wide/from16 v42, v201

    move/from16 v33, v203

    goto :goto_6adb

    :catch_6aec
    move-exception v0

    :goto_6aed
    move-object/from16 v35, v3

    :goto_6aef
    move-object/from16 v2, v59

    move-wide/from16 v42, v201

    move/from16 v33, v203

    move/from16 v27, v204

    goto :goto_6adb

    :catch_6af8
    move-exception v0

    move-object/from16 v17, v2

    goto :goto_6aed

    :catch_6afc
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v3

    move-object/from16 v2, v59

    move-wide/from16 v42, v201

    move/from16 v33, v203

    move/from16 v27, v204

    goto :goto_6adb

    :catchall_6b0a
    move-exception v0

    move-object/from16 v16, v7

    goto :goto_6a8e

    :catch_6b0e
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v35, v3

    move-object/from16 v16, v7

    goto :goto_6aef

    :catch_6b16
    move-exception v0

    move-object/from16 v16, v7

    goto :goto_6ab8

    :cond_6b1a
    move-object/from16 v17, v2

    move-object/from16 v35, v3

    move-object/from16 v16, v7

    move-wide/from16 v45, v199

    move-wide/from16 v42, v201

    move/from16 v33, v203

    move/from16 v27, v204

    move/from16 v38, v205

    move/from16 v37, v206

    move-object v7, v1

    move-object/from16 p1, v0

    move-object v0, v7

    move-object v2, v12

    move-object v12, v15

    move-object/from16 v7, v16

    move/from16 v84, v27

    move-object/from16 v49, v32

    move/from16 v83, v33

    move-object/from16 v1, v35

    move/from16 v86, v37

    move/from16 v85, v38

    move-wide/from16 v81, v42

    move-object/from16 v40, v44

    move-wide/from16 v37, v45

    move-object v15, v10

    move-object v10, v11

    move-object v11, v14

    goto/16 :goto_5099

    :catch_6b4b
    move-exception v0

    goto/16 :goto_695c

    :cond_6b4e
    :try_start_6b4e
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    :catch_6b54
    move-exception v0

    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v2, v13

    move-object/from16 v12, v35

    move/from16 v38, v48

    move-object/from16 v35, v52

    const/16 v30, 0x1

    goto/16 :goto_695c

    :cond_6b66
    move-object/from16 v17, v1

    move/from16 v37, v2

    move-object/from16 v43, v7

    move-object v2, v13

    move-object/from16 v12, v35

    move/from16 v38, v48

    move-object/from16 v35, v52

    const/16 v30, 0x1

    const-string v0, "unreachable: .Sse only produced on v2 SSE path"

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_6b7d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6b4e .. :try_end_6b7d} :catch_2e51
    .catch Ljava/lang/Exception; {:try_start_6b4e .. :try_end_6b7d} :catch_6b4b
    .catchall {:try_start_6b4e .. :try_end_6b7d} :catchall_2e20

    :catch_6b7d
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v44, v3

    move-object v10, v12

    move-object v12, v13

    move-wide/from16 v56, v25

    move-object/from16 v58, v42

    move-object/from16 v4, v43

    move-object/from16 v32, v49

    move-object/from16 v2, v59

    :goto_6b8e
    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    move-object/from16 v43, v7

    move/from16 v49, v48

    move-object v1, v6

    move-object/from16 v52, v12

    move/from16 v7, v30

    goto/16 :goto_68e0

    :catch_6bab
    move-exception v0

    move-object/from16 v17, v1

    move-object v2, v3

    move-object v10, v12

    move-object v12, v13

    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v4, v43

    move-object/from16 v32, v49

    goto :goto_6b8e

    :catch_6bbc
    move-exception v0

    move-object/from16 v17, v1

    move-object v4, v2

    move-object/from16 v35, v3

    move-object/from16 v43, v7

    move-object v10, v12

    move-object v12, v13

    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v32, v49

    move-object/from16 v2, v59

    move-wide/from16 v46, v89

    move/from16 v38, v91

    move/from16 v37, v92

    move/from16 v49, v93

    move/from16 v45, v94

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    goto/16 :goto_695c

    :catch_6bee
    move-exception v0

    move-object/from16 v17, v1

    move-object/from16 v35, v3

    move-object/from16 v33, v4

    move-object/from16 v43, v7

    move-object v10, v12

    move-object v12, v13

    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v32, v49

    move-wide/from16 v46, v89

    move/from16 v38, v91

    move/from16 v37, v92

    move/from16 v49, v93

    move/from16 v45, v94

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const/16 v31, -0x1

    move-object v4, v2

    move-object/from16 v2, v59

    goto/16 :goto_695c

    :catchall_6c22
    move-exception v0

    :goto_6c23
    move-object/from16 v1, v46

    goto/16 :goto_772a

    :catch_6c27
    move-exception v0

    move-object/from16 v32, v1

    :goto_6c2a
    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    :goto_6c32
    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    move/from16 v1, v37

    move/from16 v37, v35

    move/from16 v35, v45

    move/from16 v45, v48

    move/from16 v48, v1

    move-object v1, v4

    move-object/from16 v17, v14

    move-object/from16 v33, v27

    move-object/from16 v38, v43

    move-object/from16 v4, v44

    move-object/from16 v6, v47

    :goto_6c58
    move-object v14, v11

    move-object/from16 v43, v15

    move-object v11, v9

    move-object v15, v12

    move-object v9, v8

    move-object v12, v10

    move-object/from16 v8, v46

    move-wide/from16 v46, v52

    move-object/from16 v52, v13

    goto/16 :goto_461b

    :catch_6c67
    move-exception v0

    :goto_6c68
    move-object/from16 v1, v46

    goto/16 :goto_7729

    :catch_6c6c
    move-exception v0

    move-object/from16 v32, v1

    move/from16 v37, v2

    goto :goto_6c2a

    :catch_6c72
    move-exception v0

    move-object/from16 v32, v1

    move/from16 v37, v2

    move-wide/from16 v52, v6

    goto :goto_6c2a

    :catch_6c7a
    move-exception v0

    move-object/from16 v32, v1

    move/from16 v48, v2

    move-wide/from16 v52, v6

    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move/from16 v37, v85

    goto :goto_6c32

    :catchall_6c8c
    move-exception v0

    move-object/from16 v46, v7

    goto :goto_6c23

    :catch_6c90
    move-exception v0

    move-object/from16 v32, v1

    move/from16 v48, v2

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v37, v85

    :goto_6ca5
    const/4 v7, 0x1

    const/16 v21, 0x10

    :goto_6ca8
    const/16 v22, 0xe

    :goto_6caa
    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    :goto_6cb6
    move/from16 v1, v37

    move/from16 v37, v35

    move/from16 v35, v45

    move/from16 v45, v48

    move/from16 v48, v1

    move-object v1, v4

    move-object/from16 v17, v14

    move-object/from16 v33, v27

    move-object/from16 v38, v43

    move-object/from16 v4, v44

    goto :goto_6c58

    :catch_6cca
    move-exception v0

    move-object/from16 v46, v7

    goto :goto_6c68

    :catch_6cce
    move-exception v0

    move-object/from16 v32, v1

    move/from16 v45, v2

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    :goto_6ce1
    move/from16 v37, v85

    move/from16 v48, v86

    goto :goto_6ca5

    :catch_6ce6
    move-exception v0

    move-object/from16 v32, v1

    move/from16 v35, v2

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v45, v83

    goto :goto_6ce1

    :catch_6cfc
    move-exception v0

    move-object/from16 v32, v1

    :goto_6cff
    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    :goto_6d05
    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v45, v83

    move/from16 v35, v84

    goto :goto_6ce1

    :catch_6d12
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v27, v2

    goto :goto_6cff

    :catch_6d18
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v43, v2

    goto :goto_6cff

    :catch_6d1e
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v43, v2

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    goto :goto_6d05

    :catch_6d2c
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v43, v2

    :goto_6d31
    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    move-object/from16 v13, v35

    goto :goto_6d05

    :catch_6d3c
    move-exception v0

    move-object/from16 v32, v1

    goto :goto_6d31

    :catch_6d40
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    move-object/from16 v13, v35

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v45, v83

    move/from16 v35, v84

    move/from16 v37, v85

    move/from16 v48, v86

    goto/16 :goto_6c32

    :catch_6d5f
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move/from16 v21, v15

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    move-object/from16 v13, v35

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v45, v83

    move/from16 v35, v84

    move/from16 v37, v85

    move/from16 v48, v86

    const/4 v7, 0x1

    goto/16 :goto_6ca8

    :catch_6d81
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move/from16 v22, v13

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    move-object/from16 v13, v35

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v45, v83

    move/from16 v35, v84

    move/from16 v37, v85

    move/from16 v48, v86

    const/4 v7, 0x1

    const/16 v21, 0x10

    goto/16 :goto_6caa

    :catch_6da5
    move-exception v0

    move-object/from16 v32, v1

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    :goto_6db4
    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v45, v83

    move/from16 v37, v85

    move/from16 v48, v86

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    :goto_6dc5
    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v28, 0x4

    const/16 v31, -0x1

    move/from16 v26, v13

    move-object/from16 v13, v35

    move/from16 v35, v84

    goto/16 :goto_6cb6

    :catch_6dd5
    move-exception v0

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v32, v49

    goto :goto_6db4

    :catch_6de5
    move-exception v0

    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move/from16 v23, v15

    move-wide/from16 v56, v25

    move-object/from16 v15, v33

    move-object/from16 v44, v40

    move-object/from16 v58, v42

    move-object/from16 v32, v49

    move-object/from16 v2, v59

    move-wide/from16 v52, v81

    move/from16 v45, v83

    move/from16 v37, v85

    move/from16 v48, v86

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    goto :goto_6dc5

    :catch_6e06
    move-exception v0

    :goto_6e07
    move-object/from16 v47, v6

    move-object/from16 v46, v7

    move-object/from16 v43, v13

    move-object/from16 v44, v40

    move-object/from16 v32, v49

    move-wide/from16 v52, v81

    move/from16 v45, v83

    move/from16 v35, v84

    move/from16 v37, v85

    move/from16 v48, v86

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v13, v2

    move-object/from16 v2, v59

    goto/16 :goto_6cb6

    :catch_6e33
    move-exception v0

    move-object/from16 v27, v1

    goto :goto_6e07

    :catch_6e37
    move-exception v0

    move-object v1, v7

    :goto_6e39
    move-object/from16 v4, v40

    move-object/from16 v32, v49

    move-object/from16 v13, v58

    :goto_6e3f
    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v17, v14

    move/from16 v35, v43

    move-object/from16 v6, v45

    move/from16 v45, v46

    move-wide/from16 v46, v47

    move-object/from16 v38, v52

    move-object/from16 v52, v53

    move-object v14, v11

    move-object/from16 v43, v15

    move/from16 v48, v37

    move/from16 v37, v42

    move-object v11, v9

    move-object v15, v12

    move-object v9, v8

    move-object v12, v10

    move-object v8, v1

    move-object/from16 v1, v54

    goto/16 :goto_7437

    :catch_6e70
    move-exception v0

    move-object v1, v7

    move-object/from16 v52, v13

    goto :goto_6e39

    :catch_6e75
    move-exception v0

    move-object/from16 v33, v1

    move-object/from16 v45, v3

    move-object/from16 v53, v4

    move-object/from16 v54, v6

    move-object v1, v7

    move-object/from16 v52, v13

    move-object/from16 v4, v40

    move-object/from16 v32, v49

    move-object/from16 v13, v58

    move-object/from16 v2, v59

    move/from16 v37, v75

    move/from16 v46, v76

    move-wide/from16 v47, v77

    move/from16 v43, v79

    move/from16 v42, v80

    goto :goto_6e3f

    :catch_6e94
    move-exception v0

    :goto_6e95
    move-object v1, v2

    move-object/from16 v32, v3

    move-object v3, v13

    move-object v2, v15

    move-object/from16 v4, v40

    const/4 v7, 0x1

    :goto_6e9d
    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    :goto_6ea5
    const/16 v25, 0x12

    :goto_6ea7
    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    :goto_6eaf
    move-object v13, v10

    :goto_6eb0
    move-object/from16 v6, v43

    move-object/from16 v43, v14

    move-object v14, v6

    move-object v8, v1

    move-object/from16 v11, v27

    move-object/from16 v17, v33

    move-object/from16 v9, v35

    move/from16 v35, v38

    move-object/from16 v15, v45

    move-object/from16 v6, v48

    move-object/from16 v33, v52

    move/from16 v48, v69

    move/from16 v45, v70

    move-object/from16 v1, p1

    move-object/from16 v38, v3

    goto/16 :goto_27dc

    :catch_6ece
    move-exception v0

    :goto_6ecf
    move-object v1, v2

    move-object/from16 v32, v3

    move-object v3, v13

    move-object v2, v15

    move-object/from16 v4, v40

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    goto :goto_6eaf

    :catch_6eea
    move-exception v0

    move-object/from16 v52, v1

    goto :goto_6e95

    :catch_6eee
    move-exception v0

    move-object/from16 v52, v1

    move-object v1, v2

    move-object/from16 v32, v3

    move v7, v9

    move-object v3, v13

    move-object v2, v15

    move-object/from16 v4, v40

    goto :goto_6e9d

    :catch_6efa
    move-exception v0

    move-object/from16 v52, v1

    goto :goto_6ecf

    :catch_6efe
    move-exception v0

    move-object/from16 v52, v1

    move-object v1, v2

    move-object/from16 v32, v3

    move-wide/from16 v56, v8

    move-object v3, v13

    move-object v2, v15

    move-object/from16 v4, v40

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    goto :goto_6eaf

    :catch_6f1c
    move-exception v0

    move-object/from16 v52, v1

    move-object v1, v2

    move-object/from16 v32, v3

    move/from16 v24, v9

    move-object v3, v13

    move-object v2, v15

    move-object/from16 v4, v40

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    goto/16 :goto_6ea5

    :catch_6f31
    move-exception v0

    move-object/from16 v52, v1

    move-object v1, v2

    move-object/from16 v32, v3

    move/from16 v25, v11

    move-object v3, v13

    move-object v2, v15

    move-object/from16 v4, v40

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    goto/16 :goto_6ea7

    :catch_6f48
    move-exception v0

    move-object/from16 v32, v3

    :goto_6f4b
    move-object/from16 v45, v10

    move-object/from16 v48, v11

    move-object v3, v13

    move-object/from16 v4, v40

    move-object/from16 v13, v52

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    :goto_6f65
    const-wide/16 v56, 0x0

    move-object/from16 v52, v1

    move-object v1, v2

    move-object v2, v15

    goto/16 :goto_6eb0

    :catch_6f6d
    move-exception v0

    move-object/from16 v32, v3

    move/from16 v31, v8

    move-object/from16 v45, v10

    move-object/from16 v48, v11

    move-object v3, v13

    move-object/from16 v4, v40

    move-object/from16 v13, v52

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    goto :goto_6f65

    :catch_6f8b
    move-exception v0

    move-object/from16 v32, v3

    :goto_6f8e
    move-object/from16 v33, v9

    goto :goto_6f4b

    :catch_6f91
    move-exception v0

    move-object/from16 v32, v3

    move-object/from16 v35, v6

    move-object/from16 v27, v7

    move-object/from16 v43, v8

    goto :goto_6f8e

    :catch_6f9b
    move-exception v0

    move-object/from16 v35, v2

    move-object/from16 v42, v3

    move-object v3, v7

    move-object/from16 v27, v15

    move-object/from16 v4, v40

    move-object/from16 v2, v44

    move-object/from16 v32, v45

    move/from16 v16, v69

    move/from16 v43, v70

    move-wide/from16 v46, v71

    move/from16 v38, v73

    move/from16 v37, v74

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v15, v13

    move-object/from16 v13, v52

    move-object/from16 v17, v9

    move/from16 v48, v16

    move-object/from16 v33, v27

    move-object/from16 v52, v42

    move/from16 v45, v43

    move-object v9, v6

    move-object v6, v11

    move-object/from16 v43, v14

    move-object v11, v3

    move-object v14, v8

    move-object/from16 v8, v35

    move/from16 v35, v38

    :goto_6fdd
    move-object/from16 v38, v15

    goto/16 :goto_2263

    :catchall_6fe1
    move-exception v0

    :goto_6fe2
    move-object/from16 v1, v38

    goto/16 :goto_772a

    :catch_6fe6
    move-exception v0

    move/from16 v27, v2

    :goto_6fe9
    move-object/from16 v37, v4

    move-object v3, v7

    move-object v15, v13

    move-object/from16 v4, v40

    :goto_6fef
    move-object/from16 v32, v45

    move-object/from16 v13, v52

    move-object/from16 v2, v53

    :goto_6ff5
    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    :goto_7002
    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    :goto_7008
    move-object/from16 v17, v9

    move-object/from16 v33, v35

    move-object/from16 v52, v37

    move/from16 v37, v42

    move/from16 v35, v43

    move/from16 v45, v46

    move-wide/from16 v46, v47

    move-object v9, v6

    move-object v6, v11

    move-object/from16 v43, v14

    move/from16 v48, v27

    move-object v11, v3

    move-object v14, v8

    move-object/from16 v8, v38

    goto :goto_6fdd

    :catch_7021
    move-exception v0

    :goto_7022
    move-object/from16 v1, v38

    goto/16 :goto_7729

    :catch_7026
    move-exception v0

    move/from16 v27, v2

    move/from16 v26, v3

    move-object/from16 v37, v4

    move-object v3, v7

    move-object v15, v13

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    move-object/from16 v13, v52

    move-object/from16 v2, v53

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    goto :goto_7002

    :catch_7043
    move-exception v0

    move-wide/from16 v47, v2

    goto :goto_6fe9

    :catchall_7047
    move-exception v0

    move-object/from16 v38, v3

    goto :goto_6fe2

    :catch_704b
    move-exception v0

    move/from16 v46, v2

    :goto_704e
    move-object/from16 v38, v3

    goto :goto_6fe9

    :catch_7051
    move-exception v0

    move-object/from16 v38, v3

    goto :goto_7022

    :catch_7055
    move-exception v0

    move/from16 v43, v2

    goto :goto_704e

    :catch_7059
    move-exception v0

    move/from16 v42, v2

    goto :goto_704e

    :catch_705d
    move-exception v0

    goto :goto_704e

    :catch_705f
    move-exception v0

    move-object/from16 v35, v2

    goto :goto_704e

    :catch_7063
    move-exception v0

    move-object/from16 v38, v3

    move-object/from16 v37, v4

    move-object v3, v7

    move-object v15, v13

    :goto_706a
    move-object/from16 v4, v40

    move-object/from16 v14, v44

    goto :goto_6fef

    :catch_706f
    move-exception v0

    move-object/from16 v38, v3

    move-object/from16 v37, v4

    move-object v3, v7

    move-object v15, v13

    move-object/from16 v4, v40

    move-object/from16 v14, v44

    move-object/from16 v32, v45

    move-object/from16 v13, v52

    move-object/from16 v2, v53

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    goto/16 :goto_7002

    :catch_708f
    move-exception v0

    move-object/from16 v38, v3

    move-object/from16 v37, v4

    move-object v3, v7

    move-object v15, v13

    move/from16 v27, v14

    goto :goto_706a

    :catch_7099
    move-exception v0

    move-object/from16 v38, v3

    move-object/from16 v37, v4

    move-object v3, v7

    move-object v15, v13

    move/from16 v27, v14

    move-object/from16 v4, v40

    move-object/from16 v14, v44

    move-object/from16 v32, v45

    move-object/from16 v13, v52

    goto/16 :goto_6ff5

    :catch_70ac
    move-exception v0

    move-object/from16 v38, v3

    move-object/from16 v37, v4

    move-object v3, v7

    move-object/from16 v35, v15

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    move-object/from16 v2, v53

    move/from16 v27, v63

    move/from16 v46, v64

    move-wide/from16 v47, v65

    move/from16 v43, v67

    move/from16 v42, v68

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v15, v13

    move-object/from16 v13, v52

    goto/16 :goto_7008

    :catch_70dc
    move-exception v0

    move/from16 v28, v4

    move v1, v7

    move-object v2, v15

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    :goto_70f2
    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-wide/from16 v208, v12

    move-object v13, v14

    move-wide/from16 v14, v208

    move-object/from16 v12, v35

    move/from16 v35, v1

    move-object v1, v12

    move-object/from16 v33, v6

    move-object v12, v9

    move-object v6, v11

    move-object/from16 v52, v37

    move-object/from16 v17, v42

    move/from16 v37, v43

    move/from16 v45, v44

    move-object/from16 v11, v46

    move-object/from16 v9, v47

    move-object/from16 v43, v48

    move-wide/from16 v46, v14

    move/from16 v48, v27

    move-object v14, v8

    move-object v15, v10

    goto/16 :goto_203b

    :catch_711a
    move-exception v0

    :goto_711b
    move-object/from16 v41, v4

    move v1, v7

    move-object v2, v15

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    goto :goto_70f2

    :catch_7133
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 v42, v3

    goto :goto_711b

    :catch_7139
    move-exception v0

    move-object/from16 v51, v1

    move-object v1, v4

    move-object v2, v15

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-wide/from16 v208, v12

    move v12, v7

    move-object v13, v14

    const/4 v7, 0x1

    move-wide/from16 v14, v208

    move-object/from16 v33, v6

    move-object v6, v11

    move-object/from16 v52, v37

    move-object/from16 v17, v41

    move/from16 v45, v42

    move/from16 v37, v43

    move-object/from16 v11, v46

    move-object/from16 v43, v48

    move/from16 v48, v12

    move-object/from16 v41, v35

    move-object v12, v9

    move/from16 v35, v27

    move-object/from16 v9, v47

    move-wide/from16 v46, v14

    move-object v14, v8

    move-object v15, v10

    move-object v8, v1

    move-object v1, v3

    goto/16 :goto_7437

    :catch_717b
    move-exception v0

    move-object/from16 v51, v1

    :goto_717e
    move-object v1, v4

    move-object v2, v15

    move-object/from16 v4, v40

    move-object/from16 v32, v45

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    :goto_7196
    move-object/from16 v208, v10

    move-object v10, v7

    const/4 v7, 0x1

    move-wide/from16 v209, v12

    move-object/from16 v12, v208

    move-object v13, v14

    move-wide/from16 v14, v209

    :goto_71a1
    move-object/from16 v17, v48

    move/from16 v48, v37

    move/from16 v37, v43

    move-object/from16 v43, v17

    move-object/from16 v52, p1

    move-object/from16 v17, v41

    move-object/from16 v33, v46

    const/16 v45, 0x0

    :goto_71b1
    move-wide/from16 v46, v14

    move-object/from16 v41, v35

    move/from16 v35, v38

    move-object/from16 v38, v44

    move-object v14, v8

    move-object v15, v12

    move-object v8, v1

    move-object v1, v3

    move-object v12, v9

    move-object v9, v6

    move-object v6, v11

    move-object v11, v10

    goto/16 :goto_7437

    :catch_71c3
    move-exception v0

    move-object/from16 v51, v1

    move/from16 v37, v2

    goto :goto_717e

    :catch_71c9
    move-exception v0

    move-object/from16 v51, v1

    move/from16 v38, v2

    goto :goto_717e

    :catch_71cf
    move-exception v0

    move-object/from16 v51, v1

    move/from16 v43, v2

    goto :goto_717e

    :catch_71d5
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 v46, v2

    goto :goto_717e

    :catch_71db
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 v48, v2

    goto :goto_717e

    :catch_71e1
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 p1, v2

    goto :goto_717e

    :catch_71e7
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 v44, v2

    goto :goto_717e

    :catch_71ed
    move-exception v0

    move-object/from16 v51, v1

    move-object/from16 v41, v2

    goto :goto_717e

    :catch_71f3
    move-exception v0

    move-object/from16 v51, v1

    move-object v1, v4

    move-object/from16 v4, v40

    move-object/from16 v9, v41

    move-object/from16 v32, v45

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v41, v2

    move-object v2, v15

    goto :goto_7196

    :catch_7213
    move-exception v0

    move-object/from16 v51, v1

    move-object v1, v4

    move-object/from16 v4, v40

    move-object/from16 v9, v41

    move-object/from16 v32, v45

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v41, v2

    move-object v2, v15

    goto/16 :goto_7196

    :catch_7234
    move-exception v0

    move-object/from16 v32, v1

    move-object v1, v4

    move-object v9, v12

    move-object/from16 p1, v14

    move-object/from16 v48, v15

    move-object/from16 v4, v40

    move-object/from16 v51, v41

    move-object/from16 v46, v45

    move-wide/from16 v14, v61

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v41, v2

    move-object v12, v10

    move-object/from16 v2, v44

    move-object v10, v7

    move-object/from16 v44, v13

    move-object/from16 v13, v42

    const/4 v7, 0x1

    goto/16 :goto_71a1

    :catch_7264
    move-exception v0

    move-object/from16 v32, v1

    move-object v1, v4

    move-object v9, v12

    move-object/from16 p1, v14

    move-object/from16 v48, v15

    move-object/from16 v4, v40

    move-object/from16 v51, v41

    move-object/from16 v46, v45

    :goto_7273
    move-wide/from16 v14, v61

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v41, v2

    move-object v12, v10

    move-object/from16 v2, v44

    move-object v10, v7

    move-object/from16 v44, v13

    move-object/from16 v13, v42

    const/4 v7, 0x1

    move-object/from16 v17, v48

    move/from16 v48, v37

    move/from16 v37, v43

    move-object/from16 v43, v17

    move-object/from16 v52, p1

    move-object/from16 v17, v41

    move-object/from16 v33, v46

    move/from16 v45, v47

    goto/16 :goto_71b1

    :catch_72a4
    move-exception v0

    move-object/from16 v32, v1

    move-object v1, v4

    move-object v9, v12

    move-object/from16 p1, v14

    move-object/from16 v48, v15

    move-object/from16 v4, v40

    move-object/from16 v51, v41

    move-object/from16 v46, v45

    goto :goto_7273

    :catch_72b4
    move-exception v0

    move-object/from16 v32, v1

    move-object v1, v4

    move-object/from16 v46, v9

    move-object v9, v12

    move-object/from16 p1, v14

    move-object/from16 v48, v15

    move-object/from16 v4, v40

    move-object/from16 v51, v41

    goto :goto_7273

    :catch_72c4
    move-exception v0

    move-object/from16 v16, v7

    move v7, v2

    move-object/from16 v2, v44

    move-object/from16 v44, v10

    move-object/from16 v10, v16

    move-object/from16 v46, v9

    move-object/from16 v16, v14

    move/from16 v17, v36

    move/from16 v47, v37

    move-object/from16 v51, v41

    move-object/from16 v32, v43

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v36, v1

    move-object v1, v4

    move-object/from16 v37, v8

    move-object v14, v13

    move-object/from16 v4, v40

    move-object/from16 v13, v42

    move-wide/from16 v8, v59

    move-object/from16 v33, v11

    move-object v11, v6

    move-object/from16 v6, v33

    move-object/from16 v43, v15

    move-object/from16 v52, v16

    move/from16 v48, v17

    move-object/from16 v41, v35

    move-object/from16 v17, v37

    move/from16 v35, v38

    move-object/from16 v15, v44

    move/from16 v37, v45

    move-object/from16 v33, v46

    move/from16 v45, v47

    move-wide/from16 v46, v8

    move-object/from16 v38, v14

    move-object/from16 v9, v36

    move-object/from16 v36, p1

    move-object v8, v1

    move-object v1, v3

    move-object v14, v10

    goto/16 :goto_7437

    :catch_731e
    move-exception v0

    move-object/from16 v16, v10

    move-object/from16 v17, v13

    move-object/from16 v45, v14

    move-object/from16 v51, v41

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v10, v4

    move-object v14, v7

    move-object/from16 v4, v40

    move v7, v2

    move-object/from16 v2, v44

    :goto_7344
    move-object/from16 v33, v17

    move-object/from16 v41, v35

    move/from16 v35, v37

    move-object/from16 v43, v45

    move-object/from16 v52, v46

    move-wide/from16 v46, v47

    move/from16 v48, v1

    move-object v1, v3

    move-object/from16 v17, v8

    move/from16 v37, v15

    move-object/from16 v15, v16

    move/from16 v45, v36

    move-object/from16 v8, v38

    move-object/from16 v36, p1

    move-object/from16 v38, v11

    move-object v11, v6

    move-object v6, v9

    move-object v9, v10

    goto/16 :goto_7437

    :catch_7366
    move-exception v0

    move-object/from16 v16, v10

    move-object/from16 v17, v13

    move-object/from16 v45, v14

    move-object/from16 v51, v41

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v2, v44

    :goto_7375
    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object v10, v4

    move-object v14, v7

    move-object/from16 v4, v40

    :goto_738b
    const/4 v7, 0x1

    goto :goto_7344

    :catch_738d
    move-exception v0

    move-wide/from16 v47, v1

    move-object/from16 v16, v10

    move-object/from16 v17, v13

    move-object/from16 v45, v14

    move-object/from16 v51, v41

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v2, v44

    :goto_739e
    move/from16 v1, v58

    goto :goto_7375

    :catch_73a1
    move-exception v0

    move/from16 v36, v1

    :goto_73a4
    move-object/from16 v46, v2

    move-object/from16 v16, v10

    move-object/from16 v17, v13

    move-object/from16 v45, v14

    move-object/from16 v51, v41

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v2, v44

    move-wide/from16 v47, v56

    goto :goto_739e

    :catch_73b7
    move-exception v0

    move/from16 v37, v1

    goto :goto_73a4

    :catchall_73bb
    move-exception v0

    move-object/from16 v38, v1

    goto/16 :goto_772a

    :catch_73c0
    move-exception v0

    move-object/from16 v38, v1

    goto :goto_73a4

    :catch_73c4
    move-exception v0

    move-object/from16 v38, v1

    goto/16 :goto_7729

    :catch_73c9
    move-exception v0

    move-object/from16 v46, v2

    move-object/from16 v16, v10

    move-object/from16 v17, v13

    move-object/from16 v45, v14

    move/from16 v15, v38

    move-object/from16 v51, v41

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v2, v44

    move-wide/from16 v47, v56

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v38, v1

    move-object v10, v4

    move-object v14, v7

    move-object/from16 v4, v40

    move/from16 v1, v58

    goto :goto_738b

    :catch_73f9
    move-exception v0

    move-object/from16 v46, v2

    :goto_73fc
    move-object v14, v7

    move-object/from16 v16, v10

    move-object/from16 v17, v13

    move/from16 v15, v38

    move-object/from16 v51, v41

    move-object/from16 v13, v42

    move-object/from16 v32, v43

    move-object/from16 v2, v44

    move-wide/from16 v47, v56

    const/4 v7, 0x1

    const/16 v21, 0x10

    const/16 v22, 0xe

    const/16 v23, 0xf

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v31, -0x1

    const-wide/16 v56, 0x0

    move-object/from16 v38, v1

    move-object v10, v4

    move-object/from16 v4, v40

    move/from16 v1, v58

    goto/16 :goto_7344

    :catch_7429
    move-exception v0

    goto :goto_73fc

    :catchall_742b
    move-exception v0

    move-object/from16 v38, v1

    goto/16 :goto_6fe2

    :catch_7430
    move-exception v0

    goto :goto_73fc

    :catch_7432
    move-exception v0

    move-object/from16 v38, v1

    goto/16 :goto_7022

    :goto_7437
    :try_start_7437
    sget-object v3, Lfta;->J:Lfta;

    sget-object v10, Lmta;->a:Llta;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Llta;->b()Z

    move-result v10

    if-nez v10, :cond_744a

    move-object/from16 p1, v1

    move-object/from16 v44, v4

    goto/16 :goto_74c1

    :cond_744a
    invoke-static {v1}, Lp8;->I(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-static {}, Llta;->a()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v16

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual/range {v16 .. v16}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_745b
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v20

    if-eqz v20, :cond_747f

    move-object/from16 p1, v1

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v20, v1

    check-cast v20, Lmta;

    move-object/from16 v44, v4

    move-object/from16 v4, v20

    check-cast v4, Ls40;

    invoke-virtual {v4, v3, v10}, Ls40;->a(Lfta;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_747a

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_747a
    move-object/from16 v1, p1

    move-object/from16 v4, v44

    goto :goto_745b

    :cond_747f
    move-object/from16 p1, v1

    move-object/from16 v44, v4

    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_74c1

    sget-object v1, Lmta;->a:Llta;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-static {v0}, Loze;->a(Ljava/lang/Class;)Lky9;

    move-result-object v0

    invoke-interface {v0}, Lky9;->f()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Connection error: "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_74af
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_74c1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lmta;

    check-cast v4, Ls40;

    invoke-virtual {v4, v3, v10, v0}, Ls40;->b(Lfta;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_74c0
    .catchall {:try_start_7437 .. :try_end_74c0} :catchall_2e20

    goto :goto_74af

    :cond_74c1
    :goto_74c1
    iget-object v0, v8, Lixe;->E:Ljava/lang/Object;

    check-cast v0, Lmog;

    if-eqz v0, :cond_74ca

    invoke-virtual {v0}, Lmog;->s()V

    :cond_74ca
    move-object/from16 v1, p1

    move-object/from16 v20, v6

    move-object/from16 v0, v17

    move/from16 v7, v35

    move-object/from16 v16, v38

    move-object/from16 v6, v43

    move/from16 v3, v48

    move-object/from16 v207, v52

    move-object/from16 v17, v12

    move-object v4, v14

    move-object v10, v15

    move-object v14, v9

    move-object v15, v11

    move/from16 v12, v45

    goto/16 :goto_3359

    :goto_74e4
    invoke-interface/range {v33 .. v33}, Lvre;->m()Ljava/lang/Object;

    move-result-object v27

    invoke-static/range {v27 .. v27}, Lwp2;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v27

    check-cast v27, Ljava/lang/Long;

    if-eqz v27, :cond_74fc

    invoke-virtual/range {v27 .. v27}, Ljava/lang/Long;->longValue()J

    move-result-wide v42

    move-object/from16 v27, v10

    :goto_74f6
    move-object/from16 v52, v13

    move-object v10, v14

    move-wide/from16 v13, v42

    goto :goto_7505

    :cond_74fc
    move-object/from16 v27, v10

    iget-object v10, v13, Leak;->h:Lov5;

    invoke-interface {v10}, Lov5;->c()J

    move-result-wide v42

    goto :goto_74f6

    :goto_7505
    iget-object v6, v6, Lixe;->E:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Long;

    if-eqz v6, :cond_7517

    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    move-result-wide v42

    sub-long v42, v13, v42

    cmp-long v6, v42, v18

    if-lez v6, :cond_7517

    const/4 v6, 0x1

    goto :goto_7518

    :cond_7517
    const/4 v6, 0x0

    :goto_7518
    move-object/from16 p1, v10

    if-eqz v6, :cond_7521

    const/4 v10, 0x0

    :goto_751d
    move-object/from16 v33, v4

    const/4 v4, 0x5

    goto :goto_7524

    :cond_7521
    move/from16 v10, v37

    goto :goto_751d

    :goto_7524
    if-lt v10, v4, :cond_75ef

    new-instance v0, Lhng;

    new-instance v4, Lcz4;

    new-instance v15, Ljava/lang/Exception;

    move-object/from16 v53, v2

    const-string v2, "Max reconnection attempts (5) exceeded"

    invoke-direct {v15, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-direct {v4, v15}, Lcz4;-><init>(Ljava/lang/Exception;)V

    invoke-direct {v0, v4}, Lhng;-><init>(Lez4;)V

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v11, v5, Laak;->E:Lixe;

    const/4 v2, 0x0

    iput-object v2, v5, Laak;->F:Lpng;

    iput-object v2, v5, Laak;->G:Lexe;

    iput-object v2, v5, Laak;->H:Lhxe;

    iput-object v2, v5, Laak;->I:Ljava/util/List;

    iput-object v2, v5, Laak;->J:Ljava/util/List;

    iput-object v2, v5, Laak;->K:Lixe;

    iput-object v2, v5, Laak;->L:Lixe;

    iput-object v2, v5, Laak;->M:Lexe;

    iput-object v2, v5, Laak;->N:Lexe;

    iput-object v2, v5, Laak;->O:Lexe;

    iput-object v2, v5, Laak;->P:Lixe;

    iput-object v2, v5, Laak;->Q:Lixe;

    iput-object v2, v5, Laak;->R:Lcp2;

    iput-object v2, v5, Laak;->S:Lpe9;

    iput-object v2, v5, Laak;->T:Lexe;

    iput-object v2, v5, Laak;->U:Lcp2;

    iput-object v2, v5, Laak;->V:Ljava/lang/Object;

    iput-object v2, v5, Laak;->W:Long;

    iput-object v2, v5, Laak;->X:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v2, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v2, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v2, v5, Laak;->c0:Ljava/util/Iterator;

    iput-object v2, v5, Laak;->d0:Long;

    iput v10, v5, Laak;->e0:I

    iput-boolean v7, v5, Laak;->i0:Z

    iput v12, v5, Laak;->f0:I

    iput-wide v8, v5, Laak;->k0:J

    iput v3, v5, Laak;->g0:I

    iput-wide v13, v5, Laak;->l0:J

    iput v6, v5, Laak;->h0:I

    const/16 v2, 0x27

    iput v2, v5, Laak;->m0:I

    invoke-virtual {v1, v5, v0}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v2, v53

    if-ne v0, v2, :cond_758c

    goto/16 :goto_7700

    :cond_758c
    move v0, v3

    move v6, v7

    move-wide v3, v8

    move v7, v10

    move-object v8, v11

    :goto_7591
    move v9, v7

    move-wide/from16 v208, v3

    move v4, v0

    move-object v0, v1

    move-object v1, v8

    move v3, v12

    move v8, v6

    move-wide/from16 v6, v208

    :goto_759b
    new-instance v10, Lbre;

    const/4 v11, 0x1

    invoke-direct {v10, v11, v1}, Lbre;-><init>(ILixe;)V

    const/4 v1, 0x0

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->E:Lixe;

    iput-object v1, v5, Laak;->F:Lpng;

    iput-object v1, v5, Laak;->G:Lexe;

    iput-object v1, v5, Laak;->H:Lhxe;

    iput-object v1, v5, Laak;->I:Ljava/util/List;

    iput-object v1, v5, Laak;->J:Ljava/util/List;

    iput-object v1, v5, Laak;->K:Lixe;

    iput-object v1, v5, Laak;->L:Lixe;

    iput-object v1, v5, Laak;->M:Lexe;

    iput-object v1, v5, Laak;->N:Lexe;

    iput-object v1, v5, Laak;->O:Lexe;

    iput-object v1, v5, Laak;->P:Lixe;

    iput-object v1, v5, Laak;->Q:Lixe;

    iput-object v1, v5, Laak;->R:Lcp2;

    iput-object v1, v5, Laak;->S:Lpe9;

    iput-object v1, v5, Laak;->T:Lexe;

    iput-object v1, v5, Laak;->U:Lcp2;

    iput-object v1, v5, Laak;->V:Ljava/lang/Object;

    iput-object v1, v5, Laak;->W:Long;

    iput-object v1, v5, Laak;->X:Ljava/lang/Object;

    iput-object v1, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v1, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v1, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v1, v5, Laak;->c0:Ljava/util/Iterator;

    iput v9, v5, Laak;->e0:I

    iput-boolean v8, v5, Laak;->i0:Z

    iput v3, v5, Laak;->f0:I

    iput-wide v6, v5, Laak;->k0:J

    iput v4, v5, Laak;->g0:I

    const/16 v1, 0x2a

    iput v1, v5, Laak;->m0:I

    invoke-static {v0, v10, v5}, Lezg;->M(Lo1e;La98;La75;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v2, :cond_75ec

    goto/16 :goto_7700

    :cond_75ec
    :goto_75ec
    sget-object v0, Lz2j;->a:Lz2j;

    return-object v0

    :cond_75ef
    const/16 v30, 0x1

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v53, v2

    new-instance v2, Lhng;

    move/from16 v35, v6

    new-instance v6, Ldz4;

    invoke-direct {v6, v10, v4}, Ldz4;-><init>(II)V

    invoke-direct {v2, v6}, Lhng;-><init>(Lez4;)V

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v11, v5, Laak;->E:Lixe;

    move-object/from16 v6, p1

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v15, v5, Laak;->G:Lexe;

    move-object/from16 v4, v33

    iput-object v4, v5, Laak;->H:Lhxe;

    move-object/from16 v4, v36

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v4, v41

    check-cast v4, Ljava/util/List;

    iput-object v4, v5, Laak;->J:Ljava/util/List;

    move-object/from16 v4, v27

    iput-object v4, v5, Laak;->K:Lixe;

    iput-object v0, v5, Laak;->L:Lixe;

    move-object/from16 v4, v20

    iput-object v4, v5, Laak;->M:Lexe;

    move-object/from16 v4, v17

    iput-object v4, v5, Laak;->N:Lexe;

    move-object/from16 v4, v16

    iput-object v4, v5, Laak;->O:Lexe;

    move-object/from16 v4, v207

    iput-object v4, v5, Laak;->P:Lixe;

    move-object/from16 v37, v4

    const/4 v4, 0x0

    iput-object v4, v5, Laak;->Q:Lixe;

    iput-object v4, v5, Laak;->R:Lcp2;

    iput-object v4, v5, Laak;->S:Lpe9;

    iput-object v4, v5, Laak;->T:Lexe;

    iput-object v4, v5, Laak;->U:Lcp2;

    iput-object v4, v5, Laak;->V:Ljava/lang/Object;

    iput-object v4, v5, Laak;->W:Long;

    iput-object v4, v5, Laak;->X:Ljava/lang/Object;

    iput-object v4, v5, Laak;->Y:Ljava/lang/Object;

    iput-object v4, v5, Laak;->Z:Ljava/lang/Object;

    iput-object v4, v5, Laak;->a0:Ljava/lang/Object;

    iput-object v4, v5, Laak;->b0:Ljava/lang/Object;

    iput-object v4, v5, Laak;->c0:Ljava/util/Iterator;

    iput-object v4, v5, Laak;->d0:Long;

    iput v10, v5, Laak;->e0:I

    iput-boolean v7, v5, Laak;->i0:Z

    iput v12, v5, Laak;->f0:I

    iput-wide v8, v5, Laak;->k0:J

    iput v3, v5, Laak;->g0:I

    iput-wide v13, v5, Laak;->l0:J

    move/from16 v4, v35

    iput v4, v5, Laak;->h0:I

    move/from16 v35, v3

    const/16 v3, 0x28

    iput v3, v5, Laak;->m0:I

    invoke-virtual {v1, v5, v2}, Lo1e;->c(La75;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v3, v53

    if-ne v2, v3, :cond_7670

    goto/16 :goto_2cea

    :cond_7670
    move-object/from16 v53, v3

    move-object/from16 v3, v16

    move-object/from16 v2, v33

    move/from16 v208, v7

    move-object v7, v0

    move v0, v4

    move-object/from16 v4, v27

    move/from16 v209, v12

    move/from16 v12, v208

    move-wide/from16 v210, v13

    move v14, v10

    move/from16 v13, v209

    move-object/from16 v10, v37

    move-wide/from16 v37, v8

    move-object/from16 v9, v17

    move-object/from16 v8, v20

    move/from16 v20, v35

    move-wide/from16 v16, v210

    :goto_7691
    sget-object v27, Lrig;->y:Ljava/util/Set;

    move/from16 v27, v12

    move/from16 v33, v13

    invoke-static {v14}, Laok;->c(I)J

    move-result-wide v12

    long-to-double v12, v12

    move-wide/from16 v42, v12

    invoke-static/range {v52 .. v52}, Leak;->g(Leak;)Lhme;

    move-result-object v12

    move/from16 p1, v14

    const-wide/high16 v13, 0x3ff0000000000000L  # 1.0

    invoke-virtual {v12, v13, v14}, Lhme;->d(D)D

    move-result-wide v12

    mul-double v12, v12, v42

    double-to-long v12, v12

    iput-object v1, v5, Laak;->n0:Ljava/lang/Object;

    iput-object v11, v5, Laak;->E:Lixe;

    iput-object v6, v5, Laak;->F:Lpng;

    iput-object v15, v5, Laak;->G:Lexe;

    iput-object v2, v5, Laak;->H:Lhxe;

    move-object/from16 v14, v36

    check-cast v14, Ljava/util/List;

    iput-object v14, v5, Laak;->I:Ljava/util/List;

    move-object/from16 v14, v41

    check-cast v14, Ljava/util/List;

    iput-object v14, v5, Laak;->J:Ljava/util/List;

    iput-object v4, v5, Laak;->K:Lixe;

    iput-object v7, v5, Laak;->L:Lixe;

    iput-object v8, v5, Laak;->M:Lexe;

    iput-object v9, v5, Laak;->N:Lexe;

    iput-object v3, v5, Laak;->O:Lexe;

    iput-object v10, v5, Laak;->P:Lixe;

    const/4 v14, 0x0

    iput-object v14, v5, Laak;->Q:Lixe;

    iput-object v14, v5, Laak;->R:Lcp2;

    move/from16 v14, p1

    iput v14, v5, Laak;->e0:I

    move-object/from16 v34, v1

    move/from16 v1, v27

    iput-boolean v1, v5, Laak;->i0:Z

    move/from16 v1, v33

    iput v1, v5, Laak;->f0:I

    move/from16 v35, v1

    move-object/from16 v33, v2

    move-wide/from16 v1, v37

    iput-wide v1, v5, Laak;->k0:J

    move/from16 v1, v20

    iput v1, v5, Laak;->g0:I

    move-wide/from16 v1, v16

    iput-wide v1, v5, Laak;->l0:J

    iput v0, v5, Laak;->h0:I

    const/16 v0, 0x29

    iput v0, v5, Laak;->m0:I

    invoke-static {v12, v13, v5}, Lw10;->z(JLa75;)Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v2, v53

    if-ne v0, v2, :cond_7701

    :goto_7700
    return-object v2

    :cond_7701
    move-object v12, v9

    move-object v13, v10

    move-object v1, v11

    move v0, v14

    move/from16 v58, v20

    move/from16 v14, v27

    move-object v11, v3

    move-object v10, v4

    move-object v9, v8

    move-object/from16 v3, v34

    move/from16 v4, v35

    move-object/from16 v35, v41

    move-object v8, v7

    move-object/from16 v7, v33

    :goto_7715
    move-object/from16 v43, v32

    move-object/from16 p1, v36

    move-wide/from16 v56, v37

    move-object/from16 v40, v44

    move-object/from16 v41, v51

    move-object/from16 v42, v52

    move-object/from16 v44, v2

    move v2, v4

    move-object v4, v6

    move-object v6, v15

    move v15, v0

    goto/16 :goto_1d90

    :goto_7729
    :try_start_7729
    throw v0
    :try_end_772a
    .catchall {:try_start_7729 .. :try_end_772a} :catchall_218

    :goto_772a
    iget-object v1, v1, Lixe;->E:Ljava/lang/Object;

    check-cast v1, Lmog;

    if-eqz v1, :cond_7733

    invoke-virtual {v1}, Lmog;->s()V

    :cond_7733
    throw v0

    :goto_7734
    move-object/from16 v53, v2

    move-object v1, v4

    const/16 v24, 0x13

    const/16 v25, 0x12

    const/16 v26, 0x7

    const/16 v28, 0x4

    const/16 v30, 0x1

    const-wide/16 v56, 0x0

    goto/16 :goto_1d5b

    nop

    :pswitch_data_7746
    .packed-switch 0x0
        :pswitch_1cfd  #00000000
        :pswitch_1c7a  #00000001
        :pswitch_1c03  #00000002
        :pswitch_1b8c  #00000003
        :pswitch_1b19  #00000004
        :pswitch_1a9b  #00000005
        :pswitch_19be  #00000006
        :pswitch_18f4  #00000007
        :pswitch_1880  #00000008
        :pswitch_17e1  #00000009
        :pswitch_1748  #0000000a
        :pswitch_16b3  #0000000b
        :pswitch_1652  #0000000c
        :pswitch_15bf  #0000000d
        :pswitch_152b  #0000000e
        :pswitch_1496  #0000000f
        :pswitch_13f8  #00000010
        :pswitch_1361  #00000011
        :pswitch_12b1  #00000012
        :pswitch_1213  #00000013
        :pswitch_1158  #00000014
        :pswitch_10aa  #00000015
        :pswitch_fa2  #00000016
        :pswitch_e92  #00000017
        :pswitch_de1  #00000018
        :pswitch_d25  #00000019
        :pswitch_c1d  #0000001a
        :pswitch_b69  #0000001b
        :pswitch_ac5  #0000001c
        :pswitch_987  #0000001d
        :pswitch_8cd  #0000001e
        :pswitch_81a  #0000001f
        :pswitch_765  #00000020
        :pswitch_6ae  #00000021
        :pswitch_56f  #00000022
        :pswitch_432  #00000023
        :pswitch_356  #00000024
        :pswitch_268  #00000025
        :pswitch_160  #00000026
        :pswitch_141  #00000027
        :pswitch_b1  #00000028
        :pswitch_31  #00000029
        :pswitch_23  #0000002a
    .end packed-switch
.end method
