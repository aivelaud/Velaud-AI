.class public final La1h;
.super Lenl;
.source "SourceFile"


# virtual methods
.method public final k(Ljava/lang/String;)Ljava/lang/String;
    .registers 19

    move-object/from16 v0, p1

    if-eqz v0, :cond_e2

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_c

    goto/16 :goto_e2

    :cond_c
    sget-object v1, Llx4;->O1:Llx4;

    iget-boolean v1, v1, Llx4;->I:Z

    const/4 v2, 0x0

    const/4 v3, 0x0

    move v4, v2

    move v5, v4

    :cond_14
    :goto_14
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v6

    if-ge v4, v6, :cond_d3

    const/16 v6, 0x2f

    invoke-virtual {v0, v6, v4}, Ljava/lang/String;->indexOf(II)I

    move-result v7

    const/4 v8, -0x1

    if-eq v7, v4, :cond_c8

    if-ne v7, v8, :cond_2a

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v9

    goto :goto_2b

    :cond_2a
    move v9, v7

    :goto_2b
    sub-int v10, v9, v4

    const/16 v11, 0x30

    const/16 v12, 0x39

    const/16 v13, 0x3f

    const/4 v14, 0x3

    const/4 v15, 0x1

    if-gt v10, v14, :cond_6f

    if-le v10, v15, :cond_6f

    invoke-virtual {v0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v10

    or-int/lit8 v10, v10, 0x20

    const/16 v14, 0x76

    if-ne v10, v14, :cond_6f

    add-int/lit8 v10, v4, 0x1

    move v14, v15

    :goto_46
    if-ge v10, v9, :cond_58

    invoke-virtual {v0, v10}, Ljava/lang/String;->charAt(I)C

    move-result v15

    if-gt v15, v12, :cond_52

    if-lt v15, v11, :cond_52

    const/4 v15, 0x1

    goto :goto_53

    :cond_52
    move v15, v2

    :goto_53
    and-int/2addr v14, v15

    add-int/lit8 v10, v10, 0x1

    const/4 v15, 0x1

    goto :goto_46

    :cond_58
    if-eqz v14, :cond_61

    if-eqz v3, :cond_c4

    invoke-virtual {v3, v0, v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    goto/16 :goto_c4

    :cond_61
    if-nez v3, :cond_6b

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0, v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    :cond_6b
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_c4

    :cond_6f
    if-eqz v3, :cond_76

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v10

    goto :goto_77

    :cond_76
    move v10, v4

    :goto_77
    move v14, v2

    :goto_78
    if-ge v4, v9, :cond_b2

    if-nez v14, :cond_b2

    invoke-virtual {v0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v14

    add-int/lit8 v5, v5, -0x1

    if-gez v5, :cond_8a

    if-gt v14, v12, :cond_8a

    if-lt v14, v11, :cond_8a

    const/4 v15, 0x1

    goto :goto_8b

    :cond_8a
    move v15, v2

    :goto_8b
    if-nez v15, :cond_ae

    invoke-static {v14}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v16

    if-eqz v16, :cond_a9

    if-nez v3, :cond_9d

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0, v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    :cond_9d
    if-eqz v1, :cond_ae

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v16

    if-lez v16, :cond_ae

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_ae

    :cond_a9
    if-eqz v3, :cond_ae

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_ae
    :goto_ae
    add-int/lit8 v4, v4, 0x1

    move v14, v15

    goto :goto_78

    :cond_b2
    if-eqz v14, :cond_c4

    if-nez v3, :cond_be

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0, v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    :cond_be
    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->setLength(I)V

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_c4
    :goto_c4
    add-int/lit8 v9, v9, 0x1

    move v4, v9

    goto :goto_ca

    :cond_c8
    add-int/lit8 v4, v4, 0x1

    :goto_ca
    if-eq v7, v8, :cond_14

    if-eqz v3, :cond_14

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto/16 :goto_14

    :cond_d3
    if-nez v3, :cond_d6

    return-object v0

    :cond_d6
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-nez v0, :cond_dd

    goto :goto_e2

    :cond_dd
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_e2
    :goto_e2
    const-string v0, "/"

    return-object v0
.end method
