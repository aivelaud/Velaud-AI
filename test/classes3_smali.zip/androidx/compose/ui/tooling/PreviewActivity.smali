.class public final Landroidx/compose/ui/tooling/PreviewActivity;
.super Lrr4;
.source "SourceFile"


# static fields
.field public static final synthetic Z:I


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lrr4;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCreate(Landroid/os/Bundle;)V
    .registers 10

    invoke-super {p0, p1}, Lrr4;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    iget p1, p1, Landroid/content/pm/ApplicationInfo;->flags:I

    and-int/lit8 p1, p1, 0x2

    if-nez p1, :cond_11

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_11
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    if-eqz p1, :cond_c7

    const-string v0, "composable"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_c7

    const/16 v0, 0x2e

    invoke-static {v0, p1, p1}, Lcnh;->X0(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, p1, p1}, Lcnh;->S0(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "parameterProviderClassName"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_b6

    const/4 v4, 0x0

    :try_start_38
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0
    :try_end_3c
    .catch Ljava/lang/ClassNotFoundException; {:try_start_38 .. :try_end_3c} :catch_3d

    goto :goto_57

    :catch_3d
    move-exception v5

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "Unable to find PreviewProvider \'"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x27

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v6, "PreviewLogger"

    invoke-static {v6, v0, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object v0, v4

    :goto_57
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v5

    const-string v6, "parameterProviderIndex"

    const/4 v7, -0x1

    invoke-virtual {v5, v6, v7}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    if-eqz v0, :cond_a1

    :try_start_63
    invoke-virtual {v0}, Ljava/lang/Class;->getConstructors()[Ljava/lang/reflect/Constructor;

    move-result-object p0

    array-length p1, p0

    move v0, v2

    move-object v1, v4

    :goto_6a
    if-ge v2, p1, :cond_7e

    aget-object v5, p0, v2

    invoke-virtual {v5}, Ljava/lang/reflect/Constructor;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v6

    array-length v6, v6

    if-nez v6, :cond_7b

    if-eqz v0, :cond_79

    :goto_77
    move-object v1, v4

    goto :goto_81

    :cond_79
    move v0, v3

    move-object v1, v5

    :cond_7b
    add-int/lit8 v2, v2, 0x1

    goto :goto_6a

    :cond_7e
    if-nez v0, :cond_81

    goto :goto_77

    :cond_81
    :goto_81
    if-eqz v1, :cond_93

    invoke-virtual {v1, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v1, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Ljava/lang/ClassCastException;

    invoke-direct {p0}, Ljava/lang/ClassCastException;-><init>()V

    throw p0

    :cond_93
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "PreviewParameterProvider constructor can not have parameters"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_9b
    .catch Lkotlin/jvm/KotlinReflectionNotSupportedError; {:try_start_63 .. :try_end_9b} :catch_9b

    :catch_9b
    const-string p0, "Deploying Compose Previews with PreviewParameterProvider arguments requires adding a dependency to the kotlin-reflect library.\nConsider adding \'debugImplementation \"org.jetbrains.kotlin:kotlin-reflect:$kotlin_version\"\' to the module\'s build.gradle."

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void

    :cond_a1
    new-array v0, v2, [Ljava/lang/Object;

    new-instance v2, Laxa;

    const/16 v4, 0xd

    invoke-direct {v2, v4, v1, p1, v0}, Laxa;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance p1, Ljs4;

    const v0, -0x7155c95a

    invoke-direct {p1, v0, v3, v2}, Ljs4;-><init>(IZLr98;)V

    invoke-static {p0, p1}, Lsr4;->a(Lrr4;Ljs4;)V

    return-void

    :cond_b6
    new-instance v0, Lme4;

    const/4 v4, 0x6

    invoke-direct {v0, v1, p1, v4, v2}, Lme4;-><init>(Ljava/lang/String;Ljava/lang/String;IB)V

    new-instance p1, Ljs4;

    const v1, -0x321af304

    invoke-direct {p1, v1, v3, v0}, Ljs4;-><init>(IZLr98;)V

    invoke-static {p0, p1}, Lsr4;->a(Lrr4;Ljs4;)V

    :cond_c7
    return-void
.end method
