.class public final Layd;
.super Lc75;
.source "SourceFile"


# instance fields
.field public E:Lcom/anthropic/claude/api/chat/MessageBlobFile;

.field public synthetic F:Ljava/lang/Object;

.field public final synthetic G:Lbyd;

.field public H:I


# direct methods
.method public constructor <init>(Lbyd;Lc75;)V
    .registers 3

    iput-object p1, p0, Layd;->G:Lbyd;

    invoke-direct {p0, p2}, Lc75;-><init>(La75;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Layd;->F:Ljava/lang/Object;

    iget p1, p0, Layd;->H:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Layd;->H:I

    iget-object p1, p0, Layd;->G:Lbyd;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, v0, p0}, Lbyd;->b(Lht7;Lcom/anthropic/claude/api/chat/MessageBlobFile;Lc75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
