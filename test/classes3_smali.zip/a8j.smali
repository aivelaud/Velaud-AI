.class public final enum La8j;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum E:La8j;

.field public static final enum F:La8j;

.field public static final synthetic G:[La8j;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, La8j;

    const-string v1, "SUCCESS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, La8j;->E:La8j;

    new-instance v1, La8j;

    const-string v2, "END_OF_BODY"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, La8j;->F:La8j;

    filled-new-array {v0, v1}, [La8j;

    move-result-object v0

    sput-object v0, La8j;->G:[La8j;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)La8j;
    .registers 2

    const-class v0, La8j;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La8j;

    return-object p0
.end method

.method public static values()[La8j;
    .registers 1

    sget-object v0, La8j;->G:[La8j;

    invoke-virtual {v0}, [La8j;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La8j;

    return-object v0
.end method
