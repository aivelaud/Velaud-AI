.class public final Lb10;
.super Ln5a;
.source "SourceFile"

# interfaces
.implements Lc98;


# instance fields
.field public final synthetic F:I

.field public final synthetic G:Lixe;


# direct methods
.method public synthetic constructor <init>(ILixe;)V
    .registers 3

    iput p1, p0, Lb10;->F:I

    iput-object p2, p0, Lb10;->G:Lixe;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Ln5a;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iget v0, p0, Lb10;->F:I

    iget-object p0, p0, Lb10;->G:Lixe;

    packed-switch v0, :pswitch_data_38

    check-cast p1, Lhui;

    move-object v0, p1

    check-cast v0, Ls7c;

    iget-object v0, v0, Ls7c;->E:Ls7c;

    iget-boolean v0, v0, Ls7c;->R:Z

    if-eqz v0, :cond_16

    iput-object p1, p0, Lixe;->E:Ljava/lang/Object;

    const/4 p0, 0x0

    goto :goto_17

    :cond_16
    const/4 p0, 0x1

    :goto_17
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_1c  #0x1
    check-cast p1, Lj19;

    iget-object v0, p0, Lixe;->E:Ljava/lang/Object;

    if-nez v0, :cond_29

    iget-boolean v1, p1, Lj19;->U:Z

    if-eqz v1, :cond_29

    iput-object p1, p0, Lixe;->E:Ljava/lang/Object;

    goto :goto_2e

    :cond_29
    if-eqz v0, :cond_2e

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_2e
    :goto_2e
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p0

    :pswitch_31  #0x0
    check-cast p1, Lm38;

    iput-object p1, p0, Lixe;->E:Ljava/lang/Object;

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p0

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_1c  #00000001
    .end packed-switch
.end method
