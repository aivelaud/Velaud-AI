.class public final synthetic La4b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lf4b;


# direct methods
.method public synthetic constructor <init>(Lf4b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La4b;->a:Lf4b;

    return-void
.end method
