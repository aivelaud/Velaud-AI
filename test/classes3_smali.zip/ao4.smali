.class public final Lao4;
.super Lc75;
.source "SourceFile"


# instance fields
.field public E:Lbo4;

.field public F:Licc;

.field public synthetic G:Ljava/lang/Object;

.field public final synthetic H:Lbo4;

.field public I:I


# direct methods
.method public constructor <init>(Lbo4;Lc75;)V
    .registers 3

    iput-object p1, p0, Lao4;->H:Lbo4;

    invoke-direct {p0, p2}, Lc75;-><init>(La75;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iput-object p1, p0, Lao4;->G:Ljava/lang/Object;

    iget p1, p0, Lao4;->I:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lao4;->I:I

    const/4 p1, 0x0

    const/4 v0, 0x0

    iget-object v1, p0, Lao4;->H:Lbo4;

    invoke-static {v1, p1, v0, p0}, Lbo4;->k(Lbo4;Licc;FLc75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
