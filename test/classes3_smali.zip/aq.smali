.class public final Laq;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ldq;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laq;->a:Ljava/lang/String;

    iput-object p2, p0, Laq;->b:Ljava/lang/String;

    iput-boolean p3, p0, Laq;->c:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Laq;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Laq;

    iget-object v1, p0, Laq;->a:Ljava/lang/String;

    iget-object v3, p1, Laq;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p1, Laq;->b:Ljava/lang/String;

    iget-object v3, p0, Laq;->b:Ljava/lang/String;

    if-nez v3, :cond_23

    if-nez v1, :cond_21

    move v1, v0

    goto :goto_2a

    :cond_21
    :goto_21
    move v1, v2

    goto :goto_2a

    :cond_23
    if-nez v1, :cond_26

    goto :goto_21

    :cond_26
    invoke-static {v3, v1}, Lcom/anthropic/claude/types/strings/SessionId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    :goto_2a
    if-nez v1, :cond_2d

    return v2

    :cond_2d
    iget-boolean p0, p0, Laq;->c:Z

    iget-boolean p1, p1, Laq;->c:Z

    if-eq p0, p1, :cond_34

    return v2

    :cond_34
    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Laq;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Laq;->b:Ljava/lang/String;

    if-nez v1, :cond_e

    const/4 v1, 0x0

    goto :goto_12

    :cond_e
    invoke-static {v1}, Lcom/anthropic/claude/types/strings/SessionId;->hashCode-impl(Ljava/lang/String;)I

    move-result v1

    :goto_12
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean p0, p0, Laq;->c:Z

    invoke-static {p0}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    iget-object v0, p0, Laq;->b:Ljava/lang/String;

    if-nez v0, :cond_7

    const-string v0, "null"

    goto :goto_b

    :cond_7
    invoke-static {v0}, Lcom/anthropic/claude/types/strings/SessionId;->toString-impl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_b
    const-string v1, ", sessionId="

    const-string v2, ", isError="

    const-string v3, "TaskSessionResolved(toolUseId="

    iget-object v4, p0, Laq;->a:Ljava/lang/String;

    invoke-static {v3, v4, v1, v0, v2}, Lwsg;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    iget-boolean p0, p0, Laq;->c:Z

    invoke-static {v0, p0, v1}, Lb40;->p(Ljava/lang/StringBuilder;ZLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
