.class public final Lai;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lai;->a:I

    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method public final initialValue()Ljava/lang/Object;
    .registers 3

    iget p0, p0, Lai;->a:I

    const/4 v0, 0x0

    packed-switch p0, :pswitch_data_a0

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object p0

    :pswitch_9  #0xb
    const/4 p0, 0x4

    new-array p0, p0, [F

    return-object p0

    :pswitch_d  #0xa
    new-instance p0, Landroid/graphics/Path;

    invoke-direct {p0}, Landroid/graphics/Path;-><init>()V

    return-object p0

    :pswitch_13  #0x9
    new-instance p0, Landroid/graphics/Path;

    invoke-direct {p0}, Landroid/graphics/Path;-><init>()V

    return-object p0

    :pswitch_19  #0x8
    new-instance p0, Landroid/graphics/PathMeasure;

    invoke-direct {p0}, Landroid/graphics/PathMeasure;-><init>()V

    return-object p0

    :pswitch_1f  #0x7
    new-instance p0, Ljava/security/SecureRandom;

    invoke-direct {p0}, Ljava/security/SecureRandom;-><init>()V

    invoke-virtual {p0}, Ljava/util/Random;->nextLong()J

    return-object p0

    :pswitch_28  #0x6
    :try_start_28
    sget-object p0, Lqx6;->b:Lqx6;

    const-string v1, "AES/GCM/NoPadding"

    iget-object p0, p0, Lqx6;->a:Lpx6;

    invoke-interface {p0, v1}, Lpx6;->x(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljavax/crypto/Cipher;
    :try_end_34
    .catch Ljava/security/GeneralSecurityException; {:try_start_28 .. :try_end_34} :catch_36

    move-object v0, p0

    goto :goto_3a

    :catch_36
    move-exception p0

    invoke-static {p0}, Lgdg;->o(Ljava/lang/Throwable;)V

    :goto_3a
    return-object v0

    :pswitch_3b  #0x5
    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    return-object p0

    :pswitch_41  #0x4
    new-instance p0, Ljava/text/SimpleDateFormat;

    const-string v0, "EEE, dd MMM yyyy HH:mm:ss \'GMT\'"

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {p0, v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/text/DateFormat;->setLenient(Z)V

    sget-object v0, Lmck;->a:Ljava/util/TimeZone;

    invoke-virtual {p0, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    return-object p0

    :pswitch_54  #0x3
    :try_start_54
    sget-object p0, Lqx6;->b:Lqx6;

    const-string v1, "AES/GCM-SIV/NoPadding"

    iget-object p0, p0, Lqx6;->a:Lpx6;

    invoke-interface {p0, v1}, Lpx6;->x(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljavax/crypto/Cipher;
    :try_end_60
    .catch Ljava/security/GeneralSecurityException; {:try_start_54 .. :try_end_60} :catch_62

    move-object v0, p0

    goto :goto_66

    :catch_62
    move-exception p0

    invoke-static {p0}, Lgdg;->o(Ljava/lang/Throwable;)V

    :goto_66
    return-object v0

    :pswitch_67  #0x2
    :try_start_67
    sget-object p0, Lqx6;->b:Lqx6;

    const-string v1, "AES/CTR/NOPADDING"

    iget-object p0, p0, Lqx6;->a:Lpx6;

    invoke-interface {p0, v1}, Lpx6;->x(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljavax/crypto/Cipher;
    :try_end_73
    .catch Ljava/security/GeneralSecurityException; {:try_start_67 .. :try_end_73} :catch_75

    move-object v0, p0

    goto :goto_79

    :catch_75
    move-exception p0

    invoke-static {p0}, Lgdg;->o(Ljava/lang/Throwable;)V

    :goto_79
    return-object v0

    :pswitch_7a  #0x1
    :try_start_7a
    sget-object p0, Lqx6;->b:Lqx6;

    const-string v1, "AES/ECB/NOPADDING"

    iget-object p0, p0, Lqx6;->a:Lpx6;

    invoke-interface {p0, v1}, Lpx6;->x(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljavax/crypto/Cipher;
    :try_end_86
    .catch Ljava/security/GeneralSecurityException; {:try_start_7a .. :try_end_86} :catch_88

    move-object v0, p0

    goto :goto_8c

    :catch_88
    move-exception p0

    invoke-static {p0}, Lgdg;->o(Ljava/lang/Throwable;)V

    :goto_8c
    return-object v0

    :pswitch_8d  #0x0
    :try_start_8d
    sget-object p0, Lqx6;->b:Lqx6;

    const-string v1, "AES/CTR/NoPadding"

    iget-object p0, p0, Lqx6;->a:Lpx6;

    invoke-interface {p0, v1}, Lpx6;->x(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljavax/crypto/Cipher;
    :try_end_99
    .catch Ljava/security/GeneralSecurityException; {:try_start_8d .. :try_end_99} :catch_9b

    move-object v0, p0

    goto :goto_9f

    :catch_9b
    move-exception p0

    invoke-static {p0}, Lgdg;->o(Ljava/lang/Throwable;)V

    :goto_9f
    return-object v0

    :pswitch_data_a0
    .packed-switch 0x0
        :pswitch_8d  #00000000
        :pswitch_7a  #00000001
        :pswitch_67  #00000002
        :pswitch_54  #00000003
        :pswitch_41  #00000004
        :pswitch_3b  #00000005
        :pswitch_28  #00000006
        :pswitch_1f  #00000007
        :pswitch_19  #00000008
        :pswitch_13  #00000009
        :pswitch_d  #0000000a
        :pswitch_9  #0000000b
    .end packed-switch
.end method
