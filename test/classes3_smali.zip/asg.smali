.class public final synthetic Lasg;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lqlf;


# direct methods
.method public synthetic constructor <init>(Lqlf;I)V
    .registers 3

    iput p2, p0, Lasg;->E:I

    iput-object p1, p0, Lasg;->F:Lqlf;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 6

    iget v0, p0, Lasg;->E:I

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v3, Lz2j;->a:Lz2j;

    iget-object p0, p0, Lasg;->F:Lqlf;

    packed-switch v0, :pswitch_data_a8

    invoke-static {p0}, Lcom/anthropic/claude/chat/share/j;->b(Lqlf;)V

    return-object v3

    :pswitch_f  #0x9
    invoke-static {p0}, Lcom/anthropic/claude/chat/share/j;->b(Lqlf;)V

    return-object v3

    :pswitch_13  #0x8
    invoke-static {p0}, Lcom/anthropic/claude/chat/share/j;->b(Lqlf;)V

    return-object v3

    :pswitch_17  #0x7
    invoke-static {p0}, Lcom/anthropic/claude/chat/share/j;->b(Lqlf;)V

    return-object v3

    :pswitch_1b  #0x6
    sget-object v0, Lcom/anthropic/claude/settings/SettingsAppScreen$SharedLinksScreen;->INSTANCE:Lcom/anthropic/claude/settings/SettingsAppScreen$SharedLinksScreen;

    new-instance v1, Lcsg;

    const/16 v2, 0x8

    invoke-direct {v1, v2, v0}, Lcsg;-><init>(ILjava/lang/Object;)V

    new-instance v0, Ldsg;

    const/4 v2, 0x4

    invoke-direct {v0, v2}, Ldsg;-><init>(I)V

    iget-object p0, p0, Lqlf;->E:Li26;

    invoke-virtual {p0, v1, v0}, Li26;->f(Lc98;Lq98;)V

    return-object v3

    :pswitch_30  #0x5
    sget-object v0, Lcom/anthropic/claude/settings/SettingsAppScreen$PrivacyScreen;->INSTANCE:Lcom/anthropic/claude/settings/SettingsAppScreen$PrivacyScreen;

    new-instance v1, Lcsg;

    const/4 v2, 0x7

    invoke-direct {v1, v2, v0}, Lcsg;-><init>(ILjava/lang/Object;)V

    new-instance v0, Ldsg;

    const/4 v2, 0x3

    invoke-direct {v0, v2}, Ldsg;-><init>(I)V

    iget-object p0, p0, Lqlf;->E:Li26;

    invoke-virtual {p0, v1, v0}, Li26;->f(Lc98;Lq98;)V

    return-object v3

    :pswitch_44  #0x4
    sget-object v0, Lcom/anthropic/claude/settings/SettingsAppScreen$TimeLimitsScreen;->INSTANCE:Lcom/anthropic/claude/settings/SettingsAppScreen$TimeLimitsScreen;

    new-instance v1, Lcsg;

    const/4 v2, 0x6

    invoke-direct {v1, v2, v0}, Lcsg;-><init>(ILjava/lang/Object;)V

    new-instance v0, Ldsg;

    const/4 v2, 0x2

    invoke-direct {v0, v2}, Ldsg;-><init>(I)V

    iget-object p0, p0, Lqlf;->E:Li26;

    invoke-virtual {p0, v1, v0}, Li26;->f(Lc98;Lq98;)V

    return-object v3

    :pswitch_58  #0x3
    sget-object v0, Lcom/anthropic/claude/settings/SettingsAppScreen$NotificationSettingsScreen;->INSTANCE:Lcom/anthropic/claude/settings/SettingsAppScreen$NotificationSettingsScreen;

    new-instance v4, Lcsg;

    invoke-direct {v4, v2, v0}, Lcsg;-><init>(ILjava/lang/Object;)V

    new-instance v0, Ldsg;

    invoke-direct {v0, v1}, Ldsg;-><init>(I)V

    iget-object p0, p0, Lqlf;->E:Li26;

    invoke-virtual {p0, v4, v0}, Li26;->f(Lc98;Lq98;)V

    return-object v3

    :pswitch_6a  #0x2
    sget-object v0, Lcom/anthropic/claude/settings/SettingsAppScreen$MobileAppFeedbackScreen;->INSTANCE:Lcom/anthropic/claude/settings/SettingsAppScreen$MobileAppFeedbackScreen;

    new-instance v1, Lcsg;

    const/16 v4, 0x9

    invoke-direct {v1, v4, v0}, Lcsg;-><init>(ILjava/lang/Object;)V

    new-instance v0, Ldsg;

    invoke-direct {v0, v2}, Ldsg;-><init>(I)V

    iget-object p0, p0, Lqlf;->E:Li26;

    invoke-virtual {p0, v1, v0}, Li26;->f(Lc98;Lq98;)V

    return-object v3

    :pswitch_7e  #0x1
    sget-object v0, Lcom/anthropic/claude/settings/SettingsAppScreen$UsageScreen;->INSTANCE:Lcom/anthropic/claude/settings/SettingsAppScreen$UsageScreen;

    new-instance v2, Lcsg;

    invoke-direct {v2, v1, v0}, Lcsg;-><init>(ILjava/lang/Object;)V

    new-instance v0, Lwqg;

    const/16 v1, 0x1a

    invoke-direct {v0, v1}, Lwqg;-><init>(I)V

    iget-object p0, p0, Lqlf;->E:Li26;

    invoke-virtual {p0, v2, v0}, Li26;->f(Lc98;Lq98;)V

    return-object v3

    :pswitch_92  #0x0
    sget-object v0, Lcom/anthropic/claude/settings/SettingsAppScreen$ProfileScreen;->INSTANCE:Lcom/anthropic/claude/settings/SettingsAppScreen$ProfileScreen;

    new-instance v1, Lcsg;

    const/4 v2, 0x0

    invoke-direct {v1, v2, v0}, Lcsg;-><init>(ILjava/lang/Object;)V

    new-instance v0, Lwqg;

    const/16 v2, 0x18

    invoke-direct {v0, v2}, Lwqg;-><init>(I)V

    iget-object p0, p0, Lqlf;->E:Li26;

    invoke-virtual {p0, v1, v0}, Li26;->f(Lc98;Lq98;)V

    return-object v3

    nop

    :pswitch_data_a8
    .packed-switch 0x0
        :pswitch_92  #00000000
        :pswitch_7e  #00000001
        :pswitch_6a  #00000002
        :pswitch_58  #00000003
        :pswitch_44  #00000004
        :pswitch_30  #00000005
        :pswitch_1b  #00000006
        :pswitch_17  #00000007
        :pswitch_13  #00000008
        :pswitch_f  #00000009
    .end packed-switch
.end method
