.class public final Lb3a;
.super Llc8;
.source "SourceFile"

# interfaces
.implements Lvzb;


# virtual methods
.method public final a()Lcom/google/crypto/tink/shaded/protobuf/f;
    .registers 1

    iget-object p0, p0, Llc8;->E:Lcom/google/crypto/tink/shaded/protobuf/f;

    return-object p0
.end method

.method public final bridge synthetic clone()Ljava/lang/Object;
    .registers 1

    invoke-virtual {p0}, Llc8;->d()Llc8;

    move-result-object p0

    return-object p0
.end method
