.class public final synthetic Lap1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Z

.field public final synthetic G:Z

.field public final synthetic H:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lkh9;ZZ)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, Lap1;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lap1;->H:Ljava/lang/Object;

    iput-boolean p2, p0, Lap1;->F:Z

    iput-boolean p3, p0, Lap1;->G:Z

    return-void
.end method

.method public synthetic constructor <init>(ZLzl4;Z)V
    .registers 5

    .line 13
    const/4 v0, 0x2

    iput v0, p0, Lap1;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lap1;->F:Z

    iput-object p2, p0, Lap1;->H:Ljava/lang/Object;

    iput-boolean p3, p0, Lap1;->G:Z

    return-void
.end method

.method public synthetic constructor <init>(ZZLghh;)V
    .registers 5

    .line 14
    const/4 v0, 0x0

    iput v0, p0, Lap1;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lap1;->F:Z

    iput-boolean p2, p0, Lap1;->G:Z

    iput-object p3, p0, Lap1;->H:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 50

    move-object/from16 v0, p0

    iget v1, v0, Lap1;->E:I

    const/16 v2, 0x10

    iget-boolean v3, v0, Lap1;->G:Z

    iget-boolean v4, v0, Lap1;->F:Z

    sget-object v5, Lq7c;->E:Lq7c;

    sget-object v6, Lz2j;->a:Lz2j;

    iget-object v7, v0, Lap1;->H:Ljava/lang/Object;

    const/4 v9, 0x0

    packed-switch v1, :pswitch_data_7e8

    check-cast v7, Lzl4;

    move-object/from16 v10, p1

    check-cast v10, Ltmf;

    move-object/from16 v0, p2

    check-cast v0, Lzu4;

    move-object/from16 v1, p3

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v2, v1, 0x6

    const/16 v20, 0x2

    if-nez v2, :cond_3d

    move-object v2, v0

    check-cast v2, Leb8;

    invoke-virtual {v2, v10}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3a

    const/4 v2, 0x4

    goto :goto_3c

    :cond_3a
    move/from16 v2, v20

    :goto_3c
    or-int/2addr v1, v2

    :cond_3d
    and-int/lit8 v2, v1, 0x13

    const/16 v11, 0x12

    if-eq v2, v11, :cond_45

    const/4 v2, 0x1

    goto :goto_46

    :cond_45
    move v2, v9

    :goto_46
    and-int/lit8 v11, v1, 0x1

    check-cast v0, Leb8;

    invoke-virtual {v0, v11, v2}, Leb8;->W(IZ)Z

    move-result v2

    if-eqz v2, :cond_703

    if-eqz v4, :cond_77

    const v2, 0x13c109fc

    invoke-virtual {v0, v2}, Leb8;->g0(I)V

    sget-object v11, Laf0;->Z1:Laf0;

    invoke-static {v0}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v2

    iget-wide v14, v2, Lgw3;->u0:J

    const v2, 0x7f120181

    invoke-static {v2, v0}, Lmhl;->Z(ILzu4;)Ljava/lang/String;

    move-result-object v12

    and-int/lit8 v18, v1, 0xe

    const/16 v19, 0x14

    const/4 v13, 0x0

    const/16 v16, 0x0

    move-object/from16 v17, v0

    invoke-static/range {v10 .. v19}, Lv9l;->c(Ltmf;Laf0;Ljava/lang/String;Lt7c;JZLzu4;II)V

    invoke-virtual {v0, v9}, Leb8;->q(Z)V

    goto :goto_80

    :cond_77
    const v1, 0x13c4ae2a

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    invoke-virtual {v0, v9}, Leb8;->q(Z)V

    :goto_80
    invoke-virtual {v0, v7}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {v0}, Leb8;->R()Ljava/lang/Object;

    move-result-object v2

    sget-object v11, Lxu4;->a:Lmx8;

    if-nez v1, :cond_8e

    if-ne v2, v11, :cond_c6

    :cond_8e
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v7, Lzl4;->d:Ljava/util/List;

    invoke-static {v1}, Lsm4;->Q0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lxii;

    if-nez v1, :cond_9d

    const/4 v2, 0x0

    goto :goto_c3

    :cond_9d
    invoke-static {v1}, Lmji;->f(Lxii;)Llji;

    move-result-object v2

    sget-object v12, Llji;->Q:Llji;

    if-ne v2, v12, :cond_b1

    iget-object v2, v1, Lxii;->c:Ljava/lang/String;

    const-string v12, "Workflow"

    invoke-static {v2, v12}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_b1

    :cond_af
    const/4 v2, 0x0

    goto :goto_bd

    :cond_b1
    invoke-static {v1}, Lmji;->c(Lxii;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_af

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v12

    if-lez v12, :cond_af

    :goto_bd
    new-instance v12, Lk7d;

    invoke-direct {v12, v1, v2}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v2, v12

    :goto_c3
    invoke-virtual {v0, v2}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_c6
    check-cast v2, Lk7d;

    const v1, 0x6a95c9f1

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    invoke-static {v0}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v12, v1, Lgw3;->O:J

    invoke-static {v0}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v14, v1, Lgw3;->M:J

    invoke-static {v0}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    move-object/from16 v16, v5

    const/16 p0, 0x0

    iget-wide v4, v1, Lgw3;->u0:J

    invoke-static {v0}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->F:Ljava/lang/Object;

    check-cast v1, Lzm;

    iget-object v1, v1, Lzm;->h:Ljava/lang/Object;

    check-cast v1, Liai;

    iget-object v1, v1, Liai;->a:Llah;

    iget-object v1, v1, Llah;->f:Lz38;

    if-eqz v2, :cond_1f0

    const v9, 0x6d1d0ddf

    invoke-virtual {v0, v9}, Leb8;->g0(I)V

    iget-object v9, v2, Lk7d;->E:Ljava/lang/Object;

    check-cast v9, Lxii;

    iget-object v8, v2, Lk7d;->F:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    invoke-static {v9}, Lmji;->g(Lxii;)Z

    move-result v19

    if-eqz v8, :cond_11c

    invoke-static {v9}, Lkji;->e(Lxii;)Z

    move-result v21

    if-eqz v21, :cond_116

    invoke-static {v8}, Lkji;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    :cond_116
    :goto_116
    move-object/from16 v41, v1

    move-wide/from16 p2, v4

    const/4 v1, 0x1

    goto :goto_11f

    :cond_11c
    move-object/from16 v8, p0

    goto :goto_116

    :goto_11f
    invoke-static {v9, v0, v1}, Lmji;->a(Lxii;Lzu4;I)Ljava/lang/String;

    move-result-object v4

    iget-object v1, v9, Lxii;->f:Lwii;

    sget-object v5, Lwii;->G:Lwii;

    if-ne v1, v5, :cond_12c

    move-wide/from16 v22, p2

    goto :goto_12e

    :cond_12c
    move-wide/from16 v22, v12

    :goto_12e
    new-instance v1, Lid0;

    invoke-direct {v1}, Lid0;-><init>()V

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v5, v21

    invoke-virtual {v1, v5}, Lid0;->l(Llah;)I

    move-result v5

    :try_start_15b
    invoke-virtual {v1, v4}, Lid0;->g(Ljava/lang/String;)V
    :try_end_15e
    .catchall {:try_start_15b .. :try_end_15e} :catchall_1eb

    invoke-virtual {v1, v5}, Lid0;->i(I)V

    if-eqz v8, :cond_1da

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    move-wide/from16 v22, v12

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v4, v21

    invoke-virtual {v1, v4}, Lid0;->l(Llah;)I

    move-result v4

    const/16 v5, 0x20

    :try_start_18f
    invoke-virtual {v1, v5}, Lid0;->c(C)V
    :try_end_192
    .catchall {:try_start_18f .. :try_end_192} :catchall_1d5

    invoke-virtual {v1, v4}, Lid0;->i(I)V

    new-instance v21, Llah;

    if-eqz v19, :cond_19c

    move-wide/from16 v22, v14

    goto :goto_19e

    :cond_19c
    move-wide/from16 v22, v12

    :goto_19e
    if-eqz v19, :cond_1a3

    move-object/from16 v29, v41

    goto :goto_1a5

    :cond_1a3
    move-object/from16 v29, p0

    :goto_1a5
    const/16 v39, 0x0

    const v40, 0xffde

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v4, v21

    invoke-virtual {v1, v4}, Lid0;->l(Llah;)I

    move-result v4

    :try_start_1c9
    invoke-virtual {v1, v8}, Lid0;->g(Ljava/lang/String;)V
    :try_end_1cc
    .catchall {:try_start_1c9 .. :try_end_1cc} :catchall_1d0

    invoke-virtual {v1, v4}, Lid0;->i(I)V

    goto :goto_1da

    :catchall_1d0
    move-exception v0

    invoke-virtual {v1, v4}, Lid0;->i(I)V

    throw v0

    :catchall_1d5
    move-exception v0

    invoke-virtual {v1, v4}, Lid0;->i(I)V

    throw v0

    :cond_1da
    :goto_1da
    invoke-virtual {v1}, Lid0;->m()Lkd0;

    move-result-object v1

    const/4 v4, 0x0

    invoke-virtual {v0, v4}, Leb8;->q(Z)V

    invoke-virtual {v0, v4}, Leb8;->q(Z)V

    move-object/from16 v21, v1

    move-object/from16 v43, v6

    goto/16 :goto_60e

    :catchall_1eb
    move-exception v0

    invoke-virtual {v1, v5}, Lid0;->i(I)V

    throw v0

    :cond_1f0
    move-object/from16 v41, v1

    move-wide/from16 p2, v4

    const/4 v4, 0x0

    const v1, 0x6d2f9e51

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    invoke-virtual {v0, v4}, Leb8;->q(Z)V

    iget-object v1, v7, Lzl4;->c:Lyoi;

    iget-object v4, v7, Lzl4;->d:Ljava/util/List;

    if-eqz v1, :cond_207

    iget-object v1, v1, Lyoi;->a:Ljava/lang/String;

    goto :goto_209

    :cond_207
    move-object/from16 v1, p0

    :goto_209
    if-eqz v1, :cond_211

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v5

    if-nez v5, :cond_218

    :cond_211
    move-object/from16 v43, v6

    move-wide/from16 v22, v12

    const/4 v14, 0x0

    goto/16 :goto_422

    :cond_218
    const v5, 0x6d3142a2

    invoke-virtual {v0, v5}, Leb8;->g0(I)V

    invoke-virtual {v0, v7}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v0}, Leb8;->R()Ljava/lang/Object;

    move-result-object v8

    if-nez v5, :cond_233

    if-ne v8, v11, :cond_22b

    goto :goto_233

    :cond_22b
    move-object/from16 v43, v6

    move-wide/from16 v44, v12

    move-wide/from16 v22, v14

    goto/16 :goto_392

    :cond_233
    :goto_233
    check-cast v4, Ljava/lang/Iterable;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_23e
    :goto_23e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_254

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lxii;

    invoke-static {v8}, Lmji;->h(Lxii;)Ljava/lang/String;

    move-result-object v8

    if-eqz v8, :cond_23e

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_23e

    :cond_254
    sget-object v4, Lkji;->a:Lqp4;

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_25f
    :goto_25f
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_276

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    move-object v9, v8

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    if-lez v9, :cond_25f

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_25f

    :cond_276
    new-instance v5, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v4, v8}, Ltm4;->X(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v5, v8}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_285
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_299

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-static {v9}, Lkji;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_285

    :cond_299
    invoke-static {v5}, Lsm4;->d1(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v5

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    sget-object v9, Lkji;->c:Lz0f;

    invoke-static {v9, v1}, Lz0f;->c(Lz0f;Ljava/lang/String;)Lxt7;

    move-result-object v9

    move-object/from16 p1, v4

    new-instance v4, Llid;

    invoke-direct {v4, v9}, Llid;-><init>(Lxt7;)V

    const/4 v9, 0x0

    :goto_2b0
    invoke-virtual {v4}, Llid;->hasNext()Z

    move-result v19

    if-eqz v19, :cond_364

    invoke-virtual {v4}, Llid;->next()Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ln9b;

    move-object/from16 p2, v4

    invoke-virtual/range {v19 .. v19}, Ln9b;->c()Ljava/lang/String;

    move-result-object v4

    move-object/from16 v43, v6

    move-wide/from16 v44, v12

    const/4 v6, 0x1

    new-array v12, v6, [C

    const/16 v6, 0x2e

    const/16 v17, 0x0

    aput-char v6, v12, v17

    invoke-static {v4, v12}, Lcnh;->b1(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v6

    if-nez v6, :cond_2dd

    move-wide/from16 v22, v14

    goto/16 :goto_35a

    :cond_2dd
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_2e6

    :cond_2e3
    move-wide/from16 v22, v14

    goto :goto_320

    :cond_2e6
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_2ea
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_2e3

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    invoke-static {v12, v4}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_31d

    const-string v13, "/"

    move-object/from16 p3, v6

    invoke-virtual {v13, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-wide/from16 v22, v14

    const/4 v14, 0x0

    invoke-static {v12, v6, v14}, Ljnh;->Y(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v6

    if-nez v6, :cond_32a

    invoke-virtual {v13, v12}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6, v14}, Ljnh;->Y(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v6

    if-eqz v6, :cond_318

    goto :goto_32a

    :cond_318
    move-object/from16 v6, p3

    move-wide/from16 v14, v22

    goto :goto_2ea

    :cond_31d
    move-wide/from16 v22, v14

    goto :goto_32a

    :goto_320
    invoke-static {v4}, Lkji;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_35a

    :cond_32a
    :goto_32a
    invoke-virtual/range {v19 .. v19}, Ln9b;->b()Ltj9;

    move-result-object v6

    iget v6, v6, Lrj9;->E:I

    if-ge v9, v6, :cond_345

    new-instance v6, Lmce;

    invoke-virtual/range {v19 .. v19}, Ln9b;->b()Ltj9;

    move-result-object v12

    iget v12, v12, Lrj9;->E:I

    invoke-virtual {v1, v9, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    const/4 v14, 0x0

    invoke-direct {v6, v9, v14}, Lmce;-><init>(Ljava/lang/String;Z)V

    invoke-virtual {v8, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_345
    new-instance v6, Lmce;

    const/4 v9, 0x1

    invoke-direct {v6, v4, v9}, Lmce;-><init>(Ljava/lang/String;Z)V

    invoke-virtual {v8, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual/range {v19 .. v19}, Ln9b;->b()Ltj9;

    move-result-object v6

    iget v6, v6, Lrj9;->E:I

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    add-int v9, v4, v6

    :cond_35a
    :goto_35a
    move-object/from16 v4, p2

    move-wide/from16 v14, v22

    move-object/from16 v6, v43

    move-wide/from16 v12, v44

    goto/16 :goto_2b0

    :cond_364
    move-object/from16 v43, v6

    move-wide/from16 v44, v12

    move-wide/from16 v22, v14

    invoke-virtual {v8}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_37c

    new-instance v4, Lmce;

    const/4 v14, 0x0

    invoke-direct {v4, v1, v14}, Lmce;-><init>(Ljava/lang/String;Z)V

    invoke-static {v4}, Loz4;->H(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    move-object v8, v1

    goto :goto_38f

    :cond_37c
    const/4 v14, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    if-ge v9, v4, :cond_38f

    new-instance v4, Lmce;

    invoke-virtual {v1, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1, v14}, Lmce;-><init>(Ljava/lang/String;Z)V

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_38f
    :goto_38f
    invoke-virtual {v0, v8}, Leb8;->q0(Ljava/lang/Object;)V

    :goto_392
    check-cast v8, Ljava/util/List;

    new-instance v1, Lid0;

    invoke-direct {v1}, Lid0;-><init>()V

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_39d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_413

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lmce;

    iget-boolean v6, v5, Lmce;->b:Z

    if-eqz v6, :cond_3d6

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xffde

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    move-object/from16 v29, v41

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-wide/from16 v8, v22

    move-wide/from16 v22, v44

    :goto_3d3
    move-object/from16 v6, v21

    goto :goto_3fd

    :cond_3d6
    move-wide/from16 v8, v22

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    move-wide/from16 v22, v44

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    goto :goto_3d3

    :goto_3fd
    invoke-virtual {v1, v6}, Lid0;->l(Llah;)I

    move-result v6

    :try_start_401
    iget-object v5, v5, Lmce;->a:Ljava/lang/String;

    invoke-virtual {v1, v5}, Lid0;->g(Ljava/lang/String;)V
    :try_end_406
    .catchall {:try_start_401 .. :try_end_406} :catchall_40e

    invoke-virtual {v1, v6}, Lid0;->i(I)V

    move-wide/from16 v44, v22

    move-wide/from16 v22, v8

    goto :goto_39d

    :catchall_40e
    move-exception v0

    invoke-virtual {v1, v6}, Lid0;->i(I)V

    throw v0

    :cond_413
    invoke-virtual {v1}, Lid0;->m()Lkd0;

    move-result-object v1

    const/4 v14, 0x0

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    :goto_41b
    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    move-object/from16 v21, v1

    goto/16 :goto_60e

    :goto_422
    const v1, 0x6d3c45d1

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    const v1, 0x518cea3a

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    invoke-static {v4, v0}, Lmji;->d(Ljava/util/List;Lzu4;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_442

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    move-object/from16 v1, p0

    goto/16 :goto_5b2

    :cond_442
    new-instance v4, Lid0;

    invoke-direct {v4}, Lid0;-><init>()V

    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v5, 0x0

    :goto_44e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_5aa

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    add-int/lit8 v8, v5, 0x1

    if-ltz v5, :cond_5a6

    check-cast v6, Lrm8;

    if-lez v5, :cond_498

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v5, v21

    move-wide/from16 v12, v22

    invoke-virtual {v4, v5}, Lid0;->l(Llah;)I

    move-result v5

    :try_start_48a
    const-string v9, ", "

    invoke-virtual {v4, v9}, Lid0;->g(Ljava/lang/String;)V
    :try_end_48f
    .catchall {:try_start_48a .. :try_end_48f} :catchall_493

    invoke-virtual {v4, v5}, Lid0;->i(I)V

    goto :goto_49a

    :catchall_493
    move-exception v0

    invoke-virtual {v4, v5}, Lid0;->i(I)V

    throw v0

    :cond_498
    move-wide/from16 v12, v22

    :goto_49a
    iget-boolean v5, v6, Lrm8;->b:Z

    iget-object v6, v6, Lrm8;->a:Ljava/lang/String;

    if-eqz v5, :cond_563

    const/4 v5, 0x6

    const/16 v9, 0x20

    const/4 v14, 0x0

    invoke-static {v6, v9, v14, v5}, Lcnh;->u0(Ljava/lang/CharSequence;CII)I

    move-result v5

    if-lez v5, :cond_527

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    move-wide/from16 v22, p2

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v9, v21

    move-wide/from16 v14, v22

    invoke-virtual {v4, v9}, Lid0;->l(Llah;)I

    move-result v9

    move-object/from16 p2, v1

    move/from16 p3, v8

    const/4 v1, 0x0

    :try_start_4db
    invoke-virtual {v6, v1, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Lid0;->g(Ljava/lang/String;)V
    :try_end_4e2
    .catchall {:try_start_4db .. :try_end_4e2} :catchall_522

    invoke-virtual {v4, v9}, Lid0;->i(I)V

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    move-wide/from16 v22, v12

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v1, v21

    invoke-virtual {v4, v1}, Lid0;->l(Llah;)I

    move-result v1

    :try_start_50f
    invoke-virtual {v6, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lid0;->g(Ljava/lang/String;)V
    :try_end_516
    .catchall {:try_start_50f .. :try_end_516} :catchall_51d

    invoke-virtual {v4, v1}, Lid0;->i(I)V

    :goto_519
    move-wide/from16 v22, v12

    goto/16 :goto_599

    :catchall_51d
    move-exception v0

    invoke-virtual {v4, v1}, Lid0;->i(I)V

    throw v0

    :catchall_522
    move-exception v0

    invoke-virtual {v4, v9}, Lid0;->i(I)V

    throw v0

    :cond_527
    move-wide/from16 v14, p2

    move-object/from16 p2, v1

    move/from16 p3, v8

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    move-wide/from16 v22, v14

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v1, v21

    invoke-virtual {v4, v1}, Lid0;->l(Llah;)I

    move-result v1

    :try_start_557
    invoke-virtual {v4, v6}, Lid0;->g(Ljava/lang/String;)V
    :try_end_55a
    .catchall {:try_start_557 .. :try_end_55a} :catchall_55e

    invoke-virtual {v4, v1}, Lid0;->i(I)V

    goto :goto_519

    :catchall_55e
    move-exception v0

    invoke-virtual {v4, v1}, Lid0;->i(I)V

    throw v0

    :cond_563
    move-wide/from16 v14, p2

    move-object/from16 p2, v1

    move/from16 p3, v8

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    move-wide/from16 v22, v12

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v1, v21

    invoke-virtual {v4, v1}, Lid0;->l(Llah;)I

    move-result v1

    :try_start_593
    invoke-virtual {v4, v6}, Lid0;->g(Ljava/lang/String;)V
    :try_end_596
    .catchall {:try_start_593 .. :try_end_596} :catchall_5a1

    invoke-virtual {v4, v1}, Lid0;->i(I)V

    :goto_599
    move-object/from16 v1, p2

    move/from16 v5, p3

    move-wide/from16 p2, v14

    goto/16 :goto_44e

    :catchall_5a1
    move-exception v0

    invoke-virtual {v4, v1}, Lid0;->i(I)V

    throw v0

    :cond_5a6
    invoke-static {}, Loz4;->U()V

    throw p0

    :cond_5aa
    invoke-virtual {v4}, Lid0;->m()Lkd0;

    move-result-object v1

    const/4 v14, 0x0

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    :goto_5b2
    if-nez v1, :cond_602

    const v1, 0x1c4c518e

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    const v1, 0x7f120185

    invoke-static {v1, v0}, Lmhl;->Z(ILzu4;)Ljava/lang/String;

    move-result-object v1

    new-instance v21, Llah;

    const/16 v39, 0x0

    const v40, 0xfffe

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    invoke-direct/range {v21 .. v40}, Llah;-><init>(JJLf58;Ly48;Lz48;Lz38;Ljava/lang/String;JLgj1;Lv8i;Lrra;JLi4i;Lnsg;I)V

    move-object/from16 v4, v21

    sget-object v5, Lld0;->a:Lkd0;

    new-instance v5, Lkd0;

    new-instance v6, Ljd0;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v14, 0x0

    invoke-direct {v6, v4, v14, v8}, Ljd0;-><init>(Ljava/lang/Object;II)V

    invoke-static {v6}, Loz4;->H(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    sget-object v6, Lyv6;->E:Lyv6;

    invoke-direct {v5, v1, v4, v6}, Lkd0;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    move-object v1, v5

    goto/16 :goto_41b

    :cond_602
    const/4 v14, 0x0

    const v4, 0x1c4c4689

    invoke-virtual {v0, v4}, Leb8;->g0(I)V

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    goto/16 :goto_41b

    :goto_60e
    invoke-static {v0}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->E:Ljava/lang/Object;

    check-cast v1, Ljx3;

    iget-object v1, v1, Ljx3;->L:Ljava/lang/Object;

    move-object/from16 v38, v1

    check-cast v38, Liai;

    if-eqz v2, :cond_62f

    iget-object v1, v2, Lk7d;->E:Ljava/lang/Object;

    check-cast v1, Lxii;

    if-eqz v1, :cond_62f

    invoke-static {v1}, Lkji;->e(Lxii;)Z

    move-result v1

    const/4 v6, 0x1

    if-ne v1, v6, :cond_62f

    const/16 v20, 0x5

    :cond_62f
    move/from16 v32, v20

    const/high16 v1, 0x3f800000  # 1.0f

    move-object/from16 v4, v16

    const/4 v14, 0x0

    invoke-interface {v10, v4, v1, v14}, Ltmf;->a(Lt7c;FZ)Lt7c;

    move-result-object v22

    const/16 v41, 0x6000

    const v42, 0x3affc

    const-wide/16 v23, 0x0

    const-wide/16 v25, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x1

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v40, 0x0

    move-object/from16 v39, v0

    invoke-static/range {v21 .. v42}, Li9i;->c(Lkd0;Lt7c;JJJLv2i;JIZIILjava/util/Map;Lc98;Liai;Lzu4;III)V

    if-eqz v3, :cond_6f8

    const v1, 0x13cfbf84

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    iget-object v1, v7, Lzl4;->d:Ljava/util/List;

    invoke-virtual {v0, v1}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {v0}, Leb8;->R()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_670

    if-ne v2, v11, :cond_6c4

    :cond_670
    iget-object v1, v7, Lzl4;->d:Ljava/util/List;

    sget-object v2, Lmji;->a:Ljava/util/Set;

    check-cast v1, Ljava/lang/Iterable;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_67f
    :goto_67f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_695

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lxii;

    invoke-static {v3}, Lmji;->b(Lxii;)Lkd6;

    move-result-object v3

    if-eqz v3, :cond_67f

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_67f

    :cond_695
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_69e

    move-object/from16 v2, p0

    goto :goto_6c1

    :cond_69e
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6ef

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    :goto_6ac
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_6bf

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lkd6;

    check-cast v2, Lkd6;

    invoke-virtual {v2, v3}, Lkd6;->a(Lkd6;)Lkd6;

    move-result-object v2

    goto :goto_6ac

    :cond_6bf
    check-cast v2, Lkd6;

    :goto_6c1
    invoke-virtual {v0, v2}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_6c4
    check-cast v2, Lkd6;

    if-eqz v2, :cond_6e1

    const v1, 0x13d3704a

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    const/high16 v1, 0x41000000  # 8.0f

    invoke-static {v4, v1}, Landroidx/compose/foundation/layout/b;->s(Lt7c;F)Lt7c;

    move-result-object v1

    invoke-static {v0, v1}, Lbo9;->i(Lzu4;Lt7c;)V

    move-object/from16 v1, p0

    const/4 v14, 0x0

    invoke-static {v2, v1, v0, v14}, Lhlk;->c(Lkd6;Lt7c;Lzu4;I)V

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    goto :goto_6eb

    :cond_6e1
    const/4 v14, 0x0

    const v1, 0x13d4d8aa

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    :goto_6eb
    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    goto :goto_708

    :cond_6ef
    move-object/from16 v1, p0

    const-string v0, "Empty collection can\'t be reduced."

    invoke-static {v0}, Lgdg;->n(Ljava/lang/String;)V

    move-object v6, v1

    goto :goto_70a

    :cond_6f8
    const/4 v14, 0x0

    const v1, 0x13d4ff6a

    invoke-virtual {v0, v1}, Leb8;->g0(I)V

    invoke-virtual {v0, v14}, Leb8;->q(Z)V

    goto :goto_708

    :cond_703
    move-object/from16 v43, v6

    invoke-virtual {v0}, Leb8;->Z()V

    :goto_708
    move-object/from16 v6, v43

    :goto_70a
    return-object v6

    :pswitch_70b  #0x1
    move-object v4, v5

    move-object/from16 v43, v6

    check-cast v7, Lkh9;

    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v3, p2

    check-cast v3, Lzu4;

    move-object/from16 v5, p3

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v5, 0x11

    if-eq v1, v2, :cond_72b

    const/4 v9, 0x1

    :goto_728
    const/16 v18, 0x1

    goto :goto_72d

    :cond_72b
    const/4 v9, 0x0

    goto :goto_728

    :goto_72d
    and-int/lit8 v1, v5, 0x1

    check-cast v3, Leb8;

    invoke-virtual {v3, v1, v9}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_796

    invoke-static {v3}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v11, v1, Lgw3;->n:J

    const/high16 v1, 0x41800000  # 16.0f

    invoke-static {v4, v1}, Landroidx/compose/foundation/layout/b;->e(Lt7c;F)Lt7c;

    move-result-object v10

    const/16 v18, 0xc08

    const/16 v19, 0x1e0

    iget-boolean v8, v0, Lap1;->F:Z

    iget-boolean v9, v0, Lap1;->G:Z

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    move-object/from16 v17, v3

    invoke-static/range {v7 .. v19}, Lmmk;->e(Lkh9;ZZLt7c;JFFFFLzu4;II)V

    const/high16 v0, 0x40c00000  # 6.0f

    const v1, 0x7f1200eb

    invoke-static {v0, v1, v3, v3, v4}, Lb40;->i(FILeb8;Leb8;Lq7c;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v3}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v0

    iget-object v0, v0, Lkx3;->e:Lhk0;

    iget-object v0, v0, Lhk0;->E:Ljava/lang/Object;

    check-cast v0, Ljx3;

    iget-object v0, v0, Ljx3;->L:Ljava/lang/Object;

    move-object/from16 v29, v0

    check-cast v29, Liai;

    const/16 v32, 0x0

    const v33, 0x1fffe

    const/4 v11, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const-wide/16 v18, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const-wide/16 v22, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v31, 0x0

    move-object/from16 v30, v3

    invoke-static/range {v10 .. v33}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_79b

    :cond_796
    move-object/from16 v30, v3

    invoke-virtual/range {v30 .. v30}, Leb8;->Z()V

    :goto_79b
    return-object v43

    :pswitch_79c  #0x0
    move-object/from16 v43, v6

    check-cast v7, Lghh;

    move-object/from16 v0, p1

    check-cast v0, Ltmf;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v5, p3

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v0, v5, 0x11

    if-eq v0, v2, :cond_7bb

    const/4 v0, 0x1

    :goto_7b8
    const/16 v18, 0x1

    goto :goto_7bd

    :cond_7bb
    const/4 v0, 0x0

    goto :goto_7b8

    :goto_7bd
    and-int/lit8 v2, v5, 0x1

    move-object v13, v1

    check-cast v13, Leb8;

    invoke-virtual {v13, v2, v0}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_7e4

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    new-instance v0, Lhp1;

    const/4 v14, 0x0

    invoke-direct {v0, v3, v7, v14}, Lhp1;-><init>(ZLjava/lang/Object;I)V

    const v1, 0x3b9f0b94

    invoke-static {v1, v0, v13}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v12

    const/16 v14, 0x6c00

    const/4 v15, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string v11, "centerControlGlyph"

    invoke-static/range {v8 .. v15}, Llab;->e(Ljava/lang/Object;Lt7c;Lnv7;Ljava/lang/String;Ljs4;Lzu4;II)V

    goto :goto_7e7

    :cond_7e4
    invoke-virtual {v13}, Leb8;->Z()V

    :goto_7e7
    return-object v43

    :pswitch_data_7e8
    .packed-switch 0x0
        :pswitch_79c  #00000000
        :pswitch_70b  #00000001
    .end packed-switch
.end method
