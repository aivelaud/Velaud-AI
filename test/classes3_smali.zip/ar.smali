.class public final synthetic Lar;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;)V
    .registers 3

    const/16 v0, 0x10

    iput v0, p0, Lar;->E:I

    sget-object v0, Laf0;->e:Laf0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lar;->F:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 12
    iput p2, p0, Lar;->E:I

    iput-object p1, p0, Lar;->F:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 46

    move-object/from16 v0, p0

    iget v1, v0, Lar;->E:I

    const/16 v2, 0x30

    const/high16 v3, 0x41400000  # 12.0f

    const/high16 v4, 0x3f800000  # 1.0f

    const/4 v5, 0x0

    const/16 v6, 0x15

    sget-object v8, Lxu4;->a:Lmx8;

    sget-object v9, Lq7c;->E:Lq7c;

    const/16 v10, 0xe

    const/16 v11, 0x12

    const/4 v13, 0x2

    iget-object v14, v0, Lar;->F:Ljava/lang/String;

    const/16 v15, 0x10

    sget-object v16, Lz2j;->a:Lz2j;

    const/high16 v17, 0x30000000

    const/4 v7, 0x0

    const/4 v12, 0x1

    packed-switch v1, :pswitch_data_a5a

    move-object/from16 v0, p1

    check-cast v0, Ltmf;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v0, v2, 0x11

    if-eq v0, v15, :cond_3b

    move v7, v12

    :cond_3b
    and-int/lit8 v0, v2, 0x1

    check-cast v1, Leb8;

    invoke-virtual {v1, v0, v7}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_6b

    invoke-static {v1}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v0

    iget-object v0, v0, Lkx3;->e:Lhk0;

    iget-object v0, v0, Lhk0;->E:Ljava/lang/Object;

    check-cast v0, Ljx3;

    iget-object v0, v0, Ljx3;->M:Ljava/lang/Object;

    check-cast v0, Liai;

    sget-object v2, Li9i;->a:Lnw4;

    invoke-virtual {v2, v0}, Lnw4;->a(Ljava/lang/Object;)Lfge;

    move-result-object v0

    new-instance v2, Lq3f;

    invoke-direct {v2, v14, v6}, Lq3f;-><init>(Ljava/lang/String;I)V

    const v3, -0x1b570912

    invoke-static {v3, v2, v1}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v2

    const/16 v3, 0x38

    invoke-static {v0, v2, v1, v3}, Lr1i;->a(Lfge;Lq98;Lzu4;I)V

    goto :goto_6e

    :cond_6b
    invoke-virtual {v1}, Leb8;->Z()V

    :goto_6e
    return-object v16

    :pswitch_6f  #0x15
    move-object/from16 v1, p1

    check-cast v1, Llaa;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_87

    move v7, v12

    :cond_87
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_ab

    const/16 v25, 0xd86

    const/16 v26, 0x70

    const/16 v17, 0x0

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v18, v0

    move-object/from16 v24, v2

    invoke-static/range {v17 .. v26}, Ldlk;->d(Ljava/lang/String;Ljava/lang/String;IILa98;ZLt7c;Lzu4;II)V

    goto :goto_b0

    :cond_ab
    move-object/from16 v24, v2

    invoke-virtual/range {v24 .. v24}, Leb8;->Z()V

    :goto_b0
    return-object v16

    :pswitch_b1  #0x14
    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_c9

    move v7, v12

    :cond_c9
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_102

    const/16 v39, 0x0

    const v40, 0x3fffe

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_107

    :cond_102
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_107
    return-object v16

    :pswitch_108  #0x13
    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v3, v2, 0x11

    if-eq v3, v15, :cond_11d

    move v7, v12

    :cond_11d
    and-int/2addr v2, v12

    check-cast v1, Leb8;

    invoke-virtual {v1, v2, v7}, Leb8;->W(IZ)Z

    move-result v2

    if-eqz v2, :cond_155

    const/16 v39, 0x0

    const v40, 0x3fffe

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v1

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_15a

    :cond_155
    move-object/from16 v37, v1

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_15a
    return-object v16

    :pswitch_15b  #0x12
    move-object/from16 v0, p1

    check-cast v0, Lcqi;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v3, v2, 0x6

    if-nez v3, :cond_186

    and-int/lit8 v3, v2, 0x8

    if-nez v3, :cond_17b

    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v3

    goto :goto_182

    :cond_17b
    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v3

    :goto_182
    if-eqz v3, :cond_185

    const/4 v13, 0x4

    :cond_185
    or-int/2addr v2, v13

    :cond_186
    and-int/lit8 v3, v2, 0x13

    if-eq v3, v11, :cond_18b

    move v7, v12

    :cond_18b
    and-int/lit8 v3, v2, 0x1

    move-object v9, v1

    check-cast v9, Leb8;

    invoke-virtual {v9, v3, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_1b1

    new-instance v1, Lq3f;

    invoke-direct {v1, v14, v10}, Lq3f;-><init>(Ljava/lang/String;I)V

    const v3, -0x7e190ea

    invoke-static {v3, v1, v9}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v8

    and-int/lit8 v1, v2, 0xe

    or-int v10, v1, v17

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    invoke-static/range {v0 .. v10}, Lwpi;->a(Lcqi;Lt7c;FLysg;JJLjs4;Lzu4;I)V

    goto :goto_1b4

    :cond_1b1
    invoke-virtual {v9}, Leb8;->Z()V

    :goto_1b4
    return-object v16

    :pswitch_1b5  #0x11
    move-object/from16 v0, p1

    check-cast v0, Lcqi;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v3, v2, 0x6

    if-nez v3, :cond_1e0

    and-int/lit8 v3, v2, 0x8

    if-nez v3, :cond_1d5

    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v3

    goto :goto_1dc

    :cond_1d5
    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v3

    :goto_1dc
    if-eqz v3, :cond_1df

    const/4 v13, 0x4

    :cond_1df
    or-int/2addr v2, v13

    :cond_1e0
    and-int/lit8 v3, v2, 0x13

    if-eq v3, v11, :cond_1e5

    move v7, v12

    :cond_1e5
    and-int/lit8 v3, v2, 0x1

    check-cast v1, Leb8;

    invoke-virtual {v1, v3, v7}, Leb8;->W(IZ)Z

    move-result v3

    if-eqz v3, :cond_212

    new-instance v3, Lq3f;

    const/16 v4, 0xc

    invoke-direct {v3, v14, v4}, Lq3f;-><init>(Ljava/lang/String;I)V

    const v4, 0x19fa8514

    invoke-static {v4, v3, v1}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v25

    and-int/2addr v2, v10

    or-int v27, v2, v17

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const-wide/16 v21, 0x0

    const-wide/16 v23, 0x0

    move-object/from16 v17, v0

    move-object/from16 v26, v1

    invoke-static/range {v17 .. v27}, Lwpi;->a(Lcqi;Lt7c;FLysg;JJLjs4;Lzu4;I)V

    goto :goto_217

    :cond_212
    move-object/from16 v26, v1

    invoke-virtual/range {v26 .. v26}, Leb8;->Z()V

    :goto_217
    return-object v16

    :pswitch_218  #0x10
    sget-object v17, Laf0;->j0:Laf0;

    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_232

    move v7, v12

    :cond_232
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_291

    const/16 v24, 0xc30

    const/16 v25, 0x14

    const/16 v18, 0x0

    const/16 v19, 0x0

    sget-object v20, Lsm2;->F:Lsm2;

    const-wide/16 v21, 0x0

    move-object/from16 v23, v2

    invoke-static/range {v17 .. v25}, Lp8;->a(Laf0;Ljava/lang/String;Lt7c;Lsm2;JLzu4;II)V

    const/high16 v1, 0x40c00000  # 6.0f

    invoke-static {v9, v1}, Landroidx/compose/foundation/layout/b;->s(Lt7c;F)Lt7c;

    move-result-object v1

    invoke-static {v2, v1}, Lbo9;->i(Lzu4;Lt7c;)V

    invoke-static {v2}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->E:Ljava/lang/Object;

    check-cast v1, Ljx3;

    iget-object v1, v1, Ljx3;->O:Ljava/lang/Object;

    move-object/from16 v37, v1

    check-cast v37, Liai;

    const/16 v40, 0x0

    const v41, 0x1fffe

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const-wide/16 v26, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v39, 0x0

    move-object/from16 v18, v0

    move-object/from16 v38, v2

    invoke-static/range {v18 .. v41}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_294

    :cond_291
    invoke-virtual {v2}, Leb8;->Z()V

    :goto_294
    return-object v16

    :pswitch_295  #0xf
    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_2ad

    move v7, v12

    :cond_2ad
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_2e6

    const/16 v39, 0x0

    const v40, 0x3fffe

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_2eb

    :cond_2e6
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_2eb
    return-object v16

    :pswitch_2ec  #0xe
    move-object/from16 v1, p1

    check-cast v1, Ltb0;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_304

    move v7, v12

    :cond_304
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_36e

    invoke-static {v2}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->E:Ljava/lang/Object;

    check-cast v1, Ljx3;

    iget-object v1, v1, Ljx3;->M:Ljava/lang/Object;

    move-object/from16 v36, v1

    check-cast v36, Liai;

    invoke-virtual {v2}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v8, :cond_32c

    new-instance v1, Ljka;

    invoke-direct {v1, v13}, Ljka;-><init>(I)V

    invoke-virtual {v2, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_32c
    check-cast v1, Lc98;

    invoke-static {v9, v1}, Lkag;->a(Lt7c;Lc98;)Lt7c;

    move-result-object v1

    const/4 v3, 0x0

    const/high16 v5, 0x40800000  # 4.0f

    invoke-static {v1, v5, v3, v13}, Landroidx/compose/foundation/layout/b;->u(Lt7c;FFI)Lt7c;

    move-result-object v4

    const/4 v8, 0x0

    const/16 v9, 0xa

    const/4 v6, 0x0

    const/high16 v7, 0x41000000  # 8.0f

    invoke-static/range {v4 .. v9}, Lik5;->O(Lt7c;FFFFI)Lt7c;

    move-result-object v18

    const/16 v39, 0x6000

    const v40, 0x1bffc

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x3

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_373

    :cond_36e
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_373
    return-object v16

    :pswitch_374  #0xd
    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_38c

    move v7, v12

    :cond_38c
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_3c5

    const/16 v39, 0x0

    const v40, 0x3fffe

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_3ca

    :cond_3c5
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_3ca
    return-object v16

    :pswitch_3cb  #0xc
    move-object/from16 v0, p1

    check-cast v0, Llaa;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v3, v2, 0x6

    if-nez v3, :cond_3ed

    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3ec

    const/4 v13, 0x4

    :cond_3ec
    or-int/2addr v2, v13

    :cond_3ed
    and-int/lit8 v3, v2, 0x13

    if-eq v3, v11, :cond_3f3

    move v3, v12

    goto :goto_3f4

    :cond_3f3
    move v3, v7

    :goto_3f4
    and-int/2addr v2, v12

    check-cast v1, Leb8;

    invoke-virtual {v1, v2, v3}, Leb8;->W(IZ)Z

    move-result v2

    if-eqz v2, :cond_416

    const/4 v2, 0x7

    invoke-static {v0, v9, v5, v5, v2}, Llaa;->a(Llaa;Lt7c;Lnv7;Lnv7;I)Lt7c;

    move-result-object v17

    sget-object v0, Lin2;->a:Ld6d;

    const/16 v21, 0x0

    const/16 v22, 0xd

    const/16 v18, 0x0

    const/high16 v19, 0x41400000  # 12.0f

    const/16 v20, 0x0

    invoke-static/range {v17 .. v22}, Lik5;->O(Lt7c;FFFFI)Lt7c;

    move-result-object v0

    invoke-static {v7, v7, v1, v0, v14}, Lkal;->b(IILzu4;Lt7c;Ljava/lang/String;)V

    goto :goto_419

    :cond_416
    invoke-virtual {v1}, Leb8;->Z()V

    :goto_419
    return-object v16

    :pswitch_41a  #0xb
    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_432

    move v7, v12

    :cond_432
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_46b

    const/16 v39, 0x0

    const v40, 0x3fffe

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_470

    :cond_46b
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_470
    return-object v16

    :pswitch_471  #0xa
    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_489

    move v7, v12

    :cond_489
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_4c2

    const/16 v39, 0x0

    const v40, 0x3fffe

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_4c7

    :cond_4c2
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_4c7
    return-object v16

    :pswitch_4c8  #0x9
    move-object/from16 v0, p1

    check-cast v0, Lcqi;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v3, v2, 0x6

    if-nez v3, :cond_4f3

    and-int/lit8 v3, v2, 0x8

    if-nez v3, :cond_4e8

    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v3

    goto :goto_4ef

    :cond_4e8
    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v3

    :goto_4ef
    if-eqz v3, :cond_4f2

    const/4 v13, 0x4

    :cond_4f2
    or-int/2addr v2, v13

    :cond_4f3
    and-int/lit8 v3, v2, 0x13

    if-eq v3, v11, :cond_4f8

    move v7, v12

    :cond_4f8
    and-int/lit8 v3, v2, 0x1

    move-object v9, v1

    check-cast v9, Leb8;

    invoke-virtual {v9, v3, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_520

    new-instance v1, Lre;

    const/16 v3, 0x1a

    invoke-direct {v1, v14, v3}, Lre;-><init>(Ljava/lang/String;I)V

    const v3, 0x719a85bc

    invoke-static {v3, v1, v9}, Lgpd;->E(ILr98;Lzu4;)Ljs4;

    move-result-object v8

    and-int/lit8 v1, v2, 0xe

    or-int v10, v1, v17

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    invoke-static/range {v0 .. v10}, Lwpi;->a(Lcqi;Lt7c;FLysg;JJLjs4;Lzu4;I)V

    goto :goto_523

    :cond_520
    invoke-virtual {v9}, Leb8;->Z()V

    :goto_523
    return-object v16

    :pswitch_524  #0x8
    move-object/from16 v1, p1

    check-cast v1, Ltmf;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_53c

    move v7, v12

    :cond_53c
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_589

    invoke-static {v2}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->E:Ljava/lang/Object;

    check-cast v1, Ljx3;

    iget-object v1, v1, Ljx3;->O:Ljava/lang/Object;

    move-object/from16 v36, v1

    check-cast v36, Liai;

    invoke-static {v2}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v3, v1, Lgw3;->c:J

    const/16 v39, 0x0

    const v40, 0x1fffa

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    move-wide/from16 v19, v3

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_58e

    :cond_589
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_58e
    return-object v16

    :pswitch_58f  #0x7
    move-object/from16 v0, p1

    check-cast v0, Ltmf;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v0, v2, 0x11

    if-eq v0, v15, :cond_5a7

    move v7, v12

    :cond_5a7
    and-int/lit8 v0, v2, 0x1

    check-cast v1, Leb8;

    invoke-virtual {v1, v0, v7}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_61e

    invoke-virtual {v1, v14}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v1}, Leb8;->R()Ljava/lang/Object;

    move-result-object v2

    if-nez v0, :cond_5bd

    if-ne v2, v8, :cond_5d5

    :cond_5bd
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Ljja;

    invoke-direct {v0, v14}, Ljja;-><init>(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Ljja;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_618

    invoke-virtual {v0}, Ljja;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_5d5
    move-object/from16 v17, v2

    check-cast v17, Ljava/lang/String;

    invoke-static {v1}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v0

    iget-object v0, v0, Lkx3;->e:Lhk0;

    iget-object v0, v0, Lhk0;->E:Ljava/lang/Object;

    check-cast v0, Ljx3;

    iget-object v0, v0, Ljx3;->L:Ljava/lang/Object;

    move-object/from16 v36, v0

    check-cast v36, Liai;

    invoke-static {v1}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v0

    iget-wide v2, v0, Lgw3;->M:J

    const/16 v39, 0x6180

    const v40, 0x1affa

    const/16 v18, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x2

    const/16 v32, 0x0

    const/16 v33, 0x1

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x0

    move-object/from16 v37, v1

    move-wide/from16 v19, v2

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_623

    :cond_618
    const-string v0, "Sequence is empty."

    invoke-static {v0}, Lgdg;->h(Ljava/lang/String;)V

    goto :goto_625

    :cond_61e
    move-object/from16 v37, v1

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_623
    move-object/from16 v5, v16

    :goto_625
    return-object v5

    :pswitch_626  #0x6
    move-object/from16 v6, p1

    check-cast v6, Laif;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v3, v2, 0x6

    if-nez v3, :cond_648

    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v6}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_647

    const/4 v13, 0x4

    :cond_647
    or-int/2addr v2, v13

    :cond_648
    and-int/lit8 v3, v2, 0x13

    if-eq v3, v11, :cond_64d

    move v7, v12

    :cond_64d
    and-int/lit8 v3, v2, 0x1

    move-object v13, v1

    check-cast v13, Leb8;

    invoke-virtual {v13, v3, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_665

    const/4 v12, 0x0

    and-int/lit8 v14, v2, 0xe

    iget-object v7, v0, Lar;->F:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v6 .. v14}, Lzhf;->c(Laif;Ljava/lang/String;Lt7c;Lc98;IZILzu4;I)V

    goto :goto_668

    :cond_665
    invoke-virtual {v13}, Leb8;->Z()V

    :goto_668
    return-object v16

    :pswitch_669  #0x5
    move-object/from16 v0, p1

    check-cast v0, Llaa;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v0, v2, 0x11

    if-eq v0, v15, :cond_682

    move v0, v12

    goto :goto_683

    :cond_682
    move v0, v7

    :goto_683
    and-int/2addr v2, v12

    check-cast v1, Leb8;

    invoke-virtual {v1, v2, v0}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_6f4

    if-nez v14, :cond_699

    const v0, 0x2ec44b24

    const v2, 0x7f120109

    invoke-static {v1, v0, v2, v1, v7}, Lti6;->n(Leb8;IILeb8;Z)Ljava/lang/String;

    move-result-object v14

    goto :goto_6a2

    :cond_699
    const v0, 0x2ec44953

    invoke-virtual {v1, v0}, Leb8;->g0(I)V

    invoke-virtual {v1, v7}, Leb8;->q(Z)V

    :goto_6a2
    filled-new-array {v14}, [Ljava/lang/Object;

    move-result-object v0

    const v2, 0x7f120108

    invoke-static {v2, v0, v1}, Lmhl;->a0(I[Ljava/lang/Object;Lzu4;)Ljava/lang/String;

    move-result-object v17

    invoke-static {v1}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v0

    iget-object v0, v0, Lkx3;->e:Lhk0;

    iget-object v0, v0, Lhk0;->E:Ljava/lang/Object;

    check-cast v0, Ljx3;

    iget-object v0, v0, Ljx3;->M:Ljava/lang/Object;

    move-object/from16 v36, v0

    check-cast v36, Liai;

    invoke-static {v1}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v0

    iget-wide v5, v0, Lgw3;->O:J

    invoke-static {v9, v4}, Landroidx/compose/foundation/layout/b;->c(Lt7c;F)Lt7c;

    move-result-object v0

    const/high16 v2, 0x41000000  # 8.0f

    invoke-static {v0, v2, v3}, Lik5;->L(Lt7c;FF)Lt7c;

    move-result-object v18

    const/16 v39, 0x0

    const v40, 0x1fff8

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x30

    move-object/from16 v37, v1

    move-wide/from16 v19, v5

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_6f9

    :cond_6f4
    move-object/from16 v37, v1

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_6f9
    return-object v16

    :pswitch_6fa  #0x4
    move-object/from16 v1, p1

    check-cast v1, Ltb0;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_712

    move v7, v12

    :cond_712
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_765

    invoke-static {v2}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->E:Ljava/lang/Object;

    check-cast v1, Ljx3;

    iget-object v1, v1, Ljx3;->N:Ljava/lang/Object;

    move-object/from16 v36, v1

    check-cast v36, Liai;

    invoke-static {v2}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v3, v1, Lgw3;->y:J

    new-instance v1, Lv2i;

    const/4 v5, 0x3

    invoke-direct {v1, v5}, Lv2i;-><init>(I)V

    const/16 v39, 0x0

    const v40, 0x1fbfa

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v18, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v28, v1

    move-object/from16 v37, v2

    move-wide/from16 v19, v3

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_76a

    :cond_765
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_76a
    return-object v16

    :pswitch_76b  #0x3
    move-object/from16 v1, p1

    check-cast v1, Llaa;

    move-object/from16 v3, p2

    check-cast v3, Lzu4;

    move-object/from16 v5, p3

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v5, 0x11

    if-eq v1, v15, :cond_783

    move v7, v12

    :cond_783
    and-int/lit8 v1, v5, 0x1

    check-cast v3, Leb8;

    invoke-virtual {v3, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_828

    sget-object v1, Luwa;->T:Lou1;

    invoke-static {v9, v4}, Landroidx/compose/foundation/layout/b;->c(Lt7c;F)Lt7c;

    move-result-object v5

    sget-object v6, Lkq0;->c:Leq0;

    invoke-static {v6, v1, v3, v2}, Llo4;->a(Ljq0;Lou1;Lzu4;I)Lmo4;

    move-result-object v1

    iget-wide v6, v3, Leb8;->T:J

    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    invoke-virtual {v3}, Leb8;->l()Lnhd;

    move-result-object v6

    invoke-static {v3, v5}, Lezg;->l0(Lzu4;Lt7c;)Lt7c;

    move-result-object v5

    sget-object v7, Lru4;->e:Lqu4;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v7, Lqu4;->b:Lhw4;

    invoke-virtual {v3}, Leb8;->k0()V

    iget-boolean v8, v3, Leb8;->S:Z

    if-eqz v8, :cond_7b9

    invoke-virtual {v3, v7}, Leb8;->k(La98;)V

    goto :goto_7bc

    :cond_7b9
    invoke-virtual {v3}, Leb8;->t0()V

    :goto_7bc
    sget-object v7, Lqu4;->f:Lja0;

    invoke-static {v3, v7, v1}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v1, Lqu4;->e:Lja0;

    invoke-static {v3, v1, v6}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    sget-object v2, Lqu4;->g:Lja0;

    invoke-static {v3, v2, v1}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v1, Lqu4;->h:Lay;

    invoke-static {v3, v1}, Lr1i;->u(Lzu4;Lc98;)V

    sget-object v1, Lqu4;->d:Lja0;

    invoke-static {v3, v1, v5}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    float-to-double v1, v4

    const-wide/16 v5, 0x0

    cmpl-double v1, v1, v5

    const-string v2, "invalid weight; must be greater than zero"

    if-lez v1, :cond_7e3

    goto :goto_7e6

    :cond_7e3
    invoke-static {v2}, Lbf9;->a(Ljava/lang/String;)V

    :goto_7e6
    new-instance v1, Lg9a;

    const v7, 0x7f7fffff  # Float.MAX_VALUE

    cmpl-float v8, v4, v7

    if-lez v8, :cond_7f0

    move v4, v7

    :cond_7f0
    invoke-direct {v1, v4, v12}, Lg9a;-><init>(FZ)V

    invoke-static {v3, v1}, Lbo9;->i(Lzu4;Lt7c;)V

    const/high16 v1, 0x41800000  # 16.0f

    invoke-static {v9, v1}, Lik5;->K(Lt7c;F)Lt7c;

    move-result-object v18

    const/16 v21, 0x30

    const/16 v22, 0x4

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const/16 v19, 0x0

    move-object/from16 v17, v0

    move-object/from16 v20, v3

    invoke-static/range {v17 .. v22}, Lgmk;->f(Ljava/lang/String;Lt7c;Liai;Lzu4;II)V

    const/high16 v0, 0x40000000  # 2.0f

    float-to-double v8, v0

    cmpl-double v1, v8, v5

    if-lez v1, :cond_813

    goto :goto_816

    :cond_813
    invoke-static {v2}, Lbf9;->a(Ljava/lang/String;)V

    :goto_816
    new-instance v1, Lg9a;

    cmpl-float v2, v0, v7

    if-lez v2, :cond_81d

    goto :goto_81e

    :cond_81d
    move v7, v0

    :goto_81e
    invoke-direct {v1, v7, v12}, Lg9a;-><init>(FZ)V

    invoke-static {v3, v1}, Lbo9;->i(Lzu4;Lt7c;)V

    invoke-virtual {v3, v12}, Leb8;->q(Z)V

    goto :goto_82b

    :cond_828
    invoke-virtual {v3}, Leb8;->Z()V

    :goto_82b
    return-object v16

    :pswitch_82c  #0x2
    move-object/from16 v0, p1

    check-cast v0, Lq98;

    move-object/from16 v1, p2

    check-cast v1, Lzu4;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v3, v2, 0x6

    if-nez v3, :cond_84e

    move-object v3, v1

    check-cast v3, Leb8;

    invoke-virtual {v3, v0}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_84d

    const/4 v13, 0x4

    :cond_84d
    or-int/2addr v2, v13

    :cond_84e
    and-int/lit8 v3, v2, 0x13

    if-eq v3, v11, :cond_853

    goto :goto_854

    :cond_853
    move v12, v7

    :goto_854
    and-int/lit8 v3, v2, 0x1

    check-cast v1, Leb8;

    invoke-virtual {v1, v3, v12}, Leb8;->W(IZ)Z

    move-result v3

    if-eqz v3, :cond_8ca

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v3

    if-nez v3, :cond_8b8

    const v3, -0x4794d75f

    invoke-virtual {v1, v3}, Leb8;->g0(I)V

    sget-object v3, Ljmh;->n:Lxvh;

    invoke-virtual {v3}, Lxvh;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ltmh;

    invoke-static {v3, v1}, Lhgl;->i(Ltmh;Lzu4;)Ljava/lang/String;

    move-result-object v17

    invoke-static {v1}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v3

    iget-object v3, v3, Lkx3;->e:Lhk0;

    iget-object v3, v3, Lhk0;->E:Ljava/lang/Object;

    check-cast v3, Ljx3;

    iget-object v3, v3, Ljx3;->L:Ljava/lang/Object;

    move-object/from16 v36, v3

    check-cast v36, Liai;

    invoke-static {v1}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v3

    iget-wide v3, v3, Lgw3;->O:J

    const/16 v39, 0x0

    const v40, 0x1fffa

    const/16 v18, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x0

    move-object/from16 v37, v1

    move-wide/from16 v19, v3

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    invoke-virtual {v1, v7}, Leb8;->q(Z)V

    goto :goto_8c1

    :cond_8b8
    const v3, -0x47906a4c

    invoke-virtual {v1, v3}, Leb8;->g0(I)V

    invoke-virtual {v1, v7}, Leb8;->q(Z)V

    :goto_8c1
    and-int/2addr v2, v10

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_8cd

    :cond_8ca
    invoke-virtual {v1}, Leb8;->Z()V

    :goto_8cd
    return-object v16

    :pswitch_8ce  #0x1
    move-object/from16 v1, p1

    check-cast v1, Ltb0;

    move-object/from16 v2, p2

    check-cast v2, Lzu4;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v3, 0x11

    if-eq v1, v15, :cond_8e6

    move v7, v12

    :cond_8e6
    and-int/lit8 v1, v3, 0x1

    check-cast v2, Leb8;

    invoke-virtual {v2, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_953

    invoke-static {v2}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->E:Ljava/lang/Object;

    check-cast v1, Ljx3;

    iget-object v1, v1, Ljx3;->P:Ljava/lang/Object;

    move-object/from16 v36, v1

    check-cast v36, Liai;

    invoke-static {v2}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v3, v1, Lgw3;->O:J

    const/4 v13, 0x0

    const/16 v14, 0x8

    sget-object v9, Lq7c;->E:Lq7c;

    const/high16 v10, 0x40000000  # 2.0f

    const/high16 v11, 0x40800000  # 4.0f

    move v12, v10

    invoke-static/range {v9 .. v14}, Lik5;->O(Lt7c;FFFFI)Lt7c;

    move-result-object v1

    invoke-virtual {v2}, Leb8;->R()Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v8, :cond_922

    new-instance v5, Lq6;

    invoke-direct {v5, v6}, Lq6;-><init>(I)V

    invoke-virtual {v2, v5}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_922
    check-cast v5, Lc98;

    invoke-static {v1, v5}, Lkag;->a(Lt7c;Lc98;)Lt7c;

    move-result-object v18

    const/16 v39, 0x0

    const v40, 0x1fff8

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-object/from16 v37, v2

    move-wide/from16 v19, v3

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    goto :goto_958

    :cond_953
    move-object/from16 v37, v2

    invoke-virtual/range {v37 .. v37}, Leb8;->Z()V

    :goto_958
    return-object v16

    :pswitch_959  #0x0
    move-object/from16 v1, p1

    check-cast v1, Ltb0;

    move-object/from16 v4, p2

    check-cast v4, Lzu4;

    move-object/from16 v5, p3

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit8 v1, v5, 0x11

    if-eq v1, v15, :cond_971

    move v7, v12

    :cond_971
    and-int/lit8 v1, v5, 0x1

    check-cast v4, Leb8;

    invoke-virtual {v4, v1, v7}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_a55

    sget-object v1, Luwa;->Q:Lpu1;

    const/16 v21, 0x0

    const/16 v22, 0x9

    sget-object v17, Lq7c;->E:Lq7c;

    const/16 v18, 0x0

    const/high16 v19, 0x40800000  # 4.0f

    const/high16 v20, 0x40000000  # 2.0f

    invoke-static/range {v17 .. v22}, Lik5;->O(Lt7c;FFFFI)Lt7c;

    move-result-object v5

    move-object/from16 v6, v17

    move/from16 v7, v19

    invoke-virtual {v4}, Leb8;->R()Ljava/lang/Object;

    move-result-object v9

    if-ne v9, v8, :cond_9a1

    new-instance v9, Lq6;

    const/16 v8, 0x14

    invoke-direct {v9, v8}, Lq6;-><init>(I)V

    invoke-virtual {v4, v9}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_9a1
    check-cast v9, Lc98;

    invoke-static {v5, v9}, Lkag;->a(Lt7c;Lc98;)Lt7c;

    move-result-object v5

    sget-object v8, Lkq0;->a:Lfq0;

    invoke-static {v8, v1, v4, v2}, Lqmf;->a(Lgq0;Lpu1;Lzu4;I)Lsmf;

    move-result-object v1

    iget-wide v8, v4, Leb8;->T:J

    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    invoke-virtual {v4}, Leb8;->l()Lnhd;

    move-result-object v8

    invoke-static {v4, v5}, Lezg;->l0(Lzu4;Lt7c;)Lt7c;

    move-result-object v5

    sget-object v9, Lru4;->e:Lqu4;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v9, Lqu4;->b:Lhw4;

    invoke-virtual {v4}, Leb8;->k0()V

    iget-boolean v10, v4, Leb8;->S:Z

    if-eqz v10, :cond_9cd

    invoke-virtual {v4, v9}, Leb8;->k(La98;)V

    goto :goto_9d0

    :cond_9cd
    invoke-virtual {v4}, Leb8;->t0()V

    :goto_9d0
    sget-object v9, Lqu4;->f:Lja0;

    invoke-static {v4, v9, v1}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v1, Lqu4;->e:Lja0;

    invoke-static {v4, v1, v8}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    sget-object v2, Lqu4;->g:Lja0;

    invoke-static {v4, v2, v1}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v1, Lqu4;->h:Lay;

    invoke-static {v4, v1}, Lr1i;->u(Lzu4;Lc98;)V

    sget-object v1, Lqu4;->d:Lja0;

    invoke-static {v4, v1, v5}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v1, Laf0;->P:Laf0;

    invoke-static {v1, v4}, Lcom/anthropic/claude/design/icon/a;->a(Laf0;Lzu4;)Lj7d;

    move-result-object v17

    invoke-static {v4}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v1, v1, Lgw3;->O:J

    invoke-static {v6, v3}, Landroidx/compose/foundation/layout/b;->n(Lt7c;F)Lt7c;

    move-result-object v19

    const/16 v23, 0x1b8

    const/16 v24, 0x0

    const/16 v18, 0x0

    move-wide/from16 v20, v1

    move-object/from16 v22, v4

    invoke-static/range {v17 .. v24}, Ll69;->b(Lj7d;Ljava/lang/String;Lt7c;JLzu4;II)V

    invoke-static {v6, v7}, Landroidx/compose/foundation/layout/b;->s(Lt7c;F)Lt7c;

    move-result-object v1

    invoke-static {v4, v1}, Lbo9;->i(Lzu4;Lt7c;)V

    invoke-static {v4}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v1

    iget-object v1, v1, Lkx3;->e:Lhk0;

    iget-object v1, v1, Lhk0;->E:Ljava/lang/Object;

    check-cast v1, Ljx3;

    iget-object v1, v1, Ljx3;->P:Ljava/lang/Object;

    move-object/from16 v36, v1

    check-cast v36, Liai;

    invoke-static {v4}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v1

    iget-wide v1, v1, Lgw3;->O:J

    const/16 v39, 0x0

    const v40, 0x1fffa

    iget-object v0, v0, Lar;->F:Ljava/lang/String;

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v38, 0x0

    move-object/from16 v17, v0

    move-wide/from16 v19, v1

    move-object/from16 v37, v4

    invoke-static/range {v17 .. v40}, Li9i;->b(Ljava/lang/String;Lt7c;JJLf58;Lz38;JLi4i;Lv2i;JIZIILc98;Liai;Lzu4;III)V

    invoke-virtual {v4, v12}, Leb8;->q(Z)V

    goto :goto_a58

    :cond_a55
    invoke-virtual {v4}, Leb8;->Z()V

    :goto_a58
    return-object v16

    nop

    :pswitch_data_a5a
    .packed-switch 0x0
        :pswitch_959  #00000000
        :pswitch_8ce  #00000001
        :pswitch_82c  #00000002
        :pswitch_76b  #00000003
        :pswitch_6fa  #00000004
        :pswitch_669  #00000005
        :pswitch_626  #00000006
        :pswitch_58f  #00000007
        :pswitch_524  #00000008
        :pswitch_4c8  #00000009
        :pswitch_471  #0000000a
        :pswitch_41a  #0000000b
        :pswitch_3cb  #0000000c
        :pswitch_374  #0000000d
        :pswitch_2ec  #0000000e
        :pswitch_295  #0000000f
        :pswitch_218  #00000010
        :pswitch_1b5  #00000011
        :pswitch_15b  #00000012
        :pswitch_108  #00000013
        :pswitch_b1  #00000014
        :pswitch_6f  #00000015
    .end packed-switch
.end method
