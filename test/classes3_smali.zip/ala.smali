.class public final Lala;
.super Lf0;
.source "SourceFile"


# instance fields
.field public final a:Lyka;

.field public b:Z

.field public c:I


# direct methods
.method public constructor <init>(Lyka;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lala;->a:Lyka;

    return-void
.end method

.method public static j(Ljava/lang/CharSequence;IIZ)Lzka;
    .registers 14

    invoke-interface {p0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/16 v1, 0x2a

    const/16 v2, 0x20

    const/16 v3, 0x9

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v0, v1, :cond_67

    const/16 v1, 0x2b

    if-eq v0, v1, :cond_67

    const/16 v1, 0x2d

    if-eq v0, v1, :cond_67

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    move v1, p1

    move v7, v4

    :goto_1d
    if-ge v1, v0, :cond_65

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v8

    const/16 v9, 0x29

    if-eq v8, v9, :cond_37

    const/16 v9, 0x2e

    if-eq v8, v9, :cond_37

    packed-switch v8, :pswitch_data_ca

    goto :goto_65

    :pswitch_2f  #0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39
    add-int/lit8 v7, v7, 0x1

    if-le v7, v3, :cond_34

    goto :goto_65

    :cond_34
    add-int/lit8 v1, v1, 0x1

    goto :goto_1d

    :cond_37
    if-lt v7, v6, :cond_65

    add-int/lit8 v0, v1, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-ge v0, v7, :cond_4a

    invoke-interface {p0, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v7

    if-eq v7, v3, :cond_4a

    if-eq v7, v2, :cond_4a

    goto :goto_65

    :cond_4a
    invoke-interface {p0, p1, v1}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v7, Ln1d;

    invoke-direct {v7}, Ltmc;-><init>()V

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, v7, Ln1d;->h:I

    iput-char v8, v7, Ln1d;->i:C

    new-instance v1, Lzka;

    invoke-direct {v1, v7, v0}, Lzka;-><init>(Lyka;I)V

    goto :goto_85

    :cond_65
    :goto_65
    move-object v1, v5

    goto :goto_85

    :cond_67
    add-int/lit8 v1, p1, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-ge v1, v7, :cond_78

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v7

    if-eq v7, v3, :cond_78

    if-eq v7, v2, :cond_78

    goto :goto_65

    :cond_78
    new-instance v7, Lb62;

    invoke-direct {v7}, Ltmc;-><init>()V

    iput-char v0, v7, Lb62;->h:C

    new-instance v0, Lzka;

    invoke-direct {v0, v7, v1}, Lzka;-><init>(Lyka;I)V

    move-object v1, v0

    :goto_85
    if-nez v1, :cond_88

    goto :goto_bb

    :cond_88
    iget-object v0, v1, Lzka;->a:Lyka;

    iget v1, v1, Lzka;->b:I

    sub-int p1, v1, p1

    add-int/2addr p1, p2

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p2

    move v7, p1

    :goto_94
    const/4 v8, 0x4

    if-ge v1, p2, :cond_ab

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v9

    if-ne v9, v3, :cond_a3

    rem-int/lit8 v9, v7, 0x4

    sub-int/2addr v8, v9

    add-int/2addr v8, v7

    move v7, v8

    goto :goto_a7

    :cond_a3
    if-ne v9, v2, :cond_aa

    add-int/lit8 v7, v7, 0x1

    :goto_a7
    add-int/lit8 v1, v1, 0x1

    goto :goto_94

    :cond_aa
    move v4, v6

    :cond_ab
    if-eqz p3, :cond_bc

    instance-of p0, v0, Ln1d;

    if-eqz p0, :cond_b9

    move-object p0, v0

    check-cast p0, Ln1d;

    iget p0, p0, Ln1d;->h:I

    if-eq p0, v6, :cond_b9

    goto :goto_bb

    :cond_b9
    if-nez v4, :cond_bc

    :goto_bb
    return-object v5

    :cond_bc
    if-eqz v4, :cond_c2

    sub-int p0, v7, p1

    if-le p0, v8, :cond_c4

    :cond_c2
    add-int/lit8 v7, p1, 0x1

    :cond_c4
    new-instance p0, Lzka;

    invoke-direct {p0, v0, v7}, Lzka;-><init>(Lyka;I)V

    return-object p0

    :pswitch_data_ca
    .packed-switch 0x30
        :pswitch_2f  #00000030
        :pswitch_2f  #00000031
        :pswitch_2f  #00000032
        :pswitch_2f  #00000033
        :pswitch_2f  #00000034
        :pswitch_2f  #00000035
        :pswitch_2f  #00000036
        :pswitch_2f  #00000037
        :pswitch_2f  #00000038
        :pswitch_2f  #00000039
    .end packed-switch
.end method

.method public static k(Lyka;Lyka;)Z
    .registers 3

    instance-of v0, p0, Lb62;

    if-eqz v0, :cond_1d

    instance-of v0, p1, Lb62;

    if-eqz v0, :cond_1d

    check-cast p0, Lb62;

    iget-char p0, p0, Lb62;->h:C

    invoke-static {p0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p0

    check-cast p1, Lb62;

    iget-char p1, p1, Lb62;->h:C

    invoke-static {p1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_1d
    instance-of v0, p0, Ln1d;

    if-eqz v0, :cond_3a

    instance-of v0, p1, Ln1d;

    if-eqz v0, :cond_3a

    check-cast p0, Ln1d;

    iget-char p0, p0, Ln1d;->i:C

    invoke-static {p0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p0

    check-cast p1, Ln1d;

    iget-char p1, p1, Ln1d;->i:C

    invoke-static {p1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_3a
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final c(Lex1;)Z
    .registers 4

    instance-of p1, p1, Llma;

    const/4 v0, 0x0

    if-eqz p1, :cond_15

    iget-boolean p1, p0, Lala;->b:Z

    const/4 v1, 0x1

    if-eqz p1, :cond_14

    iget p1, p0, Lala;->c:I

    if-ne p1, v1, :cond_14

    iget-object p1, p0, Lala;->a:Lyka;

    iput-boolean v0, p1, Lyka;->g:Z

    iput-boolean v0, p0, Lala;->b:Z

    :cond_14
    return v1

    :cond_15
    return v0
.end method

.method public final f()Lex1;
    .registers 1

    iget-object p0, p0, Lala;->a:Lyka;

    return-object p0
.end method

.method public final g()Z
    .registers 1

    const/4 p0, 0x1

    return p0
.end method

.method public final i(Lzi6;)Lfx1;
    .registers 4

    iget-boolean v0, p1, Lzi6;->i:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_b

    iput-boolean v1, p0, Lala;->b:Z

    const/4 v0, 0x0

    iput v0, p0, Lala;->c:I

    goto :goto_14

    :cond_b
    iget-boolean v0, p0, Lala;->b:Z

    if-eqz v0, :cond_14

    iget v0, p0, Lala;->c:I

    add-int/2addr v0, v1

    iput v0, p0, Lala;->c:I

    :cond_14
    :goto_14
    iget p0, p1, Lzi6;->c:I

    invoke-static {p0}, Lfx1;->a(I)Lfx1;

    move-result-object p0

    return-object p0
.end method
