.class public abstract Lb9l;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljs4;

.field public static final b:Ljs4;

.field public static final c:Ljs4;

.field public static final d:Ljs4;

.field public static final e:Ljs4;

.field public static final f:Ljs4;

.field public static final g:Ljs4;

.field public static final h:Ljs4;

.field public static final i:Ljs4;

.field public static final j:Ljs4;

.field public static final k:Ljs4;

.field public static final l:Ljs4;

.field public static final m:Ljs4;

.field public static final n:Ljs4;

.field public static final o:Ljs4;

.field public static final p:Ljs4;

.field public static final q:Ljs4;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lus4;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lus4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x7febf194

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->a:Ljs4;

    new-instance v0, Lus4;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lus4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, 0x4509720b

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->b:Ljs4;

    new-instance v0, Lus4;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Lus4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x310bc6b7

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->c:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0xb

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x5b30f74b

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->d:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x4ab6f64a

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->e:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x52c0668f

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->f:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0xe

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x56e239dd

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->g:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x165b1426

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->h:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, 0x4192d9da

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->i:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0x11

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, 0x3c923bb6

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->j:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0x12

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x601c5f65

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->k:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0x13

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x651cfd89

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->l:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, 0x201bf71c

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->m:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0x15

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x451bb5ed

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->n:Ljs4;

    new-instance v0, Lqs4;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, Lqs4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, -0x57ede29f

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->o:Ljs4;

    new-instance v0, Lus4;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lus4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, 0x4aca5305  # 6629762.5f

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->p:Ljs4;

    new-instance v0, Lus4;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lus4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, 0x1b4b5da3

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    sput-object v1, Lb9l;->q:Ljs4;

    new-instance v0, Lus4;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Lus4;-><init>(I)V

    new-instance v1, Ljs4;

    const v2, 0x79af2520

    invoke-direct {v1, v2, v3, v0}, Ljs4;-><init>(IZLr98;)V

    return-void
.end method

.method public static final a(FIIILc30;Lpu1;Ljs4;Lzu4;Lt7c;Lhhc;Lz5d;Lh6d;Lx6d;Lp6h;Lu6h;Z)V
    .registers 60

    move/from16 v3, p0

    move/from16 v7, p1

    move/from16 v14, p2

    move/from16 v15, p3

    move-object/from16 v11, p5

    move-object/from16 v12, p8

    move-object/from16 v0, p9

    move-object/from16 v2, p10

    move-object/from16 v4, p11

    move-object/from16 v1, p12

    move-object/from16 v5, p13

    move-object/from16 v9, p14

    move/from16 v6, p15

    sget-object v8, Luwa;->T:Lou1;

    move-object/from16 v10, p7

    check-cast v10, Leb8;

    const v13, -0x22247a99

    invoke-virtual {v10, v13}, Leb8;->i0(I)Leb8;

    and-int/lit8 v13, v14, 0x6

    move/from16 p7, v13

    if-nez p7, :cond_3a

    invoke-virtual {v10, v12}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_35

    const/16 v17, 0x4

    goto :goto_37

    :cond_35
    const/16 v17, 0x2

    :goto_37
    or-int v17, v14, v17

    goto :goto_3c

    :cond_3a
    move/from16 v17, v14

    :goto_3c
    and-int/lit8 v18, v14, 0x30

    const/16 v19, 0x10

    if-nez v18, :cond_4f

    invoke-virtual {v10, v1}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_4b

    const/16 v18, 0x20

    goto :goto_4d

    :cond_4b
    move/from16 v18, v19

    :goto_4d
    or-int v17, v17, v18

    :cond_4f
    and-int/lit16 v13, v14, 0x180

    const/16 v20, 0x80

    move/from16 v21, v13

    if-nez v21, :cond_64

    invoke-virtual {v10, v2}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_60

    const/16 v21, 0x100

    goto :goto_62

    :cond_60
    move/from16 v21, v20

    :goto_62
    or-int v17, v17, v21

    :cond_64
    and-int/lit16 v13, v14, 0xc00

    const/16 v22, 0x400

    move/from16 v23, v13

    const/4 v13, 0x0

    if-nez v23, :cond_7a

    invoke-virtual {v10, v13}, Leb8;->g(Z)Z

    move-result v23

    if-eqz v23, :cond_76

    const/16 v23, 0x800

    goto :goto_78

    :cond_76
    move/from16 v23, v22

    :goto_78
    or-int v17, v17, v23

    :cond_7a
    and-int/lit16 v13, v14, 0x6000

    const/16 v24, 0x2000

    const/4 v12, 0x1

    if-nez v13, :cond_8e

    invoke-virtual {v10, v12}, Leb8;->d(I)Z

    move-result v13

    if-eqz v13, :cond_8a

    const/16 v13, 0x4000

    goto :goto_8c

    :cond_8a
    move/from16 v13, v24

    :goto_8c
    or-int v17, v17, v13

    :cond_8e
    const/high16 v13, 0x30000

    and-int v26, v14, v13

    const/high16 v27, 0x10000

    move/from16 v28, v13

    if-nez v26, :cond_a5

    invoke-virtual {v10, v5}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v26

    if-eqz v26, :cond_a1

    const/high16 v26, 0x20000

    goto :goto_a3

    :cond_a1
    move/from16 v26, v27

    :goto_a3
    or-int v17, v17, v26

    :cond_a5
    const/high16 v26, 0x180000

    and-int v29, v14, v26

    const/high16 v30, 0x80000

    if-nez v29, :cond_ba

    invoke-virtual {v10, v6}, Leb8;->g(Z)Z

    move-result v29

    if-eqz v29, :cond_b6

    const/high16 v29, 0x100000

    goto :goto_b8

    :cond_b6
    move/from16 v29, v30

    :goto_b8
    or-int v17, v17, v29

    :cond_ba
    const/high16 v29, 0xc00000

    and-int v31, v14, v29

    move-object/from16 v13, p4

    if-nez v31, :cond_cf

    invoke-virtual {v10, v13}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v32

    if-eqz v32, :cond_cb

    const/high16 v32, 0x800000

    goto :goto_cd

    :cond_cb
    const/high16 v32, 0x400000

    :goto_cd
    or-int v17, v17, v32

    :cond_cf
    const/high16 v32, 0x6000000

    and-int v33, v14, v32

    if-nez v33, :cond_e2

    invoke-virtual {v10, v7}, Leb8;->d(I)Z

    move-result v33

    if-eqz v33, :cond_de

    const/high16 v33, 0x4000000

    goto :goto_e0

    :cond_de
    const/high16 v33, 0x2000000

    :goto_e0
    or-int v17, v17, v33

    :cond_e2
    const/high16 v33, 0x30000000

    and-int v35, v14, v33

    if-nez v35, :cond_f5

    invoke-virtual {v10, v3}, Leb8;->c(F)Z

    move-result v35

    if-eqz v35, :cond_f1

    const/high16 v35, 0x20000000

    goto :goto_f3

    :cond_f1
    const/high16 v35, 0x10000000

    :goto_f3
    or-int v17, v17, v35

    :cond_f5
    and-int/lit8 v35, v15, 0x6

    if-nez v35, :cond_107

    invoke-virtual {v10, v4}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v35

    if-eqz v35, :cond_102

    const/16 v35, 0x4

    goto :goto_104

    :cond_102
    const/16 v35, 0x2

    :goto_104
    or-int v35, v15, v35

    goto :goto_109

    :cond_107
    move/from16 v35, v15

    :goto_109
    and-int/lit8 v36, v15, 0x30

    if-nez v36, :cond_117

    invoke-virtual {v10, v0}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v36

    if-eqz v36, :cond_115

    const/16 v19, 0x20

    :cond_115
    or-int v35, v35, v19

    :cond_117
    and-int/lit16 v12, v15, 0x180

    move/from16 v36, v12

    const/4 v12, 0x0

    if-nez v36, :cond_128

    invoke-virtual {v10, v12}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v36

    if-eqz v36, :cond_126

    const/16 v20, 0x100

    :cond_126
    or-int v35, v35, v20

    :cond_128
    and-int/lit16 v12, v15, 0xc00

    if-nez v12, :cond_136

    invoke-virtual {v10, v8}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_134

    const/16 v22, 0x800

    :cond_134
    or-int v35, v35, v22

    :cond_136
    and-int/lit16 v12, v15, 0x6000

    if-nez v12, :cond_144

    invoke-virtual {v10, v11}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_142

    const/16 v24, 0x4000

    :cond_142
    or-int v35, v35, v24

    :cond_144
    and-int v12, v15, v28

    if-nez v12, :cond_152

    invoke-virtual {v10, v9}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_150

    const/high16 v27, 0x20000

    :cond_150
    or-int v35, v35, v27

    :cond_152
    and-int v12, v15, v26

    if-nez v12, :cond_165

    move-object/from16 v12, p6

    invoke-virtual {v10, v12}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v22

    if-eqz v22, :cond_160

    const/high16 v30, 0x100000

    :cond_160
    or-int v35, v35, v30

    :goto_162
    move/from16 v0, v35

    goto :goto_168

    :cond_165
    move-object/from16 v12, p6

    goto :goto_162

    :goto_168
    const v22, 0x12492493

    and-int v5, v17, v22

    const v6, 0x12492492

    if-ne v5, v6, :cond_17e

    const v5, 0x92493

    and-int/2addr v5, v0

    const v6, 0x92492

    if-eq v5, v6, :cond_17c

    goto :goto_17e

    :cond_17c
    const/4 v5, 0x0

    goto :goto_17f

    :cond_17e
    :goto_17e
    const/4 v5, 0x1

    :goto_17f
    and-int/lit8 v6, v17, 0x1

    invoke-virtual {v10, v6, v5}, Leb8;->W(IZ)Z

    move-result v5

    if-eqz v5, :cond_50d

    if-ltz v7, :cond_18a

    goto :goto_19b

    :cond_18a
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "beyondViewportPageCount should be greater than or equal to 0, you selected "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lgf9;->a(Ljava/lang/String;)V

    :goto_19b
    and-int/lit8 v5, v17, 0x70

    const/16 v6, 0x20

    if-ne v5, v6, :cond_1a3

    const/4 v6, 0x1

    goto :goto_1a4

    :cond_1a3
    const/4 v6, 0x0

    :goto_1a4
    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v13

    sget-object v14, Lxu4;->a:Lmx8;

    if-nez v6, :cond_1ae

    if-ne v13, v14, :cond_1b7

    :cond_1ae
    new-instance v13, Lz79;

    const/4 v6, 0x1

    invoke-direct {v13, v1, v6}, Lz79;-><init>(Lx6d;I)V

    invoke-virtual {v10, v13}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_1b7
    check-cast v13, La98;

    shr-int/lit8 v24, v17, 0x3

    and-int/lit8 v27, v24, 0xe

    shr-int/lit8 v6, v0, 0xf

    and-int/lit8 v30, v6, 0x70

    or-int v30, v27, v30

    move/from16 v35, v6

    and-int/lit16 v6, v0, 0x380

    or-int v6, v30, v6

    move/from16 v30, v0

    invoke-static {v12, v10}, Lao9;->e0(Ljava/lang/Object;Lzu4;)Laec;

    move-result-object v0

    move/from16 v36, v6

    const/4 v6, 0x0

    invoke-static {v6, v10}, Lao9;->e0(Ljava/lang/Object;Lzu4;)Laec;

    move-result-object v12

    and-int/lit8 v6, v36, 0xe

    xor-int/lit8 v6, v6, 0x6

    const/4 v15, 0x4

    if-le v6, v15, :cond_1e3

    invoke-virtual {v10, v1}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1e7

    :cond_1e3
    and-int/lit8 v6, v36, 0x6

    if-ne v6, v15, :cond_1e9

    :cond_1e7
    const/4 v6, 0x1

    goto :goto_1ea

    :cond_1e9
    const/4 v6, 0x0

    :goto_1ea
    invoke-virtual {v10, v0}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v15

    or-int/2addr v6, v15

    invoke-virtual {v10, v12}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v15

    or-int/2addr v6, v15

    invoke-virtual {v10, v13}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v15

    or-int/2addr v6, v15

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v15

    if-nez v6, :cond_201

    if-ne v15, v14, :cond_22b

    :cond_201
    sget-object v6, Luwa;->f0:Luwa;

    new-instance v15, Ldj2;

    invoke-direct {v15, v0, v12, v13}, Ldj2;-><init>(Laec;Laec;La98;)V

    invoke-static {v15, v6}, Lao9;->E(La98;Lm7h;)Ly76;

    move-result-object v0

    new-instance v12, Lap8;

    const/16 v13, 0xc

    invoke-direct {v12, v0, v13, v1}, Lap8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {v12, v6}, Lao9;->E(La98;Lm7h;)Ly76;

    move-result-object v40

    new-instance v36, Lkj4;

    const/16 v37, 0x0

    const/16 v38, 0x2

    const-class v39, Lghh;

    const-string v41, "value"

    const-string v42, "getValue()Ljava/lang/Object;"

    invoke-direct/range {v36 .. v42}, Lkj4;-><init>(IILjava/lang/Class;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    move-object/from16 v15, v36

    invoke-virtual {v10, v15}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_22b
    move-object v0, v15

    check-cast v0, Lg0a;

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v6

    if-ne v6, v14, :cond_23d

    sget-object v6, Lvv6;->E:Lvv6;

    invoke-static {v6, v10}, Letf;->t(Lla5;Lzu4;)Lua5;

    move-result-object v6

    invoke-virtual {v10, v6}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_23d
    check-cast v6, Lua5;

    const/16 v12, 0x20

    if-ne v5, v12, :cond_245

    const/4 v12, 0x1

    goto :goto_246

    :cond_245
    const/4 v12, 0x0

    :goto_246
    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v13

    if-nez v12, :cond_24e

    if-ne v13, v14, :cond_257

    :cond_24e
    new-instance v13, Lz79;

    const/4 v12, 0x2

    invoke-direct {v13, v1, v12}, Lz79;-><init>(Lx6d;I)V

    invoke-virtual {v10, v13}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_257
    check-cast v13, La98;

    const v12, 0xfff0

    and-int v12, v17, v12

    shr-int/lit8 v15, v17, 0x9

    const/high16 v16, 0x70000

    and-int v36, v15, v16

    or-int v12, v12, v36

    const/high16 v36, 0x380000

    and-int v15, v15, v36

    or-int/2addr v12, v15

    shl-int/lit8 v15, v30, 0x15

    const/high16 v37, 0x1c00000

    and-int v15, v15, v37

    or-int/2addr v12, v15

    shl-int/lit8 v15, v30, 0xf

    const/high16 v30, 0xe000000

    and-int v38, v15, v30

    or-int v12, v12, v38

    const/high16 v38, 0x70000000

    and-int v15, v15, v38

    or-int/2addr v12, v15

    and-int/lit8 v15, v12, 0x70

    xor-int/lit8 v15, v15, 0x30

    move-object/from16 v39, v0

    const/16 v0, 0x20

    if-le v15, v0, :cond_28f

    invoke-virtual {v10, v1}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_293

    :cond_28f
    and-int/lit8 v15, v12, 0x30

    if-ne v15, v0, :cond_295

    :cond_293
    const/4 v0, 0x1

    goto :goto_296

    :cond_295
    const/4 v0, 0x0

    :goto_296
    and-int/lit16 v15, v12, 0x380

    xor-int/lit16 v15, v15, 0x180

    move/from16 v40, v0

    const/16 v0, 0x100

    if-le v15, v0, :cond_2a6

    invoke-virtual {v10, v2}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_2aa

    :cond_2a6
    and-int/lit16 v15, v12, 0x180

    if-ne v15, v0, :cond_2ac

    :cond_2aa
    const/4 v0, 0x1

    goto :goto_2ad

    :cond_2ac
    const/4 v0, 0x0

    :goto_2ad
    or-int v0, v40, v0

    and-int/lit16 v15, v12, 0x1c00

    xor-int/lit16 v15, v15, 0xc00

    move/from16 v21, v0

    const/16 v0, 0x800

    if-le v15, v0, :cond_2c0

    const/4 v15, 0x0

    invoke-virtual {v10, v15}, Leb8;->g(Z)Z

    move-result v25

    if-nez v25, :cond_2c4

    :cond_2c0
    and-int/lit16 v15, v12, 0xc00

    if-ne v15, v0, :cond_2c6

    :cond_2c4
    const/4 v0, 0x1

    goto :goto_2c7

    :cond_2c6
    const/4 v0, 0x0

    :goto_2c7
    or-int v0, v21, v0

    const v15, 0xe000

    and-int/2addr v15, v12

    xor-int/lit16 v15, v15, 0x6000

    move/from16 v21, v0

    const/16 v0, 0x4000

    if-le v15, v0, :cond_2dd

    const/4 v15, 0x1

    invoke-virtual {v10, v15}, Leb8;->d(I)Z

    move-result v25

    if-nez v25, :cond_2e2

    goto :goto_2de

    :cond_2dd
    const/4 v15, 0x1

    :goto_2de
    and-int/lit16 v15, v12, 0x6000

    if-ne v15, v0, :cond_2e4

    :cond_2e2
    const/4 v0, 0x1

    goto :goto_2e5

    :cond_2e4
    const/4 v0, 0x0

    :goto_2e5
    or-int v0, v21, v0

    and-int v15, v12, v30

    xor-int v15, v15, v32

    move/from16 v21, v0

    const/high16 v0, 0x4000000

    if-le v15, v0, :cond_2f7

    invoke-virtual {v10, v8}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_2fb

    :cond_2f7
    and-int v8, v12, v32

    if-ne v8, v0, :cond_2fd

    :cond_2fb
    const/4 v0, 0x1

    goto :goto_2fe

    :cond_2fd
    const/4 v0, 0x0

    :goto_2fe
    or-int v0, v21, v0

    and-int v8, v12, v38

    xor-int v8, v8, v33

    const/high16 v15, 0x20000000

    if-le v8, v15, :cond_30e

    invoke-virtual {v10, v11}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_312

    :cond_30e
    and-int v8, v12, v33

    if-ne v8, v15, :cond_314

    :cond_312
    const/4 v8, 0x1

    goto :goto_315

    :cond_314
    const/4 v8, 0x0

    :goto_315
    or-int/2addr v0, v8

    and-int v8, v12, v36

    xor-int v8, v8, v26

    const/high16 v15, 0x100000

    if-le v8, v15, :cond_324

    invoke-virtual {v10, v3}, Leb8;->c(F)Z

    move-result v8

    if-nez v8, :cond_328

    :cond_324
    and-int v8, v12, v26

    if-ne v8, v15, :cond_32a

    :cond_328
    const/4 v8, 0x1

    goto :goto_32b

    :cond_32a
    const/4 v8, 0x0

    :goto_32b
    or-int/2addr v0, v8

    and-int v8, v12, v37

    xor-int v8, v8, v29

    const/high16 v15, 0x800000

    if-le v8, v15, :cond_33a

    invoke-virtual {v10, v4}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_33e

    :cond_33a
    and-int v8, v12, v29

    if-ne v8, v15, :cond_340

    :cond_33e
    const/4 v8, 0x1

    goto :goto_341

    :cond_340
    const/4 v8, 0x0

    :goto_341
    or-int/2addr v0, v8

    and-int/lit8 v8, v35, 0xe

    xor-int/lit8 v8, v8, 0x6

    const/4 v15, 0x4

    if-le v8, v15, :cond_34f

    invoke-virtual {v10, v9}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_353

    :cond_34f
    and-int/lit8 v8, v35, 0x6

    if-ne v8, v15, :cond_355

    :cond_353
    const/4 v8, 0x1

    goto :goto_356

    :cond_355
    const/4 v8, 0x0

    :goto_356
    or-int/2addr v0, v8

    invoke-virtual {v10, v13}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v8

    or-int/2addr v0, v8

    and-int v8, v12, v16

    xor-int v8, v8, v28

    const/high16 v15, 0x20000

    if-le v8, v15, :cond_36a

    invoke-virtual {v10, v7}, Leb8;->d(I)Z

    move-result v8

    if-nez v8, :cond_36e

    :cond_36a
    and-int v8, v12, v28

    if-ne v8, v15, :cond_370

    :cond_36e
    const/4 v8, 0x1

    goto :goto_371

    :cond_370
    const/4 v8, 0x0

    :goto_371
    or-int/2addr v0, v8

    invoke-virtual {v10, v6}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v8

    or-int/2addr v0, v8

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v8

    if-nez v0, :cond_38c

    if-ne v8, v14, :cond_380

    goto :goto_38c

    :cond_380
    move-object/from16 v11, p9

    move-object/from16 v12, p13

    move v15, v5

    move v9, v7

    move-object v13, v10

    move-object v10, v6

    move-object v6, v1

    move-object/from16 v1, v39

    goto :goto_3a5

    :cond_38c
    :goto_38c
    new-instance v0, Lo6d;

    move-object v8, v10

    move-object v10, v6

    move-object v6, v13

    move-object v13, v8

    move-object/from16 v12, p13

    move v15, v5

    move v8, v7

    move-object v7, v11

    move-object/from16 v5, v39

    move-object/from16 v11, p9

    invoke-direct/range {v0 .. v10}, Lo6d;-><init>(Lx6d;Lz5d;FLh6d;Lg0a;La98;Lpu1;ILu6h;Lua5;)V

    move-object v6, v1

    move-object v1, v5

    move v9, v8

    invoke-virtual {v13, v0}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v8, v0

    :goto_3a5
    move-object/from16 v19, v8

    check-cast v19, Lica;

    xor-int/lit8 v0, v27, 0x6

    const/4 v2, 0x4

    if-le v0, v2, :cond_3b4

    invoke-virtual {v13, v6}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3b8

    :cond_3b4
    and-int/lit8 v0, v24, 0x6

    if-ne v0, v2, :cond_3bc

    :cond_3b8
    const/16 v22, 0x1

    :goto_3ba
    const/4 v0, 0x0

    goto :goto_3bf

    :cond_3bc
    const/16 v22, 0x0

    goto :goto_3ba

    :goto_3bf
    invoke-virtual {v13, v0}, Leb8;->g(Z)Z

    move-result v2

    or-int v2, v22, v2

    invoke-virtual {v13}, Leb8;->R()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_3cd

    if-ne v3, v14, :cond_3d5

    :cond_3cd
    new-instance v3, Lxca;

    invoke-direct {v3, v6, v0}, Lxca;-><init>(Lx6d;Z)V

    invoke-virtual {v13, v3}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_3d5
    move-object v2, v3

    check-cast v2, Lwca;

    const/16 v0, 0x20

    if-ne v15, v0, :cond_3de

    const/4 v0, 0x1

    goto :goto_3df

    :cond_3de
    const/4 v0, 0x0

    :goto_3df
    and-int v3, v17, v16

    const/high16 v4, 0x20000

    if-ne v3, v4, :cond_3e7

    const/4 v3, 0x1

    goto :goto_3e8

    :cond_3e7
    const/4 v3, 0x0

    :goto_3e8
    or-int/2addr v0, v3

    invoke-virtual {v13}, Leb8;->R()Ljava/lang/Object;

    move-result-object v3

    if-nez v0, :cond_3f1

    if-ne v3, v14, :cond_3f9

    :cond_3f1
    new-instance v3, Lb7d;

    invoke-direct {v3, v12, v6}, Lb7d;-><init>(Lp6h;Lx6d;)V

    invoke-virtual {v13, v3}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_3f9
    move-object v7, v3

    check-cast v7, Lb7d;

    sget-object v0, Ly32;->a:Lnw4;

    invoke-virtual {v13, v0}, Leb8;->j(Ldge;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lw32;

    sget-object v3, Llw4;->n:Lfih;

    invoke-virtual {v13, v3}, Leb8;->j(Ldge;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lf7a;

    const v4, -0x32e58e40

    invoke-virtual {v13, v4}, Leb8;->g0(I)V

    const/16 v4, 0x20

    if-ne v15, v4, :cond_418

    const/4 v4, 0x1

    goto :goto_419

    :cond_418
    const/4 v4, 0x0

    :goto_419
    invoke-virtual {v13, v0}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v4, v5

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    invoke-virtual {v13, v5}, Leb8;->d(I)Z

    move-result v5

    or-int/2addr v4, v5

    invoke-virtual {v13}, Leb8;->R()Ljava/lang/Object;

    move-result-object v5

    if-nez v4, :cond_42f

    if-ne v5, v14, :cond_437

    :cond_42f
    new-instance v5, Lj6d;

    invoke-direct {v5, v6, v0, v3}, Lj6d;-><init>(Lx6d;Lw32;Lf7a;)V

    invoke-virtual {v13, v5}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_437
    move-object v8, v5

    check-cast v8, Lj6d;

    const/4 v0, 0x0

    invoke-virtual {v13, v0}, Leb8;->q(Z)V

    sget-object v15, Lq7c;->E:Lq7c;

    sget-object v3, Lg3d;->F:Lg3d;

    if-eqz p15, :cond_49d

    const v0, -0x32df239d

    invoke-virtual {v13, v0}, Leb8;->g0(I)V

    shr-int/lit8 v0, v17, 0x15

    and-int/lit8 v0, v0, 0x70

    or-int v0, v27, v0

    and-int/lit8 v4, v0, 0xe

    xor-int/lit8 v4, v4, 0x6

    const/4 v5, 0x4

    if-le v4, v5, :cond_45d

    invoke-virtual {v13, v6}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_461

    :cond_45d
    and-int/lit8 v4, v0, 0x6

    if-ne v4, v5, :cond_463

    :cond_461
    const/4 v4, 0x1

    goto :goto_464

    :cond_463
    const/4 v4, 0x0

    :goto_464
    and-int/lit8 v5, v0, 0x70

    xor-int/lit8 v5, v5, 0x30

    move/from16 p7, v0

    const/16 v0, 0x20

    if-le v5, v0, :cond_474

    invoke-virtual {v13, v9}, Leb8;->d(I)Z

    move-result v5

    if-nez v5, :cond_478

    :cond_474
    and-int/lit8 v5, p7, 0x30

    if-ne v5, v0, :cond_47b

    :cond_478
    const/16 v34, 0x1

    goto :goto_47d

    :cond_47b
    const/16 v34, 0x0

    :goto_47d
    or-int v0, v4, v34

    invoke-virtual {v13}, Leb8;->R()Ljava/lang/Object;

    move-result-object v4

    if-nez v0, :cond_487

    if-ne v4, v14, :cond_48f

    :cond_487
    new-instance v4, Li6d;

    invoke-direct {v4, v6, v9}, Li6d;-><init>(Lx6d;I)V

    invoke-virtual {v13, v4}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_48f
    check-cast v4, Li6d;

    iget-object v0, v6, Lx6d;->w:Lxcg;

    const/4 v5, 0x0

    invoke-static {v4, v0, v5, v3}, Lgpd;->C(Ltba;Lxcg;ZLg3d;)Lt7c;

    move-result-object v0

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Leb8;->q(Z)V

    goto :goto_4a9

    :cond_49d
    const/4 v5, 0x0

    const/4 v14, 0x0

    const v0, -0x32d894c5

    invoke-virtual {v13, v0}, Leb8;->g0(I)V

    invoke-virtual {v13, v14}, Leb8;->q(Z)V

    move-object v0, v15

    :goto_4a9
    iget-object v4, v6, Lx6d;->z:Lfaa;

    move-object/from16 v14, p8

    invoke-interface {v14, v4}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v4

    iget-object v5, v6, Lx6d;->x:Lmd1;

    invoke-interface {v4, v5}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v4

    move-object/from16 p7, v7

    const/4 v5, 0x0

    move-object v7, v0

    move-object v0, v4

    move/from16 v4, p15

    invoke-static/range {v0 .. v5}, Letf;->R(Lt7c;Lg0a;Lwca;Lg3d;ZZ)Lt7c;

    move-result-object v0

    move-object/from16 v39, v1

    move-object v2, v3

    if-eqz p15, :cond_4d7

    new-instance v1, Lhj2;

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v1, v4, v6, v10, v3}, Lhj2;-><init>(ZLjava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v1, v15, v4}, Lkag;->b(Lc98;Lt7c;Z)Lt7c;

    move-result-object v1

    invoke-interface {v0, v1}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v0

    goto :goto_4dc

    :cond_4d7
    const/4 v4, 0x0

    invoke-interface {v0, v15}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v0

    :goto_4dc
    invoke-interface {v0, v7}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v0

    iget-object v7, v6, Lx6d;->p:Lncc;

    move-object/from16 v3, p4

    move v10, v4

    move-object v1, v6

    move-object/from16 v6, p7

    move/from16 v4, p15

    invoke-static/range {v0 .. v8}, Ltlc;->K(Lt7c;Ly0g;Lg3d;Lc30;ZZLly7;Lncc;Lj6d;)Lt7c;

    move-result-object v0

    move-object v6, v1

    new-instance v1, Lnca;

    invoke-direct {v1, v10, v6}, Lnca;-><init>(ILjava/lang/Object;)V

    invoke-static {v15, v6, v1}, Ldvh;->b(Lt7c;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Lt7c;

    move-result-object v1

    invoke-interface {v0, v1}, Lt7c;->B(Lt7c;)Lt7c;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v11, v1}, Lgk5;->f(Lt7c;Lhhc;Lkhc;)Lt7c;

    move-result-object v1

    iget-object v2, v6, Lx6d;->u:Ltca;

    const/4 v5, 0x0

    move-object v4, v13

    move-object/from16 v3, v19

    move-object/from16 v0, v39

    invoke-static/range {v0 .. v5}, Lin6;->c(La98;Lt7c;Ltca;Lica;Lzu4;I)V

    goto :goto_519

    :cond_50d
    move-object/from16 v14, p8

    move-object/from16 v11, p9

    move-object/from16 v12, p13

    move-object v6, v1

    move v9, v7

    move-object v4, v10

    invoke-virtual {v4}, Leb8;->Z()V

    :goto_519
    invoke-virtual {v4}, Leb8;->u()Lque;

    move-result-object v0

    if-eqz v0, :cond_544

    move-object v1, v0

    new-instance v0, Lmca;

    move/from16 v8, p0

    move/from16 v15, p3

    move-object/from16 v13, p6

    move-object/from16 v3, p10

    move/from16 v5, p15

    move-object/from16 v43, v1

    move-object v2, v6

    move v7, v9

    move-object v10, v11

    move-object v4, v12

    move-object v1, v14

    move/from16 v14, p2

    move-object/from16 v6, p4

    move-object/from16 v11, p5

    move-object/from16 v9, p11

    move-object/from16 v12, p14

    invoke-direct/range {v0 .. v15}, Lmca;-><init>(Lt7c;Lx6d;Lz5d;Lp6h;ZLc30;IFLh6d;Lhhc;Lpu1;Lu6h;Ljs4;II)V

    move-object/from16 v1, v43

    iput-object v0, v1, Lque;->d:Lq98;

    :cond_544
    return-void
.end method

.method public static final b(Lj7d;Lt7c;JLz5d;JLzu4;II)V
    .registers 28

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v5, p7

    check-cast v5, Leb8;

    const v0, 0x725a3262

    invoke-virtual {v5, v0}, Leb8;->i0(I)Leb8;

    move-object/from16 v7, p0

    invoke-virtual {v5, v7}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x2

    if-eqz v0, :cond_18

    const/4 v0, 0x4

    goto :goto_19

    :cond_18
    move v0, v1

    :goto_19
    or-int v0, p8, v0

    or-int/lit8 v0, v0, 0x30

    move-wide/from16 v9, p2

    invoke-virtual {v5, v9, v10}, Leb8;->e(J)Z

    move-result v2

    if-eqz v2, :cond_28

    const/16 v2, 0x100

    goto :goto_2a

    :cond_28
    const/16 v2, 0x80

    :goto_2a
    or-int/2addr v0, v2

    and-int/lit8 v2, p9, 0x8

    if-nez v2, :cond_3a

    move-object/from16 v2, p4

    invoke-virtual {v5, v2}, Leb8;->f(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3c

    const/16 v3, 0x800

    goto :goto_3e

    :cond_3a
    move-object/from16 v2, p4

    :cond_3c
    const/16 v3, 0x400

    :goto_3e
    or-int/2addr v0, v3

    and-int/lit8 v3, p9, 0x10

    if-nez v3, :cond_4e

    move-wide/from16 v3, p5

    invoke-virtual {v5, v3, v4}, Leb8;->e(J)Z

    move-result v6

    if-eqz v6, :cond_50

    const/16 v6, 0x4000

    goto :goto_52

    :cond_4e
    move-wide/from16 v3, p5

    :cond_50
    const/16 v6, 0x2000

    :goto_52
    or-int/2addr v0, v6

    and-int/lit16 v6, v0, 0x2493

    const/16 v8, 0x2492

    const/4 v11, 0x0

    if-eq v6, v8, :cond_5c

    const/4 v6, 0x1

    goto :goto_5d

    :cond_5c
    move v6, v11

    :goto_5d
    and-int/lit8 v8, v0, 0x1

    invoke-virtual {v5, v8, v6}, Leb8;->W(IZ)Z

    move-result v6

    if-eqz v6, :cond_141

    invoke-virtual {v5}, Leb8;->b0()V

    and-int/lit8 v6, p8, 0x1

    sget-object v8, Lq7c;->E:Lq7c;

    const v13, -0xe001

    const/4 v14, 0x0

    if-eqz v6, :cond_8c

    invoke-virtual {v5}, Leb8;->C()Z

    move-result v6

    if-eqz v6, :cond_79

    goto :goto_8c

    :cond_79
    invoke-virtual {v5}, Leb8;->Z()V

    and-int/lit8 v6, p9, 0x8

    if-eqz v6, :cond_82

    and-int/lit16 v0, v0, -0x1c01

    :cond_82
    and-int/lit8 v6, p9, 0x10

    if-eqz v6, :cond_87

    and-int/2addr v0, v13

    :cond_87
    move-object/from16 v13, p1

    move-object v15, v2

    move-wide v2, v3

    goto :goto_b8

    :cond_8c
    :goto_8c
    and-int/lit8 v6, p9, 0x8

    if-eqz v6, :cond_a0

    invoke-static {v14, v5}, Ld52;->B(FLzu4;)F

    move-result v2

    invoke-static {v14, v5}, Ld52;->B(FLzu4;)F

    move-result v6

    new-instance v15, Ld6d;

    invoke-direct {v15, v2, v6, v2, v6}, Ld6d;-><init>(FFFF)V

    and-int/lit16 v0, v0, -0x1c01

    goto :goto_a1

    :cond_a0
    move-object v15, v2

    :goto_a1
    and-int/lit8 v2, p9, 0x10

    if-eqz v2, :cond_b6

    const/high16 v2, 0x41c00000  # 24.0f

    invoke-static {v2, v5}, Ld52;->B(FLzu4;)F

    move-result v3

    invoke-static {v2, v5}, Ld52;->B(FLzu4;)F

    move-result v2

    invoke-static {v3, v2}, Llab;->f(FF)J

    move-result-wide v2

    and-int/2addr v0, v13

    :goto_b4
    move-object v13, v8

    goto :goto_b8

    :cond_b6
    move-wide v2, v3

    goto :goto_b4

    :goto_b8
    invoke-virtual {v5}, Leb8;->r()V

    sget-object v4, Luwa;->K:Lqu1;

    invoke-static {v5}, Lfx3;->c(Lzu4;)Lkx3;

    move-result-object v6

    iget-object v6, v6, Lkx3;->e:Lhk0;

    iget-object v6, v6, Lhk0;->E:Ljava/lang/Object;

    check-cast v6, Ljx3;

    iget-object v6, v6, Ljx3;->J:Ljava/lang/Object;

    check-cast v6, Liai;

    invoke-static {v6, v5}, Llab;->v(Liai;Lzu4;)F

    move-result v6

    invoke-static {v13, v6, v14, v1}, Landroidx/compose/foundation/layout/b;->f(Lt7c;FFI)Lt7c;

    move-result-object v1

    invoke-static {v4, v11}, Lw12;->d(Lmu;Z)Lnlb;

    move-result-object v4

    move-object v11, v13

    iget-wide v12, v5, Leb8;->T:J

    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    move-result v6

    invoke-virtual {v5}, Leb8;->l()Lnhd;

    move-result-object v12

    invoke-static {v5, v1}, Lezg;->l0(Lzu4;Lt7c;)Lt7c;

    move-result-object v1

    sget-object v13, Lru4;->e:Lqu4;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v13, Lqu4;->b:Lhw4;

    invoke-virtual {v5}, Leb8;->k0()V

    iget-boolean v14, v5, Leb8;->S:Z

    if-eqz v14, :cond_f8

    invoke-virtual {v5, v13}, Leb8;->k(La98;)V

    goto :goto_fb

    :cond_f8
    invoke-virtual {v5}, Leb8;->t0()V

    :goto_fb
    sget-object v13, Lqu4;->f:Lja0;

    invoke-static {v5, v13, v4}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v4, Lqu4;->e:Lja0;

    invoke-static {v5, v4, v12}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    sget-object v6, Lqu4;->g:Lja0;

    invoke-static {v5, v6, v4}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    sget-object v4, Lqu4;->h:Lay;

    invoke-static {v5, v4}, Lr1i;->u(Lzu4;Lc98;)V

    sget-object v4, Lqu4;->d:Lja0;

    invoke-static {v5, v4, v1}, Lr1i;->z(Lzu4;Lq98;Ljava/lang/Object;)V

    invoke-static {v8, v15}, Lik5;->J(Lt7c;Lz5d;)Lt7c;

    move-result-object v1

    invoke-static {v2, v3, v1}, Landroidx/compose/foundation/layout/b;->o(JLt7c;)Lt7c;

    move-result-object v1

    const/16 v4, 0x38

    and-int/lit8 v6, v0, 0xe

    or-int/2addr v4, v6

    shl-int/lit8 v0, v0, 0x3

    and-int/lit16 v0, v0, 0x1c00

    or-int v6, v4, v0

    const/4 v7, 0x0

    move-wide v3, v2

    move-object v2, v1

    const/4 v1, 0x0

    move-wide/from16 v16, v9

    move-wide v8, v3

    move-wide/from16 v3, v16

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v7}, Ll69;->b(Lj7d;Ljava/lang/String;Lt7c;JLzu4;II)V

    const/4 v0, 0x1

    invoke-virtual {v5, v0}, Leb8;->q(Z)V

    move-wide v12, v8

    move-object v8, v11

    move-object v11, v15

    goto :goto_148

    :cond_141
    invoke-virtual {v5}, Leb8;->Z()V

    move-object/from16 v8, p1

    move-object v11, v2

    move-wide v12, v3

    :goto_148
    invoke-virtual {v5}, Leb8;->u()Lque;

    move-result-object v0

    if-eqz v0, :cond_15d

    new-instance v6, Lat7;

    move-object/from16 v7, p0

    move-wide/from16 v9, p2

    move/from16 v14, p8

    move/from16 v15, p9

    invoke-direct/range {v6 .. v15}, Lat7;-><init>(Lj7d;Lt7c;JLz5d;JII)V

    iput-object v6, v0, Lque;->d:Lq98;

    :cond_15d
    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)I
    .registers 8

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    move-result v0

    const/4 v3, -0x1

    if-ne v0, v3, :cond_14

    goto :goto_30

    :cond_14
    invoke-static {p1}, Landroid/app/AppOpsManager;->permissionToOp(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_1d

    goto/16 :goto_83

    :cond_1d
    if-nez v2, :cond_31

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_30

    array-length v4, v2

    if-gtz v4, :cond_2d

    goto :goto_30

    :cond_2d
    aget-object v2, v2, v0

    goto :goto_31

    :cond_30
    :goto_30
    return v3

    :cond_31
    :goto_31
    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const-class v5, Landroid/app/AppOpsManager;

    if-ne v3, v1, :cond_77

    invoke-static {v4, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_77

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1d

    if-lt v3, v4, :cond_6c

    invoke-virtual {p0, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/AppOpsManager;

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v4

    const/4 v5, 0x1

    if-nez v3, :cond_58

    move v2, v5

    goto :goto_5c

    :cond_58
    invoke-virtual {v3, p1, v4, v2}, Landroid/app/AppOpsManager;->checkOpNoThrow(Ljava/lang/String;ILjava/lang/String;)I

    move-result v2

    :goto_5c
    if-eqz v2, :cond_5f

    goto :goto_81

    :cond_5f
    invoke-static {p0}, Lnf0;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    if-nez v3, :cond_66

    goto :goto_6a

    :cond_66
    invoke-virtual {v3, p1, v1, p0}, Landroid/app/AppOpsManager;->checkOpNoThrow(Ljava/lang/String;ILjava/lang/String;)I

    move-result v5

    :goto_6a
    move v2, v5

    goto :goto_81

    :cond_6c
    invoke-virtual {p0, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/AppOpsManager;

    invoke-virtual {p0, p1, v2}, Landroid/app/AppOpsManager;->noteProxyOpNoThrow(Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    goto :goto_81

    :cond_77
    invoke-virtual {p0, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/AppOpsManager;

    invoke-virtual {p0, p1, v2}, Landroid/app/AppOpsManager;->noteProxyOpNoThrow(Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    :goto_81
    if-nez v2, :cond_84

    :goto_83
    return v0

    :cond_84
    const/4 p0, -0x2

    return p0
.end method

.method public static final d(Lql2;Lml2;DLtd1;)Ljava/lang/CharSequence;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1, p2, p3}, Lql2;->a(Lml2;D)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    if-lez p1, :cond_11

    return-object p0

    :cond_11
    const-string p0, "`CartesianValueFormatter.format` returned an empty string. Use `HorizontalAxis.ItemPlacer` and `VerticalAxis.ItemPlacer`, not empty strings, to control which x and y values are labeled."

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static e(Lmu9;)Lt17;
    .registers 5

    const-string v0, "Unable to parse json into type Action"

    const/4 v1, 0x0

    :try_start_3
    const-string v2, "id"

    invoke-virtual {p0, v2}, Lmu9;->r(Ljava/lang/String;)Lwt9;

    move-result-object p0

    invoke-virtual {p0}, Lwt9;->c()Let9;

    move-result-object p0

    iget-object p0, p0, Let9;->E:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_36

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lwt9;

    invoke-virtual {v3}, Lwt9;->m()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1c

    :catch_30
    move-exception p0

    goto :goto_3c

    :catch_32
    move-exception p0

    goto :goto_40

    :catch_34
    move-exception p0

    goto :goto_44

    :cond_36
    new-instance p0, Lt17;

    invoke-direct {p0, v2}, Lt17;-><init>(Ljava/util/List;)V
    :try_end_3b
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3b} :catch_34
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_3b} :catch_32
    .catch Ljava/lang/NullPointerException; {:try_start_3 .. :try_end_3b} :catch_30

    return-object p0

    :goto_3c
    invoke-static {v0, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1

    :goto_40
    invoke-static {v0, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1

    :goto_44
    invoke-static {v0, p0}, Lgdg;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1
.end method

.method public static final f(Lzu4;)Lu7j;
    .registers 5

    sget-object v0, Lc4a;->b:Lnw4;

    check-cast p0, Leb8;

    invoke-virtual {p0, v0}, Leb8;->j(Ldge;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljyf;

    invoke-virtual {p0, v0}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {p0}, Leb8;->R()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_18

    sget-object v1, Lxu4;->a:Lmx8;

    if-ne v2, v1, :cond_21

    :cond_18
    new-instance v2, Lv7j;

    const/4 v1, 0x0

    invoke-direct {v2, v0, v1}, Lv7j;-><init>(Ljyf;I)V

    invoke-virtual {p0, v2}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_21
    check-cast v2, Lc98;

    sget-object v0, Loze;->a:Lpze;

    const-class v1, Lu7j;

    invoke-virtual {v0, v1}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v3

    invoke-static {v3}, Lckf;->N(Lky9;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v0

    invoke-static {v0, v3, v2, p0}, Law5;->U(Lky9;Ljava/lang/Object;Lc98;Lzu4;)Lqi9;

    move-result-object p0

    check-cast p0, Lu7j;

    return-object p0
.end method

.method public static final g(Lokio/SegmentedByteString;I)I
    .registers 6

    iget-object v0, p0, Lokio/SegmentedByteString;->J:[I

    add-int/lit8 p1, p1, 0x1

    iget-object p0, p0, Lokio/SegmentedByteString;->I:[[B

    array-length p0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 p0, p0, -0x1

    const/4 v1, 0x0

    :goto_d
    if-gt v1, p0, :cond_1f

    add-int v2, v1, p0

    ushr-int/lit8 v2, v2, 0x1

    aget v3, v0, v2

    if-ge v3, p1, :cond_1a

    add-int/lit8 v1, v2, 0x1

    goto :goto_d

    :cond_1a
    if-le v3, p1, :cond_22

    add-int/lit8 p0, v2, -0x1

    goto :goto_d

    :cond_1f
    neg-int p0, v1

    add-int/lit8 v2, p0, -0x1

    :cond_22
    if-ltz v2, :cond_25

    return v2

    :cond_25
    not-int p0, v2

    return p0
.end method
