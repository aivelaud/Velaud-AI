.class public final La9a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq98;


# static fields
.field public static final F:La9a;

.field public static final G:La9a;

.field public static final H:La9a;

.field public static final I:La9a;

.field public static final J:La9a;

.field public static final K:La9a;

.field public static final L:La9a;

.field public static final M:La9a;

.field public static final N:La9a;

.field public static final O:La9a;

.field public static final P:La9a;

.field public static final Q:La9a;

.field public static final R:La9a;

.field public static final S:La9a;

.field public static final T:La9a;

.field public static final U:La9a;

.field public static final V:La9a;

.field public static final W:La9a;

.field public static final X:La9a;

.field public static final Y:La9a;

.field public static final Z:La9a;

.field public static final a0:La9a;

.field public static final b0:La9a;

.field public static final c0:La9a;

.field public static final d0:La9a;

.field public static final e0:La9a;

.field public static final f0:La9a;

.field public static final g0:La9a;

.field public static final h0:La9a;

.field public static final i0:La9a;


# instance fields
.field public final synthetic E:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, La9a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->F:La9a;

    new-instance v0, La9a;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->G:La9a;

    new-instance v0, La9a;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->H:La9a;

    new-instance v0, La9a;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->I:La9a;

    new-instance v0, La9a;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->J:La9a;

    new-instance v0, La9a;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->K:La9a;

    new-instance v0, La9a;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->L:La9a;

    new-instance v0, La9a;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->M:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->N:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->O:La9a;

    new-instance v0, La9a;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->P:La9a;

    new-instance v0, La9a;

    const/16 v1, 0xb

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->Q:La9a;

    new-instance v0, La9a;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->R:La9a;

    new-instance v0, La9a;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->S:La9a;

    new-instance v0, La9a;

    const/16 v1, 0xe

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->T:La9a;

    new-instance v0, La9a;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->U:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->V:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x11

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->W:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x12

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->X:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x13

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->Y:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->Z:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x15

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->a0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->b0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x17

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->c0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x18

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->d0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x19

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->e0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x1a

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->f0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x1b

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->g0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x1c

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->h0:La9a;

    new-instance v0, La9a;

    const/16 v1, 0x1d

    invoke-direct {v0, v1}, La9a;-><init>(I)V

    sput-object v0, La9a;->i0:La9a;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, La9a;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    iget p0, p0, La9a;->E:I

    const/4 v0, 0x0

    sget-object v1, Lz2j;->a:Lz2j;

    packed-switch p0, :pswitch_data_1ca

    check-cast p1, Lcom/anthropic/claude/analytics/events/ChatMessageActionEvents$ActionSource;

    check-cast p2, Lcom/anthropic/claude/types/strings/MessageId;

    invoke-virtual {p2}, Lcom/anthropic/claude/types/strings/MessageId;->unbox-impl()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p0, "onSelect"

    invoke-static {p0}, Lcom/anthropic/claude/chat/share/k;->c(Ljava/lang/String;)V

    return-object v1

    :pswitch_1c  #0x1c
    check-cast p1, Lcom/anthropic/claude/types/strings/MessageId;

    invoke-virtual {p1}, Lcom/anthropic/claude/types/strings/MessageId;->unbox-impl()Ljava/lang/String;

    move-result-object p0

    check-cast p2, Lcom/anthropic/claude/api/chat/messages/MessageFlag;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :pswitch_2b  #0x1b
    check-cast p1, Lcom/anthropic/claude/analytics/events/ChatMessageActionEvents$ActionSource;

    check-cast p2, Lcom/anthropic/claude/types/strings/MessageId;

    invoke-virtual {p2}, Lcom/anthropic/claude/types/strings/MessageId;->unbox-impl()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :pswitch_3a  #0x1a
    check-cast p1, Lcom/anthropic/claude/analytics/events/ChatMessageActionEvents$ActionSource;

    check-cast p2, Lcom/anthropic/claude/types/strings/MessageId;

    invoke-virtual {p2}, Lcom/anthropic/claude/types/strings/MessageId;->unbox-impl()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :pswitch_49  #0x19
    check-cast p1, Lcom/anthropic/router/panes/Panes;

    check-cast p2, Lcom/anthropic/router/panes/Panes;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :pswitch_54  #0x18
    check-cast p1, Lcom/anthropic/router/panes/Panes;

    check-cast p2, Lcom/anthropic/router/panes/Panes;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :pswitch_5f  #0x17
    check-cast p1, Lzu4;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    check-cast p1, Leb8;

    const p0, 0x56e04c3c

    invoke-virtual {p1, p0}, Leb8;->g0(I)V

    sget-object p0, Lzhf;->b:Lnw4;

    invoke-virtual {p1, p0}, Leb8;->j(Ldge;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lan4;

    iget-wide v1, p0, Lan4;->a:J

    invoke-virtual {p1, v0}, Leb8;->q(Z)V

    new-instance p0, Lan4;

    invoke-direct {p0, v1, v2}, Lan4;-><init>(J)V

    return-object p0

    :pswitch_81  #0x16
    check-cast p1, Lzu4;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    check-cast p1, Leb8;

    const p0, 0x255775c9

    invoke-virtual {p1, p0}, Leb8;->g0(I)V

    sget-object p0, Ly45;->a:Lnw4;

    invoke-virtual {p1, p0}, Leb8;->j(Ldge;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lan4;

    iget-wide v1, p0, Lan4;->a:J

    invoke-virtual {p1, v0}, Leb8;->q(Z)V

    new-instance p0, Lan4;

    invoke-direct {p0, v1, v2}, Lan4;-><init>(J)V

    return-object p0

    :pswitch_a3  #0x15
    check-cast p1, Lk7d;

    check-cast p2, Lgh8;

    instance-of p0, p2, Lsb;

    if-eqz p0, :cond_b3

    iget-object p0, p1, Lk7d;->F:Ljava/lang/Object;

    new-instance p1, Lk7d;

    invoke-direct {p1, p2, p0}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_c3

    :cond_b3
    iget-object p0, p1, Lk7d;->E:Ljava/lang/Object;

    iget-object p1, p1, Lk7d;->F:Ljava/lang/Object;

    check-cast p1, Lhh8;

    invoke-interface {p1, p2}, Lhh8;->d(Lhh8;)Lhh8;

    move-result-object p1

    new-instance p2, Lk7d;

    invoke-direct {p2, p0, p1}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object p1, p2

    :goto_c3
    return-object p1

    :pswitch_c4  #0x14
    check-cast p1, Lk7d;

    check-cast p2, Lgh8;

    instance-of p0, p2, Lgf1;

    if-eqz p0, :cond_d4

    iget-object p0, p1, Lk7d;->F:Ljava/lang/Object;

    new-instance p1, Lk7d;

    invoke-direct {p1, p2, p0}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_e4

    :cond_d4
    iget-object p0, p1, Lk7d;->E:Ljava/lang/Object;

    iget-object p1, p1, Lk7d;->F:Ljava/lang/Object;

    check-cast p1, Lhh8;

    invoke-interface {p1, p2}, Lhh8;->d(Lhh8;)Lhh8;

    move-result-object p1

    new-instance p2, Lk7d;

    invoke-direct {p2, p0, p1}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object p1, p2

    :goto_e4
    return-object p1

    :pswitch_e5  #0x13
    check-cast p2, Lgh8;

    instance-of p0, p2, Lp1k;

    if-eqz p0, :cond_ec

    move-object p1, p2

    :cond_ec
    return-object p1

    :pswitch_ed  #0x12
    check-cast p2, Lgh8;

    instance-of p0, p2, Ley8;

    if-eqz p0, :cond_f4

    move-object p1, p2

    :cond_f4
    return-object p1

    :pswitch_f5  #0x11
    check-cast p2, Lgh8;

    instance-of p0, p2, Lp1k;

    if-eqz p0, :cond_fc

    move-object p1, p2

    :cond_fc
    return-object p1

    :pswitch_fd  #0x10
    check-cast p2, Lgh8;

    instance-of p0, p2, Ley8;

    if-eqz p0, :cond_104

    move-object p1, p2

    :cond_104
    return-object p1

    :pswitch_105  #0xf
    check-cast p1, Lk7d;

    check-cast p2, Lgh8;

    instance-of p0, p2, Lsb;

    if-eqz p0, :cond_115

    iget-object p0, p1, Lk7d;->F:Ljava/lang/Object;

    new-instance p1, Lk7d;

    invoke-direct {p1, p2, p0}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_125

    :cond_115
    iget-object p0, p1, Lk7d;->E:Ljava/lang/Object;

    iget-object p1, p1, Lk7d;->F:Ljava/lang/Object;

    check-cast p1, Lhh8;

    invoke-interface {p1, p2}, Lhh8;->d(Lhh8;)Lhh8;

    move-result-object p1

    new-instance p2, Lk7d;

    invoke-direct {p2, p0, p1}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object p1, p2

    :goto_125
    return-object p1

    :pswitch_126  #0xe
    check-cast p1, Lcom/anthropic/claude/api/chat/messages/ToolResultBlock;

    check-cast p2, Lcom/anthropic/claude/types/strings/MessageId;

    if-eqz p2, :cond_12f

    invoke-virtual {p2}, Lcom/anthropic/claude/types/strings/MessageId;->unbox-impl()Ljava/lang/String;

    :cond_12f
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :pswitch_133  #0xd
    check-cast p1, Lcom/anthropic/claude/api/chat/messages/ToolUseBlock;

    check-cast p2, Lcom/anthropic/claude/types/strings/MessageId;

    if-eqz p2, :cond_13c

    invoke-virtual {p2}, Lcom/anthropic/claude/types/strings/MessageId;->unbox-impl()Ljava/lang/String;

    :cond_13c
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :pswitch_140  #0xc
    check-cast p1, Lp6b;

    check-cast p2, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p1, Lp6b;->a:Lfj8;

    invoke-virtual {p0, p2}, Lfj8;->d(Ljava/lang/String;)V

    return-object v1

    :pswitch_14d  #0xb
    check-cast p1, Lp6b;

    check-cast p2, Lf7a;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p1, Lp6b;->c:Lf7a;

    return-object v1

    :pswitch_15a  #0xa
    check-cast p1, Lp6b;

    check-cast p2, Lrh2;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p1, Lp6b;->d:Lrh2;

    if-eq p2, p0, :cond_173

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lrh2;->b(Lfj8;)V

    iput-object p2, p1, Lp6b;->d:Lrh2;

    iget-object p0, p1, Lp6b;->a:Lfj8;

    invoke-virtual {p2, p0}, Lrh2;->b(Lfj8;)V

    :cond_173
    return-object v1

    :pswitch_174  #0x9
    check-cast p1, Lp6b;

    check-cast p2, Ld76;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p1, Lp6b;->b:Ld76;

    return-object v1

    :pswitch_181  #0x8
    check-cast p2, Lgh8;

    instance-of p0, p2, Ley8;

    if-eqz p0, :cond_188

    move-object p1, p2

    :cond_188
    return-object p1

    :pswitch_189  #0x7
    check-cast p2, Lgh8;

    instance-of p0, p2, Lp1k;

    if-eqz p0, :cond_190

    move-object p1, p2

    :cond_190
    return-object p1

    :pswitch_191  #0x6
    check-cast p2, Lgh8;

    instance-of p0, p2, Luu;

    if-eqz p0, :cond_198

    move-object p1, p2

    :cond_198
    return-object p1

    :pswitch_199  #0x5
    check-cast p2, Lgh8;

    instance-of p0, p2, Ley8;

    if-eqz p0, :cond_1a0

    move-object p1, p2

    :cond_1a0
    return-object p1

    :pswitch_1a1  #0x4
    check-cast p2, Lgh8;

    instance-of p0, p2, Lp1k;

    if-eqz p0, :cond_1a8

    move-object p1, p2

    :cond_1a8
    return-object p1

    :pswitch_1a9  #0x3
    check-cast p2, Lgh8;

    instance-of p0, p2, Ley8;

    if-eqz p0, :cond_1b0

    move-object p1, p2

    :cond_1b0
    return-object p1

    :pswitch_1b1  #0x2
    check-cast p2, Lgh8;

    instance-of p0, p2, Lp1k;

    if-eqz p0, :cond_1b8

    move-object p1, p2

    :cond_1b8
    return-object p1

    :pswitch_1b9  #0x1
    check-cast p2, Lgh8;

    instance-of p0, p2, Ley8;

    if-eqz p0, :cond_1c0

    move-object p1, p2

    :cond_1c0
    return-object p1

    :pswitch_1c1  #0x0
    check-cast p2, Lgh8;

    instance-of p0, p2, Lp1k;

    if-eqz p0, :cond_1c8

    move-object p1, p2

    :cond_1c8
    return-object p1

    nop

    :pswitch_data_1ca
    .packed-switch 0x0
        :pswitch_1c1  #00000000
        :pswitch_1b9  #00000001
        :pswitch_1b1  #00000002
        :pswitch_1a9  #00000003
        :pswitch_1a1  #00000004
        :pswitch_199  #00000005
        :pswitch_191  #00000006
        :pswitch_189  #00000007
        :pswitch_181  #00000008
        :pswitch_174  #00000009
        :pswitch_15a  #0000000a
        :pswitch_14d  #0000000b
        :pswitch_140  #0000000c
        :pswitch_133  #0000000d
        :pswitch_126  #0000000e
        :pswitch_105  #0000000f
        :pswitch_fd  #00000010
        :pswitch_f5  #00000011
        :pswitch_ed  #00000012
        :pswitch_e5  #00000013
        :pswitch_c4  #00000014
        :pswitch_a3  #00000015
        :pswitch_81  #00000016
        :pswitch_5f  #00000017
        :pswitch_54  #00000018
        :pswitch_49  #00000019
        :pswitch_3a  #0000001a
        :pswitch_2b  #0000001b
        :pswitch_1c  #0000001c
    .end packed-switch
.end method
