.class public final enum Lb61;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lb61;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum F:Lb61;

.field public static final synthetic G:[Lb61;


# instance fields
.field public final E:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, Lb61;

    const-string v1, "NONE"

    const/4 v2, 0x0

    const-string v3, "none"

    invoke-direct {v0, v1, v2, v3}, Lb61;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lb61;->F:Lb61;

    new-instance v1, Lb61;

    const-string v2, "INDIRECT"

    const/4 v3, 0x1

    const-string v4, "indirect"

    invoke-direct {v1, v2, v3, v4}, Lb61;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    new-instance v2, Lb61;

    const-string v3, "DIRECT"

    const/4 v4, 0x2

    const-string v5, "direct"

    invoke-direct {v2, v3, v4, v5}, Lb61;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    filled-new-array {v0, v1, v2}, [Lb61;

    move-result-object v0

    sput-object v0, Lb61;->G:[Lb61;

    new-instance v0, Lohk;

    const/16 v1, 0x1d

    invoke-direct {v0, v1}, Lohk;-><init>(I)V

    sput-object v0, Lb61;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lb61;->E:Ljava/lang/String;

    return-void
.end method

.method public static a(Ljava/lang/String;)Lb61;
    .registers 6

    invoke-static {}, Lb61;->values()[Lb61;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_16

    aget-object v3, v0, v2

    iget-object v4, v3, Lb61;->E:Ljava/lang/String;

    invoke-virtual {p0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_13

    return-object v3

    :cond_13
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_16
    new-instance v0, Lcom/google/android/gms/fido/fido2/api/common/AttestationConveyancePreference$UnsupportedAttestationConveyancePreferenceException;

    const-string v1, "Attestation conveyance preference "

    const-string v2, " not supported"

    invoke-static {v1, p0, v2}, Lb40;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static valueOf(Ljava/lang/String;)Lb61;
    .registers 2

    const-class v0, Lb61;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lb61;

    return-object p0
.end method

.method public static values()[Lb61;
    .registers 1

    sget-object v0, Lb61;->G:[Lb61;

    invoke-virtual {v0}, [Lb61;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lb61;

    return-object v0
.end method


# virtual methods
.method public final describeContents()I
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lb61;->E:Ljava/lang/String;

    return-object p0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 3

    iget-object p0, p0, Lb61;->E:Ljava/lang/String;

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return-void
.end method
