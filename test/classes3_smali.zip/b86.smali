.class public final Lb86;
.super Lc86;
.source "SourceFile"


# static fields
.field public static final a:Lb86;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lb86;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lb86;->a:Lb86;

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 1

    const/4 p0, 0x0

    return p0
.end method
