.class public final La2b;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public synthetic F:Ljava/lang/Object;

.field public final synthetic G:Ls98;

.field public final synthetic H:La98;


# direct methods
.method public synthetic constructor <init>(Ls98;La98;La75;I)V
    .registers 5

    iput p4, p0, La2b;->E:I

    iput-object p1, p0, La2b;->G:Ls98;

    iput-object p2, p0, La2b;->H:La98;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 6

    iget v0, p0, La2b;->E:I

    packed-switch v0, :pswitch_data_20

    new-instance v0, La2b;

    iget-object v1, p0, La2b;->H:La98;

    const/4 v2, 0x1

    iget-object p0, p0, La2b;->G:Ls98;

    invoke-direct {v0, p0, v1, p2, v2}, La2b;-><init>(Ls98;La98;La75;I)V

    iput-object p1, v0, La2b;->F:Ljava/lang/Object;

    return-object v0

    :pswitch_12  #0x0
    new-instance v0, La2b;

    iget-object v1, p0, La2b;->H:La98;

    const/4 v2, 0x0

    iget-object p0, p0, La2b;->G:Ls98;

    invoke-direct {v0, p0, v1, p2, v2}, La2b;-><init>(Ls98;La98;La75;I)V

    iput-object p1, v0, La2b;->F:Ljava/lang/Object;

    return-object v0

    nop

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_12  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget v0, p0, La2b;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    packed-switch v0, :pswitch_data_24

    check-cast p1, Ll2b;

    check-cast p2, La75;

    invoke-virtual {p0, p1, p2}, La2b;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La2b;

    invoke-virtual {p0, v1}, La2b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_15  #0x0
    check-cast p1, Lx1b;

    check-cast p2, La75;

    invoke-virtual {p0, p1, p2}, La2b;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La2b;

    invoke-virtual {p0, v1}, La2b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_15  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    iget v0, p0, La2b;->E:I

    const/4 v1, 0x0

    sget-object v2, Lz2j;->a:Lz2j;

    iget-object v3, p0, La2b;->H:La98;

    iget-object v4, p0, La2b;->G:Ls98;

    iget-object p0, p0, La2b;->F:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_62

    check-cast p0, Ll2b;

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    instance-of p1, p0, Lk2b;

    if-eqz p1, :cond_2b

    check-cast p0, Lk2b;

    iget-object p1, p0, Lk2b;->a:Ljava/lang/String;

    invoke-static {p1}, Lcom/anthropic/claude/types/strings/AccountId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/AccountId;

    move-result-object p1

    iget-object v0, p0, Lk2b;->b:Ljava/lang/String;

    invoke-static {v0}, Lcom/anthropic/claude/types/strings/OrganizationId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/OrganizationId;

    move-result-object v0

    iget-object p0, p0, Lk2b;->c:Lxk;

    invoke-interface {v4, p1, v0, p0}, Ls98;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_32

    :cond_2b
    instance-of p0, p0, Lj2b;

    if-eqz p0, :cond_34

    invoke-interface {v3}, La98;->a()Ljava/lang/Object;

    :goto_32
    move-object v1, v2

    goto :goto_37

    :cond_34
    invoke-static {}, Le97;->d()V

    :goto_37
    return-object v1

    :pswitch_38  #0x0
    check-cast p0, Lx1b;

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    instance-of p1, p0, Lw1b;

    if-eqz p1, :cond_55

    check-cast p0, Lw1b;

    iget-object p1, p0, Lw1b;->a:Ljava/lang/String;

    invoke-static {p1}, Lcom/anthropic/claude/types/strings/AccountId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/AccountId;

    move-result-object p1

    iget-object v0, p0, Lw1b;->b:Ljava/lang/String;

    invoke-static {v0}, Lcom/anthropic/claude/types/strings/OrganizationId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/OrganizationId;

    move-result-object v0

    iget-object p0, p0, Lw1b;->c:Lxk;

    invoke-interface {v4, p1, v0, p0}, Ls98;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_5c

    :cond_55
    instance-of p0, p0, Lv1b;

    if-eqz p0, :cond_5e

    invoke-interface {v3}, La98;->a()Ljava/lang/Object;

    :goto_5c
    move-object v1, v2

    goto :goto_61

    :cond_5e
    invoke-static {}, Le97;->d()V

    :goto_61
    return-object v1

    :pswitch_data_62
    .packed-switch 0x0
        :pswitch_38  #00000000
    .end packed-switch
.end method
