.class public final Lb79;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:La1f;


# direct methods
.method public constructor <init>(La1f;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb79;->a:La1f;

    return-void
.end method
