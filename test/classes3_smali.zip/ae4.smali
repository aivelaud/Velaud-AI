.class public final synthetic Lae4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lcom/anthropic/claude/code/remote/h;


# direct methods
.method public synthetic constructor <init>(Lcom/anthropic/claude/code/remote/h;I)V
    .registers 3

    iput p2, p0, Lae4;->E:I

    iput-object p1, p0, Lae4;->F:Lcom/anthropic/claude/code/remote/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 10

    iget v0, p0, Lae4;->E:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p0, p0, Lae4;->F:Lcom/anthropic/claude/code/remote/h;

    packed-switch v0, :pswitch_data_3cc

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->r1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_13  #0x1c
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->x0()Ljava/util/List;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x1b
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->m1()Z

    move-result p0

    if-eqz p0, :cond_21

    sget-object p0, Lcom/anthropic/claude/analytics/events/CodeEvents$CodeComposerSource;->NEW_SESSION:Lcom/anthropic/claude/analytics/events/CodeEvents$CodeComposerSource;

    goto :goto_23

    :cond_21
    sget-object p0, Lcom/anthropic/claude/analytics/events/CodeEvents$CodeComposerSource;->IN_SESSION:Lcom/anthropic/claude/analytics/events/CodeEvents$CodeComposerSource;

    :goto_23
    return-object p0

    :pswitch_24  #0x1a
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->h0()V

    sget-object p0, Lz2j;->a:Lz2j;

    return-object p0

    :pswitch_2a  #0x19
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->Q0()Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_31

    goto :goto_32

    :cond_31
    move-object v3, p0

    :goto_32
    return-object v3

    :pswitch_33  #0x18
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->t0()Lcom/anthropic/claude/analytics/events/CodeEvents$CodeSurface;

    move-result-object p0

    return-object p0

    :pswitch_38  #0x17
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->P0()Lcom/anthropic/claude/sessions/types/SessionResource;

    move-result-object p0

    return-object p0

    :pswitch_3d  #0x16
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->z:Ltoi;

    iget-object p0, p0, Ltoi;->I:Lghh;

    invoke-interface {p0}, Lghh;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    return-object p0

    :pswitch_4b  #0x15
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->l1:Ltad;

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    if-eqz p0, :cond_a5

    invoke-static {p0}, Lfhl;->f(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p0

    const-string v0, "2.1.163"

    invoke-static {v0}, Lfhl;->f(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v4

    move v5, v1

    :goto_70
    if-ge v5, v4, :cond_a1

    if-ltz v5, :cond_7f

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_7f

    invoke-virtual {p0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    goto :goto_80

    :cond_7f
    move-object v6, v3

    :goto_80
    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    if-ltz v5, :cond_93

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v5, v7, :cond_93

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    goto :goto_94

    :cond_93
    move-object v7, v3

    :goto_94
    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    sub-int/2addr v6, v7

    if-eqz v6, :cond_9e

    goto :goto_a2

    :cond_9e
    add-int/lit8 v5, v5, 0x1

    goto :goto_70

    :cond_a1
    move v6, v1

    :goto_a2
    if-ltz v6, :cond_a5

    move v1, v2

    :cond_a5
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_aa  #0x14
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->z:Ltoi;

    iget-object p0, p0, Ltoi;->B:Lghh;

    invoke-interface {p0}, Lghh;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    return-object p0

    :pswitch_b8  #0x13
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->o1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_c1  #0x12
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->h1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_ca  #0x11
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->U2:Lkb1;

    invoke-virtual {p0}, Lkb1;->f()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_d5  #0x10
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->m1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_de  #0xf
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->P0()Lcom/anthropic/claude/sessions/types/SessionResource;

    move-result-object p0

    if-eqz p0, :cond_133

    invoke-virtual {p0}, Lcom/anthropic/claude/sessions/types/SessionResource;->getSession_context()Lcom/anthropic/claude/sessions/types/SessionContext;

    move-result-object p0

    if-eqz p0, :cond_133

    invoke-virtual {p0}, Lcom/anthropic/claude/sessions/types/SessionContext;->getOutcomes()Ljava/util/List;

    move-result-object p0

    if-eqz p0, :cond_133

    check-cast p0, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_fb
    :goto_fb
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_10d

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Lcom/anthropic/claude/sessions/types/Outcome$GitRepository;

    if-eqz v4, :cond_fb

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_fb

    :cond_10d
    new-instance p0, Ljava/util/LinkedHashSet;

    invoke-direct {p0}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_116
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_12e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/anthropic/claude/sessions/types/Outcome$GitRepository;

    invoke-virtual {v3}, Lcom/anthropic/claude/sessions/types/Outcome$GitRepository;->getGit_info()Lcom/anthropic/claude/sessions/types/OutcomeGitInfo;

    move-result-object v3

    invoke-virtual {v3}, Lcom/anthropic/claude/sessions/types/OutcomeGitInfo;->getRepo()Ljava/lang/String;

    move-result-object v3

    invoke-interface {p0, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_116

    :cond_12e
    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result p0

    goto :goto_134

    :cond_133
    move p0, v1

    :goto_134
    if-le p0, v2, :cond_137

    move v1, v2

    :cond_137
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_13c  #0xe
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->q1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_145  #0xd
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->J1:Ly76;

    invoke-virtual {p0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lgsg;

    if-eqz p0, :cond_153

    iget-object p0, p0, Lgsg;->a:Lxii;

    iget-object v3, p0, Lxii;->a:Ljava/lang/String;

    :cond_153
    return-object v3

    :pswitch_154  #0xc
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->y1:Lc91;

    invoke-virtual {p0}, Lc91;->u()Lcom/anthropic/claude/sessions/types/GitHubRepo;

    move-result-object p0

    return-object p0

    :pswitch_15b  #0xb
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->P0()Lcom/anthropic/claude/sessions/types/SessionResource;

    move-result-object p0

    return-object p0

    :pswitch_160  #0xa
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->W0()Lrng;

    move-result-object v0

    iget-boolean v0, v0, Lrng;->K:Z

    if-nez v0, :cond_16b

    sget-object p0, Lhd5;->e:Lhd5;

    goto :goto_1a1

    :cond_16b
    new-instance v0, Lhd5;

    iget-object v1, p0, Lcom/anthropic/claude/code/remote/h;->b2:Lghh;

    invoke-interface {v1}, Lghh;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iget-object v2, p0, Lcom/anthropic/claude/code/remote/h;->c2:Lghh;

    invoke-interface {v2}, Lghh;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    iget-object v4, p0, Lcom/anthropic/claude/code/remote/h;->U2:Lkb1;

    invoke-virtual {v4}, Lkb1;->f()Z

    move-result v4

    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->u:Lkp7;

    invoke-interface {p0}, Lkp7;->b()Ltad;

    move-result-object p0

    invoke-virtual {p0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/anthropic/claude/api/feature/CoworkSettings;

    if-eqz p0, :cond_19d

    invoke-virtual {p0}, Lcom/anthropic/claude/api/feature/CoworkSettings;->getSkip_approvals_enabled()Ljava/lang/Boolean;

    move-result-object v3

    :cond_19d
    invoke-direct {v0, v1, v2, v4, v3}, Lhd5;-><init>(ZZZLjava/lang/Boolean;)V

    move-object p0, v0

    :goto_1a1
    return-object p0

    :pswitch_1a2  #0x9
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->A:Lhdj;

    iget-object v0, p0, Lhdj;->u:Ly76;

    invoke-virtual {v0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    invoke-virtual {p0}, Lhdj;->e()Ljava/util/List;

    move-result-object p0

    check-cast p0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1bb
    :goto_1bb
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1f0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/anthropic/claude/api/mcp/McpServer;

    invoke-virtual {v2}, Lcom/anthropic/claude/api/mcp/McpServer;->getUuid-owoRr7k()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/anthropic/claude/types/strings/McpServerId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/McpServerId;

    move-result-object v4

    invoke-virtual {v4}, Lcom/anthropic/claude/types/strings/McpServerId;->unbox-impl()Ljava/lang/String;

    invoke-static {v2, v0}, Lhkl;->o(Lcom/anthropic/claude/api/mcp/McpServer;Ljava/util/Map;)Z

    move-result v2

    if-eqz v2, :cond_1d9

    goto :goto_1da

    :cond_1d9
    move-object v4, v3

    :goto_1da
    if-eqz v4, :cond_1e1

    invoke-virtual {v4}, Lcom/anthropic/claude/types/strings/McpServerId;->unbox-impl()Ljava/lang/String;

    move-result-object v2

    goto :goto_1e2

    :cond_1e1
    move-object v2, v3

    :goto_1e2
    if-eqz v2, :cond_1e9

    invoke-static {v2}, Lcom/anthropic/claude/types/strings/McpServerId;->box-impl(Ljava/lang/String;)Lcom/anthropic/claude/types/strings/McpServerId;

    move-result-object v2

    goto :goto_1ea

    :cond_1e9
    move-object v2, v3

    :goto_1ea
    if-eqz v2, :cond_1bb

    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1bb

    :cond_1f0
    return-object v1

    :pswitch_1f1  #0x8
    iget-object v0, p0, Lcom/anthropic/claude/code/remote/h;->M1:Ly76;

    invoke-virtual {v0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lp0f;

    if-nez v0, :cond_207

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->r0()Lu0f;

    move-result-object v0

    if-nez v0, :cond_207

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->s1()Z

    move-result v0

    if-eqz v0, :cond_21b

    :cond_207
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->K1:Ly76;

    invoke-virtual {p0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lk7d;

    if-eqz p0, :cond_216

    iget-object p0, p0, Lk7d;->E:Ljava/lang/Object;

    check-cast p0, Lfwb;

    goto :goto_217

    :cond_216
    move-object p0, v3

    :goto_217
    if-eqz p0, :cond_21b

    iget-object v3, p0, Lfwb;->a:Ljava/lang/String;

    :cond_21b
    return-object v3

    :pswitch_21c  #0x7
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->r0()Lu0f;

    move-result-object v0

    if-nez v0, :cond_244

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->s1()Z

    move-result v0

    if-eqz v0, :cond_229

    goto :goto_244

    :cond_229
    iget-object v0, p0, Lcom/anthropic/claude/code/remote/h;->K1:Ly76;

    invoke-virtual {v0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lk7d;

    if-eqz v0, :cond_238

    iget-object v0, v0, Lk7d;->F:Ljava/lang/Object;

    check-cast v0, Lp0f;

    goto :goto_239

    :cond_238
    move-object v0, v3

    :goto_239
    if-eqz v0, :cond_244

    iget-object v1, v0, Lp0f;->e:Lu0f;

    invoke-virtual {p0, v1}, Lcom/anthropic/claude/code/remote/h;->a0(Lu0f;)Z

    move-result p0

    if-eqz p0, :cond_244

    move-object v3, v0

    :cond_244
    :goto_244
    return-object v3

    :pswitch_245  #0x6
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->y0()Ljava/util/List;

    move-result-object p0

    new-instance v0, Ll9b;

    invoke-direct {v0, p0}, Ll9b;-><init>(Ljava/util/List;)V

    invoke-virtual {v0}, Ll9b;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_252
    move-object v0, p0

    check-cast v0, Lygf;

    iget-object v0, v0, Lygf;->E:Ljava/util/ListIterator;

    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    move-result v1

    if-eqz v1, :cond_274

    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltgg;

    instance-of v1, v0, Lp0f;

    if-eqz v1, :cond_26a

    check-cast v0, Lp0f;

    goto :goto_26b

    :cond_26a
    move-object v0, v3

    :goto_26b
    if-eqz v0, :cond_270

    iget-object v0, v0, Lp0f;->a:Ljava/lang/String;

    goto :goto_271

    :cond_270
    move-object v0, v3

    :goto_271
    if-eqz v0, :cond_252

    move-object v3, v0

    :cond_274
    return-object v3

    :pswitch_275  #0x5
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->y0()Ljava/util/List;

    move-result-object p0

    sget-object v0, Lcom/anthropic/claude/code/remote/i;->b:Lz0f;

    new-instance v0, Ll9b;

    invoke-direct {v0, p0}, Ll9b;-><init>(Ljava/util/List;)V

    invoke-virtual {v0}, Ll9b;->iterator()Ljava/util/Iterator;

    move-result-object p0

    move-object v0, v3

    move-object v1, v0

    :cond_286
    :goto_286
    move-object v2, p0

    check-cast v2, Lygf;

    iget-object v2, v2, Lygf;->E:Ljava/util/ListIterator;

    invoke-interface {v2}, Ljava/util/ListIterator;->hasPrevious()Z

    move-result v4

    if-eqz v4, :cond_2d2

    invoke-interface {v2}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ltgg;

    instance-of v4, v2, Lfwb;

    if-eqz v4, :cond_2ac

    move-object v5, v2

    check-cast v5, Lfwb;

    iget-boolean v6, v5, Lfwb;->k:Z

    if-eqz v6, :cond_2ac

    if-eqz v0, :cond_2aa

    new-instance v3, Lk7d;

    invoke-direct {v3, v0, v1}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_2d9

    :cond_2aa
    move-object v0, v5

    goto :goto_286

    :cond_2ac
    instance-of v5, v2, Lp0f;

    if-eqz v5, :cond_2c5

    move-object v5, v2

    check-cast v5, Lp0f;

    iget-object v5, v5, Lp0f;->c:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    if-nez v5, :cond_2c5

    if-eqz v0, :cond_2c3

    new-instance v3, Lk7d;

    invoke-direct {v3, v0, v2}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_2d9

    :cond_2c3
    move-object v1, v2

    goto :goto_286

    :cond_2c5
    if-nez v0, :cond_286

    if-eqz v4, :cond_286

    check-cast v2, Lfwb;

    invoke-static {v2}, Lynk;->h(Lfwb;)Z

    move-result v2

    if-eqz v2, :cond_286

    goto :goto_2d9

    :cond_2d2
    if-eqz v0, :cond_2d9

    new-instance v3, Lk7d;

    invoke-direct {v3, v0, v1}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2d9
    :goto_2d9
    return-object v3

    :pswitch_2da  #0x4
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->y0()Ljava/util/List;

    move-result-object p0

    sget-object v0, Lcom/anthropic/claude/code/remote/i;->b:Lz0f;

    new-instance v0, Ll9b;

    invoke-direct {v0, p0}, Ll9b;-><init>(Ljava/util/List;)V

    invoke-virtual {v0}, Ll9b;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_2e9
    move-object v0, p0

    check-cast v0, Lygf;

    iget-object v0, v0, Lygf;->E:Ljava/util/ListIterator;

    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    move-result v1

    if-eqz v1, :cond_34b

    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltgg;

    instance-of v1, v0, Lxii;

    if-eqz v1, :cond_303

    invoke-static {v0}, Loz4;->H(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    goto :goto_311

    :cond_303
    instance-of v1, v0, Lzl4;

    if-eqz v1, :cond_2e9

    check-cast v0, Lzl4;

    iget-object v0, v0, Lzl4;->d:Ljava/util/List;

    new-instance v1, Ll9b;

    invoke-direct {v1, v0}, Ll9b;-><init>(Ljava/util/List;)V

    move-object v0, v1

    :goto_311
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_315
    :goto_315
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2e9

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lxii;

    iget-object v2, v1, Lxii;->c:Ljava/lang/String;

    const-string v4, "ReportFindings"

    invoke-static {v2, v4}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_315

    iget-object v2, v1, Lxii;->b:Ljava/lang/String;

    if-nez v2, :cond_315

    iget-object v2, v1, Lxii;->f:Lwii;

    sget-object v4, Lwii;->F:Lwii;

    if-eq v2, v4, :cond_336

    goto :goto_315

    :cond_336
    invoke-static {v1}, Ll6f;->d(Lxii;)Ln6f;

    move-result-object v2

    if-nez v2, :cond_33d

    goto :goto_315

    :cond_33d
    iget-object p0, v2, Ln6f;->b:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_346

    goto :goto_34b

    :cond_346
    new-instance v3, Lgsg;

    invoke-direct {v3, v1, v2}, Lgsg;-><init>(Lxii;Ln6f;)V

    :cond_34b
    :goto_34b
    return-object v3

    :pswitch_34c  #0x3
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->P0()Lcom/anthropic/claude/sessions/types/SessionResource;

    move-result-object p0

    return-object p0

    :pswitch_351  #0x2
    iget-object v0, p0, Lcom/anthropic/claude/code/remote/h;->p2:Ldf8;

    invoke-virtual {v0}, Ldf8;->c()Lcc6;

    move-result-object v0

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->q1()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    new-instance v1, Lk7d;

    invoke-direct {v1, v0, p0}, Lk7d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v1

    :pswitch_365  #0x1
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->M0()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    iget-object v3, p0, Lcom/anthropic/claude/code/remote/h;->M2:Lgl4;

    iget-object v3, v3, Lgl4;->m:Lq7h;

    invoke-virtual {v3}, Lq7h;->isEmpty()Z

    move-result v3

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->N0()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_37f

    move v4, v2

    goto :goto_380

    :cond_37f
    move v4, v1

    :goto_380
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->d1()Z

    move-result v5

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->v1()Z

    move-result v6

    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->K0()Lmnd;

    move-result-object v7

    if-eqz v7, :cond_390

    move v7, v2

    goto :goto_391

    :cond_390
    move v7, v1

    :goto_391
    invoke-virtual {p0}, Lcom/anthropic/claude/code/remote/h;->s0()Lwz0;

    move-result-object v8

    if-eqz v8, :cond_399

    move v8, v2

    goto :goto_39a

    :cond_399
    move v8, v1

    :goto_39a
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->s2:Lsgd;

    iget-object p0, p0, Lsgd;->m:Lq7h;

    invoke-virtual {p0}, Lq7h;->isEmpty()Z

    move-result p0

    if-eqz v0, :cond_3b3

    if-eqz v3, :cond_3b3

    if-nez v4, :cond_3b3

    if-nez v5, :cond_3b3

    if-nez v6, :cond_3b3

    if-nez v7, :cond_3b3

    if-nez v8, :cond_3b3

    if-eqz p0, :cond_3b3

    goto :goto_3b4

    :cond_3b3
    move v1, v2

    :goto_3b4
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_3b9  #0x0
    iget-object p0, p0, Lcom/anthropic/claude/code/remote/h;->V0:Lo8i;

    invoke-virtual {p0}, Lo8i;->d()Lw4i;

    move-result-object p0

    iget-object p0, p0, Lw4i;->G:Ljava/lang/CharSequence;

    invoke-static {p0}, Lcnh;->x0(Ljava/lang/CharSequence;)Z

    move-result p0

    xor-int/2addr p0, v2

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_3cc
    .packed-switch 0x0
        :pswitch_3b9  #00000000
        :pswitch_365  #00000001
        :pswitch_351  #00000002
        :pswitch_34c  #00000003
        :pswitch_2da  #00000004
        :pswitch_275  #00000005
        :pswitch_245  #00000006
        :pswitch_21c  #00000007
        :pswitch_1f1  #00000008
        :pswitch_1a2  #00000009
        :pswitch_160  #0000000a
        :pswitch_15b  #0000000b
        :pswitch_154  #0000000c
        :pswitch_145  #0000000d
        :pswitch_13c  #0000000e
        :pswitch_de  #0000000f
        :pswitch_d5  #00000010
        :pswitch_ca  #00000011
        :pswitch_c1  #00000012
        :pswitch_b8  #00000013
        :pswitch_aa  #00000014
        :pswitch_4b  #00000015
        :pswitch_3d  #00000016
        :pswitch_38  #00000017
        :pswitch_33  #00000018
        :pswitch_2a  #00000019
        :pswitch_24  #0000001a
        :pswitch_18  #0000001b
        :pswitch_13  #0000001c
    .end packed-switch
.end method
