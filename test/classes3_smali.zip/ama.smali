.class public final Lama;
.super Lbma;
.source "SourceFile"


# virtual methods
.method public final a(JLjava/lang/Object;)V
    .registers 4

    sget-object p0, Lk5j;->c:Lf5j;

    invoke-virtual {p0, p1, p2, p3}, Lf5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lel9;

    check-cast p0, Lq3;

    const/4 p1, 0x0

    iput-boolean p1, p0, Lq3;->E:Z

    return-void
.end method

.method public final b(JLjava/lang/Object;Ljava/lang/Object;)V
    .registers 8

    sget-object p0, Lk5j;->c:Lf5j;

    invoke-virtual {p0, p1, p2, p3}, Lf5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lel9;

    invoke-virtual {p0, p1, p2, p4}, Lf5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lel9;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p4

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez p4, :cond_29

    if-lez v1, :cond_29

    move-object v2, v0

    check-cast v2, Lq3;

    iget-boolean v2, v2, Lq3;->E:Z

    if-nez v2, :cond_26

    add-int/2addr v1, p4

    invoke-interface {v0, v1}, Lel9;->l(I)Lel9;

    move-result-object v0

    :cond_26
    invoke-interface {v0, p0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_29
    if-lez p4, :cond_2c

    move-object p0, v0

    :cond_2c
    invoke-static {p1, p2, p3, p0}, Lk5j;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final c(JLjava/lang/Object;)Ljava/util/List;
    .registers 5

    sget-object p0, Lk5j;->c:Lf5j;

    invoke-virtual {p0, p1, p2, p3}, Lf5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lel9;

    move-object v0, p0

    check-cast v0, Lq3;

    iget-boolean v0, v0, Lq3;->E:Z

    if-nez v0, :cond_21

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    if-nez v0, :cond_18

    const/16 v0, 0xa

    goto :goto_1a

    :cond_18
    mul-int/lit8 v0, v0, 0x2

    :goto_1a
    invoke-interface {p0, v0}, Lel9;->l(I)Lel9;

    move-result-object p0

    invoke-static {p1, p2, p3, p0}, Lk5j;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    :cond_21
    return-object p0
.end method
