.class public final Lav5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Z

.field public final synthetic G:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ZLjava/lang/Object;I)V
    .registers 4

    iput p3, p0, Lav5;->E:I

    iput-boolean p1, p0, Lav5;->F:Z

    iput-object p2, p0, Lav5;->G:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iget v0, p0, Lav5;->E:I

    iget-boolean v1, p0, Lav5;->F:Z

    iget-object p0, p0, Lav5;->G:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_52

    check-cast p1, Lo1a;

    iget-object p1, p1, Lo1a;->a:Landroid/view/KeyEvent;

    check-cast p0, Lr28;

    if-eqz v1, :cond_16

    invoke-static {p1}, Lev5;->r(Landroid/view/KeyEvent;)Z

    move-result v0

    goto :goto_1a

    :cond_16
    invoke-static {p1}, Lev5;->s(Landroid/view/KeyEvent;)Z

    move-result v0

    :goto_1a
    if-eqz v0, :cond_23

    const/4 p1, 0x1

    invoke-interface {p0, p1}, Lr28;->a(I)Z

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_39

    :cond_23
    if-eqz v1, :cond_2a

    invoke-static {p1}, Lev5;->s(Landroid/view/KeyEvent;)Z

    move-result p1

    goto :goto_2e

    :cond_2a
    invoke-static {p1}, Lev5;->r(Landroid/view/KeyEvent;)Z

    move-result p1

    :goto_2e
    if-eqz p1, :cond_37

    const/4 p1, 0x2

    invoke-interface {p0, p1}, Lr28;->a(I)Z

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_39

    :cond_37
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    :goto_39
    return-object p0

    :pswitch_3a  #0x0
    check-cast p1, Lo1a;

    iget-object p1, p1, Lo1a;->a:Landroid/view/KeyEvent;

    if-eqz v1, :cond_4e

    invoke-static {p1}, Lev5;->q(Landroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_4e

    check-cast p0, La98;

    invoke-interface {p0}, La98;->a()Ljava/lang/Object;

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_50

    :cond_4e
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    :goto_50
    return-object p0

    nop

    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_3a  #00000000
    .end packed-switch
.end method
