.class public final synthetic Laxf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lcom/anthropic/claude/sessions/types/TriggerResource;


# direct methods
.method public synthetic constructor <init>(Lcom/anthropic/claude/sessions/types/TriggerResource;II)V
    .registers 4

    iput p3, p0, Laxf;->E:I

    iput-object p1, p0, Laxf;->F:Lcom/anthropic/claude/sessions/types/TriggerResource;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    iget v0, p0, Laxf;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    const/4 v2, 0x1

    sget-object v3, Lq7c;->E:Lq7c;

    iget-object p0, p0, Laxf;->F:Lcom/anthropic/claude/sessions/types/TriggerResource;

    check-cast p1, Lzu4;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    packed-switch v0, :pswitch_data_24

    invoke-static {v2}, Lupl;->D(I)I

    move-result p2

    invoke-static {p0, v3, p1, p2}, Lcom/anthropic/claude/code/remote/r;->e(Lcom/anthropic/claude/sessions/types/TriggerResource;Lt7c;Lzu4;I)V

    return-object v1

    :pswitch_1b  #0x0
    invoke-static {v2}, Lupl;->D(I)I

    move-result p2

    invoke-static {p0, v3, p1, p2}, Lcom/anthropic/claude/code/remote/r;->e(Lcom/anthropic/claude/sessions/types/TriggerResource;Lt7c;Lzu4;I)V

    return-object v1

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_1b  #00000000
    .end packed-switch
.end method
