.class public final Lab8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public b:I

.field public c:[C

.field public d:I

.field public e:I


# direct methods
.method public constructor <init>([CIII)V
    .registers 5

    iput p4, p0, Lab8;->a:I

    packed-switch p4, :pswitch_data_20

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length p4, p1

    iput p4, p0, Lab8;->b:I

    iput-object p1, p0, Lab8;->c:[C

    iput p2, p0, Lab8;->d:I

    iput p3, p0, Lab8;->e:I

    return-void

    :pswitch_12  #0x1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length p4, p1

    iput p4, p0, Lab8;->b:I

    iput-object p1, p0, Lab8;->c:[C

    iput p2, p0, Lab8;->d:I

    iput p3, p0, Lab8;->e:I

    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x1
        :pswitch_12  #00000001
    .end packed-switch
.end method


# virtual methods
.method public final a(Ljava/lang/StringBuilder;)V
    .registers 5

    iget v0, p0, Lab8;->a:I

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_2a

    iget-object v0, p0, Lab8;->c:[C

    iget v2, p0, Lab8;->d:I

    invoke-virtual {p1, v0, v1, v2}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lab8;->c:[C

    iget v1, p0, Lab8;->e:I

    iget p0, p0, Lab8;->b:I

    sub-int/2addr p0, v1

    invoke-virtual {p1, v0, v1, p0}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    return-void

    :pswitch_18  #0x0
    iget-object v0, p0, Lab8;->c:[C

    iget v2, p0, Lab8;->d:I

    invoke-virtual {p1, v0, v1, v2}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lab8;->c:[C

    iget v1, p0, Lab8;->e:I

    iget p0, p0, Lab8;->b:I

    sub-int/2addr p0, v1

    invoke-virtual {p1, v0, v1, p0}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    return-void

    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_18  #00000000
    .end packed-switch
.end method

.method public final b()I
    .registers 2

    iget v0, p0, Lab8;->a:I

    packed-switch v0, :pswitch_data_10

    iget v0, p0, Lab8;->e:I

    iget p0, p0, Lab8;->d:I

    :goto_9
    sub-int/2addr v0, p0

    return v0

    :pswitch_b  #0x0
    iget v0, p0, Lab8;->e:I

    iget p0, p0, Lab8;->d:I

    goto :goto_9

    :pswitch_data_10
    .packed-switch 0x0
        :pswitch_b  #00000000
    .end packed-switch
.end method

.method public final c(I)C
    .registers 4

    iget v0, p0, Lab8;->a:I

    packed-switch v0, :pswitch_data_26

    iget v0, p0, Lab8;->d:I

    iget-object v1, p0, Lab8;->c:[C

    if-ge p1, v0, :cond_e

    aget-char p0, v1, p1

    goto :goto_14

    :cond_e
    sub-int/2addr p1, v0

    iget p0, p0, Lab8;->e:I

    add-int/2addr p1, p0

    aget-char p0, v1, p1

    :goto_14
    return p0

    :pswitch_15  #0x0
    iget v0, p0, Lab8;->d:I

    iget-object v1, p0, Lab8;->c:[C

    if-ge p1, v0, :cond_1e

    aget-char p0, v1, p1

    goto :goto_24

    :cond_1e
    sub-int/2addr p1, v0

    iget p0, p0, Lab8;->e:I

    add-int/2addr p1, p0

    aget-char p0, v1, p1

    :goto_24
    return p0

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_15  #00000000
    .end packed-switch
.end method

.method public final d()I
    .registers 2

    iget v0, p0, Lab8;->a:I

    packed-switch v0, :pswitch_data_14

    iget v0, p0, Lab8;->b:I

    invoke-virtual {p0}, Lab8;->b()I

    move-result p0

    :goto_b
    sub-int/2addr v0, p0

    return v0

    :pswitch_d  #0x0
    iget v0, p0, Lab8;->b:I

    invoke-virtual {p0}, Lab8;->b()I

    move-result p0

    goto :goto_b

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_d  #00000000
    .end packed-switch
.end method

.method public e(IILjava/lang/CharSequence;II)V
    .registers 13

    sub-int v0, p5, p4

    sub-int v1, p2, p1

    sub-int v1, v0, v1

    invoke-virtual {p0}, Lab8;->b()I

    move-result v2

    if-gt v1, v2, :cond_d

    goto :goto_3b

    :cond_d
    invoke-virtual {p0}, Lab8;->b()I

    move-result v2

    sub-int/2addr v1, v2

    iget v2, p0, Lab8;->b:I

    :goto_14
    mul-int/lit8 v2, v2, 0x2

    iget v3, p0, Lab8;->b:I

    sub-int v3, v2, v3

    if-ge v3, v1, :cond_1d

    goto :goto_14

    :cond_1d
    new-array v1, v2, [C

    iget-object v3, p0, Lab8;->c:[C

    iget v4, p0, Lab8;->d:I

    const/4 v5, 0x0

    invoke-static {v3, v5, v1, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v3, p0, Lab8;->b:I

    iget v4, p0, Lab8;->e:I

    sub-int/2addr v3, v4

    sub-int v5, v2, v3

    iget-object v6, p0, Lab8;->c:[C

    add-int/2addr v3, v4

    sub-int/2addr v3, v4

    invoke-static {v6, v4, v1, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v1, p0, Lab8;->c:[C

    iput v2, p0, Lab8;->b:I

    iput v5, p0, Lab8;->e:I

    :goto_3b
    iget v1, p0, Lab8;->d:I

    if-ge p1, v1, :cond_52

    if-gt p2, v1, :cond_52

    sub-int/2addr v1, p2

    iget-object v2, p0, Lab8;->c:[C

    iget v3, p0, Lab8;->e:I

    sub-int/2addr v3, v1

    invoke-static {v2, p2, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput p1, p0, Lab8;->d:I

    iget p1, p0, Lab8;->e:I

    sub-int/2addr p1, v1

    iput p1, p0, Lab8;->e:I

    goto :goto_7b

    :cond_52
    if-ge p1, v1, :cond_60

    if-lt p2, v1, :cond_60

    invoke-virtual {p0}, Lab8;->b()I

    move-result v1

    add-int/2addr v1, p2

    iput v1, p0, Lab8;->e:I

    iput p1, p0, Lab8;->d:I

    goto :goto_7b

    :cond_60
    invoke-virtual {p0}, Lab8;->b()I

    move-result v1

    add-int/2addr v1, p1

    invoke-virtual {p0}, Lab8;->b()I

    move-result p1

    add-int/2addr p1, p2

    iget p2, p0, Lab8;->e:I

    sub-int/2addr v1, p2

    iget-object v2, p0, Lab8;->c:[C

    iget v3, p0, Lab8;->d:I

    invoke-static {v2, p2, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p2, p0, Lab8;->d:I

    add-int/2addr p2, v1

    iput p2, p0, Lab8;->d:I

    iput p1, p0, Lab8;->e:I

    :goto_7b
    iget-object p1, p0, Lab8;->c:[C

    iget p2, p0, Lab8;->d:I

    invoke-static {p3, p1, p2, p4, p5}, Lgk5;->h(Ljava/lang/CharSequence;[CIII)V

    iget p1, p0, Lab8;->d:I

    add-int/2addr p1, v0

    iput p1, p0, Lab8;->d:I

    return-void
.end method

.method public f(IILjava/lang/String;)V
    .registers 11

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v0

    sub-int v1, p2, p1

    sub-int/2addr v0, v1

    invoke-virtual {p0}, Lab8;->b()I

    move-result v1

    const/4 v2, 0x0

    if-gt v0, v1, :cond_f

    goto :goto_3c

    :cond_f
    invoke-virtual {p0}, Lab8;->b()I

    move-result v1

    sub-int/2addr v0, v1

    iget v1, p0, Lab8;->b:I

    :goto_16
    mul-int/lit8 v1, v1, 0x2

    iget v3, p0, Lab8;->b:I

    sub-int v3, v1, v3

    if-ge v3, v0, :cond_1f

    goto :goto_16

    :cond_1f
    new-array v0, v1, [C

    iget-object v3, p0, Lab8;->c:[C

    iget v4, p0, Lab8;->d:I

    invoke-static {v3, v2, v0, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v3, p0, Lab8;->b:I

    iget v4, p0, Lab8;->e:I

    sub-int/2addr v3, v4

    sub-int v5, v1, v3

    iget-object v6, p0, Lab8;->c:[C

    add-int/2addr v3, v4

    sub-int/2addr v3, v4

    invoke-static {v6, v4, v0, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, Lab8;->c:[C

    iput v1, p0, Lab8;->b:I

    iput v5, p0, Lab8;->e:I

    :goto_3c
    iget v0, p0, Lab8;->d:I

    if-ge p1, v0, :cond_53

    if-gt p2, v0, :cond_53

    sub-int/2addr v0, p2

    iget-object v1, p0, Lab8;->c:[C

    iget v3, p0, Lab8;->e:I

    sub-int/2addr v3, v0

    invoke-static {v1, p2, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput p1, p0, Lab8;->d:I

    iget p1, p0, Lab8;->e:I

    sub-int/2addr p1, v0

    iput p1, p0, Lab8;->e:I

    goto :goto_7c

    :cond_53
    if-ge p1, v0, :cond_61

    if-lt p2, v0, :cond_61

    invoke-virtual {p0}, Lab8;->b()I

    move-result v0

    add-int/2addr v0, p2

    iput v0, p0, Lab8;->e:I

    iput p1, p0, Lab8;->d:I

    goto :goto_7c

    :cond_61
    invoke-virtual {p0}, Lab8;->b()I

    move-result v0

    add-int/2addr v0, p1

    invoke-virtual {p0}, Lab8;->b()I

    move-result p1

    add-int/2addr p1, p2

    iget p2, p0, Lab8;->e:I

    sub-int/2addr v0, p2

    iget-object v1, p0, Lab8;->c:[C

    iget v3, p0, Lab8;->d:I

    invoke-static {v1, p2, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p2, p0, Lab8;->d:I

    add-int/2addr p2, v0

    iput p2, p0, Lab8;->d:I

    iput p1, p0, Lab8;->e:I

    :goto_7c
    iget-object p1, p0, Lab8;->c:[C

    iget p2, p0, Lab8;->d:I

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {p3, v2, v0, p1, p2}, Ljava/lang/String;->getChars(II[CI)V

    iget p1, p0, Lab8;->d:I

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p2

    add-int/2addr p2, p1

    iput p2, p0, Lab8;->d:I

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget p0, p0, Lab8;->a:I

    packed-switch p0, :pswitch_data_c

    const-string p0, ""

    return-object p0

    :pswitch_8  #0x0
    const-string p0, ""

    return-object p0

    nop

    :pswitch_data_c
    .packed-switch 0x0
        :pswitch_8  #00000000
    .end packed-switch
.end method
