.class public final Lalk;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lzjk;


# virtual methods
.method public final a()Ljava/lang/Double;
    .registers 3

    const-wide/high16 v0, 0x7ff8000000000000L  # Double.NaN

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 2

    if-ne p1, p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    instance-of p0, p1, Lalk;

    return p0
.end method

.method public final g()Ljava/util/Iterator;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method

.method public final h()Ljava/lang/String;
    .registers 1

    const-string p0, "undefined"

    return-object p0
.end method

.method public final k()Ljava/lang/Boolean;
    .registers 1

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final m()Lzjk;
    .registers 1

    sget-object p0, Lzjk;->v:Lalk;

    return-object p0
.end method

.method public final n(Ljava/lang/String;Lc91;Ljava/util/ArrayList;)Lzjk;
    .registers 4

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p2, "Undefined has no function "

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
