.class public final synthetic Lax0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lkxg;


# direct methods
.method public synthetic constructor <init>(Lkxg;I)V
    .registers 3

    iput p2, p0, Lax0;->E:I

    iput-object p1, p0, Lax0;->F:Lkxg;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 24

    move-object/from16 v0, p0

    iget v1, v0, Lax0;->E:I

    iget-object v2, v0, Lax0;->F:Lkxg;

    sget-object v3, Lz2j;->a:Lz2j;

    sget-object v4, Lxu4;->a:Lmx8;

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    packed-switch v1, :pswitch_data_4f6

    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_21

    move v5, v6

    :cond_21
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_4f

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_39

    if-ne v1, v4, :cond_43

    :cond_39
    new-instance v1, Lh82;

    const/16 v0, 0xe

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_43
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_52

    :cond_4f
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_52
    return-object v3

    :pswitch_53  #0xf
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_64

    move v5, v6

    :cond_64
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_9e

    sget-object v6, Lerl;->X:Lerl;

    iget-object v13, v0, Lax0;->F:Lkxg;

    invoke-virtual {v10, v13}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_7e

    if-ne v1, v4, :cond_92

    :cond_7e
    new-instance v11, Lzu0;

    const/16 v17, 0x0

    const/16 v18, 0xd

    const/4 v12, 0x0

    const-class v14, Lkxg;

    const-string v15, "animateToDismiss"

    const-string v16, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v11 .. v18}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v10, v11}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v1, v11

    :cond_92
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_a1

    :cond_9e
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_a1
    return-object v3

    :pswitch_a2  #0xe
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_b3

    move v5, v6

    :cond_b3
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_103

    sget-object v1, Lerl;->X:Lerl;

    invoke-static {v10}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v2

    iget-wide v6, v2, Lgw3;->n:J

    invoke-static {v10}, Lfx3;->a(Lzu4;)Lgw3;

    move-result-object v2

    iget-wide v8, v2, Lgw3;->M:J

    move-object v12, v10

    const-wide/16 v10, 0x0

    const/16 v13, 0xc

    invoke-static/range {v6 .. v13}, Lk52;->u(JJJLzu4;I)Lg69;

    move-result-object v8

    iget-object v15, v0, Lax0;->F:Lkxg;

    invoke-virtual {v12, v15}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v12}, Leb8;->R()Ljava/lang/Object;

    move-result-object v2

    if-nez v0, :cond_e2

    if-ne v2, v4, :cond_f6

    :cond_e2
    new-instance v13, Lzu0;

    const/16 v19, 0x0

    const/16 v20, 0xc

    const/4 v14, 0x0

    const-class v16, Lkxg;

    const-string v17, "animateToDismiss"

    const-string v18, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v13 .. v20}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v12, v13}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v2, v13

    :cond_f6
    move-object v9, v2

    check-cast v9, La98;

    const/16 v11, 0xc00

    move-object v10, v12

    const/4 v12, 0x1

    const/4 v7, 0x0

    move-object v6, v1

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_107

    :cond_103
    move-object v12, v10

    invoke-virtual {v12}, Leb8;->Z()V

    :goto_107
    return-object v3

    :pswitch_108  #0xd
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_119

    move v5, v6

    :cond_119
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_153

    sget-object v6, Lerl;->X:Lerl;

    iget-object v13, v0, Lax0;->F:Lkxg;

    invoke-virtual {v10, v13}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_133

    if-ne v1, v4, :cond_147

    :cond_133
    new-instance v11, Lzu0;

    const/16 v17, 0x0

    const/16 v18, 0xb

    const/4 v12, 0x0

    const-class v14, Lkxg;

    const-string v15, "animateToDismiss"

    const-string v16, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v11 .. v18}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v10, v11}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v1, v11

    :cond_147
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->k(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_156

    :cond_153
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_156
    return-object v3

    :pswitch_157  #0xc
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_168

    move v5, v6

    :cond_168
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_1a2

    sget-object v6, Lerl;->X:Lerl;

    iget-object v13, v0, Lax0;->F:Lkxg;

    invoke-virtual {v10, v13}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_182

    if-ne v1, v4, :cond_196

    :cond_182
    new-instance v11, Lzu0;

    const/16 v17, 0x0

    const/16 v18, 0xa

    const/4 v12, 0x0

    const-class v14, Lkxg;

    const-string v15, "animateToDismiss"

    const-string v16, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v11 .. v18}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v10, v11}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v1, v11

    :cond_196
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_1a5

    :cond_1a2
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_1a5
    return-object v3

    :pswitch_1a6  #0xb
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_1b7

    move v5, v6

    :cond_1b7
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_1e5

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_1cf

    if-ne v1, v4, :cond_1d9

    :cond_1cf
    new-instance v1, Lh82;

    const/16 v0, 0x8

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_1d9
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_1e8

    :cond_1e5
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_1e8
    return-object v3

    :pswitch_1e9  #0xa
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_1fa

    move v5, v6

    :cond_1fa
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_228

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_212

    if-ne v1, v4, :cond_21c

    :cond_212
    new-instance v1, Lh82;

    const/16 v0, 0xb

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_21c
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_22b

    :cond_228
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_22b
    return-object v3

    :pswitch_22c  #0x9
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_23d

    move v5, v6

    :cond_23d
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_26a

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_255

    if-ne v1, v4, :cond_25e

    :cond_255
    new-instance v1, Lh82;

    const/4 v0, 0x6

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_25e
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_26d

    :cond_26a
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_26d
    return-object v3

    :pswitch_26e  #0x8
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_27f

    move v5, v6

    :cond_27f
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_2ad

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_297

    if-ne v1, v4, :cond_2a1

    :cond_297
    new-instance v1, Lh82;

    const/16 v0, 0xa

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_2a1
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_2b0

    :cond_2ad
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_2b0
    return-object v3

    :pswitch_2b1  #0x7
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_2c2

    move v5, v6

    :cond_2c2
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_2ef

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_2da

    if-ne v1, v4, :cond_2e3

    :cond_2da
    new-instance v1, Lh82;

    const/4 v0, 0x7

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_2e3
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_2f2

    :cond_2ef
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_2f2
    return-object v3

    :pswitch_2f3  #0x6
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_304

    move v5, v6

    :cond_304
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_332

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_31c

    if-ne v1, v4, :cond_326

    :cond_31c
    new-instance v1, Lh82;

    const/16 v0, 0xc

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_326
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_335

    :cond_332
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_335
    return-object v3

    :pswitch_336  #0x5
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_347

    move v5, v6

    :cond_347
    and-int/2addr v1, v6

    move-object v10, v0

    check-cast v10, Leb8;

    invoke-virtual {v10, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_375

    sget-object v6, Lerl;->X:Lerl;

    invoke-virtual {v10, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_35f

    if-ne v1, v4, :cond_369

    :cond_35f
    new-instance v1, Lh82;

    const/16 v0, 0x9

    invoke-direct {v1, v2, v0}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v10, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_369
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_378

    :cond_375
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_378
    return-object v3

    :pswitch_379  #0x4
    move-object/from16 v0, p1

    check-cast v0, Lzu4;

    move-object/from16 v1, p2

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    and-int/lit8 v8, v1, 0x3

    if-eq v8, v7, :cond_38a

    move v5, v6

    :cond_38a
    and-int/2addr v1, v6

    move-object v12, v0

    check-cast v12, Leb8;

    invoke-virtual {v12, v1, v5}, Leb8;->W(IZ)Z

    move-result v0

    if-eqz v0, :cond_3b6

    sget-object v8, Lerl;->X:Lerl;

    invoke-virtual {v12, v2}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v12}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_3a2

    if-ne v1, v4, :cond_3aa

    :cond_3a2
    new-instance v1, Lh82;

    invoke-direct {v1, v2, v7}, Lh82;-><init>(Lkxg;I)V

    invoke-virtual {v12, v1}, Leb8;->q0(Ljava/lang/Object;)V

    :cond_3aa
    move-object v11, v1

    check-cast v11, La98;

    const/16 v13, 0xc00

    const/4 v14, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual/range {v8 .. v14}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_3b9

    :cond_3b6
    invoke-virtual {v12}, Leb8;->Z()V

    :goto_3b9
    return-object v3

    :pswitch_3ba  #0x3
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_3cb

    move v5, v6

    :cond_3cb
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_405

    sget-object v6, Lerl;->X:Lerl;

    iget-object v13, v0, Lax0;->F:Lkxg;

    invoke-virtual {v10, v13}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_3e5

    if-ne v1, v4, :cond_3f9

    :cond_3e5
    new-instance v11, Lzu0;

    const/16 v17, 0x0

    const/16 v18, 0x8

    const/4 v12, 0x0

    const-class v14, Lkxg;

    const-string v15, "animateToDismiss"

    const-string v16, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v11 .. v18}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v10, v11}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v1, v11

    :cond_3f9
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_408

    :cond_405
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_408
    return-object v3

    :pswitch_409  #0x2
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_41a

    move v5, v6

    :cond_41a
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_454

    sget-object v6, Lerl;->X:Lerl;

    iget-object v13, v0, Lax0;->F:Lkxg;

    invoke-virtual {v10, v13}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_434

    if-ne v1, v4, :cond_448

    :cond_434
    new-instance v11, Lzu0;

    const/16 v17, 0x0

    const/16 v18, 0x6

    const/4 v12, 0x0

    const-class v14, Lkxg;

    const-string v15, "animateToDismiss"

    const-string v16, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v11 .. v18}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v10, v11}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v1, v11

    :cond_448
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_457

    :cond_454
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_457
    return-object v3

    :pswitch_458  #0x1
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_469

    move v5, v6

    :cond_469
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_4a3

    sget-object v6, Lerl;->X:Lerl;

    iget-object v13, v0, Lax0;->F:Lkxg;

    invoke-virtual {v10, v13}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_483

    if-ne v1, v4, :cond_497

    :cond_483
    new-instance v11, Lzu0;

    const/16 v17, 0x0

    const/16 v18, 0x2

    const/4 v12, 0x0

    const-class v14, Lkxg;

    const-string v15, "animateToDismiss"

    const-string v16, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v11 .. v18}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v10, v11}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v1, v11

    :cond_497
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_4a6

    :cond_4a3
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_4a6
    return-object v3

    :pswitch_4a7  #0x0
    move-object/from16 v1, p1

    check-cast v1, Lzu4;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    and-int/lit8 v8, v2, 0x3

    if-eq v8, v7, :cond_4b8

    move v5, v6

    :cond_4b8
    and-int/2addr v2, v6

    move-object v10, v1

    check-cast v10, Leb8;

    invoke-virtual {v10, v2, v5}, Leb8;->W(IZ)Z

    move-result v1

    if-eqz v1, :cond_4f2

    sget-object v6, Lerl;->X:Lerl;

    iget-object v13, v0, Lax0;->F:Lkxg;

    invoke-virtual {v10, v13}, Leb8;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v10}, Leb8;->R()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_4d2

    if-ne v1, v4, :cond_4e6

    :cond_4d2
    new-instance v11, Lzu0;

    const/16 v17, 0x0

    const/16 v18, 0x1

    const/4 v12, 0x0

    const-class v14, Lkxg;

    const-string v15, "animateToDismiss"

    const-string v16, "animateToDismiss(Lkotlin/jvm/functions/Function0;)V"

    invoke-direct/range {v11 .. v18}, Lzu0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {v10, v11}, Leb8;->q0(Ljava/lang/Object;)V

    move-object v1, v11

    :cond_4e6
    move-object v9, v1

    check-cast v9, La98;

    const/16 v11, 0xc00

    const/4 v12, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v6 .. v12}, Lerl;->l(Ljava/lang/String;Lg69;La98;Lzu4;II)V

    goto :goto_4f5

    :cond_4f2
    invoke-virtual {v10}, Leb8;->Z()V

    :goto_4f5
    return-object v3

    :pswitch_data_4f6
    .packed-switch 0x0
        :pswitch_4a7  #00000000
        :pswitch_458  #00000001
        :pswitch_409  #00000002
        :pswitch_3ba  #00000003
        :pswitch_379  #00000004
        :pswitch_336  #00000005
        :pswitch_2f3  #00000006
        :pswitch_2b1  #00000007
        :pswitch_26e  #00000008
        :pswitch_22c  #00000009
        :pswitch_1e9  #0000000a
        :pswitch_1a6  #0000000b
        :pswitch_157  #0000000c
        :pswitch_108  #0000000d
        :pswitch_a2  #0000000e
        :pswitch_53  #0000000f
    .end packed-switch
.end method
