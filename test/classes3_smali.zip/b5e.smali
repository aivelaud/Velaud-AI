.class public final Lb5e;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public F:I

.field public final synthetic G:Lm5e;


# direct methods
.method public synthetic constructor <init>(Lm5e;La75;I)V
    .registers 4

    iput p3, p0, Lb5e;->E:I

    iput-object p1, p0, Lb5e;->G:Lm5e;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 4

    iget p1, p0, Lb5e;->E:I

    iget-object p0, p0, Lb5e;->G:Lm5e;

    packed-switch p1, :pswitch_data_24

    new-instance p1, Lb5e;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, Lb5e;-><init>(Lm5e;La75;I)V

    return-object p1

    :pswitch_e  #0x2
    new-instance p1, Lb5e;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lb5e;-><init>(Lm5e;La75;I)V

    return-object p1

    :pswitch_15  #0x1
    new-instance p1, Lb5e;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lb5e;-><init>(Lm5e;La75;I)V

    return-object p1

    :pswitch_1c  #0x0
    new-instance p1, Lb5e;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lb5e;-><init>(Lm5e;La75;I)V

    return-object p1

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_1c  #00000000
        :pswitch_15  #00000001
        :pswitch_e  #00000002
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget v0, p0, Lb5e;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    check-cast p1, Lua5;

    check-cast p2, La75;

    packed-switch v0, :pswitch_data_38

    invoke-virtual {p0, p1, p2}, Lb5e;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lb5e;

    invoke-virtual {p0, v1}, Lb5e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x2
    invoke-virtual {p0, p1, p2}, Lb5e;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lb5e;

    invoke-virtual {p0, v1}, Lb5e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_21  #0x1
    invoke-virtual {p0, p1, p2}, Lb5e;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lb5e;

    invoke-virtual {p0, v1}, Lb5e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2c  #0x0
    invoke-virtual {p0, p1, p2}, Lb5e;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lb5e;

    invoke-virtual {p0, v1}, Lb5e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_2c  #00000000
        :pswitch_21  #00000001
        :pswitch_16  #00000002
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    iget v0, p0, Lb5e;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    iget-object v2, p0, Lb5e;->G:Lm5e;

    const/4 v3, 0x0

    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v5, Lva5;->E:Lva5;

    const/4 v6, 0x1

    packed-switch v0, :pswitch_data_88

    iget v0, p0, Lb5e;->F:I

    if-eqz v0, :cond_1e

    if-ne v0, v6, :cond_19

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_2a

    :cond_19
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object p1, v3

    goto :goto_2a

    :cond_1e
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, Lb5e;->F:I

    invoke-static {v2, p0}, Lm5e;->P(Lm5e;Lc75;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_2a

    move-object p1, v5

    :cond_2a
    :goto_2a
    return-object p1

    :pswitch_2b  #0x2
    iget v0, p0, Lb5e;->F:I

    if-eqz v0, :cond_3a

    if-ne v0, v6, :cond_35

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_46

    :cond_35
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_46

    :cond_3a
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, Lb5e;->F:I

    invoke-static {v2, p0}, Lm5e;->O(Lm5e;Lc75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_46

    move-object v1, v5

    :cond_46
    :goto_46
    return-object v1

    :pswitch_47  #0x1
    iget v0, p0, Lb5e;->F:I

    if-eqz v0, :cond_56

    if-ne v0, v6, :cond_51

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_65

    :cond_51
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object p1, v3

    goto :goto_65

    :cond_56
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v6, p0, Lb5e;->F:I

    sget p1, Lm5e;->F:I

    const/4 p1, 0x0

    invoke-virtual {v2, p1, p0}, Lm5e;->S(ZLc75;)Ljava/io/Serializable;

    move-result-object p1

    if-ne p1, v5, :cond_65

    move-object p1, v5

    :cond_65
    :goto_65
    return-object p1

    :pswitch_66  #0x0
    iget v0, p0, Lb5e;->F:I

    if-eqz v0, :cond_75

    if-ne v0, v6, :cond_70

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_87

    :cond_70
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_87

    :cond_75
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v2, Lm5e;->g:Lsbe;

    iget-object p1, p1, Lsbe;->i:Ly42;

    iget-object v0, v2, Lm5e;->n:Ly42;

    iput v6, p0, Lb5e;->F:I

    invoke-static {p1, v0, p0}, Lnfl;->q(Lvre;Ldbg;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_87

    move-object v1, v5

    :cond_87
    :goto_87
    return-object v1

    :pswitch_data_88
    .packed-switch 0x0
        :pswitch_66  #00000000
        :pswitch_47  #00000001
        :pswitch_2b  #00000002
    .end packed-switch
.end method
