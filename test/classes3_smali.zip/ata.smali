.class public final enum Lata;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Lcfe;


# static fields
.field public static final enum F:Lata;

.field public static final enum G:Lata;

.field public static final enum H:Lata;

.field public static final enum I:Lata;

.field public static final enum J:Lata;

.field public static final enum K:Lata;

.field public static final enum L:Lata;

.field public static final synthetic M:[Lata;


# instance fields
.field public final E:I


# direct methods
.method static constructor <clinit>()V
    .registers 9

    new-instance v0, Lata;

    const-string v1, "REASON_UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lata;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lata;->F:Lata;

    new-instance v1, Lata;

    const-string v2, "MESSAGE_TOO_OLD"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lata;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lata;->G:Lata;

    new-instance v2, Lata;

    const-string v3, "CACHE_FULL"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lata;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lata;->H:Lata;

    new-instance v3, Lata;

    const-string v4, "PAYLOAD_TOO_BIG"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lata;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lata;->I:Lata;

    new-instance v4, Lata;

    const-string v5, "MAX_RETRIES_REACHED"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6, v6}, Lata;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lata;->J:Lata;

    new-instance v5, Lata;

    const-string v6, "INVALID_PAYLOD"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7, v7}, Lata;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lata;->K:Lata;

    new-instance v6, Lata;

    const-string v7, "SERVER_ERROR"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8, v8}, Lata;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lata;->L:Lata;

    filled-new-array/range {v0 .. v6}, [Lata;

    move-result-object v0

    sput-object v0, Lata;->M:[Lata;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;II)V
    .registers 4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lata;->E:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lata;
    .registers 2

    const-class v0, Lata;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lata;

    return-object p0
.end method

.method public static values()[Lata;
    .registers 1

    sget-object v0, Lata;->M:[Lata;

    invoke-virtual {v0}, [Lata;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lata;

    return-object v0
.end method


# virtual methods
.method public final a()I
    .registers 1

    iget p0, p0, Lata;->E:I

    return p0
.end method
