.class public final Lb62;
.super Lyka;
.source "SourceFile"


# instance fields
.field public h:C


# virtual methods
.method public final a(Ly9l;)V
    .registers 2

    invoke-virtual {p1, p0}, Ly9l;->j(Lb62;)V

    return-void
.end method
