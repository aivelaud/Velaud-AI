.class public final La25;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public F:I

.field public final synthetic G:Lb25;


# direct methods
.method public synthetic constructor <init>(Lb25;La75;I)V
    .registers 4

    iput p3, p0, La25;->E:I

    iput-object p1, p0, La25;->G:Lb25;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 4

    iget p1, p0, La25;->E:I

    iget-object p0, p0, La25;->G:Lb25;

    packed-switch p1, :pswitch_data_16

    new-instance p1, La25;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, La25;-><init>(Lb25;La75;I)V

    return-object p1

    :pswitch_e  #0x0
    new-instance p1, La25;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, La25;-><init>(Lb25;La75;I)V

    return-object p1

    nop

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget v0, p0, La25;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    check-cast p1, Lua5;

    check-cast p2, La75;

    packed-switch v0, :pswitch_data_22

    invoke-virtual {p0, p1, p2}, La25;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La25;

    invoke-virtual {p0, v1}, La25;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x0
    invoke-virtual {p0, p1, p2}, La25;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La25;

    invoke-virtual {p0, v1}, La25;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    iget v0, p0, La25;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    iget-object v2, p0, La25;->G:Lb25;

    const/4 v3, 0x0

    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v5, Lva5;->E:Lva5;

    const/4 v6, 0x1

    packed-switch v0, :pswitch_data_50

    iget v0, p0, La25;->F:I

    if-eqz v0, :cond_1e

    if-ne v0, v6, :cond_19

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_2c

    :cond_19
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_2c

    :cond_1e
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v2, Lb25;->b:Lioi;

    iput v6, p0, La25;->F:I

    invoke-virtual {p1, p0}, Lioi;->e(Lc75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_2c

    move-object v1, v5

    :cond_2c
    :goto_2c
    return-object v1

    :pswitch_2d  #0x0
    iget v0, p0, La25;->F:I

    if-eqz v0, :cond_3c

    if-ne v0, v6, :cond_37

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_4e

    :cond_37
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_4e

    :cond_3c
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v2, Lb25;->b:Lioi;

    iget-object p1, p1, Lioi;->r:Ly42;

    iget-object v0, v2, Lb25;->h:Ly42;

    iput v6, p0, La25;->F:I

    invoke-static {p1, v0, p0}, Lnfl;->q(Lvre;Ldbg;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_4e

    move-object v1, v5

    :cond_4e
    :goto_4e
    return-object v1

    nop

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_2d  #00000000
    .end packed-switch
.end method
