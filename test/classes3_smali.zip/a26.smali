.class public final La26;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public F:I

.field public final synthetic G:Li79;

.field public final synthetic H:Lde1;


# direct methods
.method public synthetic constructor <init>(Li79;Lde1;La75;I)V
    .registers 5

    iput p4, p0, La26;->E:I

    iput-object p1, p0, La26;->G:Li79;

    iput-object p2, p0, La26;->H:Lde1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 5

    iget p1, p0, La26;->E:I

    iget-object v0, p0, La26;->H:Lde1;

    iget-object p0, p0, La26;->G:Li79;

    packed-switch p1, :pswitch_data_1e

    new-instance p1, La26;

    const/4 v1, 0x2

    invoke-direct {p1, p0, v0, p2, v1}, La26;-><init>(Li79;Lde1;La75;I)V

    return-object p1

    :pswitch_10  #0x1
    new-instance p1, La26;

    const/4 v1, 0x1

    invoke-direct {p1, p0, v0, p2, v1}, La26;-><init>(Li79;Lde1;La75;I)V

    return-object p1

    :pswitch_17  #0x0
    new-instance p1, La26;

    const/4 v1, 0x0

    invoke-direct {p1, p0, v0, p2, v1}, La26;-><init>(Li79;Lde1;La75;I)V

    return-object p1

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_10  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget v0, p0, La26;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    check-cast p1, Lua5;

    check-cast p2, La75;

    packed-switch v0, :pswitch_data_2c

    invoke-virtual {p0, p1, p2}, La26;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La26;

    invoke-virtual {p0, v1}, La26;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x1
    invoke-virtual {p0, p1, p2}, La26;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La26;

    invoke-virtual {p0, v1}, La26;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_21  #0x0
    invoke-virtual {p0, p1, p2}, La26;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La26;

    invoke-virtual {p0, v1}, La26;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_21  #00000000
        :pswitch_16  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    iget v0, p0, La26;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    iget-object v2, p0, La26;->H:Lde1;

    iget-object v3, p0, La26;->G:Li79;

    const/4 v4, 0x0

    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v6, Lva5;->E:Lva5;

    const/4 v7, 0x1

    packed-switch v0, :pswitch_data_76

    iget v0, p0, La26;->F:I

    if-eqz v0, :cond_20

    if-ne v0, v7, :cond_1b

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_2c

    :cond_1b
    invoke-static {v5}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_2c

    :cond_20
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iput v7, p0, La26;->F:I

    invoke-virtual {v3, v2, p0}, Li79;->x(Lde1;Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_2c

    move-object v1, v6

    :cond_2c
    :goto_2c
    return-object v1

    :pswitch_2d  #0x1
    iget v0, p0, La26;->F:I

    if-eqz v0, :cond_3c

    if-ne v0, v7, :cond_37

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_50

    :cond_37
    invoke-static {v5}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_50

    :cond_3c
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v3, Li79;->H:Ljava/lang/Object;

    check-cast p1, Lc6g;

    iget v0, v2, Lde1;->a:F

    iput v7, p0, La26;->F:I

    sget-object v2, Lmy6;->F:Lmy6;

    invoke-virtual {p1, v0, v2, p0}, Lc6g;->S0(FLjava/lang/Object;Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_50

    move-object v1, v6

    :cond_50
    :goto_50
    return-object v1

    :pswitch_51  #0x0
    iget v0, p0, La26;->F:I

    if-eqz v0, :cond_60

    if-ne v0, v7, :cond_5b

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_74

    :cond_5b
    invoke-static {v5}, Le97;->j(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_74

    :cond_60
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v3, Li79;->G:Ljava/lang/Object;

    check-cast p1, Lc6g;

    iget v0, v2, Lde1;->a:F

    iput v7, p0, La26;->F:I

    sget-object v2, Lmy6;->G:Lmy6;

    invoke-virtual {p1, v0, v2, p0}, Lc6g;->S0(FLjava/lang/Object;Lavh;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_74

    move-object v1, v6

    :cond_74
    :goto_74
    return-object v1

    nop

    :pswitch_data_76
    .packed-switch 0x0
        :pswitch_51  #00000000
        :pswitch_2d  #00000001
    .end packed-switch
.end method
