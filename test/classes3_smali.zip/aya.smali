.class public Laya;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;
.implements Liz9;


# instance fields
.field public final E:J

.field public final F:J

.field public final G:J


# direct methods
.method public constructor <init>(JJJ)V
    .registers 14

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, 0x0

    cmp-long v2, p5, v0

    if-eqz v2, :cond_64

    const-wide/high16 v3, -0x8000000000000000L

    cmp-long v3, p5, v3

    if-eqz v3, :cond_5d

    iput-wide p1, p0, Laya;->E:J

    if-lez v2, :cond_31

    cmp-long v2, p1, p3

    if-ltz v2, :cond_18

    goto :goto_51

    :cond_18
    rem-long v2, p3, p5

    cmp-long v4, v2, v0

    if-ltz v4, :cond_1f

    goto :goto_20

    :cond_1f
    add-long/2addr v2, p5

    :goto_20
    rem-long/2addr p1, p5

    cmp-long v4, p1, v0

    if-ltz v4, :cond_26

    goto :goto_27

    :cond_26
    add-long/2addr p1, p5

    :goto_27
    sub-long/2addr v2, p1

    rem-long/2addr v2, p5

    cmp-long p1, v2, v0

    if-ltz p1, :cond_2e

    goto :goto_2f

    :cond_2e
    add-long/2addr v2, p5

    :goto_2f
    sub-long/2addr p3, v2

    goto :goto_51

    :cond_31
    if-gez v2, :cond_56

    cmp-long v2, p1, p3

    if-gtz v2, :cond_38

    goto :goto_51

    :cond_38
    neg-long v2, p5

    rem-long/2addr p1, v2

    cmp-long v4, p1, v0

    if-ltz v4, :cond_3f

    goto :goto_40

    :cond_3f
    add-long/2addr p1, v2

    :goto_40
    rem-long v4, p3, v2

    cmp-long v6, v4, v0

    if-ltz v6, :cond_47

    goto :goto_48

    :cond_47
    add-long/2addr v4, v2

    :goto_48
    sub-long/2addr p1, v4

    rem-long/2addr p1, v2

    cmp-long v0, p1, v0

    if-ltz v0, :cond_4f

    goto :goto_50

    :cond_4f
    add-long/2addr p1, v2

    :goto_50
    add-long/2addr p3, p1

    :goto_51
    iput-wide p3, p0, Laya;->F:J

    iput-wide p5, p0, Laya;->G:J

    return-void

    :cond_56
    const-string p0, "Step is zero."

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :cond_5d
    const-string p0, "Step must be greater than Long.MIN_VALUE to avoid overflow on negation."

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :cond_64
    const-string p0, "Step must be non-zero."

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 6

    instance-of v0, p1, Laya;

    if-eqz v0, :cond_2f

    invoke-virtual {p0}, Laya;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Laya;

    invoke-virtual {v0}, Laya;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2d

    :cond_13
    check-cast p1, Laya;

    iget-wide v0, p1, Laya;->E:J

    iget-wide v2, p0, Laya;->E:J

    cmp-long v0, v2, v0

    if-nez v0, :cond_2f

    iget-wide v0, p0, Laya;->F:J

    iget-wide v2, p1, Laya;->F:J

    cmp-long v0, v0, v2

    if-nez v0, :cond_2f

    iget-wide v0, p0, Laya;->G:J

    iget-wide p0, p1, Laya;->G:J

    cmp-long p0, v0, p0

    if-nez p0, :cond_2f

    :cond_2d
    const/4 p0, 0x1

    return p0

    :cond_2f
    const/4 p0, 0x0

    return p0
.end method

.method public hashCode()I
    .registers 5

    invoke-virtual {p0}, Laya;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 p0, -0x1

    return p0

    :cond_8
    iget-wide v0, p0, Laya;->E:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-wide v2, p0, Laya;->F:J

    invoke-static {v0, v2, v3, v1}, Lti6;->f(IJI)I

    move-result v0

    iget-wide v1, p0, Laya;->G:J

    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public isEmpty()Z
    .registers 8

    iget-wide v0, p0, Laya;->G:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-wide v3, p0, Laya;->F:J

    iget-wide v5, p0, Laya;->E:J

    cmp-long p0, v5, v3

    if-lez v0, :cond_14

    if-lez p0, :cond_13

    return v2

    :cond_13
    return v1

    :cond_14
    if-gez p0, :cond_17

    return v2

    :cond_17
    return v1
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 8

    new-instance v0, Lbya;

    iget-wide v3, p0, Laya;->F:J

    iget-wide v5, p0, Laya;->G:J

    iget-wide v1, p0, Laya;->E:J

    invoke-direct/range {v0 .. v6}, Lbya;-><init>(JJJ)V

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 9

    const-wide/16 v0, 0x0

    iget-wide v2, p0, Laya;->G:J

    cmp-long v0, v2, v0

    const-string v1, " step "

    iget-wide v4, p0, Laya;->F:J

    iget-wide v6, p0, Laya;->E:J

    new-instance p0, Ljava/lang/StringBuilder;

    if-lez v0, :cond_29

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, ".."

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    :goto_24
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_29
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, " downTo "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    neg-long v0, v2

    invoke-virtual {p0, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    goto :goto_24
.end method
