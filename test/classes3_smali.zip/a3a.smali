.class public final La3a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lwmk;


# direct methods
.method public constructor <init>(Lwmk;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La3a;->a:Lwmk;

    return-void
.end method
