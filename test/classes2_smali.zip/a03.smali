.class public final synthetic La03;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, La03;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 1

    iget p0, p0, La03;->E:I

    packed-switch p0, :pswitch_data_9e

    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatMessageActionEvents$ChatMessageActionClicked;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x1c
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatMessageActionEvents$ChatMessageAction;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_f  #0x1b
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatMessageActionEvents$ActionSource;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_14  #0x1a
    invoke-static {}, Lcom/anthropic/claude/api/chat/ChatMessage;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_19  #0x19
    invoke-static {}, Lcom/anthropic/claude/api/chat/ChatMessage;->d()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_1e  #0x18
    invoke-static {}, Lcom/anthropic/claude/api/chat/ChatMessage;->c()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_23  #0x17
    invoke-static {}, Lcom/anthropic/claude/api/chat/ChatMessage;->b()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_28  #0x16
    const/4 p0, 0x0

    invoke-static {p0}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object p0

    return-object p0

    :pswitch_2e  #0x15
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object p0

    return-object p0

    :pswitch_35  #0x14
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatListEvents$ConversationSearchVersion;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_3a  #0x13
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatListEvents$ConversationSearchSessionEnded;->b()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_3f  #0x12
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatListEvents$ConversationSearchSessionEnded;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_44  #0x11
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatListEvents$ConversationSearchSessionEnded;->c()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_49  #0x10
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatListEvents$ConversationSearchOutcome;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_4e  #0xf
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatListEvents$ConversationSearchEntryPoint;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_53  #0xe
    sget-object p0, Lj63;->a:Li63;

    sget-object p0, Lz2j;->a:Lz2j;

    return-object p0

    :pswitch_58  #0xd
    invoke-static {}, Lcom/anthropic/claude/api/chat/ChatFeedbackType;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_5d  #0xc
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$UploadSource;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_62  #0xb
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$ThinkingExported;->b()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_67  #0xa
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$ThinkingExported;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_6c  #0x9
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$ThinkingExportSurface;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_71  #0x8
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$ThinkingExportAction;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_76  #0x7
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingResponseSuccess;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_7b  #0x6
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingMessageJank;->b()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_80  #0x5
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingMessageJank;->c()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_85  #0x4
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingMessageJank;->d()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_8a  #0x3
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingMessageJank;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_8f  #0x2
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingMessageCompletionStatus;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_94  #0x1
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingErrorSource;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_99  #0x0
    invoke-static {}, Lcom/anthropic/claude/analytics/events/ChatEvents$StreamingEndpointType;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_data_9e
    .packed-switch 0x0
        :pswitch_99  #00000000
        :pswitch_94  #00000001
        :pswitch_8f  #00000002
        :pswitch_8a  #00000003
        :pswitch_85  #00000004
        :pswitch_80  #00000005
        :pswitch_7b  #00000006
        :pswitch_76  #00000007
        :pswitch_71  #00000008
        :pswitch_6c  #00000009
        :pswitch_67  #0000000a
        :pswitch_62  #0000000b
        :pswitch_5d  #0000000c
        :pswitch_58  #0000000d
        :pswitch_53  #0000000e
        :pswitch_4e  #0000000f
        :pswitch_49  #00000010
        :pswitch_44  #00000011
        :pswitch_3f  #00000012
        :pswitch_3a  #00000013
        :pswitch_35  #00000014
        :pswitch_2e  #00000015
        :pswitch_28  #00000016
        :pswitch_23  #00000017
        :pswitch_1e  #00000018
        :pswitch_19  #00000019
        :pswitch_14  #0000001a
        :pswitch_f  #0000001b
        :pswitch_a  #0000001c
    .end packed-switch
.end method
