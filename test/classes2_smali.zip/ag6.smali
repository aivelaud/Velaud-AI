.class public final synthetic Lag6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lag6;->E:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 8

    iget p0, p0, Lag6;->E:I

    packed-switch p0, :pswitch_data_12a

    invoke-static {}, Lcom/anthropic/claude/sessions/types/EnvironmentListResponse;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x1c
    invoke-static {}, Lcom/anthropic/claude/sessions/types/EnvironmentKind;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_f  #0x1b
    invoke-static {}, Lcom/anthropic/claude/sessions/types/EnvironmentCreateRequest;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_14  #0x1a
    invoke-static {}, Lcom/anthropic/claude/sessions/types/EnvironmentConfiguration$Anthropic;->c()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_19  #0x19
    invoke-static {}, Lcom/anthropic/claude/sessions/types/EnvironmentConfiguration$Anthropic;->b()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_1e  #0x18
    invoke-static {}, Lcom/anthropic/claude/sessions/types/EnvironmentConfiguration;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_23  #0x17
    invoke-static {}, Lcom/anthropic/claude/api/consent/EntityType;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_28  #0x16
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p0

    :pswitch_2b  #0x15
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object p0

    return-object p0

    :pswitch_32  #0x14
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p0}, Lao9;->U(Ljava/lang/Object;)Ltad;

    move-result-object p0

    return-object p0

    :pswitch_39  #0x13
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DrawerEvents$DrawerTabVisibilityToggled;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_3e  #0x12
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DrawerEvents$DrawerTabReordered;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_43  #0x11
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DrawerEvents$DrawerOpened;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_48  #0x10
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DrawerEvents$DrawerOpenSource;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_4d  #0xf
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DrawerEvents$DrawerItemSelected;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_52  #0xe
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DrawerEvents$DrawerColdStartRestored;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_57  #0xd
    new-instance p0, Ltn6;

    new-instance v0, Ljef;

    const-wide/16 v3, -0x1

    const-wide/16 v5, -0x1

    sget-object v1, Lhw6;->E:Lhw6;

    const-string v2, "composeResources/claude.agentchat.generated.resources/drawable/scribble_working.xml"

    invoke-direct/range {v0 .. v6}, Ljef;-><init>(Ljava/util/Set;Ljava/lang/String;JJ)V

    invoke-static {v0}, Lrck;->W(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const-string v1, "drawable:scribble_working"

    invoke-direct {p0, v1, v0}, Lhcf;-><init>(Ljava/lang/String;Ljava/util/Set;)V

    return-object p0

    :pswitch_70  #0xc
    new-instance p0, Ltn6;

    new-instance v0, Ljef;

    const-wide/16 v3, -0x1

    const-wide/16 v5, -0x1

    sget-object v1, Lhw6;->E:Lhw6;

    const-string v2, "composeResources/claude.agentchat.generated.resources/drawable/scribble_compacting.xml"

    invoke-direct/range {v0 .. v6}, Ljef;-><init>(Ljava/util/Set;Ljava/lang/String;JJ)V

    invoke-static {v0}, Lrck;->W(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const-string v1, "drawable:scribble_compacting"

    invoke-direct {p0, v1, v0}, Lhcf;-><init>(Ljava/lang/String;Ljava/util/Set;)V

    return-object p0

    :pswitch_89  #0xb
    new-instance p0, Ltn6;

    new-instance v0, Ljef;

    const-wide/16 v3, -0x1

    const-wide/16 v5, -0x1

    sget-object v1, Lhw6;->E:Lhw6;

    const-string v2, "composeResources/claude.agentchat.generated.resources/drawable/onboarding_x.xml"

    invoke-direct/range {v0 .. v6}, Ljef;-><init>(Ljava/util/Set;Ljava/lang/String;JJ)V

    invoke-static {v0}, Lrck;->W(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const-string v1, "drawable:onboarding_x"

    invoke-direct {p0, v1, v0}, Lhcf;-><init>(Ljava/lang/String;Ljava/util/Set;)V

    return-object p0

    :pswitch_a2  #0xa
    new-instance p0, Ltn6;

    new-instance v0, Ljef;

    const-wide/16 v3, -0x1

    const-wide/16 v5, -0x1

    sget-object v1, Lhw6;->E:Lhw6;

    const-string v2, "composeResources/claude.agentchat.generated.resources/drawable/onboarding_phone.xml"

    invoke-direct/range {v0 .. v6}, Ljef;-><init>(Ljava/util/Set;Ljava/lang/String;JJ)V

    invoke-static {v0}, Lrck;->W(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const-string v1, "drawable:onboarding_phone"

    invoke-direct {p0, v1, v0}, Lhcf;-><init>(Ljava/lang/String;Ljava/util/Set;)V

    return-object p0

    :pswitch_bb  #0x9
    new-instance p0, Ltn6;

    new-instance v0, Ljef;

    const-wide/16 v3, -0x1

    const-wide/16 v5, -0x1

    sget-object v1, Lhw6;->E:Lhw6;

    const-string v2, "composeResources/claude.agentchat.generated.resources/drawable/onboarding_loop.xml"

    invoke-direct/range {v0 .. v6}, Ljef;-><init>(Ljava/util/Set;Ljava/lang/String;JJ)V

    invoke-static {v0}, Lrck;->W(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const-string v1, "drawable:onboarding_loop"

    invoke-direct {p0, v1, v0}, Lhcf;-><init>(Ljava/lang/String;Ljava/util/Set;)V

    return-object p0

    :pswitch_d4  #0x8
    new-instance p0, Ltn6;

    new-instance v0, Ljef;

    const-wide/16 v3, -0x1

    const-wide/16 v5, -0x1

    sget-object v1, Lhw6;->E:Lhw6;

    const-string v2, "composeResources/claude.agentchat.generated.resources/drawable/onboarding_laptop.xml"

    invoke-direct/range {v0 .. v6}, Ljef;-><init>(Ljava/util/Set;Ljava/lang/String;JJ)V

    invoke-static {v0}, Lrck;->W(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const-string v1, "drawable:onboarding_laptop"

    invoke-direct {p0, v1, v0}, Lhcf;-><init>(Ljava/lang/String;Ljava/util/Set;)V

    return-object p0

    :pswitch_ed  #0x7
    new-instance p0, Ltn6;

    new-instance v0, Ljef;

    const-wide/16 v3, -0x1

    const-wide/16 v5, -0x1

    sget-object v1, Lhw6;->E:Lhw6;

    const-string v2, "composeResources/claude.agentchat.generated.resources/drawable/onboarding_check.xml"

    invoke-direct/range {v0 .. v6}, Ljef;-><init>(Ljava/util/Set;Ljava/lang/String;JJ)V

    invoke-static {v0}, Lrck;->W(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const-string v1, "drawable:onboarding_check"

    invoke-direct {p0, v1, v0}, Lhcf;-><init>(Ljava/lang/String;Ljava/util/Set;)V

    return-object p0

    :pswitch_106  #0x6
    sget p0, Lyl6;->a:F

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p0

    :pswitch_10b  #0x5
    invoke-static {}, Lcom/anthropic/claude/chat/input/draft/DraftMessage;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_110  #0x4
    invoke-static {}, Lcom/anthropic/claude/chat/input/draft/DraftMessage;->b()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_115  #0x3
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DispatchEvents$StarterIntroDismissReason;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_11a  #0x2
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DispatchEvents$StarterIntroCompleted;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_11f  #0x1
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DispatchEvents$PairingFailureReason;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    :pswitch_124  #0x0
    invoke-static {}, Lcom/anthropic/claude/analytics/events/DispatchEvents$OnboardingPairingFailed;->a()Lkotlinx/serialization/KSerializer;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_12a
    .packed-switch 0x0
        :pswitch_124  #00000000
        :pswitch_11f  #00000001
        :pswitch_11a  #00000002
        :pswitch_115  #00000003
        :pswitch_110  #00000004
        :pswitch_10b  #00000005
        :pswitch_106  #00000006
        :pswitch_ed  #00000007
        :pswitch_d4  #00000008
        :pswitch_bb  #00000009
        :pswitch_a2  #0000000a
        :pswitch_89  #0000000b
        :pswitch_70  #0000000c
        :pswitch_57  #0000000d
        :pswitch_52  #0000000e
        :pswitch_4d  #0000000f
        :pswitch_48  #00000010
        :pswitch_43  #00000011
        :pswitch_3e  #00000012
        :pswitch_39  #00000013
        :pswitch_32  #00000014
        :pswitch_2b  #00000015
        :pswitch_28  #00000016
        :pswitch_23  #00000017
        :pswitch_1e  #00000018
        :pswitch_19  #00000019
        :pswitch_14  #0000001a
        :pswitch_f  #0000001b
        :pswitch_a  #0000001c
    .end packed-switch
.end method
