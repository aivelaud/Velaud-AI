.class public abstract La6b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lv5b;

.field public static final b:Lv5b;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget-object v0, Llfe;->c:Llfe;

    const/4 v0, 0x0

    :try_start_3
    const-string v1, "androidx.glance.appwidget.protobuf.MapFieldSchemaFull"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lv5b;
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_13} :catch_14

    move-object v0, v1

    :catch_14
    sput-object v0, La6b;->a:Lv5b;

    new-instance v0, Lv5b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La6b;->b:Lv5b;

    return-void
.end method
