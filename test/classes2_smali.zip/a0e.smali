.class public final La0e;
.super Ljdh;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:J

.field public final c:J


# direct methods
.method public constructor <init>(JIJ)V
    .registers 6

    iput p3, p0, La0e;->a:I

    packed-switch p3, :pswitch_data_16

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p4, p0, La0e;->b:J

    iput-wide p1, p0, La0e;->c:J

    return-void

    :pswitch_d  #0x2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, La0e;->b:J

    iput-wide p4, p0, La0e;->c:J

    return-void

    nop

    :pswitch_data_16
    .packed-switch 0x2
        :pswitch_d  #00000002
    .end packed-switch
.end method

.method public constructor <init>(JJLjava/util/List;)V
    .registers 7

    const/4 v0, 0x1

    iput v0, p0, La0e;->a:I

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    iput-wide p1, p0, La0e;->b:J

    .line 24
    iput-wide p3, p0, La0e;->c:J

    .line 25
    invoke-static {p5}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    return-void
.end method

.method public static d(JLabd;)J
    .registers 9

    invoke-virtual {p2}, Labd;->z()I

    move-result v0

    int-to-long v0, v0

    const-wide/16 v2, 0x80

    and-long/2addr v2, v0

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-eqz v2, :cond_21

    const-wide/16 v2, 0x1

    and-long/2addr v0, v2

    const/16 v2, 0x20

    shl-long/2addr v0, v2

    invoke-virtual {p2}, Labd;->B()J

    move-result-wide v2

    or-long/2addr v0, v2

    add-long/2addr v0, p0

    const-wide p0, 0x1ffffffffL

    and-long/2addr p0, v0

    return-wide p0

    :cond_21
    const-wide p0, -0x7fffffffffffffffL  # -4.9E-324

    return-wide p0
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 4

    iget v0, p0, La0e;->a:I

    packed-switch v0, :pswitch_data_54

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "SCTE-35 TimeSignalCommand { ptsTime="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, La0e;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", playbackPositionUs= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, La0e;->c:J

    const-string p0, " }"

    invoke-static {v1, v2, p0, v0}, Lkec;->s(JLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_1f  #0x1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "SCTE-35 SpliceInsertCommand { programSplicePts="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, La0e;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", programSplicePlaybackPositionUs= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, La0e;->c:J

    const-string p0, " }"

    invoke-static {v1, v2, p0, v0}, Lkec;->s(JLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_39  #0x0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "SCTE-35 PrivateCommand { ptsAdjustment="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, La0e;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", identifier= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, La0e;->c:J

    const-string p0, " }"

    invoke-static {v1, v2, p0, v0}, Lkec;->s(JLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_54
    .packed-switch 0x0
        :pswitch_39  #00000000
        :pswitch_1f  #00000001
    .end packed-switch
.end method
