.class public final La16;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public b:I

.field public c:J

.field public final d:Lvnb;

.field public e:Z

.field public f:Z

.field public final synthetic g:Lb16;


# direct methods
.method public constructor <init>(Lb16;Ljava/lang/String;ILvnb;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La16;->g:Lb16;

    iput-object p2, p0, La16;->a:Ljava/lang/String;

    iput p3, p0, La16;->b:I

    if-nez p4, :cond_e

    const-wide/16 p1, -0x1

    goto :goto_10

    :cond_e
    iget-wide p1, p4, Lvnb;->d:J

    :goto_10
    iput-wide p1, p0, La16;->c:J

    if-eqz p4, :cond_1c

    invoke-virtual {p4}, Lvnb;->b()Z

    move-result p1

    if-eqz p1, :cond_1c

    iput-object p4, p0, La16;->d:Lvnb;

    :cond_1c
    return-void
.end method


# virtual methods
.method public final a(Lly;)Z
    .registers 9

    iget-object v0, p1, Lly;->d:Lvnb;

    iget-object v1, p1, Lly;->b:Lqgi;

    if-nez v0, :cond_d

    iget p0, p0, La16;->b:I

    iget p1, p1, Lly;->c:I

    if-eq p0, p1, :cond_5a

    goto :goto_58

    :cond_d
    iget-wide v2, p0, La16;->c:J

    const-wide/16 v4, -0x1

    cmp-long p1, v2, v4

    if-nez p1, :cond_16

    goto :goto_5a

    :cond_16
    iget-wide v4, v0, Lvnb;->d:J

    cmp-long p1, v4, v2

    if-lez p1, :cond_1d

    goto :goto_58

    :cond_1d
    iget-object p0, p0, La16;->d:Lvnb;

    if-nez p0, :cond_22

    goto :goto_5a

    :cond_22
    iget p1, p0, Lvnb;->b:I

    iget-object v2, v0, Lvnb;->a:Ljava/lang/Object;

    invoke-virtual {v1, v2}, Lqgi;->b(Ljava/lang/Object;)I

    move-result v2

    iget-object v3, p0, Lvnb;->a:Ljava/lang/Object;

    invoke-virtual {v1, v3}, Lqgi;->b(Ljava/lang/Object;)I

    move-result v1

    iget-wide v3, v0, Lvnb;->d:J

    iget-wide v5, p0, Lvnb;->d:J

    cmp-long v3, v3, v5

    if-ltz v3, :cond_5a

    if-ge v2, v1, :cond_3b

    goto :goto_5a

    :cond_3b
    if-le v2, v1, :cond_3e

    goto :goto_58

    :cond_3e
    invoke-virtual {v0}, Lvnb;->b()Z

    move-result v1

    if-eqz v1, :cond_51

    iget v1, v0, Lvnb;->b:I

    iget v0, v0, Lvnb;->c:I

    if-gt v1, p1, :cond_58

    if-ne v1, p1, :cond_5a

    iget p0, p0, Lvnb;->c:I

    if-le v0, p0, :cond_5a

    goto :goto_58

    :cond_51
    iget p0, v0, Lvnb;->e:I

    const/4 v0, -0x1

    if-eq p0, v0, :cond_58

    if-le p0, p1, :cond_5a

    :cond_58
    :goto_58
    const/4 p0, 0x1

    return p0

    :cond_5a
    :goto_5a
    const/4 p0, 0x0

    return p0
.end method

.method public final b(Lqgi;Lqgi;)Z
    .registers 9

    iget v0, p0, La16;->b:I

    invoke-virtual {p1}, Lqgi;->o()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, -0x1

    if-lt v0, v1, :cond_13

    invoke-virtual {p2}, Lqgi;->o()I

    move-result p1

    if-ge v0, p1, :cond_11

    goto :goto_36

    :cond_11
    move v0, v3

    goto :goto_36

    :cond_13
    iget-object v1, p0, La16;->g:Lb16;

    iget-object v4, v1, Lb16;->a:Logi;

    invoke-virtual {p1, v0, v4}, Lqgi;->n(ILogi;)V

    iget v0, v4, Logi;->l:I

    :goto_1c
    iget v5, v4, Logi;->m:I

    if-gt v0, v5, :cond_11

    invoke-virtual {p1, v0}, Lqgi;->l(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {p2, v5}, Lqgi;->b(Ljava/lang/Object;)I

    move-result v5

    if-eq v5, v3, :cond_33

    iget-object p1, v1, Lb16;->b:Lngi;

    invoke-virtual {p2, v5, p1, v2}, Lqgi;->f(ILngi;Z)Lngi;

    move-result-object p1

    iget v0, p1, Lngi;->c:I

    goto :goto_36

    :cond_33
    add-int/lit8 v0, v0, 0x1

    goto :goto_1c

    :goto_36
    iput v0, p0, La16;->b:I

    if-ne v0, v3, :cond_3b

    goto :goto_4a

    :cond_3b
    iget-object p0, p0, La16;->d:Lvnb;

    if-nez p0, :cond_40

    goto :goto_48

    :cond_40
    iget-object p0, p0, Lvnb;->a:Ljava/lang/Object;

    invoke-virtual {p2, p0}, Lqgi;->b(Ljava/lang/Object;)I

    move-result p0

    if-eq p0, v3, :cond_4a

    :goto_48
    const/4 p0, 0x1

    return p0

    :cond_4a
    :goto_4a
    return v2
.end method
