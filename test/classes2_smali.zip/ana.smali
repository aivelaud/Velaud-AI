.class public final Lana;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# instance fields
.field public final synthetic E:Lhna;


# direct methods
.method public constructor <init>(Lhna;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lana;->E:Lhna;

    return-void
.end method


# virtual methods
.method public final onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 6

    const/4 p1, -0x1

    if-eq p3, p1, :cond_d

    iget-object p0, p0, Lana;->E:Lhna;

    iget-object p0, p0, Lhna;->G:Lqq6;

    if-eqz p0, :cond_d

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lqq6;->setListSelectionHidden(Z)V

    :cond_d
    return-void
.end method

.method public final onNothingSelected(Landroid/widget/AdapterView;)V
    .registers 2

    return-void
.end method
