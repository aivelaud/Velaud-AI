.class public final La1b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Li0b;

.field public final b:Ljava/lang/Throwable;


# direct methods
.method public constructor <init>(Li0b;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La1b;->a:Li0b;

    const/4 p1, 0x0

    iput-object p1, p0, La1b;->b:Ljava/lang/Throwable;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;)V
    .registers 2

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, La1b;->b:Ljava/lang/Throwable;

    const/4 p1, 0x0

    .line 11
    iput-object p1, p0, La1b;->a:Li0b;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La1b;

    if-nez v1, :cond_9

    goto :goto_2a

    :cond_9
    check-cast p1, La1b;

    iget-object v1, p0, La1b;->a:Li0b;

    if-eqz v1, :cond_15

    iget-object v2, p1, La1b;->a:Li0b;

    if-eq v1, v2, :cond_14

    goto :goto_15

    :cond_14
    return v0

    :cond_15
    :goto_15
    iget-object p0, p0, La1b;->b:Ljava/lang/Throwable;

    if-eqz p0, :cond_2a

    iget-object p1, p1, La1b;->b:Ljava/lang/Throwable;

    if-eqz p1, :cond_2a

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_2a
    :goto_2a
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, La1b;->a:Li0b;

    iget-object p0, p0, La1b;->b:Ljava/lang/Throwable;

    filled-new-array {v0, p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result p0

    return p0
.end method
