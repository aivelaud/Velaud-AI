.class public final La7e;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public F:I

.field public final synthetic G:Lb7e;


# direct methods
.method public synthetic constructor <init>(Lb7e;La75;I)V
    .registers 4

    iput p3, p0, La7e;->E:I

    iput-object p1, p0, La7e;->G:Lb7e;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 4

    iget p1, p0, La7e;->E:I

    iget-object p0, p0, La7e;->G:Lb7e;

    packed-switch p1, :pswitch_data_16

    new-instance p1, La7e;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, La7e;-><init>(Lb7e;La75;I)V

    return-object p1

    :pswitch_e  #0x0
    new-instance p1, La7e;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, La7e;-><init>(Lb7e;La75;I)V

    return-object p1

    nop

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget v0, p0, La7e;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    check-cast p1, Lua5;

    check-cast p2, La75;

    packed-switch v0, :pswitch_data_22

    invoke-virtual {p0, p1, p2}, La7e;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La7e;

    invoke-virtual {p0, v1}, La7e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x0
    invoke-virtual {p0, p1, p2}, La7e;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, La7e;

    invoke-virtual {p0, v1}, La7e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    iget v0, p0, La7e;->E:I

    iget-object v1, p0, La7e;->G:Lb7e;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v3, Lva5;->E:Lva5;

    const/4 v4, 0x1

    const/4 v5, 0x0

    packed-switch v0, :pswitch_data_5e

    iget v0, p0, La7e;->F:I

    if-eqz v0, :cond_1c

    if-ne v0, v4, :cond_17

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_30

    :cond_17
    invoke-static {v2}, Le97;->j(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_30

    :cond_1c
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v1, Lb7e;->c:Lsbe;

    iget-object v0, v1, Lb7e;->b:Lcom/anthropic/claude/project/knowledge/ProjectKnowledgeScreenParams;

    invoke-virtual {v0}, Lcom/anthropic/claude/project/knowledge/ProjectKnowledgeScreenParams;->getProjectId-5pmjb-U()Ljava/lang/String;

    move-result-object v0

    iput v4, p0, La7e;->F:I

    invoke-virtual {p1, v0, p0}, Lsbe;->i(Ljava/lang/String;Lc75;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v3, :cond_30

    move-object p1, v3

    :cond_30
    :goto_30
    return-object p1

    :pswitch_31  #0x0
    iget v0, p0, La7e;->F:I

    if-eqz v0, :cond_40

    if-ne v0, v4, :cond_3b

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_5c

    :cond_3b
    invoke-static {v2}, Le97;->j(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_5c

    :cond_40
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v1, Lb7e;->c:Lsbe;

    iget-object v0, v1, Lb7e;->b:Lcom/anthropic/claude/project/knowledge/ProjectKnowledgeScreenParams;

    invoke-virtual {v0}, Lcom/anthropic/claude/project/knowledge/ProjectKnowledgeScreenParams;->getProjectId-5pmjb-U()Ljava/lang/String;

    move-result-object v0

    iput v4, p0, La7e;->F:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lgq;

    invoke-direct {v1, p1, v0, v5}, Lgq;-><init>(Lsbe;Ljava/lang/String;La75;)V

    invoke-static {v1, p0}, Lvi9;->E(Lq98;La75;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v3, :cond_5c

    move-object p1, v3

    :cond_5c
    :goto_5c
    return-object p1

    nop

    :pswitch_data_5e
    .packed-switch 0x0
        :pswitch_31  #00000000
    .end packed-switch
.end method
