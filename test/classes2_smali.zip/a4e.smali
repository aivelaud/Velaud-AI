.class public final La4e;
.super Lt68;
.source "SourceFile"


# virtual methods
.method public final f(ILngi;Z)Lngi;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lt68;->f(ILngi;Z)Lngi;

    const/4 p0, 0x1

    iput-boolean p0, p2, Lngi;->f:Z

    return-object p2
.end method

.method public final m(ILogi;J)Logi;
    .registers 5

    invoke-super {p0, p1, p2, p3, p4}, Lt68;->m(ILogi;J)Logi;

    const/4 p0, 0x1

    iput-boolean p0, p2, Logi;->i:Z

    return-object p2
.end method
