.class public final La91;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lz81;

.field public final b:I

.field public final c:Lfgk;

.field public d:I

.field public e:J

.field public f:J

.field public g:J

.field public h:J

.field public i:J


# direct methods
.method public constructor <init>(Landroid/media/AudioTrack;Lfgk;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lz81;

    invoke-direct {v0, p1}, Lz81;-><init>(Landroid/media/AudioTrack;)V

    iput-object v0, p0, La91;->a:Lz81;

    invoke-virtual {p1}, Landroid/media/AudioTrack;->getSampleRate()I

    move-result p1

    iput p1, p0, La91;->b:I

    iput-object p2, p0, La91;->c:Lfgk;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, La91;->a(I)V

    return-void
.end method


# virtual methods
.method public final a(I)V
    .registers 8

    iput p1, p0, La91;->d:I

    const-wide/16 v0, 0x2710

    if-eqz p1, :cond_25

    const/4 v2, 0x1

    if-eq p1, v2, :cond_22

    const/4 v0, 0x2

    if-eq p1, v0, :cond_1c

    const/4 v0, 0x3

    if-eq p1, v0, :cond_1c

    const/4 v0, 0x4

    if-ne p1, v0, :cond_18

    const-wide/32 v0, 0x7a120

    iput-wide v0, p0, La91;->f:J

    return-void

    :cond_18
    invoke-static {}, Lio/sentry/i2;->b()V

    return-void

    :cond_1c
    const-wide/32 v0, 0x989680

    iput-wide v0, p0, La91;->f:J

    return-void

    :cond_22
    iput-wide v0, p0, La91;->f:J

    return-void

    :cond_25
    const-wide/16 v2, 0x0

    iput-wide v2, p0, La91;->g:J

    const-wide/16 v2, -0x1

    iput-wide v2, p0, La91;->h:J

    const-wide v2, -0x7fffffffffffffffL  # -4.9E-324

    iput-wide v2, p0, La91;->i:J

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    const-wide/16 v4, 0x3e8

    div-long/2addr v2, v4

    iput-wide v2, p0, La91;->e:J

    iput-wide v0, p0, La91;->f:J

    return-void
.end method
