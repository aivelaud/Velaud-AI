.class public final Laga;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# static fields
.field public static final G:Ltfa;

.field public static final H:Ljava/util/LinkedHashMap;


# instance fields
.field public final E:D

.field public final F:Lzfa;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    new-instance v0, Ltfa;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Laga;->G:Ltfa;

    invoke-static {}, Lzfa;->values()[Lzfa;

    move-result-object v0

    new-instance v1, Ljava/util/LinkedHashMap;

    array-length v2, v0

    invoke-static {v2}, Lr7b;->S(I)I

    move-result v2

    const/16 v3, 0x10

    if-ge v2, v3, :cond_17

    move v2, v3

    :cond_17
    invoke-direct {v1, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    array-length v2, v0

    const/4 v3, 0x0

    :goto_1c
    if-ge v3, v2, :cond_2d

    aget-object v4, v0, v3

    new-instance v5, Laga;

    const-wide/16 v6, 0x0

    invoke-direct {v5, v6, v7, v4}, Laga;-><init>(DLzfa;)V

    invoke-interface {v1, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v3, v3, 0x1

    goto :goto_1c

    :cond_2d
    sput-object v1, Laga;->H:Ljava/util/LinkedHashMap;

    return-void
.end method

.method public constructor <init>(DLzfa;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Laga;->E:D

    iput-object p3, p0, Laga;->F:Lzfa;

    return-void
.end method


# virtual methods
.method public final a()D
    .registers 5

    iget-object v0, p0, Laga;->F:Lzfa;

    invoke-virtual {v0}, Lzfa;->a()D

    move-result-wide v0

    iget-wide v2, p0, Laga;->E:D

    mul-double/2addr v0, v2

    return-wide v0
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 4

    check-cast p1, Laga;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Laga;->F:Lzfa;

    iget-object v1, p1, Laga;->F:Lzfa;

    if-ne v0, v1, :cond_14

    iget-wide v0, p0, Laga;->E:D

    iget-wide p0, p1, Laga;->E:D

    invoke-static {v0, v1, p0, p1}, Ljava/lang/Double;->compare(DD)I

    move-result p0

    return p0

    :cond_14
    invoke-virtual {p0}, Laga;->a()D

    move-result-wide v0

    invoke-virtual {p1}, Laga;->a()D

    move-result-wide p0

    invoke-static {v0, v1, p0, p1}, Ljava/lang/Double;->compare(DD)I

    move-result p0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Laga;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Laga;

    iget-object v1, p1, Laga;->F:Lzfa;

    iget-object v3, p0, Laga;->F:Lzfa;

    if-ne v3, v1, :cond_1c

    iget-wide v3, p0, Laga;->E:D

    iget-wide p0, p1, Laga;->E:D

    cmpg-double p0, v3, p0

    if-nez p0, :cond_1b

    return v0

    :cond_1b
    return v2

    :cond_1c
    invoke-virtual {p0}, Laga;->a()D

    move-result-wide v3

    invoke-virtual {p1}, Laga;->a()D

    move-result-wide p0

    cmpg-double p0, v3, p0

    if-nez p0, :cond_29

    return v0

    :cond_29
    return v2
.end method

.method public final hashCode()I
    .registers 3

    invoke-virtual {p0}, Laga;->a()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->hashCode(D)I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-wide v1, p0, Laga;->E:D

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object p0, p0, Laga;->F:Lzfa;

    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
