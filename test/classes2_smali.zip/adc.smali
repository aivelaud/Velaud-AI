.class public final Ladc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/ListIterator;
.implements Liz9;


# instance fields
.field public final synthetic E:I

.field public final F:Ljava/util/List;

.field public G:I


# direct methods
.method public constructor <init>(IILjava/util/List;)V
    .registers 4

    iput p2, p0, Ladc;->E:I

    packed-switch p2, :pswitch_data_18

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Ladc;->F:Ljava/util/List;

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Ladc;->G:I

    return-void

    :pswitch_f  #0x1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Ladc;->F:Ljava/util/List;

    iput p1, p0, Ladc;->G:I

    return-void

    nop

    :pswitch_data_18
    .packed-switch 0x1
        :pswitch_f  #00000001
    .end packed-switch
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, Ladc;->E:I

    iget-object v1, p0, Ladc;->F:Ljava/util/List;

    packed-switch v0, :pswitch_data_1e

    iget v0, p0, Ladc;->G:I

    invoke-interface {v1, v0, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    iget p1, p0, Ladc;->G:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Ladc;->G:I

    return-void

    :pswitch_13  #0x0
    iget v0, p0, Ladc;->G:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ladc;->G:I

    invoke-interface {v1, v0, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void

    nop

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_13  #00000000
    .end packed-switch
.end method

.method public final hasNext()Z
    .registers 5

    iget v0, p0, Ladc;->E:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v3, p0, Ladc;->F:Ljava/util/List;

    packed-switch v0, :pswitch_data_1e

    iget p0, p0, Ladc;->G:I

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_12

    move v1, v2

    :cond_12
    return v1

    :pswitch_13  #0x0
    iget p0, p0, Ladc;->G:I

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v0

    sub-int/2addr v0, v2

    if-ge p0, v0, :cond_1d

    move v1, v2

    :cond_1d
    return v1

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_13  #00000000
    .end packed-switch
.end method

.method public final hasPrevious()Z
    .registers 2

    iget v0, p0, Ladc;->E:I

    packed-switch v0, :pswitch_data_16

    iget p0, p0, Ladc;->G:I

    if-lez p0, :cond_b

    const/4 p0, 0x1

    goto :goto_c

    :cond_b
    const/4 p0, 0x0

    :goto_c
    return p0

    :pswitch_d  #0x0
    iget p0, p0, Ladc;->G:I

    if-ltz p0, :cond_13

    const/4 p0, 0x1

    goto :goto_14

    :cond_13
    const/4 p0, 0x0

    :goto_14
    return p0

    nop

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_d  #00000000
    .end packed-switch
.end method

.method public final next()Ljava/lang/Object;
    .registers 4

    iget v0, p0, Ladc;->E:I

    iget-object v1, p0, Ladc;->F:Ljava/util/List;

    packed-switch v0, :pswitch_data_1e

    iget v0, p0, Ladc;->G:I

    add-int/lit8 v2, v0, 0x1

    iput v2, p0, Ladc;->G:I

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_12  #0x0
    iget v0, p0, Ladc;->G:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Ladc;->G:I

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_12  #00000000
    .end packed-switch
.end method

.method public final nextIndex()I
    .registers 2

    iget v0, p0, Ladc;->E:I

    packed-switch v0, :pswitch_data_e

    iget p0, p0, Ladc;->G:I

    return p0

    :pswitch_8  #0x0
    iget p0, p0, Ladc;->G:I

    add-int/lit8 p0, p0, 0x1

    return p0

    nop

    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_8  #00000000
    .end packed-switch
.end method

.method public final previous()Ljava/lang/Object;
    .registers 4

    iget v0, p0, Ladc;->E:I

    iget-object v1, p0, Ladc;->F:Ljava/util/List;

    packed-switch v0, :pswitch_data_1e

    iget v0, p0, Ladc;->G:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ladc;->G:I

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_12  #0x0
    iget v0, p0, Ladc;->G:I

    add-int/lit8 v2, v0, -0x1

    iput v2, p0, Ladc;->G:I

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_12  #00000000
    .end packed-switch
.end method

.method public final previousIndex()I
    .registers 2

    iget v0, p0, Ladc;->E:I

    packed-switch v0, :pswitch_data_e

    iget p0, p0, Ladc;->G:I

    add-int/lit8 p0, p0, -0x1

    return p0

    :pswitch_a  #0x0
    iget p0, p0, Ladc;->G:I

    return p0

    nop

    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_a  #00000000
    .end packed-switch
.end method

.method public final remove()V
    .registers 3

    iget v0, p0, Ladc;->E:I

    iget-object v1, p0, Ladc;->F:Ljava/util/List;

    packed-switch v0, :pswitch_data_1e

    iget v0, p0, Ladc;->G:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ladc;->G:I

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    return-void

    :pswitch_11  #0x0
    iget v0, p0, Ladc;->G:I

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    iget v0, p0, Ladc;->G:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Ladc;->G:I

    return-void

    nop

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_11  #00000000
    .end packed-switch
.end method

.method public final set(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, Ladc;->E:I

    iget-object v1, p0, Ladc;->F:Ljava/util/List;

    packed-switch v0, :pswitch_data_14

    iget p0, p0, Ladc;->G:I

    invoke-interface {v1, p0, p1}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void

    :pswitch_d  #0x0
    iget p0, p0, Ladc;->G:I

    invoke-interface {v1, p0, p1}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_d  #00000000
    .end packed-switch
.end method
