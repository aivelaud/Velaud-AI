.class public final Lan1;
.super Lavh;
.source "SourceFile"

# interfaces
.implements Lq98;


# instance fields
.field public final synthetic E:I

.field public F:I

.field public final synthetic G:Lhn1;


# direct methods
.method public synthetic constructor <init>(Lhn1;La75;I)V
    .registers 4

    iput p3, p0, Lan1;->E:I

    iput-object p1, p0, Lan1;->G:Lhn1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lavh;-><init>(ILa75;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;La75;)La75;
    .registers 4

    iget p1, p0, Lan1;->E:I

    iget-object p0, p0, Lan1;->G:Lhn1;

    packed-switch p1, :pswitch_data_2a

    new-instance p1, Lan1;

    const/4 v0, 0x4

    invoke-direct {p1, p0, p2, v0}, Lan1;-><init>(Lhn1;La75;I)V

    return-object p1

    :pswitch_e  #0x3
    new-instance p1, Lan1;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, Lan1;-><init>(Lhn1;La75;I)V

    return-object p1

    :pswitch_15  #0x2
    new-instance p1, Lan1;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lan1;-><init>(Lhn1;La75;I)V

    return-object p1

    :pswitch_1c  #0x1
    new-instance p1, Lan1;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lan1;-><init>(Lhn1;La75;I)V

    return-object p1

    :pswitch_23  #0x0
    new-instance p1, Lan1;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lan1;-><init>(Lhn1;La75;I)V

    return-object p1

    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_23  #00000000
        :pswitch_1c  #00000001
        :pswitch_15  #00000002
        :pswitch_e  #00000003
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    iget v0, p0, Lan1;->E:I

    sget-object v1, Lz2j;->a:Lz2j;

    check-cast p1, Lua5;

    check-cast p2, La75;

    packed-switch v0, :pswitch_data_42

    invoke-virtual {p0, p1, p2}, Lan1;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lan1;

    invoke-virtual {p0, v1}, Lan1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x3
    invoke-virtual {p0, p1, p2}, Lan1;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lan1;

    invoke-virtual {p0, v1}, Lan1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_21  #0x2
    invoke-virtual {p0, p1, p2}, Lan1;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lan1;

    invoke-virtual {p0, v1}, Lan1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2c  #0x1
    invoke-virtual {p0, p1, p2}, Lan1;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lan1;

    invoke-virtual {p0, v1}, Lan1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_37  #0x0
    invoke-virtual {p0, p1, p2}, Lan1;->create(Ljava/lang/Object;La75;)La75;

    move-result-object p0

    check-cast p0, Lan1;

    invoke-virtual {p0, v1}, Lan1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_37  #00000000
        :pswitch_2c  #00000001
        :pswitch_21  #00000002
        :pswitch_16  #00000003
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    iget v0, p0, Lan1;->E:I

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v3, Lz2j;->a:Lz2j;

    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v5, Lva5;->E:Lva5;

    iget-object v6, p0, Lan1;->G:Lhn1;

    const/4 v7, 0x1

    const/4 v8, 0x0

    packed-switch v0, :pswitch_data_13c

    iget v0, p0, Lan1;->F:I

    if-eqz v0, :cond_20

    if-ne v0, v7, :cond_1b

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_50

    :cond_1b
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v3, v8

    goto :goto_50

    :cond_20
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v6, Lhn1;->d:Lo71;

    new-instance v0, Ld71;

    invoke-direct {v0, v2, p1, v8}, Ld71;-><init>(ILo71;La75;)V

    invoke-static {v0}, Lbo9;->v(Lq98;)Lqg2;

    move-result-object v0

    new-instance v1, Lg71;

    invoke-direct {v1, v0, v7}, Lg71;-><init>(Lqg2;I)V

    invoke-static {v1}, Lbo9;->J(Lqz7;)Lqz7;

    move-result-object v0

    iget-object p1, p1, Lo71;->a:Lhh6;

    invoke-interface {p1}, Lhh6;->b()Lna5;

    move-result-object p1

    invoke-static {v0, p1}, Lbo9;->S(Lqz7;Lna5;)Lqz7;

    move-result-object p1

    new-instance v0, Lum1;

    const/4 v1, 0x3

    invoke-direct {v0, v6, v1}, Lum1;-><init>(Lhn1;I)V

    iput v7, p0, Lan1;->F:I

    invoke-interface {p1, v0, p0}, Lqz7;->a(Lrz7;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_50

    move-object v3, v5

    :cond_50
    :goto_50
    return-object v3

    :pswitch_51  #0x3
    iget v0, p0, Lan1;->F:I

    if-eqz v0, :cond_60

    if-ne v0, v7, :cond_5b

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_8a

    :cond_5b
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v3, v8

    goto :goto_8a

    :cond_60
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v6, Lhn1;->d:Lo71;

    new-instance v0, Ld71;

    invoke-direct {v0, v1, p1, v8}, Ld71;-><init>(ILo71;La75;)V

    invoke-static {v0}, Lbo9;->v(Lq98;)Lqg2;

    move-result-object v0

    invoke-static {v0}, Lbo9;->J(Lqz7;)Lqz7;

    move-result-object v0

    iget-object p1, p1, Lo71;->a:Lhh6;

    invoke-interface {p1}, Lhh6;->b()Lna5;

    move-result-object p1

    invoke-static {v0, p1}, Lbo9;->S(Lqz7;Lna5;)Lqz7;

    move-result-object p1

    new-instance v0, Lcn1;

    invoke-direct {v0, v6, v8, v7}, Lcn1;-><init>(Lhn1;La75;I)V

    iput v7, p0, Lan1;->F:I

    invoke-static {p1, v0, p0}, Lbo9;->C(Lqz7;Lq98;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_8a

    move-object v3, v5

    :cond_8a
    :goto_8a
    return-object v3

    :pswitch_8b  #0x2
    iget v0, p0, Lan1;->F:I

    if-eqz v0, :cond_9e

    if-ne v0, v7, :cond_99

    :try_start_91
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V
    :try_end_94
    .catch Ljava/lang/Exception; {:try_start_91 .. :try_end_94} :catch_95

    goto :goto_bd

    :catch_95
    move-exception v0

    move-object p0, v0

    move-object v4, p0

    goto :goto_ad

    :cond_99
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v3, v8

    goto :goto_bd

    :cond_9e
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    :try_start_a1
    iget-object p1, v6, Lhn1;->g:Lnt1;

    iput v7, p0, Lan1;->F:I

    invoke-virtual {p1, p0}, Lnt1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_a9
    .catch Ljava/lang/Exception; {:try_start_a1 .. :try_end_a9} :catch_95

    if-ne p0, v5, :cond_bd

    move-object v3, v5

    goto :goto_bd

    :goto_ad
    instance-of p0, v4, Ljava/util/concurrent/CancellationException;

    if-nez p0, :cond_be

    sget-object p0, Ll0i;->a:Ljava/util/List;

    const/4 v8, 0x0

    const/16 v9, 0x3c

    const-string v5, "Bell Mode: capture keepalive failed"

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Ll0i;->f(Ljava/lang/Throwable;Ljava/lang/String;Lhsg;Ljava/util/Map;Ljava/util/List;I)V

    :cond_bd
    :goto_bd
    return-object v3

    :cond_be
    throw v4

    :pswitch_bf  #0x1
    iget v0, p0, Lan1;->F:I

    if-eqz v0, :cond_ce

    if-ne v0, v7, :cond_c9

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_fc

    :cond_c9
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v3, v8

    goto :goto_fc

    :cond_ce
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v6, Lhn1;->d:Lo71;

    iget-object v0, v6, Lhn1;->a:Lmn1;

    iget v0, v0, Lmn1;->e:I

    new-instance v1, Ln71;

    invoke-direct {v1, v0, p1, v8}, Ln71;-><init>(ILo71;La75;)V

    invoke-static {v1}, Lbo9;->v(Lq98;)Lqg2;

    move-result-object v0

    invoke-static {v0}, Lbo9;->J(Lqz7;)Lqz7;

    move-result-object v0

    iget-object p1, p1, Lo71;->a:Lhh6;

    invoke-interface {p1}, Lhh6;->b()Lna5;

    move-result-object p1

    invoke-static {v0, p1}, Lbo9;->S(Lqz7;Lna5;)Lqz7;

    move-result-object p1

    new-instance v0, Lum1;

    invoke-direct {v0, v6, v2}, Lum1;-><init>(Lhn1;I)V

    iput v7, p0, Lan1;->F:I

    invoke-interface {p1, v0, p0}, Lqz7;->a(Lrz7;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_fc

    move-object v3, v5

    :cond_fc
    :goto_fc
    return-object v3

    :pswitch_fd  #0x0
    iget v0, p0, Lan1;->F:I

    if-eqz v0, :cond_10c

    if-ne v0, v7, :cond_107

    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    goto :goto_13b

    :cond_107
    invoke-static {v4}, Le97;->j(Ljava/lang/String;)V

    move-object v3, v8

    goto :goto_13b

    :cond_10c
    invoke-static {p1}, Lw10;->P(Ljava/lang/Object;)V

    iget-object p1, v6, Lhn1;->d:Lo71;

    new-instance v0, Ld71;

    invoke-direct {v0, v2, p1, v8}, Ld71;-><init>(ILo71;La75;)V

    invoke-static {v0}, Lbo9;->v(Lq98;)Lqg2;

    move-result-object v0

    new-instance v2, Ll71;

    invoke-direct {v2, v0, v1, p1}, Ll71;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {v2}, Lbo9;->J(Lqz7;)Lqz7;

    move-result-object v0

    iget-object p1, p1, Lo71;->a:Lhh6;

    invoke-interface {p1}, Lhh6;->b()Lna5;

    move-result-object p1

    invoke-static {v0, p1}, Lbo9;->S(Lqz7;Lna5;)Lqz7;

    move-result-object p1

    new-instance v0, Lum1;

    invoke-direct {v0, v6, v7}, Lum1;-><init>(Lhn1;I)V

    iput v7, p0, Lan1;->F:I

    invoke-interface {p1, v0, p0}, Lqz7;->a(Lrz7;La75;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_13b

    move-object v3, v5

    :cond_13b
    :goto_13b
    return-object v3

    :pswitch_data_13c
    .packed-switch 0x0
        :pswitch_fd  #00000000
        :pswitch_bf  #00000001
        :pswitch_8b  #00000002
        :pswitch_51  #00000003
    .end packed-switch
.end method
