.class public final La81;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final d:La81;


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lz71;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v0}, Lz71;->a()La81;

    move-result-object v0

    sput-object v0, La81;->d:La81;

    return-void
.end method

.method public constructor <init>(Lz71;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-boolean v0, p1, Lz71;->a:Z

    iput-boolean v0, p0, La81;->a:Z

    iget-boolean v0, p1, Lz71;->b:Z

    iput-boolean v0, p0, La81;->b:Z

    iget-boolean p1, p1, Lz71;->c:Z

    iput-boolean p1, p0, La81;->c:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_3

    goto :goto_22

    :cond_3
    if-eqz p1, :cond_24

    const-class v0, La81;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_e

    goto :goto_24

    :cond_e
    check-cast p1, La81;

    iget-boolean v0, p0, La81;->a:Z

    iget-boolean v1, p1, La81;->a:Z

    if-ne v0, v1, :cond_24

    iget-boolean v0, p0, La81;->b:Z

    iget-boolean v1, p1, La81;->b:Z

    if-ne v0, v1, :cond_24

    iget-boolean p0, p0, La81;->c:Z

    iget-boolean p1, p1, La81;->c:Z

    if-ne p0, p1, :cond_24

    :goto_22
    const/4 p0, 0x1

    return p0

    :cond_24
    :goto_24
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 3

    iget-boolean v0, p0, La81;->a:Z

    shl-int/lit8 v0, v0, 0x2

    iget-boolean v1, p0, La81;->b:Z

    shl-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    iget-boolean p0, p0, La81;->c:Z

    add-int/2addr v0, p0

    return v0
.end method
