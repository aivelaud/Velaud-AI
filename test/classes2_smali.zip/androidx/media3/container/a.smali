.class public final Landroidx/media3/container/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z


# direct methods
.method public constructor <init>(Letc;Ldtc;)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget v0, p2, Ldtc;->a:I

    iget-object p2, p2, Ldtc;->b:Ljava/nio/ByteBuffer;

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eq v0, v1, :cond_12

    if-ne v0, v3, :cond_10

    goto :goto_12

    :cond_10
    move v0, v2

    goto :goto_13

    :cond_12
    :goto_12
    move v0, v4

    :goto_13
    invoke-static {v0}, Lao9;->p(Z)V

    const/4 v0, 0x4

    invoke-virtual {p2}, Ljava/nio/Buffer;->remaining()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    new-array v1, v0, [B

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->asReadOnlyBuffer()Ljava/nio/ByteBuffer;

    move-result-object p2

    invoke-virtual {p2, v1}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    new-instance p2, Lvn2;

    invoke-direct {p2, v1, v0}, Lvn2;-><init>([BI)V

    iget-boolean v0, p1, Letc;->a:Z

    if-nez v0, :cond_af

    invoke-virtual {p2}, Lvn2;->f()Z

    move-result v0

    if-eqz v0, :cond_3a

    iput-boolean v2, p0, Landroidx/media3/container/a;->a:Z

    return-void

    :cond_3a
    const/4 v0, 0x2

    invoke-virtual {p2, v0}, Lvn2;->g(I)I

    move-result v1

    invoke-virtual {p2}, Lvn2;->f()Z

    move-result v5

    iget-boolean v6, p1, Letc;->b:Z

    if-nez v6, :cond_a9

    if-nez v5, :cond_4c

    iput-boolean v4, p0, Landroidx/media3/container/a;->a:Z

    return-void

    :cond_4c
    if-eq v1, v3, :cond_56

    if-nez v1, :cond_51

    goto :goto_56

    :cond_51
    invoke-virtual {p2}, Lvn2;->f()Z

    move-result v5

    goto :goto_57

    :cond_56
    :goto_56
    move v5, v4

    :goto_57
    invoke-virtual {p2}, Lvn2;->n()V

    iget-boolean v6, p1, Letc;->d:Z

    if-eqz v6, :cond_a3

    invoke-virtual {p2}, Lvn2;->f()Z

    move-result v6

    if-eqz v6, :cond_72

    iget-boolean v6, p1, Letc;->e:Z

    if-eqz v6, :cond_6c

    invoke-virtual {p2}, Lvn2;->n()V

    goto :goto_72

    :cond_6c
    new-instance p0, Landroidx/media3/container/ObuParser$NotYetImplementedException;

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    throw p0

    :cond_72
    :goto_72
    iget-boolean v6, p1, Letc;->c:Z

    if-nez v6, :cond_9d

    if-eq v1, v3, :cond_7b

    invoke-virtual {p2}, Lvn2;->n()V

    :cond_7b
    iget p1, p1, Letc;->f:I

    invoke-virtual {p2, p1}, Lvn2;->o(I)V

    if-eq v1, v0, :cond_89

    if-eqz v1, :cond_89

    if-nez v5, :cond_89

    invoke-virtual {p2, v3}, Lvn2;->o(I)V

    :cond_89
    if-eq v1, v3, :cond_95

    if-nez v1, :cond_8e

    goto :goto_95

    :cond_8e
    const/16 p1, 0x8

    invoke-virtual {p2, p1}, Lvn2;->g(I)I

    move-result p1

    goto :goto_97

    :cond_95
    :goto_95
    const/16 p1, 0xff

    :goto_97
    if-eqz p1, :cond_9a

    move v2, v4

    :cond_9a
    iput-boolean v2, p0, Landroidx/media3/container/a;->a:Z

    return-void

    :cond_9d
    new-instance p0, Landroidx/media3/container/ObuParser$NotYetImplementedException;

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    throw p0

    :cond_a3
    new-instance p0, Landroidx/media3/container/ObuParser$NotYetImplementedException;

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    throw p0

    :cond_a9
    new-instance p0, Landroidx/media3/container/ObuParser$NotYetImplementedException;

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    throw p0

    :cond_af
    new-instance p0, Landroidx/media3/container/ObuParser$NotYetImplementedException;

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    throw p0
.end method
