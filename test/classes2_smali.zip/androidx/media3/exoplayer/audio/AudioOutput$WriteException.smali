.class public final Landroidx/media3/exoplayer/audio/AudioOutput$WriteException;
.super Ljava/lang/Exception;
.source "SourceFile"


# instance fields
.field public final E:I

.field public final F:Z


# direct methods
.method public constructor <init>(IZ)V
    .registers 4

    const-string v0, "AudioOutput write failed: "

    invoke-static {p1, v0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    iput-boolean p2, p0, Landroidx/media3/exoplayer/audio/AudioOutput$WriteException;->F:Z

    iput p1, p0, Landroidx/media3/exoplayer/audio/AudioOutput$WriteException;->E:I

    return-void
.end method
