.class public final Landroidx/media3/exoplayer/source/ClippingMediaSource$IllegalClippingException;
.super Ljava/io/IOException;
.source "SourceFile"


# direct methods
.method public constructor <init>(I)V
    .registers 8

    const-wide v1, -0x7fffffffffffffffL  # -4.9E-324

    const-wide v4, -0x7fffffffffffffffL  # -4.9E-324

    move-object v0, p0

    move v3, p1

    .line 67
    invoke-direct/range {v0 .. v5}, Landroidx/media3/exoplayer/source/ClippingMediaSource$IllegalClippingException;-><init>(JIJ)V

    return-void
.end method

.method public constructor <init>(JIJ)V
    .registers 9

    if-eqz p3, :cond_37

    const/4 v0, 0x1

    if-eq p3, v0, :cond_34

    const/4 v1, 0x2

    if-eq p3, v1, :cond_b

    const-string p1, "unknown"

    goto :goto_39

    :cond_b
    const-wide v1, -0x7fffffffffffffffL  # -4.9E-324

    cmp-long p3, p1, v1

    if-eqz p3, :cond_19

    cmp-long p3, p4, v1

    if-eqz p3, :cond_19

    goto :goto_1a

    :cond_19
    const/4 v0, 0x0

    :goto_1a
    invoke-static {v0}, Lao9;->x(Z)V

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "start exceeds end. Start time: "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p1, ", End time: "

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_39

    :cond_34
    const-string p1, "not seekable to start"

    goto :goto_39

    :cond_37
    const-string p1, "invalid period count"

    :goto_39
    const-string p2, "Illegal clipping: "

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    return-void
.end method
