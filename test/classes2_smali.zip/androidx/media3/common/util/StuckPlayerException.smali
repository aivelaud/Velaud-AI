.class public final Landroidx/media3/common/util/StuckPlayerException;
.super Ljava/lang/IllegalStateException;
.source "SourceFile"


# instance fields
.field public final E:I

.field public final F:I


# direct methods
.method public constructor <init>(II)V
    .registers 5

    const-string v0, " ms"

    if-eqz p1, :cond_31

    const/4 v1, 0x1

    if-eq p1, v1, :cond_2a

    const/4 v1, 0x2

    if-eq p1, v1, :cond_23

    const/4 v1, 0x3

    if-eq p1, v1, :cond_1c

    const/4 v1, 0x4

    if-ne p1, v1, :cond_17

    const-string v1, "Player stuck suppressed for "

    invoke-static {p2, v1, v0}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_37

    :cond_17
    invoke-static {}, Lio/sentry/i2;->b()V

    const/4 p0, 0x0

    throw p0

    :cond_1c
    const-string v1, "Player stuck playing without ending for "

    invoke-static {p2, v1, v0}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_37

    :cond_23
    const-string v1, "Player stuck playing with no progress for "

    invoke-static {p2, v1, v0}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_37

    :cond_2a
    const-string v1, "Player stuck buffering with no progress for "

    invoke-static {p2, v1, v0}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_37

    :cond_31
    const-string v1, "Player stuck buffering and not loading for "

    invoke-static {p2, v1, v0}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_37
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    iput p1, p0, Landroidx/media3/common/util/StuckPlayerException;->E:I

    iput p2, p0, Landroidx/media3/common/util/StuckPlayerException;->F:I

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_3

    goto :goto_1c

    :cond_3
    if-eqz p1, :cond_1e

    const-class v0, Landroidx/media3/common/util/StuckPlayerException;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_e

    goto :goto_1e

    :cond_e
    check-cast p1, Landroidx/media3/common/util/StuckPlayerException;

    iget v0, p0, Landroidx/media3/common/util/StuckPlayerException;->E:I

    iget v1, p1, Landroidx/media3/common/util/StuckPlayerException;->E:I

    if-ne v0, v1, :cond_1e

    iget p0, p0, Landroidx/media3/common/util/StuckPlayerException;->F:I

    iget p1, p1, Landroidx/media3/common/util/StuckPlayerException;->F:I

    if-ne p0, p1, :cond_1e

    :goto_1c
    const/4 p0, 0x1

    return p0

    :cond_1e
    :goto_1e
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 3

    const/16 v0, 0x20f

    iget v1, p0, Landroidx/media3/common/util/StuckPlayerException;->E:I

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Landroidx/media3/common/util/StuckPlayerException;->F:I

    add-int/2addr v0, p0

    return v0
.end method
