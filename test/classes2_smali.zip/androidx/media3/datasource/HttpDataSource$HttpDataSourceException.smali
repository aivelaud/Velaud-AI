.class public Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;
.super Landroidx/media3/datasource/DataSourceException;
.source "SourceFile"


# instance fields
.field public final F:I


# direct methods
.method public constructor <init>(I)V
    .registers 3

    const/16 v0, 0x7d0

    if-ne p1, v0, :cond_6

    const/16 p1, 0x7d1

    .line 17
    :cond_6
    invoke-direct {p0, p1}, Landroidx/media3/datasource/DataSourceException;-><init>(I)V

    const/4 p1, 0x1

    .line 18
    iput p1, p0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->F:I

    return-void
.end method

.method public constructor <init>(Ljava/io/IOException;II)V
    .registers 5

    const/16 v0, 0x7d0

    if-ne p2, v0, :cond_9

    const/4 v0, 0x1

    if-ne p3, v0, :cond_9

    const/16 p2, 0x7d1

    :cond_9
    invoke-direct {p0, p2, p1}, Landroidx/media3/datasource/DataSourceException;-><init>(ILjava/lang/Exception;)V

    iput p3, p0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->F:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 4

    const/16 v0, 0x7d0

    if-ne p2, v0, :cond_6

    const/16 p2, 0x7d1

    .line 15
    :cond_6
    invoke-direct {p0, p1, p2}, Landroidx/media3/datasource/DataSourceException;-><init>(Ljava/lang/String;I)V

    const/4 p1, 0x1

    .line 16
    iput p1, p0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->F:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/io/IOException;I)V
    .registers 5

    const/16 v0, 0x7d0

    if-ne p3, v0, :cond_6

    const/16 p3, 0x7d1

    .line 19
    :cond_6
    invoke-direct {p0, p1, p2, p3}, Landroidx/media3/datasource/DataSourceException;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    const/4 p1, 0x1

    .line 20
    iput p1, p0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->F:I

    return-void
.end method

.method public static a(Ljava/io/IOException;I)Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    instance-of v1, p0, Ljava/net/SocketTimeoutException;

    const/16 v2, 0x7d7

    if-eqz v1, :cond_d

    const/16 v0, 0x7d2

    goto :goto_26

    :cond_d
    instance-of v1, p0, Ljava/io/InterruptedIOException;

    if-eqz v1, :cond_14

    const/16 v0, 0x3ec

    goto :goto_26

    :cond_14
    if-eqz v0, :cond_24

    invoke-static {v0}, Lqll;->j(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "cleartext.*not permitted.*"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_24

    move v0, v2

    goto :goto_26

    :cond_24
    const/16 v0, 0x7d1

    :goto_26
    if-ne v0, v2, :cond_30

    new-instance p1, Landroidx/media3/datasource/HttpDataSource$CleartextNotPermittedException;

    const-string v0, "Cleartext HTTP traffic not permitted. See https://developer.android.com/guide/topics/media/issues/cleartext-not-permitted"

    invoke-direct {p1, v0, p0, v2}, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;-><init>(Ljava/lang/String;Ljava/io/IOException;I)V

    return-object p1

    :cond_30
    new-instance v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    invoke-direct {v1, p0, v0, p1}, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;-><init>(Ljava/io/IOException;II)V

    return-object v1
.end method
