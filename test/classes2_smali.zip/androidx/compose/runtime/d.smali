.class public final Landroidx/compose/runtime/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lvo0;


# instance fields
.field public final E:Lkcc;

.field public final F:Lddc;

.field public final G:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lkcc;

    invoke-direct {v0}, Lkcc;-><init>()V

    iput-object v0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    new-instance v0, Lddc;

    invoke-direct {v0}, Lddc;-><init>()V

    iput-object v0, p0, Landroidx/compose/runtime/d;->F:Lddc;

    iput-object p1, p0, Landroidx/compose/runtime/d;->G:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(ILjava/lang/Object;)V
    .registers 5

    const/4 v0, 0x5

    iget-object v1, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    invoke-virtual {v1, v0}, Lkcc;->a(I)V

    invoke-virtual {v1, p1}, Lkcc;->a(I)V

    iget-object p0, p0, Landroidx/compose/runtime/d;->F:Lddc;

    invoke-virtual {p0, p2}, Lddc;->a(Ljava/lang/Object;)V

    return-void
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 4

    iget-object v0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lkcc;->a(I)V

    iget-object p0, p0, Landroidx/compose/runtime/d;->F:Lddc;

    invoke-virtual {p0, p1}, Lddc;->a(Ljava/lang/Object;)V

    return-void
.end method

.method public final c()V
    .registers 2

    iget-object p0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Lkcc;->a(I)V

    return-void
.end method

.method public final d(III)V
    .registers 5

    const/4 v0, 0x3

    iget-object p0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    invoke-virtual {p0, v0}, Lkcc;->a(I)V

    invoke-virtual {p0, p1}, Lkcc;->a(I)V

    invoke-virtual {p0, p2}, Lkcc;->a(I)V

    invoke-virtual {p0, p3}, Lkcc;->a(I)V

    return-void
.end method

.method public final e(II)V
    .registers 4

    const/4 v0, 0x2

    iget-object p0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    invoke-virtual {p0, v0}, Lkcc;->a(I)V

    invoke-virtual {p0, p1}, Lkcc;->a(I)V

    invoke-virtual {p0, p2}, Lkcc;->a(I)V

    return-void
.end method

.method public final f()V
    .registers 2

    iget-object p0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    const/16 v0, 0x9

    invoke-virtual {p0, v0}, Lkcc;->a(I)V

    return-void
.end method

.method public final g()V
    .registers 2

    iget-object p0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lkcc;->a(I)V

    return-void
.end method

.method public final h(ILjava/lang/Object;)V
    .registers 5

    const/4 v0, 0x6

    iget-object v1, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    invoke-virtual {v1, v0}, Lkcc;->a(I)V

    invoke-virtual {v1, p1}, Lkcc;->a(I)V

    iget-object p0, p0, Landroidx/compose/runtime/d;->F:Lddc;

    invoke-virtual {p0, p2}, Lddc;->a(Ljava/lang/Object;)V

    return-void
.end method

.method public final j()Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Landroidx/compose/runtime/d;->G:Ljava/lang/Object;

    return-object p0
.end method

.method public final k(Lq98;Ljava/lang/Object;)V
    .registers 5

    iget-object v0, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    const/4 v1, 0x7

    invoke-virtual {v0, v1}, Lkcc;->a(I)V

    iget-object p0, p0, Landroidx/compose/runtime/d;->F:Lddc;

    invoke-virtual {p0, p1}, Lddc;->a(Ljava/lang/Object;)V

    invoke-virtual {p0, p2}, Lddc;->a(Ljava/lang/Object;)V

    return-void
.end method

.method public final l(La0;Lz70;)V
    .registers 13

    iget-object v3, p0, Landroidx/compose/runtime/d;->E:Lkcc;

    iget v0, v3, Lkcc;->b:I

    new-instance v2, Lddc;

    invoke-direct {v2}, Lddc;-><init>()V

    const/4 v1, 0x0

    move v4, v1

    move v5, v4

    move v6, v5

    :goto_d
    iget-object v1, p0, Landroidx/compose/runtime/d;->F:Lddc;

    if-ge v4, v0, :cond_c9

    add-int/lit8 v7, v4, 0x1

    :try_start_13
    invoke-virtual {v3, v4}, Lkcc;->c(I)I

    move-result v8

    packed-switch v8, :pswitch_data_e8

    goto :goto_5c

    :pswitch_1b  #0x8
    iget-object v4, p1, La0;->G:Ljava/lang/Object;

    instance-of v8, v4, Lhu4;

    if-eqz v8, :cond_3d

    move-object v8, v4

    check-cast v8, Lhu4;

    iget-object v9, p2, Lz70;->J:Ljava/lang/Object;

    check-cast v9, Ljec;

    invoke-virtual {v9, v8}, Ljec;->k(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_3d

    invoke-interface {v8}, Lhu4;->c()V

    goto :goto_3d

    :goto_32
    move-object v5, p0

    move v4, v7

    goto/16 :goto_dc

    :catchall_36
    move-exception v0

    move-object p0, v0

    goto/16 :goto_e4

    :catch_3a
    move-exception v0

    move-object p0, v0

    goto :goto_32

    :cond_3d
    :goto_3d
    invoke-virtual {v2, v4}, Lddc;->a(Ljava/lang/Object;)V

    invoke-interface {p1}, Lvo0;->c()V

    goto :goto_5c

    :pswitch_44  #0x7
    add-int/lit8 v4, v5, 0x1

    invoke-virtual {v1, v5}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v9, 0x2

    invoke-static {v9, v8}, Lsyi;->p(ILjava/lang/Object;)Ljava/lang/Object;

    check-cast v8, Lq98;

    add-int/lit8 v5, v5, 0x2

    invoke-virtual {v1, v4}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v4

    invoke-interface {p1, v8, v4}, Lvo0;->k(Lq98;Ljava/lang/Object;)V
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_5c} :catch_3a
    .catchall {:try_start_13 .. :try_end_5c} :catchall_36

    :goto_5c
    move v4, v7

    goto :goto_d

    :pswitch_5e  #0x6
    add-int/lit8 v4, v4, 0x2

    :try_start_60
    invoke-virtual {v3, v7}, Lkcc;->c(I)I

    move-result v7

    add-int/lit8 v8, v5, 0x1

    invoke-virtual {v1, v5}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {p1, v7, v5}, Lvo0;->h(ILjava/lang/Object;)V

    :goto_6d
    move v5, v8

    goto :goto_d

    :catch_6f
    move-exception v0

    move-object p0, v0

    move-object v5, p0

    goto/16 :goto_dc

    :pswitch_74  #0x5
    add-int/lit8 v4, v4, 0x2

    invoke-virtual {v3, v7}, Lkcc;->c(I)I

    move-result v7

    add-int/lit8 v8, v5, 0x1

    invoke-virtual {v1, v5}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {p1, v7, v5}, Lvo0;->a(ILjava/lang/Object;)V
    :try_end_83
    .catch Ljava/lang/Exception; {:try_start_60 .. :try_end_83} :catch_6f
    .catchall {:try_start_60 .. :try_end_83} :catchall_36

    goto :goto_6d

    :pswitch_84  #0x4
    :try_start_84
    invoke-virtual {p1}, La0;->f()V
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_84 .. :try_end_87} :catch_3a
    .catchall {:try_start_84 .. :try_end_87} :catchall_36

    goto :goto_5c

    :pswitch_88  #0x3
    add-int/lit8 v8, v4, 0x2

    :try_start_8a
    invoke-virtual {v3, v7}, Lkcc;->c(I)I

    move-result v7
    :try_end_8e
    .catch Ljava/lang/Exception; {:try_start_8a .. :try_end_8e} :catch_a4
    .catchall {:try_start_8a .. :try_end_8e} :catchall_36

    add-int/lit8 v9, v4, 0x3

    :try_start_90
    invoke-virtual {v3, v8}, Lkcc;->c(I)I

    move-result v8
    :try_end_94
    .catch Ljava/lang/Exception; {:try_start_90 .. :try_end_94} :catch_9f
    .catchall {:try_start_90 .. :try_end_94} :catchall_36

    add-int/lit8 v4, v4, 0x4

    :try_start_96
    invoke-virtual {v3, v9}, Lkcc;->c(I)I

    move-result v9

    invoke-interface {p1, v7, v8, v9}, Lvo0;->d(III)V
    :try_end_9d
    .catch Ljava/lang/Exception; {:try_start_96 .. :try_end_9d} :catch_6f
    .catchall {:try_start_96 .. :try_end_9d} :catchall_36

    goto/16 :goto_d

    :catch_9f
    move-exception v0

    move-object p0, v0

    move-object v5, p0

    move v4, v9

    goto :goto_dc

    :catch_a4
    move-exception v0

    move-object p0, v0

    move-object v5, p0

    move v4, v8

    goto :goto_dc

    :pswitch_a9  #0x2
    add-int/lit8 v8, v4, 0x2

    :try_start_ab
    invoke-virtual {v3, v7}, Lkcc;->c(I)I

    move-result v7
    :try_end_af
    .catch Ljava/lang/Exception; {:try_start_ab .. :try_end_af} :catch_a4
    .catchall {:try_start_ab .. :try_end_af} :catchall_36

    add-int/lit8 v4, v4, 0x3

    :try_start_b1
    invoke-virtual {v3, v8}, Lkcc;->c(I)I

    move-result v8

    invoke-interface {p1, v7, v8}, Lvo0;->e(II)V
    :try_end_b8
    .catch Ljava/lang/Exception; {:try_start_b1 .. :try_end_b8} :catch_6f
    .catchall {:try_start_b1 .. :try_end_b8} :catchall_36

    goto/16 :goto_d

    :pswitch_ba  #0x1
    add-int/lit8 v4, v5, 0x1

    :try_start_bc
    invoke-virtual {v1, v5}, Lddc;->f(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {p1, v5}, La0;->b(Ljava/lang/Object;)V

    move v5, v4

    goto :goto_5c

    :pswitch_c5  #0x0
    invoke-virtual {p1}, La0;->g()V
    :try_end_c8
    .catch Ljava/lang/Exception; {:try_start_bc .. :try_end_c8} :catch_3a
    .catchall {:try_start_bc .. :try_end_c8} :catchall_36

    goto :goto_5c

    :cond_c9
    :try_start_c9
    iget p0, v1, Lddc;->b:I

    if-ne v5, p0, :cond_ce

    goto :goto_d3

    :cond_ce
    const-string p0, "Applier operation size mismatch"

    invoke-static {p0}, Lev4;->a(Ljava/lang/String;)V

    :goto_d3
    invoke-virtual {v1}, Lddc;->d()V

    iput v6, v3, Lkcc;->b:I
    :try_end_d8
    .catch Ljava/lang/Exception; {:try_start_c9 .. :try_end_d8} :catch_6f
    .catchall {:try_start_c9 .. :try_end_d8} :catchall_36

    invoke-interface {p1}, Lvo0;->i()V

    return-void

    :goto_dc
    :try_start_dc
    new-instance v0, Landroidx/compose/runtime/ComposePausableCompositionException;

    add-int/lit8 v4, v4, -0x1

    invoke-direct/range {v0 .. v5}, Landroidx/compose/runtime/ComposePausableCompositionException;-><init>(Lddc;Lddc;Lkcc;ILjava/lang/Exception;)V

    throw v0
    :try_end_e4
    .catchall {:try_start_dc .. :try_end_e4} :catchall_36

    :goto_e4
    invoke-interface {p1}, Lvo0;->i()V

    throw p0

    :pswitch_data_e8
    .packed-switch 0x0
        :pswitch_c5  #00000000
        :pswitch_ba  #00000001
        :pswitch_a9  #00000002
        :pswitch_88  #00000003
        :pswitch_84  #00000004
        :pswitch_74  #00000005
        :pswitch_5e  #00000006
        :pswitch_44  #00000007
        :pswitch_1b  #00000008
    .end packed-switch
.end method
