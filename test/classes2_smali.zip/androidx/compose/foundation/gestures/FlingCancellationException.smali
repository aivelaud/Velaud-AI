.class public final Landroidx/compose/foundation/gestures/FlingCancellationException;
.super Landroidx/compose/foundation/internal/PlatformOptimizedCancellationException;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\u00020\u0001¨\u0006\u0002"
    }
    d2 = {
        "Landroidx/compose/foundation/gestures/FlingCancellationException;",
        "Landroidx/compose/foundation/internal/PlatformOptimizedCancellationException;",
        "foundation"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation
