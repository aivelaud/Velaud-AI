.class public final Landroidx/compose/foundation/MutationInterruptedException;
.super Landroidx/compose/foundation/internal/PlatformOptimizedCancellationException;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\u00020\u0001¨\u0006\u0002"
    }
    d2 = {
        "Landroidx/compose/foundation/MutationInterruptedException;",
        "Landroidx/compose/foundation/internal/PlatformOptimizedCancellationException;",
        "foundation"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 2

    const-string v0, "Mutation interrupted"

    invoke-direct {p0, v0}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    return-void
.end method
