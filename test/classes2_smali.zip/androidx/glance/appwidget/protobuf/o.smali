.class public abstract Landroidx/glance/appwidget/protobuf/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lral;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget-boolean v0, Li5j;->e:Z

    if-eqz v0, :cond_15

    sget-boolean v0, Li5j;->d:Z

    if-eqz v0, :cond_15

    invoke-static {}, Lyz;->a()Z

    move-result v0

    if-nez v0, :cond_15

    new-instance v0, Landroidx/glance/appwidget/protobuf/n;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroidx/glance/appwidget/protobuf/n;-><init>(I)V

    goto :goto_1b

    :cond_15
    new-instance v0, Landroidx/glance/appwidget/protobuf/n;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/glance/appwidget/protobuf/n;-><init>(I)V

    :goto_1b
    sput-object v0, Landroidx/glance/appwidget/protobuf/o;->a:Lral;

    return-void
.end method

.method public static a(Ljava/lang/String;)I
    .registers 10

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_6
    if-ge v2, v0, :cond_13

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x80

    if-ge v3, v4, :cond_13

    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_13
    move v3, v0

    :goto_14
    if-ge v2, v0, :cond_5a

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/16 v5, 0x800

    if-ge v4, v5, :cond_26

    rsub-int/lit8 v4, v4, 0x7f

    ushr-int/lit8 v4, v4, 0x1f

    add-int/2addr v3, v4

    add-int/lit8 v2, v2, 0x1

    goto :goto_14

    :cond_26
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v4

    move v6, v1

    :goto_2b
    if-ge v2, v4, :cond_59

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-ge v7, v5, :cond_39

    rsub-int/lit8 v7, v7, 0x7f

    ushr-int/lit8 v7, v7, 0x1f

    add-int/2addr v6, v7

    goto :goto_56

    :cond_39
    add-int/lit8 v6, v6, 0x2

    const v8, 0xd800

    if-gt v8, v7, :cond_56

    const v8, 0xdfff

    if-gt v7, v8, :cond_56

    invoke-static {p0, v2}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v7

    const/high16 v8, 0x10000

    if-lt v7, v8, :cond_50

    add-int/lit8 v2, v2, 0x1

    goto :goto_56

    :cond_50
    new-instance p0, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;

    invoke-direct {p0, v2, v4}, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw p0

    :cond_56
    :goto_56
    add-int/lit8 v2, v2, 0x1

    goto :goto_2b

    :cond_59
    add-int/2addr v3, v6

    :cond_5a
    if-lt v3, v0, :cond_5d

    return v3

    :cond_5d
    int-to-long v2, v3

    const-wide v4, 0x100000000L

    add-long/2addr v2, v4

    invoke-static {v2, v3}, Lgdg;->g(J)V

    return v1
.end method
