.class public abstract Landroidx/glance/appwidget/protobuf/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/Class;

.field public static final b:Landroidx/glance/appwidget/protobuf/k;

.field public static final c:Landroidx/glance/appwidget/protobuf/m;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget-object v0, Llfe;->c:Llfe;

    const/4 v0, 0x0

    :try_start_3
    const-string v1, "androidx.glance.appwidget.protobuf.GeneratedMessage"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_a

    goto :goto_b

    :catchall_a
    move-object v1, v0

    :goto_b
    sput-object v1, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    :try_start_d
    sget-object v1, Llfe;->c:Llfe;
    :try_end_f
    .catchall {:try_start_d .. :try_end_f} :catchall_25

    :try_start_f
    const-string v1, "androidx.glance.appwidget.protobuf.UnknownFieldSetSchema"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1
    :try_end_15
    .catchall {:try_start_f .. :try_end_15} :catchall_16

    goto :goto_17

    :catchall_16
    move-object v1, v0

    :goto_17
    if-nez v1, :cond_1a

    goto :goto_25

    :cond_1a
    :try_start_1a
    invoke-virtual {v1, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/glance/appwidget/protobuf/k;
    :try_end_24
    .catchall {:try_start_1a .. :try_end_24} :catchall_25

    move-object v0, v1

    :catchall_25
    :goto_25
    sput-object v0, Landroidx/glance/appwidget/protobuf/j;->b:Landroidx/glance/appwidget/protobuf/k;

    new-instance v0, Landroidx/glance/appwidget/protobuf/m;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/glance/appwidget/protobuf/j;->c:Landroidx/glance/appwidget/protobuf/m;

    return-void
.end method

.method public static a(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Ldj9;

    if-eqz v2, :cond_13

    check-cast p0, Ldj9;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_29

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_29
    return v2
.end method

.method public static b(ILjava/util/List;)I
    .registers 2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-nez p1, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result p0

    add-int/lit8 p0, p0, 0x4

    mul-int/2addr p0, p1

    return p0
.end method

.method public static c(ILjava/util/List;)I
    .registers 2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-nez p1, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result p0

    add-int/lit8 p0, p0, 0x8

    mul-int/2addr p0, p1

    return p0
.end method

.method public static d(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Ldj9;

    if-eqz v2, :cond_13

    check-cast p0, Ldj9;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_29

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_29
    return v2
.end method

.method public static e(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lixa;

    if-eqz v2, :cond_13

    check-cast p0, Lixa;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_28

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_28
    return v2
.end method

.method public static f(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    goto :goto_11

    :cond_8
    instance-of v2, p0, Ldj9;

    if-eqz v2, :cond_14

    invoke-static {p0}, Lb40;->x(Ljava/lang/Object;)V

    if-gtz v0, :cond_12

    :goto_11
    return v1

    :cond_12
    const/4 p0, 0x0

    throw p0

    :cond_14
    move v2, v1

    :goto_15
    if-ge v1, v0, :cond_2e

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    shl-int/lit8 v4, v3, 0x1

    shr-int/lit8 v3, v3, 0x1f

    xor-int/2addr v3, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :cond_2e
    return v2
.end method

.method public static g(Ljava/util/List;)I
    .registers 9

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    goto :goto_11

    :cond_8
    instance-of v2, p0, Lixa;

    if-eqz v2, :cond_14

    invoke-static {p0}, Lb40;->x(Ljava/lang/Object;)V

    if-gtz v0, :cond_12

    :goto_11
    return v1

    :cond_12
    const/4 p0, 0x0

    throw p0

    :cond_14
    move v2, v1

    :goto_15
    if-ge v1, v0, :cond_30

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v5, 0x1

    shl-long v5, v3, v5

    const/16 v7, 0x3f

    shr-long/2addr v3, v7

    xor-long/2addr v3, v5

    invoke-static {v3, v4}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :cond_30
    return v2
.end method

.method public static h(Ljava/util/List;)I
    .registers 5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Ldj9;

    if-eqz v2, :cond_13

    check-cast p0, Ldj9;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_28

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_28
    return v2
.end method

.method public static i(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lixa;

    if-eqz v2, :cond_13

    check-cast p0, Lixa;

    if-gtz v0, :cond_11

    return v1

    :cond_11
    const/4 p0, 0x0

    throw p0

    :cond_13
    move v2, v1

    :goto_14
    if-ge v1, v0, :cond_28

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_14

    :cond_28
    return v2
.end method

.method public static j(Ljava/lang/Object;ILcl9;Ljava/lang/Object;Landroidx/glance/appwidget/protobuf/k;)Ljava/lang/Object;
    .registers 5

    return-object p3
.end method

.method public static k(Landroidx/glance/appwidget/protobuf/k;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 9

    check-cast p0, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/glance/appwidget/protobuf/f;

    iget-object p0, p1, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    check-cast p2, Landroidx/glance/appwidget/protobuf/f;

    iget-object p2, p2, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    sget-object v0, Landroidx/glance/appwidget/protobuf/l;->f:Landroidx/glance/appwidget/protobuf/l;

    invoke-virtual {v0, p2}, Landroidx/glance/appwidget/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16

    goto :goto_75

    :cond_16
    invoke-virtual {v0, p0}, Landroidx/glance/appwidget/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_47

    iget v0, p0, Landroidx/glance/appwidget/protobuf/l;->a:I

    iget v1, p2, Landroidx/glance/appwidget/protobuf/l;->a:I

    add-int/2addr v0, v1

    iget-object v1, p0, Landroidx/glance/appwidget/protobuf/l;->b:[I

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v1

    iget-object v3, p2, Landroidx/glance/appwidget/protobuf/l;->b:[I

    iget v4, p0, Landroidx/glance/appwidget/protobuf/l;->a:I

    iget v5, p2, Landroidx/glance/appwidget/protobuf/l;->a:I

    invoke-static {v3, v2, v1, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/l;->c:[Ljava/lang/Object;

    invoke-static {v3, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    iget-object v4, p2, Landroidx/glance/appwidget/protobuf/l;->c:[Ljava/lang/Object;

    iget p0, p0, Landroidx/glance/appwidget/protobuf/l;->a:I

    iget p2, p2, Landroidx/glance/appwidget/protobuf/l;->a:I

    invoke-static {v4, v2, v3, p0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance p0, Landroidx/glance/appwidget/protobuf/l;

    const/4 p2, 0x1

    invoke-direct {p0, v0, v1, v3, p2}, Landroidx/glance/appwidget/protobuf/l;-><init>(I[I[Ljava/lang/Object;Z)V

    goto :goto_75

    :cond_47
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2, v0}, Landroidx/glance/appwidget/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_51

    goto :goto_75

    :cond_51
    iget-boolean v0, p0, Landroidx/glance/appwidget/protobuf/l;->e:Z

    if-eqz v0, :cond_78

    iget v0, p0, Landroidx/glance/appwidget/protobuf/l;->a:I

    iget v1, p2, Landroidx/glance/appwidget/protobuf/l;->a:I

    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/l;->a(I)V

    iget-object v1, p2, Landroidx/glance/appwidget/protobuf/l;->b:[I

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/l;->b:[I

    iget v4, p0, Landroidx/glance/appwidget/protobuf/l;->a:I

    iget v5, p2, Landroidx/glance/appwidget/protobuf/l;->a:I

    invoke-static {v1, v2, v3, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v1, p2, Landroidx/glance/appwidget/protobuf/l;->c:[Ljava/lang/Object;

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/l;->c:[Ljava/lang/Object;

    iget v4, p0, Landroidx/glance/appwidget/protobuf/l;->a:I

    iget p2, p2, Landroidx/glance/appwidget/protobuf/l;->a:I

    invoke-static {v1, v2, v3, v4, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput v0, p0, Landroidx/glance/appwidget/protobuf/l;->a:I

    :goto_75
    iput-object p0, p1, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    return-void

    :cond_78
    invoke-static {}, Lty9;->u()V

    return-void
.end method

.method public static l(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 2

    if-eq p0, p1, :cond_d

    if-eqz p0, :cond_b

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_b

    goto :goto_d

    :cond_b
    const/4 p0, 0x0

    return p0

    :cond_d
    :goto_d
    const/4 p0, 0x1

    return p0
.end method

.method public static m(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_72

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_72

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Ljz1;

    if-nez v0, :cond_6f

    const/4 v0, 0x0

    if-eqz p3, :cond_59

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_2f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x1

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_2f
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_32
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_72

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    int-to-byte p0, p0

    iget p3, p2, Landroidx/glance/appwidget/protobuf/e;->d:I

    iget v1, p2, Landroidx/glance/appwidget/protobuf/e;->c:I

    if-ne p3, v1, :cond_4c

    invoke-virtual {p2}, Landroidx/glance/appwidget/protobuf/e;->k()V

    :cond_4c
    iget-object p3, p2, Landroidx/glance/appwidget/protobuf/e;->b:[B

    iget v1, p2, Landroidx/glance/appwidget/protobuf/e;->d:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p2, Landroidx/glance/appwidget/protobuf/e;->d:I

    aput-byte p0, p3, v1

    add-int/lit8 v0, v0, 0x1

    goto :goto_32

    :cond_59
    :goto_59
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_72

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Boolean;

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->n(IZ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_59

    :cond_6f
    invoke-static {}, Lty9;->a()V

    :cond_72
    return-void
.end method

.method public static n(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_6c

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6c

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Lcj6;

    if-nez v0, :cond_69

    const/4 v0, 0x0

    if-eqz p3, :cond_4c

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_2f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Double;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_2f
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_32
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Double;

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->s(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_32

    :cond_4c
    :goto_4c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Double;

    invoke-virtual {p3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4c

    :cond_69
    invoke-static {}, Lty9;->a()V

    :cond_6c
    return-void
.end method

.method public static o(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_64

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_64

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Ldj9;

    if-nez v0, :cond_61

    const/4 v0, 0x0

    if-eqz p3, :cond_4b

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_32

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_32
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_35
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_64

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/glance/appwidget/protobuf/e;->u(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_35

    :cond_4b
    :goto_4b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_64

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->t(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4b

    :cond_61
    invoke-static {}, Lty9;->a()V

    :cond_64
    return-void
.end method

.method public static p(ILjava/util/List;Lfgk;Z)V
    .registers 6

    if-eqz p1, :cond_61

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_61

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Ldj9;

    if-nez v0, :cond_5e

    const/4 v0, 0x0

    if-eqz p3, :cond_48

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_2f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_2f
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_32
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/glance/appwidget/protobuf/e;->q(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_32

    :cond_48
    :goto_48
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_48

    :cond_5e
    invoke-static {}, Lty9;->a()V

    :cond_61
    return-void
.end method

.method public static q(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_61

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_61

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Lixa;

    if-nez v0, :cond_5e

    const/4 v0, 0x0

    if-eqz p3, :cond_48

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_2f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_2f
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_32
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->s(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_32

    :cond_48
    :goto_48
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_48

    :cond_5e
    invoke-static {}, Lty9;->a()V

    :cond_61
    return-void
.end method

.method public static r(ILjava/util/List;Lfgk;Z)V
    .registers 6

    if-eqz p1, :cond_6c

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6c

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Lsy7;

    if-nez v0, :cond_69

    const/4 v0, 0x0

    if-eqz p3, :cond_4c

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_2f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Float;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_2f
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_32
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/glance/appwidget/protobuf/e;->q(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_32

    :cond_4c
    :goto_4c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_6c

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Float;

    invoke-virtual {p3}, Ljava/lang/Float;->floatValue()F

    move-result p3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4c

    :cond_69
    invoke-static {}, Lty9;->a()V

    :cond_6c
    return-void
.end method

.method public static s(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_64

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_64

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Ldj9;

    if-nez v0, :cond_61

    const/4 v0, 0x0

    if-eqz p3, :cond_4b

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_32

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_32
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_35
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_64

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/glance/appwidget/protobuf/e;->u(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_35

    :cond_4b
    :goto_4b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_64

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->t(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4b

    :cond_61
    invoke-static {}, Lty9;->a()V

    :cond_64
    return-void
.end method

.method public static t(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_63

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_63

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Lixa;

    if-nez v0, :cond_60

    const/4 v0, 0x0

    if-eqz p3, :cond_4a

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_31

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_31
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_34
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_63

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->C(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_34

    :cond_4a
    :goto_4a
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_63

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4a

    :cond_60
    invoke-static {}, Lty9;->a()V

    :cond_63
    return-void
.end method

.method public static u(ILjava/util/List;Lfgk;Z)V
    .registers 6

    if-eqz p1, :cond_61

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_61

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Ldj9;

    if-nez v0, :cond_5e

    const/4 v0, 0x0

    if-eqz p3, :cond_48

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_2f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_2f
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_32
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/glance/appwidget/protobuf/e;->q(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_32

    :cond_48
    :goto_48
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_48

    :cond_5e
    invoke-static {}, Lty9;->a()V

    :cond_61
    return-void
.end method

.method public static v(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_61

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_61

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Lixa;

    if-nez v0, :cond_5e

    const/4 v0, 0x0

    if-eqz p3, :cond_48

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_2f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_2f
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_32
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->s(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_32

    :cond_48
    :goto_48
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_61

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_48

    :cond_5e
    invoke-static {}, Lty9;->a()V

    :cond_61
    return-void
.end method

.method public static w(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_72

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_72

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Ldj9;

    if-nez v0, :cond_6f

    const/4 v0, 0x0

    if-eqz p3, :cond_54

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_36

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    shl-int/lit8 v2, v1, 0x1

    shr-int/lit8 v1, v1, 0x1f

    xor-int/2addr v1, v2

    invoke-static {v1}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_36
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_39
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_72

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    shl-int/lit8 p3, p0, 0x1

    shr-int/lit8 p0, p0, 0x1f

    xor-int/2addr p0, p3

    invoke-virtual {p2, p0}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_39

    :cond_54
    :goto_54
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_72

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    shl-int/lit8 v1, p3, 0x1

    shr-int/lit8 p3, p3, 0x1f

    xor-int/2addr p3, v1

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->z(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_54

    :cond_6f
    invoke-static {}, Lty9;->a()V

    :cond_72
    return-void
.end method

.method public static x(ILjava/util/List;Lfgk;Z)V
    .registers 11

    if-eqz p1, :cond_72

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_72

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Lixa;

    if-nez v0, :cond_6f

    const/16 v0, 0x3f

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p3, :cond_55

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v2

    move p3, p0

    :goto_1c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    if-ge p0, v3, :cond_38

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    shl-long v5, v3, v1

    shr-long/2addr v3, v0

    xor-long/2addr v3, v5

    invoke-static {v3, v4}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v3

    add-int/2addr p3, v3

    add-int/lit8 p0, p0, 0x1

    goto :goto_1c

    :cond_38
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_3b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_72

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    shl-long v5, v3, v1

    shr-long/2addr v3, v0

    xor-long/2addr v3, v5

    invoke-virtual {p2, v3, v4}, Landroidx/glance/appwidget/protobuf/e;->C(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_3b

    :cond_55
    :goto_55
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_72

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    shl-long v5, v3, v1

    shr-long/2addr v3, v0

    xor-long/2addr v3, v5

    invoke-virtual {p2, p0, v3, v4}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_55

    :cond_6f
    invoke-static {}, Lty9;->a()V

    :cond_72
    return-void
.end method

.method public static y(ILjava/util/List;Lfgk;Z)V
    .registers 6

    if-eqz p1, :cond_63

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_63

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Ldj9;

    if-nez v0, :cond_60

    const/4 v0, 0x0

    if-eqz p3, :cond_4a

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_31

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v1}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_31
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_34
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_63

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_34

    :cond_4a
    :goto_4a
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_63

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->z(II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4a

    :cond_60
    invoke-static {}, Lty9;->a()V

    :cond_63
    return-void
.end method

.method public static z(ILjava/util/List;Lfgk;Z)V
    .registers 7

    if-eqz p1, :cond_63

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_63

    iget-object p2, p2, Lfgk;->F:Ljava/lang/Object;

    check-cast p2, Landroidx/glance/appwidget/protobuf/e;

    instance-of v0, p1, Lixa;

    if-nez v0, :cond_60

    const/4 v0, 0x0

    if-eqz p3, :cond_4a

    const/4 p3, 0x2

    invoke-virtual {p2, p0, p3}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    move p0, v0

    move p3, p0

    :goto_19
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p0, v1, :cond_31

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v1

    add-int/2addr p3, v1

    add-int/lit8 p0, p0, 0x1

    goto :goto_19

    :cond_31
    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    :goto_34
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_63

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->C(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_34

    :cond_4a
    :goto_4a
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v0, p3, :cond_63

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {p2, p0, v1, v2}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4a

    :cond_60
    invoke-static {}, Lty9;->a()V

    :cond_63
    return-void
.end method
