.class public final Landroidx/glance/appwidget/protobuf/n;
.super Lral;
.source "SourceFile"


# instance fields
.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Landroidx/glance/appwidget/protobuf/n;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final e([BII)Ljava/lang/String;
    .registers 13

    iget p0, p0, Landroidx/glance/appwidget/protobuf/n;->b:I

    packed-switch p0, :pswitch_data_156

    new-instance p0, Ljava/lang/String;

    sget-object v0, Lgl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {p0, p1, p2, p3, v0}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const v1, 0xfffd

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    if-gez v1, :cond_16

    goto :goto_25

    :cond_16
    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    add-int/2addr p3, p2

    invoke-static {p1, p2, p3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p1

    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([B[B)Z

    move-result p1

    if-eqz p1, :cond_26

    :goto_25
    return-object p0

    :cond_26
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->a()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :pswitch_2b  #0x0
    or-int p0, p2, p3

    array-length v0, p1

    sub-int/2addr v0, p2

    sub-int/2addr v0, p3

    or-int/2addr p0, v0

    if-ltz p0, :cond_13d

    add-int p0, p2, p3

    new-array p3, p3, [C

    const/4 v0, 0x0

    move v1, v0

    :goto_39
    if-ge p2, p0, :cond_48

    aget-byte v2, p1, p2

    if-ltz v2, :cond_48

    add-int/lit8 p2, p2, 0x1

    add-int/lit8 v3, v1, 0x1

    int-to-char v2, v2

    aput-char v2, p3, v1

    move v1, v3

    goto :goto_39

    :cond_48
    :goto_48
    if-ge p2, p0, :cond_137

    add-int/lit8 v2, p2, 0x1

    aget-byte v3, p1, p2

    if-ltz v3, :cond_67

    add-int/lit8 p2, v1, 0x1

    int-to-char v3, v3

    aput-char v3, p3, v1

    :goto_55
    if-ge v2, p0, :cond_64

    aget-byte v1, p1, v2

    if-ltz v1, :cond_64

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v3, p2, 0x1

    int-to-char v1, v1

    aput-char v1, p3, p2

    move p2, v3

    goto :goto_55

    :cond_64
    move v1, p2

    move p2, v2

    goto :goto_48

    :cond_67
    const/16 v4, -0x20

    if-ge v3, v4, :cond_93

    if-ge v2, p0, :cond_8e

    add-int/lit8 p2, p2, 0x2

    aget-byte v2, p1, v2

    add-int/lit8 v4, v1, 0x1

    const/16 v5, -0x3e

    if-lt v3, v5, :cond_89

    invoke-static {v2}, Llal;->j(B)Z

    move-result v5

    if-nez v5, :cond_89

    and-int/lit8 v3, v3, 0x1f

    shl-int/lit8 v3, v3, 0x6

    and-int/lit8 v2, v2, 0x3f

    or-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, p3, v1

    move v1, v4

    goto :goto_48

    :cond_89
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->a()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_8e
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->a()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_93
    const/16 v5, -0x10

    if-ge v3, v5, :cond_d9

    add-int/lit8 v5, p0, -0x1

    if-ge v2, v5, :cond_d4

    add-int/lit8 v5, p2, 0x2

    aget-byte v2, p1, v2

    add-int/lit8 p2, p2, 0x3

    aget-byte v5, p1, v5

    add-int/lit8 v6, v1, 0x1

    invoke-static {v2}, Llal;->j(B)Z

    move-result v7

    if-nez v7, :cond_cf

    const/16 v7, -0x60

    if-ne v3, v4, :cond_b1

    if-lt v2, v7, :cond_cf

    :cond_b1
    const/16 v4, -0x13

    if-ne v3, v4, :cond_b7

    if-ge v2, v7, :cond_cf

    :cond_b7
    invoke-static {v5}, Llal;->j(B)Z

    move-result v4

    if-nez v4, :cond_cf

    and-int/lit8 v3, v3, 0xf

    shl-int/lit8 v3, v3, 0xc

    and-int/lit8 v2, v2, 0x3f

    shl-int/lit8 v2, v2, 0x6

    or-int/2addr v2, v3

    and-int/lit8 v3, v5, 0x3f

    or-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, p3, v1

    move v1, v6

    goto/16 :goto_48

    :cond_cf
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->a()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_d4
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->a()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_d9
    add-int/lit8 v4, p0, -0x2

    if-ge v2, v4, :cond_132

    add-int/lit8 v4, p2, 0x2

    aget-byte v2, p1, v2

    add-int/lit8 v5, p2, 0x3

    aget-byte v4, p1, v4

    add-int/lit8 p2, p2, 0x4

    aget-byte v5, p1, v5

    add-int/lit8 v6, v1, 0x1

    invoke-static {v2}, Llal;->j(B)Z

    move-result v7

    if-nez v7, :cond_12d

    shl-int/lit8 v7, v3, 0x1c

    add-int/lit8 v8, v2, 0x70

    add-int/2addr v8, v7

    shr-int/lit8 v7, v8, 0x1e

    if-nez v7, :cond_12d

    invoke-static {v4}, Llal;->j(B)Z

    move-result v7

    if-nez v7, :cond_12d

    invoke-static {v5}, Llal;->j(B)Z

    move-result v7

    if-nez v7, :cond_12d

    and-int/lit8 v3, v3, 0x7

    shl-int/lit8 v3, v3, 0x12

    and-int/lit8 v2, v2, 0x3f

    shl-int/lit8 v2, v2, 0xc

    or-int/2addr v2, v3

    and-int/lit8 v3, v4, 0x3f

    shl-int/lit8 v3, v3, 0x6

    or-int/2addr v2, v3

    and-int/lit8 v3, v5, 0x3f

    or-int/2addr v2, v3

    ushr-int/lit8 v3, v2, 0xa

    const v4, 0xd7c0

    add-int/2addr v3, v4

    int-to-char v3, v3

    aput-char v3, p3, v1

    and-int/lit16 v2, v2, 0x3ff

    const v3, 0xdc00

    add-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, p3, v6

    add-int/lit8 v1, v1, 0x2

    goto/16 :goto_48

    :cond_12d
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->a()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_132
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->a()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_137
    new-instance p0, Ljava/lang/String;

    invoke-direct {p0, p3, v0, v1}, Ljava/lang/String;-><init>([CII)V

    goto :goto_154

    :cond_13d
    array-length p0, p1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    filled-new-array {p0, p1, p2}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "buffer length=%d, index=%d, size=%d"

    invoke-static {p1, p0}, Lgdg;->k(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 p0, 0x0

    :goto_154
    return-object p0

    nop

    :pswitch_data_156
    .packed-switch 0x0
        :pswitch_2b  #00000000
    .end packed-switch
.end method

.method public final f(Ljava/lang/String;[BII)I
    .registers 27

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move/from16 v2, p3

    move-object/from16 v3, p0

    move/from16 v4, p4

    iget v3, v3, Landroidx/glance/appwidget/protobuf/n;->b:I

    const/16 v5, 0x800

    const/16 v6, 0x80

    const v7, 0xd800

    const v8, 0xdfff

    packed-switch v3, :pswitch_data_21c

    int-to-long v10, v2

    int-to-long v12, v4

    add-long/2addr v12, v10

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    if-gt v3, v4, :cond_126

    array-length v14, v1

    sub-int/2addr v14, v4

    if-lt v14, v2, :cond_126

    const/4 v2, 0x0

    :goto_27
    const-wide/16 v14, 0x1

    if-ge v2, v3, :cond_3a

    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ge v4, v6, :cond_3a

    add-long/2addr v14, v10

    int-to-byte v4, v4

    invoke-static {v1, v10, v11, v4}, Li5j;->j([BJB)V

    add-int/lit8 v2, v2, 0x1

    move-wide v10, v14

    goto :goto_27

    :cond_3a
    if-ne v2, v3, :cond_3f

    :cond_3c
    long-to-int v9, v10

    goto/16 :goto_132

    :cond_3f
    :goto_3f
    if-ge v2, v3, :cond_3c

    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ge v4, v6, :cond_57

    cmp-long v16, v10, v12

    if-gez v16, :cond_57

    add-long v16, v10, v14

    int-to-byte v4, v4

    invoke-static {v1, v10, v11, v4}, Li5j;->j([BJB)V

    move-wide/from16 p3, v14

    move-wide/from16 v10, v16

    goto/16 :goto_f1

    :cond_57
    const-wide/16 v16, 0x2

    if-ge v4, v5, :cond_78

    sub-long v18, v12, v16

    cmp-long v18, v10, v18

    if-gtz v18, :cond_78

    move-wide/from16 p3, v14

    add-long v14, v10, p3

    ushr-int/lit8 v9, v4, 0x6

    or-int/lit16 v9, v9, 0x3c0

    int-to-byte v9, v9

    invoke-static {v1, v10, v11, v9}, Li5j;->j([BJB)V

    add-long v10, v10, v16

    and-int/lit8 v4, v4, 0x3f

    or-int/2addr v4, v6

    int-to-byte v4, v4

    invoke-static {v1, v14, v15, v4}, Li5j;->j([BJB)V

    goto/16 :goto_f1

    :cond_78
    move-wide/from16 p3, v14

    const-wide/16 v14, 0x3

    if-lt v4, v7, :cond_84

    if-ge v8, v4, :cond_81

    goto :goto_84

    :cond_81
    move-wide/from16 v18, v14

    goto :goto_ab

    :cond_84
    :goto_84
    sub-long v18, v12, v14

    cmp-long v9, v10, v18

    if-gtz v9, :cond_81

    move-wide/from16 v18, v14

    add-long v14, v10, p3

    ushr-int/lit8 v9, v4, 0xc

    or-int/lit16 v9, v9, 0x1e0

    int-to-byte v9, v9

    invoke-static {v1, v10, v11, v9}, Li5j;->j([BJB)V

    add-long v8, v10, v16

    ushr-int/lit8 v16, v4, 0x6

    and-int/lit8 v5, v16, 0x3f

    or-int/2addr v5, v6

    int-to-byte v5, v5

    invoke-static {v1, v14, v15, v5}, Li5j;->j([BJB)V

    add-long v10, v10, v18

    and-int/lit8 v4, v4, 0x3f

    or-int/2addr v4, v6

    int-to-byte v4, v4

    invoke-static {v1, v8, v9, v4}, Li5j;->j([BJB)V

    goto :goto_f1

    :goto_ab
    const-wide/16 v8, 0x4

    sub-long v14, v12, v8

    cmp-long v5, v10, v14

    if-gtz v5, :cond_105

    add-int/lit8 v5, v2, 0x1

    if-eq v5, v3, :cond_fd

    invoke-virtual {v0, v5}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v4, v2}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v14

    if-eqz v14, :cond_fc

    invoke-static {v4, v2}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v2

    add-long v14, v10, p3

    ushr-int/lit8 v4, v2, 0x12

    or-int/lit16 v4, v4, 0xf0

    int-to-byte v4, v4

    invoke-static {v1, v10, v11, v4}, Li5j;->j([BJB)V

    move-wide/from16 v20, v8

    add-long v8, v10, v16

    ushr-int/lit8 v4, v2, 0xc

    and-int/lit8 v4, v4, 0x3f

    or-int/2addr v4, v6

    int-to-byte v4, v4

    invoke-static {v1, v14, v15, v4}, Li5j;->j([BJB)V

    add-long v14, v10, v18

    ushr-int/lit8 v4, v2, 0x6

    and-int/lit8 v4, v4, 0x3f

    or-int/2addr v4, v6

    int-to-byte v4, v4

    invoke-static {v1, v8, v9, v4}, Li5j;->j([BJB)V

    add-long v10, v10, v20

    and-int/lit8 v2, v2, 0x3f

    or-int/2addr v2, v6

    int-to-byte v2, v2

    invoke-static {v1, v14, v15, v2}, Li5j;->j([BJB)V

    move v2, v5

    :goto_f1
    add-int/lit8 v2, v2, 0x1

    move-wide/from16 v14, p3

    const/16 v5, 0x800

    const v8, 0xdfff

    goto/16 :goto_3f

    :cond_fc
    move v2, v5

    :cond_fd
    new-instance v0, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;

    add-int/lit8 v2, v2, -0x1

    invoke-direct {v0, v2, v3}, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_105
    if-gt v7, v4, :cond_121

    const v1, 0xdfff

    if-gt v4, v1, :cond_121

    add-int/lit8 v1, v2, 0x1

    if-eq v1, v3, :cond_11b

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v4, v0}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v0

    if-eqz v0, :cond_11b

    goto :goto_121

    :cond_11b
    new-instance v0, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;

    invoke-direct {v0, v2, v3}, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_121
    :goto_121
    invoke-static {v4, v10, v11}, Lm1f;->f(IJ)V

    :goto_124
    const/4 v9, 0x0

    goto :goto_132

    :cond_126
    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v0

    add-int v1, v2, v4

    invoke-static {v0, v1}, Lm1f;->e(II)V

    goto :goto_124

    :goto_132
    return v9

    :pswitch_133  #0x0
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    add-int/2addr v4, v2

    const/4 v5, 0x0

    :goto_139
    if-ge v5, v3, :cond_14b

    add-int v8, v5, v2

    if-ge v8, v4, :cond_14b

    invoke-virtual {v0, v5}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-ge v9, v6, :cond_14b

    int-to-byte v9, v9

    aput-byte v9, v1, v8

    add-int/lit8 v5, v5, 0x1

    goto :goto_139

    :cond_14b
    if-ne v5, v3, :cond_151

    add-int v9, v2, v3

    goto/16 :goto_21a

    :cond_151
    add-int/2addr v2, v5

    :goto_152
    if-ge v5, v3, :cond_219

    invoke-virtual {v0, v5}, Ljava/lang/String;->charAt(I)C

    move-result v8

    if-ge v8, v6, :cond_166

    if-ge v2, v4, :cond_166

    add-int/lit8 v9, v2, 0x1

    int-to-byte v8, v8

    aput-byte v8, v1, v2

    move v2, v9

    const/16 v9, 0x800

    goto/16 :goto_1e7

    :cond_166
    const/16 v9, 0x800

    if-ge v8, v9, :cond_180

    add-int/lit8 v10, v4, -0x2

    if-gt v2, v10, :cond_180

    add-int/lit8 v10, v2, 0x1

    ushr-int/lit8 v11, v8, 0x6

    or-int/lit16 v11, v11, 0x3c0

    int-to-byte v11, v11

    aput-byte v11, v1, v2

    add-int/lit8 v2, v2, 0x2

    and-int/lit8 v8, v8, 0x3f

    or-int/2addr v8, v6

    int-to-byte v8, v8

    aput-byte v8, v1, v10

    goto :goto_1e7

    :cond_180
    if-lt v8, v7, :cond_187

    const v10, 0xdfff

    if-ge v10, v8, :cond_1a7

    :cond_187
    add-int/lit8 v10, v4, -0x3

    if-gt v2, v10, :cond_1a7

    add-int/lit8 v10, v2, 0x1

    ushr-int/lit8 v11, v8, 0xc

    or-int/lit16 v11, v11, 0x1e0

    int-to-byte v11, v11

    aput-byte v11, v1, v2

    add-int/lit8 v11, v2, 0x2

    ushr-int/lit8 v12, v8, 0x6

    and-int/lit8 v12, v12, 0x3f

    or-int/2addr v12, v6

    int-to-byte v12, v12

    aput-byte v12, v1, v10

    add-int/lit8 v2, v2, 0x3

    and-int/lit8 v8, v8, 0x3f

    or-int/2addr v8, v6

    int-to-byte v8, v8

    aput-byte v8, v1, v11

    goto :goto_1e7

    :cond_1a7
    add-int/lit8 v10, v4, -0x4

    if-gt v2, v10, :cond_1f4

    add-int/lit8 v10, v5, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v11

    if-eq v10, v11, :cond_1ec

    invoke-virtual {v0, v10}, Ljava/lang/String;->charAt(I)C

    move-result v5

    invoke-static {v8, v5}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v11

    if-eqz v11, :cond_1eb

    invoke-static {v8, v5}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v5

    add-int/lit8 v8, v2, 0x1

    ushr-int/lit8 v11, v5, 0x12

    or-int/lit16 v11, v11, 0xf0

    int-to-byte v11, v11

    aput-byte v11, v1, v2

    add-int/lit8 v11, v2, 0x2

    ushr-int/lit8 v12, v5, 0xc

    and-int/lit8 v12, v12, 0x3f

    or-int/2addr v12, v6

    int-to-byte v12, v12

    aput-byte v12, v1, v8

    add-int/lit8 v8, v2, 0x3

    ushr-int/lit8 v12, v5, 0x6

    and-int/lit8 v12, v12, 0x3f

    or-int/2addr v12, v6

    int-to-byte v12, v12

    aput-byte v12, v1, v11

    add-int/lit8 v2, v2, 0x4

    and-int/lit8 v5, v5, 0x3f

    or-int/2addr v5, v6

    int-to-byte v5, v5

    aput-byte v5, v1, v8

    move v5, v10

    :goto_1e7
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_152

    :cond_1eb
    move v5, v10

    :cond_1ec
    new-instance v0, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;

    add-int/lit8 v5, v5, -0x1

    invoke-direct {v0, v5, v3}, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_1f4
    if-gt v7, v8, :cond_214

    const v1, 0xdfff

    if-gt v8, v1, :cond_214

    add-int/lit8 v1, v5, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    if-eq v1, v4, :cond_20e

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v8, v0}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v0

    if-eqz v0, :cond_20e

    goto :goto_214

    :cond_20e
    new-instance v0, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;

    invoke-direct {v0, v5, v3}, Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    throw v0

    :cond_214
    :goto_214
    invoke-static {v8, v2}, Lgdg;->e(II)V

    const/4 v9, 0x0

    goto :goto_21a

    :cond_219
    move v9, v2

    :goto_21a
    return v9

    nop

    :pswitch_data_21c
    .packed-switch 0x0
        :pswitch_133  #00000000
    .end packed-switch
.end method
