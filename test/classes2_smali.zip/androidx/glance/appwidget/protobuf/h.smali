.class public final Landroidx/glance/appwidget/protobuf/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lzxf;


# static fields
.field public static final n:[I

.field public static final o:Lsun/misc/Unsafe;


# instance fields
.field public final a:[I

.field public final b:[Ljava/lang/Object;

.field public final c:I

.field public final d:I

.field public final e:Landroidx/glance/appwidget/protobuf/a;

.field public final f:Z

.field public final g:[I

.field public final h:I

.field public final i:I

.field public final j:Lwjc;

.field public final k:Ldma;

.field public final l:Landroidx/glance/appwidget/protobuf/k;

.field public final m:Lv5b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    new-array v0, v0, [I

    sput-object v0, Landroidx/glance/appwidget/protobuf/h;->n:[I

    invoke-static {}, Li5j;->i()Lsun/misc/Unsafe;

    move-result-object v0

    sput-object v0, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    return-void
.end method

.method public constructor <init>([I[Ljava/lang/Object;IILandroidx/glance/appwidget/protobuf/a;[IIILwjc;Ldma;Landroidx/glance/appwidget/protobuf/k;Llm7;Lv5b;)V
    .registers 14

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    iput-object p2, p0, Landroidx/glance/appwidget/protobuf/h;->b:[Ljava/lang/Object;

    iput p3, p0, Landroidx/glance/appwidget/protobuf/h;->c:I

    iput p4, p0, Landroidx/glance/appwidget/protobuf/h;->d:I

    instance-of p1, p5, Landroidx/glance/appwidget/protobuf/f;

    iput-boolean p1, p0, Landroidx/glance/appwidget/protobuf/h;->f:Z

    iput-object p6, p0, Landroidx/glance/appwidget/protobuf/h;->g:[I

    iput p7, p0, Landroidx/glance/appwidget/protobuf/h;->h:I

    iput p8, p0, Landroidx/glance/appwidget/protobuf/h;->i:I

    iput-object p9, p0, Landroidx/glance/appwidget/protobuf/h;->j:Lwjc;

    iput-object p10, p0, Landroidx/glance/appwidget/protobuf/h;->k:Ldma;

    iput-object p11, p0, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    iput-object p5, p0, Landroidx/glance/appwidget/protobuf/h;->e:Landroidx/glance/appwidget/protobuf/a;

    iput-object p13, p0, Landroidx/glance/appwidget/protobuf/h;->m:Lv5b;

    return-void
.end method

.method public static F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    .registers 7

    :try_start_0
    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0
    :try_end_4
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_4} :catch_5

    return-object p0

    :catch_5
    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_b
    if-ge v2, v1, :cond_1d

    aget-object v3, v0, v2

    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1a

    return-object v3

    :cond_1a
    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_1d
    new-instance v1, Ljava/lang/RuntimeException;

    const-string v2, "Field "

    const-string v3, " for "

    invoke-static {v2, p1, v3}, Ld07;->x(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " not found. Known fields are "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public static K(I)I
    .registers 2

    const/high16 v0, 0xff00000

    and-int/2addr p0, v0

    ushr-int/lit8 p0, p0, 0x14

    return p0
.end method

.method public static p(Ljava/lang/Object;)Z
    .registers 2

    if-nez p0, :cond_4

    const/4 p0, 0x0

    return p0

    :cond_4
    instance-of v0, p0, Landroidx/glance/appwidget/protobuf/f;

    if-eqz v0, :cond_f

    check-cast p0, Landroidx/glance/appwidget/protobuf/f;

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/f;->f()Z

    move-result p0

    return p0

    :cond_f
    const/4 p0, 0x1

    return p0
.end method

.method public static w(Llne;Lwjc;Ldma;Landroidx/glance/appwidget/protobuf/k;Llm7;Lv5b;)Landroidx/glance/appwidget/protobuf/h;
    .registers 42

    move-object/from16 v0, p0

    iget-object v1, v0, Llne;->b:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const v6, 0xd800

    if-lt v4, v6, :cond_1d

    const/4 v4, 0x1

    :goto_13
    add-int/lit8 v7, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_1e

    move v4, v7

    goto :goto_13

    :cond_1d
    const/4 v7, 0x1

    :cond_1e
    add-int/lit8 v4, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_3d

    and-int/lit16 v7, v7, 0x1fff

    const/16 v9, 0xd

    :goto_2a
    add-int/lit8 v10, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_3a

    and-int/lit16 v4, v4, 0x1fff

    shl-int/2addr v4, v9

    or-int/2addr v7, v4

    add-int/lit8 v9, v9, 0xd

    move v4, v10

    goto :goto_2a

    :cond_3a
    shl-int/2addr v4, v9

    or-int/2addr v7, v4

    move v4, v10

    :cond_3d
    if-nez v7, :cond_4d

    sget-object v7, Landroidx/glance/appwidget/protobuf/h;->n:[I

    move v9, v3

    move v10, v9

    move v11, v10

    move v12, v11

    move v13, v12

    move/from16 v16, v13

    move-object v15, v7

    move/from16 v7, v16

    goto/16 :goto_160

    :cond_4d
    add-int/lit8 v7, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_6c

    and-int/lit16 v4, v4, 0x1fff

    const/16 v9, 0xd

    :goto_59
    add-int/lit8 v10, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_69

    and-int/lit16 v7, v7, 0x1fff

    shl-int/2addr v7, v9

    or-int/2addr v4, v7

    add-int/lit8 v9, v9, 0xd

    move v7, v10

    goto :goto_59

    :cond_69
    shl-int/2addr v7, v9

    or-int/2addr v4, v7

    move v7, v10

    :cond_6c
    add-int/lit8 v9, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_8b

    and-int/lit16 v7, v7, 0x1fff

    const/16 v10, 0xd

    :goto_78
    add-int/lit8 v11, v9, 0x1

    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-lt v9, v6, :cond_88

    and-int/lit16 v9, v9, 0x1fff

    shl-int/2addr v9, v10

    or-int/2addr v7, v9

    add-int/lit8 v10, v10, 0xd

    move v9, v11

    goto :goto_78

    :cond_88
    shl-int/2addr v9, v10

    or-int/2addr v7, v9

    move v9, v11

    :cond_8b
    add-int/lit8 v10, v9, 0x1

    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-lt v9, v6, :cond_aa

    and-int/lit16 v9, v9, 0x1fff

    const/16 v11, 0xd

    :goto_97
    add-int/lit8 v12, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v6, :cond_a7

    and-int/lit16 v10, v10, 0x1fff

    shl-int/2addr v10, v11

    or-int/2addr v9, v10

    add-int/lit8 v11, v11, 0xd

    move v10, v12

    goto :goto_97

    :cond_a7
    shl-int/2addr v10, v11

    or-int/2addr v9, v10

    move v10, v12

    :cond_aa
    add-int/lit8 v11, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v6, :cond_c9

    and-int/lit16 v10, v10, 0x1fff

    const/16 v12, 0xd

    :goto_b6
    add-int/lit8 v13, v11, 0x1

    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v11

    if-lt v11, v6, :cond_c6

    and-int/lit16 v11, v11, 0x1fff

    shl-int/2addr v11, v12

    or-int/2addr v10, v11

    add-int/lit8 v12, v12, 0xd

    move v11, v13

    goto :goto_b6

    :cond_c6
    shl-int/2addr v11, v12

    or-int/2addr v10, v11

    move v11, v13

    :cond_c9
    add-int/lit8 v12, v11, 0x1

    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v11

    if-lt v11, v6, :cond_e8

    and-int/lit16 v11, v11, 0x1fff

    const/16 v13, 0xd

    :goto_d5
    add-int/lit8 v14, v12, 0x1

    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    if-lt v12, v6, :cond_e5

    and-int/lit16 v12, v12, 0x1fff

    shl-int/2addr v12, v13

    or-int/2addr v11, v12

    add-int/lit8 v13, v13, 0xd

    move v12, v14

    goto :goto_d5

    :cond_e5
    shl-int/2addr v12, v13

    or-int/2addr v11, v12

    move v12, v14

    :cond_e8
    add-int/lit8 v13, v12, 0x1

    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    if-lt v12, v6, :cond_107

    and-int/lit16 v12, v12, 0x1fff

    const/16 v14, 0xd

    :goto_f4
    add-int/lit8 v15, v13, 0x1

    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-lt v13, v6, :cond_104

    and-int/lit16 v13, v13, 0x1fff

    shl-int/2addr v13, v14

    or-int/2addr v12, v13

    add-int/lit8 v14, v14, 0xd

    move v13, v15

    goto :goto_f4

    :cond_104
    shl-int/2addr v13, v14

    or-int/2addr v12, v13

    move v13, v15

    :cond_107
    add-int/lit8 v14, v13, 0x1

    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-lt v13, v6, :cond_128

    and-int/lit16 v13, v13, 0x1fff

    const/16 v15, 0xd

    :goto_113
    add-int/lit8 v16, v14, 0x1

    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-lt v14, v6, :cond_124

    and-int/lit16 v14, v14, 0x1fff

    shl-int/2addr v14, v15

    or-int/2addr v13, v14

    add-int/lit8 v15, v15, 0xd

    move/from16 v14, v16

    goto :goto_113

    :cond_124
    shl-int/2addr v14, v15

    or-int/2addr v13, v14

    move/from16 v14, v16

    :cond_128
    add-int/lit8 v15, v14, 0x1

    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-lt v14, v6, :cond_14b

    and-int/lit16 v14, v14, 0x1fff

    const/16 v16, 0xd

    :goto_134
    add-int/lit8 v17, v15, 0x1

    invoke-virtual {v1, v15}, Ljava/lang/String;->charAt(I)C

    move-result v15

    if-lt v15, v6, :cond_146

    and-int/lit16 v15, v15, 0x1fff

    shl-int v15, v15, v16

    or-int/2addr v14, v15

    add-int/lit8 v16, v16, 0xd

    move/from16 v15, v17

    goto :goto_134

    :cond_146
    shl-int v15, v15, v16

    or-int/2addr v14, v15

    move/from16 v15, v17

    :cond_14b
    add-int v16, v14, v12

    add-int v13, v16, v13

    new-array v13, v13, [I

    mul-int/lit8 v16, v4, 0x2

    add-int v16, v16, v7

    move v7, v12

    move v12, v9

    move v9, v7

    move v7, v4

    move v4, v15

    move-object v15, v13

    move v13, v10

    move/from16 v10, v16

    move/from16 v16, v14

    :goto_160
    sget-object v14, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    iget-object v3, v0, Llne;->c:[Ljava/lang/Object;

    iget-object v8, v0, Llne;->a:Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    mul-int/lit8 v5, v11, 0x3

    new-array v5, v5, [I

    const/4 v6, 0x2

    mul-int/2addr v11, v6

    new-array v11, v11, [Ljava/lang/Object;

    add-int v9, v16, v9

    move/from16 v24, v9

    move/from16 v23, v16

    const/4 v6, 0x0

    const/16 v21, 0x0

    :goto_17b
    if-ge v4, v2, :cond_408

    add-int/lit8 v25, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    move/from16 v26, v2

    const v2, 0xd800

    if-lt v4, v2, :cond_1af

    and-int/lit16 v4, v4, 0x1fff

    move/from16 v2, v25

    const/16 v25, 0xd

    :goto_190
    add-int/lit8 v27, v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    move-object/from16 v28, v3

    const v3, 0xd800

    if-lt v2, v3, :cond_1a9

    and-int/lit16 v2, v2, 0x1fff

    shl-int v2, v2, v25

    or-int/2addr v4, v2

    add-int/lit8 v25, v25, 0xd

    move/from16 v2, v27

    move-object/from16 v3, v28

    goto :goto_190

    :cond_1a9
    shl-int v2, v2, v25

    or-int/2addr v4, v2

    move/from16 v2, v27

    goto :goto_1b3

    :cond_1af
    move-object/from16 v28, v3

    move/from16 v2, v25

    :goto_1b3
    add-int/lit8 v3, v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    move/from16 v25, v3

    const v3, 0xd800

    if-lt v2, v3, :cond_1e5

    and-int/lit16 v2, v2, 0x1fff

    move/from16 v3, v25

    const/16 v25, 0xd

    :goto_1c6
    add-int/lit8 v27, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    move/from16 v29, v2

    const v2, 0xd800

    if-lt v3, v2, :cond_1de

    and-int/lit16 v2, v3, 0x1fff

    shl-int v2, v2, v25

    or-int v2, v29, v2

    add-int/lit8 v25, v25, 0xd

    move/from16 v3, v27

    goto :goto_1c6

    :cond_1de
    shl-int v2, v3, v25

    or-int v2, v29, v2

    move/from16 v3, v27

    goto :goto_1e7

    :cond_1e5
    move/from16 v3, v25

    :goto_1e7
    move/from16 v25, v4

    and-int/lit16 v4, v2, 0xff

    move-object/from16 v27, v5

    and-int/lit16 v5, v2, 0x400

    if-eqz v5, :cond_1f7

    add-int/lit8 v5, v21, 0x1

    aput v6, v15, v21

    move/from16 v21, v5

    :cond_1f7
    const/16 v5, 0x33

    move/from16 v31, v7

    if-lt v4, v5, :cond_2b0

    add-int/lit8 v5, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const v7, 0xd800

    if-lt v3, v7, :cond_226

    and-int/lit16 v3, v3, 0x1fff

    const/16 v34, 0xd

    :goto_20c
    add-int/lit8 v35, v5, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-lt v5, v7, :cond_221

    and-int/lit16 v5, v5, 0x1fff

    shl-int v5, v5, v34

    or-int/2addr v3, v5

    add-int/lit8 v34, v34, 0xd

    move/from16 v5, v35

    const v7, 0xd800

    goto :goto_20c

    :cond_221
    shl-int v5, v5, v34

    or-int/2addr v3, v5

    move/from16 v5, v35

    :cond_226
    add-int/lit8 v7, v4, -0x33

    move/from16 v34, v3

    const/16 v3, 0x9

    if-eq v7, v3, :cond_232

    const/16 v3, 0x11

    if-ne v7, v3, :cond_238

    :cond_232
    move/from16 v29, v5

    const/4 v3, 0x3

    const/4 v5, 0x2

    const/4 v7, 0x1

    goto :goto_263

    :cond_238
    const/16 v3, 0xc

    if-ne v7, v3, :cond_261

    invoke-virtual {v0}, Llne;->a()I

    move-result v3

    const/4 v7, 0x1

    invoke-static {v3, v7}, Ld07;->c(II)Z

    move-result v3

    if-nez v3, :cond_24b

    and-int/lit16 v3, v2, 0x800

    if-eqz v3, :cond_250

    :cond_24b
    move/from16 v29, v5

    const/4 v3, 0x3

    const/4 v5, 0x2

    goto :goto_254

    :cond_250
    :goto_250
    move/from16 v29, v5

    const/4 v5, 0x2

    goto :goto_26e

    :goto_254
    invoke-static {v6, v3, v5, v7}, Lti6;->e(IIII)I

    move-result v3

    add-int/lit8 v19, v10, 0x1

    aget-object v10, v28, v10

    aput-object v10, v11, v3

    move/from16 v10, v19

    goto :goto_26e

    :cond_261
    const/4 v7, 0x1

    goto :goto_250

    :goto_263
    invoke-static {v6, v3, v5, v7}, Lti6;->e(IIII)I

    move-result v3

    add-int/lit8 v7, v10, 0x1

    aget-object v10, v28, v10

    aput-object v10, v11, v3

    move v10, v7

    :goto_26e
    mul-int/lit8 v3, v34, 0x2

    aget-object v5, v28, v3

    instance-of v7, v5, Ljava/lang/reflect/Field;

    if-eqz v7, :cond_27c

    check-cast v5, Ljava/lang/reflect/Field;

    :goto_278
    move v7, v9

    move/from16 v30, v10

    goto :goto_285

    :cond_27c
    check-cast v5, Ljava/lang/String;

    invoke-static {v8, v5}, Landroidx/glance/appwidget/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    aput-object v5, v28, v3

    goto :goto_278

    :goto_285
    invoke-virtual {v14, v5}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v5, v9

    add-int/lit8 v3, v3, 0x1

    aget-object v9, v28, v3

    instance-of v10, v9, Ljava/lang/reflect/Field;

    if-eqz v10, :cond_295

    check-cast v9, Ljava/lang/reflect/Field;

    goto :goto_29d

    :cond_295
    check-cast v9, Ljava/lang/String;

    invoke-static {v8, v9}, Landroidx/glance/appwidget/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v9

    aput-object v9, v28, v3

    :goto_29d
    invoke-virtual {v14, v9}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v3, v9

    move-object/from16 v32, v1

    move v9, v5

    move v1, v6

    move/from16 v10, v29

    const/16 v22, 0x2

    move v5, v3

    move/from16 v29, v7

    const/4 v3, 0x0

    goto/16 :goto_3c5

    :cond_2b0
    move v7, v9

    add-int/lit8 v5, v10, 0x1

    aget-object v9, v28, v10

    check-cast v9, Ljava/lang/String;

    invoke-static {v8, v9}, Landroidx/glance/appwidget/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v9

    move/from16 v34, v5

    const/16 v5, 0x9

    if-eq v4, v5, :cond_2c5

    const/16 v5, 0x11

    if-ne v4, v5, :cond_2cc

    :cond_2c5
    move/from16 v29, v7

    const/4 v5, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x2

    goto/16 :goto_345

    :cond_2cc
    const/16 v5, 0x1b

    if-eq v4, v5, :cond_2d4

    const/16 v5, 0x31

    if-ne v4, v5, :cond_2dc

    :cond_2d4
    move/from16 v29, v7

    move/from16 v19, v10

    const/4 v5, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x2

    goto :goto_33a

    :cond_2dc
    const/16 v5, 0xc

    if-eq v4, v5, :cond_31c

    const/16 v5, 0x1e

    if-eq v4, v5, :cond_31c

    const/16 v5, 0x2c

    if-ne v4, v5, :cond_2e9

    goto :goto_31c

    :cond_2e9
    const/16 v5, 0x32

    if-ne v4, v5, :cond_318

    add-int/lit8 v5, v23, 0x1

    aput v6, v15, v23

    div-int/lit8 v23, v6, 0x3

    const/16 v22, 0x2

    mul-int/lit8 v23, v23, 0x2

    add-int/lit8 v29, v10, 0x2

    aget-object v30, v28, v34

    aput-object v30, v11, v23

    move/from16 v30, v5

    and-int/lit16 v5, v2, 0x800

    if-eqz v5, :cond_311

    add-int/lit8 v23, v23, 0x1

    add-int/lit8 v5, v10, 0x3

    aget-object v10, v28, v29

    aput-object v10, v11, v23

    move/from16 v29, v7

    move/from16 v23, v30

    :goto_30f
    const/4 v7, 0x1

    goto :goto_351

    :cond_311
    move/from16 v5, v29

    move/from16 v23, v30

    move/from16 v29, v7

    goto :goto_30f

    :cond_318
    move/from16 v29, v7

    const/4 v7, 0x1

    goto :goto_34f

    :cond_31c
    :goto_31c
    invoke-virtual {v0}, Llne;->a()I

    move-result v5

    move/from16 v29, v7

    const/4 v7, 0x1

    if-eq v5, v7, :cond_329

    and-int/lit16 v5, v2, 0x800

    if-eqz v5, :cond_34f

    :cond_329
    move/from16 v19, v10

    const/4 v5, 0x3

    const/4 v10, 0x2

    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    add-int/lit8 v19, v19, 0x2

    aget-object v22, v28, v34

    aput-object v22, v11, v5

    :goto_337
    move/from16 v5, v19

    goto :goto_351

    :goto_33a
    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    add-int/lit8 v19, v19, 0x2

    aget-object v22, v28, v34

    aput-object v22, v11, v5

    goto :goto_337

    :goto_345
    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    invoke-virtual {v9}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v10

    aput-object v10, v11, v5

    :cond_34f
    :goto_34f
    move/from16 v5, v34

    :goto_351
    invoke-virtual {v14, v9}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v9, v9

    and-int/lit16 v10, v2, 0x1000

    if-eqz v10, :cond_3ab

    const/16 v10, 0x11

    if-gt v4, v10, :cond_3ab

    add-int/lit8 v10, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const v7, 0xd800

    if-lt v3, v7, :cond_384

    and-int/lit16 v3, v3, 0x1fff

    const/16 v20, 0xd

    :goto_36d
    add-int/lit8 v30, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v7, :cond_37f

    and-int/lit16 v10, v10, 0x1fff

    shl-int v10, v10, v20

    or-int/2addr v3, v10

    add-int/lit8 v20, v20, 0xd

    move/from16 v10, v30

    goto :goto_36d

    :cond_37f
    shl-int v10, v10, v20

    or-int/2addr v3, v10

    move/from16 v10, v30

    :cond_384
    const/16 v22, 0x2

    mul-int/lit8 v20, v31, 0x2

    div-int/lit8 v30, v3, 0x20

    add-int v30, v30, v20

    aget-object v7, v28, v30

    move-object/from16 v32, v1

    instance-of v1, v7, Ljava/lang/reflect/Field;

    if-eqz v1, :cond_39a

    check-cast v7, Ljava/lang/reflect/Field;

    :goto_396
    move/from16 v30, v5

    move v1, v6

    goto :goto_3a3

    :cond_39a
    check-cast v7, Ljava/lang/String;

    invoke-static {v8, v7}, Landroidx/glance/appwidget/protobuf/h;->F(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v7

    aput-object v7, v28, v30

    goto :goto_396

    :goto_3a3
    invoke-virtual {v14, v7}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v5

    long-to-int v5, v5

    rem-int/lit8 v3, v3, 0x20

    goto :goto_3b7

    :cond_3ab
    move-object/from16 v32, v1

    move/from16 v30, v5

    move v1, v6

    const/16 v22, 0x2

    const v5, 0xfffff

    move v10, v3

    const/4 v3, 0x0

    :goto_3b7
    const/16 v6, 0x12

    if-lt v4, v6, :cond_3c5

    const/16 v6, 0x31

    if-gt v4, v6, :cond_3c5

    add-int/lit8 v6, v24, 0x1

    aput v9, v15, v24

    move/from16 v24, v6

    :cond_3c5
    :goto_3c5
    add-int/lit8 v6, v1, 0x1

    aput v25, v27, v1

    add-int/lit8 v7, v1, 0x2

    move/from16 v25, v1

    and-int/lit16 v1, v2, 0x200

    if-eqz v1, :cond_3d4

    const/high16 v1, 0x20000000

    goto :goto_3d5

    :cond_3d4
    const/4 v1, 0x0

    :goto_3d5
    move/from16 v33, v1

    and-int/lit16 v1, v2, 0x100

    if-eqz v1, :cond_3de

    const/high16 v1, 0x10000000

    goto :goto_3df

    :cond_3de
    const/4 v1, 0x0

    :goto_3df
    or-int v1, v33, v1

    and-int/lit16 v2, v2, 0x800

    if-eqz v2, :cond_3e8

    const/high16 v2, -0x80000000

    goto :goto_3e9

    :cond_3e8
    const/4 v2, 0x0

    :goto_3e9
    or-int/2addr v1, v2

    shl-int/lit8 v2, v4, 0x14

    or-int/2addr v1, v2

    or-int/2addr v1, v9

    aput v1, v27, v6

    add-int/lit8 v6, v25, 0x3

    shl-int/lit8 v1, v3, 0x14

    or-int/2addr v1, v5

    aput v1, v27, v7

    move v4, v10

    move/from16 v2, v26

    move-object/from16 v5, v27

    move-object/from16 v3, v28

    move/from16 v9, v29

    move/from16 v10, v30

    move/from16 v7, v31

    move-object/from16 v1, v32

    goto/16 :goto_17b

    :cond_408
    move-object/from16 v27, v5

    move/from16 v29, v9

    new-instance v9, Landroidx/glance/appwidget/protobuf/h;

    iget-object v14, v0, Llne;->a:Landroidx/glance/appwidget/protobuf/a;

    move-object/from16 v18, p1

    move-object/from16 v19, p2

    move-object/from16 v20, p3

    move-object/from16 v21, p4

    move-object/from16 v22, p5

    move-object/from16 v10, v27

    move/from16 v17, v29

    invoke-direct/range {v9 .. v22}, Landroidx/glance/appwidget/protobuf/h;-><init>([I[Ljava/lang/Object;IILandroidx/glance/appwidget/protobuf/a;[IIILwjc;Ldma;Landroidx/glance/appwidget/protobuf/k;Llm7;Lv5b;)V

    return-object v9
.end method

.method public static x(I)J
    .registers 3

    const v0, 0xfffff

    and-int/2addr p0, v0

    int-to-long v0, p0

    return-wide v0
.end method

.method public static y(JLjava/lang/Object;)I
    .registers 4

    sget-object v0, Li5j;->c:Ld5j;

    invoke-virtual {v0, p0, p1, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public static z(JLjava/lang/Object;)J
    .registers 4

    sget-object v0, Li5j;->c:Ld5j;

    invoke-virtual {v0, p0, p1, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    return-wide p0
.end method


# virtual methods
.method public final A(I)I
    .registers 7

    iget v0, p0, Landroidx/glance/appwidget/protobuf/h;->c:I

    if-lt p1, v0, :cond_27

    iget v0, p0, Landroidx/glance/appwidget/protobuf/h;->d:I

    if-gt p1, v0, :cond_27

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    array-length v0, p0

    div-int/lit8 v0, v0, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    :goto_10
    if-gt v1, v0, :cond_27

    add-int v2, v0, v1

    ushr-int/lit8 v2, v2, 0x1

    mul-int/lit8 v3, v2, 0x3

    aget v4, p0, v3

    if-ne p1, v4, :cond_1d

    return v3

    :cond_1d
    if-ge p1, v4, :cond_23

    add-int/lit8 v2, v2, -0x1

    move v0, v2

    goto :goto_10

    :cond_23
    add-int/lit8 v2, v2, 0x1

    move v1, v2

    goto :goto_10

    :cond_27
    const/4 p0, -0x1

    return p0
.end method

.method public final B(Ljava/lang/Object;JLandroidx/glance/appwidget/protobuf/d;Lzxf;Lfm7;)V
    .registers 8

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->k:Ldma;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p2, p3, p1}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object p0

    iget-object p1, p4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    iget p2, p4, Landroidx/glance/appwidget/protobuf/d;->b:I

    and-int/lit8 p3, p2, 0x7

    const/4 v0, 0x3

    if-ne p3, v0, :cond_33

    :cond_12
    invoke-interface {p5}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p3

    invoke-virtual {p4, p3, p5, p6}, Landroidx/glance/appwidget/protobuf/d;->b(Ljava/lang/Object;Lzxf;Lfm7;)V

    invoke-interface {p5, p3}, Lzxf;->b(Ljava/lang/Object;)V

    invoke-interface {p0, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Lkl4;->g()Z

    move-result p3

    if-nez p3, :cond_32

    iget p3, p4, Landroidx/glance/appwidget/protobuf/d;->d:I

    if-eqz p3, :cond_2a

    goto :goto_32

    :cond_2a
    invoke-virtual {p1}, Lkl4;->C()I

    move-result p3

    if-eq p3, p2, :cond_12

    iput p3, p4, Landroidx/glance/appwidget/protobuf/d;->d:I

    :cond_32
    :goto_32
    return-void

    :cond_33
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->b()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p0

    throw p0
.end method

.method public final C(Ljava/lang/Object;ILandroidx/glance/appwidget/protobuf/d;Lzxf;Lfm7;)V
    .registers 8

    const v0, 0xfffff

    and-int/2addr p2, v0

    int-to-long v0, p2

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->k:Ldma;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1, p1}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object p0

    iget-object p1, p3, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    iget p2, p3, Landroidx/glance/appwidget/protobuf/d;->b:I

    and-int/lit8 v0, p2, 0x7

    const/4 v1, 0x2

    if-ne v0, v1, :cond_38

    :cond_17
    invoke-interface {p4}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object v0

    invoke-virtual {p3, v0, p4, p5}, Landroidx/glance/appwidget/protobuf/d;->c(Ljava/lang/Object;Lzxf;Lfm7;)V

    invoke-interface {p4, v0}, Lzxf;->b(Ljava/lang/Object;)V

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Lkl4;->g()Z

    move-result v0

    if-nez v0, :cond_37

    iget v0, p3, Landroidx/glance/appwidget/protobuf/d;->d:I

    if-eqz v0, :cond_2f

    goto :goto_37

    :cond_2f
    invoke-virtual {p1}, Lkl4;->C()I

    move-result v0

    if-eq v0, p2, :cond_17

    iput v0, p3, Landroidx/glance/appwidget/protobuf/d;->d:I

    :cond_37
    :goto_37
    return-void

    :cond_38
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->b()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p0

    throw p0
.end method

.method public final D(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)V
    .registers 7

    const/high16 v0, 0x20000000

    and-int/2addr v0, p1

    const/4 v1, 0x2

    const v2, 0xfffff

    if-eqz v0, :cond_19

    and-int p0, p1, v2

    int-to-long p0, p0

    invoke-virtual {p2, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object p2, p2, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {p2}, Lkl4;->B()Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1, p3, p2}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_19
    iget-boolean p0, p0, Landroidx/glance/appwidget/protobuf/h;->f:Z

    if-eqz p0, :cond_2d

    and-int p0, p1, v2

    int-to-long p0, p0

    invoke-virtual {p2, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object p2, p2, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {p2}, Lkl4;->A()Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1, p3, p2}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_2d
    and-int p0, p1, v2

    int-to-long p0, p0

    invoke-virtual {p2}, Landroidx/glance/appwidget/protobuf/d;->e()Lg92;

    move-result-object p2

    invoke-static {p0, p1, p3, p2}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final E(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)V
    .registers 8

    const/high16 v0, 0x20000000

    and-int/2addr v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_9

    move v0, v2

    goto :goto_a

    :cond_9
    move v0, v1

    :goto_a
    const v3, 0xfffff

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->k:Ldma;

    if-eqz v0, :cond_1e

    and-int/2addr p1, v3

    int-to-long v0, p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1, p3}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object p0

    invoke-virtual {p2, p0, v2}, Landroidx/glance/appwidget/protobuf/d;->r(Lcl9;Z)V

    return-void

    :cond_1e
    and-int/2addr p1, v3

    int-to-long v2, p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v3, p3}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object p0

    invoke-virtual {p2, p0, v1}, Landroidx/glance/appwidget/protobuf/d;->r(Lcl9;Z)V

    return-void
.end method

.method public final G(ILjava/lang/Object;)V
    .registers 7

    add-int/lit8 p1, p1, 0x2

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget p0, p0, p1

    const p1, 0xfffff

    and-int/2addr p1, p0

    int-to-long v0, p1

    const-wide/32 v2, 0xfffff

    cmp-long p1, v0, v2

    if-nez p1, :cond_13

    return-void

    :cond_13
    ushr-int/lit8 p0, p0, 0x14

    const/4 p1, 0x1

    shl-int p0, p1, p0

    sget-object p1, Li5j;->c:Ld5j;

    invoke-virtual {p1, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p1

    or-int/2addr p0, p1

    invoke-static {p0, v0, v1, p2}, Li5j;->m(IJLjava/lang/Object;)V

    return-void
.end method

.method public final H(ILjava/lang/Object;I)V
    .registers 6

    add-int/lit8 p3, p3, 0x2

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget p0, p0, p3

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v0, p0

    invoke-static {p1, v0, v1, p2}, Li5j;->m(IJLjava/lang/Object;)V

    return-void
.end method

.method public final I(Ljava/lang/Object;ILandroidx/glance/appwidget/protobuf/a;)V
    .registers 7

    sget-object v0, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {v0, p1, v1, v2, p3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {p0, p2, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    return-void
.end method

.method public final J(Ljava/lang/Object;IILandroidx/glance/appwidget/protobuf/a;)V
    .registers 8

    sget-object v0, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p3}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {v0, p1, v1, v2, p4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {p0, p2, p1, p3}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    return-void
.end method

.method public final L(I)I
    .registers 2

    add-int/lit8 p1, p1, 0x1

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget p0, p0, p1

    return p0
.end method

.method public final M(Ljava/lang/Object;Lfgk;)V
    .registers 23

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v6, p2

    iget-object v7, v0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    array-length v8, v7

    sget-object v9, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    const v10, 0xfffff

    move v3, v10

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_11
    if-ge v2, v8, :cond_5e8

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v5

    aget v12, v7, v2

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v13

    const/16 v14, 0x11

    const/4 v15, 0x1

    if-gt v13, v14, :cond_3f

    add-int/lit8 v14, v2, 0x2

    aget v14, v7, v14

    and-int v11, v14, v10

    if-eq v11, v3, :cond_35

    if-ne v11, v10, :cond_2e

    const/4 v4, 0x0

    goto :goto_34

    :cond_2e
    int-to-long v3, v11

    invoke-virtual {v9, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    move v4, v3

    :goto_34
    move v3, v11

    :cond_35
    ushr-int/lit8 v11, v14, 0x14

    shl-int v11, v15, v11

    move/from16 v19, v11

    move v11, v5

    move/from16 v5, v19

    goto :goto_41

    :cond_3f
    move v11, v5

    const/4 v5, 0x0

    :goto_41
    and-int/2addr v11, v10

    int-to-long v10, v11

    const/16 v16, 0x3f

    packed-switch v13, :pswitch_data_5f8

    :cond_48
    :goto_48
    const/4 v13, 0x0

    goto/16 :goto_5e1

    :pswitch_4b  #0x44
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    invoke-virtual {v6, v12, v5, v10}, Lfgk;->A(ILjava/lang/Object;Lzxf;)V

    goto :goto_48

    :pswitch_5d  #0x43
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    shl-long v17, v10, v15

    shr-long v10, v10, v16

    xor-long v10, v17, v10

    invoke-virtual {v5, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    goto :goto_48

    :pswitch_75  #0x42
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    shl-int/lit8 v11, v5, 0x1

    shr-int/lit8 v5, v5, 0x1f

    xor-int/2addr v5, v11

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->z(II)V

    goto :goto_48

    :pswitch_8c  #0x41
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    goto :goto_48

    :pswitch_9e  #0x40
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    goto :goto_48

    :pswitch_b0  #0x3f
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->t(II)V

    goto :goto_48

    :pswitch_c2  #0x3e
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->z(II)V

    goto/16 :goto_48

    :pswitch_d5  #0x3d
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lg92;

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->o(ILg92;)V

    goto/16 :goto_48

    :pswitch_ea  #0x3c
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    iget-object v11, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v11, Landroidx/glance/appwidget/protobuf/e;

    check-cast v5, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v11, v12, v5, v10}, Landroidx/glance/appwidget/protobuf/e;->w(ILandroidx/glance/appwidget/protobuf/a;Lzxf;)V

    goto/16 :goto_48

    :pswitch_103  #0x3b
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    instance-of v10, v5, Ljava/lang/String;

    if-eqz v10, :cond_11c

    check-cast v5, Ljava/lang/String;

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->x(ILjava/lang/String;)V

    goto/16 :goto_48

    :cond_11c
    check-cast v5, Lg92;

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->o(ILg92;)V

    goto/16 :goto_48

    :pswitch_127  #0x3a
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v10, v11, v1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->n(IZ)V

    goto/16 :goto_48

    :pswitch_142  #0x39
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    goto/16 :goto_48

    :pswitch_155  #0x38
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    goto/16 :goto_48

    :pswitch_168  #0x37
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->t(II)V

    goto/16 :goto_48

    :pswitch_17b  #0x36
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    goto/16 :goto_48

    :pswitch_18e  #0x35
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    invoke-static {v10, v11, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    goto/16 :goto_48

    :pswitch_1a1  #0x34
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v10, v11, v1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Float;

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    iget-object v10, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v10, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v5

    invoke-virtual {v10, v12, v5}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    goto/16 :goto_48

    :pswitch_1c3  #0x33
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_48

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v10, v11, v1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Double;

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v10

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v11}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v10

    invoke-virtual {v5, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    goto/16 :goto_48

    :pswitch_1e5  #0x32
    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    if-nez v5, :cond_1ed

    goto/16 :goto_48

    :cond_1ed
    div-int/lit8 v2, v2, 0x3

    mul-int/lit8 v2, v2, 0x2

    iget-object v1, v0, Landroidx/glance/appwidget/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v1, v1, v2

    iget-object v0, v0, Landroidx/glance/appwidget/protobuf/h;->m:Lv5b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1}, Lb40;->x(Ljava/lang/Object;)V

    const/4 v0, 0x0

    throw v0

    :pswitch_1ff  #0x31
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v11

    sget-object v12, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v10, :cond_48

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_48

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    :goto_219
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v13

    if-ge v12, v13, :cond_48

    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v6, v5, v13, v11}, Lfgk;->A(ILjava/lang/Object;Lzxf;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_219

    :pswitch_229  #0x30
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->x(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_236  #0x2f
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->w(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_243  #0x2e
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->v(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_250  #0x2d
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->u(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_25d  #0x2c
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->o(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_26a  #0x2b
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->y(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_277  #0x2a
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->m(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_284  #0x29
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->p(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_291  #0x28
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->q(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_29e  #0x27
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->s(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_2ab  #0x26
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->z(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_2b8  #0x25
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->t(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_2c5  #0x24
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->r(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_2d2  #0x23
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v15}, Landroidx/glance/appwidget/protobuf/j;->n(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_48

    :pswitch_2df  #0x22
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    const/4 v12, 0x0

    invoke-static {v5, v10, v6, v12}, Landroidx/glance/appwidget/protobuf/j;->x(ILjava/util/List;Lfgk;Z)V

    :goto_2eb
    move v13, v12

    goto/16 :goto_5e1

    :pswitch_2ee  #0x21
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/glance/appwidget/protobuf/j;->w(ILjava/util/List;Lfgk;Z)V

    goto :goto_2eb

    :pswitch_2fb  #0x20
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/glance/appwidget/protobuf/j;->v(ILjava/util/List;Lfgk;Z)V

    goto :goto_2eb

    :pswitch_308  #0x1f
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/glance/appwidget/protobuf/j;->u(ILjava/util/List;Lfgk;Z)V

    goto :goto_2eb

    :pswitch_315  #0x1e
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/glance/appwidget/protobuf/j;->o(ILjava/util/List;Lfgk;Z)V

    goto :goto_2eb

    :pswitch_322  #0x1d
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/glance/appwidget/protobuf/j;->y(ILjava/util/List;Lfgk;Z)V

    goto :goto_2eb

    :pswitch_32f  #0x1c
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    sget-object v11, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v10, :cond_48

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_48

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    :goto_345
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v11

    if-ge v12, v11, :cond_48

    iget-object v11, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v11, Landroidx/glance/appwidget/protobuf/e;

    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lg92;

    invoke-virtual {v11, v5, v13}, Landroidx/glance/appwidget/protobuf/e;->o(ILg92;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_345

    :pswitch_35b  #0x1b
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v11

    sget-object v12, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v10, :cond_48

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_48

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    :goto_375
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v13

    if-ge v12, v13, :cond_48

    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    iget-object v15, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v15, Landroidx/glance/appwidget/protobuf/e;

    check-cast v13, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v15, v5, v13, v11}, Landroidx/glance/appwidget/protobuf/e;->w(ILandroidx/glance/appwidget/protobuf/a;Lzxf;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_375

    :pswitch_38b  #0x1a
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    sget-object v11, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    if-eqz v10, :cond_48

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_48

    iget-object v11, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v11, Landroidx/glance/appwidget/protobuf/e;

    instance-of v12, v10, Lkea;

    if-eqz v12, :cond_3c5

    move-object v12, v10

    check-cast v12, Lkea;

    const/4 v13, 0x0

    :goto_3a9
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v15

    if-ge v13, v15, :cond_48

    invoke-interface {v12}, Lkea;->f()Ljava/lang/Object;

    move-result-object v15

    instance-of v14, v15, Ljava/lang/String;

    if-eqz v14, :cond_3bd

    check-cast v15, Ljava/lang/String;

    invoke-virtual {v11, v5, v15}, Landroidx/glance/appwidget/protobuf/e;->x(ILjava/lang/String;)V

    goto :goto_3c2

    :cond_3bd
    check-cast v15, Lg92;

    invoke-virtual {v11, v5, v15}, Landroidx/glance/appwidget/protobuf/e;->o(ILg92;)V

    :goto_3c2
    add-int/lit8 v13, v13, 0x1

    goto :goto_3a9

    :cond_3c5
    const/4 v12, 0x0

    :goto_3c6
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v13

    if-ge v12, v13, :cond_48

    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-virtual {v11, v5, v13}, Landroidx/glance/appwidget/protobuf/e;->x(ILjava/lang/String;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_3c6

    :pswitch_3d8  #0x19
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    const/4 v13, 0x0

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->m(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_3e6  #0x18
    const/4 v13, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->p(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_3f4  #0x17
    const/4 v13, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->q(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_402  #0x16
    const/4 v13, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->s(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_410  #0x15
    const/4 v13, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->z(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_41e  #0x14
    const/4 v13, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->t(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_42c  #0x13
    const/4 v13, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->r(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_43a  #0x12
    const/4 v13, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v13}, Landroidx/glance/appwidget/protobuf/j;->n(ILjava/util/List;Lfgk;Z)V

    goto/16 :goto_5e1

    :pswitch_448  #0x11
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5e1

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    invoke-virtual {v6, v12, v5, v10}, Lfgk;->A(ILjava/lang/Object;Lzxf;)V

    goto/16 :goto_5e1

    :pswitch_45c  #0x10
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v0, Landroidx/glance/appwidget/protobuf/e;

    shl-long v14, v10, v15

    shr-long v10, v10, v16

    xor-long/2addr v10, v14

    invoke-virtual {v0, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    :cond_473
    :goto_473
    move-object/from16 v0, p0

    goto/16 :goto_5e1

    :pswitch_477  #0xf
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    shl-int/lit8 v10, v0, 0x1

    shr-int/lit8 v0, v0, 0x1f

    xor-int/2addr v0, v10

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->z(II)V

    goto :goto_473

    :pswitch_48f  #0xe
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v0, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    goto :goto_473

    :pswitch_4a2  #0xd
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    goto :goto_473

    :pswitch_4b5  #0xc
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->t(II)V

    goto :goto_473

    :pswitch_4c8  #0xb
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->z(II)V

    goto :goto_473

    :pswitch_4db  #0xa
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lg92;

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->o(ILg92;)V

    goto :goto_473

    :pswitch_4f0  #0x9
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5e1

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    iget-object v11, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v11, Landroidx/glance/appwidget/protobuf/e;

    check-cast v5, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v11, v12, v5, v10}, Landroidx/glance/appwidget/protobuf/e;->w(ILandroidx/glance/appwidget/protobuf/a;Lzxf;)V

    goto/16 :goto_5e1

    :pswitch_50a  #0x8
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    instance-of v5, v0, Ljava/lang/String;

    if-eqz v5, :cond_524

    check-cast v0, Ljava/lang/String;

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->x(ILjava/lang/String;)V

    goto/16 :goto_473

    :cond_524
    check-cast v0, Lg92;

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->o(ILg92;)V

    goto/16 :goto_473

    :pswitch_52f  #0x7
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    sget-object v0, Li5j;->c:Ld5j;

    invoke-virtual {v0, v10, v11, v1}, Ld5j;->c(JLjava/lang/Object;)Z

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->n(IZ)V

    goto/16 :goto_473

    :pswitch_545  #0x6
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    goto/16 :goto_473

    :pswitch_559  #0x5
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v0, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    goto/16 :goto_473

    :pswitch_56d  #0x4
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->t(II)V

    goto/16 :goto_473

    :pswitch_581  #0x3
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v0, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    goto/16 :goto_473

    :pswitch_595  #0x2
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v0, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->B(IJ)V

    goto/16 :goto_473

    :pswitch_5a9  #0x1
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_473

    sget-object v0, Li5j;->c:Ld5j;

    invoke-virtual {v0, v10, v11, v1}, Ld5j;->e(JLjava/lang/Object;)F

    move-result v0

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    invoke-virtual {v5, v12, v0}, Landroidx/glance/appwidget/protobuf/e;->p(II)V

    goto/16 :goto_473

    :pswitch_5c6  #0x0
    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5e1

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v10, v11, v1}, Ld5j;->d(JLjava/lang/Object;)D

    move-result-wide v10

    iget-object v5, v6, Lfgk;->F:Ljava/lang/Object;

    check-cast v5, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v11}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v10

    invoke-virtual {v5, v12, v10, v11}, Landroidx/glance/appwidget/protobuf/e;->r(IJ)V

    :cond_5e1
    :goto_5e1
    add-int/lit8 v2, v2, 0x3

    const v10, 0xfffff

    goto/16 :goto_11

    :cond_5e8
    iget-object v0, v0, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    check-cast v0, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, v1

    check-cast v0, Landroidx/glance/appwidget/protobuf/f;

    iget-object v0, v0, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    invoke-virtual {v0, v6}, Landroidx/glance/appwidget/protobuf/l;->d(Lfgk;)V

    return-void

    :pswitch_data_5f8
    .packed-switch 0x0
        :pswitch_5c6  #00000000
        :pswitch_5a9  #00000001
        :pswitch_595  #00000002
        :pswitch_581  #00000003
        :pswitch_56d  #00000004
        :pswitch_559  #00000005
        :pswitch_545  #00000006
        :pswitch_52f  #00000007
        :pswitch_50a  #00000008
        :pswitch_4f0  #00000009
        :pswitch_4db  #0000000a
        :pswitch_4c8  #0000000b
        :pswitch_4b5  #0000000c
        :pswitch_4a2  #0000000d
        :pswitch_48f  #0000000e
        :pswitch_477  #0000000f
        :pswitch_45c  #00000010
        :pswitch_448  #00000011
        :pswitch_43a  #00000012
        :pswitch_42c  #00000013
        :pswitch_41e  #00000014
        :pswitch_410  #00000015
        :pswitch_402  #00000016
        :pswitch_3f4  #00000017
        :pswitch_3e6  #00000018
        :pswitch_3d8  #00000019
        :pswitch_38b  #0000001a
        :pswitch_35b  #0000001b
        :pswitch_32f  #0000001c
        :pswitch_322  #0000001d
        :pswitch_315  #0000001e
        :pswitch_308  #0000001f
        :pswitch_2fb  #00000020
        :pswitch_2ee  #00000021
        :pswitch_2df  #00000022
        :pswitch_2d2  #00000023
        :pswitch_2c5  #00000024
        :pswitch_2b8  #00000025
        :pswitch_2ab  #00000026
        :pswitch_29e  #00000027
        :pswitch_291  #00000028
        :pswitch_284  #00000029
        :pswitch_277  #0000002a
        :pswitch_26a  #0000002b
        :pswitch_25d  #0000002c
        :pswitch_250  #0000002d
        :pswitch_243  #0000002e
        :pswitch_236  #0000002f
        :pswitch_229  #00000030
        :pswitch_1ff  #00000031
        :pswitch_1e5  #00000032
        :pswitch_1c3  #00000033
        :pswitch_1a1  #00000034
        :pswitch_18e  #00000035
        :pswitch_17b  #00000036
        :pswitch_168  #00000037
        :pswitch_155  #00000038
        :pswitch_142  #00000039
        :pswitch_127  #0000003a
        :pswitch_103  #0000003b
        :pswitch_ea  #0000003c
        :pswitch_d5  #0000003d
        :pswitch_c2  #0000003e
        :pswitch_b0  #0000003f
        :pswitch_9e  #00000040
        :pswitch_8c  #00000041
        :pswitch_75  #00000042
        :pswitch_5d  #00000043
        :pswitch_4b  #00000044
    .end packed-switch
.end method

.method public final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 13

    invoke-static {p1}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1f7

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    :goto_a
    iget-object v1, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    array-length v2, v1

    if-ge v0, v2, :cond_1f0

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v2

    const v3, 0xfffff

    and-int/2addr v3, v2

    int-to-long v6, v3

    aget v1, v1, v0

    invoke-static {v2}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v2

    packed-switch v2, :pswitch_data_202

    goto :goto_25

    :pswitch_22  #0x44
    invoke-virtual {p0, p1, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->t(Ljava/lang/Object;ILjava/lang/Object;)V

    :cond_25
    :goto_25
    move-object v5, p1

    goto/16 :goto_1eb

    :pswitch_28  #0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43
    invoke-virtual {p0, v1, p2, v0}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v2

    if-eqz v2, :cond_25

    sget-object v2, Li5j;->c:Ld5j;

    invoke-virtual {v2, v6, v7, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v6, v7, p1, v2}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v1, p1, v0}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_25

    :pswitch_3b  #0x3c
    invoke-virtual {p0, p1, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->t(Ljava/lang/Object;ILjava/lang/Object;)V

    goto :goto_25

    :pswitch_3f  #0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b
    invoke-virtual {p0, v1, p2, v0}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v2

    if-eqz v2, :cond_25

    sget-object v2, Li5j;->c:Ld5j;

    invoke-virtual {v2, v6, v7, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v6, v7, p1, v2}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v1, p1, v0}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_25

    :pswitch_52  #0x32
    sget-object v1, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/h;->m:Lv5b;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v1}, Lv5b;->a(Ljava/lang/Object;Ljava/lang/Object;)Lq5b;

    move-result-object v1

    invoke-static {v6, v7, p1, v1}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    goto :goto_25

    :pswitch_6b  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    iget-object v1, p0, Landroidx/glance/appwidget/protobuf/h;->k:Ldma;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcl9;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcl9;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v4

    if-lez v3, :cond_9b

    if-lez v4, :cond_9b

    move-object v5, v2

    check-cast v5, Lo3;

    iget-boolean v5, v5, Lo3;->E:Z

    if-nez v5, :cond_98

    add-int/2addr v4, v3

    check-cast v2, Lrfe;

    invoke-virtual {v2, v4}, Lrfe;->c(I)Lrfe;

    move-result-object v2

    :cond_98
    invoke-interface {v2, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_9b
    if-lez v3, :cond_9e

    move-object v1, v2

    :cond_9e
    invoke-static {v6, v7, p1, v1}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    goto :goto_25

    :pswitch_a2  #0x11
    invoke-virtual {p0, p1, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->s(Ljava/lang/Object;ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_a7  #0x10
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_bb  #0xf
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_cf  #0xe
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_e3  #0xd
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_f7  #0xc
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_10b  #0xb
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_11f  #0xa
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v6, v7, p1, v1}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_133  #0x9
    invoke-virtual {p0, p1, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->s(Ljava/lang/Object;ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_138  #0x8
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v6, v7, p1, v1}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_14c  #0x7
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->c(JLjava/lang/Object;)Z

    move-result v2

    invoke-virtual {v1, p1, v6, v7, v2}, Ld5j;->j(Ljava/lang/Object;JZ)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_160  #0x6
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_174  #0x5
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_188  #0x4
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v1

    invoke-static {v1, v6, v7, p1}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_19c  #0x3
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_1b0  #0x2
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v1

    invoke-static {p1, v6, v7, v1, v2}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_1c4  #0x1
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v1, Li5j;->c:Ld5j;

    invoke-virtual {v1, v6, v7, p2}, Ld5j;->e(JLjava/lang/Object;)F

    move-result v2

    invoke-virtual {v1, p1, v6, v7, v2}, Ld5j;->m(Ljava/lang/Object;JF)V

    invoke-virtual {p0, v0, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_25

    :pswitch_1d8  #0x0
    invoke-virtual {p0, v0, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_25

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p2}, Ld5j;->d(JLjava/lang/Object;)D

    move-result-wide v8

    move-object v5, p1

    invoke-virtual/range {v4 .. v9}, Ld5j;->l(Ljava/lang/Object;JD)V

    invoke-virtual {p0, v0, v5}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    :goto_1eb
    add-int/lit8 v0, v0, 0x3

    move-object p1, v5

    goto/16 :goto_a

    :cond_1f0
    move-object v5, p1

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    invoke-static {p0, v5, p2}, Landroidx/glance/appwidget/protobuf/j;->k(Landroidx/glance/appwidget/protobuf/k;Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_1f7
    move-object v5, p1

    const-string p0, "Mutating immutable message: "

    invoke-static {p0, v5}, Lb40;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    return-void

    :pswitch_data_202
    .packed-switch 0x0
        :pswitch_1d8  #00000000
        :pswitch_1c4  #00000001
        :pswitch_1b0  #00000002
        :pswitch_19c  #00000003
        :pswitch_188  #00000004
        :pswitch_174  #00000005
        :pswitch_160  #00000006
        :pswitch_14c  #00000007
        :pswitch_138  #00000008
        :pswitch_133  #00000009
        :pswitch_11f  #0000000a
        :pswitch_10b  #0000000b
        :pswitch_f7  #0000000c
        :pswitch_e3  #0000000d
        :pswitch_cf  #0000000e
        :pswitch_bb  #0000000f
        :pswitch_a7  #00000010
        :pswitch_a2  #00000011
        :pswitch_6b  #00000012
        :pswitch_6b  #00000013
        :pswitch_6b  #00000014
        :pswitch_6b  #00000015
        :pswitch_6b  #00000016
        :pswitch_6b  #00000017
        :pswitch_6b  #00000018
        :pswitch_6b  #00000019
        :pswitch_6b  #0000001a
        :pswitch_6b  #0000001b
        :pswitch_6b  #0000001c
        :pswitch_6b  #0000001d
        :pswitch_6b  #0000001e
        :pswitch_6b  #0000001f
        :pswitch_6b  #00000020
        :pswitch_6b  #00000021
        :pswitch_6b  #00000022
        :pswitch_6b  #00000023
        :pswitch_6b  #00000024
        :pswitch_6b  #00000025
        :pswitch_6b  #00000026
        :pswitch_6b  #00000027
        :pswitch_6b  #00000028
        :pswitch_6b  #00000029
        :pswitch_6b  #0000002a
        :pswitch_6b  #0000002b
        :pswitch_6b  #0000002c
        :pswitch_6b  #0000002d
        :pswitch_6b  #0000002e
        :pswitch_6b  #0000002f
        :pswitch_6b  #00000030
        :pswitch_6b  #00000031
        :pswitch_52  #00000032
        :pswitch_3f  #00000033
        :pswitch_3f  #00000034
        :pswitch_3f  #00000035
        :pswitch_3f  #00000036
        :pswitch_3f  #00000037
        :pswitch_3f  #00000038
        :pswitch_3f  #00000039
        :pswitch_3f  #0000003a
        :pswitch_3f  #0000003b
        :pswitch_3b  #0000003c
        :pswitch_28  #0000003d
        :pswitch_28  #0000003e
        :pswitch_28  #0000003f
        :pswitch_28  #00000040
        :pswitch_28  #00000041
        :pswitch_28  #00000042
        :pswitch_28  #00000043
        :pswitch_22  #00000044
    .end packed-switch
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 11

    invoke-static {p1}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto/16 :goto_a7

    :cond_8
    instance-of v0, p1, Landroidx/glance/appwidget/protobuf/f;

    const/4 v1, 0x0

    if-eqz v0, :cond_1b

    move-object v0, p1

    check-cast v0, Landroidx/glance/appwidget/protobuf/f;

    const v2, 0x7fffffff

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/f;->j(I)V

    iput v1, v0, Landroidx/glance/appwidget/protobuf/a;->memoizedHashCode:I

    invoke-virtual {v0}, Landroidx/glance/appwidget/protobuf/f;->g()V

    :cond_1b
    iget-object v0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    array-length v2, v0

    move v3, v1

    :goto_1f
    if-ge v3, v2, :cond_96

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v4

    const v5, 0xfffff

    and-int/2addr v5, v4

    int-to-long v5, v5

    invoke-static {v4}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v4

    const/16 v7, 0x9

    if-eq v4, v7, :cond_80

    const/16 v7, 0x3c

    if-eq v4, v7, :cond_6a

    const/16 v7, 0x44

    if-eq v4, v7, :cond_6a

    packed-switch v4, :pswitch_data_a8

    goto :goto_93

    :pswitch_3e  #0x32
    sget-object v4, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v4, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_93

    iget-object v8, p0, Landroidx/glance/appwidget/protobuf/h;->m:Lv5b;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v8, v7

    check-cast v8, Lq5b;

    iput-boolean v1, v8, Lq5b;->E:Z

    invoke-virtual {v4, p1, v5, v6, v7}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_93

    :pswitch_54  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    iget-object v4, p0, Landroidx/glance/appwidget/protobuf/h;->k:Ldma;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v5, v6, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcl9;

    check-cast v4, Lo3;

    iget-boolean v5, v4, Lo3;->E:Z

    if-eqz v5, :cond_93

    iput-boolean v1, v4, Lo3;->E:Z

    goto :goto_93

    :cond_6a
    aget v4, v0, v3

    invoke-virtual {p0, v4, p1, v3}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_93

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v4

    sget-object v7, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v4, v5}, Lzxf;->b(Ljava/lang/Object;)V

    goto :goto_93

    :cond_80
    :pswitch_80  #0x11
    invoke-virtual {p0, v3, p1}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_93

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v4

    sget-object v7, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v4, v5}, Lzxf;->b(Ljava/lang/Object;)V

    :cond_93
    :goto_93
    add-int/lit8 v3, v3, 0x3

    goto :goto_1f

    :cond_96
    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    check-cast p0, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/glance/appwidget/protobuf/f;

    iget-object p0, p1, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    iget-boolean p1, p0, Landroidx/glance/appwidget/protobuf/l;->e:Z

    if-eqz p1, :cond_a7

    iput-boolean v1, p0, Landroidx/glance/appwidget/protobuf/l;->e:Z

    :cond_a7
    :goto_a7
    return-void

    :pswitch_data_a8
    .packed-switch 0x11
        :pswitch_80  #00000011
        :pswitch_54  #00000012
        :pswitch_54  #00000013
        :pswitch_54  #00000014
        :pswitch_54  #00000015
        :pswitch_54  #00000016
        :pswitch_54  #00000017
        :pswitch_54  #00000018
        :pswitch_54  #00000019
        :pswitch_54  #0000001a
        :pswitch_54  #0000001b
        :pswitch_54  #0000001c
        :pswitch_54  #0000001d
        :pswitch_54  #0000001e
        :pswitch_54  #0000001f
        :pswitch_54  #00000020
        :pswitch_54  #00000021
        :pswitch_54  #00000022
        :pswitch_54  #00000023
        :pswitch_54  #00000024
        :pswitch_54  #00000025
        :pswitch_54  #00000026
        :pswitch_54  #00000027
        :pswitch_54  #00000028
        :pswitch_54  #00000029
        :pswitch_54  #0000002a
        :pswitch_54  #0000002b
        :pswitch_54  #0000002c
        :pswitch_54  #0000002d
        :pswitch_54  #0000002e
        :pswitch_54  #0000002f
        :pswitch_54  #00000030
        :pswitch_54  #00000031
        :pswitch_3e  #00000032
    .end packed-switch
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const v6, 0xfffff

    const/4 v7, 0x0

    move v2, v6

    move v3, v7

    move v8, v3

    :goto_b
    iget v4, v0, Landroidx/glance/appwidget/protobuf/h;->h:I

    const/4 v5, 0x1

    if-ge v8, v4, :cond_f1

    iget-object v4, v0, Landroidx/glance/appwidget/protobuf/h;->g:[I

    aget v4, v4, v8

    iget-object v9, v0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget v10, v9, v4

    invoke-virtual {v0, v4}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v11

    add-int/lit8 v12, v4, 0x2

    aget v9, v9, v12

    and-int v12, v9, v6

    ushr-int/lit8 v9, v9, 0x14

    shl-int/2addr v5, v9

    if-eq v12, v2, :cond_34

    if-eq v12, v6, :cond_30

    sget-object v2, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    int-to-long v13, v12

    invoke-virtual {v2, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    :cond_30
    move v2, v4

    move v4, v3

    move v3, v12

    goto :goto_38

    :cond_34
    move v15, v3

    move v3, v2

    move v2, v4

    move v4, v15

    :goto_38
    const/high16 v9, 0x10000000

    and-int/2addr v9, v11

    if-eqz v9, :cond_45

    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v9

    if-nez v9, :cond_45

    goto/16 :goto_ea

    :cond_45
    invoke-static {v11}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v9

    const/16 v12, 0x9

    if-eq v9, v12, :cond_d1

    const/16 v12, 0x11

    if-eq v9, v12, :cond_d1

    const/16 v5, 0x1b

    if-eq v9, v5, :cond_a6

    const/16 v5, 0x3c

    if-eq v9, v5, :cond_8c

    const/16 v5, 0x44

    if-eq v9, v5, :cond_8c

    const/16 v5, 0x31

    if-eq v9, v5, :cond_a6

    const/16 v5, 0x32

    if-eq v9, v5, :cond_67

    goto/16 :goto_eb

    :cond_67
    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v9, v10, v1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    iget-object v9, v0, Landroidx/glance/appwidget/protobuf/h;->m:Lv5b;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, Lq5b;

    invoke-virtual {v5}, Ljava/util/HashMap;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_7f

    goto/16 :goto_eb

    :cond_7f
    div-int/lit8 v4, v2, 0x3

    mul-int/lit8 v4, v4, 0x2

    iget-object v0, v0, Landroidx/glance/appwidget/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v0, v0, v4

    invoke-static {v0}, Lb40;->x(Ljava/lang/Object;)V

    const/4 v0, 0x0

    throw v0

    :cond_8c
    invoke-virtual {v0, v10, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_eb

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v2

    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v9, v10, v1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Lzxf;->c(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_eb

    goto :goto_ea

    :cond_a6
    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v9, v10, v1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_b8

    goto :goto_eb

    :cond_b8
    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v2

    move v9, v7

    :goto_bd
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-ge v9, v10, :cond_eb

    invoke-interface {v5, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-interface {v2, v10}, Lzxf;->c(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_ce

    goto :goto_ea

    :cond_ce
    add-int/lit8 v9, v9, 0x1

    goto :goto_bd

    :cond_d1
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_eb

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v2

    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v9, v10, v1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Lzxf;->c(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_eb

    :goto_ea
    return v7

    :cond_eb
    :goto_eb
    add-int/lit8 v8, v8, 0x1

    move v2, v3

    move v3, v4

    goto/16 :goto_b

    :cond_f1
    return v5
.end method

.method public final d()Landroidx/glance/appwidget/protobuf/f;
    .registers 2

    iget-object v0, p0, Landroidx/glance/appwidget/protobuf/h;->j:Lwjc;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->e:Landroidx/glance/appwidget/protobuf/a;

    check-cast p0, Landroidx/glance/appwidget/protobuf/f;

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/f;->h()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p0

    return-object p0
.end method

.method public final e(Landroidx/glance/appwidget/protobuf/f;)I
    .registers 19

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    sget-object v6, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    const/4 v7, 0x0

    const v8, 0xfffff

    move v2, v7

    move v4, v2

    move v9, v4

    move v3, v8

    :goto_e
    iget-object v5, v0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    array-length v10, v5

    if-ge v2, v10, :cond_6b9

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v10

    invoke-static {v10}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v11

    aget v12, v5, v2

    add-int/lit8 v13, v2, 0x2

    aget v5, v5, v13

    and-int v13, v5, v8

    const/16 v14, 0x11

    const/4 v15, 0x1

    if-gt v11, v14, :cond_3a

    if-eq v13, v3, :cond_35

    if-ne v13, v8, :cond_2e

    move v4, v7

    goto :goto_34

    :cond_2e
    int-to-long v3, v13

    invoke-virtual {v6, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    move v4, v3

    :goto_34
    move v3, v13

    :cond_35
    ushr-int/lit8 v5, v5, 0x14

    shl-int v5, v15, v5

    goto :goto_3b

    :cond_3a
    move v5, v7

    :goto_3b
    and-int/2addr v10, v8

    int-to-long v13, v10

    sget-object v10, Lmr7;->F:Lmr7;

    iget v10, v10, Lmr7;->E:I

    if-lt v11, v10, :cond_47

    sget-object v10, Lmr7;->G:Lmr7;

    iget v10, v10, Lmr7;->E:I

    :cond_47
    const/16 v10, 0x3f

    packed-switch v11, :pswitch_data_6c8

    goto/16 :goto_6b5

    :pswitch_4e  #0x44
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    mul-int/lit8 v11, v11, 0x2

    invoke-virtual {v5, v10}, Landroidx/glance/appwidget/protobuf/a;->a(Lzxf;)I

    move-result v5

    :goto_68
    add-int/2addr v5, v11

    :goto_69
    add-int/2addr v9, v5

    goto/16 :goto_6b5

    :pswitch_6c  #0x43
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v13, v14, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v13

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    shl-long v11, v13, v15

    shr-long/2addr v13, v10

    xor-long v10, v11, v13

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v10

    :goto_83
    add-int/2addr v10, v5

    :goto_84
    add-int/2addr v9, v10

    goto/16 :goto_6b5

    :pswitch_87  #0x42
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v13, v14, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    shl-int/lit8 v11, v5, 0x1

    shr-int/lit8 v5, v5, 0x1f

    xor-int/2addr v5, v11

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v5

    :goto_9e
    add-int/2addr v5, v10

    goto :goto_69

    :pswitch_a0  #0x41
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    :goto_aa
    add-int/lit8 v5, v5, 0x8

    goto :goto_69

    :pswitch_ad  #0x40
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    :goto_b7
    add-int/lit8 v5, v5, 0x4

    goto :goto_69

    :pswitch_ba  #0x3f
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v13, v14, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    int-to-long v11, v5

    invoke-static {v11, v12}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v5

    goto :goto_9e

    :pswitch_ce  #0x3e
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v13, v14, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v5

    goto :goto_9e

    :pswitch_e1  #0x3d
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lg92;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/e;->f(ILg92;)I

    move-result v5

    goto/16 :goto_69

    :pswitch_f3  #0x3c
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    sget-object v11, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    check-cast v5, Landroidx/glance/appwidget/protobuf/a;

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    invoke-virtual {v5, v10}, Landroidx/glance/appwidget/protobuf/a;->a(Lzxf;)I

    move-result v5

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v10

    :goto_111
    add-int/2addr v10, v5

    add-int/2addr v10, v11

    goto/16 :goto_84

    :pswitch_115  #0x3b
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    instance-of v10, v5, Lg92;

    if-eqz v10, :cond_12d

    check-cast v5, Lg92;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/e;->f(ILg92;)I

    move-result v5

    :goto_129
    add-int/2addr v5, v9

    move v9, v5

    goto/16 :goto_6b5

    :cond_12d
    check-cast v5, Ljava/lang/String;

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->g(Ljava/lang/String;)I

    move-result v5

    add-int/2addr v5, v10

    goto :goto_129

    :pswitch_139  #0x3a
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    add-int/2addr v5, v15

    goto/16 :goto_69

    :pswitch_146  #0x39
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_b7

    :pswitch_152  #0x38
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_aa

    :pswitch_15e  #0x37
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v13, v14, v1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    int-to-long v11, v5

    invoke-static {v11, v12}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v5

    goto/16 :goto_9e

    :pswitch_173  #0x36
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v13, v14, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v10

    goto/16 :goto_83

    :pswitch_187  #0x35
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v13, v14, v1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v10

    goto/16 :goto_83

    :pswitch_19b  #0x34
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_b7

    :pswitch_1a7  #0x33
    invoke-virtual {v0, v12, v1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_aa

    :pswitch_1b3  #0x32
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    div-int/lit8 v10, v2, 0x3

    mul-int/lit8 v10, v10, 0x2

    iget-object v11, v0, Landroidx/glance/appwidget/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v10, v11, v10

    iget-object v11, v0, Landroidx/glance/appwidget/protobuf/h;->m:Lv5b;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, Lq5b;

    if-nez v10, :cond_1ee

    invoke-virtual {v5}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_1d0

    goto/16 :goto_6b5

    :cond_1d0
    invoke-virtual {v5}, Lq5b;->entrySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-nez v10, :cond_1e0

    goto/16 :goto_6b5

    :cond_1e0
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    const/4 v0, 0x0

    throw v0

    :cond_1ee
    invoke-static {}, Lty9;->a()V

    return v7

    :pswitch_1f2  #0x31
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    sget-object v11, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    if-nez v11, :cond_206

    move v14, v7

    goto :goto_220

    :cond_206
    move v13, v7

    move v14, v13

    :goto_208
    if-ge v13, v11, :cond_220

    invoke-interface {v5, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Landroidx/glance/appwidget/protobuf/a;

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v16

    mul-int/lit8 v16, v16, 0x2

    invoke-virtual {v15, v10}, Landroidx/glance/appwidget/protobuf/a;->a(Lzxf;)I

    move-result v15

    add-int v15, v15, v16

    add-int/2addr v14, v15

    add-int/lit8 v13, v13, 0x1

    goto :goto_208

    :cond_220
    :goto_220
    add-int/2addr v9, v14

    goto/16 :goto_6b5

    :pswitch_223  #0x30
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->g(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    :goto_237
    add-int/2addr v11, v10

    add-int/2addr v11, v5

    add-int/2addr v9, v11

    goto/16 :goto_6b5

    :pswitch_23c  #0x2f
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->f(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto :goto_237

    :pswitch_251  #0x2e
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto :goto_237

    :pswitch_26a  #0x2d
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto :goto_237

    :pswitch_283  #0x2c
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->a(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto :goto_237

    :pswitch_298  #0x2b
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->h(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto :goto_237

    :pswitch_2ad  #0x2a
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_2c5  #0x29
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_2df  #0x28
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_2f9  #0x27
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->d(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_30f  #0x26
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->i(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_325  #0x25
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->e(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_33b  #0x24
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_355  #0x23
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v11

    goto/16 :goto_237

    :pswitch_36f  #0x22
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_37f

    :goto_37d
    move v11, v7

    goto :goto_389

    :cond_37f
    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->g(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    :goto_387
    mul-int/2addr v11, v10

    add-int/2addr v11, v5

    :cond_389
    :goto_389
    add-int/2addr v9, v11

    goto/16 :goto_6b5

    :pswitch_38c  #0x21
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_39b

    goto :goto_37d

    :cond_39b
    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->f(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    goto :goto_387

    :pswitch_3a4  #0x20
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/j;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_69

    :pswitch_3b0  #0x1f
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/j;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_69

    :pswitch_3bc  #0x1e
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_3cb

    goto :goto_37d

    :cond_3cb
    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->a(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    goto :goto_387

    :pswitch_3d4  #0x1d
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_3e3

    goto :goto_37d

    :cond_3e3
    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->h(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    goto :goto_387

    :pswitch_3ec  #0x1c
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_3fb

    goto :goto_37d

    :cond_3fb
    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    mul-int/2addr v11, v10

    move v10, v7

    :goto_401
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v12

    if-ge v10, v12, :cond_389

    invoke-interface {v5, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lg92;

    invoke-virtual {v12}, Lg92;->size()I

    move-result v12

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v13

    add-int/2addr v13, v12

    add-int/2addr v11, v13

    add-int/lit8 v10, v10, 0x1

    goto :goto_401

    :pswitch_41a  #0x1b
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    sget-object v11, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    if-nez v11, :cond_42e

    move v12, v7

    goto :goto_449

    :cond_42e
    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v12

    mul-int/2addr v12, v11

    move v13, v7

    :goto_434
    if-ge v13, v11, :cond_449

    invoke-interface {v5, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v14, v10}, Landroidx/glance/appwidget/protobuf/a;->a(Lzxf;)I

    move-result v14

    invoke-static {v14}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v15

    add-int/2addr v15, v14

    add-int/2addr v12, v15

    add-int/lit8 v13, v13, 0x1

    goto :goto_434

    :cond_449
    :goto_449
    add-int/2addr v9, v12

    goto/16 :goto_6b5

    :pswitch_44c  #0x1a
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_45c

    goto/16 :goto_37d

    :cond_45c
    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    mul-int/2addr v11, v10

    instance-of v12, v5, Lkea;

    if-eqz v12, :cond_48b

    check-cast v5, Lkea;

    move v12, v7

    :goto_468
    if-ge v12, v10, :cond_389

    invoke-interface {v5}, Lkea;->f()Ljava/lang/Object;

    move-result-object v13

    instance-of v14, v13, Lg92;

    if-eqz v14, :cond_480

    check-cast v13, Lg92;

    invoke-virtual {v13}, Lg92;->size()I

    move-result v13

    invoke-static {v13}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v14

    add-int/2addr v14, v13

    add-int/2addr v14, v11

    move v11, v14

    goto :goto_488

    :cond_480
    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Landroidx/glance/appwidget/protobuf/e;->g(Ljava/lang/String;)I

    move-result v13

    add-int/2addr v13, v11

    move v11, v13

    :goto_488
    add-int/lit8 v12, v12, 0x1

    goto :goto_468

    :cond_48b
    move v12, v7

    :goto_48c
    if-ge v12, v10, :cond_389

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    instance-of v14, v13, Lg92;

    if-eqz v14, :cond_4a4

    check-cast v13, Lg92;

    invoke-virtual {v13}, Lg92;->size()I

    move-result v13

    invoke-static {v13}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v14

    add-int/2addr v14, v13

    add-int/2addr v14, v11

    move v11, v14

    goto :goto_4ac

    :cond_4a4
    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Landroidx/glance/appwidget/protobuf/e;->g(Ljava/lang/String;)I

    move-result v13

    add-int/2addr v13, v11

    move v11, v13

    :goto_4ac
    add-int/lit8 v12, v12, 0x1

    goto :goto_48c

    :pswitch_4af  #0x19
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-nez v5, :cond_4bf

    move v10, v7

    goto :goto_4c5

    :cond_4bf
    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v10

    add-int/2addr v10, v15

    mul-int/2addr v10, v5

    :goto_4c5
    add-int/2addr v9, v10

    goto/16 :goto_6b5

    :pswitch_4c8  #0x18
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/j;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_69

    :pswitch_4d4  #0x17
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/j;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_69

    :pswitch_4e0  #0x16
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_4f0

    goto/16 :goto_37d

    :cond_4f0
    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->d(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    goto/16 :goto_387

    :pswitch_4fa  #0x15
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_50a

    goto/16 :goto_37d

    :cond_50a
    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->i(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    goto/16 :goto_387

    :pswitch_514  #0x14
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v10, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_524

    goto/16 :goto_37d

    :cond_524
    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/j;->e(Ljava/util/List;)I

    move-result v10

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    mul-int/2addr v11, v5

    add-int/2addr v11, v10

    goto/16 :goto_389

    :pswitch_534  #0x13
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/j;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_69

    :pswitch_540  #0x12
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/glance/appwidget/protobuf/j;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_69

    :pswitch_54c  #0x11
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    mul-int/lit8 v11, v11, 0x2

    invoke-virtual {v5, v10}, Landroidx/glance/appwidget/protobuf/a;->a(Lzxf;)I

    move-result v5

    goto/16 :goto_68

    :pswitch_568  #0x10
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v13

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    shl-long v11, v13, v15

    shr-long/2addr v13, v10

    xor-long v10, v11, v13

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v5

    :goto_57f
    add-int/2addr v5, v0

    add-int/2addr v9, v5

    :cond_581
    :goto_581
    move-object/from16 v0, p0

    goto/16 :goto_6b5

    :pswitch_585  #0xf
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    shl-int/lit8 v10, v0, 0x1

    shr-int/lit8 v0, v0, 0x1f

    xor-int/2addr v0, v10

    invoke-static {v0}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v0

    :goto_59c
    add-int/2addr v0, v5

    :goto_59d
    add-int/2addr v9, v0

    goto :goto_581

    :pswitch_59f  #0xe
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5ac

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    :goto_5a9
    add-int/lit8 v0, v0, 0x8

    :goto_5ab
    add-int/2addr v9, v0

    :cond_5ac
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    goto/16 :goto_6b5

    :pswitch_5b2  #0xd
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5ac

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    :goto_5bc
    add-int/lit8 v0, v0, 0x4

    goto :goto_5ab

    :pswitch_5bf  #0xc
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    int-to-long v10, v0

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v0

    goto :goto_59c

    :pswitch_5d3  #0xb
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v0}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v0

    goto :goto_59c

    :pswitch_5e6  #0xa
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lg92;

    invoke-static {v12, v0}, Landroidx/glance/appwidget/protobuf/e;->f(ILg92;)I

    move-result v0

    goto :goto_59d

    :pswitch_5f7  #0x9
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v10

    sget-object v11, Landroidx/glance/appwidget/protobuf/j;->a:Ljava/lang/Class;

    check-cast v5, Landroidx/glance/appwidget/protobuf/a;

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v11

    invoke-virtual {v5, v10}, Landroidx/glance/appwidget/protobuf/a;->a(Lzxf;)I

    move-result v5

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v10

    goto/16 :goto_111

    :pswitch_617  #0x8
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    instance-of v5, v0, Lg92;

    if-eqz v5, :cond_62f

    check-cast v0, Lg92;

    invoke-static {v12, v0}, Landroidx/glance/appwidget/protobuf/e;->f(ILg92;)I

    move-result v0

    :goto_62b
    add-int/2addr v0, v9

    move v9, v0

    goto/16 :goto_581

    :cond_62f
    check-cast v0, Ljava/lang/String;

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    invoke-static {v0}, Landroidx/glance/appwidget/protobuf/e;->g(Ljava/lang/String;)I

    move-result v0

    add-int/2addr v0, v5

    goto :goto_62b

    :pswitch_63b  #0x7
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5ac

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    add-int/2addr v0, v15

    goto/16 :goto_5ab

    :pswitch_648  #0x6
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5ac

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    goto/16 :goto_5bc

    :pswitch_654  #0x5
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5ac

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    goto/16 :goto_5a9

    :pswitch_660  #0x4
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    int-to-long v10, v0

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v0

    goto/16 :goto_59c

    :pswitch_675  #0x3
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v5

    goto/16 :goto_57f

    :pswitch_689  #0x2
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_581

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    invoke-static {v10, v11}, Landroidx/glance/appwidget/protobuf/e;->j(J)I

    move-result v5

    goto/16 :goto_57f

    :pswitch_69d  #0x1
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_5ac

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v0

    goto/16 :goto_5bc

    :pswitch_6a9  #0x0
    invoke-virtual/range {v0 .. v5}, Landroidx/glance/appwidget/protobuf/h;->o(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6b5

    invoke-static {v12}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result v5

    goto/16 :goto_aa

    :cond_6b5
    :goto_6b5
    add-int/lit8 v2, v2, 0x3

    goto/16 :goto_e

    :cond_6b9
    iget-object v0, v0, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    check-cast v0, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v1, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    invoke-virtual {v0}, Landroidx/glance/appwidget/protobuf/l;->b()I

    move-result v0

    add-int/2addr v0, v9

    return v0

    :pswitch_data_6c8
    .packed-switch 0x0
        :pswitch_6a9  #00000000
        :pswitch_69d  #00000001
        :pswitch_689  #00000002
        :pswitch_675  #00000003
        :pswitch_660  #00000004
        :pswitch_654  #00000005
        :pswitch_648  #00000006
        :pswitch_63b  #00000007
        :pswitch_617  #00000008
        :pswitch_5f7  #00000009
        :pswitch_5e6  #0000000a
        :pswitch_5d3  #0000000b
        :pswitch_5bf  #0000000c
        :pswitch_5b2  #0000000d
        :pswitch_59f  #0000000e
        :pswitch_585  #0000000f
        :pswitch_568  #00000010
        :pswitch_54c  #00000011
        :pswitch_540  #00000012
        :pswitch_534  #00000013
        :pswitch_514  #00000014
        :pswitch_4fa  #00000015
        :pswitch_4e0  #00000016
        :pswitch_4d4  #00000017
        :pswitch_4c8  #00000018
        :pswitch_4af  #00000019
        :pswitch_44c  #0000001a
        :pswitch_41a  #0000001b
        :pswitch_3ec  #0000001c
        :pswitch_3d4  #0000001d
        :pswitch_3bc  #0000001e
        :pswitch_3b0  #0000001f
        :pswitch_3a4  #00000020
        :pswitch_38c  #00000021
        :pswitch_36f  #00000022
        :pswitch_355  #00000023
        :pswitch_33b  #00000024
        :pswitch_325  #00000025
        :pswitch_30f  #00000026
        :pswitch_2f9  #00000027
        :pswitch_2df  #00000028
        :pswitch_2c5  #00000029
        :pswitch_2ad  #0000002a
        :pswitch_298  #0000002b
        :pswitch_283  #0000002c
        :pswitch_26a  #0000002d
        :pswitch_251  #0000002e
        :pswitch_23c  #0000002f
        :pswitch_223  #00000030
        :pswitch_1f2  #00000031
        :pswitch_1b3  #00000032
        :pswitch_1a7  #00000033
        :pswitch_19b  #00000034
        :pswitch_187  #00000035
        :pswitch_173  #00000036
        :pswitch_15e  #00000037
        :pswitch_152  #00000038
        :pswitch_146  #00000039
        :pswitch_139  #0000003a
        :pswitch_115  #0000003b
        :pswitch_f3  #0000003c
        :pswitch_e1  #0000003d
        :pswitch_ce  #0000003e
        :pswitch_ba  #0000003f
        :pswitch_ad  #00000040
        :pswitch_a0  #00000041
        :pswitch_87  #00000042
        :pswitch_6c  #00000043
        :pswitch_4e  #00000044
    .end packed-switch
.end method

.method public final f(Ljava/lang/Object;Landroidx/glance/appwidget/protobuf/d;Lfm7;)V
    .registers 24

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v4, p2

    move-object/from16 v6, p3

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_714

    iget-object v8, v1, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    iget-object v9, v1, Landroidx/glance/appwidget/protobuf/h;->g:[I

    iget v10, v1, Landroidx/glance/appwidget/protobuf/h;->i:I

    iget v11, v1, Landroidx/glance/appwidget/protobuf/h;->h:I

    const/4 v13, 0x0

    :goto_1a
    :try_start_1a
    invoke-virtual {v4}, Landroidx/glance/appwidget/protobuf/d;->a()I

    move-result v0

    invoke-virtual {v1, v0}, Landroidx/glance/appwidget/protobuf/h;->A(I)I

    move-result v7
    :try_end_22
    .catchall {:try_start_1a .. :try_end_22} :catchall_4d

    const/4 v14, 0x0

    if-gez v7, :cond_67

    const v3, 0x7fffffff

    if-ne v0, v3, :cond_42

    :goto_2a
    if-ge v11, v10, :cond_34

    aget v0, v9, v11

    invoke-virtual {v1, v2, v0, v13}, Landroidx/glance/appwidget/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_2a

    :cond_34
    if-eqz v13, :cond_6f2

    check-cast v8, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_3b
    move-object v0, v2

    check-cast v0, Landroidx/glance/appwidget/protobuf/f;

    iput-object v13, v0, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    goto/16 :goto_6f2

    :cond_42
    :try_start_42
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v13, :cond_53

    invoke-virtual {v8, v2}, Landroidx/glance/appwidget/protobuf/k;->a(Ljava/lang/Object;)Landroidx/glance/appwidget/protobuf/l;

    move-result-object v0

    move-object v13, v0

    goto :goto_53

    :catchall_4d
    move-exception v0

    move-object v6, v1

    move/from16 v19, v11

    goto/16 :goto_6fb

    :cond_53
    :goto_53
    invoke-virtual {v8, v14, v4, v13}, Landroidx/glance/appwidget/protobuf/k;->b(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)Z

    move-result v0
    :try_end_57
    .catchall {:try_start_42 .. :try_end_57} :catchall_4d

    if-eqz v0, :cond_5a

    goto :goto_1a

    :cond_5a
    :goto_5a
    if-ge v11, v10, :cond_64

    aget v0, v9, v11

    invoke-virtual {v1, v2, v0, v13}, Landroidx/glance/appwidget/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_5a

    :cond_64
    if-eqz v13, :cond_6f2

    :goto_66
    goto :goto_3b

    :cond_67
    :try_start_67
    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v3
    :try_end_6b
    .catchall {:try_start_67 .. :try_end_6b} :catchall_4d

    :try_start_6b
    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v5
    :try_end_6f
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_6b .. :try_end_6f} :catch_6ca
    .catchall {:try_start_6b .. :try_end_6f} :catchall_4d

    const/16 v16, 0x0

    const/4 v12, 0x3

    iget-object v15, v1, Landroidx/glance/appwidget/protobuf/h;->k:Ldma;

    packed-switch v5, :pswitch_data_71e

    if-nez v13, :cond_85

    :try_start_79
    invoke-virtual {v8, v2}, Landroidx/glance/appwidget/protobuf/k;->a(Ljava/lang/Object;)Landroidx/glance/appwidget/protobuf/l;

    move-result-object v0

    move-object v13, v0

    goto :goto_85

    :catch_7f
    move-object v6, v1

    move/from16 v19, v11

    :goto_82
    move-object v11, v4

    goto/16 :goto_6d1

    :cond_85
    :goto_85
    invoke-virtual {v8, v14, v4, v13}, Landroidx/glance/appwidget/protobuf/k;->b(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)Z

    move-result v0
    :try_end_89
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_79 .. :try_end_89} :catch_7f
    .catchall {:try_start_79 .. :try_end_89} :catchall_4d

    if-nez v0, :cond_ab

    :goto_8b
    if-ge v11, v10, :cond_95

    aget v0, v9, v11

    invoke-virtual {v1, v2, v0, v13}, Landroidx/glance/appwidget/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_8b

    :cond_95
    if-eqz v13, :cond_6f2

    goto :goto_66

    :pswitch_98  #0x44
    :try_start_98
    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->v(ILjava/lang/Object;I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v5

    invoke-virtual {v4, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    invoke-virtual {v4, v3, v5, v6}, Landroidx/glance/appwidget/protobuf/d;->b(Ljava/lang/Object;Lzxf;Lfm7;)V

    invoke-virtual {v1, v2, v0, v7, v3}, Landroidx/glance/appwidget/protobuf/h;->J(Ljava/lang/Object;IILandroidx/glance/appwidget/protobuf/a;)V
    :try_end_ab
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_98 .. :try_end_ab} :catch_7f
    .catchall {:try_start_98 .. :try_end_ab} :catchall_4d

    :cond_ab
    move-object v6, v1

    move/from16 v19, v11

    :goto_ae
    move-object v11, v4

    goto/16 :goto_6f3

    :pswitch_b1  #0x43
    move/from16 v19, v11

    :try_start_b3
    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->z()J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    :goto_ca
    move-object v6, v1

    goto :goto_ae

    :catchall_cc
    move-exception v0

    move-object v6, v1

    goto/16 :goto_6fb

    :catch_d0
    :goto_d0
    move-object v6, v1

    goto :goto_82

    :pswitch_d2  #0x42
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->y()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_ca

    :pswitch_ec  #0x41
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    const/4 v3, 0x1

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->x()J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_ca

    :pswitch_107  #0x40
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    const/4 v3, 0x5

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->w()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_ca

    :pswitch_122  #0x3f
    move/from16 v19, v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v5, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v5}, Lkl4;->q()I

    move-result v5

    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->l(I)V

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto :goto_ca

    :pswitch_13f  #0x3e
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->D()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_15a  #0x3d
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4}, Landroidx/glance/appwidget/protobuf/d;->e()Lg92;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_16c  #0x3c
    move/from16 v19, v11

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->v(ILjava/lang/Object;I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v5

    const/4 v11, 0x2

    invoke-virtual {v4, v11}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    invoke-virtual {v4, v3, v5, v6}, Landroidx/glance/appwidget/protobuf/d;->c(Ljava/lang/Object;Lzxf;Lfm7;)V

    invoke-virtual {v1, v2, v0, v7, v3}, Landroidx/glance/appwidget/protobuf/h;->J(Ljava/lang/Object;IILandroidx/glance/appwidget/protobuf/a;)V

    goto/16 :goto_ca

    :pswitch_184  #0x3b
    move/from16 v19, v11

    invoke-virtual {v1, v3, v4, v2}, Landroidx/glance/appwidget/protobuf/h;->D(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_18e  #0x3a
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->m()Z

    move-result v3

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_1a9  #0x39
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    const/4 v3, 0x5

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->r()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_1c5  #0x38
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    const/4 v3, 0x1

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->s()J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_1e1  #0x37
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->u()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_1fc  #0x36
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->E()J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_217  #0x35
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    invoke-virtual {v4, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->v()J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_232  #0x34
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    const/4 v3, 0x5

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->t()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_24e  #0x33
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v11

    const/4 v3, 0x1

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v3, v4, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v3}, Lkl4;->p()D

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    invoke-static {v11, v12, v2, v3}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2, v7}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    goto/16 :goto_ca

    :pswitch_26a  #0x32
    move/from16 v19, v11

    iget-object v0, v1, Landroidx/glance/appwidget/protobuf/h;->b:[Ljava/lang/Object;

    div-int/lit8 v3, v7, 0x3

    const/16 v17, 0x2

    mul-int/lit8 v3, v3, 0x2

    aget-object v0, v0, v3

    invoke-virtual {v1, v2, v7, v0}, Landroidx/glance/appwidget/protobuf/h;->r(Ljava/lang/Object;ILjava/lang/Object;)V

    throw v16
    :try_end_27a
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_b3 .. :try_end_27a} :catch_d0
    .catchall {:try_start_b3 .. :try_end_27a} :catchall_cc

    :pswitch_27a  #0x31
    move/from16 v19, v11

    :try_start_27c
    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v6
    :try_end_284
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_27c .. :try_end_284} :catch_292
    .catchall {:try_start_27c .. :try_end_284} :catchall_cc

    move-object/from16 v5, p2

    move-object/from16 v7, p3

    :try_start_288
    invoke-virtual/range {v1 .. v7}, Landroidx/glance/appwidget/protobuf/h;->B(Ljava/lang/Object;JLandroidx/glance/appwidget/protobuf/d;Lzxf;Lfm7;)V
    :try_end_28b
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_288 .. :try_end_28b} :catch_28e
    .catchall {:try_start_288 .. :try_end_28b} :catchall_cc

    move-object v4, v5

    goto/16 :goto_ca

    :catch_28e
    move-object v6, v1

    move-object v11, v5

    goto/16 :goto_6d1

    :catch_292
    move-object/from16 v11, p2

    :goto_294
    move-object v6, v1

    goto/16 :goto_6d1

    :pswitch_297  #0x30
    move/from16 v19, v11

    :try_start_299
    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->q(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_2a9  #0x2f
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->p(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_2bb  #0x2e
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->o(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_2cd  #0x2d
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->n(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_2df  #0x2c
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->h(Lcl9;)V

    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->l(I)V

    invoke-static {v2, v0, v3, v13, v8}, Landroidx/glance/appwidget/protobuf/j;->j(Ljava/lang/Object;ILcl9;Ljava/lang/Object;Landroidx/glance/appwidget/protobuf/k;)Ljava/lang/Object;

    goto/16 :goto_ca

    :pswitch_2f7  #0x2b
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->s(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_309  #0x2a
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->d(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_31b  #0x29
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->i(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_32d  #0x28
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->j(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_33f  #0x27
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->l(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_351  #0x26
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->t(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_363  #0x25
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->m(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_375  #0x24
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->k(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_387  #0x23
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->g(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_399  #0x22
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->q(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_3ab  #0x21
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->p(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_3bd  #0x20
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->o(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_3cf  #0x1f
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->n(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_3e1  #0x1e
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroidx/glance/appwidget/protobuf/d;->h(Lcl9;)V

    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->l(I)V

    invoke-static {v2, v0, v3, v13, v8}, Landroidx/glance/appwidget/protobuf/j;->j(Ljava/lang/Object;ILcl9;Ljava/lang/Object;Landroidx/glance/appwidget/protobuf/k;)Ljava/lang/Object;

    goto/16 :goto_ca

    :pswitch_3f9  #0x1d
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->s(Lcl9;)V

    goto/16 :goto_ca

    :pswitch_40b  #0x1c
    move/from16 v19, v11

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v5

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v6, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroidx/glance/appwidget/protobuf/d;->f(Lcl9;)V
    :try_end_41b
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_299 .. :try_end_41b} :catch_d0
    .catchall {:try_start_299 .. :try_end_41b} :catchall_cc

    goto/16 :goto_ca

    :pswitch_41d  #0x1b
    move/from16 v19, v11

    :try_start_41f
    invoke-virtual {v1, v7}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v5
    :try_end_423
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_41f .. :try_end_423} :catch_431
    .catchall {:try_start_41f .. :try_end_423} :catchall_cc

    move-object/from16 v6, p3

    :try_start_425
    invoke-virtual/range {v1 .. v6}, Landroidx/glance/appwidget/protobuf/h;->C(Ljava/lang/Object;ILandroidx/glance/appwidget/protobuf/d;Lzxf;Lfm7;)V
    :try_end_428
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_425 .. :try_end_428} :catch_42d
    .catchall {:try_start_425 .. :try_end_428} :catchall_cc

    move-object v11, v4

    move-object v0, v6

    move-object v6, v1

    goto/16 :goto_6f3

    :catch_42d
    move-object v11, v4

    move-object v0, v6

    goto/16 :goto_294

    :catch_431
    move-object/from16 v0, p3

    goto/16 :goto_d0

    :pswitch_435  #0x1a
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    :try_start_43a
    invoke-virtual {v6, v3, v11, v2}, Landroidx/glance/appwidget/protobuf/h;->E(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)V

    goto/16 :goto_6f3

    :catchall_43f
    move-exception v0

    goto/16 :goto_6fb

    :pswitch_442  #0x19
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->d(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_457  #0x18
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->i(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_46c  #0x17
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->j(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_481  #0x16
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->l(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_496  #0x15
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->t(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_4ab  #0x14
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->m(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_4c0  #0x13
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->k(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_4d5  #0x12
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4, v2}, Ldma;->a(JLjava/lang/Object;)Lcl9;

    move-result-object v1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->g(Lcl9;)V

    goto/16 :goto_6f3

    :pswitch_4ea  #0x11
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->u(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v6, v7}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v3

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    invoke-virtual {v11, v1, v3, v0}, Landroidx/glance/appwidget/protobuf/d;->b(Ljava/lang/Object;Lzxf;Lfm7;)V

    invoke-virtual {v6, v2, v7, v1}, Landroidx/glance/appwidget/protobuf/h;->I(Ljava/lang/Object;ILandroidx/glance/appwidget/protobuf/a;)V

    goto/16 :goto_6f3

    :pswitch_504  #0x10
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v11, v14}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->z()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_51e  #0xf
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->y()I

    move-result v1

    invoke-static {v1, v3, v4, v2}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_539  #0xe
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v1, 0x1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->x()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_554  #0xd
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v1, 0x5

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->w()I

    move-result v1

    invoke-static {v1, v3, v4, v2}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_56f  #0xc
    move-object v0, v6

    move/from16 v19, v11

    move v12, v14

    move-object v6, v1

    move-object v11, v4

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->q()I

    move-result v1

    invoke-virtual {v6, v7}, Landroidx/glance/appwidget/protobuf/h;->l(I)V

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-static {v1, v3, v4, v2}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_58d  #0xb
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->D()I

    move-result v1

    invoke-static {v1, v3, v4, v2}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_5a8  #0xa
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    invoke-virtual {v11}, Landroidx/glance/appwidget/protobuf/d;->e()Lg92;

    move-result-object v1

    invoke-static {v3, v4, v2, v1}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_5bd  #0x9
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->u(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/glance/appwidget/protobuf/a;

    invoke-virtual {v6, v7}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v3

    const/4 v4, 0x2

    invoke-virtual {v11, v4}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    invoke-virtual {v11, v1, v3, v0}, Landroidx/glance/appwidget/protobuf/d;->c(Ljava/lang/Object;Lzxf;Lfm7;)V

    invoke-virtual {v6, v2, v7, v1}, Landroidx/glance/appwidget/protobuf/h;->I(Ljava/lang/Object;ILandroidx/glance/appwidget/protobuf/a;)V

    goto/16 :goto_6f3

    :pswitch_5d8  #0x8
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-virtual {v6, v3, v11, v2}, Landroidx/glance/appwidget/protobuf/h;->D(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_5e5  #0x7
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->m()Z

    move-result v1

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v2, v3, v4, v1}, Ld5j;->j(Ljava/lang/Object;JZ)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_602  #0x6
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v1, 0x5

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->r()I

    move-result v1

    invoke-static {v1, v3, v4, v2}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_61d  #0x5
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v1, 0x1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->s()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_638  #0x4
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->u()I

    move-result v1

    invoke-static {v1, v3, v4, v2}, Li5j;->m(IJLjava/lang/Object;)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_653  #0x3
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->E()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_66e  #0x2
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->v()J

    move-result-wide v14

    invoke-static {v2, v3, v4, v14, v15}, Li5j;->n(Ljava/lang/Object;JJ)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto/16 :goto_6f3

    :pswitch_689  #0x1
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v1, 0x5

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->t()F

    move-result v1

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v2, v3, v4, v1}, Ld5j;->m(Ljava/lang/Object;JF)V

    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    goto :goto_6f3

    :pswitch_6a5  #0x0
    move-object v0, v6

    move/from16 v19, v11

    move-object v6, v1

    move-object v11, v4

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->x(I)J

    move-result-wide v3

    const/4 v1, 0x1

    invoke-virtual {v11, v1}, Landroidx/glance/appwidget/protobuf/d;->v(I)V

    iget-object v1, v11, Landroidx/glance/appwidget/protobuf/d;->a:Lkl4;

    invoke-virtual {v1}, Lkl4;->p()D

    move-result-wide v14

    sget-object v0, Li5j;->c:Ld5j;
    :try_end_6ba
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_43a .. :try_end_6ba} :catch_6d1
    .catchall {:try_start_43a .. :try_end_6ba} :catchall_43f

    move-object v1, v2

    move-wide v2, v3

    move-wide v4, v14

    :try_start_6bd
    invoke-virtual/range {v0 .. v5}, Ld5j;->l(Ljava/lang/Object;JD)V
    :try_end_6c0
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_6bd .. :try_end_6c0} :catch_6c8
    .catchall {:try_start_6bd .. :try_end_6c0} :catchall_6c5

    move-object v2, v1

    :try_start_6c1
    invoke-virtual {v6, v7, v2}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V
    :try_end_6c4
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_6c1 .. :try_end_6c4} :catch_6d1
    .catchall {:try_start_6c1 .. :try_end_6c4} :catchall_43f

    goto :goto_6f3

    :catchall_6c5
    move-exception v0

    move-object v2, v1

    goto :goto_6fb

    :catch_6c8
    move-object v2, v1

    goto :goto_6d1

    :catch_6ca
    move-object v6, v1

    move/from16 v19, v11

    const/16 v16, 0x0

    goto/16 :goto_82

    :catch_6d1
    :goto_6d1
    :try_start_6d1
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v13, :cond_6db

    invoke-virtual {v8, v2}, Landroidx/glance/appwidget/protobuf/k;->a(Ljava/lang/Object;)Landroidx/glance/appwidget/protobuf/l;

    move-result-object v0

    move-object v13, v0

    :cond_6db
    const/4 v12, 0x0

    invoke-virtual {v8, v12, v11, v13}, Landroidx/glance/appwidget/protobuf/k;->b(ILandroidx/glance/appwidget/protobuf/d;Ljava/lang/Object;)Z

    move-result v0
    :try_end_6e0
    .catchall {:try_start_6d1 .. :try_end_6e0} :catchall_43f

    if-nez v0, :cond_6f3

    move/from16 v11, v19

    :goto_6e4
    if-ge v11, v10, :cond_6ee

    aget v0, v9, v11

    invoke-virtual {v6, v2, v0, v13}, Landroidx/glance/appwidget/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_6e4

    :cond_6ee
    if-eqz v13, :cond_6f2

    goto/16 :goto_66

    :cond_6f2
    :goto_6f2
    return-void

    :cond_6f3
    :goto_6f3
    move-object v1, v6

    move-object v4, v11

    move/from16 v11, v19

    move-object/from16 v6, p3

    goto/16 :goto_1a

    :goto_6fb
    move/from16 v11, v19

    :goto_6fd
    if-ge v11, v10, :cond_707

    aget v1, v9, v11

    invoke-virtual {v6, v2, v1, v13}, Landroidx/glance/appwidget/protobuf/h;->k(Ljava/lang/Object;ILjava/lang/Object;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_6fd

    :cond_707
    if-eqz v13, :cond_713

    check-cast v8, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v1, v2

    check-cast v1, Landroidx/glance/appwidget/protobuf/f;

    iput-object v13, v1, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    :cond_713
    throw v0

    :cond_714
    const-string v0, "Mutating immutable message: "

    invoke-static {v0, v2}, Lb40;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le97;->p(Ljava/lang/String;)V

    return-void

    :pswitch_data_71e
    .packed-switch 0x0
        :pswitch_6a5  #00000000
        :pswitch_689  #00000001
        :pswitch_66e  #00000002
        :pswitch_653  #00000003
        :pswitch_638  #00000004
        :pswitch_61d  #00000005
        :pswitch_602  #00000006
        :pswitch_5e5  #00000007
        :pswitch_5d8  #00000008
        :pswitch_5bd  #00000009
        :pswitch_5a8  #0000000a
        :pswitch_58d  #0000000b
        :pswitch_56f  #0000000c
        :pswitch_554  #0000000d
        :pswitch_539  #0000000e
        :pswitch_51e  #0000000f
        :pswitch_504  #00000010
        :pswitch_4ea  #00000011
        :pswitch_4d5  #00000012
        :pswitch_4c0  #00000013
        :pswitch_4ab  #00000014
        :pswitch_496  #00000015
        :pswitch_481  #00000016
        :pswitch_46c  #00000017
        :pswitch_457  #00000018
        :pswitch_442  #00000019
        :pswitch_435  #0000001a
        :pswitch_41d  #0000001b
        :pswitch_40b  #0000001c
        :pswitch_3f9  #0000001d
        :pswitch_3e1  #0000001e
        :pswitch_3cf  #0000001f
        :pswitch_3bd  #00000020
        :pswitch_3ab  #00000021
        :pswitch_399  #00000022
        :pswitch_387  #00000023
        :pswitch_375  #00000024
        :pswitch_363  #00000025
        :pswitch_351  #00000026
        :pswitch_33f  #00000027
        :pswitch_32d  #00000028
        :pswitch_31b  #00000029
        :pswitch_309  #0000002a
        :pswitch_2f7  #0000002b
        :pswitch_2df  #0000002c
        :pswitch_2cd  #0000002d
        :pswitch_2bb  #0000002e
        :pswitch_2a9  #0000002f
        :pswitch_297  #00000030
        :pswitch_27a  #00000031
        :pswitch_26a  #00000032
        :pswitch_24e  #00000033
        :pswitch_232  #00000034
        :pswitch_217  #00000035
        :pswitch_1fc  #00000036
        :pswitch_1e1  #00000037
        :pswitch_1c5  #00000038
        :pswitch_1a9  #00000039
        :pswitch_18e  #0000003a
        :pswitch_184  #0000003b
        :pswitch_16c  #0000003c
        :pswitch_15a  #0000003d
        :pswitch_13f  #0000003e
        :pswitch_122  #0000003f
        :pswitch_107  #00000040
        :pswitch_ec  #00000041
        :pswitch_d2  #00000042
        :pswitch_b1  #00000043
        :pswitch_98  #00000044
    .end packed-switch
.end method

.method public final g(Landroidx/glance/appwidget/protobuf/f;)I
    .registers 13

    iget-object v0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_5
    if-ge v2, v1, :cond_27c

    invoke-virtual {p0, v2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v4

    aget v5, v0, v2

    const v6, 0xfffff

    and-int/2addr v6, v4

    int-to-long v6, v6

    invoke-static {v4}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v4

    const/16 v8, 0x4d5

    const/16 v9, 0x4cf

    const/16 v10, 0x25

    packed-switch v4, :pswitch_data_28e

    goto/16 :goto_278

    :pswitch_21  #0x44
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    mul-int/lit8 v3, v3, 0x35

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    :goto_33
    add-int/2addr v4, v3

    move v3, v4

    goto/16 :goto_278

    :pswitch_37  #0x43
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto :goto_33

    :pswitch_48  #0x42
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_55  #0x41
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto :goto_33

    :pswitch_66  #0x40
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_73  #0x3f
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_80  #0x3e
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_8d  #0x3d
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto :goto_33

    :pswitch_a0  #0x3c
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    mul-int/lit8 v3, v3, 0x35

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto :goto_33

    :pswitch_b3  #0x3b
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_c9  #0x3a
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    sget-object v5, Lgl9;->a:Ljava/nio/charset/Charset;

    if-eqz v4, :cond_e2

    :goto_e1
    move v8, v9

    :cond_e2
    add-int/2addr v8, v3

    move v3, v8

    goto/16 :goto_278

    :pswitch_e6  #0x39
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_f4  #0x38
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_106  #0x37
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->y(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_114  #0x36
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_126  #0x35
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/glance/appwidget/protobuf/h;->z(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_138  #0x34
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Float;

    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v4

    goto/16 :goto_33

    :pswitch_152  #0x33
    invoke-virtual {p0, v5, p1, v2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Double;

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_170  #0x32
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_17e  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_18c  #0x11
    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_198

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v10

    :cond_198
    :goto_198
    mul-int/lit8 v3, v3, 0x35

    add-int/2addr v3, v10

    goto/16 :goto_278

    :pswitch_19d  #0x10
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1ab  #0xf
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1b5  #0xe
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1c3  #0xd
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1cd  #0xc
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1d7  #0xb
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1e1  #0xa
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_1ef  #0x9
    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_198

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v10

    goto :goto_198

    :pswitch_1fc  #0x8
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_20c  #0x7
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->c(JLjava/lang/Object;)Z

    move-result v4

    sget-object v5, Lgl9;->a:Ljava/nio/charset/Charset;

    if-eqz v4, :cond_e2

    goto/16 :goto_e1

    :pswitch_21a  #0x6
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_224  #0x5
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_232  #0x4
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_23c  #0x3
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_24a  #0x2
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_258  #0x1
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->e(JLjava/lang/Object;)F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v4

    goto/16 :goto_33

    :pswitch_266  #0x0
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v6, v7, p1}, Ld5j;->d(JLjava/lang/Object;)D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    invoke-static {v4, v5}, Lgl9;->b(J)I

    move-result v4

    goto/16 :goto_33

    :cond_278
    :goto_278
    add-int/lit8 v2, v2, 0x3

    goto/16 :goto_5

    :cond_27c
    mul-int/lit8 v3, v3, 0x35

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    check-cast p0, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p1, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/l;->hashCode()I

    move-result p0

    add-int/2addr p0, v3

    return p0

    nop

    :pswitch_data_28e
    .packed-switch 0x0
        :pswitch_266  #00000000
        :pswitch_258  #00000001
        :pswitch_24a  #00000002
        :pswitch_23c  #00000003
        :pswitch_232  #00000004
        :pswitch_224  #00000005
        :pswitch_21a  #00000006
        :pswitch_20c  #00000007
        :pswitch_1fc  #00000008
        :pswitch_1ef  #00000009
        :pswitch_1e1  #0000000a
        :pswitch_1d7  #0000000b
        :pswitch_1cd  #0000000c
        :pswitch_1c3  #0000000d
        :pswitch_1b5  #0000000e
        :pswitch_1ab  #0000000f
        :pswitch_19d  #00000010
        :pswitch_18c  #00000011
        :pswitch_17e  #00000012
        :pswitch_17e  #00000013
        :pswitch_17e  #00000014
        :pswitch_17e  #00000015
        :pswitch_17e  #00000016
        :pswitch_17e  #00000017
        :pswitch_17e  #00000018
        :pswitch_17e  #00000019
        :pswitch_17e  #0000001a
        :pswitch_17e  #0000001b
        :pswitch_17e  #0000001c
        :pswitch_17e  #0000001d
        :pswitch_17e  #0000001e
        :pswitch_17e  #0000001f
        :pswitch_17e  #00000020
        :pswitch_17e  #00000021
        :pswitch_17e  #00000022
        :pswitch_17e  #00000023
        :pswitch_17e  #00000024
        :pswitch_17e  #00000025
        :pswitch_17e  #00000026
        :pswitch_17e  #00000027
        :pswitch_17e  #00000028
        :pswitch_17e  #00000029
        :pswitch_17e  #0000002a
        :pswitch_17e  #0000002b
        :pswitch_17e  #0000002c
        :pswitch_17e  #0000002d
        :pswitch_17e  #0000002e
        :pswitch_17e  #0000002f
        :pswitch_17e  #00000030
        :pswitch_17e  #00000031
        :pswitch_170  #00000032
        :pswitch_152  #00000033
        :pswitch_138  #00000034
        :pswitch_126  #00000035
        :pswitch_114  #00000036
        :pswitch_106  #00000037
        :pswitch_f4  #00000038
        :pswitch_e6  #00000039
        :pswitch_c9  #0000003a
        :pswitch_b3  #0000003b
        :pswitch_a0  #0000003c
        :pswitch_8d  #0000003d
        :pswitch_80  #0000003e
        :pswitch_73  #0000003f
        :pswitch_66  #00000040
        :pswitch_55  #00000041
        :pswitch_48  #00000042
        :pswitch_37  #00000043
        :pswitch_21  #00000044
    .end packed-switch
.end method

.method public final h(Ljava/lang/Object;Lfgk;)V
    .registers 3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1, p2}, Landroidx/glance/appwidget/protobuf/h;->M(Ljava/lang/Object;Lfgk;)V

    return-void
.end method

.method public final i(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;)Z
    .registers 14

    iget-object v0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_5
    const/4 v4, 0x1

    if-ge v3, v1, :cond_1f5

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v5

    const v6, 0xfffff

    and-int v7, v5, v6

    int-to-long v7, v7

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result v5

    packed-switch v5, :pswitch_data_20c

    goto/16 :goto_1ee

    :pswitch_1b  #0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43, 0x44
    add-int/lit8 v5, v3, 0x2

    aget v5, v0, v5

    and-int/2addr v5, v6

    int-to-long v5, v5

    sget-object v9, Li5j;->c:Ld5j;

    invoke-virtual {v9, v5, v6, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v10

    invoke-virtual {v9, v5, v6, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v10, v5, :cond_3d

    invoke-virtual {v9, v7, v8, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v9, v7, v8, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5, v6}, Landroidx/glance/appwidget/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :cond_3d
    move v4, v2

    goto/16 :goto_1ee

    :pswitch_40  #0x32
    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v7, v8, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v7, v8, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v5, v4}, Landroidx/glance/appwidget/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_1ee

    :pswitch_50  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    sget-object v4, Li5j;->c:Ld5j;

    invoke-virtual {v4, v7, v8, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v7, v8, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v5, v4}, Landroidx/glance/appwidget/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_1ee

    :pswitch_60  #0x11
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/glance/appwidget/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_78  #0x10
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_8e  #0xf
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_a2  #0xe
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_b8  #0xd
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_cc  #0xc
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_e0  #0xb
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_f4  #0xa
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/glance/appwidget/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_10c  #0x9
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/glance/appwidget/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_124  #0x8
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/glance/appwidget/protobuf/j;->l(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_13c  #0x7
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->c(JLjava/lang/Object;)Z

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->c(JLjava/lang/Object;)Z

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_150  #0x6
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_164  #0x5
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_17a  #0x4
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto :goto_1ee

    :pswitch_18d  #0x3
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto :goto_1ee

    :pswitch_1a2  #0x2
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto :goto_1ee

    :pswitch_1b7  #0x1
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->e(JLjava/lang/Object;)F

    move-result v6

    invoke-static {v6}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->e(JLjava/lang/Object;)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto :goto_1ee

    :pswitch_1d2  #0x0
    invoke-virtual {p0, p1, p2, v3}, Landroidx/glance/appwidget/protobuf/h;->j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Li5j;->c:Ld5j;

    invoke-virtual {v5, v7, v8, p1}, Ld5j;->d(JLjava/lang/Object;)D

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Ld5j;->d(JLjava/lang/Object;)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    :goto_1ee
    if-nez v4, :cond_1f1

    goto :goto_209

    :cond_1f1
    add-int/lit8 v3, v3, 0x3

    goto/16 :goto_5

    :cond_1f5
    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->l:Landroidx/glance/appwidget/protobuf/k;

    check-cast p0, Landroidx/glance/appwidget/protobuf/m;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p2, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    invoke-virtual {p1, p0}, Landroidx/glance/appwidget/protobuf/l;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_20a

    :goto_209
    return v2

    :cond_20a
    return v4

    nop

    :pswitch_data_20c
    .packed-switch 0x0
        :pswitch_1d2  #00000000
        :pswitch_1b7  #00000001
        :pswitch_1a2  #00000002
        :pswitch_18d  #00000003
        :pswitch_17a  #00000004
        :pswitch_164  #00000005
        :pswitch_150  #00000006
        :pswitch_13c  #00000007
        :pswitch_124  #00000008
        :pswitch_10c  #00000009
        :pswitch_f4  #0000000a
        :pswitch_e0  #0000000b
        :pswitch_cc  #0000000c
        :pswitch_b8  #0000000d
        :pswitch_a2  #0000000e
        :pswitch_8e  #0000000f
        :pswitch_78  #00000010
        :pswitch_60  #00000011
        :pswitch_50  #00000012
        :pswitch_50  #00000013
        :pswitch_50  #00000014
        :pswitch_50  #00000015
        :pswitch_50  #00000016
        :pswitch_50  #00000017
        :pswitch_50  #00000018
        :pswitch_50  #00000019
        :pswitch_50  #0000001a
        :pswitch_50  #0000001b
        :pswitch_50  #0000001c
        :pswitch_50  #0000001d
        :pswitch_50  #0000001e
        :pswitch_50  #0000001f
        :pswitch_50  #00000020
        :pswitch_50  #00000021
        :pswitch_50  #00000022
        :pswitch_50  #00000023
        :pswitch_50  #00000024
        :pswitch_50  #00000025
        :pswitch_50  #00000026
        :pswitch_50  #00000027
        :pswitch_50  #00000028
        :pswitch_50  #00000029
        :pswitch_50  #0000002a
        :pswitch_50  #0000002b
        :pswitch_50  #0000002c
        :pswitch_50  #0000002d
        :pswitch_50  #0000002e
        :pswitch_50  #0000002f
        :pswitch_50  #00000030
        :pswitch_50  #00000031
        :pswitch_40  #00000032
        :pswitch_1b  #00000033
        :pswitch_1b  #00000034
        :pswitch_1b  #00000035
        :pswitch_1b  #00000036
        :pswitch_1b  #00000037
        :pswitch_1b  #00000038
        :pswitch_1b  #00000039
        :pswitch_1b  #0000003a
        :pswitch_1b  #0000003b
        :pswitch_1b  #0000003c
        :pswitch_1b  #0000003d
        :pswitch_1b  #0000003e
        :pswitch_1b  #0000003f
        :pswitch_1b  #00000040
        :pswitch_1b  #00000041
        :pswitch_1b  #00000042
        :pswitch_1b  #00000043
        :pswitch_1b  #00000044
    .end packed-switch
.end method

.method public final j(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;I)Z
    .registers 4

    invoke-virtual {p0, p3, p1}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p1

    invoke-virtual {p0, p3, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p0

    if-ne p1, p0, :cond_c

    const/4 p0, 0x1

    return p0

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method public final k(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 6

    iget-object p3, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget p3, p3, p2

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result p3

    const v0, 0xfffff

    and-int/2addr p3, v0

    int-to-long v0, p3

    sget-object p3, Li5j;->c:Ld5j;

    invoke-virtual {p3, v0, v1, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-nez p1, :cond_16

    return-void

    :cond_16
    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->l(I)V

    return-void
.end method

.method public final l(I)V
    .registers 5

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1, v2, v0, v1}, Lti6;->e(IIII)I

    move-result p1

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->b:[Ljava/lang/Object;

    aget-object p0, p0, p1

    if-nez p0, :cond_e

    return-void

    :cond_e
    invoke-static {}, Lty9;->a()V

    return-void
.end method

.method public final m(I)Lzxf;
    .registers 4

    div-int/lit8 p1, p1, 0x3

    mul-int/lit8 p1, p1, 0x2

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->b:[Ljava/lang/Object;

    aget-object v0, p0, p1

    check-cast v0, Lzxf;

    if-eqz v0, :cond_d

    return-object v0

    :cond_d
    sget-object v0, Llfe;->c:Llfe;

    add-int/lit8 v1, p1, 0x1

    aget-object v1, p0, v1

    check-cast v1, Ljava/lang/Class;

    invoke-virtual {v0, v1}, Llfe;->a(Ljava/lang/Class;)Lzxf;

    move-result-object v0

    aput-object v0, p0, p1

    return-object v0
.end method

.method public final n(ILjava/lang/Object;)Z
    .registers 10

    add-int/lit8 v0, p1, 0x2

    iget-object v1, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget v0, v1, v0

    const v1, 0xfffff

    and-int v2, v0, v1

    int-to-long v2, v2

    const-wide/32 v4, 0xfffff

    cmp-long v4, v2, v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v4, :cond_103

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result p0

    and-int p1, p0, v1

    int-to-long v0, p1

    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/h;->K(I)I

    move-result p0

    const-wide/16 v2, 0x0

    packed-switch p0, :pswitch_data_112

    invoke-static {}, Lty9;->y()V

    return v5

    :pswitch_29  #0x11
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_33  #0x10
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_3f  #0xf
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_49  #0xe
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_55  #0xd
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_5f  #0xc
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_69  #0xb
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_73  #0xa
    sget-object p0, Lg92;->G:Lg92;

    sget-object p1, Li5j;->c:Ld5j;

    invoke-virtual {p1, v0, v1, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p0, p1}, Lg92;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :pswitch_81  #0x9
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_8b  #0x8
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_9d

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :cond_9d
    instance-of p1, p0, Lg92;

    if-eqz p1, :cond_a9

    sget-object p1, Lg92;->G:Lg92;

    invoke-virtual {p1, p0}, Lg92;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :cond_a9
    invoke-static {}, Lty9;->y()V

    return v5

    :pswitch_ad  #0x7
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->c(JLjava/lang/Object;)Z

    move-result p0

    return p0

    :pswitch_b4  #0x6
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_bd  #0x5
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_c8  #0x4
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_d1  #0x3
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_dc  #0x2
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->g(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_e7  #0x1
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->e(JLjava/lang/Object;)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_f4  #0x0
    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->d(JLjava/lang/Object;)D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :cond_103
    ushr-int/lit8 p0, v0, 0x14

    shl-int p0, v6, p0

    sget-object p1, Li5j;->c:Ld5j;

    invoke-virtual {p1, v2, v3, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p1

    and-int/2addr p0, p1

    if-eqz p0, :cond_111

    :goto_110
    return v6

    :cond_111
    return v5

    :pswitch_data_112
    .packed-switch 0x0
        :pswitch_f4  #00000000
        :pswitch_e7  #00000001
        :pswitch_dc  #00000002
        :pswitch_d1  #00000003
        :pswitch_c8  #00000004
        :pswitch_bd  #00000005
        :pswitch_b4  #00000006
        :pswitch_ad  #00000007
        :pswitch_8b  #00000008
        :pswitch_81  #00000009
        :pswitch_73  #0000000a
        :pswitch_69  #0000000b
        :pswitch_5f  #0000000c
        :pswitch_55  #0000000d
        :pswitch_49  #0000000e
        :pswitch_3f  #0000000f
        :pswitch_33  #00000010
        :pswitch_29  #00000011
    .end packed-switch
.end method

.method public final o(Ljava/lang/Object;IIII)Z
    .registers 7

    const v0, 0xfffff

    if-ne p3, v0, :cond_a

    invoke-virtual {p0, p2, p1}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p0

    return p0

    :cond_a
    and-int p0, p4, p5

    if-eqz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method public final q(ILjava/lang/Object;I)Z
    .registers 6

    add-int/lit8 p3, p3, 0x2

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget p0, p0, p3

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v0, p0

    sget-object p0, Li5j;->c:Ld5j;

    invoke-virtual {p0, v0, v1, p2}, Ld5j;->f(JLjava/lang/Object;)I

    move-result p0

    if-ne p0, p1, :cond_15

    const/4 p0, 0x1

    return p0

    :cond_15
    const/4 p0, 0x0

    return p0
.end method

.method public final r(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 7

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result p2

    const v0, 0xfffff

    and-int/2addr p2, v0

    int-to-long v0, p2

    sget-object p2, Li5j;->c:Ld5j;

    invoke-virtual {p2, v0, v1, p1}, Ld5j;->h(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->m:Lv5b;

    if-eqz p2, :cond_2b

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v2, p2

    check-cast v2, Lq5b;

    iget-boolean v2, v2, Lq5b;->E:Z

    if-nez v2, :cond_37

    sget-object v2, Lq5b;->F:Lq5b;

    invoke-virtual {v2}, Lq5b;->d()Lq5b;

    move-result-object v2

    invoke-static {v2, p2}, Lv5b;->a(Ljava/lang/Object;Ljava/lang/Object;)Lq5b;

    invoke-static {v0, v1, p1, v2}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    move-object p2, v2

    goto :goto_37

    :cond_2b
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Lq5b;->F:Lq5b;

    invoke-virtual {p2}, Lq5b;->d()Lq5b;

    move-result-object p2

    invoke-static {v0, v1, p1, p2}, Li5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    :cond_37
    :goto_37
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lq5b;

    invoke-static {p3}, Lb40;->x(Ljava/lang/Object;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final s(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 9

    invoke-virtual {p0, p2, p3}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v0

    const v1, 0xfffff

    and-int/2addr v0, v1

    int-to-long v0, v0

    sget-object v2, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v2, p3, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_53

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object p3

    invoke-virtual {p0, p2, p1}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3a

    invoke-static {v3}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2c

    invoke-virtual {v2, p1, v0, v1, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_36

    :cond_2c
    invoke-interface {p3}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object v4

    invoke-interface {p3, v4, v3}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v0, v1, v4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :goto_36
    invoke-virtual {p0, p2, p1}, Landroidx/glance/appwidget/protobuf/h;->G(ILjava/lang/Object;)V

    return-void

    :cond_3a
    invoke-virtual {v2, p1, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_4f

    invoke-interface {p3}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p2

    invoke-interface {p3, p2, p0}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v0, v1, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    move-object p0, p2

    :cond_4f
    invoke-interface {p3, p0, v3}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_53
    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget p0, p0, p2

    const-string p1, " is present but null: "

    const-string p2, "Source subfield "

    invoke-static {p0, p1, p3, p2}, Lm1f;->i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final t(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 10

    iget-object v0, p0, Landroidx/glance/appwidget/protobuf/h;->a:[I

    aget v1, v0, p2

    invoke-virtual {p0, v1, p3, p2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v2

    if-nez v2, :cond_b

    return-void

    :cond_b
    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v2

    const v3, 0xfffff

    and-int/2addr v2, v3

    int-to-long v2, v2

    sget-object v4, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {v4, p3, v2, v3}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    if-eqz v5, :cond_57

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object p3

    invoke-virtual {p0, v1, p1, p2}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result v0

    if-nez v0, :cond_3e

    invoke-static {v5}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_30

    invoke-virtual {v4, p1, v2, v3, v5}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_3a

    :cond_30
    invoke-interface {p3}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object v0

    invoke-interface {p3, v0, v5}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v4, p1, v2, v3, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :goto_3a
    invoke-virtual {p0, v1, p1, p2}, Landroidx/glance/appwidget/protobuf/h;->H(ILjava/lang/Object;I)V

    return-void

    :cond_3e
    invoke-virtual {v4, p1, v2, v3}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_53

    invoke-interface {p3}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p2

    invoke-interface {p3, p2, p0}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v4, p1, v2, v3, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    move-object p0, p2

    :cond_53
    invoke-interface {p3, p0, v5}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_57
    aget p0, v0, p2

    const-string p1, " is present but null: "

    const-string p2, "Source subfield "

    invoke-static {p0, p1, p3, p2}, Lm1f;->i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final u(ILjava/lang/Object;)Ljava/lang/Object;
    .registers 6

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v0

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {p0, p1, p2}, Landroidx/glance/appwidget/protobuf/h;->n(ILjava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_18

    invoke-interface {v0}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p0

    return-object p0

    :cond_18
    sget-object p0, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p2, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_25

    return-object p0

    :cond_25
    invoke-interface {v0}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p1

    if-eqz p0, :cond_2e

    invoke-interface {v0, p1, p0}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2e
    return-object p1
.end method

.method public final v(ILjava/lang/Object;I)Ljava/lang/Object;
    .registers 7

    invoke-virtual {p0, p3}, Landroidx/glance/appwidget/protobuf/h;->m(I)Lzxf;

    move-result-object v0

    invoke-virtual {p0, p1, p2, p3}, Landroidx/glance/appwidget/protobuf/h;->q(ILjava/lang/Object;I)Z

    move-result p1

    if-nez p1, :cond_f

    invoke-interface {v0}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p0

    return-object p0

    :cond_f
    sget-object p1, Landroidx/glance/appwidget/protobuf/h;->o:Lsun/misc/Unsafe;

    invoke-virtual {p0, p3}, Landroidx/glance/appwidget/protobuf/h;->L(I)I

    move-result p0

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v1, p0

    invoke-virtual {p1, p2, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/h;->p(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_25

    return-object p0

    :cond_25
    invoke-interface {v0}, Lzxf;->d()Landroidx/glance/appwidget/protobuf/f;

    move-result-object p1

    if-eqz p0, :cond_2e

    invoke-interface {v0, p1, p0}, Lzxf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2e
    return-object p1
.end method
