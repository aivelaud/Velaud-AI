.class public final Landroidx/glance/appwidget/protobuf/c;
.super Lkl4;
.source "SourceFile"


# instance fields
.field public final c:Ljava/io/FileInputStream;

.field public final d:[B

.field public e:I

.field public f:I

.field public g:I

.field public h:I

.field public i:I

.field public j:I


# direct methods
.method public constructor <init>(Ljava/io/FileInputStream;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const v0, 0x7fffffff

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    sget-object v0, Lgl9;->a:Ljava/nio/charset/Charset;

    iput-object p1, p0, Landroidx/glance/appwidget/protobuf/c;->c:Ljava/io/FileInputStream;

    const/16 p1, 0x1000

    new-array p1, p1, [B

    iput-object p1, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    const/4 p1, 0x0

    iput p1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iput p1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iput p1, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    return-void
.end method


# virtual methods
.method public final A()Ljava/lang/String;
    .registers 6

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result v0

    iget-object v1, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    if-lez v0, :cond_1c

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    sub-int/2addr v2, v3

    if-gt v0, v2, :cond_1c

    new-instance v2, Ljava/lang/String;

    sget-object v4, Lgl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v2, v1, v3, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int/2addr v1, v0

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    return-object v2

    :cond_1c
    if-nez v0, :cond_21

    const-string p0, ""

    return-object p0

    :cond_21
    if-ltz v0, :cond_45

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    if-gt v0, v2, :cond_39

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/c;->O(I)V

    new-instance v2, Ljava/lang/String;

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    sget-object v4, Lgl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v2, v1, v3, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int/2addr v1, v0

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    return-object v2

    :cond_39
    new-instance v1, Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/c;->F(I)[B

    move-result-object p0

    sget-object v0, Lgl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v1, p0, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    return-object v1

    :cond_45
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->d()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final B()Ljava/lang/String;
    .registers 6

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result v0

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int v3, v2, v1

    iget-object v4, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    if-gt v0, v3, :cond_15

    if-lez v0, :cond_15

    add-int v2, v1, v0

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    goto :goto_29

    :cond_15
    if-nez v0, :cond_1a

    const-string p0, ""

    return-object p0

    :cond_1a
    if-ltz v0, :cond_30

    const/4 v1, 0x0

    if-gt v0, v2, :cond_25

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/c;->O(I)V

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    goto :goto_29

    :cond_25
    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/c;->F(I)[B

    move-result-object v4

    :goto_29
    sget-object p0, Landroidx/glance/appwidget/protobuf/o;->a:Lral;

    invoke-virtual {p0, v4, v1, v0}, Lral;->e([BII)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_30
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->d()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final C()I
    .registers 2

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->g()Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 v0, 0x0

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->h:I

    return v0

    :cond_a
    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result v0

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->h:I

    ushr-int/lit8 p0, v0, 0x3

    if-eqz p0, :cond_15

    return v0

    :cond_15
    new-instance p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    const-string v0, "Protocol message contained an invalid tag (zero)."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final D()I
    .registers 1

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result p0

    return p0
.end method

.method public final E()J
    .registers 3

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->L()J

    move-result-wide v0

    return-wide v0
.end method

.method public final F(I)[B
    .registers 6

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/c;->G(I)[B

    move-result-object v0

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int v2, v1, v0

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v3, v1

    iput v3, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    const/4 v1, 0x0

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int v3, p1, v2

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/c;->H(I)Ljava/util/ArrayList;

    move-result-object v3

    new-array p1, p1, [B

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    invoke-static {p0, v0, p1, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_28
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    array-length v3, v0

    invoke-static {v0, v1, p1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    array-length v0, v0

    add-int/2addr v2, v0

    goto :goto_28

    :cond_3b
    return-object p1
.end method

.method public final G(I)[B
    .registers 9

    if-nez p1, :cond_5

    sget-object p0, Lgl9;->b:[B

    return-object p0

    :cond_5
    if-ltz p1, :cond_75

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int v2, v0, v1

    add-int/2addr v2, p1

    const v3, 0x7fffffff

    sub-int v3, v2, v3

    if-gtz v3, :cond_6d

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    if-gt v2, v3, :cond_63

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int/2addr v0, v1

    sub-int v1, p1, v0

    const/16 v2, 0x1000

    const/4 v3, 0x1

    iget-object v4, p0, Landroidx/glance/appwidget/protobuf/c;->c:Ljava/io/FileInputStream;

    if-lt v1, v2, :cond_32

    :try_start_25
    invoke-virtual {v4}, Ljava/io/InputStream;->available()I

    move-result v2
    :try_end_29
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException; {:try_start_25 .. :try_end_29} :catch_2e

    if-gt v1, v2, :cond_2c

    goto :goto_32

    :cond_2c
    const/4 p0, 0x0

    return-object p0

    :catch_2e
    move-exception p0

    iput-boolean v3, p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->E:Z

    throw p0

    :cond_32
    :goto_32
    new-array v1, p1, [B

    iget-object v2, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    iget v5, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    const/4 v6, 0x0

    invoke-static {v2, v5, v1, v6, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    iget v5, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    add-int/2addr v2, v5

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    iput v6, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iput v6, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    :goto_47
    if-ge v0, p1, :cond_62

    sub-int v2, p1, v0

    :try_start_4b
    invoke-virtual {v4, v1, v0, v2}, Ljava/io/InputStream;->read([BII)I

    move-result v2
    :try_end_4f
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException; {:try_start_4b .. :try_end_4f} :catch_5e

    const/4 v5, -0x1

    if-eq v2, v5, :cond_59

    iget v5, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v5, v2

    iput v5, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v0, v2

    goto :goto_47

    :cond_59
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->e()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :catch_5e
    move-exception p0

    iput-boolean v3, p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->E:Z

    throw p0

    :cond_62
    return-object v1

    :cond_63
    sub-int/2addr v3, v0

    sub-int/2addr v3, v1

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/c;->P(I)V

    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->e()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_6d
    new-instance p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    const-string p1, "Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_75
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->d()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final H(I)Ljava/util/ArrayList;
    .registers 8

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_5
    if-lez p1, :cond_2e

    const/16 v1, 0x1000

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    new-array v2, v1, [B

    const/4 v3, 0x0

    :goto_10
    if-ge v3, v1, :cond_29

    iget-object v4, p0, Landroidx/glance/appwidget/protobuf/c;->c:Ljava/io/FileInputStream;

    sub-int v5, v1, v3

    invoke-virtual {v4, v2, v3, v5}, Ljava/io/InputStream;->read([BII)I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_24

    iget v5, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v5, v4

    iput v5, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v3, v4

    goto :goto_10

    :cond_24
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->e()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_29
    sub-int/2addr p1, v1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_2e
    return-object v0
.end method

.method public final I()I
    .registers 4

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int/2addr v1, v0

    const/4 v2, 0x4

    if-ge v1, v2, :cond_d

    invoke-virtual {p0, v2}, Landroidx/glance/appwidget/protobuf/c;->O(I)V

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    :cond_d
    add-int/lit8 v1, v0, 0x4

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    aget-byte v1, p0, v0

    and-int/lit16 v1, v1, 0xff

    add-int/lit8 v2, v0, 0x1

    aget-byte v2, p0, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x8

    or-int/2addr v1, v2

    add-int/lit8 v2, v0, 0x2

    aget-byte v2, p0, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x10

    or-int/2addr v1, v2

    add-int/lit8 v0, v0, 0x3

    aget-byte p0, p0, v0

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x18

    or-int/2addr p0, v1

    return p0
.end method

.method public final J()J
    .registers 10

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int/2addr v1, v0

    const/16 v2, 0x8

    if-ge v1, v2, :cond_e

    invoke-virtual {p0, v2}, Landroidx/glance/appwidget/protobuf/c;->O(I)V

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    :cond_e
    add-int/lit8 v1, v0, 0x8

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    aget-byte v1, p0, v0

    int-to-long v3, v1

    const-wide/16 v5, 0xff

    and-long/2addr v3, v5

    add-int/lit8 v1, v0, 0x1

    aget-byte v1, p0, v1

    int-to-long v7, v1

    and-long/2addr v7, v5

    shl-long v1, v7, v2

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x2

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x10

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x3

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x18

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x4

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x20

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x5

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x28

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v3, v0, 0x6

    aget-byte v3, p0, v3

    int-to-long v3, v3

    and-long/2addr v3, v5

    const/16 v7, 0x30

    shl-long/2addr v3, v7

    or-long/2addr v1, v3

    add-int/lit8 v0, v0, 0x7

    aget-byte p0, p0, v0

    int-to-long v3, p0

    and-long/2addr v3, v5

    const/16 p0, 0x38

    shl-long/2addr v3, p0

    or-long v0, v1, v3

    return-wide v0
.end method

.method public final K()I
    .registers 8

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    if-ne v1, v0, :cond_7

    goto :goto_6b

    :cond_7
    add-int/lit8 v2, v0, 0x1

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    aget-byte v4, v3, v0

    if-ltz v4, :cond_12

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    return v4

    :cond_12
    sub-int/2addr v1, v2

    const/16 v5, 0x9

    if-ge v1, v5, :cond_18

    goto :goto_6b

    :cond_18
    add-int/lit8 v1, v0, 0x2

    aget-byte v2, v3, v2

    shl-int/lit8 v2, v2, 0x7

    xor-int/2addr v2, v4

    if-gez v2, :cond_24

    xor-int/lit8 v0, v2, -0x80

    goto :goto_79

    :cond_24
    add-int/lit8 v4, v0, 0x3

    aget-byte v1, v3, v1

    shl-int/lit8 v1, v1, 0xe

    xor-int/2addr v1, v2

    if-ltz v1, :cond_31

    xor-int/lit16 v0, v1, 0x3f80

    :goto_2f
    move v1, v4

    goto :goto_79

    :cond_31
    add-int/lit8 v2, v0, 0x4

    aget-byte v4, v3, v4

    shl-int/lit8 v4, v4, 0x15

    xor-int/2addr v1, v4

    if-gez v1, :cond_40

    const v0, -0x1fc080

    xor-int/2addr v0, v1

    :goto_3e
    move v1, v2

    goto :goto_79

    :cond_40
    add-int/lit8 v4, v0, 0x5

    aget-byte v2, v3, v2

    shl-int/lit8 v5, v2, 0x1c

    xor-int/2addr v1, v5

    const v5, 0xfe03f80

    xor-int/2addr v1, v5

    if-gez v2, :cond_75

    add-int/lit8 v2, v0, 0x6

    aget-byte v4, v3, v4

    if-gez v4, :cond_77

    add-int/lit8 v4, v0, 0x7

    aget-byte v2, v3, v2

    if-gez v2, :cond_75

    add-int/lit8 v2, v0, 0x8

    aget-byte v4, v3, v4

    if-gez v4, :cond_77

    add-int/lit8 v4, v0, 0x9

    aget-byte v2, v3, v2

    if-gez v2, :cond_75

    add-int/lit8 v0, v0, 0xa

    aget-byte v2, v3, v4

    if-gez v2, :cond_71

    :goto_6b
    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->M()J

    move-result-wide v0

    long-to-int p0, v0

    return p0

    :cond_71
    move v6, v1

    move v1, v0

    move v0, v6

    goto :goto_79

    :cond_75
    move v0, v1

    goto :goto_2f

    :cond_77
    move v0, v1

    goto :goto_3e

    :goto_79
    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    return v0
.end method

.method public final L()J
    .registers 13

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    if-ne v1, v0, :cond_8

    goto/16 :goto_b6

    :cond_8
    add-int/lit8 v2, v0, 0x1

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    aget-byte v4, v3, v0

    if-ltz v4, :cond_14

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    int-to-long v0, v4

    return-wide v0

    :cond_14
    sub-int/2addr v1, v2

    const/16 v5, 0x9

    if-ge v1, v5, :cond_1b

    goto/16 :goto_b6

    :cond_1b
    add-int/lit8 v1, v0, 0x2

    aget-byte v2, v3, v2

    shl-int/lit8 v2, v2, 0x7

    xor-int/2addr v2, v4

    if-gez v2, :cond_29

    xor-int/lit8 v0, v2, -0x80

    int-to-long v2, v0

    goto/16 :goto_bd

    :cond_29
    add-int/lit8 v4, v0, 0x3

    aget-byte v1, v3, v1

    shl-int/lit8 v1, v1, 0xe

    xor-int/2addr v1, v2

    if-ltz v1, :cond_38

    xor-int/lit16 v0, v1, 0x3f80

    int-to-long v2, v0

    move v1, v4

    goto/16 :goto_bd

    :cond_38
    add-int/lit8 v2, v0, 0x4

    aget-byte v4, v3, v4

    shl-int/lit8 v4, v4, 0x15

    xor-int/2addr v1, v4

    if-gez v1, :cond_4b

    const v0, -0x1fc080

    xor-int/2addr v0, v1

    int-to-long v0, v0

    :goto_46
    move-wide v10, v0

    move v1, v2

    move-wide v2, v10

    goto/16 :goto_bd

    :cond_4b
    int-to-long v4, v1

    add-int/lit8 v1, v0, 0x5

    aget-byte v2, v3, v2

    int-to-long v6, v2

    const/16 v2, 0x1c

    shl-long/2addr v6, v2

    xor-long/2addr v4, v6

    const-wide/16 v6, 0x0

    cmp-long v2, v4, v6

    if-ltz v2, :cond_60

    const-wide/32 v2, 0xfe03f80

    :goto_5e
    xor-long/2addr v2, v4

    goto :goto_bd

    :cond_60
    add-int/lit8 v2, v0, 0x6

    aget-byte v1, v3, v1

    int-to-long v8, v1

    const/16 v1, 0x23

    shl-long/2addr v8, v1

    xor-long/2addr v4, v8

    cmp-long v1, v4, v6

    if-gez v1, :cond_74

    const-wide v0, -0x7f01fc080L

    :goto_72
    xor-long/2addr v0, v4

    goto :goto_46

    :cond_74
    add-int/lit8 v1, v0, 0x7

    aget-byte v2, v3, v2

    int-to-long v8, v2

    const/16 v2, 0x2a

    shl-long/2addr v8, v2

    xor-long/2addr v4, v8

    cmp-long v2, v4, v6

    if-ltz v2, :cond_87

    const-wide v2, 0x3f80fe03f80L

    goto :goto_5e

    :cond_87
    add-int/lit8 v2, v0, 0x8

    aget-byte v1, v3, v1

    int-to-long v8, v1

    const/16 v1, 0x31

    shl-long/2addr v8, v1

    xor-long/2addr v4, v8

    cmp-long v1, v4, v6

    if-gez v1, :cond_9a

    const-wide v0, -0x1fc07f01fc080L

    goto :goto_72

    :cond_9a
    add-int/lit8 v1, v0, 0x9

    aget-byte v2, v3, v2

    int-to-long v8, v2

    const/16 v2, 0x38

    shl-long/2addr v8, v2

    xor-long/2addr v4, v8

    const-wide v8, 0xfe03f80fe03f80L

    xor-long/2addr v4, v8

    cmp-long v2, v4, v6

    if-gez v2, :cond_bc

    add-int/lit8 v0, v0, 0xa

    aget-byte v1, v3, v1

    int-to-long v1, v1

    cmp-long v1, v1, v6

    if-gez v1, :cond_bb

    :goto_b6
    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->M()J

    move-result-wide v0

    return-wide v0

    :cond_bb
    move v1, v0

    :cond_bc
    move-wide v2, v4

    :goto_bd
    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    return-wide v2
.end method

.method public final M()J
    .registers 7

    const-wide/16 v0, 0x0

    const/4 v2, 0x0

    :goto_3
    const/16 v3, 0x40

    if-ge v2, v3, :cond_28

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v4, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    if-ne v3, v4, :cond_11

    const/4 v3, 0x1

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/c;->O(I)V

    :cond_11
    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int/lit8 v4, v3, 0x1

    iput v4, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget-object v4, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    aget-byte v3, v4, v3

    and-int/lit8 v4, v3, 0x7f

    int-to-long v4, v4

    shl-long/2addr v4, v2

    or-long/2addr v0, v4

    and-int/lit16 v3, v3, 0x80

    if-nez v3, :cond_25

    return-wide v0

    :cond_25
    add-int/lit8 v2, v2, 0x7

    goto :goto_3

    :cond_28
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->c()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final N()V
    .registers 4

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->f:I

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v1, v0

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    if-le v1, v2, :cond_15

    sub-int/2addr v1, v2

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->f:I

    sub-int/2addr v0, v1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    return-void

    :cond_15
    const/4 v0, 0x0

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->f:I

    return-void
.end method

.method public final O(I)V
    .registers 4

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/c;->Q(I)Z

    move-result v0

    if-nez v0, :cond_1e

    const v0, 0x7fffffff

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    sub-int/2addr v0, v1

    iget p0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    sub-int/2addr v0, p0

    if-le p1, v0, :cond_19

    new-instance p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    const-string p1, "Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_19
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->e()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_1e
    return-void
.end method

.method public final P(I)V
    .registers 11

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    sub-int/2addr v0, v1

    if-gt p1, v0, :cond_d

    if-ltz p1, :cond_d

    add-int/2addr v1, p1

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    return-void

    :cond_d
    iget-object v2, p0, Landroidx/glance/appwidget/protobuf/c;->c:Ljava/io/FileInputStream;

    if-ltz p1, :cond_9d

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int v4, v3, v1

    add-int v5, v4, p1

    iget v6, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    if-gt v5, v6, :cond_93

    iput v4, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    const/4 v1, 0x0

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    :goto_22
    const/4 v1, 0x1

    if-ge v0, p1, :cond_6e

    sub-int v3, p1, v0

    int-to-long v3, v3

    :try_start_28
    invoke-virtual {v2, v3, v4}, Ljava/io/InputStream;->skip(J)J

    move-result-wide v5
    :try_end_2c
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException; {:try_start_28 .. :try_end_2c} :catch_61
    .catchall {:try_start_28 .. :try_end_2c} :catchall_5f

    const-wide/16 v7, 0x0

    cmp-long v7, v5, v7

    if-ltz v7, :cond_3c

    cmp-long v3, v5, v3

    if-gtz v3, :cond_3c

    if-nez v7, :cond_39

    goto :goto_6e

    :cond_39
    long-to-int v1, v5

    add-int/2addr v0, v1

    goto :goto_22

    :cond_3c
    :try_start_3c
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, "#skip returned invalid result: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "\nThe InputStream implementation is buggy."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :catchall_5f
    move-exception p1

    goto :goto_65

    :catch_61
    move-exception p1

    iput-boolean v1, p1, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->E:Z

    throw p1
    :try_end_65
    .catchall {:try_start_3c .. :try_end_65} :catchall_5f

    :goto_65
    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v1, v0

    iput v1, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->N()V

    throw p1

    :cond_6e
    :goto_6e
    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v2, v0

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->N()V

    if-ge v0, p1, :cond_92

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    sub-int v2, v0, v2

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    invoke-virtual {p0, v1}, Landroidx/glance/appwidget/protobuf/c;->O(I)V

    :goto_83
    sub-int v0, p1, v2

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    if-le v0, v3, :cond_90

    add-int/2addr v2, v3

    iput v3, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    invoke-virtual {p0, v1}, Landroidx/glance/appwidget/protobuf/c;->O(I)V

    goto :goto_83

    :cond_90
    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    :cond_92
    return-void

    :cond_93
    sub-int/2addr v6, v3

    sub-int/2addr v6, v1

    invoke-virtual {p0, v6}, Landroidx/glance/appwidget/protobuf/c;->P(I)V

    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->e()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_9d
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->d()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final Q(I)Z
    .registers 9

    iget-object v0, p0, Landroidx/glance/appwidget/protobuf/c;->c:Ljava/io/FileInputStream;

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int v2, v1, p1

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    const/4 v4, 0x0

    if-le v2, v3, :cond_6d

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    const v5, 0x7fffffff

    sub-int v6, v5, v2

    sub-int/2addr v6, v1

    if-le p1, v6, :cond_16

    goto :goto_60

    :cond_16
    add-int/2addr v2, v1

    add-int/2addr v2, p1

    iget v6, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    if-le v2, v6, :cond_1d

    goto :goto_60

    :cond_1d
    iget-object v2, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    if-lez v1, :cond_33

    if-le v3, v1, :cond_27

    sub-int/2addr v3, v1

    invoke-static {v2, v1, v2, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_27
    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v3, v1

    iput v3, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    iget v3, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int/2addr v3, v1

    iput v3, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iput v4, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    :cond_33
    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    array-length v3, v2

    sub-int/2addr v3, v1

    iget v6, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    sub-int/2addr v5, v6

    sub-int/2addr v5, v1

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v5, 0x1

    :try_start_40
    invoke-virtual {v0, v2, v1, v3}, Ljava/io/InputStream;->read([BII)I

    move-result v1
    :try_end_44
    .catch Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException; {:try_start_40 .. :try_end_44} :catch_69

    if-eqz v1, :cond_61

    const/4 v3, -0x1

    if-lt v1, v3, :cond_61

    array-length v2, v2

    if-gt v1, v2, :cond_61

    if-lez v1, :cond_60

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->N()V

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    if-lt v0, p1, :cond_5b

    return v5

    :cond_5b
    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/c;->Q(I)Z

    move-result p0

    return p0

    :cond_60
    :goto_60
    return v4

    :cond_61
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-static {v1, p0}, Le97;->f(ILjava/lang/Object;)V

    return v4

    :catch_69
    move-exception p0

    iput-boolean v5, p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->E:Z

    throw p0

    :cond_6d
    const-string p0, "refillBuffer() called when "

    const-string v0, " bytes were already available in buffer"

    invoke-static {p1, p0, v0}, Lkec;->q(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return v4
.end method

.method public final b(I)V
    .registers 2

    iget p0, p0, Landroidx/glance/appwidget/protobuf/c;->h:I

    if-ne p0, p1, :cond_5

    return-void

    :cond_5
    new-instance p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    const-string p1, "Protocol message end-group tag did not match expected tag."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final f()I
    .registers 2

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    iget p0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int/2addr v0, p0

    return v0
.end method

.method public final g()Z
    .registers 3

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    if-ne v0, v1, :cond_e

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/c;->Q(I)Z

    move-result p0

    if-nez p0, :cond_e

    return v0

    :cond_e
    const/4 p0, 0x0

    return p0
.end method

.method public final j(I)V
    .registers 2

    iput p1, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->N()V

    return-void
.end method

.method public final l(I)I
    .registers 4

    if-ltz p1, :cond_21

    iget v0, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int/2addr v0, v1

    add-int/2addr v0, p1

    if-ltz v0, :cond_19

    iget p1, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    if-gt v0, p1, :cond_14

    iput v0, p0, Landroidx/glance/appwidget/protobuf/c;->j:I

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->N()V

    return p1

    :cond_14
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->e()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_19
    new-instance p0, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    const-string p1, "Failed to parse the message."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_21
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->d()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final m()Z
    .registers 5

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->L()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long p0, v0, v2

    if-eqz p0, :cond_c

    const/4 p0, 0x1

    return p0

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method public final n()Lg92;
    .registers 8

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result v0

    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    sub-int/2addr v1, v2

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/c;->d:[B

    if-gt v0, v1, :cond_19

    if-lez v0, :cond_19

    invoke-static {v3, v2, v0}, Lg92;->c([BII)Lg92;

    move-result-object v1

    iget v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    add-int/2addr v2, v0

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    return-object v1

    :cond_19
    if-nez v0, :cond_1e

    sget-object p0, Lg92;->G:Lg92;

    return-object p0

    :cond_1e
    if-ltz v0, :cond_66

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/c;->G(I)[B

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_2d

    array-length p0, v1

    invoke-static {v1, v2, p0}, Lg92;->c([BII)Lg92;

    move-result-object p0

    return-object p0

    :cond_2d
    iget v1, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iget v4, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int v5, v4, v1

    iget v6, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    add-int/2addr v6, v4

    iput v6, p0, Landroidx/glance/appwidget/protobuf/c;->i:I

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->g:I

    iput v2, p0, Landroidx/glance/appwidget/protobuf/c;->e:I

    sub-int v4, v0, v5

    invoke-virtual {p0, v4}, Landroidx/glance/appwidget/protobuf/c;->H(I)Ljava/util/ArrayList;

    move-result-object p0

    new-array v0, v0, [B

    invoke-static {v3, v1, v0, v2, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_4b
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5e

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    array-length v3, v1

    invoke-static {v1, v2, v0, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    array-length v1, v1

    add-int/2addr v5, v1

    goto :goto_4b

    :cond_5e
    sget-object p0, Lg92;->G:Lg92;

    new-instance p0, Lg92;

    invoke-direct {p0, v0}, Lg92;-><init>([B)V

    return-object p0

    :cond_66
    invoke-static {}, Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;->d()Landroidx/glance/appwidget/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method public final p()D
    .registers 3

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->J()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    return-wide v0
.end method

.method public final q()I
    .registers 1

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result p0

    return p0
.end method

.method public final r()I
    .registers 1

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->I()I

    move-result p0

    return p0
.end method

.method public final s()J
    .registers 3

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->J()J

    move-result-wide v0

    return-wide v0
.end method

.method public final t()F
    .registers 1

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->I()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    return p0
.end method

.method public final u()I
    .registers 1

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result p0

    return p0
.end method

.method public final v()J
    .registers 3

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->L()J

    move-result-wide v0

    return-wide v0
.end method

.method public final w()I
    .registers 1

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->I()I

    move-result p0

    return p0
.end method

.method public final x()J
    .registers 3

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->J()J

    move-result-wide v0

    return-wide v0
.end method

.method public final y()I
    .registers 2

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->K()I

    move-result p0

    ushr-int/lit8 v0, p0, 0x1

    and-int/lit8 p0, p0, 0x1

    neg-int p0, p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public final z()J
    .registers 7

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/c;->L()J

    move-result-wide v0

    const/4 p0, 0x1

    ushr-long v2, v0, p0

    const-wide/16 v4, 0x1

    and-long/2addr v0, v4

    neg-long v0, v0

    xor-long/2addr v0, v2

    return-wide v0
.end method
