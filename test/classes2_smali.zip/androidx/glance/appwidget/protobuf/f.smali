.class public abstract Landroidx/glance/appwidget/protobuf/f;
.super Landroidx/glance/appwidget/protobuf/a;
.source "SourceFile"


# static fields
.field private static final MEMOIZED_SERIALIZED_SIZE_MASK:I = 0x7fffffff

.field private static final MUTABLE_FLAG_MASK:I = -0x80000000

.field static final UNINITIALIZED_HASH_CODE:I = 0x0

.field static final UNINITIALIZED_SERIALIZED_SIZE:I = 0x7fffffff

.field private static defaultInstanceMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Landroidx/glance/appwidget/protobuf/f;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private memoizedSerializedSize:I

.field protected unknownFields:Landroidx/glance/appwidget/protobuf/l;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Landroidx/glance/appwidget/protobuf/f;->defaultInstanceMap:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroidx/glance/appwidget/protobuf/a;->memoizedHashCode:I

    const/4 v0, -0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/f;->memoizedSerializedSize:I

    sget-object v0, Landroidx/glance/appwidget/protobuf/l;->f:Landroidx/glance/appwidget/protobuf/l;

    iput-object v0, p0, Landroidx/glance/appwidget/protobuf/f;->unknownFields:Landroidx/glance/appwidget/protobuf/l;

    return-void
.end method

.method public static c(Ljava/lang/Class;)Landroidx/glance/appwidget/protobuf/f;
    .registers 4

    sget-object v0, Landroidx/glance/appwidget/protobuf/f;->defaultInstanceMap:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/glance/appwidget/protobuf/f;

    if-nez v0, :cond_28

    :try_start_a
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v2, v1}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    :try_end_16
    .catch Ljava/lang/ClassNotFoundException; {:try_start_a .. :try_end_16} :catch_1f

    sget-object v0, Landroidx/glance/appwidget/protobuf/f;->defaultInstanceMap:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/glance/appwidget/protobuf/f;

    goto :goto_28

    :catch_1f
    move-exception p0

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Class initialization cannot fail."

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_28
    :goto_28
    if-nez v0, :cond_44

    invoke-static {p0}, Li5j;->d(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/glance/appwidget/protobuf/f;

    const/4 v1, 0x6

    invoke-virtual {v0, v1}, Landroidx/glance/appwidget/protobuf/f;->b(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/glance/appwidget/protobuf/f;

    if-eqz v0, :cond_3f

    sget-object v1, Landroidx/glance/appwidget/protobuf/f;->defaultInstanceMap:Ljava/util/Map;

    invoke-interface {v1, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    :cond_3f
    invoke-static {}, Lio/sentry/i2;->b()V

    const/4 p0, 0x0

    return-object p0

    :cond_44
    return-object v0
.end method

.method public static varargs d(Ljava/lang/reflect/Method;Landroidx/glance/appwidget/protobuf/f;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    const/4 v0, 0x0

    :try_start_1
    invoke-virtual {p0, p1, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_5
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_5} :catch_1f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_5} :catch_6

    return-object p0

    :catch_6
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/RuntimeException;

    if-nez p1, :cond_1c

    instance-of p1, p0, Ljava/lang/Error;

    if-nez p1, :cond_19

    const-string p1, "Unexpected exception thrown by generated accessor method."

    invoke-static {p1, p0}, Lty9;->o(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v0

    :cond_19
    check-cast p0, Ljava/lang/Error;

    throw p0

    :cond_1c
    check-cast p0, Ljava/lang/RuntimeException;

    throw p0

    :catch_1f
    move-exception p0

    const-string p1, "Couldn\'t use Java reflection to implement protocol message reflection."

    invoke-static {p1, p0}, Lty9;->o(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v0
.end method

.method public static final e(Landroidx/glance/appwidget/protobuf/f;Z)Z
    .registers 4

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/f;->b(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Byte;

    invoke-virtual {v1}, Ljava/lang/Byte;->byteValue()B

    move-result v1

    if-ne v1, v0, :cond_e

    return v0

    :cond_e
    if-nez v1, :cond_12

    const/4 p0, 0x0

    return p0

    :cond_12
    sget-object v0, Llfe;->c:Llfe;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Llfe;->a(Ljava/lang/Class;)Lzxf;

    move-result-object v0

    invoke-interface {v0, p0}, Lzxf;->c(Ljava/lang/Object;)Z

    move-result v0

    if-eqz p1, :cond_29

    const/4 p1, 0x2

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/f;->b(I)Ljava/lang/Object;

    :cond_29
    return v0
.end method

.method public static i(Ljava/lang/Class;Landroidx/glance/appwidget/protobuf/f;)V
    .registers 3

    invoke-virtual {p1}, Landroidx/glance/appwidget/protobuf/f;->g()V

    sget-object v0, Landroidx/glance/appwidget/protobuf/f;->defaultInstanceMap:Ljava/util/Map;

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Lzxf;)I
    .registers 5

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/f;->f()Z

    move-result v0

    if-eqz v0, :cond_2c

    if-nez p1, :cond_1a

    sget-object p1, Llfe;->c:Llfe;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {p1, v0}, Llfe;->a(Ljava/lang/Class;)Lzxf;

    move-result-object p1

    invoke-interface {p1, p0}, Lzxf;->e(Landroidx/glance/appwidget/protobuf/f;)I

    move-result p0

    goto :goto_1e

    :cond_1a
    invoke-interface {p1, p0}, Lzxf;->e(Landroidx/glance/appwidget/protobuf/f;)I

    move-result p0

    :goto_1e
    if-ltz p0, :cond_21

    return p0

    :cond_21
    const-string p1, "serialized size must be non-negative, was "

    invoke-static {p0, p1}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0

    :cond_2c
    iget v0, p0, Landroidx/glance/appwidget/protobuf/f;->memoizedSerializedSize:I

    const v1, 0x7fffffff

    and-int v2, v0, v1

    if-eq v2, v1, :cond_38

    and-int p0, v0, v1

    return p0

    :cond_38
    if-nez p1, :cond_4c

    sget-object p1, Llfe;->c:Llfe;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {p1, v0}, Llfe;->a(Ljava/lang/Class;)Lzxf;

    move-result-object p1

    invoke-interface {p1, p0}, Lzxf;->e(Landroidx/glance/appwidget/protobuf/f;)I

    move-result p1

    goto :goto_50

    :cond_4c
    invoke-interface {p1, p0}, Lzxf;->e(Landroidx/glance/appwidget/protobuf/f;)I

    move-result p1

    :goto_50
    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/f;->j(I)V

    return p1
.end method

.method public abstract b(I)Ljava/lang/Object;
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    if-nez p1, :cond_7

    goto :goto_11

    :cond_7
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_13

    :goto_11
    const/4 p0, 0x0

    return p0

    :cond_13
    sget-object v0, Llfe;->c:Llfe;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Llfe;->a(Ljava/lang/Class;)Lzxf;

    move-result-object v0

    check-cast p1, Landroidx/glance/appwidget/protobuf/f;

    invoke-interface {v0, p0, p1}, Lzxf;->i(Landroidx/glance/appwidget/protobuf/f;Landroidx/glance/appwidget/protobuf/f;)Z

    move-result p0

    return p0
.end method

.method public final f()Z
    .registers 2

    iget p0, p0, Landroidx/glance/appwidget/protobuf/f;->memoizedSerializedSize:I

    const/high16 v0, -0x80000000

    and-int/2addr p0, v0

    if-eqz p0, :cond_9

    const/4 p0, 0x1

    return p0

    :cond_9
    const/4 p0, 0x0

    return p0
.end method

.method public final g()V
    .registers 3

    iget v0, p0, Landroidx/glance/appwidget/protobuf/f;->memoizedSerializedSize:I

    const v1, 0x7fffffff

    and-int/2addr v0, v1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/f;->memoizedSerializedSize:I

    return-void
.end method

.method public final h()Landroidx/glance/appwidget/protobuf/f;
    .registers 2

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/f;->b(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/glance/appwidget/protobuf/f;

    return-object p0
.end method

.method public final hashCode()I
    .registers 3

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/f;->f()Z

    move-result v0

    if-eqz v0, :cond_18

    sget-object v0, Llfe;->c:Llfe;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Llfe;->a(Ljava/lang/Class;)Lzxf;

    move-result-object v0

    invoke-interface {v0, p0}, Lzxf;->g(Landroidx/glance/appwidget/protobuf/f;)I

    move-result p0

    return p0

    :cond_18
    iget v0, p0, Landroidx/glance/appwidget/protobuf/a;->memoizedHashCode:I

    if-nez v0, :cond_2f

    sget-object v0, Llfe;->c:Llfe;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Llfe;->a(Ljava/lang/Class;)Lzxf;

    move-result-object v0

    invoke-interface {v0, p0}, Lzxf;->g(Landroidx/glance/appwidget/protobuf/f;)I

    move-result v0

    iput v0, p0, Landroidx/glance/appwidget/protobuf/a;->memoizedHashCode:I

    :cond_2f
    iget p0, p0, Landroidx/glance/appwidget/protobuf/a;->memoizedHashCode:I

    return p0
.end method

.method public final j(I)V
    .registers 4

    if-ltz p1, :cond_f

    iget v0, p0, Landroidx/glance/appwidget/protobuf/f;->memoizedSerializedSize:I

    const/high16 v1, -0x80000000

    and-int/2addr v0, v1

    const v1, 0x7fffffff

    and-int/2addr p1, v1

    or-int/2addr p1, v0

    iput p1, p0, Landroidx/glance/appwidget/protobuf/f;->memoizedSerializedSize:I

    return-void

    :cond_f
    const-string p0, "serialized size must be non-negative, was "

    invoke-static {p1, p0}, Lwsg;->q(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Landroidx/glance/appwidget/protobuf/g;->a:[C

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "# "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-static {p0, v1, v0}, Landroidx/glance/appwidget/protobuf/g;->c(Landroidx/glance/appwidget/protobuf/f;Ljava/lang/StringBuilder;I)V

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
