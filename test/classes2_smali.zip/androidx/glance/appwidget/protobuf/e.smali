.class public final Landroidx/glance/appwidget/protobuf/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final f:Ljava/util/logging/Logger;

.field public static final g:Z


# instance fields
.field public a:Lfgk;

.field public final b:[B

.field public final c:I

.field public d:I

.field public final e:Ll2j;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Landroidx/glance/appwidget/protobuf/e;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    sget-boolean v0, Li5j;->e:Z

    sput-boolean v0, Landroidx/glance/appwidget/protobuf/e;->g:Z

    return-void
.end method

.method public constructor <init>(Ll2j;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-ltz p2, :cond_14

    const/16 v0, 0x14

    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    move-result p2

    new-array v0, p2, [B

    iput-object v0, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    iput p2, p0, Landroidx/glance/appwidget/protobuf/e;->c:I

    iput-object p1, p0, Landroidx/glance/appwidget/protobuf/e;->e:Ll2j;

    return-void

    :cond_14
    const-string p0, "bufferSize must be >= 0"

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public static f(ILg92;)I
    .registers 3

    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/e;->h(I)I

    move-result p0

    invoke-virtual {p1}, Lg92;->size()I

    move-result p1

    invoke-static {p1}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v0

    add-int/2addr v0, p1

    add-int/2addr v0, p0

    return v0
.end method

.method public static g(Ljava/lang/String;)I
    .registers 2

    :try_start_0
    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/o;->a(Ljava/lang/String;)I

    move-result p0
    :try_end_4
    .catch Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException; {:try_start_0 .. :try_end_4} :catch_5

    goto :goto_c

    :catch_5
    sget-object v0, Lgl9;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    array-length p0, p0

    :goto_c
    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v0

    add-int/2addr v0, p0

    return v0
.end method

.method public static h(I)I
    .registers 1

    shl-int/lit8 p0, p0, 0x3

    invoke-static {p0}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result p0

    return p0
.end method

.method public static i(I)I
    .registers 1

    invoke-static {p0}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    move-result p0

    mul-int/lit8 p0, p0, 0x9

    rsub-int p0, p0, 0x160

    ushr-int/lit8 p0, p0, 0x6

    return p0
.end method

.method public static j(J)I
    .registers 2

    invoke-static {p0, p1}, Ljava/lang/Long;->numberOfLeadingZeros(J)I

    move-result p0

    mul-int/lit8 p0, p0, 0x9

    rsub-int p0, p0, 0x280

    ushr-int/lit8 p0, p0, 0x6

    return p0
.end method


# virtual methods
.method public final A(I)V
    .registers 3

    const/4 v0, 0x5

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/e;->d(I)V

    return-void
.end method

.method public final B(IJ)V
    .registers 5

    const/16 v0, 0x14

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->c(II)V

    invoke-virtual {p0, p2, p3}, Landroidx/glance/appwidget/protobuf/e;->e(J)V

    return-void
.end method

.method public final C(J)V
    .registers 4

    const/16 v0, 0xa

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    invoke-virtual {p0, p1, p2}, Landroidx/glance/appwidget/protobuf/e;->e(J)V

    return-void
.end method

.method public final a(I)V
    .registers 7

    iget v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    and-int/lit16 v2, p1, 0xff

    int-to-byte v2, v2

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    aput-byte v2, v3, v0

    add-int/lit8 v2, v0, 0x2

    iput v2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    shr-int/lit8 v4, p1, 0x8

    and-int/lit16 v4, v4, 0xff

    int-to-byte v4, v4

    aput-byte v4, v3, v1

    add-int/lit8 v1, v0, 0x3

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    shr-int/lit8 v4, p1, 0x10

    and-int/lit16 v4, v4, 0xff

    int-to-byte v4, v4

    aput-byte v4, v3, v2

    add-int/lit8 v0, v0, 0x4

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    shr-int/lit8 p0, p1, 0x18

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    aput-byte p0, v3, v1

    return-void
.end method

.method public final b(J)V
    .registers 12

    iget v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const-wide/16 v2, 0xff

    and-long v4, p1, v2

    long-to-int v4, v4

    int-to-byte v4, v4

    iget-object v5, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    aput-byte v4, v5, v0

    add-int/lit8 v4, v0, 0x2

    iput v4, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const/16 v6, 0x8

    shr-long v7, p1, v6

    and-long/2addr v7, v2

    long-to-int v7, v7

    int-to-byte v7, v7

    aput-byte v7, v5, v1

    add-int/lit8 v1, v0, 0x3

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const/16 v7, 0x10

    shr-long v7, p1, v7

    and-long/2addr v7, v2

    long-to-int v7, v7

    int-to-byte v7, v7

    aput-byte v7, v5, v4

    add-int/lit8 v4, v0, 0x4

    iput v4, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const/16 v7, 0x18

    shr-long v7, p1, v7

    and-long/2addr v2, v7

    long-to-int v2, v2

    int-to-byte v2, v2

    aput-byte v2, v5, v1

    add-int/lit8 v1, v0, 0x5

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const/16 v2, 0x20

    shr-long v2, p1, v2

    long-to-int v2, v2

    and-int/lit16 v2, v2, 0xff

    int-to-byte v2, v2

    aput-byte v2, v5, v4

    add-int/lit8 v2, v0, 0x6

    iput v2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const/16 v3, 0x28

    shr-long v3, p1, v3

    long-to-int v3, v3

    and-int/lit16 v3, v3, 0xff

    int-to-byte v3, v3

    aput-byte v3, v5, v1

    add-int/lit8 v1, v0, 0x7

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const/16 v3, 0x30

    shr-long v3, p1, v3

    long-to-int v3, v3

    and-int/lit16 v3, v3, 0xff

    int-to-byte v3, v3

    aput-byte v3, v5, v2

    add-int/2addr v0, v6

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    const/16 p0, 0x38

    shr-long p0, p1, p0

    long-to-int p0, p0

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    aput-byte p0, v5, v1

    return-void
.end method

.method public final c(II)V
    .registers 3

    shl-int/lit8 p1, p1, 0x3

    or-int/2addr p1, p2

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/e;->d(I)V

    return-void
.end method

.method public final d(I)V
    .registers 6

    sget-boolean v0, Landroidx/glance/appwidget/protobuf/e;->g:Z

    iget-object v1, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    if-eqz v0, :cond_26

    :goto_6
    and-int/lit8 v0, p1, -0x80

    iget v2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    if-nez v0, :cond_16

    add-int/lit8 v0, v2, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    int-to-long v2, v2

    int-to-byte p0, p1

    invoke-static {v1, v2, v3, p0}, Li5j;->j([BJB)V

    return-void

    :cond_16
    add-int/lit8 v0, v2, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    int-to-long v2, v2

    or-int/lit16 v0, p1, 0x80

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    invoke-static {v1, v2, v3, v0}, Li5j;->j([BJB)V

    ushr-int/lit8 p1, p1, 0x7

    goto :goto_6

    :cond_26
    :goto_26
    and-int/lit8 v0, p1, -0x80

    iget v2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    if-nez v0, :cond_34

    add-int/lit8 v0, v2, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    int-to-byte p0, p1

    aput-byte p0, v1, v2

    return-void

    :cond_34
    add-int/lit8 v0, v2, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    or-int/lit16 v0, p1, 0x80

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    aput-byte v0, v1, v2

    ushr-int/lit8 p1, p1, 0x7

    goto :goto_26
.end method

.method public final e(J)V
    .registers 12

    sget-boolean v0, Landroidx/glance/appwidget/protobuf/e;->g:Z

    const/4 v1, 0x7

    iget-object v2, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    const-wide/16 v3, 0x0

    const-wide/16 v5, -0x80

    if-eqz v0, :cond_2e

    :goto_b
    and-long v7, p1, v5

    cmp-long v0, v7, v3

    iget v7, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    if-nez v0, :cond_1e

    add-int/lit8 v0, v7, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    int-to-long v0, v7

    long-to-int p0, p1

    int-to-byte p0, p0

    invoke-static {v2, v0, v1, p0}, Li5j;->j([BJB)V

    return-void

    :cond_1e
    add-int/lit8 v0, v7, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    int-to-long v7, v7

    long-to-int v0, p1

    or-int/lit16 v0, v0, 0x80

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    invoke-static {v2, v7, v8, v0}, Li5j;->j([BJB)V

    ushr-long/2addr p1, v1

    goto :goto_b

    :cond_2e
    :goto_2e
    and-long v7, p1, v5

    cmp-long v0, v7, v3

    iget v7, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    if-nez v0, :cond_3f

    add-int/lit8 v0, v7, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    long-to-int p0, p1

    int-to-byte p0, p0

    aput-byte p0, v2, v7

    return-void

    :cond_3f
    add-int/lit8 v0, v7, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    long-to-int v0, p1

    or-int/lit16 v0, v0, 0x80

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    aput-byte v0, v2, v7

    ushr-long/2addr p1, v1

    goto :goto_2e
.end method

.method public final k()V
    .registers 5

    iget v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    iget-object v1, p0, Landroidx/glance/appwidget/protobuf/e;->e:Ll2j;

    iget-object v2, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3, v0}, Ll2j;->write([BII)V

    iput v3, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    return-void
.end method

.method public final l(I)V
    .registers 4

    iget v0, p0, Landroidx/glance/appwidget/protobuf/e;->c:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    sub-int/2addr v0, v1

    if-ge v0, p1, :cond_a

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/e;->k()V

    :cond_a
    return-void
.end method

.method public final m([BII)V
    .registers 8

    iget v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    iget v1, p0, Landroidx/glance/appwidget/protobuf/e;->c:I

    sub-int v2, v1, v0

    iget-object v3, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    if-lt v2, p3, :cond_13

    invoke-static {p1, p2, v3, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    add-int/2addr p1, p3

    iput p1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    return-void

    :cond_13
    invoke-static {p1, p2, v3, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr p2, v2

    sub-int/2addr p3, v2

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/e;->k()V

    if-gt p3, v1, :cond_26

    const/4 v0, 0x0

    invoke-static {p1, p2, v3, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput p3, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    goto :goto_2b

    :cond_26
    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/e;->e:Ll2j;

    invoke-virtual {p0, p1, p2, p3}, Ll2j;->write([BII)V

    :goto_2b
    return-void
.end method

.method public final n(IZ)V
    .registers 4

    const/16 v0, 0xb

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->c(II)V

    int-to-byte p1, p2

    iget p2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    add-int/lit8 v0, p2, 0x1

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    aput-byte p1, p0, p2

    return-void
.end method

.method public final o(ILg92;)V
    .registers 4

    const/4 v0, 0x2

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    invoke-virtual {p2}, Lg92;->size()I

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    iget-object p1, p2, Lg92;->F:[B

    invoke-virtual {p2}, Lg92;->g()I

    move-result v0

    invoke-virtual {p2}, Lg92;->size()I

    move-result p2

    invoke-virtual {p0, p1, v0, p2}, Landroidx/glance/appwidget/protobuf/e;->v([BII)V

    return-void
.end method

.method public final p(II)V
    .registers 4

    const/16 v0, 0xe

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    const/4 v0, 0x5

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->c(II)V

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/e;->a(I)V

    return-void
.end method

.method public final q(I)V
    .registers 3

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/e;->a(I)V

    return-void
.end method

.method public final r(IJ)V
    .registers 5

    const/16 v0, 0x12

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->c(II)V

    invoke-virtual {p0, p2, p3}, Landroidx/glance/appwidget/protobuf/e;->b(J)V

    return-void
.end method

.method public final s(J)V
    .registers 4

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    invoke-virtual {p0, p1, p2}, Landroidx/glance/appwidget/protobuf/e;->b(J)V

    return-void
.end method

.method public final t(II)V
    .registers 4

    const/16 v0, 0x14

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->c(II)V

    if-ltz p2, :cond_f

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/e;->d(I)V

    return-void

    :cond_f
    int-to-long p1, p2

    invoke-virtual {p0, p1, p2}, Landroidx/glance/appwidget/protobuf/e;->e(J)V

    return-void
.end method

.method public final u(I)V
    .registers 4

    if-ltz p1, :cond_6

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    return-void

    :cond_6
    int-to-long v0, p1

    invoke-virtual {p0, v0, v1}, Landroidx/glance/appwidget/protobuf/e;->C(J)V

    return-void
.end method

.method public final v([BII)V
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Landroidx/glance/appwidget/protobuf/e;->m([BII)V

    return-void
.end method

.method public final w(ILandroidx/glance/appwidget/protobuf/a;Lzxf;)V
    .registers 5

    const/4 v0, 0x2

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    invoke-virtual {p2, p3}, Landroidx/glance/appwidget/protobuf/a;->a(Lzxf;)I

    move-result p1

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    iget-object p0, p0, Landroidx/glance/appwidget/protobuf/e;->a:Lfgk;

    invoke-interface {p3, p2, p0}, Lzxf;->h(Ljava/lang/Object;Lfgk;)V

    return-void
.end method

.method public final x(ILjava/lang/String;)V
    .registers 9

    const/4 v0, 0x2

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->y(II)V

    const/4 p1, 0x0

    :try_start_5
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    mul-int/lit8 v0, v0, 0x3

    invoke-static {v0}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v1
    :try_end_f
    .catch Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException; {:try_start_5 .. :try_end_f} :catch_24

    add-int v2, v1, v0

    iget v3, p0, Landroidx/glance/appwidget/protobuf/e;->c:I

    if-le v2, v3, :cond_26

    :try_start_15
    new-array v1, v0, [B

    sget-object v2, Landroidx/glance/appwidget/protobuf/o;->a:Lral;

    invoke-virtual {v2, p2, v1, p1, v0}, Lral;->f(Ljava/lang/String;[BII)I

    move-result v0

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    invoke-virtual {p0, v1, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->m([BII)V

    return-void

    :catch_24
    move-exception v0

    goto :goto_72

    :cond_26
    iget v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    sub-int v0, v3, v0

    if-le v2, v0, :cond_2f

    invoke-virtual {p0}, Landroidx/glance/appwidget/protobuf/e;->k()V

    :cond_2f
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    invoke-static {v0}, Landroidx/glance/appwidget/protobuf/e;->i(I)I

    move-result v0

    iget v2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I
    :try_end_39
    .catch Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException; {:try_start_15 .. :try_end_39} :catch_24

    iget-object v4, p0, Landroidx/glance/appwidget/protobuf/e;->b:[B

    if-ne v0, v1, :cond_57

    add-int v1, v2, v0

    :try_start_3f
    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    sub-int/2addr v3, v1

    sget-object v5, Landroidx/glance/appwidget/protobuf/o;->a:Lral;

    invoke-virtual {v5, p2, v4, v1, v3}, Lral;->f(Ljava/lang/String;[BII)I

    move-result v1

    iput v2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    sub-int v3, v1, v2

    sub-int/2addr v3, v0

    invoke-virtual {p0, v3}, Landroidx/glance/appwidget/protobuf/e;->d(I)V

    iput v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    return-void

    :catch_53
    move-exception v0

    goto :goto_69

    :catch_55
    move-exception v0

    goto :goto_6f

    :cond_57
    invoke-static {p2}, Landroidx/glance/appwidget/protobuf/o;->a(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->d(I)V

    iget v1, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    sget-object v3, Landroidx/glance/appwidget/protobuf/o;->a:Lral;

    invoke-virtual {v3, p2, v4, v1, v0}, Lral;->f(Ljava/lang/String;[BII)I

    move-result v0

    iput v0, p0, Landroidx/glance/appwidget/protobuf/e;->d:I
    :try_end_68
    .catch Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException; {:try_start_3f .. :try_end_68} :catch_55
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_3f .. :try_end_68} :catch_53

    return-void

    :goto_69
    :try_start_69
    new-instance v1, Landroidx/glance/appwidget/protobuf/CodedOutputStream$OutOfSpaceException;

    invoke-direct {v1, v0}, Landroidx/glance/appwidget/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/IndexOutOfBoundsException;)V

    throw v1

    :goto_6f
    iput v2, p0, Landroidx/glance/appwidget/protobuf/e;->d:I

    throw v0
    :try_end_72
    .catch Landroidx/glance/appwidget/protobuf/Utf8$UnpairedSurrogateException; {:try_start_69 .. :try_end_72} :catch_24

    :goto_72
    sget-object v1, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const-string v2, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!"

    sget-object v3, Landroidx/glance/appwidget/protobuf/e;->f:Ljava/util/logging/Logger;

    invoke-virtual {v3, v1, v2, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    sget-object v0, Lgl9;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p2

    :try_start_81
    array-length v0, p2

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    array-length v0, p2

    invoke-virtual {p0, p2, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->v([BII)V
    :try_end_89
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_81 .. :try_end_89} :catch_8a

    return-void

    :catch_8a
    move-exception p0

    new-instance p1, Landroidx/glance/appwidget/protobuf/CodedOutputStream$OutOfSpaceException;

    invoke-direct {p1, p0}, Landroidx/glance/appwidget/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/IndexOutOfBoundsException;)V

    throw p1
.end method

.method public final y(II)V
    .registers 3

    shl-int/lit8 p1, p1, 0x3

    or-int/2addr p1, p2

    invoke-virtual {p0, p1}, Landroidx/glance/appwidget/protobuf/e;->A(I)V

    return-void
.end method

.method public final z(II)V
    .registers 4

    const/16 v0, 0x14

    invoke-virtual {p0, v0}, Landroidx/glance/appwidget/protobuf/e;->l(I)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/glance/appwidget/protobuf/e;->c(II)V

    invoke-virtual {p0, p2}, Landroidx/glance/appwidget/protobuf/e;->d(I)V

    return-void
.end method
