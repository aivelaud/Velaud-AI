.class public Landroidx/appcompat/widget/ContentFrameLayout;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# instance fields
.field public E:Landroid/util/TypedValue;

.field public F:Landroid/util/TypedValue;

.field public G:Landroid/util/TypedValue;

.field public H:Landroid/util/TypedValue;

.field public I:Landroid/util/TypedValue;

.field public J:Landroid/util/TypedValue;

.field public final K:Landroid/graphics/Rect;

.field public L:Lb55;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 12
    invoke-direct {p0, p1, v0}, Landroidx/appcompat/widget/ContentFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 11
    invoke-direct {p0, p1, p2, v0}, Landroidx/appcompat/widget/ContentFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/widget/ContentFrameLayout;->K:Landroid/graphics/Rect;

    return-void
.end method


# virtual methods
.method public getFixedHeightMajor()Landroid/util/TypedValue;
    .registers 2

    iget-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->I:Landroid/util/TypedValue;

    if-nez v0, :cond_b

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->I:Landroid/util/TypedValue;

    :cond_b
    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->I:Landroid/util/TypedValue;

    return-object p0
.end method

.method public getFixedHeightMinor()Landroid/util/TypedValue;
    .registers 2

    iget-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->J:Landroid/util/TypedValue;

    if-nez v0, :cond_b

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->J:Landroid/util/TypedValue;

    :cond_b
    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->J:Landroid/util/TypedValue;

    return-object p0
.end method

.method public getFixedWidthMajor()Landroid/util/TypedValue;
    .registers 2

    iget-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->G:Landroid/util/TypedValue;

    if-nez v0, :cond_b

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->G:Landroid/util/TypedValue;

    :cond_b
    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->G:Landroid/util/TypedValue;

    return-object p0
.end method

.method public getFixedWidthMinor()Landroid/util/TypedValue;
    .registers 2

    iget-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->H:Landroid/util/TypedValue;

    if-nez v0, :cond_b

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->H:Landroid/util/TypedValue;

    :cond_b
    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->H:Landroid/util/TypedValue;

    return-object p0
.end method

.method public getMinWidthMajor()Landroid/util/TypedValue;
    .registers 2

    iget-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->E:Landroid/util/TypedValue;

    if-nez v0, :cond_b

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->E:Landroid/util/TypedValue;

    :cond_b
    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->E:Landroid/util/TypedValue;

    return-object p0
.end method

.method public getMinWidthMinor()Landroid/util/TypedValue;
    .registers 2

    iget-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->F:Landroid/util/TypedValue;

    if-nez v0, :cond_b

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->F:Landroid/util/TypedValue;

    :cond_b
    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->F:Landroid/util/TypedValue;

    return-object p0
.end method

.method public final onAttachedToWindow()V
    .registers 1

    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->L:Lb55;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_a
    return-void
.end method

.method public final onDetachedFromWindow()V
    .registers 3

    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    iget-object p0, p0, Landroidx/appcompat/widget/ContentFrameLayout;->L:Lb55;

    if-eqz p0, :cond_65

    check-cast p0, Lsh0;

    iget-object p0, p0, Lsh0;->E:Lci0;

    iget-object v0, p0, Lci0;->N:Landroidx/appcompat/widget/ActionBarOverlayLayout;

    if-eqz v0, :cond_32

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionBarOverlayLayout;->k()V

    iget-object v0, v0, Landroidx/appcompat/widget/ActionBarOverlayLayout;->I:Lbx5;

    check-cast v0, Ljpi;

    iget-object v0, v0, Ljpi;->a:Landroidx/appcompat/widget/Toolbar;

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->E:Landroidx/appcompat/widget/ActionMenuView;

    if-eqz v0, :cond_32

    iget-object v0, v0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    if-eqz v0, :cond_32

    invoke-virtual {v0}, Lnb;->f()Z

    iget-object v0, v0, Lnb;->X:Lkb;

    if-eqz v0, :cond_32

    invoke-virtual {v0}, Livb;->b()Z

    move-result v1

    if-eqz v1, :cond_32

    iget-object v0, v0, Livb;->i:Lgvb;

    invoke-interface {v0}, Lhzg;->dismiss()V

    :cond_32
    iget-object v0, p0, Lci0;->S:Landroid/widget/PopupWindow;

    if-eqz v0, :cond_51

    iget-object v0, p0, Lci0;->J:Landroid/view/Window;

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Lci0;->T:Lqh0;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Lci0;->S:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_4e

    :try_start_49
    iget-object v0, p0, Lci0;->S:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V
    :try_end_4e
    .catch Ljava/lang/IllegalArgumentException; {:try_start_49 .. :try_end_4e} :catch_4e

    :catch_4e
    :cond_4e
    const/4 v0, 0x0

    iput-object v0, p0, Lci0;->S:Landroid/widget/PopupWindow;

    :cond_51
    iget-object v0, p0, Lci0;->U:Lymj;

    if-eqz v0, :cond_58

    invoke-virtual {v0}, Lymj;->b()V

    :cond_58
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lci0;->q(I)Lbi0;

    move-result-object p0

    iget-object p0, p0, Lbi0;->h:Lpub;

    if-eqz p0, :cond_65

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lpub;->c(Z)V

    :cond_65
    return-void
.end method

.method public final onMeasure(II)V
    .registers 19

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v2, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v3, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ge v2, v3, :cond_18

    move v2, v4

    goto :goto_19

    :cond_18
    move v2, v5

    :goto_19
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v3

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v6

    iget-object v7, v0, Landroidx/appcompat/widget/ContentFrameLayout;->K:Landroid/graphics/Rect;

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/high16 v10, -0x80000000

    const/high16 v11, 0x40000000  # 2.0f

    if-ne v3, v10, :cond_62

    if-eqz v2, :cond_30

    iget-object v12, v0, Landroidx/appcompat/widget/ContentFrameLayout;->H:Landroid/util/TypedValue;

    goto :goto_32

    :cond_30
    iget-object v12, v0, Landroidx/appcompat/widget/ContentFrameLayout;->G:Landroid/util/TypedValue;

    :goto_32
    if-eqz v12, :cond_62

    iget v13, v12, Landroid/util/TypedValue;->type:I

    if-eqz v13, :cond_62

    if-ne v13, v9, :cond_40

    invoke-virtual {v12, v1}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F

    move-result v12

    :goto_3e
    float-to-int v12, v12

    goto :goto_4c

    :cond_40
    if-ne v13, v8, :cond_4b

    iget v13, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v14, v13

    int-to-float v13, v13

    invoke-virtual {v12, v14, v13}, Landroid/util/TypedValue;->getFraction(FF)F

    move-result v12

    goto :goto_3e

    :cond_4b
    move v12, v5

    :goto_4c
    if-lez v12, :cond_62

    iget v13, v7, Landroid/graphics/Rect;->left:I

    iget v14, v7, Landroid/graphics/Rect;->right:I

    add-int/2addr v13, v14

    sub-int/2addr v12, v13

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v13

    invoke-static {v12, v13}, Ljava/lang/Math;->min(II)I

    move-result v12

    invoke-static {v12, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v12

    move v13, v4

    goto :goto_65

    :cond_62
    move/from16 v12, p1

    move v13, v5

    :goto_65
    if-ne v6, v10, :cond_9d

    if-eqz v2, :cond_6c

    iget-object v6, v0, Landroidx/appcompat/widget/ContentFrameLayout;->I:Landroid/util/TypedValue;

    goto :goto_6e

    :cond_6c
    iget-object v6, v0, Landroidx/appcompat/widget/ContentFrameLayout;->J:Landroid/util/TypedValue;

    :goto_6e
    if-eqz v6, :cond_9d

    iget v14, v6, Landroid/util/TypedValue;->type:I

    if-eqz v14, :cond_9d

    if-ne v14, v9, :cond_7c

    invoke-virtual {v6, v1}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F

    move-result v6

    :goto_7a
    float-to-int v6, v6

    goto :goto_88

    :cond_7c
    if-ne v14, v8, :cond_87

    iget v14, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v15, v14

    int-to-float v14, v14

    invoke-virtual {v6, v15, v14}, Landroid/util/TypedValue;->getFraction(FF)F

    move-result v6

    goto :goto_7a

    :cond_87
    move v6, v5

    :goto_88
    if-lez v6, :cond_9d

    iget v14, v7, Landroid/graphics/Rect;->top:I

    iget v15, v7, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v14, v15

    sub-int/2addr v6, v14

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v14

    invoke-static {v6, v14}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-static {v6, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    goto :goto_9f

    :cond_9d
    move/from16 v6, p2

    :goto_9f
    invoke-super {v0, v12, v6}, Landroid/widget/FrameLayout;->onMeasure(II)V

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v12

    invoke-static {v12, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v14

    if-nez v13, :cond_de

    if-ne v3, v10, :cond_de

    if-eqz v2, :cond_b3

    iget-object v2, v0, Landroidx/appcompat/widget/ContentFrameLayout;->F:Landroid/util/TypedValue;

    goto :goto_b5

    :cond_b3
    iget-object v2, v0, Landroidx/appcompat/widget/ContentFrameLayout;->E:Landroid/util/TypedValue;

    :goto_b5
    if-eqz v2, :cond_de

    iget v3, v2, Landroid/util/TypedValue;->type:I

    if-eqz v3, :cond_de

    if-ne v3, v9, :cond_c3

    invoke-virtual {v2, v1}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F

    move-result v1

    :goto_c1
    float-to-int v1, v1

    goto :goto_cf

    :cond_c3
    if-ne v3, v8, :cond_ce

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v3, v1

    int-to-float v1, v1

    invoke-virtual {v2, v3, v1}, Landroid/util/TypedValue;->getFraction(FF)F

    move-result v1

    goto :goto_c1

    :cond_ce
    move v1, v5

    :goto_cf
    if-lez v1, :cond_d7

    iget v2, v7, Landroid/graphics/Rect;->left:I

    iget v3, v7, Landroid/graphics/Rect;->right:I

    add-int/2addr v2, v3

    sub-int/2addr v1, v2

    :cond_d7
    if-ge v12, v1, :cond_de

    invoke-static {v1, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v14

    goto :goto_df

    :cond_de
    move v4, v5

    :goto_df
    if-eqz v4, :cond_e4

    invoke-super {v0, v14, v6}, Landroid/widget/FrameLayout;->onMeasure(II)V

    :cond_e4
    return-void
.end method

.method public setAttachListener(Lb55;)V
    .registers 2

    iput-object p1, p0, Landroidx/appcompat/widget/ContentFrameLayout;->L:Lb55;

    return-void
.end method
