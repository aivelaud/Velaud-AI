.class public Landroidx/appcompat/widget/ActionMenuView;
.super Lija;
.source "SourceFile"

# interfaces
.implements Loub;
.implements Lsvb;


# instance fields
.field public T:Lpub;

.field public U:Landroid/content/Context;

.field public V:I

.field public W:Z

.field public a0:Lnb;

.field public b0:La1f;

.field public c0:Z

.field public d0:I

.field public final e0:I

.field public final f0:I

.field public g0:Lqb;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 34
    invoke-direct {p0, p1, v0}, Landroidx/appcompat/widget/ActionMenuView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lija;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 p2, 0x0

    invoke-virtual {p0, p2}, Lija;->setBaselineAligned(Z)V

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/high16 v1, 0x42600000  # 56.0f

    mul-float/2addr v1, v0

    float-to-int v1, v1

    iput v1, p0, Landroidx/appcompat/widget/ActionMenuView;->e0:I

    const/high16 v1, 0x40800000  # 4.0f

    mul-float/2addr v0, v1

    float-to-int v0, v0

    iput v0, p0, Landroidx/appcompat/widget/ActionMenuView;->f0:I

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->U:Landroid/content/Context;

    iput p2, p0, Landroidx/appcompat/widget/ActionMenuView;->V:I

    return-void
.end method

.method public static i()Lpb;
    .registers 2

    new-instance v0, Lpb;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v1, 0x0

    iput-boolean v1, v0, Lpb;->a:Z

    const/16 v1, 0x10

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    return-object v0
.end method

.method public static j(Landroid/view/ViewGroup$LayoutParams;)Lpb;
    .registers 2

    if-eqz p0, :cond_20

    instance-of v0, p0, Lpb;

    if-eqz v0, :cond_12

    new-instance v0, Lpb;

    check-cast p0, Lpb;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    iget-boolean p0, p0, Lpb;->a:Z

    iput-boolean p0, v0, Lpb;->a:Z

    goto :goto_17

    :cond_12
    new-instance v0, Lpb;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_17
    iget p0, v0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    if-gtz p0, :cond_1f

    const/16 p0, 0x10

    iput p0, v0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    :cond_1f
    return-object v0

    :cond_20
    invoke-static {}, Landroidx/appcompat/widget/ActionMenuView;->i()Lpb;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final a(Luub;)Z
    .registers 4

    iget-object p0, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0}, Lpub;->q(Landroid/view/MenuItem;Lqvb;I)Z

    move-result p0

    return p0
.end method

.method public final b(Lpub;)V
    .registers 2

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    return-void
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .registers 2

    instance-of p0, p1, Lpb;

    return p0
.end method

.method public final dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 2

    const/4 p0, 0x0

    return p0
.end method

.method public final bridge synthetic e()Lhja;
    .registers 1

    invoke-static {}, Landroidx/appcompat/widget/ActionMenuView;->i()Lpb;

    move-result-object p0

    return-object p0
.end method

.method public final f(Landroid/util/AttributeSet;)Lhja;
    .registers 3

    new-instance v0, Lpb;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final bridge synthetic g(Landroid/view/ViewGroup$LayoutParams;)Lhja;
    .registers 2

    invoke-static {p1}, Landroidx/appcompat/widget/ActionMenuView;->j(Landroid/view/ViewGroup$LayoutParams;)Lpb;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .registers 1

    invoke-static {}, Landroidx/appcompat/widget/ActionMenuView;->i()Lpb;

    move-result-object p0

    return-object p0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .registers 3

    new-instance v0, Lpb;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final bridge synthetic generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .registers 2

    .line 10
    invoke-static {p1}, Landroidx/appcompat/widget/ActionMenuView;->j(Landroid/view/ViewGroup$LayoutParams;)Lpb;

    move-result-object p0

    return-object p0
.end method

.method public getMenu()Landroid/view/Menu;
    .registers 4

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    if-nez v0, :cond_3a

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Lpub;

    invoke-direct {v1, v0}, Lpub;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    new-instance v2, Lgkf;

    invoke-direct {v2, p0}, Lgkf;-><init>(Ljava/lang/Object;)V

    iput-object v2, v1, Lpub;->e:Lnub;

    new-instance v1, Lnb;

    invoke-direct {v1, v0}, Lnb;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    const/4 v0, 0x1

    iput-boolean v0, v1, Lnb;->P:Z

    iput-boolean v0, v1, Lnb;->Q:Z

    new-instance v0, Lrsl;

    const/16 v2, 0x16

    invoke-direct {v0, v2}, Lrsl;-><init>(I)V

    iput-object v0, v1, Lnb;->I:Lpvb;

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    iget-object v2, p0, Landroidx/appcompat/widget/ActionMenuView;->U:Landroid/content/Context;

    invoke-virtual {v0, v1, v2}, Lpub;->b(Lqvb;Landroid/content/Context;)V

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    iput-object p0, v0, Lnb;->L:Lsvb;

    iget-object v0, v0, Lnb;->G:Lpub;

    iput-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    :cond_3a
    iget-object p0, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    return-object p0
.end method

.method public getOverflowIcon()Landroid/graphics/drawable/Drawable;
    .registers 2

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->getMenu()Landroid/view/Menu;

    iget-object p0, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    iget-object v0, p0, Lnb;->M:Lmb;

    if-eqz v0, :cond_e

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0

    :cond_e
    iget-boolean v0, p0, Lnb;->O:Z

    if-eqz v0, :cond_15

    iget-object p0, p0, Lnb;->N:Landroid/graphics/drawable/Drawable;

    return-object p0

    :cond_15
    const/4 p0, 0x0

    return-object p0
.end method

.method public getPopupTheme()I
    .registers 1

    iget p0, p0, Landroidx/appcompat/widget/ActionMenuView;->V:I

    return p0
.end method

.method public getWindowAnimations()I
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final k(I)Z
    .registers 5

    const/4 v0, 0x0

    if-nez p1, :cond_4

    return v0

    :cond_4
    add-int/lit8 v1, p1, -0x1

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p0

    if-ge p1, p0, :cond_1e

    instance-of p0, v1, Lob;

    if-eqz p0, :cond_1e

    check-cast v1, Lob;

    invoke-interface {v1}, Lob;->b()Z

    move-result v0

    :cond_1e
    if-lez p1, :cond_2c

    instance-of p0, v2, Lob;

    if-eqz p0, :cond_2c

    check-cast v2, Lob;

    invoke-interface {v2}, Lob;->c()Z

    move-result p0

    or-int/2addr p0, v0

    return p0

    :cond_2c
    return v0
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 2

    invoke-super {p0, p1}, Landroid/view/View;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    if-eqz p1, :cond_1c

    invoke-virtual {p1}, Lnb;->i()V

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    invoke-virtual {p1}, Lnb;->j()Z

    move-result p1

    if-eqz p1, :cond_1c

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    invoke-virtual {p1}, Lnb;->f()Z

    iget-object p0, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    invoke-virtual {p0}, Lnb;->l()Z

    :cond_1c
    return-void
.end method

.method public final onDetachedFromWindow()V
    .registers 2

    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    iget-object p0, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    if-eqz p0, :cond_19

    invoke-virtual {p0}, Lnb;->f()Z

    iget-object p0, p0, Lnb;->X:Lkb;

    if-eqz p0, :cond_19

    invoke-virtual {p0}, Livb;->b()Z

    move-result v0

    if-eqz v0, :cond_19

    iget-object p0, p0, Livb;->i:Lgvb;

    invoke-interface {p0}, Lhzg;->dismiss()V

    :cond_19
    return-void
.end method

.method public final onLayout(ZIIII)V
    .registers 23

    move-object/from16 v0, p0

    iget-boolean v1, v0, Landroidx/appcompat/widget/ActionMenuView;->c0:Z

    if-nez v1, :cond_a

    invoke-super/range {p0 .. p5}, Lija;->onLayout(ZIIII)V

    return-void

    :cond_a
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    sub-int v2, p5, p3

    div-int/lit8 v2, v2, 0x2

    invoke-virtual {v0}, Lija;->getDividerWidth()I

    move-result v3

    sub-int v4, p4, p2

    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    sub-int v5, v4, v5

    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v6

    sub-int/2addr v5, v6

    sget-boolean v6, Lmnj;->a:Z

    invoke-virtual {v0}, Landroid/view/View;->getLayoutDirection()I

    move-result v6

    const/4 v7, 0x1

    if-ne v6, v7, :cond_2e

    move v6, v7

    goto :goto_2f

    :cond_2e
    const/4 v6, 0x0

    :goto_2f
    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_32
    const/16 v12, 0x8

    if-ge v9, v1, :cond_94

    invoke-virtual {v0, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    move-result v14

    if-ne v14, v12, :cond_41

    goto :goto_91

    :cond_41
    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v12

    check-cast v12, Lpb;

    iget-boolean v14, v12, Lpb;->a:Z

    if-eqz v14, :cond_81

    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v10

    invoke-virtual {v0, v9}, Landroidx/appcompat/widget/ActionMenuView;->k(I)Z

    move-result v14

    if-eqz v14, :cond_56

    add-int/2addr v10, v3

    :cond_56
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    move-result v14

    if-eqz v6, :cond_66

    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v15

    iget v12, v12, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v15, v12

    add-int v12, v15, v10

    goto :goto_76

    :cond_66
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v15

    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    move-result v16

    sub-int v15, v15, v16

    iget v12, v12, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    sub-int v12, v15, v12

    sub-int v15, v12, v10

    :goto_76
    div-int/lit8 v16, v14, 0x2

    sub-int v8, v2, v16

    add-int/2addr v14, v8

    invoke-virtual {v13, v15, v8, v12, v14}, Landroid/view/View;->layout(IIII)V

    sub-int/2addr v5, v10

    move v10, v7

    goto :goto_91

    :cond_81
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v8

    iget v13, v12, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v8, v13

    iget v12, v12, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v8, v12

    sub-int/2addr v5, v8

    invoke-virtual {v0, v9}, Landroidx/appcompat/widget/ActionMenuView;->k(I)Z

    add-int/lit8 v11, v11, 0x1

    :goto_91
    add-int/lit8 v9, v9, 0x1

    goto :goto_32

    :cond_94
    if-ne v1, v7, :cond_b3

    if-nez v10, :cond_b3

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    div-int/lit8 v4, v4, 0x2

    div-int/lit8 v5, v1, 0x2

    sub-int/2addr v4, v5

    div-int/lit8 v5, v3, 0x2

    sub-int/2addr v2, v5

    add-int/2addr v1, v4

    add-int/2addr v3, v2

    invoke-virtual {v0, v4, v2, v1, v3}, Landroid/view/View;->layout(IIII)V

    return-void

    :cond_b3
    xor-int/lit8 v3, v10, 0x1

    sub-int/2addr v11, v3

    if-lez v11, :cond_bc

    div-int v3, v5, v11

    :goto_ba
    const/4 v4, 0x0

    goto :goto_be

    :cond_bc
    const/4 v3, 0x0

    goto :goto_ba

    :goto_be
    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    if-eqz v6, :cond_102

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v5

    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    move-result v6

    sub-int/2addr v5, v6

    move v8, v4

    :goto_ce
    if-ge v8, v1, :cond_13c

    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Lpb;

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v7

    if-eq v7, v12, :cond_ff

    iget-boolean v7, v6, Lpb;->a:Z

    if-eqz v7, :cond_e5

    goto :goto_ff

    :cond_e5
    iget v7, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    sub-int/2addr v5, v7

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v7

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v9

    div-int/lit8 v10, v9, 0x2

    sub-int v10, v2, v10

    sub-int v11, v5, v7

    add-int/2addr v9, v10

    invoke-virtual {v4, v11, v10, v5, v9}, Landroid/view/View;->layout(IIII)V

    iget v4, v6, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v7, v4

    add-int/2addr v7, v3

    sub-int/2addr v5, v7

    :cond_ff
    :goto_ff
    add-int/lit8 v8, v8, 0x1

    goto :goto_ce

    :cond_102
    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v5

    move v8, v4

    :goto_107
    if-ge v8, v1, :cond_13c

    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Lpb;

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v7

    if-eq v7, v12, :cond_139

    iget-boolean v7, v6, Lpb;->a:Z

    if-eqz v7, :cond_11e

    goto :goto_139

    :cond_11e
    iget v7, v6, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v5, v7

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v7

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v9

    div-int/lit8 v10, v9, 0x2

    sub-int v10, v2, v10

    add-int v11, v5, v7

    add-int/2addr v9, v10

    invoke-virtual {v4, v5, v10, v11, v9}, Landroid/view/View;->layout(IIII)V

    iget v4, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v7, v4

    add-int/2addr v7, v3

    add-int/2addr v7, v5

    move v5, v7

    :cond_139
    :goto_139
    add-int/lit8 v8, v8, 0x1

    goto :goto_107

    :cond_13c
    return-void
.end method

.method public final onMeasure(II)V
    .registers 33

    move-object/from16 v0, p0

    iget-boolean v1, v0, Landroidx/appcompat/widget/ActionMenuView;->c0:Z

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/high16 v5, 0x40000000  # 2.0f

    if-ne v2, v5, :cond_10

    move v2, v3

    goto :goto_11

    :cond_10
    move v2, v4

    :goto_11
    iput-boolean v2, v0, Landroidx/appcompat/widget/ActionMenuView;->c0:Z

    if-eq v1, v2, :cond_17

    iput v4, v0, Landroidx/appcompat/widget/ActionMenuView;->d0:I

    :cond_17
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    iget-boolean v2, v0, Landroidx/appcompat/widget/ActionMenuView;->c0:Z

    if-eqz v2, :cond_2c

    iget-object v2, v0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    if-eqz v2, :cond_2c

    iget v6, v0, Landroidx/appcompat/widget/ActionMenuView;->d0:I

    if-eq v1, v6, :cond_2c

    iput v1, v0, Landroidx/appcompat/widget/ActionMenuView;->d0:I

    invoke-virtual {v2, v3}, Lpub;->p(Z)V

    :cond_2c
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    iget-boolean v2, v0, Landroidx/appcompat/widget/ActionMenuView;->c0:Z

    if-eqz v2, :cond_2fb

    if-lez v1, :cond_2fb

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v2

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v6

    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v7

    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    move-result v8

    add-int/2addr v8, v7

    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    move-result v7

    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    move-result v9

    add-int/2addr v9, v7

    const/4 v7, -0x2

    move/from16 v10, p2

    invoke-static {v10, v9, v7}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v7

    sub-int/2addr v2, v8

    iget v8, v0, Landroidx/appcompat/widget/ActionMenuView;->e0:I

    div-int v10, v2, v8

    rem-int v11, v2, v8

    if-nez v10, :cond_68

    invoke-virtual {v0, v2, v4}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void

    :cond_68
    div-int/2addr v11, v10

    add-int/2addr v11, v8

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    move v3, v4

    move v12, v3

    move v13, v12

    move v14, v13

    move v15, v14

    move/from16 v16, v15

    const-wide/16 p1, 0x0

    const-wide/16 v18, 0x0

    :goto_79
    iget v5, v0, Landroidx/appcompat/widget/ActionMenuView;->f0:I

    if-ge v14, v8, :cond_166

    invoke-virtual {v0, v14}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    move/from16 v21, v6

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v6

    move/from16 v22, v9

    const/16 v9, 0x8

    if-ne v6, v9, :cond_91

    move/from16 v23, v11

    goto/16 :goto_15b

    :cond_91
    instance-of v6, v4, Landroidx/appcompat/view/menu/ActionMenuItemView;

    add-int/lit8 v12, v12, 0x1

    const/4 v9, 0x0

    if-eqz v6, :cond_9b

    invoke-virtual {v4, v5, v9, v5, v9}, Landroid/view/View;->setPadding(IIII)V

    :cond_9b
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Lpb;

    iput-boolean v9, v5, Lpb;->f:Z

    iput v9, v5, Lpb;->c:I

    iput v9, v5, Lpb;->b:I

    iput-boolean v9, v5, Lpb;->d:Z

    iput v9, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iput v9, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    if-eqz v6, :cond_be

    move-object v9, v4

    check-cast v9, Landroidx/appcompat/view/menu/ActionMenuItemView;

    invoke-virtual {v9}, Llj0;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_be

    const/4 v9, 0x1

    goto :goto_bf

    :cond_be
    const/4 v9, 0x0

    :goto_bf
    iput-boolean v9, v5, Lpb;->e:Z

    iget-boolean v9, v5, Lpb;->a:Z

    if-eqz v9, :cond_c7

    const/4 v9, 0x1

    goto :goto_c8

    :cond_c7
    move v9, v10

    :goto_c8
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v23

    move/from16 v24, v6

    move-object/from16 v6, v23

    check-cast v6, Lpb;

    invoke-static {v7}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v23

    move/from16 v25, v10

    sub-int v10, v23, v22

    move/from16 v23, v11

    invoke-static {v7}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v11

    invoke-static {v10, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v10

    if-eqz v24, :cond_ea

    move-object v11, v4

    check-cast v11, Landroidx/appcompat/view/menu/ActionMenuItemView;

    goto :goto_eb

    :cond_ea
    const/4 v11, 0x0

    :goto_eb
    if-eqz v11, :cond_f9

    invoke-virtual {v11}, Llj0;->getText()Ljava/lang/CharSequence;

    move-result-object v11

    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_f9

    const/4 v11, 0x1

    goto :goto_fa

    :cond_f9
    const/4 v11, 0x0

    :goto_fa
    move/from16 v24, v11

    if-lez v9, :cond_121

    if-eqz v11, :cond_103

    const/4 v11, 0x2

    if-lt v9, v11, :cond_121

    :cond_103
    mul-int v11, v23, v9

    const/high16 v9, -0x80000000

    invoke-static {v11, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v9

    invoke-virtual {v4, v9, v10}, Landroid/view/View;->measure(II)V

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v9

    div-int v11, v9, v23

    rem-int v9, v9, v23

    if-eqz v9, :cond_11a

    add-int/lit8 v11, v11, 0x1

    :cond_11a
    if-eqz v24, :cond_122

    const/4 v9, 0x2

    if-ge v11, v9, :cond_122

    const/4 v11, 0x2

    goto :goto_122

    :cond_121
    const/4 v11, 0x0

    :cond_122
    :goto_122
    iget-boolean v9, v6, Lpb;->a:Z

    if-nez v9, :cond_12a

    if-eqz v24, :cond_12a

    const/4 v9, 0x1

    goto :goto_12b

    :cond_12a
    const/4 v9, 0x0

    :goto_12b
    iput-boolean v9, v6, Lpb;->d:Z

    iput v11, v6, Lpb;->b:I

    mul-int v6, v11, v23

    const/high16 v9, 0x40000000  # 2.0f

    invoke-static {v6, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    invoke-virtual {v4, v6, v10}, Landroid/view/View;->measure(II)V

    invoke-static {v13, v11}, Ljava/lang/Math;->max(II)I

    move-result v13

    iget-boolean v6, v5, Lpb;->d:Z

    if-eqz v6, :cond_144

    add-int/lit8 v16, v16, 0x1

    :cond_144
    iget-boolean v5, v5, Lpb;->a:Z

    if-eqz v5, :cond_149

    const/4 v15, 0x1

    :cond_149
    sub-int v10, v25, v11

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    const/4 v4, 0x1

    if-ne v11, v4, :cond_15b

    shl-int v5, v4, v14

    int-to-long v4, v5

    or-long v18, v18, v4

    :cond_15b
    :goto_15b
    add-int/lit8 v14, v14, 0x1

    move/from16 v6, v21

    move/from16 v9, v22

    move/from16 v11, v23

    const/4 v4, 0x0

    goto/16 :goto_79

    :cond_166
    move/from16 v21, v6

    move/from16 v25, v10

    move/from16 v23, v11

    if-eqz v15, :cond_173

    const/4 v9, 0x2

    if-ne v12, v9, :cond_173

    const/4 v4, 0x1

    goto :goto_174

    :cond_173
    const/4 v4, 0x0

    :goto_174
    move/from16 v10, v25

    const/4 v6, 0x0

    :goto_177
    const-wide/16 v24, 0x1

    if-lez v16, :cond_208

    if-lez v10, :cond_208

    const v9, 0x7fffffff

    move-wide/from16 v26, p1

    const/4 v11, 0x0

    const/4 v14, 0x0

    :goto_184
    if-ge v14, v8, :cond_1b4

    invoke-virtual {v0, v14}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v22

    move/from16 v28, v3

    move-object/from16 v3, v22

    check-cast v3, Lpb;

    move/from16 v22, v4

    iget-boolean v4, v3, Lpb;->d:Z

    if-nez v4, :cond_19b

    goto :goto_1ad

    :cond_19b
    iget v3, v3, Lpb;->b:I

    if-ge v3, v9, :cond_1a4

    shl-long v26, v24, v14

    move v9, v3

    const/4 v11, 0x1

    goto :goto_1ad

    :cond_1a4
    if-ne v3, v9, :cond_1ad

    shl-long v3, v24, v14

    or-long v26, v26, v3

    add-int/lit8 v3, v11, 0x1

    move v11, v3

    :cond_1ad
    :goto_1ad
    add-int/lit8 v14, v14, 0x1

    move/from16 v4, v22

    move/from16 v3, v28

    goto :goto_184

    :cond_1b4
    move/from16 v28, v3

    move/from16 v22, v4

    or-long v18, v18, v26

    if-le v11, v10, :cond_1bf

    :goto_1bc
    move/from16 v29, v15

    goto :goto_20b

    :cond_1bf
    add-int/lit8 v9, v9, 0x1

    const/4 v3, 0x0

    :goto_1c2
    if-ge v3, v8, :cond_201

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Lpb;

    const/16 v17, 0x1

    shl-int v11, v17, v3

    move/from16 v29, v15

    int-to-long v14, v11

    and-long v24, v26, v14

    cmp-long v11, v24, p1

    if-nez v11, :cond_1e2

    iget v4, v6, Lpb;->b:I

    if-ne v4, v9, :cond_1fc

    or-long v18, v18, v14

    goto :goto_1fc

    :cond_1e2
    if-eqz v22, :cond_1f2

    iget-boolean v11, v6, Lpb;->e:Z

    if-eqz v11, :cond_1f2

    const/4 v11, 0x1

    if-ne v10, v11, :cond_1f3

    add-int v14, v5, v23

    const/4 v15, 0x0

    invoke-virtual {v4, v14, v15, v5, v15}, Landroid/view/View;->setPadding(IIII)V

    goto :goto_1f3

    :cond_1f2
    const/4 v11, 0x1

    :cond_1f3
    :goto_1f3
    iget v4, v6, Lpb;->b:I

    add-int/2addr v4, v11

    iput v4, v6, Lpb;->b:I

    iput-boolean v11, v6, Lpb;->f:Z

    add-int/lit8 v10, v10, -0x1

    :cond_1fc
    :goto_1fc
    add-int/lit8 v3, v3, 0x1

    move/from16 v15, v29

    goto :goto_1c2

    :cond_201
    move/from16 v4, v22

    move/from16 v3, v28

    const/4 v6, 0x1

    goto/16 :goto_177

    :cond_208
    move/from16 v28, v3

    goto :goto_1bc

    :goto_20b
    const/4 v4, 0x1

    if-nez v29, :cond_212

    if-ne v12, v4, :cond_212

    move v3, v4

    goto :goto_213

    :cond_212
    const/4 v3, 0x0

    :goto_213
    if-lez v10, :cond_2c5

    cmp-long v5, v18, p1

    if-eqz v5, :cond_2c5

    sub-int/2addr v12, v4

    if-lt v10, v12, :cond_220

    if-nez v3, :cond_220

    if-le v13, v4, :cond_2c5

    :cond_220
    invoke-static/range {v18 .. v19}, Ljava/lang/Long;->bitCount(J)I

    move-result v4

    int-to-float v4, v4

    if-nez v3, :cond_25b

    and-long v11, v18, v24

    cmp-long v3, v11, p1

    const/high16 v5, 0x3f000000  # 0.5f

    if-eqz v3, :cond_23f

    const/4 v15, 0x0

    invoke-virtual {v0, v15}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Lpb;

    iget-boolean v3, v3, Lpb;->e:Z

    if-nez v3, :cond_23f

    sub-float/2addr v4, v5

    :cond_23f
    add-int/lit8 v3, v8, -0x1

    const/16 v17, 0x1

    shl-int v9, v17, v3

    int-to-long v11, v9

    and-long v11, v18, v11

    cmp-long v9, v11, p1

    if-eqz v9, :cond_25b

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Lpb;

    iget-boolean v3, v3, Lpb;->e:Z

    if-nez v3, :cond_25b

    sub-float/2addr v4, v5

    :cond_25b
    const/4 v3, 0x0

    cmpl-float v3, v4, v3

    if-lez v3, :cond_266

    mul-int v10, v10, v23

    int-to-float v3, v10

    div-float/2addr v3, v4

    float-to-int v9, v3

    goto :goto_267

    :cond_266
    const/4 v9, 0x0

    :goto_267
    move v4, v6

    const/4 v3, 0x0

    :goto_269
    if-ge v3, v8, :cond_2c4

    const/16 v17, 0x1

    shl-int v5, v17, v3

    int-to-long v5, v5

    and-long v5, v18, v5

    cmp-long v5, v5, p1

    if-nez v5, :cond_27a

    const/4 v11, 0x1

    const/16 v20, 0x2

    goto :goto_2c1

    :cond_27a
    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Lpb;

    instance-of v5, v5, Landroidx/appcompat/view/menu/ActionMenuItemView;

    if-eqz v5, :cond_2a0

    iput v9, v6, Lpb;->c:I

    const/4 v4, 0x1

    iput-boolean v4, v6, Lpb;->f:Z

    if-nez v3, :cond_29b

    iget-boolean v4, v6, Lpb;->e:Z

    if-nez v4, :cond_29b

    neg-int v4, v9

    const/16 v20, 0x2

    div-int/lit8 v4, v4, 0x2

    iput v4, v6, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    goto :goto_29d

    :cond_29b
    const/16 v20, 0x2

    :goto_29d
    const/4 v4, 0x1

    const/4 v11, 0x1

    goto :goto_2c1

    :cond_2a0
    const/16 v20, 0x2

    iget-boolean v5, v6, Lpb;->a:Z

    if-eqz v5, :cond_2b2

    iput v9, v6, Lpb;->c:I

    const/4 v11, 0x1

    iput-boolean v11, v6, Lpb;->f:Z

    neg-int v4, v9

    div-int/lit8 v4, v4, 0x2

    iput v4, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    move v4, v11

    goto :goto_2c1

    :cond_2b2
    const/4 v11, 0x1

    if-eqz v3, :cond_2b9

    div-int/lit8 v5, v9, 0x2

    iput v5, v6, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_2b9
    add-int/lit8 v5, v8, -0x1

    if-eq v3, v5, :cond_2c1

    div-int/lit8 v5, v9, 0x2

    iput v5, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    :cond_2c1
    :goto_2c1
    add-int/lit8 v3, v3, 0x1

    goto :goto_269

    :cond_2c4
    move v6, v4

    :cond_2c5
    if-eqz v6, :cond_2ee

    const/4 v4, 0x0

    :goto_2c8
    if-ge v4, v8, :cond_2ee

    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Lpb;

    iget-boolean v6, v5, Lpb;->f:Z

    if-nez v6, :cond_2db

    const/high16 v9, 0x40000000  # 2.0f

    goto :goto_2eb

    :cond_2db
    iget v6, v5, Lpb;->b:I

    mul-int v6, v6, v23

    iget v5, v5, Lpb;->c:I

    add-int/2addr v6, v5

    const/high16 v9, 0x40000000  # 2.0f

    invoke-static {v6, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    invoke-virtual {v3, v5, v7}, Landroid/view/View;->measure(II)V

    :goto_2eb
    add-int/lit8 v4, v4, 0x1

    goto :goto_2c8

    :cond_2ee
    const/high16 v9, 0x40000000  # 2.0f

    if-eq v1, v9, :cond_2f5

    move/from16 v6, v28

    goto :goto_2f7

    :cond_2f5
    move/from16 v6, v21

    :goto_2f7
    invoke-virtual {v0, v2, v6}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void

    :cond_2fb
    move/from16 v10, p2

    const/4 v9, 0x0

    :goto_2fe
    if-ge v9, v1, :cond_312

    invoke-virtual {v0, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Lpb;

    const/4 v15, 0x0

    iput v15, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    iput v15, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/lit8 v9, v9, 0x1

    goto :goto_2fe

    :cond_312
    invoke-super/range {p0 .. p2}, Lija;->onMeasure(II)V

    return-void
.end method

.method public setExpandedActionViewsExclusive(Z)V
    .registers 2

    iget-object p0, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    iput-boolean p1, p0, Lnb;->U:Z

    return-void
.end method

.method public setOnMenuItemClickListener(Lqb;)V
    .registers 2

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->g0:Lqb;

    return-void
.end method

.method public setOverflowIcon(Landroid/graphics/drawable/Drawable;)V
    .registers 3

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->getMenu()Landroid/view/Menu;

    iget-object p0, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    iget-object v0, p0, Lnb;->M:Lmb;

    if-eqz v0, :cond_d

    invoke-virtual {v0, p1}, Lji0;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void

    :cond_d
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnb;->O:Z

    iput-object p1, p0, Lnb;->N:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public setOverflowReserved(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuView;->W:Z

    return-void
.end method

.method public setPopupTheme(I)V
    .registers 4

    iget v0, p0, Landroidx/appcompat/widget/ActionMenuView;->V:I

    if-eq v0, p1, :cond_1a

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuView;->V:I

    if-nez p1, :cond_f

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->U:Landroid/content/Context;

    return-void

    :cond_f
    new-instance v0, Landroid/view/ContextThemeWrapper;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->U:Landroid/content/Context;

    :cond_1a
    return-void
.end method

.method public setPresenter(Lnb;)V
    .registers 2

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->a0:Lnb;

    iput-object p0, p1, Lnb;->L:Lsvb;

    iget-object p1, p1, Lnb;->G:Lpub;

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->T:Lpub;

    return-void
.end method
