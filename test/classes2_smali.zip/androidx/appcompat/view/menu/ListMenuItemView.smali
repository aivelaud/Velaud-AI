.class public Landroidx/appcompat/view/menu/ListMenuItemView;
.super Landroid/widget/LinearLayout;
.source "SourceFile"

# interfaces
.implements Lrvb;
.implements Landroid/widget/AbsListView$SelectionBoundsAdjuster;


# instance fields
.field public E:Luub;

.field public F:Landroid/widget/ImageView;

.field public G:Landroid/widget/RadioButton;

.field public H:Landroid/widget/TextView;

.field public I:Landroid/widget/CheckBox;

.field public J:Landroid/widget/TextView;

.field public K:Landroid/widget/ImageView;

.field public L:Landroid/widget/ImageView;

.field public M:Landroid/widget/LinearLayout;

.field public final N:Landroid/graphics/drawable/Drawable;

.field public final O:I

.field public final P:Landroid/content/Context;

.field public Q:Z

.field public final R:Landroid/graphics/drawable/Drawable;

.field public final S:Z

.field public T:Landroid/view/LayoutInflater;

.field public U:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const v0, 0x7f0402b9

    .line 82
    invoke-direct {p0, p1, p2, v0}, Landroidx/appcompat/view/menu/ListMenuItemView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 7

    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lbme;->r:[I

    invoke-static {v0, p2, v1, p3}, Lq8b;->J(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lq8b;

    move-result-object p2

    const/4 p3, 0x5

    invoke-virtual {p2, p3}, Lq8b;->r(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    iput-object p3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->N:Landroid/graphics/drawable/Drawable;

    iget-object p3, p2, Lq8b;->G:Ljava/lang/Object;

    check-cast p3, Landroid/content/res/TypedArray;

    const/4 v0, 0x1

    const/4 v1, -0x1

    invoke-virtual {p3, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->O:I

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p3, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    iput-boolean p3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->Q:Z

    iput-object p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->P:Landroid/content/Context;

    const/16 p3, 0x8

    invoke-virtual {p2, p3}, Lq8b;->r(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    iput-object p3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const p3, 0x1010129

    filled-new-array {p3}, [I

    move-result-object p3

    const v0, 0x7f04018b

    const/4 v2, 0x0

    invoke-virtual {p1, v2, p3, v0, v1}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p3

    iput-boolean p3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->S:Z

    invoke-virtual {p2}, Lq8b;->M()V

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method

.method private getInflater()Landroid/view/LayoutInflater;
    .registers 2

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->T:Landroid/view/LayoutInflater;

    if-nez v0, :cond_e

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->T:Landroid/view/LayoutInflater;

    :cond_e
    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->T:Landroid/view/LayoutInflater;

    return-object p0
.end method

.method private setSubMenuArrowVisible(Z)V
    .registers 2

    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:Landroid/widget/ImageView;

    if-eqz p0, :cond_d

    if-eqz p1, :cond_8

    const/4 p1, 0x0

    goto :goto_a

    :cond_8
    const/16 p1, 0x8

    :goto_a
    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_d
    return-void
.end method


# virtual methods
.method public final a(Luub;)V
    .registers 12

    iput-object p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    invoke-virtual {p1}, Luub;->isVisible()Z

    move-result v0

    iget-object v1, p1, Luub;->n:Lpub;

    const/16 v2, 0x8

    const/4 v3, 0x0

    if-eqz v0, :cond_f

    move v0, v3

    goto :goto_10

    :cond_f
    move v0, v2

    :goto_10
    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p1, Luub;->e:Ljava/lang/CharSequence;

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/ListMenuItemView;->setTitle(Ljava/lang/CharSequence;)V

    invoke-virtual {p1}, Luub;->isCheckable()Z

    move-result v0

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/ListMenuItemView;->setCheckable(Z)V

    invoke-virtual {v1}, Lpub;->o()Z

    move-result v0

    const/4 v4, 0x1

    if-eqz v0, :cond_35

    invoke-virtual {v1}, Lpub;->n()Z

    move-result v0

    if-eqz v0, :cond_2f

    iget-char v0, p1, Luub;->j:C

    goto :goto_31

    :cond_2f
    iget-char v0, p1, Luub;->h:C

    :goto_31
    if-eqz v0, :cond_35

    move v0, v4

    goto :goto_36

    :cond_35
    move v0, v3

    :goto_36
    invoke-virtual {v1}, Lpub;->n()Z

    if-eqz v0, :cond_53

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    iget-object v1, v0, Luub;->n:Lpub;

    invoke-virtual {v1}, Lpub;->o()Z

    move-result v5

    if-eqz v5, :cond_53

    invoke-virtual {v1}, Lpub;->n()Z

    move-result v1

    if-eqz v1, :cond_4e

    iget-char v0, v0, Luub;->j:C

    goto :goto_50

    :cond_4e
    iget-char v0, v0, Luub;->h:C

    :goto_50
    if-eqz v0, :cond_53

    goto :goto_54

    :cond_53
    move v3, v2

    :goto_54
    if-nez v3, :cond_10e

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->J:Landroid/widget/TextView;

    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    iget-object v5, v1, Luub;->n:Lpub;

    iget-object v6, v5, Lpub;->a:Landroid/content/Context;

    invoke-virtual {v5}, Lpub;->n()Z

    move-result v7

    if-eqz v7, :cond_67

    iget-char v7, v1, Luub;->j:C

    goto :goto_69

    :cond_67
    iget-char v7, v1, Luub;->h:C

    :goto_69
    if-nez v7, :cond_6f

    const-string v1, ""

    goto/16 :goto_10b

    :cond_6f
    invoke-virtual {v6}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v6}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/ViewConfiguration;->hasPermanentMenuKey()Z

    move-result v6

    if-eqz v6, :cond_8c

    const v6, 0x7f120013

    invoke-virtual {v8, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_8c
    invoke-virtual {v5}, Lpub;->n()Z

    move-result v5

    if-eqz v5, :cond_95

    iget v1, v1, Luub;->k:I

    goto :goto_97

    :cond_95
    iget v1, v1, Luub;->i:I

    :goto_97
    const v5, 0x7f12000f

    invoke-virtual {v8, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/high16 v6, 0x10000

    invoke-static {v9, v1, v6, v5}, Luub;->c(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const v5, 0x7f12000b

    invoke-virtual {v8, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x1000

    invoke-static {v9, v1, v6, v5}, Luub;->c(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const v5, 0x7f12000a

    invoke-virtual {v8, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x2

    invoke-static {v9, v1, v6, v5}, Luub;->c(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const v5, 0x7f120010

    invoke-virtual {v8, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v9, v1, v4, v5}, Luub;->c(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const v4, 0x7f120012

    invoke-virtual {v8, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x4

    invoke-static {v9, v1, v5, v4}, Luub;->c(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const v4, 0x7f12000e

    invoke-virtual {v8, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v9, v1, v2, v4}, Luub;->c(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    if-eq v7, v2, :cond_fd

    const/16 v1, 0xa

    if-eq v7, v1, :cond_f2

    const/16 v1, 0x20

    if-eq v7, v1, :cond_e7

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_107

    :cond_e7
    const v1, 0x7f120011

    invoke-virtual {v8, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_107

    :cond_f2
    const v1, 0x7f12000d

    invoke-virtual {v8, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_107

    :cond_fd
    const v1, 0x7f12000c

    invoke-virtual {v8, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_107
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_10b
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_10e
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->J:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-eq v0, v3, :cond_11b

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->J:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_11b
    invoke-virtual {p1}, Luub;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/ListMenuItemView;->setIcon(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p1}, Luub;->isEnabled()Z

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {p1}, Luub;->hasSubMenu()Z

    move-result v0

    invoke-direct {p0, v0}, Landroidx/appcompat/view/menu/ListMenuItemView;->setSubMenuArrowVisible(Z)V

    iget-object p1, p1, Luub;->q:Ljava/lang/CharSequence;

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final adjustListItemSelectionBounds(Landroid/graphics/Rect;)V
    .registers 5

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/ImageView;

    if-eqz v0, :cond_23

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_23

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    iget v1, p1, Landroid/graphics/Rect;->top:I

    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/ImageView;

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p0

    iget v2, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr p0, v2

    iget v0, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr p0, v0

    add-int/2addr p0, v1

    iput p0, p1, Landroid/graphics/Rect;->top:I

    :cond_23
    return-void
.end method

.method public getItemData()Luub;
    .registers 1

    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    return-object p0
.end method

.method public final onFinishInflate()V
    .registers 4

    invoke-super {p0}, Landroid/view/View;->onFinishInflate()V

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->N:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const v0, 0x7f0a044c

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->H:Landroid/widget/TextView;

    const/4 v1, -0x1

    iget v2, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->O:I

    if-eq v2, v1, :cond_1d

    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->P:Landroid/content/Context;

    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V

    :cond_1d
    const v0, 0x7f0a0400

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->J:Landroid/widget/TextView;

    const v0, 0x7f0a0424

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:Landroid/widget/ImageView;

    if-eqz v0, :cond_3a

    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_3a
    const v0, 0x7f0a032b

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/ImageView;

    const v0, 0x7f0a00e3

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->M:Landroid/widget/LinearLayout;

    return-void
.end method

.method public final onMeasure(II)V
    .registers 6

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    if-eqz v0, :cond_1e

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->Q:Z

    if-eqz v0, :cond_1e

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    iget v0, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-lez v0, :cond_1e

    iget v2, v1, Landroid/widget/LinearLayout$LayoutParams;->width:I

    if-gtz v2, :cond_1e

    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->width:I

    :cond_1e
    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    return-void
.end method

.method public setCheckable(Z)V
    .registers 6

    if-nez p1, :cond_c

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    if-nez v0, :cond_c

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    if-nez v0, :cond_c

    goto/16 :goto_8b

    :cond_c
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    iget v0, v0, Luub;->x:I

    and-int/lit8 v0, v0, 0x4

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_39

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    if-nez v0, :cond_34

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ListMenuItemView;->getInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v3, 0x7f0d0011

    invoke-virtual {v0, v3, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->M:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_31

    invoke-virtual {v3, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    goto :goto_34

    :cond_31
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    :cond_34
    :goto_34
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    goto :goto_5b

    :cond_39
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    if-nez v0, :cond_57

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ListMenuItemView;->getInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v3, 0x7f0d000e

    invoke-virtual {v0, v3, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->M:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_54

    invoke-virtual {v3, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    goto :goto_57

    :cond_54
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    :cond_57
    :goto_57
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    :goto_5b
    const/16 v3, 0x8

    if-eqz p1, :cond_7d

    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    invoke-virtual {p0}, Luub;->isChecked()Z

    move-result p0

    invoke-virtual {v0, p0}, Landroid/widget/CompoundButton;->setChecked(Z)V

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result p0

    if-eqz p0, :cond_71

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_71
    if-eqz v1, :cond_8b

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result p0

    if-eq p0, v3, :cond_8b

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_7d
    iget-object p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    if-eqz p1, :cond_84

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_84
    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    if-eqz p0, :cond_8b

    invoke-virtual {p0, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_8b
    :goto_8b
    return-void
.end method

.method public setChecked(Z)V
    .registers 6

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    iget v0, v0, Luub;->x:I

    and-int/lit8 v0, v0, 0x4

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_2b

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    if-nez v0, :cond_28

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ListMenuItemView;->getInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v3, 0x7f0d0011

    invoke-virtual {v0, v3, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RadioButton;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    iget-object v2, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->M:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_25

    invoke-virtual {v2, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    goto :goto_28

    :cond_25
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    :cond_28
    :goto_28
    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->G:Landroid/widget/RadioButton;

    goto :goto_4b

    :cond_2b
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    if-nez v0, :cond_49

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ListMenuItemView;->getInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v3, 0x7f0d000e

    invoke-virtual {v0, v3, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    iget-object v2, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->M:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_46

    invoke-virtual {v2, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    goto :goto_49

    :cond_46
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    :cond_49
    :goto_49
    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->I:Landroid/widget/CheckBox;

    :goto_4b
    invoke-virtual {p0, p1}, Landroid/widget/CompoundButton;->setChecked(Z)V

    return-void
.end method

.method public setForceShowIcon(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->U:Z

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->Q:Z

    return-void
.end method

.method public setGroupDividerEnabled(Z)V
    .registers 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/ImageView;

    if-eqz v0, :cond_11

    iget-boolean p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->S:Z

    if-nez p0, :cond_c

    if-eqz p1, :cond_c

    const/4 p0, 0x0

    goto :goto_e

    :cond_c
    const/16 p0, 0x8

    :goto_e
    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_11
    return-void
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)V
    .registers 6

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Luub;

    iget-object v0, v0, Luub;->n:Lpub;

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->U:Z

    if-nez v0, :cond_d

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->Q:Z

    if-nez v1, :cond_d

    goto :goto_5a

    :cond_d
    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    if-nez v1, :cond_18

    if-nez p1, :cond_18

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->Q:Z

    if-nez v2, :cond_18

    goto :goto_5a

    :cond_18
    const/4 v2, 0x0

    if-nez v1, :cond_35

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ListMenuItemView;->getInflater()Landroid/view/LayoutInflater;

    move-result-object v1

    const v3, 0x7f0d000f

    invoke-virtual {v1, v3, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->M:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_32

    invoke-virtual {v3, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    goto :goto_35

    :cond_32
    invoke-virtual {p0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    :cond_35
    :goto_35
    if-nez p1, :cond_44

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->Q:Z

    if-eqz v1, :cond_3c

    goto :goto_44

    :cond_3c
    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    return-void

    :cond_44
    :goto_44
    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    if-eqz v0, :cond_49

    goto :goto_4a

    :cond_49
    const/4 p1, 0x0

    :goto_4a
    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-eqz p1, :cond_5a

    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/ImageView;

    invoke-virtual {p0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_5a
    :goto_5a
    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .registers 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->H:Landroid/widget/TextView;

    if-eqz p1, :cond_16

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->H:Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-eqz p1, :cond_23

    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->H:Landroid/widget/TextView;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_16
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/16 v0, 0x8

    if-eq p1, v0, :cond_23

    iget-object p0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->H:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_23
    return-void
.end method
