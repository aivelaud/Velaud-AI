.class public final Landroidx/health/platform/client/proto/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Layf;


# static fields
.field public static final m:[I

.field public static final n:Lsun/misc/Unsafe;


# instance fields
.field public final a:[I

.field public final b:[Ljava/lang/Object;

.field public final c:I

.field public final d:I

.field public final e:Landroidx/health/platform/client/proto/a;

.field public final f:[I

.field public final g:I

.field public final h:I

.field public final i:Lxjc;

.field public final j:Lema;

.field public final k:Landroidx/health/platform/client/proto/a0;

.field public final l:Lw5b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    new-array v0, v0, [I

    sput-object v0, Landroidx/health/platform/client/proto/p;->m:[I

    invoke-static {}, Lj5j;->j()Lsun/misc/Unsafe;

    move-result-object v0

    sput-object v0, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    return-void
.end method

.method public constructor <init>([I[Ljava/lang/Object;IILandroidx/health/platform/client/proto/a;[IIILxjc;Lema;Landroidx/health/platform/client/proto/a0;Lmm7;Lw5b;)V
    .registers 14

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/health/platform/client/proto/p;->a:[I

    iput-object p2, p0, Landroidx/health/platform/client/proto/p;->b:[Ljava/lang/Object;

    iput p3, p0, Landroidx/health/platform/client/proto/p;->c:I

    iput p4, p0, Landroidx/health/platform/client/proto/p;->d:I

    iput-object p6, p0, Landroidx/health/platform/client/proto/p;->f:[I

    iput p7, p0, Landroidx/health/platform/client/proto/p;->g:I

    iput p8, p0, Landroidx/health/platform/client/proto/p;->h:I

    iput-object p9, p0, Landroidx/health/platform/client/proto/p;->i:Lxjc;

    iput-object p10, p0, Landroidx/health/platform/client/proto/p;->j:Lema;

    iput-object p11, p0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    iput-object p5, p0, Landroidx/health/platform/client/proto/p;->e:Landroidx/health/platform/client/proto/a;

    iput-object p13, p0, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    return-void
.end method

.method public static D(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    .registers 7

    :try_start_0
    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0
    :try_end_4
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_4} :catch_5

    return-object p0

    :catch_5
    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_b
    if-ge v2, v1, :cond_1d

    aget-object v3, v0, v2

    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1a

    return-object v3

    :cond_1a
    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_1d
    new-instance v1, Ljava/lang/RuntimeException;

    const-string v2, "Field "

    const-string v3, " for "

    invoke-static {v2, p1, v3}, Ld07;->x(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " not found. Known fields are "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public static I(I)I
    .registers 2

    const/high16 v0, 0xff00000

    and-int/2addr p0, v0

    ushr-int/lit8 p0, p0, 0x14

    return p0
.end method

.method public static k([BIILu5k;Ljava/lang/Class;Lpq0;)I
    .registers 12

    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    move-result p3

    const/4 v0, 0x0

    packed-switch p3, :pswitch_data_ee

    :pswitch_8  #0x9
    const-string p0, "unsupported field type."

    invoke-static {p0}, Lgdg;->p(Ljava/lang/String;)V

    return v0

    :pswitch_e  #0x11
    invoke-static {p0, p1, p5}, Lckl;->p([BILpq0;)I

    move-result p0

    iget-wide p1, p5, Lpq0;->b:J

    invoke-static {p1, p2}, Lthl;->e(J)J

    move-result-wide p1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, p5, Lpq0;->c:Ljava/lang/Object;

    return p0

    :pswitch_1f  #0x10
    invoke-static {p0, p1, p5}, Lckl;->n([BILpq0;)I

    move-result p0

    iget p1, p5, Lpq0;->a:I

    invoke-static {p1}, Lthl;->d(I)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p5, Lpq0;->c:Ljava/lang/Object;

    return p0

    :pswitch_30  #0xb
    invoke-static {p0, p1, p5}, Lckl;->h([BILpq0;)I

    move-result p0

    return p0

    :pswitch_35  #0xa
    sget-object p3, Lmfe;->c:Lmfe;

    invoke-virtual {p3, p4}, Lmfe;->a(Ljava/lang/Class;)Layf;

    move-result-object v1

    invoke-interface {v1}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object v0

    move-object v2, p0

    move v3, p1

    move v4, p2

    move-object v5, p5

    invoke-static/range {v0 .. v5}, Lckl;->t(Ljava/lang/Object;Layf;[BIILpq0;)I

    move-result p0

    invoke-interface {v1, v0}, Layf;->b(Ljava/lang/Object;)V

    iput-object v0, v5, Lpq0;->c:Ljava/lang/Object;

    return p0

    :pswitch_4d  #0x8
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3, v5}, Lckl;->n([BILpq0;)I

    move-result p0

    iget p1, v5, Lpq0;->a:I

    if-ltz p1, :cond_69

    if-nez p1, :cond_5f

    const-string p1, ""

    iput-object p1, v5, Lpq0;->c:Ljava/lang/Object;

    return p0

    :cond_5f
    sget-object p2, Landroidx/health/platform/client/proto/d0;->a:Lval;

    invoke-virtual {p2, v2, p0, p1}, Lval;->e([BII)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v5, Lpq0;->c:Ljava/lang/Object;

    add-int/2addr p0, p1

    return p0

    :cond_69
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :pswitch_6e  #0x7
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3, v5}, Lckl;->p([BILpq0;)I

    move-result p0

    iget-wide p1, v5, Lpq0;->b:J

    const-wide/16 p3, 0x0

    cmp-long p1, p1, p3

    if-eqz p1, :cond_7e

    const/4 v0, 0x1

    :cond_7e
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iput-object p1, v5, Lpq0;->c:Ljava/lang/Object;

    return p0

    :pswitch_85  #0x6, 0xe
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3}, Lckl;->i([BI)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    iput-object p0, v5, Lpq0;->c:Ljava/lang/Object;

    add-int/lit8 p1, v3, 0x4

    return p1

    :pswitch_95  #0x5, 0xf
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3}, Lckl;->j([BI)J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    iput-object p0, v5, Lpq0;->c:Ljava/lang/Object;

    add-int/lit8 p1, v3, 0x8

    return p1

    :pswitch_a5  #0x4, 0xc, 0xd
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3, v5}, Lckl;->n([BILpq0;)I

    move-result p0

    iget p1, v5, Lpq0;->a:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, v5, Lpq0;->c:Ljava/lang/Object;

    return p0

    :pswitch_b5  #0x2, 0x3
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3, v5}, Lckl;->p([BILpq0;)I

    move-result p0

    iget-wide p1, v5, Lpq0;->b:J

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, v5, Lpq0;->c:Ljava/lang/Object;

    return p0

    :pswitch_c5  #0x1
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3}, Lckl;->i([BI)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    iput-object p0, v5, Lpq0;->c:Ljava/lang/Object;

    add-int/lit8 p1, v3, 0x4

    return p1

    :pswitch_d9  #0x0
    move-object v2, p0

    move v3, p1

    move-object v5, p5

    invoke-static {v2, v3}, Lckl;->j([BI)J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    iput-object p0, v5, Lpq0;->c:Ljava/lang/Object;

    add-int/lit8 p1, v3, 0x8

    return p1

    nop

    :pswitch_data_ee
    .packed-switch 0x0
        :pswitch_d9  #00000000
        :pswitch_c5  #00000001
        :pswitch_b5  #00000002
        :pswitch_b5  #00000003
        :pswitch_a5  #00000004
        :pswitch_95  #00000005
        :pswitch_85  #00000006
        :pswitch_6e  #00000007
        :pswitch_4d  #00000008
        :pswitch_8  #00000009
        :pswitch_35  #0000000a
        :pswitch_30  #0000000b
        :pswitch_a5  #0000000c
        :pswitch_a5  #0000000d
        :pswitch_85  #0000000e
        :pswitch_95  #0000000f
        :pswitch_1f  #00000010
        :pswitch_e  #00000011
    .end packed-switch
.end method

.method public static q(Ljava/lang/Object;)Z
    .registers 2

    if-nez p0, :cond_4

    const/4 p0, 0x0

    return p0

    :cond_4
    instance-of v0, p0, Landroidx/health/platform/client/proto/n;

    if-eqz v0, :cond_f

    check-cast p0, Landroidx/health/platform/client/proto/n;

    invoke-virtual {p0}, Landroidx/health/platform/client/proto/n;->i()Z

    move-result p0

    return p0

    :cond_f
    const/4 p0, 0x1

    return p0
.end method

.method public static w(Lmne;Lxjc;Lema;Landroidx/health/platform/client/proto/a0;Lmm7;Lw5b;)Landroidx/health/platform/client/proto/p;
    .registers 42

    move-object/from16 v0, p0

    iget-object v1, v0, Lmne;->b:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const v6, 0xd800

    if-lt v4, v6, :cond_1d

    const/4 v4, 0x1

    :goto_13
    add-int/lit8 v7, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_1e

    move v4, v7

    goto :goto_13

    :cond_1d
    const/4 v7, 0x1

    :cond_1e
    add-int/lit8 v4, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_3d

    and-int/lit16 v7, v7, 0x1fff

    const/16 v9, 0xd

    :goto_2a
    add-int/lit8 v10, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_3a

    and-int/lit16 v4, v4, 0x1fff

    shl-int/2addr v4, v9

    or-int/2addr v7, v4

    add-int/lit8 v9, v9, 0xd

    move v4, v10

    goto :goto_2a

    :cond_3a
    shl-int/2addr v4, v9

    or-int/2addr v7, v4

    move v4, v10

    :cond_3d
    if-nez v7, :cond_4d

    sget-object v7, Landroidx/health/platform/client/proto/p;->m:[I

    move v9, v3

    move v10, v9

    move v11, v10

    move v12, v11

    move v13, v12

    move/from16 v16, v13

    move-object v15, v7

    move/from16 v7, v16

    goto/16 :goto_160

    :cond_4d
    add-int/lit8 v7, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-lt v4, v6, :cond_6c

    and-int/lit16 v4, v4, 0x1fff

    const/16 v9, 0xd

    :goto_59
    add-int/lit8 v10, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_69

    and-int/lit16 v7, v7, 0x1fff

    shl-int/2addr v7, v9

    or-int/2addr v4, v7

    add-int/lit8 v9, v9, 0xd

    move v7, v10

    goto :goto_59

    :cond_69
    shl-int/2addr v7, v9

    or-int/2addr v4, v7

    move v7, v10

    :cond_6c
    add-int/lit8 v9, v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-lt v7, v6, :cond_8b

    and-int/lit16 v7, v7, 0x1fff

    const/16 v10, 0xd

    :goto_78
    add-int/lit8 v11, v9, 0x1

    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-lt v9, v6, :cond_88

    and-int/lit16 v9, v9, 0x1fff

    shl-int/2addr v9, v10

    or-int/2addr v7, v9

    add-int/lit8 v10, v10, 0xd

    move v9, v11

    goto :goto_78

    :cond_88
    shl-int/2addr v9, v10

    or-int/2addr v7, v9

    move v9, v11

    :cond_8b
    add-int/lit8 v10, v9, 0x1

    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-lt v9, v6, :cond_aa

    and-int/lit16 v9, v9, 0x1fff

    const/16 v11, 0xd

    :goto_97
    add-int/lit8 v12, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v6, :cond_a7

    and-int/lit16 v10, v10, 0x1fff

    shl-int/2addr v10, v11

    or-int/2addr v9, v10

    add-int/lit8 v11, v11, 0xd

    move v10, v12

    goto :goto_97

    :cond_a7
    shl-int/2addr v10, v11

    or-int/2addr v9, v10

    move v10, v12

    :cond_aa
    add-int/lit8 v11, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v6, :cond_c9

    and-int/lit16 v10, v10, 0x1fff

    const/16 v12, 0xd

    :goto_b6
    add-int/lit8 v13, v11, 0x1

    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v11

    if-lt v11, v6, :cond_c6

    and-int/lit16 v11, v11, 0x1fff

    shl-int/2addr v11, v12

    or-int/2addr v10, v11

    add-int/lit8 v12, v12, 0xd

    move v11, v13

    goto :goto_b6

    :cond_c6
    shl-int/2addr v11, v12

    or-int/2addr v10, v11

    move v11, v13

    :cond_c9
    add-int/lit8 v12, v11, 0x1

    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v11

    if-lt v11, v6, :cond_e8

    and-int/lit16 v11, v11, 0x1fff

    const/16 v13, 0xd

    :goto_d5
    add-int/lit8 v14, v12, 0x1

    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    if-lt v12, v6, :cond_e5

    and-int/lit16 v12, v12, 0x1fff

    shl-int/2addr v12, v13

    or-int/2addr v11, v12

    add-int/lit8 v13, v13, 0xd

    move v12, v14

    goto :goto_d5

    :cond_e5
    shl-int/2addr v12, v13

    or-int/2addr v11, v12

    move v12, v14

    :cond_e8
    add-int/lit8 v13, v12, 0x1

    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    if-lt v12, v6, :cond_107

    and-int/lit16 v12, v12, 0x1fff

    const/16 v14, 0xd

    :goto_f4
    add-int/lit8 v15, v13, 0x1

    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-lt v13, v6, :cond_104

    and-int/lit16 v13, v13, 0x1fff

    shl-int/2addr v13, v14

    or-int/2addr v12, v13

    add-int/lit8 v14, v14, 0xd

    move v13, v15

    goto :goto_f4

    :cond_104
    shl-int/2addr v13, v14

    or-int/2addr v12, v13

    move v13, v15

    :cond_107
    add-int/lit8 v14, v13, 0x1

    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-lt v13, v6, :cond_128

    and-int/lit16 v13, v13, 0x1fff

    const/16 v15, 0xd

    :goto_113
    add-int/lit8 v16, v14, 0x1

    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-lt v14, v6, :cond_124

    and-int/lit16 v14, v14, 0x1fff

    shl-int/2addr v14, v15

    or-int/2addr v13, v14

    add-int/lit8 v15, v15, 0xd

    move/from16 v14, v16

    goto :goto_113

    :cond_124
    shl-int/2addr v14, v15

    or-int/2addr v13, v14

    move/from16 v14, v16

    :cond_128
    add-int/lit8 v15, v14, 0x1

    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-lt v14, v6, :cond_14b

    and-int/lit16 v14, v14, 0x1fff

    const/16 v16, 0xd

    :goto_134
    add-int/lit8 v17, v15, 0x1

    invoke-virtual {v1, v15}, Ljava/lang/String;->charAt(I)C

    move-result v15

    if-lt v15, v6, :cond_146

    and-int/lit16 v15, v15, 0x1fff

    shl-int v15, v15, v16

    or-int/2addr v14, v15

    add-int/lit8 v16, v16, 0xd

    move/from16 v15, v17

    goto :goto_134

    :cond_146
    shl-int v15, v15, v16

    or-int/2addr v14, v15

    move/from16 v15, v17

    :cond_14b
    add-int v16, v14, v12

    add-int v13, v16, v13

    new-array v13, v13, [I

    mul-int/lit8 v16, v4, 0x2

    add-int v16, v16, v7

    move v7, v12

    move v12, v9

    move v9, v7

    move v7, v4

    move v4, v15

    move-object v15, v13

    move v13, v10

    move/from16 v10, v16

    move/from16 v16, v14

    :goto_160
    sget-object v14, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    iget-object v3, v0, Lmne;->c:[Ljava/lang/Object;

    iget-object v8, v0, Lmne;->a:Landroidx/health/platform/client/proto/a;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    mul-int/lit8 v5, v11, 0x3

    new-array v5, v5, [I

    const/4 v6, 0x2

    mul-int/2addr v11, v6

    new-array v11, v11, [Ljava/lang/Object;

    add-int v9, v16, v9

    move/from16 v24, v9

    move/from16 v23, v16

    const/4 v6, 0x0

    const/16 v21, 0x0

    :goto_17b
    if-ge v4, v2, :cond_408

    add-int/lit8 v25, v4, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    move/from16 v26, v2

    const v2, 0xd800

    if-lt v4, v2, :cond_1af

    and-int/lit16 v4, v4, 0x1fff

    move/from16 v2, v25

    const/16 v25, 0xd

    :goto_190
    add-int/lit8 v27, v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    move-object/from16 v28, v3

    const v3, 0xd800

    if-lt v2, v3, :cond_1a9

    and-int/lit16 v2, v2, 0x1fff

    shl-int v2, v2, v25

    or-int/2addr v4, v2

    add-int/lit8 v25, v25, 0xd

    move/from16 v2, v27

    move-object/from16 v3, v28

    goto :goto_190

    :cond_1a9
    shl-int v2, v2, v25

    or-int/2addr v4, v2

    move/from16 v2, v27

    goto :goto_1b3

    :cond_1af
    move-object/from16 v28, v3

    move/from16 v2, v25

    :goto_1b3
    add-int/lit8 v3, v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    move/from16 v25, v3

    const v3, 0xd800

    if-lt v2, v3, :cond_1e5

    and-int/lit16 v2, v2, 0x1fff

    move/from16 v3, v25

    const/16 v25, 0xd

    :goto_1c6
    add-int/lit8 v27, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    move/from16 v29, v2

    const v2, 0xd800

    if-lt v3, v2, :cond_1de

    and-int/lit16 v2, v3, 0x1fff

    shl-int v2, v2, v25

    or-int v2, v29, v2

    add-int/lit8 v25, v25, 0xd

    move/from16 v3, v27

    goto :goto_1c6

    :cond_1de
    shl-int v2, v3, v25

    or-int v2, v29, v2

    move/from16 v3, v27

    goto :goto_1e7

    :cond_1e5
    move/from16 v3, v25

    :goto_1e7
    move/from16 v25, v4

    and-int/lit16 v4, v2, 0xff

    move-object/from16 v27, v5

    and-int/lit16 v5, v2, 0x400

    if-eqz v5, :cond_1f7

    add-int/lit8 v5, v21, 0x1

    aput v6, v15, v21

    move/from16 v21, v5

    :cond_1f7
    const/16 v5, 0x33

    move/from16 v31, v7

    if-lt v4, v5, :cond_2b0

    add-int/lit8 v5, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const v7, 0xd800

    if-lt v3, v7, :cond_226

    and-int/lit16 v3, v3, 0x1fff

    const/16 v34, 0xd

    :goto_20c
    add-int/lit8 v35, v5, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-lt v5, v7, :cond_221

    and-int/lit16 v5, v5, 0x1fff

    shl-int v5, v5, v34

    or-int/2addr v3, v5

    add-int/lit8 v34, v34, 0xd

    move/from16 v5, v35

    const v7, 0xd800

    goto :goto_20c

    :cond_221
    shl-int v5, v5, v34

    or-int/2addr v3, v5

    move/from16 v5, v35

    :cond_226
    add-int/lit8 v7, v4, -0x33

    move/from16 v34, v3

    const/16 v3, 0x9

    if-eq v7, v3, :cond_232

    const/16 v3, 0x11

    if-ne v7, v3, :cond_238

    :cond_232
    move/from16 v29, v5

    const/4 v3, 0x3

    const/4 v5, 0x2

    const/4 v7, 0x1

    goto :goto_263

    :cond_238
    const/16 v3, 0xc

    if-ne v7, v3, :cond_261

    invoke-virtual {v0}, Lmne;->a()I

    move-result v3

    const/4 v7, 0x1

    invoke-static {v3, v7}, Ld07;->c(II)Z

    move-result v3

    if-nez v3, :cond_24b

    and-int/lit16 v3, v2, 0x800

    if-eqz v3, :cond_250

    :cond_24b
    move/from16 v29, v5

    const/4 v3, 0x3

    const/4 v5, 0x2

    goto :goto_254

    :cond_250
    :goto_250
    move/from16 v29, v5

    const/4 v5, 0x2

    goto :goto_26e

    :goto_254
    invoke-static {v6, v3, v5, v7}, Lti6;->e(IIII)I

    move-result v3

    add-int/lit8 v19, v10, 0x1

    aget-object v10, v28, v10

    aput-object v10, v11, v3

    move/from16 v10, v19

    goto :goto_26e

    :cond_261
    const/4 v7, 0x1

    goto :goto_250

    :goto_263
    invoke-static {v6, v3, v5, v7}, Lti6;->e(IIII)I

    move-result v3

    add-int/lit8 v7, v10, 0x1

    aget-object v10, v28, v10

    aput-object v10, v11, v3

    move v10, v7

    :goto_26e
    mul-int/lit8 v3, v34, 0x2

    aget-object v5, v28, v3

    instance-of v7, v5, Ljava/lang/reflect/Field;

    if-eqz v7, :cond_27c

    check-cast v5, Ljava/lang/reflect/Field;

    :goto_278
    move v7, v9

    move/from16 v30, v10

    goto :goto_285

    :cond_27c
    check-cast v5, Ljava/lang/String;

    invoke-static {v8, v5}, Landroidx/health/platform/client/proto/p;->D(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    aput-object v5, v28, v3

    goto :goto_278

    :goto_285
    invoke-virtual {v14, v5}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v5, v9

    add-int/lit8 v3, v3, 0x1

    aget-object v9, v28, v3

    instance-of v10, v9, Ljava/lang/reflect/Field;

    if-eqz v10, :cond_295

    check-cast v9, Ljava/lang/reflect/Field;

    goto :goto_29d

    :cond_295
    check-cast v9, Ljava/lang/String;

    invoke-static {v8, v9}, Landroidx/health/platform/client/proto/p;->D(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v9

    aput-object v9, v28, v3

    :goto_29d
    invoke-virtual {v14, v9}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v3, v9

    move-object/from16 v32, v1

    move v9, v5

    move v1, v6

    move/from16 v10, v29

    const/16 v22, 0x2

    move v5, v3

    move/from16 v29, v7

    const/4 v3, 0x0

    goto/16 :goto_3c5

    :cond_2b0
    move v7, v9

    add-int/lit8 v5, v10, 0x1

    aget-object v9, v28, v10

    check-cast v9, Ljava/lang/String;

    invoke-static {v8, v9}, Landroidx/health/platform/client/proto/p;->D(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v9

    move/from16 v34, v5

    const/16 v5, 0x9

    if-eq v4, v5, :cond_2c5

    const/16 v5, 0x11

    if-ne v4, v5, :cond_2cc

    :cond_2c5
    move/from16 v29, v7

    const/4 v5, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x2

    goto/16 :goto_345

    :cond_2cc
    const/16 v5, 0x1b

    if-eq v4, v5, :cond_2d4

    const/16 v5, 0x31

    if-ne v4, v5, :cond_2dc

    :cond_2d4
    move/from16 v29, v7

    move/from16 v19, v10

    const/4 v5, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x2

    goto :goto_33a

    :cond_2dc
    const/16 v5, 0xc

    if-eq v4, v5, :cond_31c

    const/16 v5, 0x1e

    if-eq v4, v5, :cond_31c

    const/16 v5, 0x2c

    if-ne v4, v5, :cond_2e9

    goto :goto_31c

    :cond_2e9
    const/16 v5, 0x32

    if-ne v4, v5, :cond_318

    add-int/lit8 v5, v23, 0x1

    aput v6, v15, v23

    div-int/lit8 v23, v6, 0x3

    const/16 v22, 0x2

    mul-int/lit8 v23, v23, 0x2

    add-int/lit8 v29, v10, 0x2

    aget-object v30, v28, v34

    aput-object v30, v11, v23

    move/from16 v30, v5

    and-int/lit16 v5, v2, 0x800

    if-eqz v5, :cond_311

    add-int/lit8 v23, v23, 0x1

    add-int/lit8 v5, v10, 0x3

    aget-object v10, v28, v29

    aput-object v10, v11, v23

    move/from16 v29, v7

    move/from16 v23, v30

    :goto_30f
    const/4 v7, 0x1

    goto :goto_351

    :cond_311
    move/from16 v5, v29

    move/from16 v23, v30

    move/from16 v29, v7

    goto :goto_30f

    :cond_318
    move/from16 v29, v7

    const/4 v7, 0x1

    goto :goto_34f

    :cond_31c
    :goto_31c
    invoke-virtual {v0}, Lmne;->a()I

    move-result v5

    move/from16 v29, v7

    const/4 v7, 0x1

    if-eq v5, v7, :cond_329

    and-int/lit16 v5, v2, 0x800

    if-eqz v5, :cond_34f

    :cond_329
    move/from16 v19, v10

    const/4 v5, 0x3

    const/4 v10, 0x2

    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    add-int/lit8 v19, v19, 0x2

    aget-object v22, v28, v34

    aput-object v22, v11, v5

    :goto_337
    move/from16 v5, v19

    goto :goto_351

    :goto_33a
    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    add-int/lit8 v19, v19, 0x2

    aget-object v22, v28, v34

    aput-object v22, v11, v5

    goto :goto_337

    :goto_345
    invoke-static {v6, v5, v10, v7}, Lti6;->e(IIII)I

    move-result v5

    invoke-virtual {v9}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v10

    aput-object v10, v11, v5

    :cond_34f
    :goto_34f
    move/from16 v5, v34

    :goto_351
    invoke-virtual {v14, v9}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v9

    long-to-int v9, v9

    and-int/lit16 v10, v2, 0x1000

    if-eqz v10, :cond_3ab

    const/16 v10, 0x11

    if-gt v4, v10, :cond_3ab

    add-int/lit8 v10, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const v7, 0xd800

    if-lt v3, v7, :cond_384

    and-int/lit16 v3, v3, 0x1fff

    const/16 v20, 0xd

    :goto_36d
    add-int/lit8 v30, v10, 0x1

    invoke-virtual {v1, v10}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-lt v10, v7, :cond_37f

    and-int/lit16 v10, v10, 0x1fff

    shl-int v10, v10, v20

    or-int/2addr v3, v10

    add-int/lit8 v20, v20, 0xd

    move/from16 v10, v30

    goto :goto_36d

    :cond_37f
    shl-int v10, v10, v20

    or-int/2addr v3, v10

    move/from16 v10, v30

    :cond_384
    const/16 v22, 0x2

    mul-int/lit8 v20, v31, 0x2

    div-int/lit8 v30, v3, 0x20

    add-int v30, v30, v20

    aget-object v7, v28, v30

    move-object/from16 v32, v1

    instance-of v1, v7, Ljava/lang/reflect/Field;

    if-eqz v1, :cond_39a

    check-cast v7, Ljava/lang/reflect/Field;

    :goto_396
    move/from16 v30, v5

    move v1, v6

    goto :goto_3a3

    :cond_39a
    check-cast v7, Ljava/lang/String;

    invoke-static {v8, v7}, Landroidx/health/platform/client/proto/p;->D(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v7

    aput-object v7, v28, v30

    goto :goto_396

    :goto_3a3
    invoke-virtual {v14, v7}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v5

    long-to-int v5, v5

    rem-int/lit8 v3, v3, 0x20

    goto :goto_3b7

    :cond_3ab
    move-object/from16 v32, v1

    move/from16 v30, v5

    move v1, v6

    const/16 v22, 0x2

    const v5, 0xfffff

    move v10, v3

    const/4 v3, 0x0

    :goto_3b7
    const/16 v6, 0x12

    if-lt v4, v6, :cond_3c5

    const/16 v6, 0x31

    if-gt v4, v6, :cond_3c5

    add-int/lit8 v6, v24, 0x1

    aput v9, v15, v24

    move/from16 v24, v6

    :cond_3c5
    :goto_3c5
    add-int/lit8 v6, v1, 0x1

    aput v25, v27, v1

    add-int/lit8 v7, v1, 0x2

    move/from16 v25, v1

    and-int/lit16 v1, v2, 0x200

    if-eqz v1, :cond_3d4

    const/high16 v1, 0x20000000

    goto :goto_3d5

    :cond_3d4
    const/4 v1, 0x0

    :goto_3d5
    move/from16 v33, v1

    and-int/lit16 v1, v2, 0x100

    if-eqz v1, :cond_3de

    const/high16 v1, 0x10000000

    goto :goto_3df

    :cond_3de
    const/4 v1, 0x0

    :goto_3df
    or-int v1, v33, v1

    and-int/lit16 v2, v2, 0x800

    if-eqz v2, :cond_3e8

    const/high16 v2, -0x80000000

    goto :goto_3e9

    :cond_3e8
    const/4 v2, 0x0

    :goto_3e9
    or-int/2addr v1, v2

    shl-int/lit8 v2, v4, 0x14

    or-int/2addr v1, v2

    or-int/2addr v1, v9

    aput v1, v27, v6

    add-int/lit8 v6, v25, 0x3

    shl-int/lit8 v1, v3, 0x14

    or-int/2addr v1, v5

    aput v1, v27, v7

    move v4, v10

    move/from16 v2, v26

    move-object/from16 v5, v27

    move-object/from16 v3, v28

    move/from16 v9, v29

    move/from16 v10, v30

    move/from16 v7, v31

    move-object/from16 v1, v32

    goto/16 :goto_17b

    :cond_408
    move-object/from16 v27, v5

    move/from16 v29, v9

    new-instance v9, Landroidx/health/platform/client/proto/p;

    iget-object v14, v0, Lmne;->a:Landroidx/health/platform/client/proto/a;

    move-object/from16 v18, p1

    move-object/from16 v19, p2

    move-object/from16 v20, p3

    move-object/from16 v21, p4

    move-object/from16 v22, p5

    move-object/from16 v10, v27

    move/from16 v17, v29

    invoke-direct/range {v9 .. v22}, Landroidx/health/platform/client/proto/p;-><init>([I[Ljava/lang/Object;IILandroidx/health/platform/client/proto/a;[IIILxjc;Lema;Landroidx/health/platform/client/proto/a0;Lmm7;Lw5b;)V

    return-object v9
.end method

.method public static x(JLjava/lang/Object;)I
    .registers 4

    sget-object v0, Lj5j;->c:Le5j;

    invoke-virtual {v0, p0, p1, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public static y(JLjava/lang/Object;)J
    .registers 4

    sget-object v0, Lj5j;->c:Le5j;

    invoke-virtual {v0, p0, p1, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    return-wide p0
.end method


# virtual methods
.method public final A(Ljava/lang/Object;[BIIILpq0;)I
    .registers 41

    move-object/from16 v0, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p4

    move-object/from16 v9, p6

    invoke-static {v2}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6a7

    sget-object v1, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    move/from16 v5, p3

    const/4 v6, -0x1

    const/4 v7, 0x0

    const v8, 0xfffff

    const/4 v13, 0x0

    const/4 v14, 0x0

    :goto_1b
    sget-object v16, Lugd;->F:Lugd;

    sget-object v17, Lugd;->G:Lugd;

    sget-object v18, Lugd;->H:Lugd;

    const v19, 0xfffff

    sget-object v11, Landroidx/health/platform/client/proto/b0;->f:Landroidx/health/platform/client/proto/b0;

    const/16 v20, 0x0

    iget-object v12, v0, Landroidx/health/platform/client/proto/p;->a:[I

    const/16 p3, 0x3

    const/16 v23, 0x1

    if-ge v5, v4, :cond_58b

    add-int/lit8 v14, v5, 0x1

    aget-byte v5, v3, v5

    if-gez v5, :cond_3c

    invoke-static {v5, v3, v14, v9}, Lckl;->m(I[BILpq0;)I

    move-result v14

    iget v5, v9, Lpq0;->a:I

    :cond_3c
    move/from16 v32, v14

    move v14, v5

    move/from16 v5, v32

    ushr-int/lit8 v10, v14, 0x3

    move/from16 v25, v7

    and-int/lit8 v7, v14, 0x7

    iget v3, v0, Landroidx/health/platform/client/proto/p;->d:I

    iget v4, v0, Landroidx/health/platform/client/proto/p;->c:I

    if-le v10, v6, :cond_5d

    div-int/lit8 v6, v25, 0x3

    if-lt v10, v4, :cond_58

    if-gt v10, v3, :cond_58

    invoke-virtual {v0, v10, v6}, Landroidx/health/platform/client/proto/p;->F(II)I

    move-result v3

    goto :goto_59

    :cond_58
    const/4 v3, -0x1

    :goto_59
    move v4, v3

    const/4 v3, 0x0

    :goto_5b
    const/4 v6, -0x1

    goto :goto_6a

    :cond_5d
    if-lt v10, v4, :cond_67

    if-gt v10, v3, :cond_67

    const/4 v3, 0x0

    invoke-virtual {v0, v10, v3}, Landroidx/health/platform/client/proto/p;->F(II)I

    move-result v4

    goto :goto_5b

    :cond_67
    const/4 v3, 0x0

    const/4 v4, -0x1

    goto :goto_5b

    :goto_6a
    if-ne v4, v6, :cond_85

    move/from16 v21, p3

    move/from16 v9, p5

    move-object/from16 v30, v1

    move v7, v3

    move/from16 v22, v7

    move/from16 v24, v6

    move/from16 v19, v8

    move/from16 v26, v10

    move-object/from16 v31, v11

    move-object/from16 v27, v12

    const/4 v15, 0x2

    move-object v6, v0

    move-object v8, v2

    :goto_82
    move v2, v14

    goto/16 :goto_54e

    :cond_85
    add-int/lit8 v21, v4, 0x1

    aget v3, v12, v21

    invoke-static {v3}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v6

    move/from16 v25, v5

    and-int v5, v3, v19

    move/from16 v26, v10

    int-to-long v9, v5

    const/16 v5, 0x11

    if-gt v6, v5, :cond_40f

    add-int/lit8 v5, v4, 0x2

    aget v5, v12, v5

    ushr-int/lit8 v27, v5, 0x14

    shl-int v27, v23, v27

    and-int v5, v5, v19

    move-wide/from16 v28, v9

    move/from16 v10, v19

    if-eq v5, v8, :cond_bb

    if-eq v8, v10, :cond_ae

    int-to-long v8, v8

    invoke-virtual {v1, v2, v8, v9, v13}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    :cond_ae
    if-ne v5, v10, :cond_b2

    const/4 v8, 0x0

    goto :goto_b7

    :cond_b2
    int-to-long v8, v5

    invoke-virtual {v1, v2, v8, v9}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v8

    :goto_b7
    move v13, v5

    move/from16 v19, v8

    goto :goto_be

    :cond_bb
    move/from16 v19, v13

    move v13, v8

    :goto_be
    const/4 v5, 0x5

    packed-switch v6, :pswitch_data_6b4

    move-object/from16 v9, p2

    move-object/from16 v10, p6

    move-object v7, v1

    move-object v1, v2

    move v2, v4

    move/from16 v5, v23

    move/from16 v8, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    goto/16 :goto_3f7

    :pswitch_d3  #0x11
    move/from16 v9, p3

    if-ne v7, v9, :cond_108

    invoke-virtual {v0, v4, v2}, Landroidx/health/platform/client/proto/p;->u(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    shl-int/lit8 v5, v26, 0x3

    or-int/lit8 v8, v5, 0x4

    move v12, v4

    invoke-virtual {v0, v12}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v4

    move-object/from16 v5, p2

    move/from16 v7, p4

    move-object/from16 v9, p6

    move v11, v12

    move/from16 v6, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    invoke-static/range {v3 .. v9}, Lckl;->s(Ljava/lang/Object;Layf;[BIIILpq0;)I

    move-result v4

    move-object v8, v5

    move-object v5, v3

    move-object v3, v9

    invoke-virtual {v0, v2, v11, v5}, Landroidx/health/platform/client/proto/p;->G(Ljava/lang/Object;ILjava/lang/Object;)V

    or-int v5, v19, v27

    move-object v3, v8

    move v7, v11

    move v8, v13

    move/from16 v6, v26

    move v13, v5

    :goto_103
    move v5, v4

    :goto_104
    move/from16 v4, p4

    goto/16 :goto_1b

    :cond_108
    const/16 v21, -0x1

    const/16 v22, 0x0

    move-object/from16 v9, p2

    move-object/from16 v10, p6

    move-object v7, v1

    move-object v1, v2

    move v2, v4

    move/from16 v5, v23

    move/from16 v8, v25

    goto/16 :goto_3f7

    :pswitch_119  #0x10
    move-object/from16 v8, p2

    move/from16 v9, p3

    move-object/from16 v3, p6

    move v5, v4

    move/from16 v4, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-nez v7, :cond_152

    invoke-static {v8, v4, v3}, Lckl;->p([BILpq0;)I

    move-result v7

    iget-wide v11, v3, Lpq0;->b:J

    invoke-static {v11, v12}, Lthl;->e(J)J

    move-result-wide v11

    move-wide v3, v11

    move v12, v5

    move-wide v5, v3

    move-wide/from16 v3, v28

    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    move-object/from16 v32, v2

    move-object v2, v1

    move-object/from16 v1, v32

    or-int v3, v19, v27

    move-object v4, v2

    move-object v2, v1

    move-object v1, v4

    move v4, v13

    move v13, v3

    move-object v3, v8

    move v8, v4

    move/from16 v4, p4

    move-object/from16 v9, p6

    move v5, v7

    move v7, v12

    move/from16 v6, v26

    goto/16 :goto_1b

    :cond_152
    move-object/from16 v32, v2

    move-object v2, v1

    move-object/from16 v1, v32

    move-object v7, v2

    move-object v10, v3

    move v2, v5

    :goto_15a
    move-object v9, v8

    move/from16 v5, v23

    :goto_15d
    move v8, v4

    goto/16 :goto_3f7

    :pswitch_160  #0xf
    move-object v5, v2

    move-object v2, v1

    move-object v1, v5

    move-object/from16 v8, p2

    move-object/from16 v5, p6

    move v6, v4

    move/from16 v4, v25

    move-wide/from16 v9, v28

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-nez v7, :cond_18e

    invoke-static {v8, v4, v5}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v5, Lpq0;->a:I

    invoke-static {v4}, Lthl;->d(I)I

    move-result v4

    invoke-virtual {v2, v1, v9, v10, v4}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    :goto_17f
    or-int v4, v19, v27

    move-object v7, v2

    move-object v2, v1

    move-object v1, v7

    move-object v9, v5

    move v7, v6

    move/from16 v6, v26

    move v5, v3

    move-object v3, v8

    move v8, v13

    move v13, v4

    goto/16 :goto_104

    :cond_18e
    move-object v7, v2

    move-object v10, v5

    move v2, v6

    goto :goto_15a

    :pswitch_192  #0xc
    move-object v5, v2

    move-object v2, v1

    move-object v1, v5

    move-object/from16 v8, p2

    move-object/from16 v5, p6

    move v6, v4

    move/from16 v4, v25

    move-wide/from16 v9, v28

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-nez v7, :cond_1fb

    invoke-static {v8, v4, v5}, Lckl;->n([BILpq0;)I

    move-result v4

    iget v7, v5, Lpq0;->a:I

    invoke-virtual {v0, v6}, Landroidx/health/platform/client/proto/p;->l(I)Ltgd;

    move-result-object v12

    const/high16 v28, -0x80000000

    and-int v3, v3, v28

    if-eqz v3, :cond_1ec

    if-eqz v12, :cond_1ec

    if-eqz v7, :cond_1c7

    move/from16 v3, v23

    if-eq v7, v3, :cond_1c5

    const/4 v3, 0x2

    if-eq v7, v3, :cond_1c2

    move-object/from16 v16, v20

    goto :goto_1c7

    :cond_1c2
    move-object/from16 v16, v18

    goto :goto_1c7

    :cond_1c5
    move-object/from16 v16, v17

    :cond_1c7
    :goto_1c7
    if-eqz v16, :cond_1ca

    goto :goto_1ec

    :cond_1ca
    move-object v3, v1

    check-cast v3, Landroidx/health/platform/client/proto/n;

    iget-object v9, v3, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    if-ne v9, v11, :cond_1d7

    invoke-static {}, Landroidx/health/platform/client/proto/b0;->c()Landroidx/health/platform/client/proto/b0;

    move-result-object v9

    iput-object v9, v3, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    :cond_1d7
    int-to-long v10, v7

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v9, v14, v3}, Landroidx/health/platform/client/proto/b0;->d(ILjava/lang/Object;)V

    move-object v3, v2

    move-object v2, v1

    move-object v1, v3

    move-object v9, v5

    move v7, v6

    move-object v3, v8

    move v8, v13

    move/from16 v13, v19

    :goto_1e8
    move/from16 v6, v26

    goto/16 :goto_103

    :cond_1ec
    :goto_1ec
    invoke-virtual {v2, v1, v9, v10, v7}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    or-int v3, v19, v27

    move-object v7, v2

    move-object v2, v1

    move-object v1, v7

    move v7, v13

    move v13, v3

    move-object v3, v8

    move v8, v7

    move-object v9, v5

    move v7, v6

    goto :goto_1e8

    :cond_1fb
    move-object v7, v2

    move-object v10, v5

    move v2, v6

    move-object v9, v8

    :goto_1ff
    const/4 v5, 0x1

    goto/16 :goto_15d

    :pswitch_202  #0xa
    move-object v3, v2

    move-object v2, v1

    move-object v1, v3

    move-object/from16 v8, p2

    move-object/from16 v5, p6

    move v6, v4

    move/from16 v4, v25

    move-wide/from16 v9, v28

    const/4 v3, 0x2

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-ne v7, v3, :cond_1fb

    invoke-static {v8, v4, v5}, Lckl;->h([BILpq0;)I

    move-result v3

    iget-object v4, v5, Lpq0;->c:Ljava/lang/Object;

    invoke-virtual {v2, v1, v9, v10, v4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto/16 :goto_17f

    :pswitch_220  #0x9
    move-object v3, v2

    move-object v2, v1

    move-object v1, v3

    move-object/from16 v8, p2

    move-object/from16 v5, p6

    move v6, v4

    move/from16 v4, v25

    const/4 v3, 0x2

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-ne v7, v3, :cond_25c

    move-object v7, v1

    invoke-virtual {v0, v6, v7}, Landroidx/health/platform/client/proto/p;->u(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v2

    invoke-virtual {v0, v6}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v2

    move-object v9, v7

    move-object v7, v3

    move-object v3, v8

    move-object v8, v9

    move v9, v6

    move-object v6, v5

    move/from16 v5, p4

    invoke-static/range {v1 .. v6}, Lckl;->t(Ljava/lang/Object;Layf;[BIILpq0;)I

    move-result v2

    move-object v4, v3

    move-object v3, v1

    move-object v1, v4

    move-object v4, v6

    invoke-virtual {v0, v8, v9, v3}, Landroidx/health/platform/client/proto/p;->G(Ljava/lang/Object;ILjava/lang/Object;)V

    or-int v3, v19, v27

    move v5, v2

    move-object v2, v8

    move v8, v13

    move/from16 v6, v26

    move v13, v3

    move-object v3, v1

    move-object v1, v7

    move v7, v9

    move-object v9, v4

    goto/16 :goto_104

    :cond_25c
    move-object v7, v8

    move-object v8, v1

    move-object v1, v7

    move-object v7, v2

    move-object v9, v1

    move-object v10, v5

    move v2, v6

    move-object v1, v8

    goto :goto_1ff

    :pswitch_265  #0x8
    move-object v6, v1

    move-object v8, v2

    move/from16 v2, v25

    move-wide/from16 v9, v28

    const/4 v5, 0x2

    const/16 v21, -0x1

    const/16 v22, 0x0

    move-object/from16 v1, p2

    move/from16 v28, v4

    move-object/from16 v4, p6

    if-ne v7, v5, :cond_2cc

    const/high16 v5, 0x20000000

    and-int/2addr v3, v5

    const-string v5, ""

    if-eqz v3, :cond_29c

    invoke-static {v1, v2, v4}, Lckl;->n([BILpq0;)I

    move-result v2

    iget v3, v4, Lpq0;->a:I

    if-ltz v3, :cond_297

    if-nez v3, :cond_28c

    iput-object v5, v4, Lpq0;->c:Ljava/lang/Object;

    goto :goto_295

    :cond_28c
    sget-object v5, Landroidx/health/platform/client/proto/d0;->a:Lval;

    invoke-virtual {v5, v1, v2, v3}, Lval;->e([BII)Ljava/lang/String;

    move-result-object v5

    iput-object v5, v4, Lpq0;->c:Ljava/lang/Object;

    :goto_294
    add-int/2addr v2, v3

    :goto_295
    move v5, v2

    goto :goto_2b3

    :cond_297
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_29c
    invoke-static {v1, v2, v4}, Lckl;->n([BILpq0;)I

    move-result v2

    iget v3, v4, Lpq0;->a:I

    if-ltz v3, :cond_2c7

    if-nez v3, :cond_2a9

    iput-object v5, v4, Lpq0;->c:Ljava/lang/Object;

    goto :goto_295

    :cond_2a9
    new-instance v5, Ljava/lang/String;

    sget-object v7, Lhl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v5, v1, v2, v3, v7}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    iput-object v5, v4, Lpq0;->c:Ljava/lang/Object;

    goto :goto_294

    :goto_2b3
    iget-object v2, v4, Lpq0;->c:Ljava/lang/Object;

    invoke-virtual {v6, v8, v9, v10, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :goto_2b8
    or-int v2, v19, v27

    move v3, v13

    move v13, v2

    move-object v2, v8

    move v8, v3

    move-object v3, v1

    move-object v9, v4

    move-object v1, v6

    move/from16 v6, v26

    move/from16 v7, v28

    goto/16 :goto_104

    :cond_2c7
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_2cc
    move-object v9, v1

    move-object v10, v4

    move-object v7, v6

    move-object v1, v8

    const/4 v5, 0x1

    move v8, v2

    :goto_2d2
    move/from16 v2, v28

    goto/16 :goto_3f7

    :pswitch_2d6  #0x7
    move-object v6, v1

    move-object v8, v2

    move/from16 v2, v25

    move-wide/from16 v9, v28

    const/16 v21, -0x1

    const/16 v22, 0x0

    move-object/from16 v1, p2

    move/from16 v28, v4

    move-object/from16 v4, p6

    if-nez v7, :cond_2cc

    invoke-static {v1, v2, v4}, Lckl;->p([BILpq0;)I

    move-result v5

    iget-wide v2, v4, Lpq0;->b:J

    const-wide/16 v11, 0x0

    cmp-long v2, v2, v11

    if-eqz v2, :cond_2f6

    const/4 v2, 0x1

    goto :goto_2f8

    :cond_2f6
    move/from16 v2, v22

    :goto_2f8
    sget-object v3, Lj5j;->c:Le5j;

    invoke-virtual {v3, v8, v9, v10, v2}, Le5j;->k(Ljava/lang/Object;JZ)V

    goto :goto_2b8

    :pswitch_2fe  #0x6, 0xd
    move-object v6, v1

    move-object v8, v2

    move/from16 v2, v25

    move-wide/from16 v9, v28

    const/16 v21, -0x1

    const/16 v22, 0x0

    move-object/from16 v1, p2

    move/from16 v28, v4

    move-object/from16 v4, p6

    if-ne v7, v5, :cond_2cc

    invoke-static {v1, v2}, Lckl;->i([BI)I

    move-result v3

    invoke-virtual {v6, v8, v9, v10, v3}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    add-int/lit8 v5, v2, 0x4

    goto :goto_2b8

    :pswitch_31a  #0x5, 0xe
    move-object v6, v1

    move-object v8, v2

    move/from16 v3, v23

    move/from16 v2, v25

    move-wide/from16 v9, v28

    const/16 v21, -0x1

    const/16 v22, 0x0

    move-object/from16 v1, p2

    move/from16 v28, v4

    move-object/from16 v4, p6

    if-ne v7, v3, :cond_352

    move-object v3, v6

    invoke-static {v1, v2}, Lckl;->j([BI)J

    move-result-wide v5

    move-object/from16 v32, v8

    move v8, v2

    move-object/from16 v2, v32

    move-wide/from16 v32, v9

    move-object v9, v1

    move-object v1, v3

    move-object v10, v4

    move-wide/from16 v3, v32

    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    add-int/lit8 v5, v8, 0x8

    :goto_344
    or-int v3, v19, v27

    move/from16 v4, p4

    :goto_348
    move v8, v13

    move/from16 v6, v26

    move/from16 v7, v28

    move v13, v3

    move-object v3, v9

    move-object v9, v10

    goto/16 :goto_1b

    :cond_352
    move-object v9, v8

    move v8, v2

    move-object v2, v9

    move-object v9, v1

    move-object v10, v4

    move-object v1, v2

    move v5, v3

    move-object v7, v6

    goto/16 :goto_2d2

    :pswitch_35c  #0x4, 0xb
    move-wide/from16 v8, v28

    move/from16 v28, v4

    move-wide v3, v8

    move-object/from16 v9, p2

    move-object/from16 v10, p6

    move/from16 v8, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-nez v7, :cond_377

    invoke-static {v9, v8, v10}, Lckl;->n([BILpq0;)I

    move-result v5

    iget v6, v10, Lpq0;->a:I

    invoke-virtual {v1, v2, v3, v4, v6}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    goto :goto_344

    :cond_377
    move-object v7, v1

    move-object v1, v2

    move/from16 v2, v28

    const/4 v5, 0x1

    goto/16 :goto_3f7

    :pswitch_37e  #0x2, 0x3
    move-wide/from16 v8, v28

    move/from16 v28, v4

    move-wide v3, v8

    move-object/from16 v9, p2

    move-object/from16 v10, p6

    move/from16 v8, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-nez v7, :cond_377

    invoke-static {v9, v8, v10}, Lckl;->p([BILpq0;)I

    move-result v7

    iget-wide v5, v10, Lpq0;->b:J

    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    or-int v3, v19, v27

    move/from16 v4, p4

    move v5, v7

    goto :goto_348

    :pswitch_39e  #0x1
    move-wide/from16 v8, v28

    move/from16 v28, v4

    move-wide v3, v8

    move-object/from16 v9, p2

    move-object/from16 v10, p6

    move/from16 v8, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-ne v7, v5, :cond_377

    invoke-static {v9, v8}, Lckl;->i([BI)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v5

    sget-object v6, Lj5j;->c:Le5j;

    invoke-virtual {v6, v2, v3, v4, v5}, Le5j;->n(Ljava/lang/Object;JF)V

    add-int/lit8 v5, v8, 0x4

    goto :goto_344

    :pswitch_3bf  #0x0
    move-wide/from16 v8, v28

    move/from16 v28, v4

    move-wide v3, v8

    move-object/from16 v9, p2

    move-object/from16 v10, p6

    move/from16 v5, v23

    move/from16 v8, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    if-ne v7, v5, :cond_3f3

    invoke-static {v9, v8}, Lckl;->j([BI)J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v5

    move-object v7, v1

    sget-object v1, Lj5j;->c:Le5j;

    invoke-virtual/range {v1 .. v6}, Le5j;->m(Ljava/lang/Object;JD)V

    move-object v1, v2

    add-int/lit8 v5, v8, 0x8

    or-int v2, v19, v27

    move/from16 v4, p4

    move-object v3, v9

    move-object v9, v10

    move v8, v13

    move/from16 v6, v26

    move v13, v2

    move-object v2, v1

    move-object v1, v7

    move/from16 v7, v28

    goto/16 :goto_1b

    :cond_3f3
    move-object v7, v1

    move-object v1, v2

    goto/16 :goto_2d2

    :goto_3f7
    move/from16 v5, v19

    move/from16 v19, v13

    move v13, v5

    move/from16 v9, p5

    move-object v6, v0

    move-object/from16 v30, v7

    move v5, v8

    move-object/from16 v31, v11

    move-object/from16 v27, v12

    move/from16 v24, v21

    const/4 v15, 0x2

    const/16 v21, 0x3

    move-object v8, v1

    move v7, v2

    goto/16 :goto_82

    :cond_40f
    move/from16 v19, v4

    move-object v4, v1

    move-object v1, v2

    move/from16 v2, v19

    move-object/from16 v27, v12

    move/from16 v23, v13

    move/from16 v19, v25

    const/16 v21, -0x1

    const/16 v22, 0x0

    move-wide v12, v9

    move-object/from16 v9, p2

    move-object/from16 v10, p6

    const/16 v5, 0x1b

    if-ne v6, v5, :cond_482

    const/4 v5, 0x2

    if-ne v7, v5, :cond_46f

    invoke-virtual {v4, v1, v12, v13}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldl9;

    move-object v5, v3

    check-cast v5, Lp3;

    iget-boolean v5, v5, Lp3;->E:Z

    if-nez v5, :cond_44a

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v5

    if-nez v5, :cond_441

    const/16 v5, 0xa

    goto :goto_443

    :cond_441
    mul-int/lit8 v5, v5, 0x2

    :goto_443
    invoke-interface {v3, v5}, Ldl9;->l(I)Ldl9;

    move-result-object v3

    invoke-virtual {v4, v1, v12, v13, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :cond_44a
    move-object v6, v3

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v1

    move/from16 v5, p4

    move-object v3, v9

    move-object v7, v10

    move-object v9, v4

    move v10, v8

    move/from16 v4, v19

    move v8, v2

    move v2, v14

    invoke-static/range {v1 .. v7}, Lckl;->k(Layf;I[BIILdl9;Lpq0;)I

    move-result v1

    move-object/from16 v3, p2

    move/from16 v4, p4

    move v5, v1

    move v7, v8

    move-object v1, v9

    move v8, v10

    move/from16 v13, v23

    move/from16 v6, v26

    move-object/from16 v2, p1

    move-object/from16 v9, p6

    goto/16 :goto_1b

    :cond_46f
    move-object v9, v4

    move v10, v8

    move/from16 v28, v2

    move v15, v5

    move-object/from16 v30, v9

    move-object/from16 v31, v11

    move/from16 v4, v19

    move/from16 v24, v21

    const/16 v21, 0x3

    move/from16 v19, v10

    goto/16 :goto_51a

    :cond_482
    move-object v9, v4

    move v10, v8

    move/from16 v4, v19

    const/4 v5, 0x2

    move v8, v2

    move v2, v14

    const/16 v1, 0x31

    if-gt v6, v1, :cond_4d7

    move-object v1, v9

    move v14, v10

    int-to-long v9, v3

    move-object/from16 v30, v1

    move v3, v4

    move v15, v5

    move-object/from16 v31, v11

    move/from16 v19, v14

    move/from16 v24, v21

    const/16 v21, 0x3

    move-object/from16 v1, p1

    move/from16 v4, p4

    move-object/from16 v14, p6

    move v5, v2

    move v11, v6

    move/from16 v6, v26

    move-object/from16 v2, p2

    invoke-virtual/range {v0 .. v14}, Landroidx/health/platform/client/proto/p;->C(Ljava/lang/Object;[BIIIIIIJIJLpq0;)I

    move-result v7

    move v4, v3

    move v14, v5

    move/from16 v28, v8

    if-eq v7, v4, :cond_4c9

    move-object/from16 v0, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p4

    move-object/from16 v9, p6

    move v5, v7

    :goto_4bd
    move/from16 v8, v19

    move/from16 v13, v23

    move/from16 v6, v26

    move/from16 v7, v28

    move-object/from16 v1, v30

    goto/16 :goto_1b

    :cond_4c9
    move-object/from16 v6, p0

    move-object/from16 v8, p1

    move/from16 v9, p5

    move v5, v7

    :goto_4d0
    move v2, v14

    :goto_4d1
    move/from16 v13, v23

    move/from16 v7, v28

    goto/16 :goto_54e

    :cond_4d7
    move v14, v2

    move v15, v5

    move/from16 v28, v8

    move-object/from16 v30, v9

    move/from16 v19, v10

    move-object/from16 v31, v11

    move/from16 v24, v21

    const/16 v21, 0x3

    move v9, v6

    const/16 v0, 0x32

    if-ne v9, v0, :cond_522

    if-ne v7, v15, :cond_51a

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v8, p6

    move v3, v4

    move-wide v6, v12

    move/from16 v5, v28

    move/from16 v4, p4

    invoke-virtual/range {v0 .. v8}, Landroidx/health/platform/client/proto/p;->z(Ljava/lang/Object;[BIIIJLpq0;)I

    move-result v6

    move v4, v3

    if-eq v6, v4, :cond_50d

    move-object/from16 v0, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p4

    move-object/from16 v9, p6

    move v5, v6

    goto :goto_4bd

    :cond_50d
    move-object/from16 v8, p1

    move/from16 v9, p5

    move v5, v6

    move v2, v14

    move/from16 v13, v23

    move/from16 v7, v28

    move-object/from16 v6, p0

    goto :goto_54e

    :cond_51a
    :goto_51a
    move-object/from16 v6, p0

    move-object/from16 v8, p1

    move/from16 v9, p5

    move v5, v4

    goto :goto_4d0

    :cond_522
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move v8, v3

    move v3, v4

    move-wide v10, v12

    move v5, v14

    move/from16 v6, v26

    move/from16 v12, v28

    move/from16 v4, p4

    move-object/from16 v13, p6

    invoke-virtual/range {v0 .. v13}, Landroidx/health/platform/client/proto/p;->B(Ljava/lang/Object;[BIIIIIIIJILpq0;)I

    move-result v7

    move-object v8, v1

    move v4, v3

    move v2, v5

    move-object v6, v0

    if-eq v7, v4, :cond_54a

    move-object/from16 v3, p2

    move/from16 v4, p4

    move-object/from16 v9, p6

    move v14, v2

    move-object v0, v6

    move v5, v7

    move-object v2, v8

    goto/16 :goto_4bd

    :cond_54a
    move/from16 v9, p5

    move v5, v7

    goto :goto_4d1

    :goto_54e
    if-ne v2, v9, :cond_55d

    if-eqz v9, :cond_55d

    move/from16 v4, p4

    move v14, v2

    move-object/from16 v3, v31

    :goto_557
    move/from16 v0, v19

    const v10, 0xfffff

    goto :goto_59e

    :cond_55d
    move-object v0, v8

    check-cast v0, Landroidx/health/platform/client/proto/n;

    iget-object v1, v0, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    move-object/from16 v3, v31

    if-ne v1, v3, :cond_56c

    invoke-static {}, Landroidx/health/platform/client/proto/b0;->c()Landroidx/health/platform/client/proto/b0;

    move-result-object v1

    iput-object v1, v0, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    :cond_56c
    move/from16 v3, p4

    move-object v4, v1

    move v0, v2

    move v2, v5

    move-object/from16 v1, p2

    move-object/from16 v5, p6

    invoke-static/range {v0 .. v5}, Lckl;->l(I[BIILandroidx/health/platform/client/proto/b0;Lpq0;)I

    move-result v2

    move v5, v0

    move-object/from16 v9, p6

    move v4, v3

    move v14, v5

    move-object v0, v6

    move/from16 v6, v26

    move-object/from16 v1, v30

    move-object/from16 v3, p2

    move v5, v2

    move-object v2, v8

    move/from16 v8, v19

    goto/16 :goto_1b

    :cond_58b
    move/from16 v21, p3

    move/from16 v9, p5

    move-object v6, v0

    move-object/from16 v30, v1

    move/from16 v19, v8

    move-object v3, v11

    move-object/from16 v27, v12

    move/from16 v23, v13

    const/4 v15, 0x2

    const/16 v22, 0x0

    move-object v8, v2

    goto :goto_557

    :goto_59e
    if-eq v0, v10, :cond_5a6

    int-to-long v0, v0

    move-object/from16 v7, v30

    invoke-virtual {v7, v8, v0, v1, v13}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    :cond_5a6
    iget v0, v6, Landroidx/health/platform/client/proto/p;->g:I

    move-object/from16 v1, v20

    :goto_5aa
    iget v2, v6, Landroidx/health/platform/client/proto/p;->h:I

    iget-object v7, v6, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    if-ge v0, v2, :cond_687

    iget-object v2, v6, Landroidx/health/platform/client/proto/p;->f:[I

    aget v2, v2, v0

    aget v11, v27, v2

    invoke-virtual {v6, v2}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v12

    and-int/2addr v12, v10

    int-to-long v12, v12

    sget-object v10, Lj5j;->c:Le5j;

    invoke-virtual {v10, v12, v13, v8}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    if-nez v10, :cond_5c5

    goto :goto_5cb

    :cond_5c5
    invoke-virtual {v6, v2}, Landroidx/health/platform/client/proto/p;->l(I)Ltgd;

    move-result-object v12

    if-nez v12, :cond_5d1

    :cond_5cb
    :goto_5cb
    move/from16 v23, v0

    move/from16 v24, v15

    goto/16 :goto_67e

    :cond_5d1
    iget-object v12, v6, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v10, Lr5b;

    invoke-virtual {v6, v2}, Landroidx/health/platform/client/proto/p;->m(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lk5b;

    iget-object v2, v2, Lk5b;->a:Li79;

    invoke-virtual {v10}, Lr5b;->entrySet()Ljava/util/Set;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_5e8
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_5cb

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/util/Map$Entry;

    invoke-interface {v12}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Integer;

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    if-eqz v13, :cond_610

    move/from16 v23, v0

    const/4 v0, 0x1

    if-eq v13, v0, :cond_60d

    if-eq v13, v15, :cond_60a

    move-object/from16 v13, v20

    goto :goto_615

    :cond_60a
    move-object/from16 v13, v18

    goto :goto_615

    :cond_60d
    move-object/from16 v13, v17

    goto :goto_615

    :cond_610
    move/from16 v23, v0

    const/4 v0, 0x1

    move-object/from16 v13, v16

    :goto_615
    if-eqz v13, :cond_61a

    move/from16 v24, v15

    goto :goto_66d

    :cond_61a
    if-nez v1, :cond_630

    move-object v1, v7

    check-cast v1, Ll3j;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v1, v8

    check-cast v1, Landroidx/health/platform/client/proto/n;

    iget-object v13, v1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    if-ne v13, v3, :cond_62f

    invoke-static {}, Landroidx/health/platform/client/proto/b0;->c()Landroidx/health/platform/client/proto/b0;

    move-result-object v13

    iput-object v13, v1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    :cond_62f
    move-object v1, v13

    :cond_630
    invoke-interface {v12}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v13

    invoke-interface {v12}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v2, v13, v0}, Lk5b;->a(Li79;Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v0

    new-array v13, v0, [B

    move/from16 v24, v15

    new-instance v15, Landroidx/health/platform/client/proto/b;

    invoke-direct {v15, v13, v0}, Landroidx/health/platform/client/proto/b;-><init>([BI)V

    move/from16 p2, v0

    :try_start_647
    invoke-interface {v12}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v12}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v12

    invoke-static {v15, v2, v0, v12}, Lk5b;->b(Landroidx/health/platform/client/proto/b;Li79;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_652
    .catch Ljava/io/IOException; {:try_start_647 .. :try_end_652} :catch_679

    iget v0, v15, Landroidx/health/platform/client/proto/b;->d:I

    sub-int v0, p2, v0

    if-nez v0, :cond_673

    new-instance v0, Lh92;

    invoke-direct {v0, v13}, Lh92;-><init>([B)V

    move-object v12, v7

    check-cast v12, Ll3j;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    shl-int/lit8 v12, v11, 0x3

    or-int/lit8 v12, v12, 0x2

    invoke-virtual {v1, v12, v0}, Landroidx/health/platform/client/proto/b0;->d(ILjava/lang/Object;)V

    invoke-interface {v10}, Ljava/util/Iterator;->remove()V

    :goto_66d
    move/from16 v0, v23

    move/from16 v15, v24

    goto/16 :goto_5e8

    :cond_673
    const-string v0, "Did not write as much data as expected."

    invoke-static {v0}, Le97;->j(Ljava/lang/String;)V

    return v22

    :catch_679
    move-exception v0

    invoke-static {v0}, Lmf6;->h(Ljava/lang/Throwable;)V

    return v22

    :goto_67e
    add-int/lit8 v0, v23, 0x1

    move/from16 v15, v24

    const v10, 0xfffff

    goto/16 :goto_5aa

    :cond_687
    if-eqz v1, :cond_693

    check-cast v7, Ll3j;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, v8

    check-cast v0, Landroidx/health/platform/client/proto/n;

    iput-object v1, v0, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    :cond_693
    if-nez v9, :cond_69d

    if-ne v5, v4, :cond_698

    goto :goto_6a1

    :cond_698
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->c()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_69d
    if-gt v5, v4, :cond_6a2

    if-ne v14, v9, :cond_6a2

    :goto_6a1
    return v5

    :cond_6a2
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->c()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_6a7
    move-object v8, v2

    const/16 v22, 0x0

    const-string v0, "Mutating immutable message: "

    invoke-static {v0, v8}, Lb40;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le97;->p(Ljava/lang/String;)V

    return v22

    :pswitch_data_6b4
    .packed-switch 0x0
        :pswitch_3bf  #00000000
        :pswitch_39e  #00000001
        :pswitch_37e  #00000002
        :pswitch_37e  #00000003
        :pswitch_35c  #00000004
        :pswitch_31a  #00000005
        :pswitch_2fe  #00000006
        :pswitch_2d6  #00000007
        :pswitch_265  #00000008
        :pswitch_220  #00000009
        :pswitch_202  #0000000a
        :pswitch_35c  #0000000b
        :pswitch_192  #0000000c
        :pswitch_2fe  #0000000d
        :pswitch_31a  #0000000e
        :pswitch_160  #0000000f
        :pswitch_119  #00000010
        :pswitch_d3  #00000011
    .end packed-switch
.end method

.method public final B(Ljava/lang/Object;[BIIIIIIIJILpq0;)I
    .registers 30

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v9, p6

    move/from16 v3, p7

    move-wide/from16 v4, p10

    move/from16 v10, p12

    sget-object v6, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    add-int/lit8 v7, v10, 0x2

    iget-object v8, v0, Landroidx/health/platform/client/proto/p;->a:[I

    aget v7, v8, v7

    const v8, 0xfffff

    and-int/2addr v7, v8

    int-to-long v7, v7

    const/4 v11, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x2

    packed-switch p9, :pswitch_data_1f0

    :cond_1f
    move/from16 v2, p3

    goto/16 :goto_1ef

    :pswitch_23  #0x44
    const/4 v4, 0x3

    if-ne v3, v4, :cond_1f

    move/from16 v11, p5

    invoke-virtual {v0, v9, v1, v10}, Landroidx/health/platform/client/proto/p;->v(ILjava/lang/Object;I)Ljava/lang/Object;

    move-result-object v2

    and-int/lit8 v3, v11, -0x8

    or-int/lit8 v7, v3, 0x4

    invoke-virtual {v0, v10}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v3

    move-object/from16 v4, p2

    move/from16 v5, p3

    move/from16 v6, p4

    move-object/from16 v8, p13

    invoke-static/range {v2 .. v8}, Lckl;->s(Ljava/lang/Object;Layf;[BIIILpq0;)I

    move-result v3

    invoke-virtual {v0, v9, v1, v2, v10}, Landroidx/health/platform/client/proto/p;->H(ILjava/lang/Object;Ljava/lang/Object;I)V

    return v3

    :pswitch_44  #0x43
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-nez v3, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v2, v15, Lpq0;->b:J

    invoke-static {v2, v3}, Lthl;->e(J)J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v6, v1, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_61  #0x42
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-nez v3, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v15, Lpq0;->a:I

    invoke-static {v2}, Lthl;->d(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v6, v1, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_7e  #0x3f
    move-object/from16 v14, p2

    move/from16 v2, p3

    move/from16 v11, p5

    move-object/from16 v15, p13

    if-nez v3, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->n([BILpq0;)I

    move-result v2

    iget v3, v15, Lpq0;->a:I

    invoke-virtual {v0, v10}, Landroidx/health/platform/client/proto/p;->l(I)Ltgd;

    move-result-object v0

    if-eqz v0, :cond_bf

    if-eqz v3, :cond_a2

    if-eq v3, v12, :cond_9f

    if-eq v3, v13, :cond_9c

    const/4 v0, 0x0

    goto :goto_a4

    :cond_9c
    sget-object v0, Lugd;->H:Lugd;

    goto :goto_a4

    :cond_9f
    sget-object v0, Lugd;->G:Lugd;

    goto :goto_a4

    :cond_a2
    sget-object v0, Lugd;->F:Lugd;

    :goto_a4
    if-eqz v0, :cond_a7

    goto :goto_bf

    :cond_a7
    move-object v0, v1

    check-cast v0, Landroidx/health/platform/client/proto/n;

    iget-object v1, v0, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    sget-object v4, Landroidx/health/platform/client/proto/b0;->f:Landroidx/health/platform/client/proto/b0;

    if-ne v1, v4, :cond_b6

    invoke-static {}, Landroidx/health/platform/client/proto/b0;->c()Landroidx/health/platform/client/proto/b0;

    move-result-object v1

    iput-object v1, v0, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    :cond_b6
    int-to-long v3, v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v1, v11, v0}, Landroidx/health/platform/client/proto/b0;->d(ILjava/lang/Object;)V

    return v2

    :cond_bf
    :goto_bf
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v6, v1, v4, v5, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v2

    :pswitch_ca  #0x3d
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-ne v3, v13, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->h([BILpq0;)I

    move-result v0

    iget-object v2, v15, Lpq0;->c:Ljava/lang/Object;

    invoke-virtual {v6, v1, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_df  #0x3c
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-ne v3, v13, :cond_1ef

    invoke-virtual {v0, v9, v1, v10}, Landroidx/health/platform/client/proto/p;->v(ILjava/lang/Object;I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v10}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v3

    move/from16 v5, p3

    move/from16 v6, p4

    move-object v4, v14

    move-object v7, v15

    invoke-static/range {v2 .. v7}, Lckl;->t(Ljava/lang/Object;Layf;[BIILpq0;)I

    move-result v3

    invoke-virtual {v0, v9, v1, v2, v10}, Landroidx/health/platform/client/proto/p;->H(ILjava/lang/Object;Ljava/lang/Object;I)V

    return v3

    :pswitch_fd  #0x3b
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-ne v3, v13, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v15, Lpq0;->a:I

    if-nez v2, :cond_113

    const-string v2, ""

    invoke-virtual {v6, v1, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_134

    :cond_113
    const/high16 v3, 0x20000000

    and-int v3, p8, v3

    if-eqz v3, :cond_129

    add-int v3, v0, v2

    sget-object v10, Landroidx/health/platform/client/proto/d0;->a:Lval;

    invoke-virtual {v10, v14, v0, v3}, Lval;->i([BII)I

    move-result v3

    if-nez v3, :cond_124

    goto :goto_129

    :cond_124
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->a()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_129
    :goto_129
    new-instance v3, Ljava/lang/String;

    sget-object v10, Lhl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v3, v14, v0, v2, v10}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-virtual {v6, v1, v4, v5, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/2addr v0, v2

    :goto_134
    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_138  #0x3a
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-nez v3, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v2, v15, Lpq0;->b:J

    const-wide/16 v10, 0x0

    cmp-long v2, v2, v10

    if-eqz v2, :cond_14d

    goto :goto_14e

    :cond_14d
    const/4 v12, 0x0

    :goto_14e
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v6, v1, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_159  #0x39, 0x40
    move-object/from16 v14, p2

    move/from16 v2, p3

    if-ne v3, v11, :cond_1ef

    invoke-static/range {p2 .. p3}, Lckl;->i([BI)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v6, v1, v4, v5, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v2, 0x4

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_170  #0x38, 0x41
    move-object/from16 v14, p2

    move/from16 v2, p3

    if-ne v3, v12, :cond_1ef

    invoke-static/range {p2 .. p3}, Lckl;->j([BI)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v6, v1, v4, v5, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v2, 0x8

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_187  #0x37, 0x3e
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-nez v3, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v15, Lpq0;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v6, v1, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_1a0  #0x35, 0x36
    move-object/from16 v14, p2

    move/from16 v2, p3

    move-object/from16 v15, p13

    if-nez v3, :cond_1ef

    invoke-static {v14, v2, v15}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v2, v15, Lpq0;->b:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v6, v1, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_1b9  #0x34
    move-object/from16 v14, p2

    move/from16 v2, p3

    if-ne v3, v11, :cond_1ef

    invoke-static/range {p2 .. p3}, Lckl;->i([BI)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-virtual {v6, v1, v4, v5, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v2, 0x4

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_1d4  #0x33
    move-object/from16 v14, p2

    move/from16 v2, p3

    if-ne v3, v12, :cond_1ef

    invoke-static/range {p2 .. p3}, Lckl;->j([BI)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    invoke-virtual {v6, v1, v4, v5, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v2, 0x8

    invoke-virtual {v6, v1, v7, v8, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :cond_1ef
    :goto_1ef
    return v2

    :pswitch_data_1f0
    .packed-switch 0x33
        :pswitch_1d4  #00000033
        :pswitch_1b9  #00000034
        :pswitch_1a0  #00000035
        :pswitch_1a0  #00000036
        :pswitch_187  #00000037
        :pswitch_170  #00000038
        :pswitch_159  #00000039
        :pswitch_138  #0000003a
        :pswitch_fd  #0000003b
        :pswitch_df  #0000003c
        :pswitch_ca  #0000003d
        :pswitch_187  #0000003e
        :pswitch_7e  #0000003f
        :pswitch_159  #00000040
        :pswitch_170  #00000041
        :pswitch_61  #00000042
        :pswitch_44  #00000043
        :pswitch_23  #00000044
    .end packed-switch
.end method

.method public final C(Ljava/lang/Object;[BIIIIIIJIJLpq0;)I
    .registers 32

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p5

    move/from16 v3, p7

    move/from16 v8, p8

    move-wide/from16 v4, p12

    sget-object v6, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {v6, v1, v4, v5}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ldl9;

    move-object v9, v7

    check-cast v9, Lp3;

    iget-boolean v9, v9, Lp3;->E:Z

    const/4 v10, 0x2

    if-nez v9, :cond_2d

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v9

    if-nez v9, :cond_25

    const/16 v9, 0xa

    goto :goto_26

    :cond_25
    mul-int/2addr v9, v10

    :goto_26
    invoke-interface {v7, v9}, Ldl9;->l(I)Ldl9;

    move-result-object v7

    invoke-virtual {v6, v1, v4, v5, v7}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :cond_2d
    move-object v6, v7

    const/4 v9, 0x3

    const/4 v4, 0x5

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x1

    packed-switch p11, :pswitch_data_55e

    :cond_37
    move/from16 v11, p3

    goto/16 :goto_55d

    :pswitch_3b  #0x31
    if-ne v3, v9, :cond_37

    invoke-virtual {v0, v8}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v0

    and-int/lit8 v1, v2, -0x8

    or-int/lit8 v1, v1, 0x4

    invoke-interface {v0}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object v3

    move-object/from16 p8, p2

    move/from16 p9, p3

    move/from16 p10, p4

    move-object/from16 p12, p14

    move-object/from16 p7, v0

    move/from16 p11, v1

    move-object/from16 p6, v3

    invoke-static/range {p6 .. p12}, Lckl;->s(Ljava/lang/Object;Layf;[BIIILpq0;)I

    move-result v0

    move-object/from16 v8, p6

    move-object/from16 v1, p7

    move-object/from16 v3, p8

    move/from16 v5, p10

    move/from16 v4, p11

    move-object/from16 v7, p12

    invoke-interface {v1, v8}, Layf;->b(Ljava/lang/Object;)V

    iput-object v8, v7, Lpq0;->c:Ljava/lang/Object;

    invoke-interface {v6, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_6f
    if-ge v0, v5, :cond_a4

    invoke-static {v3, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v8

    iget v9, v7, Lpq0;->a:I

    if-eq v2, v9, :cond_7a

    goto :goto_a4

    :cond_7a
    invoke-interface {v1}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object v0

    move-object/from16 p6, v0

    move-object/from16 p7, v1

    move-object/from16 p8, v3

    move/from16 p11, v4

    move/from16 p10, v5

    move-object/from16 p12, v7

    move/from16 p9, v8

    invoke-static/range {p6 .. p12}, Lckl;->s(Ljava/lang/Object;Layf;[BIIILpq0;)I

    move-result v0

    move-object/from16 v8, p6

    move-object/from16 v4, p8

    move/from16 v3, p11

    invoke-interface {v1, v8}, Layf;->b(Ljava/lang/Object;)V

    iput-object v8, v7, Lpq0;->c:Ljava/lang/Object;

    invoke-interface {v6, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object/from16 v16, v4

    move v4, v3

    move-object/from16 v3, v16

    goto :goto_6f

    :cond_a4
    :goto_a4
    return v0

    :pswitch_a5  #0x22, 0x30
    move-object/from16 v4, p2

    move/from16 v11, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_d0

    check-cast v6, Ljxa;

    invoke-static {v4, v11, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v1, v7, Lpq0;->a:I

    add-int/2addr v1, v0

    :goto_b8
    if-ge v0, v1, :cond_c8

    invoke-static {v4, v0, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v2, v7, Lpq0;->b:J

    invoke-static {v2, v3}, Lthl;->e(J)J

    move-result-wide v2

    invoke-virtual {v6, v2, v3}, Ljxa;->b(J)V

    goto :goto_b8

    :cond_c8
    if-ne v0, v1, :cond_cb

    return v0

    :cond_cb
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_d0
    if-nez v3, :cond_55d

    check-cast v6, Ljxa;

    invoke-static {v4, v11, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v8, v7, Lpq0;->b:J

    invoke-static {v8, v9}, Lthl;->e(J)J

    move-result-wide v8

    invoke-virtual {v6, v8, v9}, Ljxa;->b(J)V

    :goto_e1
    if-ge v0, v5, :cond_fa

    invoke-static {v4, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v1

    iget v3, v7, Lpq0;->a:I

    if-eq v2, v3, :cond_ec

    goto :goto_fa

    :cond_ec
    invoke-static {v4, v1, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v8, v7, Lpq0;->b:J

    invoke-static {v8, v9}, Lthl;->e(J)J

    move-result-wide v8

    invoke-virtual {v6, v8, v9}, Ljxa;->b(J)V

    goto :goto_e1

    :cond_fa
    :goto_fa
    return v0

    :pswitch_fb  #0x21, 0x2f
    move-object/from16 v4, p2

    move/from16 v11, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_126

    check-cast v6, Lej9;

    invoke-static {v4, v11, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v1, v7, Lpq0;->a:I

    add-int/2addr v1, v0

    :goto_10e
    if-ge v0, v1, :cond_11e

    invoke-static {v4, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    invoke-static {v2}, Lthl;->d(I)I

    move-result v2

    invoke-virtual {v6, v2}, Lej9;->b(I)V

    goto :goto_10e

    :cond_11e
    if-ne v0, v1, :cond_121

    return v0

    :cond_121
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_126
    if-nez v3, :cond_55d

    check-cast v6, Lej9;

    invoke-static {v4, v11, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v1, v7, Lpq0;->a:I

    invoke-static {v1}, Lthl;->d(I)I

    move-result v1

    invoke-virtual {v6, v1}, Lej9;->b(I)V

    :goto_137
    if-ge v0, v5, :cond_150

    invoke-static {v4, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v1

    iget v3, v7, Lpq0;->a:I

    if-eq v2, v3, :cond_142

    goto :goto_150

    :cond_142
    invoke-static {v4, v1, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v1, v7, Lpq0;->a:I

    invoke-static {v1}, Lthl;->d(I)I

    move-result v1

    invoke-virtual {v6, v1}, Lej9;->b(I)V

    goto :goto_137

    :cond_150
    :goto_150
    return v0

    :pswitch_151  #0x1e, 0x2c
    move-object/from16 v4, p2

    move/from16 v11, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_179

    move-object v2, v6

    check-cast v2, Lej9;

    invoke-static {v4, v11, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v5, v7, Lpq0;->a:I

    add-int/2addr v5, v3

    :goto_165
    if-ge v3, v5, :cond_171

    invoke-static {v4, v3, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v11, v7, Lpq0;->a:I

    invoke-virtual {v2, v11}, Lej9;->b(I)V

    goto :goto_165

    :cond_171
    if-ne v3, v5, :cond_174

    goto :goto_181

    :cond_174
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_179
    if-nez v3, :cond_55d

    move-object v3, v4

    move v4, v11

    invoke-static/range {v2 .. v7}, Lckl;->o(I[BIILdl9;Lpq0;)I

    move-result v3

    :goto_181
    invoke-virtual {v0, v8}, Landroidx/health/platform/client/proto/p;->l(I)Ltgd;

    move-result-object v2

    sget-object v4, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    if-nez v2, :cond_18b

    goto/16 :goto_1ed

    :cond_18b
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x0

    move-object v7, v4

    move v5, v13

    :goto_192
    if-ge v13, v2, :cond_1e4

    invoke-interface {v6, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v11

    if-eqz v11, :cond_1ac

    if-eq v11, v14, :cond_1a9

    if-eq v11, v10, :cond_1a6

    move-object v12, v4

    goto :goto_1ae

    :cond_1a6
    sget-object v12, Lugd;->H:Lugd;

    goto :goto_1ae

    :cond_1a9
    sget-object v12, Lugd;->G:Lugd;

    goto :goto_1ae

    :cond_1ac
    sget-object v12, Lugd;->F:Lugd;

    :goto_1ae
    if-eqz v12, :cond_1b8

    if-eq v13, v5, :cond_1b5

    invoke-interface {v6, v5, v8}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_1b5
    add-int/lit8 v5, v5, 0x1

    goto :goto_1e1

    :cond_1b8
    iget-object v8, v0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    if-nez v7, :cond_1d2

    move-object v7, v8

    check-cast v7, Ll3j;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v7, v1

    check-cast v7, Landroidx/health/platform/client/proto/n;

    iget-object v12, v7, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    sget-object v15, Landroidx/health/platform/client/proto/b0;->f:Landroidx/health/platform/client/proto/b0;

    if-ne v12, v15, :cond_1d1

    invoke-static {}, Landroidx/health/platform/client/proto/b0;->c()Landroidx/health/platform/client/proto/b0;

    move-result-object v12

    iput-object v12, v7, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    :cond_1d1
    move-object v7, v12

    :cond_1d2
    int-to-long v11, v11

    check-cast v8, Ll3j;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    shl-int/lit8 v8, p6, 0x3

    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    invoke-virtual {v7, v8, v11}, Landroidx/health/platform/client/proto/b0;->d(ILjava/lang/Object;)V

    :goto_1e1
    add-int/lit8 v13, v13, 0x1

    goto :goto_192

    :cond_1e4
    if-eq v5, v2, :cond_1ed

    invoke-interface {v6, v5, v2}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    :cond_1ed
    :goto_1ed
    return v3

    :pswitch_1ee  #0x1c
    move-object/from16 v1, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_250

    invoke-static {v1, v4, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v3, v7, Lpq0;->a:I

    if-ltz v3, :cond_24b

    array-length v4, v1

    sub-int/2addr v4, v0

    if-gt v3, v4, :cond_246

    if-nez v3, :cond_20c

    sget-object v3, Lh92;->G:Lh92;

    invoke-interface {v6, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_214

    :cond_20c
    invoke-static {v1, v0, v3}, Lh92;->c([BII)Lh92;

    move-result-object v4

    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_213
    add-int/2addr v0, v3

    :goto_214
    if-ge v0, v5, :cond_245

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v7, Lpq0;->a:I

    if-eq v2, v4, :cond_21f

    goto :goto_245

    :cond_21f
    invoke-static {v1, v3, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v3, v7, Lpq0;->a:I

    if-ltz v3, :cond_240

    array-length v4, v1

    sub-int/2addr v4, v0

    if-gt v3, v4, :cond_23b

    if-nez v3, :cond_233

    sget-object v3, Lh92;->G:Lh92;

    invoke-interface {v6, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_214

    :cond_233
    invoke-static {v1, v0, v3}, Lh92;->c([BII)Lh92;

    move-result-object v4

    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_213

    :cond_23b
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_240
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_245
    :goto_245
    return v0

    :cond_246
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_24b
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_250
    move v11, v4

    goto/16 :goto_55d

    :pswitch_253  #0x1b
    move-object/from16 v1, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_250

    invoke-virtual {v0, v8}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v0

    move-object/from16 p6, v0

    move-object/from16 p8, v1

    move/from16 p7, v2

    move/from16 p9, v4

    move/from16 p10, v5

    move-object/from16 p11, v6

    move-object/from16 p12, v7

    invoke-static/range {p6 .. p12}, Lckl;->k(Layf;I[BIILdl9;Lpq0;)I

    move-result v0

    return v0

    :pswitch_274  #0x1a
    move-object/from16 v1, p2

    move/from16 v0, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_337

    const-wide/32 v3, 0x20000000

    and-long v3, p9, v3

    cmp-long v3, v3, v11

    const-string v4, ""

    if-nez v3, :cond_2d1

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v3, v7, Lpq0;->a:I

    if-ltz v3, :cond_2cc

    if-nez v3, :cond_297

    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2a2

    :cond_297
    new-instance v8, Ljava/lang/String;

    sget-object v9, Lhl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v8, v1, v0, v3, v9}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-interface {v6, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_2a1
    add-int/2addr v0, v3

    :goto_2a2
    if-ge v0, v5, :cond_2cb

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v8, v7, Lpq0;->a:I

    if-eq v2, v8, :cond_2ad

    goto :goto_2cb

    :cond_2ad
    invoke-static {v1, v3, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v3, v7, Lpq0;->a:I

    if-ltz v3, :cond_2c6

    if-nez v3, :cond_2bb

    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2a2

    :cond_2bb
    new-instance v8, Ljava/lang/String;

    sget-object v9, Lhl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v8, v1, v0, v3, v9}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-interface {v6, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2a1

    :cond_2c6
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_2cb
    :goto_2cb
    return v0

    :cond_2cc
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_2d1
    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v3, v7, Lpq0;->a:I

    if-ltz v3, :cond_332

    if-nez v3, :cond_2df

    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2f4

    :cond_2df
    add-int v8, v0, v3

    sget-object v9, Landroidx/health/platform/client/proto/d0;->a:Lval;

    invoke-virtual {v9, v1, v0, v8}, Lval;->i([BII)I

    move-result v9

    if-nez v9, :cond_32d

    new-instance v9, Ljava/lang/String;

    sget-object v10, Lhl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v9, v1, v0, v3, v10}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-interface {v6, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_2f3
    move v0, v8

    :goto_2f4
    if-ge v0, v5, :cond_32c

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v8, v7, Lpq0;->a:I

    if-eq v2, v8, :cond_2ff

    goto :goto_32c

    :cond_2ff
    invoke-static {v1, v3, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v3, v7, Lpq0;->a:I

    if-ltz v3, :cond_327

    if-nez v3, :cond_30d

    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2f4

    :cond_30d
    add-int v8, v0, v3

    sget-object v9, Landroidx/health/platform/client/proto/d0;->a:Lval;

    invoke-virtual {v9, v1, v0, v8}, Lval;->i([BII)I

    move-result v9

    if-nez v9, :cond_322

    new-instance v9, Ljava/lang/String;

    sget-object v10, Lhl9;->a:Ljava/nio/charset/Charset;

    invoke-direct {v9, v1, v0, v3, v10}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-interface {v6, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2f3

    :cond_322
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->a()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_327
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_32c
    :goto_32c
    return v0

    :cond_32d
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->a()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_332
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->b()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_337
    move v11, v0

    goto/16 :goto_55d

    :pswitch_33a  #0x19, 0x2a
    move-object/from16 v1, p2

    move/from16 v0, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_368

    check-cast v6, Lkz1;

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    add-int/2addr v2, v0

    :goto_34d
    if-ge v0, v2, :cond_360

    invoke-static {v1, v0, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v3, v7, Lpq0;->b:J

    cmp-long v3, v3, v11

    if-eqz v3, :cond_35b

    move v3, v14

    goto :goto_35c

    :cond_35b
    move v3, v13

    :goto_35c
    invoke-virtual {v6, v3}, Lkz1;->b(Z)V

    goto :goto_34d

    :cond_360
    if-ne v0, v2, :cond_363

    return v0

    :cond_363
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_368
    if-nez v3, :cond_337

    check-cast v6, Lkz1;

    invoke-static {v1, v0, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v3, v7, Lpq0;->b:J

    cmp-long v3, v3, v11

    if-eqz v3, :cond_378

    move v3, v14

    goto :goto_379

    :cond_378
    move v3, v13

    :goto_379
    invoke-virtual {v6, v3}, Lkz1;->b(Z)V

    :goto_37c
    if-ge v0, v5, :cond_398

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v7, Lpq0;->a:I

    if-eq v2, v4, :cond_387

    goto :goto_398

    :cond_387
    invoke-static {v1, v3, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v3, v7, Lpq0;->b:J

    cmp-long v3, v3, v11

    if-eqz v3, :cond_393

    move v3, v14

    goto :goto_394

    :cond_393
    move v3, v13

    :goto_394
    invoke-virtual {v6, v3}, Lkz1;->b(Z)V

    goto :goto_37c

    :cond_398
    :goto_398
    return v0

    :pswitch_399  #0x18, 0x1f, 0x29, 0x2d
    move-object/from16 v1, p2

    move/from16 v0, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_3c0

    check-cast v6, Lej9;

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    add-int/2addr v2, v0

    :goto_3ac
    if-ge v0, v2, :cond_3b8

    invoke-static {v1, v0}, Lckl;->i([BI)I

    move-result v3

    invoke-virtual {v6, v3}, Lej9;->b(I)V

    add-int/lit8 v0, v0, 0x4

    goto :goto_3ac

    :cond_3b8
    if-ne v0, v2, :cond_3bb

    return v0

    :cond_3bb
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_3c0
    if-ne v3, v4, :cond_337

    check-cast v6, Lej9;

    invoke-static/range {p2 .. p3}, Lckl;->i([BI)I

    move-result v3

    invoke-virtual {v6, v3}, Lej9;->b(I)V

    add-int/lit8 v0, v0, 0x4

    :goto_3cd
    if-ge v0, v5, :cond_3e2

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v7, Lpq0;->a:I

    if-eq v2, v4, :cond_3d8

    goto :goto_3e2

    :cond_3d8
    invoke-static {v1, v3}, Lckl;->i([BI)I

    move-result v0

    invoke-virtual {v6, v0}, Lej9;->b(I)V

    add-int/lit8 v0, v3, 0x4

    goto :goto_3cd

    :cond_3e2
    :goto_3e2
    return v0

    :pswitch_3e3  #0x17, 0x20, 0x28, 0x2e
    move-object/from16 v1, p2

    move/from16 v0, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_40a

    check-cast v6, Ljxa;

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    add-int/2addr v2, v0

    :goto_3f6
    if-ge v0, v2, :cond_402

    invoke-static {v1, v0}, Lckl;->j([BI)J

    move-result-wide v3

    invoke-virtual {v6, v3, v4}, Ljxa;->b(J)V

    add-int/lit8 v0, v0, 0x8

    goto :goto_3f6

    :cond_402
    if-ne v0, v2, :cond_405

    return v0

    :cond_405
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_40a
    if-ne v3, v14, :cond_337

    check-cast v6, Ljxa;

    invoke-static/range {p2 .. p3}, Lckl;->j([BI)J

    move-result-wide v3

    invoke-virtual {v6, v3, v4}, Ljxa;->b(J)V

    add-int/lit8 v0, v0, 0x8

    :goto_417
    if-ge v0, v5, :cond_42c

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v7, Lpq0;->a:I

    if-eq v2, v4, :cond_422

    goto :goto_42c

    :cond_422
    invoke-static {v1, v3}, Lckl;->j([BI)J

    move-result-wide v8

    invoke-virtual {v6, v8, v9}, Ljxa;->b(J)V

    add-int/lit8 v0, v3, 0x8

    goto :goto_417

    :cond_42c
    :goto_42c
    return v0

    :pswitch_42d  #0x16, 0x1d, 0x27, 0x2b
    move-object/from16 v1, p2

    move/from16 v0, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_454

    check-cast v6, Lej9;

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    add-int/2addr v2, v0

    :goto_440
    if-ge v0, v2, :cond_44c

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v3, v7, Lpq0;->a:I

    invoke-virtual {v6, v3}, Lej9;->b(I)V

    goto :goto_440

    :cond_44c
    if-ne v0, v2, :cond_44f

    return v0

    :cond_44f
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_454
    if-nez v3, :cond_337

    move/from16 p8, v0

    move-object/from16 p7, v1

    move/from16 p6, v2

    move/from16 p9, v5

    move-object/from16 p10, v6

    move-object/from16 p11, v7

    invoke-static/range {p6 .. p11}, Lckl;->o(I[BIILdl9;Lpq0;)I

    move-result v0

    return v0

    :pswitch_467  #0x14, 0x15, 0x25, 0x26
    move-object/from16 v1, p2

    move/from16 v11, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_48e

    check-cast v6, Ljxa;

    invoke-static {v1, v11, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    add-int/2addr v2, v0

    :goto_47a
    if-ge v0, v2, :cond_486

    invoke-static {v1, v0, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v3, v7, Lpq0;->b:J

    invoke-virtual {v6, v3, v4}, Ljxa;->b(J)V

    goto :goto_47a

    :cond_486
    if-ne v0, v2, :cond_489

    return v0

    :cond_489
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_48e
    if-nez v3, :cond_55d

    check-cast v6, Ljxa;

    invoke-static {v1, v11, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v3, v7, Lpq0;->b:J

    invoke-virtual {v6, v3, v4}, Ljxa;->b(J)V

    :goto_49b
    if-ge v0, v5, :cond_4b0

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v7, Lpq0;->a:I

    if-eq v2, v4, :cond_4a6

    goto :goto_4b0

    :cond_4a6
    invoke-static {v1, v3, v7}, Lckl;->p([BILpq0;)I

    move-result v0

    iget-wide v3, v7, Lpq0;->b:J

    invoke-virtual {v6, v3, v4}, Ljxa;->b(J)V

    goto :goto_49b

    :cond_4b0
    :goto_4b0
    return v0

    :pswitch_4b1  #0x13, 0x24
    move-object/from16 v1, p2

    move/from16 v11, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_4dc

    check-cast v6, Lty7;

    invoke-static {v1, v11, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    add-int/2addr v2, v0

    :goto_4c4
    if-ge v0, v2, :cond_4d4

    invoke-static {v1, v0}, Lckl;->i([BI)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v3

    invoke-virtual {v6, v3}, Lty7;->b(F)V

    add-int/lit8 v0, v0, 0x4

    goto :goto_4c4

    :cond_4d4
    if-ne v0, v2, :cond_4d7

    return v0

    :cond_4d7
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_4dc
    if-ne v3, v4, :cond_55d

    check-cast v6, Lty7;

    invoke-static/range {p2 .. p3}, Lckl;->i([BI)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    invoke-virtual {v6, v0}, Lty7;->b(F)V

    add-int/lit8 v0, v11, 0x4

    :goto_4ed
    if-ge v0, v5, :cond_506

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v7, Lpq0;->a:I

    if-eq v2, v4, :cond_4f8

    goto :goto_506

    :cond_4f8
    invoke-static {v1, v3}, Lckl;->i([BI)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    invoke-virtual {v6, v0}, Lty7;->b(F)V

    add-int/lit8 v0, v3, 0x4

    goto :goto_4ed

    :cond_506
    :goto_506
    return v0

    :pswitch_507  #0x12, 0x23
    move-object/from16 v1, p2

    move/from16 v11, p3

    move/from16 v5, p4

    move-object/from16 v7, p14

    if-ne v3, v10, :cond_532

    check-cast v6, Ldj6;

    invoke-static {v1, v11, v7}, Lckl;->n([BILpq0;)I

    move-result v0

    iget v2, v7, Lpq0;->a:I

    add-int/2addr v2, v0

    :goto_51a
    if-ge v0, v2, :cond_52a

    invoke-static {v1, v0}, Lckl;->j([BI)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v3

    invoke-virtual {v6, v3, v4}, Ldj6;->b(D)V

    add-int/lit8 v0, v0, 0x8

    goto :goto_51a

    :cond_52a
    if-ne v0, v2, :cond_52d

    return v0

    :cond_52d
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object v0

    throw v0

    :cond_532
    if-ne v3, v14, :cond_55d

    check-cast v6, Ldj6;

    invoke-static/range {p2 .. p3}, Lckl;->j([BI)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v3

    invoke-virtual {v6, v3, v4}, Ldj6;->b(D)V

    add-int/lit8 v0, v11, 0x8

    :goto_543
    if-ge v0, v5, :cond_55c

    invoke-static {v1, v0, v7}, Lckl;->n([BILpq0;)I

    move-result v3

    iget v4, v7, Lpq0;->a:I

    if-eq v2, v4, :cond_54e

    goto :goto_55c

    :cond_54e
    invoke-static {v1, v3}, Lckl;->j([BI)J

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v8

    invoke-virtual {v6, v8, v9}, Ldj6;->b(D)V

    add-int/lit8 v0, v3, 0x8

    goto :goto_543

    :cond_55c
    :goto_55c
    return v0

    :cond_55d
    :goto_55d
    return v11

    :pswitch_data_55e
    .packed-switch 0x12
        :pswitch_507  #00000012
        :pswitch_4b1  #00000013
        :pswitch_467  #00000014
        :pswitch_467  #00000015
        :pswitch_42d  #00000016
        :pswitch_3e3  #00000017
        :pswitch_399  #00000018
        :pswitch_33a  #00000019
        :pswitch_274  #0000001a
        :pswitch_253  #0000001b
        :pswitch_1ee  #0000001c
        :pswitch_42d  #0000001d
        :pswitch_151  #0000001e
        :pswitch_399  #0000001f
        :pswitch_3e3  #00000020
        :pswitch_fb  #00000021
        :pswitch_a5  #00000022
        :pswitch_507  #00000023
        :pswitch_4b1  #00000024
        :pswitch_467  #00000025
        :pswitch_467  #00000026
        :pswitch_42d  #00000027
        :pswitch_3e3  #00000028
        :pswitch_399  #00000029
        :pswitch_33a  #0000002a
        :pswitch_42d  #0000002b
        :pswitch_151  #0000002c
        :pswitch_399  #0000002d
        :pswitch_3e3  #0000002e
        :pswitch_fb  #0000002f
        :pswitch_a5  #00000030
        :pswitch_3b  #00000031
    .end packed-switch
.end method

.method public final E(ILjava/lang/Object;)V
    .registers 7

    add-int/lit8 p1, p1, 0x2

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    aget p0, p0, p1

    const p1, 0xfffff

    and-int/2addr p1, p0

    int-to-long v0, p1

    const-wide/32 v2, 0xfffff

    cmp-long p1, v0, v2

    if-nez p1, :cond_13

    return-void

    :cond_13
    ushr-int/lit8 p0, p0, 0x14

    const/4 p1, 0x1

    shl-int p0, p1, p0

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    or-int/2addr p0, p1

    invoke-static {p0, v0, v1, p2}, Lj5j;->n(IJLjava/lang/Object;)V

    return-void
.end method

.method public final F(II)I
    .registers 7

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    array-length v0, p0

    div-int/lit8 v0, v0, 0x3

    add-int/lit8 v0, v0, -0x1

    :goto_7
    if-gt p2, v0, :cond_1e

    add-int v1, v0, p2

    ushr-int/lit8 v1, v1, 0x1

    mul-int/lit8 v2, v1, 0x3

    aget v3, p0, v2

    if-ne p1, v3, :cond_14

    return v2

    :cond_14
    if-ge p1, v3, :cond_1a

    add-int/lit8 v1, v1, -0x1

    move v0, v1

    goto :goto_7

    :cond_1a
    add-int/lit8 v1, v1, 0x1

    move p2, v1

    goto :goto_7

    :cond_1e
    const/4 p0, -0x1

    return p0
.end method

.method public final G(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 7

    sget-object v0, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {p0, p2}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {v0, p1, v1, v2, p3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    invoke-virtual {p0, p2, p1}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    return-void
.end method

.method public final H(ILjava/lang/Object;Ljava/lang/Object;I)V
    .registers 10

    sget-object v0, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {p0, p4}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v3, v1

    invoke-virtual {v0, p2, v3, v4, p3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 p4, p4, 0x2

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    aget p0, p0, p4

    and-int/2addr p0, v2

    int-to-long p3, p0

    invoke-static {p1, p3, p4, p2}, Lj5j;->n(IJLjava/lang/Object;)V

    return-void
.end method

.method public final J(I)I
    .registers 2

    add-int/lit8 p1, p1, 0x1

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    aget p0, p0, p1

    return p0
.end method

.method public final K(Ljava/lang/Object;Lgkf;)V
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v6, p2

    iget-object v7, v0, Landroidx/health/platform/client/proto/p;->a:[I

    array-length v8, v7

    sget-object v9, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    const v10, 0xfffff

    move v3, v10

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_11
    if-ge v2, v8, :cond_663

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v5

    aget v12, v7, v2

    invoke-static {v5}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v13

    const/16 v14, 0x11

    if-gt v13, v14, :cond_3b

    add-int/lit8 v14, v2, 0x2

    aget v14, v7, v14

    const/16 v16, 0x1

    and-int v15, v14, v10

    if-eq v15, v3, :cond_36

    if-ne v15, v10, :cond_2f

    const/4 v4, 0x0

    goto :goto_35

    :cond_2f
    int-to-long v3, v15

    invoke-virtual {v9, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    move v4, v3

    :goto_35
    move v3, v15

    :cond_36
    ushr-int/lit8 v14, v14, 0x14

    shl-int v14, v16, v14

    goto :goto_3e

    :cond_3b
    const/16 v16, 0x1

    const/4 v14, 0x0

    :goto_3e
    and-int/2addr v5, v10

    int-to-long v10, v5

    const/16 v17, 0x3f

    const/4 v5, 0x2

    packed-switch v13, :pswitch_data_674

    :cond_46
    :goto_46
    const/4 v13, 0x0

    goto/16 :goto_65c

    :pswitch_49  #0x44
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v10

    invoke-virtual {v6, v12, v5, v10}, Lgkf;->H(ILjava/lang/Object;Layf;)V

    goto :goto_46

    :pswitch_5b  #0x43
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    shl-long v13, v10, v16

    shr-long v10, v10, v17

    xor-long/2addr v10, v13

    invoke-virtual {v5, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    goto :goto_46

    :pswitch_72  #0x42
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    shl-int/lit8 v11, v5, 0x1

    shr-int/lit8 v5, v5, 0x1f

    xor-int/2addr v5, v11

    invoke-virtual {v10, v12, v5}, Landroidx/health/platform/client/proto/b;->s(II)V

    goto :goto_46

    :pswitch_89  #0x41
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    goto :goto_46

    :pswitch_9b  #0x40
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v10, v12, v5}, Landroidx/health/platform/client/proto/b;->k(II)V

    goto :goto_46

    :pswitch_ad  #0x3f
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v10, v12, v5}, Landroidx/health/platform/client/proto/b;->o(II)V

    goto :goto_46

    :pswitch_bf  #0x3e
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v10, v12, v5}, Landroidx/health/platform/client/proto/b;->s(II)V

    goto/16 :goto_46

    :pswitch_d2  #0x3d
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v13

    if-eqz v13, :cond_46

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lh92;

    iget-object v11, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v11, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v11, v12, v5}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v11, v10}, Landroidx/health/platform/client/proto/b;->j(Lh92;)V

    goto/16 :goto_46

    :pswitch_ea  #0x3c
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v10

    invoke-virtual {v6, v12, v5, v10}, Lgkf;->I(ILjava/lang/Object;Layf;)V

    goto/16 :goto_46

    :pswitch_fd  #0x3b
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v13

    if-eqz v13, :cond_46

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    instance-of v11, v10, Ljava/lang/String;

    if-eqz v11, :cond_119

    check-cast v10, Ljava/lang/String;

    iget-object v11, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v11, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v11, v12, v5}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v11, v10}, Landroidx/health/platform/client/proto/b;->q(Ljava/lang/String;)V

    goto/16 :goto_46

    :cond_119
    check-cast v10, Lh92;

    iget-object v11, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v11, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v11, v12, v5}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v11, v10}, Landroidx/health/platform/client/proto/b;->j(Lh92;)V

    goto/16 :goto_46

    :pswitch_127  #0x3a
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v10, v11, v1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    const/4 v11, 0x0

    invoke-virtual {v10, v12, v11}, Landroidx/health/platform/client/proto/b;->r(II)V

    int-to-byte v5, v5

    invoke-virtual {v10, v5}, Landroidx/health/platform/client/proto/b;->h(B)V

    goto/16 :goto_46

    :pswitch_147  #0x39
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v10, v12, v5}, Landroidx/health/platform/client/proto/b;->k(II)V

    goto/16 :goto_46

    :pswitch_15a  #0x38
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    goto/16 :goto_46

    :pswitch_16d  #0x37
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v10, v12, v5}, Landroidx/health/platform/client/proto/b;->o(II)V

    goto/16 :goto_46

    :pswitch_180  #0x36
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    goto/16 :goto_46

    :pswitch_193  #0x35
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-static {v10, v11, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    goto/16 :goto_46

    :pswitch_1a6  #0x34
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v10, v11, v1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Float;

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    iget-object v10, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v10, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v5

    invoke-virtual {v10, v12, v5}, Landroidx/health/platform/client/proto/b;->k(II)V

    goto/16 :goto_46

    :pswitch_1c8  #0x33
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_46

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v10, v11, v1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Double;

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v10

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v11}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v10

    invoke-virtual {v5, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    goto/16 :goto_46

    :pswitch_1ea  #0x32
    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    if-eqz v10, :cond_46

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->m(I)Ljava/lang/Object;

    move-result-object v11

    iget-object v13, v0, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Lk5b;

    iget-object v11, v11, Lk5b;->a:Li79;

    check-cast v10, Lr5b;

    iget-object v13, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v13, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Lr5b;->entrySet()Ljava/util/Set;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_20e
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_46

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/util/Map$Entry;

    invoke-virtual {v13, v12, v5}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v15

    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    invoke-static {v11, v15, v5}, Lk5b;->a(Li79;Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v5

    invoke-virtual {v13, v5}, Landroidx/health/platform/client/proto/b;->t(I)V

    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v14

    invoke-static {v13, v11, v5, v14}, Lk5b;->b(Landroidx/health/platform/client/proto/b;Li79;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x2

    goto :goto_20e

    :pswitch_239  #0x31
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v11

    sget-object v12, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    if-eqz v10, :cond_46

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_46

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    :goto_253
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v13

    if-ge v12, v13, :cond_46

    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v6, v5, v13, v11}, Lgkf;->H(ILjava/lang/Object;Layf;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_253

    :pswitch_263  #0x30
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    move/from16 v12, v16

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->w(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_272  #0x2f
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->v(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_281  #0x2e
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->u(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_290  #0x2d
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->t(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_29f  #0x2c
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->n(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_2ae  #0x2b
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->x(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_2bd  #0x2a
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->l(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_2cc  #0x29
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->o(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_2db  #0x28
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->p(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_2ea  #0x27
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->r(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_2f9  #0x26
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->y(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_308  #0x25
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->s(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_317  #0x24
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->q(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_326  #0x23
    move/from16 v12, v16

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->m(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_46

    :pswitch_335  #0x22
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    const/4 v12, 0x0

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->w(ILjava/util/List;Lgkf;Z)V

    :goto_341
    move v13, v12

    goto/16 :goto_65c

    :pswitch_344  #0x21
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->v(ILjava/util/List;Lgkf;Z)V

    goto :goto_341

    :pswitch_351  #0x20
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->u(ILjava/util/List;Lgkf;Z)V

    goto :goto_341

    :pswitch_35e  #0x1f
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->t(ILjava/util/List;Lgkf;Z)V

    goto :goto_341

    :pswitch_36b  #0x1e
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->n(ILjava/util/List;Lgkf;Z)V

    goto :goto_341

    :pswitch_378  #0x1d
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->x(ILjava/util/List;Lgkf;Z)V

    goto :goto_341

    :pswitch_385  #0x1c
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    sget-object v11, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    if-eqz v10, :cond_46

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_46

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x0

    :goto_39b
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v12

    if-ge v11, v12, :cond_46

    iget-object v12, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v12, Landroidx/health/platform/client/proto/b;

    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lh92;

    const/4 v14, 0x2

    invoke-virtual {v12, v5, v14}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v12, v13}, Landroidx/health/platform/client/proto/b;->j(Lh92;)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_39b

    :pswitch_3b5  #0x1b
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v11

    sget-object v12, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    if-eqz v10, :cond_46

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_46

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    :goto_3cf
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v13

    if-ge v12, v13, :cond_46

    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v6, v5, v13, v11}, Lgkf;->I(ILjava/lang/Object;Layf;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_3cf

    :pswitch_3df  #0x1a
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    sget-object v11, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    if-eqz v10, :cond_46

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_46

    iget-object v11, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v11, Landroidx/health/platform/client/proto/b;

    instance-of v12, v10, Llea;

    if-eqz v12, :cond_421

    move-object v12, v10

    check-cast v12, Llea;

    const/4 v13, 0x0

    :goto_3fd
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v14

    if-ge v13, v14, :cond_46

    invoke-interface {v12}, Llea;->f()Ljava/lang/Object;

    move-result-object v14

    instance-of v15, v14, Ljava/lang/String;

    if-eqz v15, :cond_415

    check-cast v14, Ljava/lang/String;

    const/4 v15, 0x2

    invoke-virtual {v11, v5, v15}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v11, v14}, Landroidx/health/platform/client/proto/b;->q(Ljava/lang/String;)V

    goto :goto_41e

    :cond_415
    const/4 v15, 0x2

    check-cast v14, Lh92;

    invoke-virtual {v11, v5, v15}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v11, v14}, Landroidx/health/platform/client/proto/b;->j(Lh92;)V

    :goto_41e
    add-int/lit8 v13, v13, 0x1

    goto :goto_3fd

    :cond_421
    const/4 v12, 0x0

    :goto_422
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v13

    if-ge v12, v13, :cond_46

    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    const/4 v14, 0x2

    invoke-virtual {v11, v5, v14}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v11, v13}, Landroidx/health/platform/client/proto/b;->q(Ljava/lang/String;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_422

    :pswitch_438  #0x19
    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    const/4 v12, 0x0

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->l(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_446  #0x18
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->o(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_454  #0x17
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->p(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_462  #0x16
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->r(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_470  #0x15
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->y(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_47e  #0x14
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->s(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_48c  #0x13
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->q(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_49a  #0x12
    const/4 v12, 0x0

    aget v5, v7, v2

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/List;

    invoke-static {v5, v10, v6, v12}, Landroidx/health/platform/client/proto/y;->m(ILjava/util/List;Lgkf;Z)V

    goto/16 :goto_341

    :pswitch_4a8  #0x11
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v10

    invoke-virtual {v6, v12, v5, v10}, Lgkf;->H(ILjava/lang/Object;Layf;)V

    goto/16 :goto_46

    :pswitch_4bc  #0x10
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v0, Landroidx/health/platform/client/proto/b;

    const/16 v16, 0x1

    shl-long v13, v10, v16

    shr-long v10, v10, v17

    xor-long/2addr v10, v13

    invoke-virtual {v0, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    :cond_4d5
    :goto_4d5
    const/4 v13, 0x0

    :cond_4d6
    :goto_4d6
    move-object/from16 v0, p0

    goto/16 :goto_65c

    :pswitch_4da  #0xf
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    shl-int/lit8 v10, v0, 0x1

    shr-int/lit8 v0, v0, 0x1f

    xor-int/2addr v0, v10

    invoke-virtual {v5, v12, v0}, Landroidx/health/platform/client/proto/b;->s(II)V

    goto :goto_4d5

    :pswitch_4f2  #0xe
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v0, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    goto :goto_4d5

    :pswitch_505  #0xd
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v0}, Landroidx/health/platform/client/proto/b;->k(II)V

    goto :goto_4d5

    :pswitch_518  #0xc
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v0}, Landroidx/health/platform/client/proto/b;->o(II)V

    goto :goto_4d5

    :pswitch_52b  #0xb
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v0}, Landroidx/health/platform/client/proto/b;->s(II)V

    goto :goto_4d5

    :pswitch_53e  #0xa
    move/from16 v18, v14

    move v14, v5

    move/from16 v5, v18

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lh92;

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v14}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v5, v0}, Landroidx/health/platform/client/proto/b;->j(Lh92;)V

    goto/16 :goto_4d5

    :pswitch_55b  #0x9
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v10

    invoke-virtual {v6, v12, v5, v10}, Lgkf;->I(ILjava/lang/Object;Layf;)V

    goto/16 :goto_46

    :pswitch_56f  #0x8
    move/from16 v18, v14

    move v14, v5

    move/from16 v5, v18

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    instance-of v5, v0, Ljava/lang/String;

    if-eqz v5, :cond_590

    check-cast v0, Ljava/lang/String;

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v14}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v5, v0}, Landroidx/health/platform/client/proto/b;->q(Ljava/lang/String;)V

    goto/16 :goto_4d5

    :cond_590
    check-cast v0, Lh92;

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v14}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v5, v0}, Landroidx/health/platform/client/proto/b;->j(Lh92;)V

    goto/16 :goto_4d5

    :pswitch_59e  #0x7
    move v5, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d5

    sget-object v0, Lj5j;->c:Le5j;

    invoke-virtual {v0, v10, v11, v1}, Le5j;->c(JLjava/lang/Object;)Z

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    const/4 v13, 0x0

    invoke-virtual {v5, v12, v13}, Landroidx/health/platform/client/proto/b;->r(II)V

    int-to-byte v0, v0

    invoke-virtual {v5, v0}, Landroidx/health/platform/client/proto/b;->h(B)V

    goto/16 :goto_4d6

    :pswitch_5b9  #0x6
    move v5, v14

    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d6

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v0}, Landroidx/health/platform/client/proto/b;->k(II)V

    goto/16 :goto_4d6

    :pswitch_5ce  #0x5
    move v5, v14

    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d6

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v0, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    goto/16 :goto_4d6

    :pswitch_5e3  #0x4
    move v5, v14

    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d6

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5, v12, v0}, Landroidx/health/platform/client/proto/b;->o(II)V

    goto/16 :goto_4d6

    :pswitch_5f8  #0x3
    move v5, v14

    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d6

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v0, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    goto/16 :goto_4d6

    :pswitch_60d  #0x2
    move v5, v14

    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d6

    invoke-virtual {v9, v1, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    iget-object v0, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v0, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v0, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    goto/16 :goto_4d6

    :pswitch_622  #0x1
    move v5, v14

    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_4d6

    sget-object v0, Lj5j;->c:Le5j;

    invoke-virtual {v0, v10, v11, v1}, Le5j;->f(JLjava/lang/Object;)F

    move-result v0

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v0

    invoke-virtual {v5, v12, v0}, Landroidx/health/platform/client/proto/b;->k(II)V

    goto/16 :goto_4d6

    :pswitch_640  #0x0
    move v5, v14

    const/4 v13, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_65c

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v10, v11, v1}, Le5j;->e(JLjava/lang/Object;)D

    move-result-wide v10

    iget-object v5, v6, Lgkf;->E:Ljava/lang/Object;

    check-cast v5, Landroidx/health/platform/client/proto/b;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v11}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v10

    invoke-virtual {v5, v12, v10, v11}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    :cond_65c
    :goto_65c
    add-int/lit8 v2, v2, 0x3

    const v10, 0xfffff

    goto/16 :goto_11

    :cond_663
    iget-object v0, v0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    check-cast v0, Ll3j;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, v1

    check-cast v0, Landroidx/health/platform/client/proto/n;

    iget-object v0, v0, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    invoke-virtual {v0, v6}, Landroidx/health/platform/client/proto/b0;->e(Lgkf;)V

    return-void

    nop

    :pswitch_data_674
    .packed-switch 0x0
        :pswitch_640  #00000000
        :pswitch_622  #00000001
        :pswitch_60d  #00000002
        :pswitch_5f8  #00000003
        :pswitch_5e3  #00000004
        :pswitch_5ce  #00000005
        :pswitch_5b9  #00000006
        :pswitch_59e  #00000007
        :pswitch_56f  #00000008
        :pswitch_55b  #00000009
        :pswitch_53e  #0000000a
        :pswitch_52b  #0000000b
        :pswitch_518  #0000000c
        :pswitch_505  #0000000d
        :pswitch_4f2  #0000000e
        :pswitch_4da  #0000000f
        :pswitch_4bc  #00000010
        :pswitch_4a8  #00000011
        :pswitch_49a  #00000012
        :pswitch_48c  #00000013
        :pswitch_47e  #00000014
        :pswitch_470  #00000015
        :pswitch_462  #00000016
        :pswitch_454  #00000017
        :pswitch_446  #00000018
        :pswitch_438  #00000019
        :pswitch_3df  #0000001a
        :pswitch_3b5  #0000001b
        :pswitch_385  #0000001c
        :pswitch_378  #0000001d
        :pswitch_36b  #0000001e
        :pswitch_35e  #0000001f
        :pswitch_351  #00000020
        :pswitch_344  #00000021
        :pswitch_335  #00000022
        :pswitch_326  #00000023
        :pswitch_317  #00000024
        :pswitch_308  #00000025
        :pswitch_2f9  #00000026
        :pswitch_2ea  #00000027
        :pswitch_2db  #00000028
        :pswitch_2cc  #00000029
        :pswitch_2bd  #0000002a
        :pswitch_2ae  #0000002b
        :pswitch_29f  #0000002c
        :pswitch_290  #0000002d
        :pswitch_281  #0000002e
        :pswitch_272  #0000002f
        :pswitch_263  #00000030
        :pswitch_239  #00000031
        :pswitch_1ea  #00000032
        :pswitch_1c8  #00000033
        :pswitch_1a6  #00000034
        :pswitch_193  #00000035
        :pswitch_180  #00000036
        :pswitch_16d  #00000037
        :pswitch_15a  #00000038
        :pswitch_147  #00000039
        :pswitch_127  #0000003a
        :pswitch_fd  #0000003b
        :pswitch_ea  #0000003c
        :pswitch_d2  #0000003d
        :pswitch_bf  #0000003e
        :pswitch_ad  #0000003f
        :pswitch_9b  #00000040
        :pswitch_89  #00000041
        :pswitch_72  #00000042
        :pswitch_5b  #00000043
        :pswitch_49  #00000044
    .end packed-switch
.end method

.method public final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 14

    invoke-static {p1}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20e

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    :goto_a
    iget-object v1, p0, Landroidx/health/platform/client/proto/p;->a:[I

    array-length v2, v1

    if-ge v0, v2, :cond_207

    invoke-virtual {p0, v0}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v2

    const v3, 0xfffff

    and-int v4, v2, v3

    int-to-long v7, v4

    aget v4, v1, v0

    invoke-static {v2}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v2

    packed-switch v2, :pswitch_data_21a

    goto :goto_26

    :pswitch_23  #0x44
    invoke-virtual {p0, p1, v0, p2}, Landroidx/health/platform/client/proto/p;->t(Ljava/lang/Object;ILjava/lang/Object;)V

    :cond_26
    :goto_26
    move-object v6, p1

    goto/16 :goto_202

    :pswitch_29  #0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43
    invoke-virtual {p0, v4, p2, v0}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v2

    if-eqz v2, :cond_26

    sget-object v2, Lj5j;->c:Le5j;

    invoke-virtual {v2, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v7, v8, p1, v2}, Lj5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    add-int/lit8 v2, v0, 0x2

    aget v1, v1, v2

    and-int/2addr v1, v3

    int-to-long v1, v1

    invoke-static {v4, v1, v2, p1}, Lj5j;->n(IJLjava/lang/Object;)V

    goto :goto_26

    :pswitch_42  #0x3c
    invoke-virtual {p0, p1, v0, p2}, Landroidx/health/platform/client/proto/p;->t(Ljava/lang/Object;ILjava/lang/Object;)V

    goto :goto_26

    :pswitch_46  #0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b
    invoke-virtual {p0, v4, p2, v0}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v2

    if-eqz v2, :cond_26

    sget-object v2, Lj5j;->c:Le5j;

    invoke-virtual {v2, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v7, v8, p1, v2}, Lj5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    add-int/lit8 v2, v0, 0x2

    aget v1, v1, v2

    and-int/2addr v1, v3

    int-to-long v1, v1

    invoke-static {v4, v1, v2, p1}, Lj5j;->n(IJLjava/lang/Object;)V

    goto :goto_26

    :pswitch_5f  #0x32
    sget-object v1, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    sget-object v1, Lj5j;->c:Le5j;

    invoke-virtual {v1, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    iget-object v3, p0, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v1}, Lw5b;->a(Ljava/lang/Object;Ljava/lang/Object;)Lr5b;

    move-result-object v1

    invoke-static {v7, v8, p1, v1}, Lj5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    goto :goto_26

    :pswitch_78  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    iget-object v1, p0, Landroidx/health/platform/client/proto/p;->j:Lema;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lj5j;->c:Le5j;

    invoke-virtual {v1, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ldl9;

    invoke-virtual {v1, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ldl9;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v4

    if-lez v3, :cond_a6

    if-lez v4, :cond_a6

    move-object v5, v2

    check-cast v5, Lp3;

    iget-boolean v5, v5, Lp3;->E:Z

    if-nez v5, :cond_a3

    add-int/2addr v4, v3

    invoke-interface {v2, v4}, Ldl9;->l(I)Ldl9;

    move-result-object v2

    :cond_a3
    invoke-interface {v2, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_a6
    if-lez v3, :cond_a9

    move-object v1, v2

    :cond_a9
    invoke-static {v7, v8, p1, v1}, Lj5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_26

    :pswitch_ae  #0x11
    invoke-virtual {p0, p1, v0, p2}, Landroidx/health/platform/client/proto/p;->s(Ljava/lang/Object;ILjava/lang/Object;)V

    goto/16 :goto_26

    :pswitch_b3  #0x10
    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_26

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    move-object v6, p1

    invoke-virtual/range {v5 .. v10}, Le5j;->p(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_c8  #0xf
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    invoke-static {p1, v7, v8, v6}, Lj5j;->n(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_dd  #0xe
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual/range {v5 .. v10}, Le5j;->p(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_f2  #0xd
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    invoke-static {p1, v7, v8, v6}, Lj5j;->n(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_107  #0xc
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    invoke-static {p1, v7, v8, v6}, Lj5j;->n(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_11c  #0xb
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    invoke-static {p1, v7, v8, v6}, Lj5j;->n(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_131  #0xa
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {v7, v8, v6, p1}, Lj5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_146  #0x9
    move-object v6, p1

    invoke-virtual {p0, v6, v0, p2}, Landroidx/health/platform/client/proto/p;->s(Ljava/lang/Object;ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_14c  #0x8
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {v7, v8, v6, p1}, Lj5j;->o(JLjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_161  #0x7
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->c(JLjava/lang/Object;)Z

    move-result v1

    invoke-virtual {p1, v6, v7, v8, v1}, Le5j;->k(Ljava/lang/Object;JZ)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_176  #0x6
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    invoke-static {p1, v7, v8, v6}, Lj5j;->n(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto/16 :goto_202

    :pswitch_18b  #0x5
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual/range {v5 .. v10}, Le5j;->p(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto :goto_202

    :pswitch_19f  #0x4
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    invoke-static {p1, v7, v8, v6}, Lj5j;->n(IJLjava/lang/Object;)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto :goto_202

    :pswitch_1b3  #0x3
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual/range {v5 .. v10}, Le5j;->p(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto :goto_202

    :pswitch_1c7  #0x2
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual/range {v5 .. v10}, Le5j;->p(Ljava/lang/Object;JJ)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto :goto_202

    :pswitch_1db  #0x1
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v7, v8, p2}, Le5j;->f(JLjava/lang/Object;)F

    move-result v1

    invoke-virtual {p1, v6, v7, v8, v1}, Le5j;->n(Ljava/lang/Object;JF)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    goto :goto_202

    :pswitch_1ef  #0x0
    move-object v6, p1

    invoke-virtual {p0, v0, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_202

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p2}, Le5j;->e(JLjava/lang/Object;)D

    move-result-wide v9

    invoke-virtual/range {v5 .. v10}, Le5j;->m(Ljava/lang/Object;JD)V

    invoke-virtual {p0, v0, v6}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    :cond_202
    :goto_202
    add-int/lit8 v0, v0, 0x3

    move-object p1, v6

    goto/16 :goto_a

    :cond_207
    move-object v6, p1

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    invoke-static {p0, v6, p2}, Landroidx/health/platform/client/proto/y;->j(Landroidx/health/platform/client/proto/a0;Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_20e
    move-object v6, p1

    const-string p0, "Mutating immutable message: "

    invoke-static {p0, v6}, Lb40;->j(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_21a
    .packed-switch 0x0
        :pswitch_1ef  #00000000
        :pswitch_1db  #00000001
        :pswitch_1c7  #00000002
        :pswitch_1b3  #00000003
        :pswitch_19f  #00000004
        :pswitch_18b  #00000005
        :pswitch_176  #00000006
        :pswitch_161  #00000007
        :pswitch_14c  #00000008
        :pswitch_146  #00000009
        :pswitch_131  #0000000a
        :pswitch_11c  #0000000b
        :pswitch_107  #0000000c
        :pswitch_f2  #0000000d
        :pswitch_dd  #0000000e
        :pswitch_c8  #0000000f
        :pswitch_b3  #00000010
        :pswitch_ae  #00000011
        :pswitch_78  #00000012
        :pswitch_78  #00000013
        :pswitch_78  #00000014
        :pswitch_78  #00000015
        :pswitch_78  #00000016
        :pswitch_78  #00000017
        :pswitch_78  #00000018
        :pswitch_78  #00000019
        :pswitch_78  #0000001a
        :pswitch_78  #0000001b
        :pswitch_78  #0000001c
        :pswitch_78  #0000001d
        :pswitch_78  #0000001e
        :pswitch_78  #0000001f
        :pswitch_78  #00000020
        :pswitch_78  #00000021
        :pswitch_78  #00000022
        :pswitch_78  #00000023
        :pswitch_78  #00000024
        :pswitch_78  #00000025
        :pswitch_78  #00000026
        :pswitch_78  #00000027
        :pswitch_78  #00000028
        :pswitch_78  #00000029
        :pswitch_78  #0000002a
        :pswitch_78  #0000002b
        :pswitch_78  #0000002c
        :pswitch_78  #0000002d
        :pswitch_78  #0000002e
        :pswitch_78  #0000002f
        :pswitch_78  #00000030
        :pswitch_78  #00000031
        :pswitch_5f  #00000032
        :pswitch_46  #00000033
        :pswitch_46  #00000034
        :pswitch_46  #00000035
        :pswitch_46  #00000036
        :pswitch_46  #00000037
        :pswitch_46  #00000038
        :pswitch_46  #00000039
        :pswitch_46  #0000003a
        :pswitch_46  #0000003b
        :pswitch_42  #0000003c
        :pswitch_29  #0000003d
        :pswitch_29  #0000003e
        :pswitch_29  #0000003f
        :pswitch_29  #00000040
        :pswitch_29  #00000041
        :pswitch_29  #00000042
        :pswitch_29  #00000043
        :pswitch_23  #00000044
    .end packed-switch
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 11

    invoke-static {p1}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto/16 :goto_a7

    :cond_8
    instance-of v0, p1, Landroidx/health/platform/client/proto/n;

    const/4 v1, 0x0

    if-eqz v0, :cond_1b

    move-object v0, p1

    check-cast v0, Landroidx/health/platform/client/proto/n;

    const v2, 0x7fffffff

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/n;->o(I)V

    iput v1, v0, Landroidx/health/platform/client/proto/a;->memoizedHashCode:I

    invoke-virtual {v0}, Landroidx/health/platform/client/proto/n;->k()V

    :cond_1b
    iget-object v0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    array-length v2, v0

    move v3, v1

    :goto_1f
    if-ge v3, v2, :cond_96

    invoke-virtual {p0, v3}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v4

    const v5, 0xfffff

    and-int/2addr v5, v4

    int-to-long v5, v5

    invoke-static {v4}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v4

    const/16 v7, 0x9

    if-eq v4, v7, :cond_80

    const/16 v7, 0x3c

    if-eq v4, v7, :cond_6a

    const/16 v7, 0x44

    if-eq v4, v7, :cond_6a

    packed-switch v4, :pswitch_data_a8

    goto :goto_93

    :pswitch_3e  #0x32
    sget-object v4, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {v4, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_93

    iget-object v8, p0, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v8, v7

    check-cast v8, Lr5b;

    iput-boolean v1, v8, Lr5b;->E:Z

    invoke-virtual {v4, p1, v5, v6, v7}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_93

    :pswitch_54  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    iget-object v4, p0, Landroidx/health/platform/client/proto/p;->j:Lema;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v5, v6, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ldl9;

    check-cast v4, Lp3;

    iget-boolean v5, v4, Lp3;->E:Z

    if-eqz v5, :cond_93

    iput-boolean v1, v4, Lp3;->E:Z

    goto :goto_93

    :cond_6a
    aget v4, v0, v3

    invoke-virtual {p0, v4, p1, v3}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_93

    invoke-virtual {p0, v3}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v4

    sget-object v7, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v4, v5}, Layf;->b(Ljava/lang/Object;)V

    goto :goto_93

    :cond_80
    :pswitch_80  #0x11
    invoke-virtual {p0, v3, p1}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_93

    invoke-virtual {p0, v3}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v4

    sget-object v7, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v4, v5}, Layf;->b(Ljava/lang/Object;)V

    :cond_93
    :goto_93
    add-int/lit8 v3, v3, 0x3

    goto :goto_1f

    :cond_96
    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    check-cast p0, Ll3j;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/health/platform/client/proto/n;

    iget-object p0, p1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    iget-boolean p1, p0, Landroidx/health/platform/client/proto/b0;->e:Z

    if-eqz p1, :cond_a7

    iput-boolean v1, p0, Landroidx/health/platform/client/proto/b0;->e:Z

    :cond_a7
    :goto_a7
    return-void

    :pswitch_data_a8
    .packed-switch 0x11
        :pswitch_80  #00000011
        :pswitch_54  #00000012
        :pswitch_54  #00000013
        :pswitch_54  #00000014
        :pswitch_54  #00000015
        :pswitch_54  #00000016
        :pswitch_54  #00000017
        :pswitch_54  #00000018
        :pswitch_54  #00000019
        :pswitch_54  #0000001a
        :pswitch_54  #0000001b
        :pswitch_54  #0000001c
        :pswitch_54  #0000001d
        :pswitch_54  #0000001e
        :pswitch_54  #0000001f
        :pswitch_54  #00000020
        :pswitch_54  #00000021
        :pswitch_54  #00000022
        :pswitch_54  #00000023
        :pswitch_54  #00000024
        :pswitch_54  #00000025
        :pswitch_54  #00000026
        :pswitch_54  #00000027
        :pswitch_54  #00000028
        :pswitch_54  #00000029
        :pswitch_54  #0000002a
        :pswitch_54  #0000002b
        :pswitch_54  #0000002c
        :pswitch_54  #0000002d
        :pswitch_54  #0000002e
        :pswitch_54  #0000002f
        :pswitch_54  #00000030
        :pswitch_54  #00000031
        :pswitch_3e  #00000032
    .end packed-switch
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const v6, 0xfffff

    const/4 v7, 0x0

    move v2, v6

    move v3, v7

    move v8, v3

    :goto_b
    iget v4, v0, Landroidx/health/platform/client/proto/p;->g:I

    const/4 v5, 0x1

    if-ge v8, v4, :cond_11e

    iget-object v4, v0, Landroidx/health/platform/client/proto/p;->f:[I

    aget v4, v4, v8

    iget-object v9, v0, Landroidx/health/platform/client/proto/p;->a:[I

    aget v10, v9, v4

    invoke-virtual {v0, v4}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v11

    add-int/lit8 v12, v4, 0x2

    aget v9, v9, v12

    and-int v12, v9, v6

    ushr-int/lit8 v9, v9, 0x14

    shl-int/2addr v5, v9

    if-eq v12, v2, :cond_34

    if-eq v12, v6, :cond_30

    sget-object v2, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    int-to-long v13, v12

    invoke-virtual {v2, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    :cond_30
    move v2, v4

    move v4, v3

    move v3, v12

    goto :goto_38

    :cond_34
    move v15, v3

    move v3, v2

    move v2, v4

    move v4, v15

    :goto_38
    const/high16 v9, 0x10000000

    and-int/2addr v9, v11

    if-eqz v9, :cond_45

    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v9

    if-nez v9, :cond_45

    goto/16 :goto_117

    :cond_45
    invoke-static {v11}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v9

    const/16 v12, 0x9

    if-eq v9, v12, :cond_fe

    const/16 v12, 0x11

    if-eq v9, v12, :cond_fe

    const/16 v5, 0x1b

    if-eq v9, v5, :cond_d3

    const/16 v5, 0x3c

    if-eq v9, v5, :cond_b9

    const/16 v5, 0x44

    if-eq v9, v5, :cond_b9

    const/16 v5, 0x31

    if-eq v9, v5, :cond_d3

    const/16 v5, 0x32

    if-eq v9, v5, :cond_67

    goto/16 :goto_118

    :cond_67
    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v9, v10, v1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    iget-object v9, v0, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, Lr5b;

    invoke-virtual {v5}, Ljava/util/HashMap;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_7f

    goto/16 :goto_118

    :cond_7f
    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->m(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lk5b;

    iget-object v2, v2, Lk5b;->a:Li79;

    iget-object v2, v2, Li79;->G:Ljava/lang/Object;

    check-cast v2, Lu5k;

    iget-object v2, v2, Lu5k;->E:Ly5k;

    sget-object v9, Ly5k;->M:Ly5k;

    if-eq v2, v9, :cond_93

    goto/16 :goto_118

    :cond_93
    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v5, 0x0

    :cond_9c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_118

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    if-nez v5, :cond_b2

    sget-object v5, Lmfe;->c:Lmfe;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v10

    invoke-virtual {v5, v10}, Lmfe;->a(Ljava/lang/Class;)Layf;

    move-result-object v5

    :cond_b2
    invoke-interface {v5, v9}, Layf;->c(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_9c

    goto :goto_117

    :cond_b9
    invoke-virtual {v0, v10, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_118

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v2

    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v9, v10, v1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Layf;->c(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_118

    goto :goto_117

    :cond_d3
    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v9, v10, v1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_e5

    goto :goto_118

    :cond_e5
    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v2

    move v9, v7

    :goto_ea
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-ge v9, v10, :cond_118

    invoke-interface {v5, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-interface {v2, v10}, Layf;->c(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_fb

    goto :goto_117

    :cond_fb
    add-int/lit8 v9, v9, 0x1

    goto :goto_ea

    :cond_fe
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_118

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v2

    and-int v5, v11, v6

    int-to-long v9, v5

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v9, v10, v1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Layf;->c(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_118

    :goto_117
    return v7

    :cond_118
    :goto_118
    add-int/lit8 v8, v8, 0x1

    move v2, v3

    move v3, v4

    goto/16 :goto_b

    :cond_11e
    return v5
.end method

.method public final d()Landroidx/health/platform/client/proto/n;
    .registers 2

    iget-object v0, p0, Landroidx/health/platform/client/proto/p;->i:Lxjc;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->e:Landroidx/health/platform/client/proto/a;

    check-cast p0, Landroidx/health/platform/client/proto/n;

    invoke-virtual {p0}, Landroidx/health/platform/client/proto/n;->l()Landroidx/health/platform/client/proto/n;

    move-result-object p0

    return-object p0
.end method

.method public final e(Landroidx/health/platform/client/proto/n;)I
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    sget-object v6, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    const v8, 0xfffff

    move v3, v8

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v9, 0x0

    :goto_d
    iget-object v5, v0, Landroidx/health/platform/client/proto/p;->a:[I

    array-length v10, v5

    if-ge v2, v10, :cond_6ad

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v10

    invoke-static {v10}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v11

    aget v12, v5, v2

    add-int/lit8 v13, v2, 0x2

    aget v5, v5, v13

    and-int v13, v5, v8

    const/16 v14, 0x11

    const/4 v15, 0x1

    if-gt v11, v14, :cond_39

    if-eq v13, v3, :cond_34

    if-ne v13, v8, :cond_2d

    const/4 v4, 0x0

    goto :goto_33

    :cond_2d
    int-to-long v3, v13

    invoke-virtual {v6, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v3

    move v4, v3

    :goto_33
    move v3, v13

    :cond_34
    ushr-int/lit8 v5, v5, 0x14

    shl-int v5, v15, v5

    goto :goto_3a

    :cond_39
    const/4 v5, 0x0

    :goto_3a
    and-int/2addr v10, v8

    int-to-long v13, v10

    sget-object v10, Lnr7;->F:Lnr7;

    iget v10, v10, Lnr7;->E:I

    if-lt v11, v10, :cond_46

    sget-object v10, Lnr7;->G:Lnr7;

    iget v10, v10, Lnr7;->E:I

    :cond_46
    packed-switch v11, :pswitch_data_6bc

    goto/16 :goto_6a9

    :pswitch_4b  #0x44
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/health/platform/client/proto/a;

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v10

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v11

    mul-int/lit8 v11, v11, 0x2

    invoke-virtual {v5, v10}, Landroidx/health/platform/client/proto/a;->b(Layf;)I

    move-result v5

    add-int/2addr v5, v11

    :goto_66
    add-int/2addr v9, v5

    goto/16 :goto_6a9

    :pswitch_69  #0x43
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v13, v14, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->c(J)I

    move-result v10

    :goto_7b
    add-int/2addr v10, v5

    :goto_7c
    add-int/2addr v9, v10

    goto/16 :goto_6a9

    :pswitch_7f  #0x42
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v13, v14, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->b(I)I

    move-result v5

    :goto_91
    add-int/2addr v5, v10

    goto :goto_66

    :pswitch_93  #0x41
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    :goto_9d
    add-int/lit8 v5, v5, 0x8

    goto :goto_66

    :pswitch_a0  #0x40
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    :goto_aa
    add-int/lit8 v5, v5, 0x4

    goto :goto_66

    :pswitch_ad  #0x3f
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v13, v14, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    int-to-long v11, v5

    invoke-static {v11, v12}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v5

    goto :goto_91

    :pswitch_c1  #0x3e
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v13, v14, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v5

    goto :goto_91

    :pswitch_d4  #0x3d
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lh92;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/b;->a(ILh92;)I

    move-result v5

    goto :goto_66

    :pswitch_e5  #0x3c
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v10

    sget-object v11, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    check-cast v5, Landroidx/health/platform/client/proto/a;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v11

    invoke-virtual {v5, v10}, Landroidx/health/platform/client/proto/a;->b(Layf;)I

    move-result v5

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    add-int/2addr v10, v5

    add-int/2addr v10, v11

    goto/16 :goto_7c

    :pswitch_107  #0x3b
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    instance-of v10, v5, Lh92;

    if-eqz v10, :cond_11f

    check-cast v5, Lh92;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/b;->a(ILh92;)I

    move-result v5

    :goto_11b
    add-int/2addr v5, v9

    move v9, v5

    goto/16 :goto_6a9

    :cond_11f
    check-cast v5, Ljava/lang/String;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->d(Ljava/lang/String;)I

    move-result v5

    add-int/2addr v5, v10

    goto :goto_11b

    :pswitch_12b  #0x3a
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    add-int/2addr v5, v15

    goto/16 :goto_66

    :pswitch_138  #0x39
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    goto/16 :goto_aa

    :pswitch_144  #0x38
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    goto/16 :goto_9d

    :pswitch_150  #0x37
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v13, v14, v1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    int-to-long v11, v5

    invoke-static {v11, v12}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v5

    goto/16 :goto_91

    :pswitch_165  #0x36
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v13, v14, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v10

    goto/16 :goto_7b

    :pswitch_179  #0x35
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v13, v14, v1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v10

    goto/16 :goto_7b

    :pswitch_18d  #0x34
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    goto/16 :goto_aa

    :pswitch_199  #0x33
    invoke-virtual {v0, v12, v1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    goto/16 :goto_9d

    :pswitch_1a5  #0x32
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->m(I)Ljava/lang/Object;

    move-result-object v10

    iget-object v11, v0, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, Lr5b;

    check-cast v10, Lk5b;

    invoke-virtual {v5}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_1be

    :goto_1bc
    const/4 v11, 0x0

    goto :goto_1f0

    :cond_1be
    invoke-virtual {v5}, Lr5b;->entrySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    const/4 v11, 0x0

    :goto_1c7
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_1f0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/util/Map$Entry;

    invoke-interface {v13}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v14

    invoke-interface {v13}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v15

    iget-object v7, v10, Lk5b;->a:Li79;

    invoke-static {v7, v14, v13}, Lk5b;->a(Li79;Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v7

    invoke-static {v7}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v13

    add-int/2addr v13, v7

    add-int/2addr v13, v15

    add-int/2addr v11, v13

    goto :goto_1c7

    :cond_1f0
    :goto_1f0
    add-int/2addr v9, v11

    goto/16 :goto_6a9

    :pswitch_1f3  #0x31
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v7

    sget-object v10, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_207

    const/4 v13, 0x0

    goto :goto_220

    :cond_207
    const/4 v11, 0x0

    const/4 v13, 0x0

    :goto_209
    if-ge v11, v10, :cond_220

    invoke-interface {v5, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/health/platform/client/proto/a;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v15

    mul-int/lit8 v15, v15, 0x2

    invoke-virtual {v14, v7}, Landroidx/health/platform/client/proto/a;->b(Layf;)I

    move-result v14

    add-int/2addr v14, v15

    add-int/2addr v13, v14

    add-int/lit8 v11, v11, 0x1

    goto :goto_209

    :cond_220
    :goto_220
    add-int/2addr v9, v13

    goto/16 :goto_6a9

    :pswitch_223  #0x30
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->g(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    :goto_237
    add-int/2addr v10, v7

    goto/16 :goto_7b

    :pswitch_23a  #0x2f
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->f(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto :goto_237

    :pswitch_24f  #0x2e
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto :goto_237

    :pswitch_268  #0x2d
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto :goto_237

    :pswitch_281  #0x2c
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->a(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto :goto_237

    :pswitch_296  #0x2b
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->h(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto :goto_237

    :pswitch_2ab  #0x2a
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_2c3  #0x29
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_2dd  #0x28
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_2f7  #0x27
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->d(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_30d  #0x26
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->i(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_323  #0x25
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->e(Ljava/util/List;)I

    move-result v5

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_339  #0x24
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x4

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_353  #0x23
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    if-lez v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v10

    goto/16 :goto_237

    :pswitch_36d  #0x22
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_37d

    :goto_37b
    const/4 v10, 0x0

    goto :goto_387

    :cond_37d
    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->g(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    :goto_385
    mul-int/2addr v10, v7

    add-int/2addr v10, v5

    :cond_387
    :goto_387
    add-int/2addr v9, v10

    goto/16 :goto_6a9

    :pswitch_38a  #0x21
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_399

    goto :goto_37b

    :cond_399
    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->f(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    goto :goto_385

    :pswitch_3a2  #0x20
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/y;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_66

    :pswitch_3ae  #0x1f
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/y;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_66

    :pswitch_3ba  #0x1e
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_3c9

    goto :goto_37b

    :cond_3c9
    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->a(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    goto :goto_385

    :pswitch_3d2  #0x1d
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_3e1

    goto :goto_37b

    :cond_3e1
    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->h(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    goto :goto_385

    :pswitch_3ea  #0x1c
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_3f9

    goto :goto_37b

    :cond_3f9
    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    mul-int/2addr v10, v7

    const/4 v7, 0x0

    :goto_3ff
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    if-ge v7, v11, :cond_387

    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lh92;

    invoke-virtual {v11}, Lh92;->size()I

    move-result v11

    invoke-static {v11}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v12

    add-int/2addr v12, v11

    add-int/2addr v10, v12

    add-int/lit8 v7, v7, 0x1

    goto :goto_3ff

    :pswitch_418  #0x1b
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v7

    sget-object v10, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-nez v10, :cond_42c

    goto/16 :goto_1bc

    :cond_42c
    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v11

    mul-int/2addr v11, v10

    const/4 v12, 0x0

    :goto_432
    if-ge v12, v10, :cond_1f0

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroidx/health/platform/client/proto/a;

    invoke-virtual {v13, v7}, Landroidx/health/platform/client/proto/a;->b(Layf;)I

    move-result v13

    invoke-static {v13}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v14

    add-int/2addr v14, v13

    add-int/2addr v11, v14

    add-int/lit8 v12, v12, 0x1

    goto :goto_432

    :pswitch_447  #0x1a
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_457

    goto/16 :goto_37b

    :cond_457
    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    mul-int/2addr v10, v7

    instance-of v11, v5, Llea;

    if-eqz v11, :cond_486

    check-cast v5, Llea;

    const/4 v11, 0x0

    :goto_463
    if-ge v11, v7, :cond_387

    invoke-interface {v5}, Llea;->f()Ljava/lang/Object;

    move-result-object v12

    instance-of v13, v12, Lh92;

    if-eqz v13, :cond_47b

    check-cast v12, Lh92;

    invoke-virtual {v12}, Lh92;->size()I

    move-result v12

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v13

    add-int/2addr v13, v12

    add-int/2addr v13, v10

    move v10, v13

    goto :goto_483

    :cond_47b
    check-cast v12, Ljava/lang/String;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->d(Ljava/lang/String;)I

    move-result v12

    add-int/2addr v12, v10

    move v10, v12

    :goto_483
    add-int/lit8 v11, v11, 0x1

    goto :goto_463

    :cond_486
    const/4 v11, 0x0

    :goto_487
    if-ge v11, v7, :cond_387

    invoke-interface {v5, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    instance-of v13, v12, Lh92;

    if-eqz v13, :cond_49f

    check-cast v12, Lh92;

    invoke-virtual {v12}, Lh92;->size()I

    move-result v12

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v13

    add-int/2addr v13, v12

    add-int/2addr v13, v10

    move v10, v13

    goto :goto_4a7

    :cond_49f
    check-cast v12, Ljava/lang/String;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->d(Ljava/lang/String;)I

    move-result v12

    add-int/2addr v12, v10

    move v10, v12

    :goto_4a7
    add-int/lit8 v11, v11, 0x1

    goto :goto_487

    :pswitch_4aa  #0x19
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-nez v5, :cond_4ba

    const/4 v7, 0x0

    goto :goto_4c0

    :cond_4ba
    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v7

    add-int/2addr v7, v15

    mul-int/2addr v7, v5

    :goto_4c0
    add-int/2addr v9, v7

    goto/16 :goto_6a9

    :pswitch_4c3  #0x18
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/y;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_66

    :pswitch_4cf  #0x17
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/y;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_66

    :pswitch_4db  #0x16
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_4eb

    goto/16 :goto_37b

    :cond_4eb
    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->d(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    goto/16 :goto_385

    :pswitch_4f5  #0x15
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_505

    goto/16 :goto_37b

    :cond_505
    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->i(Ljava/util/List;)I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    goto/16 :goto_385

    :pswitch_50f  #0x14
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    sget-object v7, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_51f

    goto/16 :goto_37b

    :cond_51f
    invoke-static {v5}, Landroidx/health/platform/client/proto/y;->e(Ljava/util/List;)I

    move-result v7

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    mul-int/2addr v10, v5

    add-int/2addr v10, v7

    goto/16 :goto_387

    :pswitch_52f  #0x13
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/y;->b(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_66

    :pswitch_53b  #0x12
    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v12, v5}, Landroidx/health/platform/client/proto/y;->c(ILjava/util/List;)I

    move-result v5

    goto/16 :goto_66

    :pswitch_547  #0x11
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/health/platform/client/proto/a;

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v7

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    mul-int/lit8 v10, v10, 0x2

    invoke-virtual {v5, v7}, Landroidx/health/platform/client/proto/a;->b(Layf;)I

    move-result v5

    goto/16 :goto_91

    :pswitch_563  #0x10
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->c(J)I

    move-result v5

    :goto_575
    add-int/2addr v5, v0

    add-int/2addr v9, v5

    :cond_577
    :goto_577
    move-object/from16 v0, p0

    goto/16 :goto_6a9

    :pswitch_57b  #0xf
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    invoke-static {v0}, Landroidx/health/platform/client/proto/b;->b(I)I

    move-result v0

    :goto_58d
    add-int/2addr v0, v5

    :goto_58e
    add-int/2addr v9, v0

    goto :goto_577

    :pswitch_590  #0xe
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_59d

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    :goto_59a
    add-int/lit8 v0, v0, 0x8

    :goto_59c
    add-int/2addr v9, v0

    :cond_59d
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    goto/16 :goto_6a9

    :pswitch_5a3  #0xd
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_59d

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    :goto_5ad
    add-int/lit8 v0, v0, 0x4

    goto :goto_59c

    :pswitch_5b0  #0xc
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    int-to-long v10, v0

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    goto :goto_58d

    :pswitch_5c4  #0xb
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    invoke-static {v0}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v0

    goto :goto_58d

    :pswitch_5d7  #0xa
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lh92;

    invoke-static {v12, v0}, Landroidx/health/platform/client/proto/b;->a(ILh92;)I

    move-result v0

    goto :goto_58e

    :pswitch_5e8  #0x9
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v7

    sget-object v10, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    check-cast v5, Landroidx/health/platform/client/proto/a;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v10

    invoke-virtual {v5, v7}, Landroidx/health/platform/client/proto/a;->b(Layf;)I

    move-result v5

    invoke-static {v5}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v7

    add-int/2addr v7, v5

    add-int/2addr v7, v10

    add-int/2addr v9, v7

    goto/16 :goto_6a9

    :pswitch_60b  #0x8
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    instance-of v5, v0, Lh92;

    if-eqz v5, :cond_623

    check-cast v0, Lh92;

    invoke-static {v12, v0}, Landroidx/health/platform/client/proto/b;->a(ILh92;)I

    move-result v0

    :goto_61f
    add-int/2addr v0, v9

    move v9, v0

    goto/16 :goto_577

    :cond_623
    check-cast v0, Ljava/lang/String;

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    invoke-static {v0}, Landroidx/health/platform/client/proto/b;->d(Ljava/lang/String;)I

    move-result v0

    add-int/2addr v0, v5

    goto :goto_61f

    :pswitch_62f  #0x7
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_59d

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    add-int/2addr v0, v15

    goto/16 :goto_59c

    :pswitch_63c  #0x6
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_59d

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    goto/16 :goto_5ad

    :pswitch_648  #0x5
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_59d

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    goto/16 :goto_59a

    :pswitch_654  #0x4
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    move-result v0

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    int-to-long v10, v0

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    goto/16 :goto_58d

    :pswitch_669  #0x3
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v5

    goto/16 :goto_575

    :pswitch_67d  #0x2
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_577

    invoke-virtual {v6, v1, v13, v14}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v10

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    invoke-static {v10, v11}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v5

    goto/16 :goto_575

    :pswitch_691  #0x1
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_59d

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v0

    goto/16 :goto_5ad

    :pswitch_69d  #0x0
    invoke-virtual/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->p(Ljava/lang/Object;IIII)Z

    move-result v5

    if-eqz v5, :cond_6a9

    invoke-static {v12}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v5

    goto/16 :goto_9d

    :cond_6a9
    :goto_6a9
    add-int/lit8 v2, v2, 0x3

    goto/16 :goto_d

    :cond_6ad
    iget-object v0, v0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    check-cast v0, Ll3j;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    invoke-virtual {v0}, Landroidx/health/platform/client/proto/b0;->b()I

    move-result v0

    add-int/2addr v0, v9

    return v0

    :pswitch_data_6bc
    .packed-switch 0x0
        :pswitch_69d  #00000000
        :pswitch_691  #00000001
        :pswitch_67d  #00000002
        :pswitch_669  #00000003
        :pswitch_654  #00000004
        :pswitch_648  #00000005
        :pswitch_63c  #00000006
        :pswitch_62f  #00000007
        :pswitch_60b  #00000008
        :pswitch_5e8  #00000009
        :pswitch_5d7  #0000000a
        :pswitch_5c4  #0000000b
        :pswitch_5b0  #0000000c
        :pswitch_5a3  #0000000d
        :pswitch_590  #0000000e
        :pswitch_57b  #0000000f
        :pswitch_563  #00000010
        :pswitch_547  #00000011
        :pswitch_53b  #00000012
        :pswitch_52f  #00000013
        :pswitch_50f  #00000014
        :pswitch_4f5  #00000015
        :pswitch_4db  #00000016
        :pswitch_4cf  #00000017
        :pswitch_4c3  #00000018
        :pswitch_4aa  #00000019
        :pswitch_447  #0000001a
        :pswitch_418  #0000001b
        :pswitch_3ea  #0000001c
        :pswitch_3d2  #0000001d
        :pswitch_3ba  #0000001e
        :pswitch_3ae  #0000001f
        :pswitch_3a2  #00000020
        :pswitch_38a  #00000021
        :pswitch_36d  #00000022
        :pswitch_353  #00000023
        :pswitch_339  #00000024
        :pswitch_323  #00000025
        :pswitch_30d  #00000026
        :pswitch_2f7  #00000027
        :pswitch_2dd  #00000028
        :pswitch_2c3  #00000029
        :pswitch_2ab  #0000002a
        :pswitch_296  #0000002b
        :pswitch_281  #0000002c
        :pswitch_268  #0000002d
        :pswitch_24f  #0000002e
        :pswitch_23a  #0000002f
        :pswitch_223  #00000030
        :pswitch_1f3  #00000031
        :pswitch_1a5  #00000032
        :pswitch_199  #00000033
        :pswitch_18d  #00000034
        :pswitch_179  #00000035
        :pswitch_165  #00000036
        :pswitch_150  #00000037
        :pswitch_144  #00000038
        :pswitch_138  #00000039
        :pswitch_12b  #0000003a
        :pswitch_107  #0000003b
        :pswitch_e5  #0000003c
        :pswitch_d4  #0000003d
        :pswitch_c1  #0000003e
        :pswitch_ad  #0000003f
        :pswitch_a0  #00000040
        :pswitch_93  #00000041
        :pswitch_7f  #00000042
        :pswitch_69  #00000043
        :pswitch_4b  #00000044
    .end packed-switch
.end method

.method public final f(Landroidx/health/platform/client/proto/n;)I
    .registers 13

    iget-object v0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_5
    if-ge v2, v1, :cond_27c

    invoke-virtual {p0, v2}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v4

    aget v5, v0, v2

    const v6, 0xfffff

    and-int/2addr v6, v4

    int-to-long v6, v6

    invoke-static {v4}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v4

    const/16 v8, 0x4d5

    const/16 v9, 0x4cf

    const/16 v10, 0x25

    packed-switch v4, :pswitch_data_28e

    goto/16 :goto_278

    :pswitch_21  #0x44
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    mul-int/lit8 v3, v3, 0x35

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    :goto_33
    add-int/2addr v4, v3

    move v3, v4

    goto/16 :goto_278

    :pswitch_37  #0x43
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto :goto_33

    :pswitch_48  #0x42
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_55  #0x41
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto :goto_33

    :pswitch_66  #0x40
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_73  #0x3f
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_80  #0x3e
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v4

    goto :goto_33

    :pswitch_8d  #0x3d
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto :goto_33

    :pswitch_a0  #0x3c
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    mul-int/lit8 v3, v3, 0x35

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto :goto_33

    :pswitch_b3  #0x3b
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_c9  #0x3a
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    sget-object v5, Lhl9;->a:Ljava/nio/charset/Charset;

    if-eqz v4, :cond_e2

    :goto_e1
    move v8, v9

    :cond_e2
    add-int/2addr v8, v3

    move v3, v8

    goto/16 :goto_278

    :pswitch_e6  #0x39
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_f4  #0x38
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_106  #0x37
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->x(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_114  #0x36
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_126  #0x35
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    invoke-static {v6, v7, p1}, Landroidx/health/platform/client/proto/p;->y(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_138  #0x34
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Float;

    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v4

    goto/16 :goto_33

    :pswitch_152  #0x33
    invoke-virtual {p0, v5, p1, v2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v4

    if-eqz v4, :cond_278

    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Double;

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_170  #0x32
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_17e  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_18c  #0x11
    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_198

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v10

    :cond_198
    :goto_198
    mul-int/lit8 v3, v3, 0x35

    add-int/2addr v3, v10

    goto/16 :goto_278

    :pswitch_19d  #0x10
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1ab  #0xf
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1b5  #0xe
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1c3  #0xd
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1cd  #0xc
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1d7  #0xb
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_1e1  #0xa
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_1ef  #0x9
    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_198

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v10

    goto :goto_198

    :pswitch_1fc  #0x8
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v4

    goto/16 :goto_33

    :pswitch_20c  #0x7
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->c(JLjava/lang/Object;)Z

    move-result v4

    sget-object v5, Lhl9;->a:Ljava/nio/charset/Charset;

    if-eqz v4, :cond_e2

    goto/16 :goto_e1

    :pswitch_21a  #0x6
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_224  #0x5
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_232  #0x4
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v4

    goto/16 :goto_33

    :pswitch_23c  #0x3
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_24a  #0x2
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :pswitch_258  #0x1
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->f(JLjava/lang/Object;)F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v4

    goto/16 :goto_33

    :pswitch_266  #0x0
    mul-int/lit8 v3, v3, 0x35

    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v6, v7, p1}, Le5j;->e(JLjava/lang/Object;)D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    invoke-static {v4, v5}, Lhl9;->a(J)I

    move-result v4

    goto/16 :goto_33

    :cond_278
    :goto_278
    add-int/lit8 v2, v2, 0x3

    goto/16 :goto_5

    :cond_27c
    mul-int/lit8 v3, v3, 0x35

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    check-cast p0, Ll3j;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    invoke-virtual {p0}, Landroidx/health/platform/client/proto/b0;->hashCode()I

    move-result p0

    add-int/2addr p0, v3

    return p0

    nop

    :pswitch_data_28e
    .packed-switch 0x0
        :pswitch_266  #00000000
        :pswitch_258  #00000001
        :pswitch_24a  #00000002
        :pswitch_23c  #00000003
        :pswitch_232  #00000004
        :pswitch_224  #00000005
        :pswitch_21a  #00000006
        :pswitch_20c  #00000007
        :pswitch_1fc  #00000008
        :pswitch_1ef  #00000009
        :pswitch_1e1  #0000000a
        :pswitch_1d7  #0000000b
        :pswitch_1cd  #0000000c
        :pswitch_1c3  #0000000d
        :pswitch_1b5  #0000000e
        :pswitch_1ab  #0000000f
        :pswitch_19d  #00000010
        :pswitch_18c  #00000011
        :pswitch_17e  #00000012
        :pswitch_17e  #00000013
        :pswitch_17e  #00000014
        :pswitch_17e  #00000015
        :pswitch_17e  #00000016
        :pswitch_17e  #00000017
        :pswitch_17e  #00000018
        :pswitch_17e  #00000019
        :pswitch_17e  #0000001a
        :pswitch_17e  #0000001b
        :pswitch_17e  #0000001c
        :pswitch_17e  #0000001d
        :pswitch_17e  #0000001e
        :pswitch_17e  #0000001f
        :pswitch_17e  #00000020
        :pswitch_17e  #00000021
        :pswitch_17e  #00000022
        :pswitch_17e  #00000023
        :pswitch_17e  #00000024
        :pswitch_17e  #00000025
        :pswitch_17e  #00000026
        :pswitch_17e  #00000027
        :pswitch_17e  #00000028
        :pswitch_17e  #00000029
        :pswitch_17e  #0000002a
        :pswitch_17e  #0000002b
        :pswitch_17e  #0000002c
        :pswitch_17e  #0000002d
        :pswitch_17e  #0000002e
        :pswitch_17e  #0000002f
        :pswitch_17e  #00000030
        :pswitch_17e  #00000031
        :pswitch_170  #00000032
        :pswitch_152  #00000033
        :pswitch_138  #00000034
        :pswitch_126  #00000035
        :pswitch_114  #00000036
        :pswitch_106  #00000037
        :pswitch_f4  #00000038
        :pswitch_e6  #00000039
        :pswitch_c9  #0000003a
        :pswitch_b3  #0000003b
        :pswitch_a0  #0000003c
        :pswitch_8d  #0000003d
        :pswitch_80  #0000003e
        :pswitch_73  #0000003f
        :pswitch_66  #00000040
        :pswitch_55  #00000041
        :pswitch_48  #00000042
        :pswitch_37  #00000043
        :pswitch_21  #00000044
    .end packed-switch
.end method

.method public final g(Ljava/lang/Object;Lgkf;)V
    .registers 3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1, p2}, Landroidx/health/platform/client/proto/p;->K(Ljava/lang/Object;Lgkf;)V

    return-void
.end method

.method public final h(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;)Z
    .registers 14

    iget-object v0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_5
    const/4 v4, 0x1

    if-ge v3, v1, :cond_1f5

    invoke-virtual {p0, v3}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v5

    const v6, 0xfffff

    and-int v7, v5, v6

    int-to-long v7, v7

    invoke-static {v5}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result v5

    packed-switch v5, :pswitch_data_20c

    goto/16 :goto_1ee

    :pswitch_1b  #0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43, 0x44
    add-int/lit8 v5, v3, 0x2

    aget v5, v0, v5

    and-int/2addr v5, v6

    int-to-long v5, v5

    sget-object v9, Lj5j;->c:Le5j;

    invoke-virtual {v9, v5, v6, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v10

    invoke-virtual {v9, v5, v6, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result v5

    if-ne v10, v5, :cond_3d

    invoke-virtual {v9, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v9, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5, v6}, Landroidx/health/platform/client/proto/y;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :cond_3d
    move v4, v2

    goto/16 :goto_1ee

    :pswitch_40  #0x32
    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v5, v4}, Landroidx/health/platform/client/proto/y;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_1ee

    :pswitch_50  #0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31
    sget-object v4, Lj5j;->c:Le5j;

    invoke-virtual {v4, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v5, v4}, Landroidx/health/platform/client/proto/y;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    goto/16 :goto_1ee

    :pswitch_60  #0x11
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/health/platform/client/proto/y;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_78  #0x10
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_8e  #0xf
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_a2  #0xe
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_b8  #0xd
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_cc  #0xc
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_e0  #0xb
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_f4  #0xa
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/health/platform/client/proto/y;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_10c  #0x9
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/health/platform/client/proto/y;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_124  #0x8
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6, v5}, Landroidx/health/platform/client/proto/y;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_13c  #0x7
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->c(JLjava/lang/Object;)Z

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->c(JLjava/lang/Object;)Z

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_150  #0x6
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_164  #0x5
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto/16 :goto_1ee

    :pswitch_17a  #0x4
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->g(JLjava/lang/Object;)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto :goto_1ee

    :pswitch_18d  #0x3
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto :goto_1ee

    :pswitch_1a2  #0x2
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    goto :goto_1ee

    :pswitch_1b7  #0x1
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->f(JLjava/lang/Object;)F

    move-result v6

    invoke-static {v6}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v6

    invoke-virtual {v5, v7, v8, p2}, Le5j;->f(JLjava/lang/Object;)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v5

    if-ne v6, v5, :cond_3d

    goto :goto_1ee

    :pswitch_1d2  #0x0
    invoke-virtual {p0, p1, p2, v3}, Landroidx/health/platform/client/proto/p;->j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z

    move-result v5

    if-eqz v5, :cond_3d

    sget-object v5, Lj5j;->c:Le5j;

    invoke-virtual {v5, v7, v8, p1}, Le5j;->e(JLjava/lang/Object;)D

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v9

    invoke-virtual {v5, v7, v8, p2}, Le5j;->e(JLjava/lang/Object;)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v5

    cmp-long v5, v9, v5

    if-nez v5, :cond_3d

    :goto_1ee
    if-nez v4, :cond_1f1

    goto :goto_209

    :cond_1f1
    add-int/lit8 v3, v3, 0x3

    goto/16 :goto_5

    :cond_1f5
    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->k:Landroidx/health/platform/client/proto/a0;

    check-cast p0, Ll3j;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p2, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    invoke-virtual {p1, p0}, Landroidx/health/platform/client/proto/b0;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_20a

    :goto_209
    return v2

    :cond_20a
    return v4

    nop

    :pswitch_data_20c
    .packed-switch 0x0
        :pswitch_1d2  #00000000
        :pswitch_1b7  #00000001
        :pswitch_1a2  #00000002
        :pswitch_18d  #00000003
        :pswitch_17a  #00000004
        :pswitch_164  #00000005
        :pswitch_150  #00000006
        :pswitch_13c  #00000007
        :pswitch_124  #00000008
        :pswitch_10c  #00000009
        :pswitch_f4  #0000000a
        :pswitch_e0  #0000000b
        :pswitch_cc  #0000000c
        :pswitch_b8  #0000000d
        :pswitch_a2  #0000000e
        :pswitch_8e  #0000000f
        :pswitch_78  #00000010
        :pswitch_60  #00000011
        :pswitch_50  #00000012
        :pswitch_50  #00000013
        :pswitch_50  #00000014
        :pswitch_50  #00000015
        :pswitch_50  #00000016
        :pswitch_50  #00000017
        :pswitch_50  #00000018
        :pswitch_50  #00000019
        :pswitch_50  #0000001a
        :pswitch_50  #0000001b
        :pswitch_50  #0000001c
        :pswitch_50  #0000001d
        :pswitch_50  #0000001e
        :pswitch_50  #0000001f
        :pswitch_50  #00000020
        :pswitch_50  #00000021
        :pswitch_50  #00000022
        :pswitch_50  #00000023
        :pswitch_50  #00000024
        :pswitch_50  #00000025
        :pswitch_50  #00000026
        :pswitch_50  #00000027
        :pswitch_50  #00000028
        :pswitch_50  #00000029
        :pswitch_50  #0000002a
        :pswitch_50  #0000002b
        :pswitch_50  #0000002c
        :pswitch_50  #0000002d
        :pswitch_50  #0000002e
        :pswitch_50  #0000002f
        :pswitch_50  #00000030
        :pswitch_50  #00000031
        :pswitch_40  #00000032
        :pswitch_1b  #00000033
        :pswitch_1b  #00000034
        :pswitch_1b  #00000035
        :pswitch_1b  #00000036
        :pswitch_1b  #00000037
        :pswitch_1b  #00000038
        :pswitch_1b  #00000039
        :pswitch_1b  #0000003a
        :pswitch_1b  #0000003b
        :pswitch_1b  #0000003c
        :pswitch_1b  #0000003d
        :pswitch_1b  #0000003e
        :pswitch_1b  #0000003f
        :pswitch_1b  #00000040
        :pswitch_1b  #00000041
        :pswitch_1b  #00000042
        :pswitch_1b  #00000043
        :pswitch_1b  #00000044
    .end packed-switch
.end method

.method public final i(Ljava/lang/Object;[BIILpq0;)V
    .registers 13

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move-object v6, p5

    invoke-virtual/range {v0 .. v6}, Landroidx/health/platform/client/proto/p;->A(Ljava/lang/Object;[BIIILpq0;)I

    return-void
.end method

.method public final j(Landroidx/health/platform/client/proto/n;Landroidx/health/platform/client/proto/n;I)Z
    .registers 4

    invoke-virtual {p0, p3, p1}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p1

    invoke-virtual {p0, p3, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p0

    if-ne p1, p0, :cond_c

    const/4 p0, 0x1

    return p0

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method public final l(I)Ltgd;
    .registers 5

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1, v2, v0, v1}, Lti6;->e(IIII)I

    move-result p1

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->b:[Ljava/lang/Object;

    aget-object p0, p0, p1

    check-cast p0, Ltgd;

    return-object p0
.end method

.method public final m(I)Ljava/lang/Object;
    .registers 2

    div-int/lit8 p1, p1, 0x3

    mul-int/lit8 p1, p1, 0x2

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->b:[Ljava/lang/Object;

    aget-object p0, p0, p1

    return-object p0
.end method

.method public final n(I)Layf;
    .registers 4

    div-int/lit8 p1, p1, 0x3

    mul-int/lit8 p1, p1, 0x2

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->b:[Ljava/lang/Object;

    aget-object v0, p0, p1

    check-cast v0, Layf;

    if-eqz v0, :cond_d

    return-object v0

    :cond_d
    sget-object v0, Lmfe;->c:Lmfe;

    add-int/lit8 v1, p1, 0x1

    aget-object v1, p0, v1

    check-cast v1, Ljava/lang/Class;

    invoke-virtual {v0, v1}, Lmfe;->a(Ljava/lang/Class;)Layf;

    move-result-object v0

    aput-object v0, p0, p1

    return-object v0
.end method

.method public final o(ILjava/lang/Object;)Z
    .registers 10

    add-int/lit8 v0, p1, 0x2

    iget-object v1, p0, Landroidx/health/platform/client/proto/p;->a:[I

    aget v0, v1, v0

    const v1, 0xfffff

    and-int v2, v0, v1

    int-to-long v2, v2

    const-wide/32 v4, 0xfffff

    cmp-long v4, v2, v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v4, :cond_103

    invoke-virtual {p0, p1}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result p0

    and-int p1, p0, v1

    int-to-long v0, p1

    invoke-static {p0}, Landroidx/health/platform/client/proto/p;->I(I)I

    move-result p0

    const-wide/16 v2, 0x0

    packed-switch p0, :pswitch_data_112

    invoke-static {}, Lty9;->y()V

    return v5

    :pswitch_29  #0x11
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_33  #0x10
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_3f  #0xf
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_49  #0xe
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_55  #0xd
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_5f  #0xc
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_69  #0xb
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_73  #0xa
    sget-object p0, Lh92;->G:Lh92;

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v0, v1, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p0, p1}, Lh92;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :pswitch_81  #0x9
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_111

    goto/16 :goto_110

    :pswitch_8b  #0x8
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_9d

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :cond_9d
    instance-of p1, p0, Lh92;

    if-eqz p1, :cond_a9

    sget-object p1, Lh92;->G:Lh92;

    invoke-virtual {p1, p0}, Lh92;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/2addr p0, v6

    return p0

    :cond_a9
    invoke-static {}, Lty9;->y()V

    return v5

    :pswitch_ad  #0x7
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->c(JLjava/lang/Object;)Z

    move-result p0

    return p0

    :pswitch_b4  #0x6
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_bd  #0x5
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_c8  #0x4
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_d1  #0x3
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_dc  #0x2
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->h(JLjava/lang/Object;)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_e7  #0x1
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->f(JLjava/lang/Object;)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    if-eqz p0, :cond_111

    goto :goto_110

    :pswitch_f4  #0x0
    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->e(JLjava/lang/Object;)D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide p0

    cmp-long p0, p0, v2

    if-eqz p0, :cond_111

    goto :goto_110

    :cond_103
    ushr-int/lit8 p0, v0, 0x14

    shl-int p0, v6, p0

    sget-object p1, Lj5j;->c:Le5j;

    invoke-virtual {p1, v2, v3, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p1

    and-int/2addr p0, p1

    if-eqz p0, :cond_111

    :goto_110
    return v6

    :cond_111
    return v5

    :pswitch_data_112
    .packed-switch 0x0
        :pswitch_f4  #00000000
        :pswitch_e7  #00000001
        :pswitch_dc  #00000002
        :pswitch_d1  #00000003
        :pswitch_c8  #00000004
        :pswitch_bd  #00000005
        :pswitch_b4  #00000006
        :pswitch_ad  #00000007
        :pswitch_8b  #00000008
        :pswitch_81  #00000009
        :pswitch_73  #0000000a
        :pswitch_69  #0000000b
        :pswitch_5f  #0000000c
        :pswitch_55  #0000000d
        :pswitch_49  #0000000e
        :pswitch_3f  #0000000f
        :pswitch_33  #00000010
        :pswitch_29  #00000011
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;IIII)Z
    .registers 7

    const v0, 0xfffff

    if-ne p3, v0, :cond_a

    invoke-virtual {p0, p2, p1}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p0

    return p0

    :cond_a
    and-int p0, p4, p5

    if-eqz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method public final r(ILjava/lang/Object;I)Z
    .registers 6

    add-int/lit8 p3, p3, 0x2

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    aget p0, p0, p3

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v0, p0

    sget-object p0, Lj5j;->c:Le5j;

    invoke-virtual {p0, v0, v1, p2}, Le5j;->g(JLjava/lang/Object;)I

    move-result p0

    if-ne p0, p1, :cond_15

    const/4 p0, 0x1

    return p0

    :cond_15
    const/4 p0, 0x0

    return p0
.end method

.method public final s(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 9

    invoke-virtual {p0, p2, p3}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    invoke-virtual {p0, p2}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v0

    const v1, 0xfffff

    and-int/2addr v0, v1

    int-to-long v0, v0

    sget-object v2, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {v2, p3, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_53

    invoke-virtual {p0, p2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object p3

    invoke-virtual {p0, p2, p1}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3a

    invoke-static {v3}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2c

    invoke-virtual {v2, p1, v0, v1, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_36

    :cond_2c
    invoke-interface {p3}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object v4

    invoke-interface {p3, v4, v3}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v0, v1, v4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :goto_36
    invoke-virtual {p0, p2, p1}, Landroidx/health/platform/client/proto/p;->E(ILjava/lang/Object;)V

    return-void

    :cond_3a
    invoke-virtual {v2, p1, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_4f

    invoke-interface {p3}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object p2

    invoke-interface {p3, p2, p0}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v0, v1, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    move-object p0, p2

    :cond_4f
    invoke-interface {p3, p0, v3}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_53
    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    aget p0, p0, p2

    const-string p1, " is present but null: "

    const-string p2, "Source subfield "

    invoke-static {p0, p1, p3, p2}, Lm1f;->i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final t(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 11

    iget-object v0, p0, Landroidx/health/platform/client/proto/p;->a:[I

    aget v1, v0, p2

    invoke-virtual {p0, v1, p3, p2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result v2

    if-nez v2, :cond_b

    return-void

    :cond_b
    invoke-virtual {p0, p2}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v2

    const v3, 0xfffff

    and-int/2addr v2, v3

    int-to-long v4, v2

    sget-object v2, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {v2, p3, v4, v5}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_5d

    invoke-virtual {p0, p2}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object p3

    invoke-virtual {p0, v1, p1, p2}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result p0

    if-nez p0, :cond_44

    invoke-static {v6}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_30

    invoke-virtual {v2, p1, v4, v5, v6}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_3a

    :cond_30
    invoke-interface {p3}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object p0

    invoke-interface {p3, p0, v6}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v4, v5, p0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :goto_3a
    add-int/lit8 p2, p2, 0x2

    aget p0, v0, p2

    and-int/2addr p0, v3

    int-to-long p2, p0

    invoke-static {v1, p2, p3, p1}, Lj5j;->n(IJLjava/lang/Object;)V

    return-void

    :cond_44
    invoke-virtual {v2, p1, v4, v5}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_59

    invoke-interface {p3}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object p2

    invoke-interface {p3, p2, p0}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, p1, v4, v5, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    move-object p0, p2

    :cond_59
    invoke-interface {p3, p0, v6}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_5d
    aget p0, v0, p2

    const-string p1, " is present but null: "

    const-string p2, "Source subfield "

    invoke-static {p0, p1, p3, p2}, Lm1f;->i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final u(ILjava/lang/Object;)Ljava/lang/Object;
    .registers 6

    invoke-virtual {p0, p1}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v0

    invoke-virtual {p0, p1}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result v1

    const v2, 0xfffff

    and-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {p0, p1, p2}, Landroidx/health/platform/client/proto/p;->o(ILjava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_18

    invoke-interface {v0}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object p0

    return-object p0

    :cond_18
    sget-object p0, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {p0, p2, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_25

    return-object p0

    :cond_25
    invoke-interface {v0}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object p1

    if-eqz p0, :cond_2e

    invoke-interface {v0, p1, p0}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2e
    return-object p1
.end method

.method public final v(ILjava/lang/Object;I)Ljava/lang/Object;
    .registers 7

    invoke-virtual {p0, p3}, Landroidx/health/platform/client/proto/p;->n(I)Layf;

    move-result-object v0

    invoke-virtual {p0, p1, p2, p3}, Landroidx/health/platform/client/proto/p;->r(ILjava/lang/Object;I)Z

    move-result p1

    if-nez p1, :cond_f

    invoke-interface {v0}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object p0

    return-object p0

    :cond_f
    sget-object p1, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    invoke-virtual {p0, p3}, Landroidx/health/platform/client/proto/p;->J(I)I

    move-result p0

    const p3, 0xfffff

    and-int/2addr p0, p3

    int-to-long v1, p0

    invoke-virtual {p1, p2, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroidx/health/platform/client/proto/p;->q(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_25

    return-object p0

    :cond_25
    invoke-interface {v0}, Layf;->d()Landroidx/health/platform/client/proto/n;

    move-result-object p1

    if-eqz p0, :cond_2e

    invoke-interface {v0, p1, p0}, Layf;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2e
    return-object p1
.end method

.method public final z(Ljava/lang/Object;[BIIIJLpq0;)I
    .registers 21

    move-wide/from16 v1, p6

    move-object/from16 v5, p8

    sget-object v3, Landroidx/health/platform/client/proto/p;->n:Lsun/misc/Unsafe;

    move/from16 v4, p5

    invoke-virtual {p0, v4}, Landroidx/health/platform/client/proto/p;->m(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, p1, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v6

    iget-object p0, p0, Landroidx/health/platform/client/proto/p;->l:Lw5b;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object p0, v6

    check-cast p0, Lr5b;

    iget-boolean p0, p0, Lr5b;->E:Z

    const/4 v7, 0x1

    if-nez p0, :cond_3a

    sget-object p0, Lr5b;->F:Lr5b;

    invoke-virtual {p0}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_2b

    new-instance p0, Lr5b;

    invoke-direct {p0}, Lr5b;-><init>()V

    goto :goto_33

    :cond_2b
    new-instance v8, Lr5b;

    invoke-direct {v8, p0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    iput-boolean v7, v8, Lr5b;->E:Z

    move-object p0, v8

    :goto_33
    invoke-static {p0, v6}, Lw5b;->a(Ljava/lang/Object;Ljava/lang/Object;)Lr5b;

    invoke-virtual {v3, p1, v1, v2, p0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    move-object v6, p0

    :cond_3a
    check-cast v4, Lk5b;

    iget-object p0, v4, Lk5b;->a:Li79;

    check-cast v6, Lr5b;

    invoke-static {p2, p3, v5}, Lckl;->n([BILpq0;)I

    move-result p1

    iget v1, v5, Lpq0;->a:I

    if-ltz v1, :cond_a9

    sub-int v2, p4, p1

    if-gt v1, v2, :cond_a9

    add-int v8, p1, v1

    iget-object v9, p0, Li79;->H:Ljava/lang/Object;

    const-string v1, ""

    move-object v10, v1

    move-object v11, v9

    :goto_54
    if-ge p1, v8, :cond_9e

    add-int/lit8 v1, p1, 0x1

    aget-byte p1, p2, p1

    if-gez p1, :cond_62

    invoke-static {p1, p2, v1, v5}, Lckl;->m(I[BILpq0;)I

    move-result v1

    iget p1, v5, Lpq0;->a:I

    :cond_62
    ushr-int/lit8 v2, p1, 0x3

    and-int/lit8 v3, p1, 0x7

    if-eq v2, v7, :cond_85

    const/4 v4, 0x2

    if-eq v2, v4, :cond_6e

    :cond_6b
    move/from16 v2, p4

    goto :goto_99

    :cond_6e
    iget-object v2, p0, Li79;->G:Ljava/lang/Object;

    check-cast v2, Lu5k;

    iget v4, v2, Lu5k;->F:I

    if-ne v3, v4, :cond_6b

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    move-object v0, p2

    move-object v3, v2

    move/from16 v2, p4

    invoke-static/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->k([BIILu5k;Ljava/lang/Class;Lpq0;)I

    move-result p1

    iget-object v11, v5, Lpq0;->c:Ljava/lang/Object;

    goto :goto_54

    :cond_85
    iget-object v0, p0, Li79;->F:Ljava/lang/Object;

    check-cast v0, Lu5k;

    iget v2, v0, Lu5k;->F:I

    if-ne v3, v2, :cond_6b

    const/4 v4, 0x0

    move/from16 v2, p4

    move-object v3, v0

    move-object v0, p2

    invoke-static/range {v0 .. v5}, Landroidx/health/platform/client/proto/p;->k([BIILu5k;Ljava/lang/Class;Lpq0;)I

    move-result p1

    iget-object v10, v5, Lpq0;->c:Ljava/lang/Object;

    goto :goto_54

    :goto_99
    invoke-static {p1, p2, v1, v2, v5}, Lckl;->v(I[BIILpq0;)I

    move-result p1

    goto :goto_54

    :cond_9e
    if-ne p1, v8, :cond_a4

    invoke-virtual {v6, v10, v11}, Lr5b;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return v8

    :cond_a4
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->c()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_a9
    invoke-static {}, Landroidx/health/platform/client/proto/InvalidProtocolBufferException;->d()Landroidx/health/platform/client/proto/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method
