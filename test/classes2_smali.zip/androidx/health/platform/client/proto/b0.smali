.class public final Landroidx/health/platform/client/proto/b0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final f:Landroidx/health/platform/client/proto/b0;


# instance fields
.field public a:I

.field public b:[I

.field public c:[Ljava/lang/Object;

.field public d:I

.field public e:Z


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Landroidx/health/platform/client/proto/b0;

    const/4 v1, 0x0

    new-array v2, v1, [I

    new-array v3, v1, [Ljava/lang/Object;

    invoke-direct {v0, v1, v2, v3, v1}, Landroidx/health/platform/client/proto/b0;-><init>(I[I[Ljava/lang/Object;Z)V

    sput-object v0, Landroidx/health/platform/client/proto/b0;->f:Landroidx/health/platform/client/proto/b0;

    return-void
.end method

.method public constructor <init>(I[I[Ljava/lang/Object;Z)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/health/platform/client/proto/b0;->d:I

    iput p1, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iput-object p2, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    iput-object p3, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    iput-boolean p4, p0, Landroidx/health/platform/client/proto/b0;->e:Z

    return-void
.end method

.method public static c()Landroidx/health/platform/client/proto/b0;
    .registers 5

    new-instance v0, Landroidx/health/platform/client/proto/b0;

    const/16 v1, 0x8

    new-array v2, v1, [I

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, v4, v2, v1, v3}, Landroidx/health/platform/client/proto/b0;-><init>(I[I[Ljava/lang/Object;Z)V

    return-object v0
.end method


# virtual methods
.method public final a(I)V
    .registers 5

    iget-object v0, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    array-length v1, v0

    if-le p1, v1, :cond_21

    iget v1, p0, Landroidx/health/platform/client/proto/b0;->a:I

    div-int/lit8 v2, v1, 0x2

    add-int/2addr v2, v1

    if-ge v2, p1, :cond_d

    goto :goto_e

    :cond_d
    move p1, v2

    :goto_e
    const/16 v1, 0x8

    if-ge p1, v1, :cond_13

    move p1, v1

    :cond_13
    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    iput-object v0, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    iget-object v0, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    :cond_21
    return-void
.end method

.method public final b()I
    .registers 7

    iget v0, p0, Landroidx/health/platform/client/proto/b0;->d:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_6

    return v0

    :cond_6
    const/4 v0, 0x0

    move v1, v0

    :goto_8
    iget v2, p0, Landroidx/health/platform/client/proto/b0;->a:I

    if-ge v0, v2, :cond_84

    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    aget v2, v2, v0

    ushr-int/lit8 v3, v2, 0x3

    and-int/lit8 v2, v2, 0x7

    if-eqz v2, :cond_6e

    const/4 v4, 0x1

    if-eq v2, v4, :cond_5e

    const/4 v4, 0x2

    if-eq v2, v4, :cond_53

    const/4 v5, 0x3

    if-eq v2, v5, :cond_40

    const/4 v4, 0x5

    if-ne v2, v4, :cond_34

    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    aget-object v2, v2, v0

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x4

    :goto_31
    add-int/2addr v2, v1

    move v1, v2

    goto :goto_81

    :cond_34
    new-instance p0, Landroidx/health/platform/client/proto/InvalidProtocolBufferException$InvalidWireTypeException;

    const-string v0, "Protocol message tag had invalid wire type."

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Lgdg;->o(Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return p0

    :cond_40
    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v2

    mul-int/2addr v2, v4

    iget-object v3, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    aget-object v3, v3, v0

    check-cast v3, Landroidx/health/platform/client/proto/b0;

    invoke-virtual {v3}, Landroidx/health/platform/client/proto/b0;->b()I

    move-result v3

    :goto_4f
    add-int/2addr v3, v2

    add-int/2addr v3, v1

    move v1, v3

    goto :goto_81

    :cond_53
    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    aget-object v2, v2, v0

    check-cast v2, Lh92;

    invoke-static {v3, v2}, Landroidx/health/platform/client/proto/b;->a(ILh92;)I

    move-result v2

    goto :goto_31

    :cond_5e
    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    aget-object v2, v2, v0

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x8

    goto :goto_31

    :cond_6e
    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    aget-object v2, v2, v0

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result v2

    invoke-static {v4, v5}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    goto :goto_4f

    :goto_81
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    :cond_84
    iput v1, p0, Landroidx/health/platform/client/proto/b0;->d:I

    return v1
.end method

.method public final d(ILjava/lang/Object;)V
    .registers 5

    iget-boolean v0, p0, Landroidx/health/platform/client/proto/b0;->e:Z

    if-eqz v0, :cond_1a

    iget v0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/health/platform/client/proto/b0;->a(I)V

    iget-object v0, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    iget v1, p0, Landroidx/health/platform/client/proto/b0;->a:I

    aput p1, v0, v1

    iget-object p1, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    aput-object p2, p1, v1

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Landroidx/health/platform/client/proto/b0;->a:I

    return-void

    :cond_1a
    invoke-static {}, Lty9;->u()V

    return-void
.end method

.method public final e(Lgkf;)V
    .registers 8

    iget v0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    if-nez v0, :cond_5

    goto :goto_6c

    :cond_5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Lgkf;->E:Ljava/lang/Object;

    check-cast v0, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x0

    :goto_d
    iget v2, p0, Landroidx/health/platform/client/proto/b0;->a:I

    if-ge v1, v2, :cond_6c

    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    aget v2, v2, v1

    iget-object v3, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    aget-object v3, v3, v1

    ushr-int/lit8 v4, v2, 0x3

    and-int/lit8 v2, v2, 0x7

    if-eqz v2, :cond_60

    const/4 v5, 0x1

    if-eq v2, v5, :cond_56

    const/4 v5, 0x2

    if-eq v2, v5, :cond_4d

    const/4 v5, 0x3

    if-eq v2, v5, :cond_40

    const/4 v5, 0x5

    if-ne v2, v5, :cond_35

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v0, v4, v2}, Landroidx/health/platform/client/proto/b;->k(II)V

    goto :goto_69

    :cond_35
    new-instance p0, Landroidx/health/platform/client/proto/InvalidProtocolBufferException$InvalidWireTypeException;

    const-string p1, "Protocol message tag had invalid wire type."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Lmf6;->h(Ljava/lang/Throwable;)V

    return-void

    :cond_40
    invoke-virtual {v0, v4, v5}, Landroidx/health/platform/client/proto/b;->r(II)V

    check-cast v3, Landroidx/health/platform/client/proto/b0;

    invoke-virtual {v3, p1}, Landroidx/health/platform/client/proto/b0;->e(Lgkf;)V

    const/4 v2, 0x4

    invoke-virtual {v0, v4, v2}, Landroidx/health/platform/client/proto/b;->r(II)V

    goto :goto_69

    :cond_4d
    check-cast v3, Lh92;

    invoke-virtual {v0, v4, v5}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {v0, v3}, Landroidx/health/platform/client/proto/b;->j(Lh92;)V

    goto :goto_69

    :cond_56
    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {v0, v4, v2, v3}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    goto :goto_69

    :cond_60
    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {v0, v4, v2, v3}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    :goto_69
    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_6c
    :goto_6c
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 10

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    const/4 v1, 0x0

    if-nez p1, :cond_8

    return v1

    :cond_8
    instance-of v2, p1, Landroidx/health/platform/client/proto/b0;

    if-nez v2, :cond_d

    return v1

    :cond_d
    check-cast p1, Landroidx/health/platform/client/proto/b0;

    iget v2, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iget v3, p1, Landroidx/health/platform/client/proto/b0;->a:I

    if-ne v2, v3, :cond_3e

    iget-object v3, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    iget-object v4, p1, Landroidx/health/platform/client/proto/b0;->b:[I

    move v5, v1

    :goto_1a
    if-ge v5, v2, :cond_26

    aget v6, v3, v5

    aget v7, v4, v5

    if-eq v6, v7, :cond_23

    goto :goto_3e

    :cond_23
    add-int/lit8 v5, v5, 0x1

    goto :goto_1a

    :cond_26
    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    iget-object p1, p1, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    iget p0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    move v3, v1

    :goto_2d
    if-ge v3, p0, :cond_3d

    aget-object v4, v2, v3

    aget-object v5, p1, v3

    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3a

    goto :goto_3e

    :cond_3a
    add-int/lit8 v3, v3, 0x1

    goto :goto_2d

    :cond_3d
    return v0

    :cond_3e
    :goto_3e
    return v1
.end method

.method public final hashCode()I
    .registers 9

    iget v0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    const/16 v1, 0x20f

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v2, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    const/16 v3, 0x11

    const/4 v4, 0x0

    move v6, v3

    move v5, v4

    :goto_e
    if-ge v5, v0, :cond_18

    mul-int/lit8 v6, v6, 0x1f

    aget v7, v2, v5

    add-int/2addr v6, v7

    add-int/lit8 v5, v5, 0x1

    goto :goto_e

    :cond_18
    add-int/2addr v1, v6

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    iget p0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    :goto_1f
    if-ge v4, p0, :cond_2d

    mul-int/lit8 v3, v3, 0x1f

    aget-object v2, v0, v4

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v3, v2

    add-int/lit8 v4, v4, 0x1

    goto :goto_1f

    :cond_2d
    add-int/2addr v1, v3

    return v1
.end method
