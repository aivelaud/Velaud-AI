.class public abstract Landroidx/health/platform/client/proto/y;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/Class;

.field public static final b:Landroidx/health/platform/client/proto/a0;

.field public static final c:Ll3j;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget-object v0, Lmfe;->c:Lmfe;

    const/4 v0, 0x0

    :try_start_3
    const-string v1, "androidx.health.platform.client.proto.GeneratedMessage"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_a

    goto :goto_b

    :catchall_a
    move-object v1, v0

    :goto_b
    sput-object v1, Landroidx/health/platform/client/proto/y;->a:Ljava/lang/Class;

    :try_start_d
    sget-object v1, Lmfe;->c:Lmfe;
    :try_end_f
    .catchall {:try_start_d .. :try_end_f} :catchall_25

    :try_start_f
    const-string v1, "androidx.health.platform.client.proto.UnknownFieldSetSchema"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1
    :try_end_15
    .catchall {:try_start_f .. :try_end_15} :catchall_16

    goto :goto_17

    :catchall_16
    move-object v1, v0

    :goto_17
    if-nez v1, :cond_1a

    goto :goto_25

    :cond_1a
    :try_start_1a
    invoke-virtual {v1, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/health/platform/client/proto/a0;
    :try_end_24
    .catchall {:try_start_1a .. :try_end_24} :catchall_25

    move-object v0, v1

    :catchall_25
    :goto_25
    sput-object v0, Landroidx/health/platform/client/proto/y;->b:Landroidx/health/platform/client/proto/a0;

    new-instance v0, Ll3j;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/health/platform/client/proto/y;->c:Ll3j;

    return-void
.end method

.method public static a(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lej9;

    if-eqz v2, :cond_1f

    check-cast p0, Lej9;

    move v2, v1

    :goto_f
    if-ge v1, v0, :cond_1e

    invoke-virtual {p0, v1}, Lej9;->c(I)I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_1e
    return v2

    :cond_1f
    move v2, v1

    :goto_20
    if-ge v1, v0, :cond_35

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_20

    :cond_35
    return v2
.end method

.method public static b(ILjava/util/List;)I
    .registers 2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-nez p1, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    invoke-static {p0}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result p0

    add-int/lit8 p0, p0, 0x4

    mul-int/2addr p0, p1

    return p0
.end method

.method public static c(ILjava/util/List;)I
    .registers 2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-nez p1, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    invoke-static {p0}, Landroidx/health/platform/client/proto/b;->e(I)I

    move-result p0

    add-int/lit8 p0, p0, 0x8

    mul-int/2addr p0, p1

    return p0
.end method

.method public static d(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lej9;

    if-eqz v2, :cond_1f

    check-cast p0, Lej9;

    move v2, v1

    :goto_f
    if-ge v1, v0, :cond_1e

    invoke-virtual {p0, v1}, Lej9;->c(I)I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_1e
    return v2

    :cond_1f
    move v2, v1

    :goto_20
    if-ge v1, v0, :cond_35

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    int-to-long v3, v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_20

    :cond_35
    return v2
.end method

.method public static e(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Ljxa;

    if-eqz v2, :cond_1e

    check-cast p0, Ljxa;

    move v2, v1

    :goto_f
    if-ge v1, v0, :cond_1d

    invoke-virtual {p0, v1}, Ljxa;->c(I)J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_1d
    return v2

    :cond_1e
    move v2, v1

    :goto_1f
    if-ge v1, v0, :cond_33

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    :cond_33
    return v2
.end method

.method public static f(Ljava/util/List;)I
    .registers 5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lej9;

    if-eqz v2, :cond_1e

    check-cast p0, Lej9;

    move v2, v1

    :goto_f
    if-ge v1, v0, :cond_1d

    invoke-virtual {p0, v1}, Lej9;->c(I)I

    move-result v3

    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->b(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_1d
    return v2

    :cond_1e
    move v2, v1

    :goto_1f
    if-ge v1, v0, :cond_33

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->b(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    :cond_33
    return v2
.end method

.method public static g(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Ljxa;

    if-eqz v2, :cond_1e

    check-cast p0, Ljxa;

    move v2, v1

    :goto_f
    if-ge v1, v0, :cond_1d

    invoke-virtual {p0, v1}, Ljxa;->c(I)J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->c(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_1d
    return v2

    :cond_1e
    move v2, v1

    :goto_1f
    if-ge v1, v0, :cond_33

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->c(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    :cond_33
    return v2
.end method

.method public static h(Ljava/util/List;)I
    .registers 5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Lej9;

    if-eqz v2, :cond_1e

    check-cast p0, Lej9;

    move v2, v1

    :goto_f
    if-ge v1, v0, :cond_1d

    invoke-virtual {p0, v1}, Lej9;->c(I)I

    move-result v3

    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_1d
    return v2

    :cond_1e
    move v2, v1

    :goto_1f
    if-ge v1, v0, :cond_33

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v3}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    :cond_33
    return v2
.end method

.method public static i(Ljava/util/List;)I
    .registers 6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    instance-of v2, p0, Ljxa;

    if-eqz v2, :cond_1e

    check-cast p0, Ljxa;

    move v2, v1

    :goto_f
    if-ge v1, v0, :cond_1d

    invoke-virtual {p0, v1}, Ljxa;->c(I)J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_1d
    return v2

    :cond_1e
    move v2, v1

    :goto_1f
    if-ge v1, v0, :cond_33

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    :cond_33
    return v2
.end method

.method public static j(Landroidx/health/platform/client/proto/a0;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 9

    check-cast p0, Ll3j;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/health/platform/client/proto/n;

    iget-object p0, p1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    check-cast p2, Landroidx/health/platform/client/proto/n;

    iget-object p2, p2, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    sget-object v0, Landroidx/health/platform/client/proto/b0;->f:Landroidx/health/platform/client/proto/b0;

    invoke-virtual {v0, p2}, Landroidx/health/platform/client/proto/b0;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16

    goto :goto_75

    :cond_16
    invoke-virtual {v0, p0}, Landroidx/health/platform/client/proto/b0;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_47

    iget v0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iget v1, p2, Landroidx/health/platform/client/proto/b0;->a:I

    add-int/2addr v0, v1

    iget-object v1, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v1

    iget-object v3, p2, Landroidx/health/platform/client/proto/b0;->b:[I

    iget v4, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iget v5, p2, Landroidx/health/platform/client/proto/b0;->a:I

    invoke-static {v3, v2, v1, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v3, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    invoke-static {v3, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    iget-object v4, p2, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    iget p0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iget p2, p2, Landroidx/health/platform/client/proto/b0;->a:I

    invoke-static {v4, v2, v3, p0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    new-instance p0, Landroidx/health/platform/client/proto/b0;

    const/4 p2, 0x1

    invoke-direct {p0, v0, v1, v3, p2}, Landroidx/health/platform/client/proto/b0;-><init>(I[I[Ljava/lang/Object;Z)V

    goto :goto_75

    :cond_47
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2, v0}, Landroidx/health/platform/client/proto/b0;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_51

    goto :goto_75

    :cond_51
    iget-boolean v0, p0, Landroidx/health/platform/client/proto/b0;->e:Z

    if-eqz v0, :cond_78

    iget v0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iget v1, p2, Landroidx/health/platform/client/proto/b0;->a:I

    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroidx/health/platform/client/proto/b0;->a(I)V

    iget-object v1, p2, Landroidx/health/platform/client/proto/b0;->b:[I

    iget-object v3, p0, Landroidx/health/platform/client/proto/b0;->b:[I

    iget v4, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iget v5, p2, Landroidx/health/platform/client/proto/b0;->a:I

    invoke-static {v1, v2, v3, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v1, p2, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    iget-object v3, p0, Landroidx/health/platform/client/proto/b0;->c:[Ljava/lang/Object;

    iget v4, p0, Landroidx/health/platform/client/proto/b0;->a:I

    iget p2, p2, Landroidx/health/platform/client/proto/b0;->a:I

    invoke-static {v1, v2, v3, v4, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput v0, p0, Landroidx/health/platform/client/proto/b0;->a:I

    :goto_75
    iput-object p0, p1, Landroidx/health/platform/client/proto/n;->unknownFields:Landroidx/health/platform/client/proto/b0;

    return-void

    :cond_78
    invoke-static {}, Lty9;->u()V

    return-void
.end method

.method public static k(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 2

    if-eq p0, p1, :cond_d

    if-eqz p0, :cond_b

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_b

    goto :goto_d

    :cond_b
    const/4 p0, 0x0

    return p0

    :cond_d
    :goto_d
    const/4 p0, 0x1

    return p0
.end method

.method public static l(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_6d

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6d

    instance-of v0, p1, Lkz1;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_1b

    if-eqz p3, :cond_6d

    invoke-virtual {p2, p0, v2}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {p2, v1}, Landroidx/health/platform/client/proto/b;->t(I)V

    goto :goto_6d

    :cond_1b
    if-eqz p3, :cond_52

    invoke-virtual {p2, p0, v2}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v1

    move p3, p0

    :goto_22
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_38

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x1

    add-int/lit8 p0, p0, 0x1

    goto :goto_22

    :cond_38
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_3b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v1, p0, :cond_6d

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    int-to-byte p0, p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->h(B)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_3b

    :cond_52
    move p3, v1

    :goto_53
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p3, v0, :cond_6d

    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    int-to-byte v0, v0

    invoke-virtual {p2, v0}, Landroidx/health/platform/client/proto/b;->h(B)V

    add-int/lit8 p3, p3, 0x1

    goto :goto_53

    :cond_6d
    :goto_6d
    return-void
.end method

.method public static m(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_72

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_72

    instance-of v0, p1, Ldj6;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_1b

    if-eqz p3, :cond_72

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {p2, v2}, Landroidx/health/platform/client/proto/b;->t(I)V

    goto :goto_72

    :cond_1b
    if-eqz p3, :cond_55

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_22
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_38

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_22

    :cond_38
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_3b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_72

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Double;

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->n(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_3b

    :cond_55
    :goto_55
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_72

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Double;

    invoke-virtual {p3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_55

    :cond_72
    :goto_72
    return-void
.end method

.method public static n(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_94

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_94

    instance-of v0, p1, Lej9;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_45

    check-cast p1, Lej9;

    if-eqz p3, :cond_39

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_2a

    invoke-virtual {p1, p0}, Lej9;->c(I)I

    move-result v0

    int-to-long v0, v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_2a
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2d
    if-gez v2, :cond_94

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->p(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2d

    :cond_39
    :goto_39
    if-gez v2, :cond_94

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->o(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_39

    :cond_45
    if-eqz p3, :cond_7e

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_4c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_65

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    int-to-long v0, v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_4c

    :cond_65
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_68
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_94

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->p(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_68

    :cond_7e
    :goto_7e
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_94

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->o(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7e

    :cond_94
    return-void
.end method

.method public static o(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_8e

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_8e

    instance-of v0, p1, Lej9;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_42

    check-cast p1, Lej9;

    if-eqz p3, :cond_36

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_27

    invoke-virtual {p1, p0}, Lej9;->c(I)I

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_27
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2a
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->l(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2a

    :cond_36
    :goto_36
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->k(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_36

    :cond_42
    if-eqz p3, :cond_78

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_49
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_5f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_49

    :cond_5f
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_62
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->l(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_62

    :cond_78
    :goto_78
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->k(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_78

    :cond_8e
    return-void
.end method

.method public static p(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_8e

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_8e

    instance-of v0, p1, Ljxa;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_42

    check-cast p1, Ljxa;

    if-eqz p3, :cond_36

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_27

    invoke-virtual {p1, p0}, Ljxa;->c(I)J

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_27
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2a
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->n(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2a

    :cond_36
    :goto_36
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_36

    :cond_42
    if-eqz p3, :cond_78

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_49
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_5f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_49

    :cond_5f
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_62
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->n(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_62

    :cond_78
    :goto_78
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_78

    :cond_8e
    return-void
.end method

.method public static q(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_72

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_72

    instance-of v0, p1, Lty7;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_1b

    if-eqz p3, :cond_72

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    invoke-virtual {p2, v2}, Landroidx/health/platform/client/proto/b;->t(I)V

    goto :goto_72

    :cond_1b
    if-eqz p3, :cond_55

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_22
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_38

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_22

    :cond_38
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_3b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_72

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->l(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_3b

    :cond_55
    :goto_55
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_72

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Float;

    invoke-virtual {p3}, Ljava/lang/Float;->floatValue()F

    move-result p3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->k(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_55

    :cond_72
    :goto_72
    return-void
.end method

.method public static r(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_94

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_94

    instance-of v0, p1, Lej9;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_45

    check-cast p1, Lej9;

    if-eqz p3, :cond_39

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_2a

    invoke-virtual {p1, p0}, Lej9;->c(I)I

    move-result v0

    int-to-long v0, v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_2a
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2d
    if-gez v2, :cond_94

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->p(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2d

    :cond_39
    :goto_39
    if-gez v2, :cond_94

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->o(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_39

    :cond_45
    if-eqz p3, :cond_7e

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_4c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_65

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    int-to-long v0, v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_4c

    :cond_65
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_68
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_94

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->p(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_68

    :cond_7e
    :goto_7e
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_94

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->o(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7e

    :cond_94
    return-void
.end method

.method public static s(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_92

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_92

    instance-of v0, p1, Ljxa;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_44

    check-cast p1, Ljxa;

    if-eqz p3, :cond_38

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_29

    invoke-virtual {p1, p0}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_29
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2c
    if-gez v2, :cond_92

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->v(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2c

    :cond_38
    :goto_38
    if-gez v2, :cond_92

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_38

    :cond_44
    if-eqz p3, :cond_7c

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_4b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_63

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_4b

    :cond_63
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_66
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_92

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->v(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_66

    :cond_7c
    :goto_7c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_92

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7c

    :cond_92
    return-void
.end method

.method public static t(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_8e

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_8e

    instance-of v0, p1, Lej9;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_42

    check-cast p1, Lej9;

    if-eqz p3, :cond_36

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_27

    invoke-virtual {p1, p0}, Lej9;->c(I)I

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_27
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2a
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->l(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2a

    :cond_36
    :goto_36
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->k(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_36

    :cond_42
    if-eqz p3, :cond_78

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_49
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_5f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x4

    add-int/lit8 p0, p0, 0x1

    goto :goto_49

    :cond_5f
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_62
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->l(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_62

    :cond_78
    :goto_78
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->k(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_78

    :cond_8e
    return-void
.end method

.method public static u(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_8e

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_8e

    instance-of v0, p1, Ljxa;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_42

    check-cast p1, Ljxa;

    if-eqz p3, :cond_36

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_27

    invoke-virtual {p1, p0}, Ljxa;->c(I)J

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_27
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2a
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->n(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2a

    :cond_36
    :goto_36
    if-gez v2, :cond_8e

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_36

    :cond_42
    if-eqz p3, :cond_78

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_49
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_5f

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Landroidx/health/platform/client/proto/b;->e:Ljava/util/logging/Logger;

    add-int/lit8 p3, p3, 0x8

    add-int/lit8 p0, p0, 0x1

    goto :goto_49

    :cond_5f
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_62
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->n(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_62

    :cond_78
    :goto_78
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_8e

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->m(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_78

    :cond_8e
    return-void
.end method

.method public static v(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_a6

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a6

    instance-of v0, p1, Lej9;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_4e

    check-cast p1, Lej9;

    if-eqz p3, :cond_3d

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_29

    invoke-virtual {p1, p0}, Lej9;->c(I)I

    move-result v0

    invoke-static {v0}, Landroidx/health/platform/client/proto/b;->b(I)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_29
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2c
    if-gez v2, :cond_a6

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p0

    shl-int/lit8 p3, p0, 0x1

    shr-int/lit8 p0, p0, 0x1f

    xor-int/2addr p0, p3

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->t(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2c

    :cond_3d
    :goto_3d
    if-gez v2, :cond_a6

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p3

    shl-int/lit8 v0, p3, 0x1

    shr-int/lit8 p3, p3, 0x1f

    xor-int/2addr p3, v0

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->s(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_3d

    :cond_4e
    if-eqz p3, :cond_8b

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_55
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_6d

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Landroidx/health/platform/client/proto/b;->b(I)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_55

    :cond_6d
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_70
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_a6

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    shl-int/lit8 p3, p0, 0x1

    shr-int/lit8 p0, p0, 0x1f

    xor-int/2addr p0, p3

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->t(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_70

    :cond_8b
    :goto_8b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_a6

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    shl-int/lit8 v0, p3, 0x1

    shr-int/lit8 p3, p3, 0x1f

    xor-int/2addr p3, v0

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->s(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_8b

    :cond_a6
    return-void
.end method

.method public static w(ILjava/util/List;Lgkf;Z)V
    .registers 13

    if-eqz p1, :cond_a5

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a5

    instance-of v0, p1, Ljxa;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/16 v1, 0x3f

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_4f

    check-cast p1, Ljxa;

    if-eqz p3, :cond_3f

    invoke-virtual {p2, p0, v3}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v4

    move p3, p0

    :goto_1e
    if-gez p0, :cond_2c

    invoke-virtual {p1, p0}, Ljxa;->c(I)J

    move-result-wide v5

    invoke-static {v5, v6}, Landroidx/health/platform/client/proto/b;->c(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1e

    :cond_2c
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2f
    if-gez v4, :cond_a5

    invoke-virtual {p1, v4}, Ljxa;->c(I)J

    move-result-wide v5

    shl-long v7, v5, v2

    shr-long/2addr v5, v1

    xor-long/2addr v5, v7

    invoke-virtual {p2, v5, v6}, Landroidx/health/platform/client/proto/b;->v(J)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_2f

    :cond_3f
    :goto_3f
    if-gez v4, :cond_a5

    invoke-virtual {p1, v4}, Ljxa;->c(I)J

    move-result-wide v5

    shl-long v7, v5, v2

    shr-long/2addr v5, v1

    xor-long/2addr v5, v7

    invoke-virtual {p2, p0, v5, v6}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_3f

    :cond_4f
    if-eqz p3, :cond_8b

    invoke-virtual {p2, p0, v3}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v4

    move p3, p0

    :goto_56
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_6e

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-static {v5, v6}, Landroidx/health/platform/client/proto/b;->c(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_56

    :cond_6e
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_71
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v4, p0, :cond_a5

    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    shl-long v7, v5, v2

    shr-long/2addr v5, v1

    xor-long/2addr v5, v7

    invoke-virtual {p2, v5, v6}, Landroidx/health/platform/client/proto/b;->v(J)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_71

    :cond_8b
    :goto_8b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v4, p3, :cond_a5

    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    shl-long v7, v5, v2

    shr-long/2addr v5, v1

    xor-long/2addr v5, v7

    invoke-virtual {p2, p0, v5, v6}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_8b

    :cond_a5
    return-void
.end method

.method public static x(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_92

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_92

    instance-of v0, p1, Lej9;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_44

    check-cast p1, Lej9;

    if-eqz p3, :cond_38

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_29

    invoke-virtual {p1, p0}, Lej9;->c(I)I

    move-result v0

    invoke-static {v0}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_29
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2c
    if-gez v2, :cond_92

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->t(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2c

    :cond_38
    :goto_38
    if-gez v2, :cond_92

    invoke-virtual {p1, v2}, Lej9;->c(I)I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->s(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_38

    :cond_44
    if-eqz p3, :cond_7c

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_4b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_63

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Landroidx/health/platform/client/proto/b;->f(I)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_4b

    :cond_63
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_66
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_92

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {p2, p0}, Landroidx/health/platform/client/proto/b;->t(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_66

    :cond_7c
    :goto_7c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_92

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-virtual {p2, p0, p3}, Landroidx/health/platform/client/proto/b;->s(II)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7c

    :cond_92
    return-void
.end method

.method public static y(ILjava/util/List;Lgkf;Z)V
    .registers 7

    if-eqz p1, :cond_92

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_92

    instance-of v0, p1, Ljxa;

    iget-object p2, p2, Lgkf;->E:Ljava/lang/Object;

    check-cast p2, Landroidx/health/platform/client/proto/b;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_44

    check-cast p1, Ljxa;

    if-eqz p3, :cond_38

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_1b
    if-gez p0, :cond_29

    invoke-virtual {p1, p0}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1b

    :cond_29
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_2c
    if-gez v2, :cond_92

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->v(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2c

    :cond_38
    :goto_38
    if-gez v2, :cond_92

    invoke-virtual {p1, v2}, Ljxa;->c(I)J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_38

    :cond_44
    if-eqz p3, :cond_7c

    invoke-virtual {p2, p0, v1}, Landroidx/health/platform/client/proto/b;->r(II)V

    move p0, v2

    move p3, p0

    :goto_4b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge p0, v0, :cond_63

    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/health/platform/client/proto/b;->g(J)I

    move-result v0

    add-int/2addr p3, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_4b

    :cond_63
    invoke-virtual {p2, p3}, Landroidx/health/platform/client/proto/b;->t(I)V

    :goto_66
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-ge v2, p0, :cond_92

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroidx/health/platform/client/proto/b;->v(J)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_66

    :cond_7c
    :goto_7c
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p3

    if-ge v2, p3, :cond_92

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Long;

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p2, p0, v0, v1}, Landroidx/health/platform/client/proto/b;->u(IJ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7c

    :cond_92
    return-void
.end method
