.class public final Landroidx/health/platform/client/proto/s;
.super Landroidx/health/platform/client/proto/n;
.source "SourceFile"


# static fields
.field public static final DATA_ORIGIN_FIELD_NUMBER:I = 0x3

.field private static final DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/s;

.field public static final METRIC_SPEC_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Ldcd; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldcd;"
        }
    .end annotation
.end field

.field public static final SLICE_DURATION_MILLIS_FIELD_NUMBER:I = 0x4

.field public static final SLICE_PERIOD_FIELD_NUMBER:I = 0x5

.field public static final TIME_SPEC_FIELD_NUMBER:I = 0x1


# instance fields
.field private bitField0_:I

.field private dataOrigin_:Ldl9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldl9;"
        }
    .end annotation
.end field

.field private metricSpec_:Ldl9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldl9;"
        }
    .end annotation
.end field

.field private sliceDurationMillis_:J

.field private slicePeriod_:Ljava/lang/String;

.field private timeSpec_:Landroidx/health/platform/client/proto/z;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroidx/health/platform/client/proto/s;

    invoke-direct {v0}, Landroidx/health/platform/client/proto/s;-><init>()V

    sput-object v0, Landroidx/health/platform/client/proto/s;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/s;

    const-class v1, Landroidx/health/platform/client/proto/s;

    invoke-static {v1, v0}, Landroidx/health/platform/client/proto/n;->n(Ljava/lang/Class;Landroidx/health/platform/client/proto/n;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroidx/health/platform/client/proto/n;-><init>()V

    sget-object v0, Lsfe;->H:Lsfe;

    iput-object v0, p0, Landroidx/health/platform/client/proto/s;->metricSpec_:Ldl9;

    iput-object v0, p0, Landroidx/health/platform/client/proto/s;->dataOrigin_:Ldl9;

    const-string v0, ""

    iput-object v0, p0, Landroidx/health/platform/client/proto/s;->slicePeriod_:Ljava/lang/String;

    return-void
.end method

.method public static p(Landroidx/health/platform/client/proto/s;Landroidx/health/platform/client/proto/z;)V
    .registers 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Landroidx/health/platform/client/proto/s;->timeSpec_:Landroidx/health/platform/client/proto/z;

    iget p1, p0, Landroidx/health/platform/client/proto/s;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Landroidx/health/platform/client/proto/s;->bitField0_:I

    return-void
.end method

.method public static q(Landroidx/health/platform/client/proto/s;Ljava/util/ArrayList;)V
    .registers 4

    iget-object v0, p0, Landroidx/health/platform/client/proto/s;->metricSpec_:Ldl9;

    move-object v1, v0

    check-cast v1, Lp3;

    iget-boolean v1, v1, Lp3;->E:Z

    if-nez v1, :cond_1a

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    if-nez v1, :cond_12

    const/16 v1, 0xa

    goto :goto_14

    :cond_12
    mul-int/lit8 v1, v1, 0x2

    :goto_14
    invoke-interface {v0, v1}, Ldl9;->l(I)Ldl9;

    move-result-object v0

    iput-object v0, p0, Landroidx/health/platform/client/proto/s;->metricSpec_:Ldl9;

    :cond_1a
    iget-object p0, p0, Landroidx/health/platform/client/proto/s;->metricSpec_:Ldl9;

    invoke-static {p1, p0}, Landroidx/health/platform/client/proto/a;->a(Ljava/util/ArrayList;Ljava/util/List;)V

    return-void
.end method

.method public static r(Landroidx/health/platform/client/proto/s;Ljava/util/ArrayList;)V
    .registers 4

    iget-object v0, p0, Landroidx/health/platform/client/proto/s;->dataOrigin_:Ldl9;

    move-object v1, v0

    check-cast v1, Lp3;

    iget-boolean v1, v1, Lp3;->E:Z

    if-nez v1, :cond_1a

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    if-nez v1, :cond_12

    const/16 v1, 0xa

    goto :goto_14

    :cond_12
    mul-int/lit8 v1, v1, 0x2

    :goto_14
    invoke-interface {v0, v1}, Ldl9;->l(I)Ldl9;

    move-result-object v0

    iput-object v0, p0, Landroidx/health/platform/client/proto/s;->dataOrigin_:Ldl9;

    :cond_1a
    iget-object p0, p0, Landroidx/health/platform/client/proto/s;->dataOrigin_:Ldl9;

    invoke-static {p1, p0}, Landroidx/health/platform/client/proto/a;->a(Ljava/util/ArrayList;Ljava/util/List;)V

    return-void
.end method

.method public static s(Landroidx/health/platform/client/proto/s;J)V
    .registers 4

    iget v0, p0, Landroidx/health/platform/client/proto/s;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Landroidx/health/platform/client/proto/s;->bitField0_:I

    iput-wide p1, p0, Landroidx/health/platform/client/proto/s;->sliceDurationMillis_:J

    return-void
.end method

.method public static t(Landroidx/health/platform/client/proto/s;Ljava/lang/String;)V
    .registers 3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v0, p0, Landroidx/health/platform/client/proto/s;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Landroidx/health/platform/client/proto/s;->bitField0_:I

    iput-object p1, p0, Landroidx/health/platform/client/proto/s;->slicePeriod_:Ljava/lang/String;

    return-void
.end method

.method public static u()Li8f;
    .registers 1

    sget-object v0, Landroidx/health/platform/client/proto/s;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/s;

    invoke-virtual {v0}, Landroidx/health/platform/client/proto/n;->d()Lkc8;

    move-result-object v0

    check-cast v0, Li8f;

    return-object v0
.end method

.method public static v([B)Landroidx/health/platform/client/proto/s;
    .registers 2

    sget-object v0, Landroidx/health/platform/client/proto/s;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/s;

    invoke-static {v0, p0}, Landroidx/health/platform/client/proto/n;->m(Landroidx/health/platform/client/proto/n;[B)Landroidx/health/platform/client/proto/n;

    move-result-object p0

    check-cast p0, Landroidx/health/platform/client/proto/s;

    return-object p0
.end method


# virtual methods
.method public final e(I)Ljava/lang/Object;
    .registers 10

    invoke-static {p1}, Ld07;->F(I)I

    move-result p0

    const/4 p1, 0x0

    packed-switch p0, :pswitch_data_5e

    invoke-static {}, Lty9;->u()V

    return-object p1

    :pswitch_c  #0x6
    sget-object p0, Landroidx/health/platform/client/proto/s;->PARSER:Ldcd;

    if-nez p0, :cond_26

    const-class p1, Landroidx/health/platform/client/proto/s;

    monitor-enter p1

    :try_start_13
    sget-object p0, Landroidx/health/platform/client/proto/s;->PARSER:Ldcd;

    if-nez p0, :cond_22

    new-instance p0, Lqc8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sput-object p0, Landroidx/health/platform/client/proto/s;->PARSER:Ldcd;

    goto :goto_22

    :catchall_1f
    move-exception v0

    move-object p0, v0

    goto :goto_24

    :cond_22
    :goto_22
    monitor-exit p1

    return-object p0

    :goto_24
    monitor-exit p1
    :try_end_25
    .catchall {:try_start_13 .. :try_end_25} :catchall_1f

    throw p0

    :cond_26
    return-object p0

    :pswitch_27  #0x5
    sget-object p0, Landroidx/health/platform/client/proto/s;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/s;

    return-object p0

    :pswitch_2a  #0x4
    new-instance p0, Li8f;

    sget-object p1, Landroidx/health/platform/client/proto/s;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/s;

    invoke-direct {p0, p1}, Lkc8;-><init>(Landroidx/health/platform/client/proto/n;)V

    return-object p0

    :pswitch_32  #0x3
    new-instance p0, Landroidx/health/platform/client/proto/s;

    invoke-direct {p0}, Landroidx/health/platform/client/proto/s;-><init>()V

    return-object p0

    :pswitch_38  #0x2
    const-string v0, "bitField0_"

    const-string v1, "timeSpec_"

    const-string v2, "metricSpec_"

    const-class v3, Landroidx/health/platform/client/proto/t;

    const-string v4, "dataOrigin_"

    const-class v5, Landroidx/health/platform/client/proto/e;

    const-string v6, "sliceDurationMillis_"

    const-string v7, "slicePeriod_"

    filled-new-array/range {v0 .. v7}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0002\u0000\u0001ဉ\u0000\u0002\u001b\u0003\u001b\u0004ဂ\u0001\u0005ဈ\u0002"

    sget-object v0, Landroidx/health/platform/client/proto/s;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/s;

    new-instance v1, Lmne;

    invoke-direct {v1, v0, p1, p0}, Lmne;-><init>(Landroidx/health/platform/client/proto/a;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v1

    :pswitch_56  #0x1
    return-object p1

    :pswitch_57  #0x0
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_5e
    .packed-switch 0x0
        :pswitch_57  #00000000
        :pswitch_56  #00000001
        :pswitch_38  #00000002
        :pswitch_32  #00000003
        :pswitch_2a  #00000004
        :pswitch_27  #00000005
        :pswitch_c  #00000006
    .end packed-switch
.end method
