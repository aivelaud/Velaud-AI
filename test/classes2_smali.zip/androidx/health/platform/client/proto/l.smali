.class public final Landroidx/health/platform/client/proto/l;
.super Landroidx/health/platform/client/proto/n;
.source "SourceFile"


# static fields
.field public static final BOOLEAN_VAL_FIELD_NUMBER:I = 0x5

.field private static final DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/l;

.field public static final DOUBLE_VAL_FIELD_NUMBER:I = 0x2

.field public static final ENUM_VAL_FIELD_NUMBER:I = 0x4

.field public static final LONG_VAL_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Ldcd; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldcd;"
        }
    .end annotation
.end field

.field public static final STRING_VAL_FIELD_NUMBER:I = 0x3


# instance fields
.field private valueCase_:I

.field private value_:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroidx/health/platform/client/proto/l;

    invoke-direct {v0}, Landroidx/health/platform/client/proto/l;-><init>()V

    sput-object v0, Landroidx/health/platform/client/proto/l;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/l;

    const-class v1, Landroidx/health/platform/client/proto/l;

    invoke-static {v1, v0}, Landroidx/health/platform/client/proto/n;->n(Ljava/lang/Class;Landroidx/health/platform/client/proto/n;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroidx/health/platform/client/proto/n;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroidx/health/platform/client/proto/l;->valueCase_:I

    return-void
.end method

.method public static q()Landroidx/health/platform/client/proto/l;
    .registers 1

    sget-object v0, Landroidx/health/platform/client/proto/l;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/l;

    return-object v0
.end method


# virtual methods
.method public final e(I)Ljava/lang/Object;
    .registers 4

    invoke-static {p1}, Ld07;->F(I)I

    move-result p0

    const/4 p1, 0x0

    packed-switch p0, :pswitch_data_50

    invoke-static {}, Lty9;->u()V

    return-object p1

    :pswitch_c  #0x6
    sget-object p0, Landroidx/health/platform/client/proto/l;->PARSER:Ldcd;

    if-nez p0, :cond_25

    const-class p1, Landroidx/health/platform/client/proto/l;

    monitor-enter p1

    :try_start_13
    sget-object p0, Landroidx/health/platform/client/proto/l;->PARSER:Ldcd;

    if-nez p0, :cond_21

    new-instance p0, Lqc8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sput-object p0, Landroidx/health/platform/client/proto/l;->PARSER:Ldcd;

    goto :goto_21

    :catchall_1f
    move-exception p0

    goto :goto_23

    :cond_21
    :goto_21
    monitor-exit p1

    return-object p0

    :goto_23
    monitor-exit p1
    :try_end_24
    .catchall {:try_start_13 .. :try_end_24} :catchall_1f

    throw p0

    :cond_25
    return-object p0

    :pswitch_26  #0x5
    sget-object p0, Landroidx/health/platform/client/proto/l;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/l;

    return-object p0

    :pswitch_29  #0x4
    new-instance p0, Lko5;

    sget-object p1, Landroidx/health/platform/client/proto/l;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/l;

    invoke-direct {p0, p1}, Lkc8;-><init>(Landroidx/health/platform/client/proto/n;)V

    return-object p0

    :pswitch_31  #0x3
    new-instance p0, Landroidx/health/platform/client/proto/l;

    invoke-direct {p0}, Landroidx/health/platform/client/proto/l;-><init>()V

    return-object p0

    :pswitch_37  #0x2
    const-string p0, "value_"

    const-string p1, "valueCase_"

    filled-new-array {p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "\u0001\u0005\u0001\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u00015\u0000\u00023\u0000\u0003;\u0000\u0004;\u0000\u0005:\u0000"

    sget-object v0, Landroidx/health/platform/client/proto/l;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/l;

    new-instance v1, Lmne;

    invoke-direct {v1, v0, p1, p0}, Lmne;-><init>(Landroidx/health/platform/client/proto/a;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v1

    :pswitch_49  #0x1
    return-object p1

    :pswitch_4a  #0x0
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_4a  #00000000
        :pswitch_49  #00000001
        :pswitch_37  #00000002
        :pswitch_31  #00000003
        :pswitch_29  #00000004
        :pswitch_26  #00000005
        :pswitch_c  #00000006
    .end packed-switch
.end method

.method public final p()Z
    .registers 3

    iget v0, p0, Landroidx/health/platform/client/proto/l;->valueCase_:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_e

    iget-object p0, p0, Landroidx/health/platform/client/proto/l;->value_:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    :cond_e
    const/4 p0, 0x0

    return p0
.end method

.method public final r()D
    .registers 3

    iget v0, p0, Landroidx/health/platform/client/proto/l;->valueCase_:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_e

    iget-object p0, p0, Landroidx/health/platform/client/proto/l;->value_:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Double;

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    return-wide v0

    :cond_e
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public final s()Ljava/lang/String;
    .registers 3

    iget v0, p0, Landroidx/health/platform/client/proto/l;->valueCase_:I

    const/4 v1, 0x4

    if-ne v0, v1, :cond_a

    iget-object p0, p0, Landroidx/health/platform/client/proto/l;->value_:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_a
    const-string p0, ""

    return-object p0
.end method

.method public final t()J
    .registers 3

    iget v0, p0, Landroidx/health/platform/client/proto/l;->valueCase_:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_e

    iget-object p0, p0, Landroidx/health/platform/client/proto/l;->value_:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    :cond_e
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public final u()Ljava/lang/String;
    .registers 3

    iget v0, p0, Landroidx/health/platform/client/proto/l;->valueCase_:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_a

    iget-object p0, p0, Landroidx/health/platform/client/proto/l;->value_:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_a
    const-string p0, ""

    return-object p0
.end method
