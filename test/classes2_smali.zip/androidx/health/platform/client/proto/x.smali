.class public final Landroidx/health/platform/client/proto/x;
.super Landroidx/health/platform/client/proto/n;
.source "SourceFile"


# static fields
.field public static final DATA_POINT_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/x;

.field public static final PAGE_TOKEN_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Ldcd;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldcd;"
        }
    .end annotation
.end field


# instance fields
.field private bitField0_:I

.field private dataPoint_:Ldl9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldl9;"
        }
    .end annotation
.end field

.field private pageToken_:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroidx/health/platform/client/proto/x;

    invoke-direct {v0}, Landroidx/health/platform/client/proto/x;-><init>()V

    sput-object v0, Landroidx/health/platform/client/proto/x;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/x;

    const-class v1, Landroidx/health/platform/client/proto/x;

    invoke-static {v1, v0}, Landroidx/health/platform/client/proto/n;->n(Ljava/lang/Class;Landroidx/health/platform/client/proto/n;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroidx/health/platform/client/proto/n;-><init>()V

    sget-object v0, Lsfe;->H:Lsfe;

    iput-object v0, p0, Landroidx/health/platform/client/proto/x;->dataPoint_:Ldl9;

    const-string v0, ""

    iput-object v0, p0, Landroidx/health/platform/client/proto/x;->pageToken_:Ljava/lang/String;

    return-void
.end method

.method public static r([B)Landroidx/health/platform/client/proto/x;
    .registers 2

    sget-object v0, Landroidx/health/platform/client/proto/x;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/x;

    invoke-static {v0, p0}, Landroidx/health/platform/client/proto/n;->m(Landroidx/health/platform/client/proto/n;[B)Landroidx/health/platform/client/proto/n;

    move-result-object p0

    check-cast p0, Landroidx/health/platform/client/proto/x;

    return-object p0
.end method


# virtual methods
.method public final e(I)Ljava/lang/Object;
    .registers 4

    invoke-static {p1}, Ld07;->F(I)I

    move-result p0

    const/4 p1, 0x0

    packed-switch p0, :pswitch_data_54

    invoke-static {}, Lty9;->u()V

    return-object p1

    :pswitch_c  #0x6
    sget-object p0, Landroidx/health/platform/client/proto/x;->PARSER:Ldcd;

    if-nez p0, :cond_25

    const-class p1, Landroidx/health/platform/client/proto/x;

    monitor-enter p1

    :try_start_13
    sget-object p0, Landroidx/health/platform/client/proto/x;->PARSER:Ldcd;

    if-nez p0, :cond_21

    new-instance p0, Lqc8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sput-object p0, Landroidx/health/platform/client/proto/x;->PARSER:Ldcd;

    goto :goto_21

    :catchall_1f
    move-exception p0

    goto :goto_23

    :cond_21
    :goto_21
    monitor-exit p1

    return-object p0

    :goto_23
    monitor-exit p1
    :try_end_24
    .catchall {:try_start_13 .. :try_end_24} :catchall_1f

    throw p0

    :cond_25
    return-object p0

    :pswitch_26  #0x5
    sget-object p0, Landroidx/health/platform/client/proto/x;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/x;

    return-object p0

    :pswitch_29  #0x4
    new-instance p0, Lko5;

    sget-object p1, Landroidx/health/platform/client/proto/x;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/x;

    invoke-direct {p0, p1}, Lkc8;-><init>(Landroidx/health/platform/client/proto/n;)V

    return-object p0

    :pswitch_31  #0x3
    new-instance p0, Landroidx/health/platform/client/proto/x;

    invoke-direct {p0}, Landroidx/health/platform/client/proto/x;-><init>()V

    return-object p0

    :pswitch_37  #0x2
    const-string p0, "bitField0_"

    const-string p1, "dataPoint_"

    const-class v0, Landroidx/health/platform/client/proto/g;

    const-string v1, "pageToken_"

    filled-new-array {p0, p1, v0, v1}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001b\u0002ဈ\u0000"

    sget-object v0, Landroidx/health/platform/client/proto/x;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/x;

    new-instance v1, Lmne;

    invoke-direct {v1, v0, p1, p0}, Lmne;-><init>(Landroidx/health/platform/client/proto/a;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v1

    :pswitch_4d  #0x1
    return-object p1

    :pswitch_4e  #0x0
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0

    :pswitch_data_54
    .packed-switch 0x0
        :pswitch_4e  #00000000
        :pswitch_4d  #00000001
        :pswitch_37  #00000002
        :pswitch_31  #00000003
        :pswitch_29  #00000004
        :pswitch_26  #00000005
        :pswitch_c  #00000006
    .end packed-switch
.end method

.method public final p()Ldl9;
    .registers 1

    iget-object p0, p0, Landroidx/health/platform/client/proto/x;->dataPoint_:Ldl9;

    return-object p0
.end method

.method public final q()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Landroidx/health/platform/client/proto/x;->pageToken_:Ljava/lang/String;

    return-object p0
.end method
