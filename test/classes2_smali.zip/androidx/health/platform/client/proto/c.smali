.class public final Landroidx/health/platform/client/proto/c;
.super Landroidx/health/platform/client/proto/n;
.source "SourceFile"


# static fields
.field public static final DATA_ORIGINS_FIELD_NUMBER:I = 0x8

.field private static final DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/c;

.field public static final DOUBLE_VALUES_FIELD_NUMBER:I = 0x6

.field public static final END_LOCAL_DATE_TIME_FIELD_NUMBER:I = 0x4

.field public static final END_TIME_EPOCH_MS_FIELD_NUMBER:I = 0x2

.field public static final LONG_VALUES_FIELD_NUMBER:I = 0x7

.field private static volatile PARSER:Ldcd; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldcd;"
        }
    .end annotation
.end field

.field public static final START_LOCAL_DATE_TIME_FIELD_NUMBER:I = 0x3

.field public static final START_TIME_EPOCH_MS_FIELD_NUMBER:I = 0x1

.field public static final ZONE_OFFSET_SECONDS_FIELD_NUMBER:I = 0x5


# instance fields
.field private bitField0_:I

.field private dataOrigins_:Ldl9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ldl9;"
        }
    .end annotation
.end field

.field private doubleValues_:Lr5b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lr5b;"
        }
    .end annotation
.end field

.field private endLocalDateTime_:Ljava/lang/String;

.field private endTimeEpochMs_:J

.field private longValues_:Lr5b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lr5b;"
        }
    .end annotation
.end field

.field private startLocalDateTime_:Ljava/lang/String;

.field private startTimeEpochMs_:J

.field private zoneOffsetSeconds_:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Landroidx/health/platform/client/proto/c;

    invoke-direct {v0}, Landroidx/health/platform/client/proto/c;-><init>()V

    sput-object v0, Landroidx/health/platform/client/proto/c;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/c;

    const-class v1, Landroidx/health/platform/client/proto/c;

    invoke-static {v1, v0}, Landroidx/health/platform/client/proto/n;->n(Ljava/lang/Class;Landroidx/health/platform/client/proto/n;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroidx/health/platform/client/proto/n;-><init>()V

    sget-object v0, Lr5b;->F:Lr5b;

    iput-object v0, p0, Landroidx/health/platform/client/proto/c;->doubleValues_:Lr5b;

    iput-object v0, p0, Landroidx/health/platform/client/proto/c;->longValues_:Lr5b;

    const-string v0, ""

    iput-object v0, p0, Landroidx/health/platform/client/proto/c;->startLocalDateTime_:Ljava/lang/String;

    iput-object v0, p0, Landroidx/health/platform/client/proto/c;->endLocalDateTime_:Ljava/lang/String;

    sget-object v0, Lsfe;->H:Lsfe;

    iput-object v0, p0, Landroidx/health/platform/client/proto/c;->dataOrigins_:Ldl9;

    return-void
.end method


# virtual methods
.method public final A()Z
    .registers 2

    iget p0, p0, Landroidx/health/platform/client/proto/c;->bitField0_:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-eqz p0, :cond_7

    return v0

    :cond_7
    const/4 p0, 0x0

    return p0
.end method

.method public final e(I)Ljava/lang/Object;
    .registers 14

    invoke-static {p1}, Ld07;->F(I)I

    move-result p0

    const/4 p1, 0x0

    packed-switch p0, :pswitch_data_66

    invoke-static {}, Lty9;->u()V

    return-object p1

    :pswitch_c  #0x6
    sget-object p0, Landroidx/health/platform/client/proto/c;->PARSER:Ldcd;

    if-nez p0, :cond_26

    const-class p1, Landroidx/health/platform/client/proto/c;

    monitor-enter p1

    :try_start_13
    sget-object p0, Landroidx/health/platform/client/proto/c;->PARSER:Ldcd;

    if-nez p0, :cond_22

    new-instance p0, Lqc8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sput-object p0, Landroidx/health/platform/client/proto/c;->PARSER:Ldcd;

    goto :goto_22

    :catchall_1f
    move-exception v0

    move-object p0, v0

    goto :goto_24

    :cond_22
    :goto_22
    monitor-exit p1

    return-object p0

    :goto_24
    monitor-exit p1
    :try_end_25
    .catchall {:try_start_13 .. :try_end_25} :catchall_1f

    throw p0

    :cond_26
    return-object p0

    :pswitch_27  #0x5
    sget-object p0, Landroidx/health/platform/client/proto/c;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/c;

    return-object p0

    :pswitch_2a  #0x4
    new-instance p0, Lko5;

    sget-object p1, Landroidx/health/platform/client/proto/c;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/c;

    invoke-direct {p0, p1}, Lkc8;-><init>(Landroidx/health/platform/client/proto/n;)V

    return-object p0

    :pswitch_32  #0x3
    new-instance p0, Landroidx/health/platform/client/proto/c;

    invoke-direct {p0}, Landroidx/health/platform/client/proto/c;-><init>()V

    return-object p0

    :pswitch_38  #0x2
    const-string v0, "bitField0_"

    const-string v1, "startTimeEpochMs_"

    const-string v2, "endTimeEpochMs_"

    const-string v3, "startLocalDateTime_"

    const-string v4, "endLocalDateTime_"

    const-string v5, "zoneOffsetSeconds_"

    const-string v6, "doubleValues_"

    sget-object v7, Llo5;->a:Lk5b;

    const-string v8, "longValues_"

    sget-object v9, Lmo5;->a:Lk5b;

    const-string v10, "dataOrigins_"

    const-class v11, Landroidx/health/platform/client/proto/e;

    filled-new-array/range {v0 .. v11}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "\u0001\b\u0000\u0001\u0001\b\b\u0002\u0001\u0000\u0001ဂ\u0000\u0002ဂ\u0001\u0003ဈ\u0002\u0004ဈ\u0003\u0005င\u0004\u00062\u00072\b\u001b"

    sget-object v0, Landroidx/health/platform/client/proto/c;->DEFAULT_INSTANCE:Landroidx/health/platform/client/proto/c;

    new-instance v1, Lmne;

    invoke-direct {v1, v0, p1, p0}, Lmne;-><init>(Landroidx/health/platform/client/proto/a;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v1

    :pswitch_5e  #0x1
    return-object p1

    :pswitch_5f  #0x0
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_66
    .packed-switch 0x0
        :pswitch_5f  #00000000
        :pswitch_5e  #00000001
        :pswitch_38  #00000002
        :pswitch_32  #00000003
        :pswitch_2a  #00000004
        :pswitch_27  #00000005
        :pswitch_c  #00000006
    .end packed-switch
.end method

.method public final p()Ldl9;
    .registers 1

    iget-object p0, p0, Landroidx/health/platform/client/proto/c;->dataOrigins_:Ldl9;

    return-object p0
.end method

.method public final q()Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Landroidx/health/platform/client/proto/c;->doubleValues_:Lr5b;

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method

.method public final r()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Landroidx/health/platform/client/proto/c;->endLocalDateTime_:Ljava/lang/String;

    return-object p0
.end method

.method public final s()J
    .registers 3

    iget-wide v0, p0, Landroidx/health/platform/client/proto/c;->endTimeEpochMs_:J

    return-wide v0
.end method

.method public final t()Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Landroidx/health/platform/client/proto/c;->longValues_:Lr5b;

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method

.method public final u()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Landroidx/health/platform/client/proto/c;->startLocalDateTime_:Ljava/lang/String;

    return-object p0
.end method

.method public final v()J
    .registers 3

    iget-wide v0, p0, Landroidx/health/platform/client/proto/c;->startTimeEpochMs_:J

    return-wide v0
.end method

.method public final w()I
    .registers 1

    iget p0, p0, Landroidx/health/platform/client/proto/c;->zoneOffsetSeconds_:I

    return p0
.end method

.method public final x()Z
    .registers 1

    iget p0, p0, Landroidx/health/platform/client/proto/c;->bitField0_:I

    and-int/lit8 p0, p0, 0x8

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final y()Z
    .registers 1

    iget p0, p0, Landroidx/health/platform/client/proto/c;->bitField0_:I

    and-int/lit8 p0, p0, 0x2

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final z()Z
    .registers 1

    iget p0, p0, Landroidx/health/platform/client/proto/c;->bitField0_:I

    and-int/lit8 p0, p0, 0x4

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method
