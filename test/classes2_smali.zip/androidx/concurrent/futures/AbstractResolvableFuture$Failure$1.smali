.class Landroidx/concurrent/futures/AbstractResolvableFuture$Failure$1;
.super Ljava/lang/Throwable;
.source "SourceFile"


# virtual methods
.method public final declared-synchronized fillInStackTrace()Ljava/lang/Throwable;
    .registers 1

    monitor-enter p0

    monitor-exit p0

    return-object p0
.end method
