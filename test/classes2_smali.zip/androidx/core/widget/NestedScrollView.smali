.class public Landroidx/core/widget/NestedScrollView;
.super Landroid/widget/FrameLayout;
.source "SourceFile"

# interfaces
.implements Luhc;
.implements Landroidx/core/view/ScrollingView;


# static fields
.field public static final j0:F

.field public static final k0:Lphc;

.field public static final l0:[I


# instance fields
.field public final E:F

.field public F:J

.field public final G:Landroid/graphics/Rect;

.field public final H:Landroid/widget/OverScroller;

.field public final I:Landroid/widget/EdgeEffect;

.field public final J:Landroid/widget/EdgeEffect;

.field public K:Lxzf;

.field public L:I

.field public M:Z

.field public N:Z

.field public O:Landroid/view/View;

.field public P:Z

.field public Q:Landroid/view/VelocityTracker;

.field public R:Z

.field public S:Z

.field public final T:I

.field public final U:I

.field public final V:I

.field public W:I

.field public final a0:[I

.field public final b0:[I

.field public c0:I

.field public d0:I

.field public e0:Lshc;

.field public final f0:Llb2;

.field public final g0:Lvu1;

.field public h0:F

.field public final i0:Lld6;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const-wide v0, 0x3fe8f5c28f5c28f6L  # 0.78

    invoke-static {v0, v1}, Ljava/lang/Math;->log(D)D

    move-result-wide v0

    const-wide v2, 0x3feccccccccccccdL  # 0.9

    invoke-static {v2, v3}, Ljava/lang/Math;->log(D)D

    move-result-wide v2

    div-double/2addr v0, v2

    double-to-float v0, v0

    sput v0, Landroidx/core/widget/NestedScrollView;->j0:F

    new-instance v0, Lphc;

    invoke-direct {v0}, Lh5;-><init>()V

    sput-object v0, Landroidx/core/widget/NestedScrollView;->k0:Lphc;

    const v0, 0x101017a

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Landroidx/core/widget/NestedScrollView;->l0:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 196
    invoke-direct {p0, p1, v0}, Landroidx/core/widget/NestedScrollView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const v0, 0x7f04035b

    .line 195
    invoke-direct {p0, p1, p2, v0}, Landroidx/core/widget/NestedScrollView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 9

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/core/widget/NestedScrollView;->M:Z

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/core/widget/NestedScrollView;->N:Z

    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/core/widget/NestedScrollView;->O:Landroid/view/View;

    iput-boolean v1, p0, Landroidx/core/widget/NestedScrollView;->P:Z

    iput-boolean v0, p0, Landroidx/core/widget/NestedScrollView;->S:Z

    const/4 v2, -0x1

    iput v2, p0, Landroidx/core/widget/NestedScrollView;->W:I

    const/4 v2, 0x2

    new-array v3, v2, [I

    iput-object v3, p0, Landroidx/core/widget/NestedScrollView;->a0:[I

    new-array v2, v2, [I

    iput-object v2, p0, Landroidx/core/widget/NestedScrollView;->b0:[I

    new-instance v2, Lkv6;

    invoke-direct {v2, p0}, Lkv6;-><init>(Ljava/lang/Object;)V

    new-instance v3, Lld6;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4, v2}, Lld6;-><init>(Landroid/content/Context;Lkv6;)V

    iput-object v3, p0, Landroidx/core/widget/NestedScrollView;->i0:Lld6;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1f

    if-lt v2, v3, :cond_3e

    invoke-static {p1, p2}, Lis6;->a(Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/widget/EdgeEffect;

    move-result-object v4

    goto :goto_43

    :cond_3e
    new-instance v4, Landroid/widget/EdgeEffect;

    invoke-direct {v4, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    :goto_43
    iput-object v4, p0, Landroidx/core/widget/NestedScrollView;->I:Landroid/widget/EdgeEffect;

    if-lt v2, v3, :cond_4c

    invoke-static {p1, p2}, Lis6;->a(Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/widget/EdgeEffect;

    move-result-object v2

    goto :goto_51

    :cond_4c
    new-instance v2, Landroid/widget/EdgeEffect;

    invoke-direct {v2, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    :goto_51
    iput-object v2, p0, Landroidx/core/widget/NestedScrollView;->J:Landroid/widget/EdgeEffect;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    const/high16 v3, 0x43200000  # 160.0f

    mul-float/2addr v2, v3

    const v3, 0x43c10b3d

    mul-float/2addr v2, v3

    const v3, 0x3f570a3d  # 0.84f

    mul-float/2addr v2, v3

    iput v2, p0, Landroidx/core/widget/NestedScrollView;->E:F

    new-instance v2, Landroid/widget/OverScroller;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    const/high16 v2, 0x40000

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->setDescendantFocusability(I)V

    invoke-virtual {p0, v1}, Landroid/view/View;->setWillNotDraw(Z)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v3

    iput v3, p0, Landroidx/core/widget/NestedScrollView;->T:I

    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v3

    iput v3, p0, Landroidx/core/widget/NestedScrollView;->U:I

    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    move-result v2

    iput v2, p0, Landroidx/core/widget/NestedScrollView;->V:I

    sget-object v2, Landroidx/core/widget/NestedScrollView;->l0:[I

    invoke-virtual {p1, p2, v2, p3, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1, v1, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    invoke-virtual {p0, p2}, Landroidx/core/widget/NestedScrollView;->setFillViewport(Z)V

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    new-instance p1, Llb2;

    invoke-direct {p1}, Llb2;-><init>()V

    iput-object p1, p0, Landroidx/core/widget/NestedScrollView;->f0:Llb2;

    new-instance p1, Lvu1;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p0, p1, Lvu1;->d:Ljava/lang/Object;

    iput-object p1, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    invoke-virtual {p0, v0}, Landroidx/core/widget/NestedScrollView;->setNestedScrollingEnabled(Z)V

    sget-object p1, Landroidx/core/widget/NestedScrollView;->k0:Lphc;

    invoke-static {p0, p1}, Lgkj;->h(Landroid/view/View;Lh5;)V

    return-void
.end method

.method private getScrollFeedbackProvider()Lxzf;
    .registers 2

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->K:Lxzf;

    if-nez v0, :cond_b

    new-instance v0, Lxzf;

    invoke-direct {v0, p0}, Lxzf;-><init>(Landroidx/core/widget/NestedScrollView;)V

    iput-object v0, p0, Landroidx/core/widget/NestedScrollView;->K:Lxzf;

    :cond_b
    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->K:Lxzf;

    return-object p0
.end method

.method public static m(Landroid/view/View;Landroidx/core/widget/NestedScrollView;)Z
    .registers 3

    if-ne p0, p1, :cond_3

    goto :goto_13

    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_15

    check-cast p0, Landroid/view/View;

    invoke-static {p0, p1}, Landroidx/core/widget/NestedScrollView;->m(Landroid/view/View;Landroidx/core/widget/NestedScrollView;)Z

    move-result p0

    if-eqz p0, :cond_15

    :goto_13
    const/4 p0, 0x1

    return p0

    :cond_15
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final a(Landroidx/core/widget/NestedScrollView;IIIII)V
    .registers 7

    const/4 p1, 0x0

    invoke-virtual {p0, p5, p6, p1}, Landroidx/core/widget/NestedScrollView;->o(II[I)V

    return-void
.end method

.method public final addView(Landroid/view/View;)V
    .registers 3

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-gtz v0, :cond_a

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void

    :cond_a
    const-string p0, "ScrollView can host only one direct child"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void
.end method

.method public final addView(Landroid/view/View;I)V
    .registers 4

    .line 16
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-gtz v0, :cond_a

    .line 17
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    return-void

    .line 18
    :cond_a
    const-string p0, "ScrollView can host only one direct child"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void
.end method

.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .registers 5

    .line 22
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-gtz v0, :cond_a

    .line 23
    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void

    .line 24
    :cond_a
    const-string p0, "ScrollView can host only one direct child"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void
.end method

.method public final addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 4

    .line 19
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-gtz v0, :cond_a

    .line 20
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void

    .line 21
    :cond_a
    const-string p0, "ScrollView can host only one direct child"

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return-void
.end method

.method public final b(I)Z
    .registers 12

    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v1

    if-ne v1, p0, :cond_7

    const/4 v1, 0x0

    :cond_7
    move-object v7, v1

    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    move-result-object v1

    invoke-virtual {v1, p0, v7, p1}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    move-result-object v8

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->getMaxScrollAmount()I

    move-result v1

    const/4 v9, 0x0

    if-eqz v8, :cond_3a

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-virtual {p0, v8, v1, v2}, Landroidx/core/widget/NestedScrollView;->n(Landroid/view/View;II)Z

    move-result v2

    if-eqz v2, :cond_3a

    iget-object v1, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    invoke-virtual {v8, v1}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    invoke-virtual {p0, v8, v1}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->c(Landroid/graphics/Rect;)I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroidx/core/widget/NestedScrollView;->t(IILandroid/view/MotionEvent;IIZ)I

    invoke-virtual {v8, p1}, Landroid/view/View;->requestFocus(I)Z

    goto :goto_87

    :cond_3a
    const/16 v2, 0x21

    const/16 v3, 0x82

    if-ne p1, v2, :cond_4b

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v2

    if-ge v2, v1, :cond_4b

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v1

    goto :goto_77

    :cond_4b
    if-ne p1, v3, :cond_77

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    if-lez v2, :cond_77

    invoke-virtual {p0, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    move-result v2

    iget v4, v4, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v2, v4

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v4

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v5

    add-int/2addr v5, v4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    sub-int/2addr v5, v4

    sub-int/2addr v2, v5

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    :cond_77
    :goto_77
    if-nez v1, :cond_7a

    return v9

    :cond_7a
    if-ne p1, v3, :cond_7d

    goto :goto_7e

    :cond_7d
    neg-int v1, v1

    :goto_7e
    const/4 v2, -0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroidx/core/widget/NestedScrollView;->t(IILandroid/view/MotionEvent;IIZ)I

    :goto_87
    const/4 v1, 0x1

    if-eqz v7, :cond_a9

    invoke-virtual {v7}, Landroid/view/View;->isFocused()Z

    move-result v2

    if-eqz v2, :cond_a9

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-virtual {p0, v7, v9, v2}, Landroidx/core/widget/NestedScrollView;->n(Landroid/view/View;II)Z

    move-result v2

    if-nez v2, :cond_a9

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getDescendantFocusability()I

    move-result v2

    const/high16 v3, 0x20000

    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->setDescendantFocusability(I)V

    invoke-virtual {p0}, Landroid/view/View;->requestFocus()Z

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->setDescendantFocusability(I)V

    :cond_a9
    return v1
.end method

.method public final c(Landroid/graphics/Rect;)I
    .registers 12

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    :cond_8
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v2

    add-int v3, v2, v0

    invoke-virtual {p0}, Landroid/view/View;->getVerticalFadingEdgeLength()I

    move-result v4

    iget v5, p1, Landroid/graphics/Rect;->top:I

    if-lez v5, :cond_1b

    add-int/2addr v2, v4

    :cond_1b
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroid/widget/FrameLayout$LayoutParams;

    iget v7, p1, Landroid/graphics/Rect;->bottom:I

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result v8

    iget v9, v6, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    add-int/2addr v8, v9

    iget v9, v6, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v8, v9

    if-ge v7, v8, :cond_36

    sub-int v4, v3, v4

    goto :goto_37

    :cond_36
    move v4, v3

    :goto_37
    iget v7, p1, Landroid/graphics/Rect;->bottom:I

    if-le v7, v4, :cond_59

    iget v8, p1, Landroid/graphics/Rect;->top:I

    if-le v8, v2, :cond_59

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result p0

    if-le p0, v0, :cond_49

    iget p0, p1, Landroid/graphics/Rect;->top:I

    sub-int/2addr p0, v2

    goto :goto_4c

    :cond_49
    iget p0, p1, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr p0, v4

    :goto_4c
    invoke-virtual {v5}, Landroid/view/View;->getBottom()I

    move-result p1

    iget v0, v6, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr p1, v0

    sub-int/2addr p1, v3

    invoke-static {p0, p1}, Ljava/lang/Math;->min(II)I

    move-result p0

    return p0

    :cond_59
    iget v3, p1, Landroid/graphics/Rect;->top:I

    if-ge v3, v2, :cond_78

    if-ge v7, v4, :cond_78

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result v3

    if-le v3, v0, :cond_6a

    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr v4, p1

    sub-int/2addr v1, v4

    goto :goto_6e

    :cond_6a
    iget p1, p1, Landroid/graphics/Rect;->top:I

    sub-int/2addr v2, p1

    sub-int/2addr v1, v2

    :goto_6e
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p0

    neg-int p0, p0

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0

    :cond_78
    return v1
.end method

.method public final computeHorizontalScrollExtent()I
    .registers 1

    invoke-super {p0}, Landroid/view/View;->computeHorizontalScrollExtent()I

    move-result p0

    return p0
.end method

.method public final computeHorizontalScrollOffset()I
    .registers 1

    invoke-super {p0}, Landroid/view/View;->computeHorizontalScrollOffset()I

    move-result p0

    return p0
.end method

.method public final computeHorizontalScrollRange()I
    .registers 1

    invoke-super {p0}, Landroid/view/View;->computeHorizontalScrollRange()I

    move-result p0

    return p0
.end method

.method public final computeScroll()V
    .registers 18

    move-object/from16 v0, p0

    iget-object v6, v0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    invoke-virtual {v6}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v1

    if-eqz v1, :cond_b

    return-void

    :cond_b
    invoke-virtual {v6}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    invoke-virtual {v6}, Landroid/widget/OverScroller;->getCurrY()I

    move-result v1

    iget v2, v0, Landroidx/core/widget/NestedScrollView;->d0:I

    sub-int v2, v1, v2

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v3

    iget-object v7, v0, Landroidx/core/widget/NestedScrollView;->I:Landroid/widget/EdgeEffect;

    iget-object v8, v0, Landroidx/core/widget/NestedScrollView;->J:Landroid/widget/EdgeEffect;

    const/high16 v4, 0x3f000000  # 0.5f

    const/4 v5, 0x0

    const/high16 v9, 0x40800000  # 4.0f

    if-lez v2, :cond_45

    invoke-static {v7}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v10

    cmpl-float v10, v10, v5

    if-eqz v10, :cond_45

    neg-int v5, v2

    int-to-float v5, v5

    mul-float/2addr v5, v9

    int-to-float v10, v3

    div-float/2addr v5, v10

    neg-int v3, v3

    int-to-float v3, v3

    div-float/2addr v3, v9

    invoke-static {v7, v5, v4}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    move-result v4

    mul-float/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v3

    if-eq v3, v2, :cond_43

    invoke-virtual {v7}, Landroid/widget/EdgeEffect;->finish()V

    :cond_43
    :goto_43
    sub-int/2addr v2, v3

    goto :goto_63

    :cond_45
    if-gez v2, :cond_63

    invoke-static {v8}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v10

    cmpl-float v5, v10, v5

    if-eqz v5, :cond_63

    int-to-float v5, v2

    mul-float/2addr v5, v9

    int-to-float v3, v3

    div-float/2addr v5, v3

    div-float/2addr v3, v9

    invoke-static {v8, v5, v4}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    move-result v4

    mul-float/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v3

    if-eq v3, v2, :cond_43

    invoke-virtual {v8}, Landroid/widget/EdgeEffect;->finish()V

    goto :goto_43

    :cond_63
    :goto_63
    iput v1, v0, Landroidx/core/widget/NestedScrollView;->d0:I

    iget-object v4, v0, Landroidx/core/widget/NestedScrollView;->b0:[I

    const/4 v9, 0x1

    const/4 v10, 0x0

    aput v10, v4, v9

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    invoke-virtual/range {v0 .. v5}, Landroidx/core/widget/NestedScrollView;->i(III[I[I)Z

    move-object/from16 v16, v4

    aget v1, v16, v9

    sub-int/2addr v2, v1

    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v1

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x23

    if-lt v3, v4, :cond_8b

    invoke-virtual {v6}, Landroid/widget/OverScroller;->getCurrVelocity()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    invoke-static {v0, v3}, Lqhc;->a(Landroidx/core/widget/NestedScrollView;F)V

    :cond_8b
    if-eqz v2, :cond_b3

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v3

    invoke-virtual {v0}, Landroid/view/View;->getScrollX()I

    move-result v4

    invoke-virtual {v0, v2, v4, v3, v1}, Landroidx/core/widget/NestedScrollView;->q(IIII)Z

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v4

    sub-int v11, v4, v3

    sub-int v13, v2, v11

    aput v10, v16, v9

    const/4 v12, 0x0

    move v2, v9

    iget-object v9, v0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    const/4 v10, 0x0

    iget-object v14, v0, Landroidx/core/widget/NestedScrollView;->a0:[I

    const/4 v15, 0x1

    move v3, v2

    invoke-virtual/range {v9 .. v16}, Lvu1;->b(IIII[II[I)Z

    aget v2, v16, v3

    sub-int v2, v13, v2

    goto :goto_b4

    :cond_b3
    move v3, v9

    :goto_b4
    if-eqz v2, :cond_e5

    invoke-virtual {v0}, Landroid/view/View;->getOverScrollMode()I

    move-result v4

    if-eqz v4, :cond_c0

    if-ne v4, v3, :cond_df

    if-lez v1, :cond_df

    :cond_c0
    if-gez v2, :cond_d1

    invoke-virtual {v7}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v1

    if-eqz v1, :cond_df

    invoke-virtual {v6}, Landroid/widget/OverScroller;->getCurrVelocity()F

    move-result v1

    float-to-int v1, v1

    invoke-virtual {v7, v1}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    goto :goto_df

    :cond_d1
    invoke-virtual {v8}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v1

    if-eqz v1, :cond_df

    invoke-virtual {v6}, Landroid/widget/OverScroller;->getCurrVelocity()F

    move-result v1

    float-to-int v1, v1

    invoke-virtual {v8, v1}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    :cond_df
    :goto_df
    invoke-virtual {v6}, Landroid/widget/OverScroller;->abortAnimation()V

    invoke-virtual {v0, v3}, Landroidx/core/widget/NestedScrollView;->y(I)V

    :cond_e5
    invoke-virtual {v6}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v1

    if-nez v1, :cond_ef

    invoke-virtual {v0}, Landroid/view/View;->postInvalidateOnAnimation()V

    return-void

    :cond_ef
    invoke-virtual {v0, v3}, Landroidx/core/widget/NestedScrollView;->y(I)V

    return-void
.end method

.method public final computeVerticalScrollExtent()I
    .registers 1

    invoke-super {p0}, Landroid/view/View;->computeVerticalScrollExtent()I

    move-result p0

    return p0
.end method

.method public final computeVerticalScrollOffset()I
    .registers 2

    const/4 v0, 0x0

    invoke-super {p0}, Landroid/view/View;->computeVerticalScrollOffset()I

    move-result p0

    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method public final computeVerticalScrollRange()I
    .registers 5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    sub-int/2addr v1, v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    sub-int/2addr v1, v2

    if-nez v0, :cond_15

    return v1

    :cond_15
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    move-result v2

    iget v3, v3, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v2, v3

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p0

    sub-int v1, v2, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    if-gez p0, :cond_35

    sub-int/2addr v2, p0

    return v2

    :cond_35
    if-le p0, v0, :cond_3a

    sub-int/2addr p0, v0

    add-int/2addr p0, v2

    return p0

    :cond_3a
    return v2
.end method

.method public final d(Landroid/view/View;Landroid/view/View;II)Z
    .registers 5

    and-int/lit8 p0, p3, 0x2

    if-eqz p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .registers 3

    invoke-super {p0, p1}, Landroid/view/View;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v0

    if-nez v0, :cond_f

    invoke-virtual {p0, p1}, Landroidx/core/widget/NestedScrollView;->j(Landroid/view/KeyEvent;)Z

    move-result p0

    if-eqz p0, :cond_d

    goto :goto_f

    :cond_d
    const/4 p0, 0x0

    return p0

    :cond_f
    :goto_f
    const/4 p0, 0x1

    return p0
.end method

.method public final dispatchNestedFling(FFZ)Z
    .registers 6

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    iget-boolean v0, p0, Lvu1;->a:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_2f

    invoke-virtual {p0, v1}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_2f

    iget-object p0, p0, Lvu1;->d:Ljava/lang/Object;

    check-cast p0, Landroidx/core/widget/NestedScrollView;

    :try_start_11
    invoke-interface {v0, p0, p1, p2, p3}, Landroid/view/ViewParent;->onNestedFling(Landroid/view/View;FFZ)Z

    move-result p0
    :try_end_15
    .catch Ljava/lang/AbstractMethodError; {:try_start_11 .. :try_end_15} :catch_16

    return p0

    :catch_16
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "ViewParent "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " does not implement interface method onNestedFling"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "ViewParentCompat"

    invoke-static {p2, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_2f
    return v1
.end method

.method public final dispatchNestedPreFling(FF)Z
    .registers 5

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    iget-boolean v0, p0, Lvu1;->a:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_2f

    invoke-virtual {p0, v1}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_2f

    iget-object p0, p0, Lvu1;->d:Ljava/lang/Object;

    check-cast p0, Landroidx/core/widget/NestedScrollView;

    :try_start_11
    invoke-interface {v0, p0, p1, p2}, Landroid/view/ViewParent;->onNestedPreFling(Landroid/view/View;FF)Z

    move-result p0
    :try_end_15
    .catch Ljava/lang/AbstractMethodError; {:try_start_11 .. :try_end_15} :catch_16

    return p0

    :catch_16
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "ViewParent "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " does not implement interface method onNestedPreFling"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "ViewParentCompat"

    invoke-static {p2, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_2f
    return v1
.end method

.method public final dispatchNestedPreScroll(II[I[I)Z
    .registers 11

    const/4 v3, 0x0

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v4, p3

    move-object v5, p4

    invoke-virtual/range {v0 .. v5}, Landroidx/core/widget/NestedScrollView;->i(III[I[I)Z

    move-result p0

    return p0
.end method

.method public final dispatchNestedScroll(IIII[I)Z
    .registers 14

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    invoke-virtual/range {v0 .. v7}, Lvu1;->b(IIII[II[I)Z

    move-result p0

    return p0
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .registers 12

    invoke-super {p0, p1}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v0

    iget-object v1, p0, Landroidx/core/widget/NestedScrollView;->I:Landroid/widget/EdgeEffect;

    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v2

    const/4 v3, 0x0

    if-nez v2, :cond_59

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v4

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v5

    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getClipToPadding()Z

    move-result v7

    if-eqz v7, :cond_44

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v8

    add-int/2addr v8, v7

    sub-int/2addr v4, v8

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v8

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v9

    add-int/2addr v9, v8

    sub-int/2addr v5, v9

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v8

    add-int/2addr v6, v8

    goto :goto_45

    :cond_44
    move v7, v3

    :goto_45
    int-to-float v7, v7

    int-to-float v6, v6

    invoke-virtual {p1, v7, v6}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {v1, v4, v5}, Landroid/widget/EdgeEffect;->setSize(II)V

    invoke-virtual {v1, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    move-result v1

    if-eqz v1, :cond_56

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_56
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_59
    iget-object v1, p0, Landroidx/core/widget/NestedScrollView;->J:Landroid/widget/EdgeEffect;

    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v2

    if-nez v2, :cond_bb

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v4

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v5

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v6

    invoke-static {v6, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    add-int/2addr v0, v5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getClipToPadding()Z

    move-result v6

    if-eqz v6, :cond_8a

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v6

    add-int/2addr v6, v3

    sub-int/2addr v4, v6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v3

    :cond_8a
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getClipToPadding()Z

    move-result v6

    if-eqz v6, :cond_9f

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v7

    add-int/2addr v7, v6

    sub-int/2addr v5, v7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v6

    sub-int/2addr v0, v6

    :cond_9f
    sub-int/2addr v3, v4

    int-to-float v3, v3

    int-to-float v0, v0

    invoke-virtual {p1, v3, v0}, Landroid/graphics/Canvas;->translate(FF)V

    int-to-float v0, v4

    const/4 v3, 0x0

    const/high16 v6, 0x43340000  # 180.0f

    invoke-virtual {p1, v6, v0, v3}, Landroid/graphics/Canvas;->rotate(FFF)V

    invoke-virtual {v1, v4, v5}, Landroid/widget/EdgeEffect;->setSize(II)V

    invoke-virtual {v1, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    move-result v0

    if-eqz v0, :cond_b8

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_b8
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_bb
    return-void
.end method

.method public final e(Landroid/view/View;Landroid/view/View;II)V
    .registers 5

    const/4 p1, 0x1

    iget-object p2, p0, Landroidx/core/widget/NestedScrollView;->f0:Llb2;

    if-ne p4, p1, :cond_8

    iput p3, p2, Llb2;->c:I

    goto :goto_a

    :cond_8
    iput p3, p2, Llb2;->b:I

    :goto_a
    const/4 p1, 0x2

    invoke-virtual {p0, p1, p4}, Landroidx/core/widget/NestedScrollView;->w(II)Z

    return-void
.end method

.method public final f(Landroid/view/View;I)V
    .registers 5

    const/4 p1, 0x1

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->f0:Llb2;

    const/4 v1, 0x0

    if-ne p2, p1, :cond_9

    iput v1, v0, Llb2;->c:I

    goto :goto_b

    :cond_9
    iput v1, v0, Llb2;->b:I

    :goto_b
    invoke-virtual {p0, p2}, Landroidx/core/widget/NestedScrollView;->y(I)V

    return-void
.end method

.method public final g(Landroidx/core/widget/NestedScrollView;IIIII[I)V
    .registers 8

    invoke-virtual {p0, p5, p6, p7}, Landroidx/core/widget/NestedScrollView;->o(II[I)V

    return-void
.end method

.method public getBottomFadingEdgeStrength()F
    .registers 6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-nez v0, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {p0}, Landroid/view/View;->getVerticalFadingEdgeLength()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v0

    iget v1, v1, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v1

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p0

    sub-int/2addr v0, p0

    sub-int/2addr v0, v3

    if-ge v0, v2, :cond_33

    int-to-float p0, v0

    int-to-float v0, v2

    div-float/2addr p0, v0

    return p0

    :cond_33
    const/high16 p0, 0x3f800000  # 1.0f

    return p0
.end method

.method public getMaxScrollAmount()I
    .registers 2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p0

    int-to-float p0, p0

    const/high16 v0, 0x3f000000  # 0.5f

    mul-float/2addr p0, v0

    float-to-int p0, p0

    return p0
.end method

.method public getNestedScrollAxes()I
    .registers 2

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->f0:Llb2;

    iget v0, p0, Llb2;->b:I

    iget p0, p0, Llb2;->c:I

    or-int/2addr p0, v0

    return p0
.end method

.method public getScrollRange()I
    .registers 5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_2f

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    iget v3, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    add-int/2addr v0, v3

    iget v2, v2, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    sub-int/2addr v2, v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result p0

    sub-int/2addr v2, p0

    sub-int/2addr v0, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0

    :cond_2f
    return v1
.end method

.method public getTopFadingEdgeStrength()F
    .registers 2

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-nez v0, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    invoke-virtual {p0}, Landroid/view/View;->getVerticalFadingEdgeLength()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p0

    if-ge p0, v0, :cond_16

    int-to-float p0, p0

    int-to-float v0, v0

    div-float/2addr p0, v0

    return p0

    :cond_16
    const/high16 p0, 0x3f800000  # 1.0f

    return p0
.end method

.method public getVerticalScrollFactorCompat()F
    .registers 7

    iget v0, p0, Landroidx/core/widget/NestedScrollView;->h0:F

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-nez v0, :cond_33

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const v4, 0x101004d

    const/4 v5, 0x1

    invoke-virtual {v3, v4, v0, v5}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result v3

    if-eqz v3, :cond_2d

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F

    move-result v0

    iput v0, p0, Landroidx/core/widget/NestedScrollView;->h0:F

    goto :goto_33

    :cond_2d
    const-string p0, "Expected theme to define listPreferredItemHeight."

    invoke-static {p0}, Le97;->j(Ljava/lang/String;)V

    return v1

    :cond_33
    :goto_33
    iget p0, p0, Landroidx/core/widget/NestedScrollView;->h0:F

    return p0
.end method

.method public final h(II[II)V
    .registers 11

    const/4 v5, 0x0

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v4, p3

    move v3, p4

    invoke-virtual/range {v0 .. v5}, Landroidx/core/widget/NestedScrollView;->i(III[I[I)Z

    return-void
.end method

.method public final hasNestedScrollingParent()Z
    .registers 2

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object p0

    if-eqz p0, :cond_b

    const/4 p0, 0x1

    return p0

    :cond_b
    return v0
.end method

.method public final i(III[I[I)Z
    .registers 13

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    iget-object v0, p0, Lvu1;->d:Ljava/lang/Object;

    check-cast v0, Landroidx/core/widget/NestedScrollView;

    iget-boolean v1, p0, Lvu1;->a:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_86

    invoke-virtual {p0, p3}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object v1

    if-nez v1, :cond_13

    goto/16 :goto_86

    :cond_13
    const/4 v3, 0x1

    if-nez p1, :cond_20

    if-eqz p2, :cond_19

    goto :goto_20

    :cond_19
    if-eqz p5, :cond_86

    aput v2, p5, v2

    aput v2, p5, v3

    return v2

    :cond_20
    :goto_20
    if-eqz p5, :cond_2a

    invoke-virtual {v0, p5}, Landroid/view/View;->getLocationInWindow([I)V

    aget v4, p5, v2

    aget v5, p5, v3

    goto :goto_2c

    :cond_2a
    move v4, v2

    move v5, v4

    :goto_2c
    if-nez p4, :cond_3d

    iget-object p4, p0, Lvu1;->e:Ljava/lang/Object;

    check-cast p4, [I

    if-nez p4, :cond_39

    const/4 p4, 0x2

    new-array p4, p4, [I

    iput-object p4, p0, Lvu1;->e:Ljava/lang/Object;

    :cond_39
    iget-object p4, p0, Lvu1;->e:Ljava/lang/Object;

    check-cast p4, [I

    :cond_3d
    aput v2, p4, v2

    aput v2, p4, v3

    iget-object p0, p0, Lvu1;->d:Ljava/lang/Object;

    check-cast p0, Landroidx/core/widget/NestedScrollView;

    instance-of v6, v1, Lthc;

    if-eqz v6, :cond_4f

    check-cast v1, Lthc;

    invoke-interface {v1, p1, p2, p4, p3}, Lthc;->h(II[II)V

    goto :goto_6e

    :cond_4f
    if-nez p3, :cond_6e

    :try_start_51
    invoke-interface {v1, p0, p1, p2, p4}, Landroid/view/ViewParent;->onNestedPreScroll(Landroid/view/View;II[I)V
    :try_end_54
    .catch Ljava/lang/AbstractMethodError; {:try_start_51 .. :try_end_54} :catch_55

    goto :goto_6e

    :catch_55
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "ViewParent "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " does not implement interface method onNestedPreScroll"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "ViewParentCompat"

    invoke-static {p2, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_6e
    :goto_6e
    if-eqz p5, :cond_7d

    invoke-virtual {v0, p5}, Landroid/view/View;->getLocationInWindow([I)V

    aget p0, p5, v2

    sub-int/2addr p0, v4

    aput p0, p5, v2

    aget p0, p5, v3

    sub-int/2addr p0, v5

    aput p0, p5, v3

    :cond_7d
    aget p0, p4, v2

    if-nez p0, :cond_85

    aget p0, p4, v3

    if-eqz p0, :cond_86

    :cond_85
    move v2, v3

    :cond_86
    :goto_86
    return v2
.end method

.method public final isNestedScrollingEnabled()Z
    .registers 1

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    iget-boolean p0, p0, Lvu1;->a:Z

    return p0
.end method

.method public final j(Landroid/view/KeyEvent;)Z
    .registers 7

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    invoke-virtual {v0}, Landroid/graphics/Rect;->setEmpty()V

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/16 v1, 0x82

    const/4 v2, 0x0

    if-lez v0, :cond_98

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    iget v4, v3, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    add-int/2addr v0, v4

    iget v3, v3, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v3

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    sub-int/2addr v3, v4

    if-le v0, v3, :cond_98

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_c0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v3, 0x13

    const/16 v4, 0x21

    if-eq v0, v3, :cond_88

    const/16 v3, 0x14

    if-eq v0, v3, :cond_78

    const/16 v3, 0x3e

    if-eq v0, v3, :cond_6d

    const/16 p1, 0x5c

    if-eq v0, p1, :cond_68

    const/16 p1, 0x5d

    if-eq v0, p1, :cond_63

    const/16 p1, 0x7a

    if-eq v0, p1, :cond_5f

    const/16 p1, 0x7b

    if-eq v0, p1, :cond_5b

    goto :goto_c0

    :cond_5b
    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->r(I)V

    return v2

    :cond_5f
    invoke-virtual {p0, v4}, Landroidx/core/widget/NestedScrollView;->r(I)V

    return v2

    :cond_63
    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->l(I)Z

    move-result p0

    return p0

    :cond_68
    invoke-virtual {p0, v4}, Landroidx/core/widget/NestedScrollView;->l(I)Z

    move-result p0

    return p0

    :cond_6d
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isShiftPressed()Z

    move-result p1

    if-eqz p1, :cond_74

    move v1, v4

    :cond_74
    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->r(I)V

    return v2

    :cond_78
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isAltPressed()Z

    move-result p1

    if-eqz p1, :cond_83

    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->l(I)Z

    move-result p0

    return p0

    :cond_83
    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->b(I)Z

    move-result p0

    return p0

    :cond_88
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isAltPressed()Z

    move-result p1

    if-eqz p1, :cond_93

    invoke-virtual {p0, v4}, Landroidx/core/widget/NestedScrollView;->l(I)Z

    move-result p0

    return p0

    :cond_93
    invoke-virtual {p0, v4}, Landroidx/core/widget/NestedScrollView;->b(I)Z

    move-result p0

    return p0

    :cond_98
    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    move-result v0

    if-eqz v0, :cond_c0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result p1

    const/4 v0, 0x4

    if-eq p1, v0, :cond_c0

    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object p1

    if-ne p1, p0, :cond_ac

    const/4 p1, 0x0

    :cond_ac
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    move-result-object v0

    invoke-virtual {v0, p0, p1, v1}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_c0

    if-eq p1, p0, :cond_c0

    invoke-virtual {p1, v1}, Landroid/view/View;->requestFocus(I)Z

    move-result p0

    if-eqz p0, :cond_c0

    const/4 p0, 0x1

    return p0

    :cond_c0
    :goto_c0
    return v2
.end method

.method public final k(I)V
    .registers 14

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lez v0, :cond_3f

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v3

    const/4 v10, 0x0

    const/4 v11, 0x0

    iget-object v1, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/high16 v8, -0x80000000

    const v9, 0x7fffffff

    move v5, p1

    invoke-virtual/range {v1 .. v11}, Landroid/widget/OverScroller;->fling(IIIIIIIIII)V

    const/4 p1, 0x1

    const/4 v0, 0x2

    invoke-virtual {p0, v0, p1}, Landroidx/core/widget/NestedScrollView;->w(II)Z

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p1

    iput p1, p0, Landroidx/core/widget/NestedScrollView;->d0:I

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x23

    if-lt p1, v0, :cond_3f

    iget-object p1, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    invoke-virtual {p1}, Landroid/widget/OverScroller;->getCurrVelocity()F

    move-result p1

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    invoke-static {p0, p1}, Lqhc;->a(Landroidx/core/widget/NestedScrollView;F)V

    :cond_3f
    return-void
.end method

.method public final l(I)Z
    .registers 7

    const/16 v0, 0x82

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne p1, v0, :cond_8

    move v0, v2

    goto :goto_9

    :cond_8
    move v0, v1

    :goto_9
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    iget-object v4, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    iput v1, v4, Landroid/graphics/Rect;->top:I

    iput v3, v4, Landroid/graphics/Rect;->bottom:I

    if-eqz v0, :cond_37

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lez v0, :cond_37

    sub-int/2addr v0, v2

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v0

    iget v1, v1, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v1

    add-int/2addr v1, v0

    iput v1, v4, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr v1, v3

    iput v1, v4, Landroid/graphics/Rect;->top:I

    :cond_37
    iget v0, v4, Landroid/graphics/Rect;->top:I

    iget v1, v4, Landroid/graphics/Rect;->bottom:I

    invoke-virtual {p0, p1, v0, v1}, Landroidx/core/widget/NestedScrollView;->s(III)Z

    move-result p0

    return p0
.end method

.method public final measureChild(Landroid/view/View;II)V
    .registers 5

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result p0

    add-int/2addr p0, v0

    iget p3, p3, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-static {p2, p0, p3}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result p0

    const/4 p2, 0x0

    invoke-static {p2, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    invoke-virtual {p1, p0, p2}, Landroid/view/View;->measure(II)V

    return-void
.end method

.method public final measureChildWithMargins(Landroid/view/View;IIII)V
    .registers 6

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p4

    check-cast p4, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result p5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result p0

    add-int/2addr p0, p5

    iget p5, p4, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr p0, p5

    iget p5, p4, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr p0, p5

    add-int/2addr p0, p3

    iget p3, p4, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {p2, p0, p3}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result p0

    iget p2, p4, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget p3, p4, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr p2, p3

    const/4 p3, 0x0

    invoke-static {p2, p3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    invoke-virtual {p1, p0, p2}, Landroid/view/View;->measure(II)V

    return-void
.end method

.method public final n(Landroid/view/View;II)Z
    .registers 6

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    invoke-virtual {p1, v0}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    invoke-virtual {p0, p1, v0}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    iget p1, v0, Landroid/graphics/Rect;->bottom:I

    add-int/2addr p1, p2

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v1

    if-lt p1, v1, :cond_1d

    iget p1, v0, Landroid/graphics/Rect;->top:I

    sub-int/2addr p1, p2

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p0

    add-int/2addr p0, p3

    if-gt p1, p0, :cond_1d

    const/4 p0, 0x1

    return p0

    :cond_1d
    const/4 p0, 0x0

    return p0
.end method

.method public final o(II[I)V
    .registers 14

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v0

    const/4 v1, 0x0

    invoke-virtual {p0, v1, p1}, Landroid/view/View;->scrollBy(II)V

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v1

    sub-int v4, v1, v0

    if-eqz p3, :cond_16

    const/4 v0, 0x1

    aget v1, p3, v0

    add-int/2addr v1, v4

    aput v1, p3, v0

    :cond_16
    sub-int v6, p1, v4

    const/4 v5, 0x0

    const/4 v7, 0x0

    iget-object v2, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    const/4 v3, 0x0

    move v8, p2

    move-object v9, p3

    invoke-virtual/range {v2 .. v9}, Lvu1;->b(IIII[II[I)Z

    return-void
.end method

.method public final onAttachedToWindow()V
    .registers 2

    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/core/widget/NestedScrollView;->N:Z

    return-void
.end method

.method public final onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 29

    move-object/from16 v0, p0

    move-object/from16 v3, p1

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getAction()I

    move-result v1

    const/16 v2, 0x8

    if-ne v1, v2, :cond_339

    iget-boolean v1, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    if-nez v1, :cond_339

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v1

    const/4 v8, 0x2

    and-int/2addr v1, v8

    const/high16 v9, 0x400000

    const/4 v10, 0x0

    const/16 v11, 0x1a

    if-ne v1, v8, :cond_2e

    const/16 v1, 0x9

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v2

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    float-to-int v4, v4

    move/from16 v26, v2

    move v2, v1

    move/from16 v1, v26

    goto :goto_45

    :cond_2e
    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v1

    and-int/2addr v1, v9

    if-ne v1, v9, :cond_42

    invoke-virtual {v3, v11}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v2

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    div-int/lit8 v4, v1, 0x2

    move v1, v2

    move v2, v11

    goto :goto_45

    :cond_42
    move v1, v10

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_45
    cmpl-float v5, v1, v10

    if-eqz v5, :cond_339

    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->getVerticalScrollFactorCompat()F

    move-result v5

    mul-float/2addr v5, v1

    float-to-int v1, v5

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v5

    const/16 v6, 0x2002

    and-int/2addr v5, v6

    if-ne v5, v6, :cond_5a

    const/4 v6, 0x1

    goto :goto_5b

    :cond_5a
    const/4 v6, 0x0

    :goto_5b
    neg-int v1, v1

    const/4 v5, 0x1

    invoke-virtual/range {v0 .. v6}, Landroidx/core/widget/NestedScrollView;->t(IILandroid/view/MotionEvent;IIZ)I

    if-eqz v2, :cond_30f

    iget-object v0, v0, Landroidx/core/widget/NestedScrollView;->i0:Lld6;

    iget-object v1, v0, Lld6;->b:Lkv6;

    iget-object v1, v1, Lkv6;->E:Ljava/lang/Object;

    check-cast v1, Landroidx/core/widget/NestedScrollView;

    iget-object v4, v0, Lld6;->h:[I

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v5

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v6

    iget v13, v0, Lld6;->f:I

    const/16 v14, 0x22

    if-ne v13, v5, :cond_8a

    iget v13, v0, Lld6;->g:I

    if-ne v13, v6, :cond_8a

    iget v13, v0, Lld6;->e:I

    if-eq v13, v2, :cond_83

    goto :goto_8a

    :cond_83
    const/4 v7, 0x0

    const/16 v16, 0x1

    const/16 v19, 0x0

    goto/16 :goto_133

    :cond_8a
    :goto_8a
    iget-object v13, v0, Lld6;->a:Landroid/content/Context;

    const/16 v16, 0x1

    invoke-static {v13}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v12

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v8

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v10

    const/16 v19, 0x0

    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const-string v15, "android"

    const-string v11, "dimen"

    const/4 v9, -0x1

    if-lt v7, v14, :cond_aa

    invoke-static {v12, v8, v2, v10}, Li5;->g(Landroid/view/ViewConfiguration;III)I

    move-result v8

    goto :goto_e0

    :cond_aa
    invoke-static {v8}, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;

    move-result-object v8

    if-eqz v8, :cond_dd

    invoke-virtual {v8, v2, v10}, Landroid/view/InputDevice;->getMotionRange(II)Landroid/view/InputDevice$MotionRange;

    move-result-object v8

    if-eqz v8, :cond_dd

    invoke-virtual {v13}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    const/high16 v14, 0x400000

    if-ne v10, v14, :cond_c9

    const/16 v10, 0x1a

    if-ne v2, v10, :cond_c9

    const-string v10, "config_viewMinRotaryEncoderFlingVelocity"

    invoke-virtual {v8, v10, v11, v15}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    goto :goto_ca

    :cond_c9
    move v10, v9

    :goto_ca
    invoke-static {v12}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    if-eq v10, v9, :cond_d8

    if-eqz v10, :cond_dd

    invoke-virtual {v8, v10}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v8

    if-gez v8, :cond_e0

    goto :goto_dd

    :cond_d8
    invoke-virtual {v12}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v8

    goto :goto_e0

    :cond_dd
    :goto_dd
    const v8, 0x7fffffff

    :cond_e0
    :goto_e0
    aput v8, v4, v19

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v8

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v10

    const/16 v14, 0x22

    if-lt v7, v14, :cond_f3

    invoke-static {v12, v8, v2, v10}, Li5;->f(Landroid/view/ViewConfiguration;III)I

    move-result v7

    goto :goto_129

    :cond_f3
    invoke-static {v8}, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;

    move-result-object v7

    const/high16 v8, -0x80000000

    if-eqz v7, :cond_128

    invoke-virtual {v7, v2, v10}, Landroid/view/InputDevice;->getMotionRange(II)Landroid/view/InputDevice$MotionRange;

    move-result-object v7

    if-eqz v7, :cond_128

    invoke-virtual {v13}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    const/high16 v14, 0x400000

    if-ne v10, v14, :cond_114

    const/16 v10, 0x1a

    if-ne v2, v10, :cond_114

    const-string v10, "config_viewMaxRotaryEncoderFlingVelocity"

    invoke-virtual {v7, v10, v11, v15}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    goto :goto_115

    :cond_114
    move v10, v9

    :goto_115
    invoke-static {v12}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    if-eq v10, v9, :cond_123

    if-eqz v10, :cond_128

    invoke-virtual {v7, v10}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v7

    if-gez v7, :cond_129

    goto :goto_128

    :cond_123
    invoke-virtual {v12}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    move-result v7

    goto :goto_129

    :cond_128
    :goto_128
    move v7, v8

    :cond_129
    :goto_129
    aput v7, v4, v16

    iput v5, v0, Lld6;->f:I

    iput v6, v0, Lld6;->g:I

    iput v2, v0, Lld6;->e:I

    move/from16 v7, v16

    :goto_133
    aget v5, v4, v19

    iget-object v6, v0, Lld6;->c:Landroid/view/VelocityTracker;

    const v8, 0x7fffffff

    if-ne v5, v8, :cond_145

    if-eqz v6, :cond_338

    invoke-virtual {v6}, Landroid/view/VelocityTracker;->recycle()V

    const/4 v1, 0x0

    iput-object v1, v0, Lld6;->c:Landroid/view/VelocityTracker;

    return v16

    :cond_145
    if-nez v6, :cond_14d

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v5

    iput-object v5, v0, Lld6;->c:Landroid/view/VelocityTracker;

    :cond_14d
    iget-object v5, v0, Lld6;->c:Landroid/view/VelocityTracker;

    sget-object v6, Lphj;->a:Ljava/util/Map;

    invoke-virtual {v5, v3}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x14

    const/16 v14, 0x22

    if-lt v6, v14, :cond_15d

    goto :goto_1b5

    :cond_15d
    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v6

    const/high16 v14, 0x400000

    if-ne v6, v14, :cond_1b5

    sget-object v6, Lphj;->a:Ljava/util/Map;

    invoke-interface {v6, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_175

    new-instance v9, Lqhj;

    invoke-direct {v9}, Lqhj;-><init>()V

    invoke-interface {v6, v5, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_175
    invoke-interface {v6, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lqhj;

    iget-object v9, v6, Lqhj;->b:[J

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v10

    iget v12, v6, Lqhj;->d:I

    if-eqz v12, :cond_198

    iget v12, v6, Lqhj;->e:I

    aget-wide v12, v9, v12

    sub-long v12, v10, v12

    const-wide/16 v14, 0x28

    cmp-long v12, v12, v14

    if-lez v12, :cond_198

    move/from16 v12, v19

    iput v12, v6, Lqhj;->d:I

    const/4 v12, 0x0

    iput v12, v6, Lqhj;->c:F

    :cond_198
    iget v12, v6, Lqhj;->e:I

    add-int/lit8 v12, v12, 0x1

    rem-int/2addr v12, v8

    iput v12, v6, Lqhj;->e:I

    iget v13, v6, Lqhj;->d:I

    if-eq v13, v8, :cond_1a7

    add-int/lit8 v13, v13, 0x1

    iput v13, v6, Lqhj;->d:I

    :cond_1a7
    iget-object v13, v6, Lqhj;->a:[F

    const/16 v14, 0x1a

    invoke-virtual {v3, v14}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v3

    aput v3, v13, v12

    iget v3, v6, Lqhj;->e:I

    aput-wide v10, v9, v3

    :cond_1b5
    :goto_1b5
    const/16 v3, 0x3e8

    const v6, 0x7f7fffff  # Float.MAX_VALUE

    invoke-virtual {v5, v3, v6}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    sget-object v3, Lphj;->a:Ljava/util/Map;

    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lqhj;

    if-eqz v3, :cond_2b2

    iget-object v9, v3, Lqhj;->a:[F

    iget-object v10, v3, Lqhj;->b:[J

    iget v11, v3, Lqhj;->d:I

    const/4 v12, 0x2

    if-ge v11, v12, :cond_1d7

    move/from16 p0, v6

    :goto_1d2
    move/from16 v23, v7

    const/4 v6, 0x0

    goto/16 :goto_28b

    :cond_1d7
    iget v12, v3, Lqhj;->e:I

    add-int/lit8 v13, v12, 0x14

    add-int/lit8 v11, v11, -0x1

    sub-int/2addr v13, v11

    rem-int/2addr v13, v8

    aget-wide v11, v10, v12

    :goto_1e1
    aget-wide v14, v10, v13

    sub-long v21, v11, v14

    const-wide/16 v23, 0x64

    cmp-long v20, v21, v23

    move/from16 p0, v6

    iget v6, v3, Lqhj;->d:I

    if-lez v20, :cond_1f9

    add-int/lit8 v6, v6, -0x1

    iput v6, v3, Lqhj;->d:I

    add-int/lit8 v13, v13, 0x1

    rem-int/2addr v13, v8

    move/from16 v6, p0

    goto :goto_1e1

    :cond_1f9
    move/from16 v20, v8

    const/4 v8, 0x2

    if-ge v6, v8, :cond_1ff

    :goto_1fe
    goto :goto_1d2

    :cond_1ff
    if-ne v6, v8, :cond_215

    add-int/lit8 v13, v13, 0x1

    rem-int/lit8 v13, v13, 0x14

    aget-wide v11, v10, v13

    cmp-long v6, v14, v11

    if-nez v6, :cond_20c

    goto :goto_1fe

    :cond_20c
    aget v6, v9, v13

    sub-long/2addr v11, v14

    long-to-float v8, v11

    div-float/2addr v6, v8

    move/from16 v23, v7

    goto/16 :goto_28b

    :cond_215
    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v11, 0x0

    :goto_218
    iget v12, v3, Lqhj;->d:I

    add-int/lit8 v12, v12, -0x1

    const/high16 v14, 0x40000000  # 2.0f

    const/high16 v15, 0x3f800000  # 1.0f

    const/high16 v17, -0x40800000  # -1.0f

    if-ge v8, v12, :cond_273

    add-int v12, v8, v13

    rem-int/lit8 v21, v12, 0x14

    aget-wide v21, v10, v21

    add-int/lit8 v12, v12, 0x1

    rem-int/lit8 v12, v12, 0x14

    aget-wide v23, v10, v12

    cmp-long v23, v23, v21

    if-nez v23, :cond_237

    move/from16 v23, v7

    goto :goto_26c

    :cond_237
    add-int/lit8 v11, v11, 0x1

    const/16 v18, 0x0

    cmpg-float v23, v6, v18

    if-gez v23, :cond_241

    move/from16 v15, v17

    :cond_241
    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v17

    mul-float v14, v14, v17

    move/from16 p1, v6

    move/from16 v23, v7

    float-to-double v6, v14

    invoke-static {v6, v7}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v6

    double-to-float v6, v6

    mul-float/2addr v15, v6

    aget v6, v9, v12

    aget-wide v24, v10, v12

    move v12, v6

    sub-long v6, v24, v21

    long-to-float v6, v6

    div-float v6, v12, v6

    sub-float v7, v6, v15

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v6

    mul-float/2addr v6, v7

    add-float v6, v6, p1

    move/from16 v7, v16

    if-ne v11, v7, :cond_26c

    const/high16 v7, 0x3f000000  # 0.5f

    mul-float/2addr v6, v7

    :cond_26c
    :goto_26c
    add-int/lit8 v8, v8, 0x1

    move/from16 v7, v23

    const/16 v16, 0x1

    goto :goto_218

    :cond_273
    move/from16 p1, v6

    move/from16 v23, v7

    const/16 v18, 0x0

    cmpg-float v6, p1, v18

    if-gez v6, :cond_27f

    move/from16 v15, v17

    :cond_27f
    invoke-static/range {p1 .. p1}, Ljava/lang/Math;->abs(F)F

    move-result v6

    mul-float/2addr v6, v14

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v6

    double-to-float v6, v6

    mul-float/2addr v6, v15

    :goto_28b
    const/high16 v7, 0x447a0000  # 1000.0f

    mul-float/2addr v6, v7

    iput v6, v3, Lqhj;->c:F

    invoke-static/range {p0 .. p0}, Ljava/lang/Math;->abs(F)F

    move-result v7

    neg-float v7, v7

    cmpg-float v6, v6, v7

    if-gez v6, :cond_2a1

    invoke-static/range {p0 .. p0}, Ljava/lang/Math;->abs(F)F

    move-result v6

    neg-float v6, v6

    iput v6, v3, Lqhj;->c:F

    goto :goto_2b4

    :cond_2a1
    iget v6, v3, Lqhj;->c:F

    invoke-static/range {p0 .. p0}, Ljava/lang/Math;->abs(F)F

    move-result v7

    cmpl-float v6, v6, v7

    if-lez v6, :cond_2b4

    invoke-static/range {p0 .. p0}, Ljava/lang/Math;->abs(F)F

    move-result v6

    iput v6, v3, Lqhj;->c:F

    goto :goto_2b4

    :cond_2b2
    move/from16 v23, v7

    :cond_2b4
    :goto_2b4
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v14, 0x22

    if-lt v3, v14, :cond_2bf

    invoke-static {v5, v2}, Li5;->e(Landroid/view/VelocityTracker;I)F

    move-result v2

    goto :goto_2e1

    :cond_2bf
    if-nez v2, :cond_2c6

    invoke-virtual {v5}, Landroid/view/VelocityTracker;->getXVelocity()F

    move-result v2

    goto :goto_2e1

    :cond_2c6
    const/4 v7, 0x1

    if-ne v2, v7, :cond_2ce

    invoke-virtual {v5}, Landroid/view/VelocityTracker;->getYVelocity()F

    move-result v2

    goto :goto_2e1

    :cond_2ce
    sget-object v3, Lphj;->a:Ljava/util/Map;

    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lqhj;

    if-eqz v3, :cond_2e0

    const/16 v10, 0x1a

    if-eq v2, v10, :cond_2dd

    goto :goto_2e0

    :cond_2dd
    iget v2, v3, Lqhj;->c:F

    goto :goto_2e1

    :cond_2e0
    :goto_2e0
    const/4 v2, 0x0

    :goto_2e1
    invoke-virtual {v1}, Landroidx/core/widget/NestedScrollView;->getVerticalScrollFactorCompat()F

    move-result v3

    neg-float v3, v3

    mul-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Math;->signum(F)F

    move-result v3

    if-nez v23, :cond_2fd

    iget v5, v0, Lld6;->d:F

    invoke-static {v5}, Ljava/lang/Math;->signum(F)F

    move-result v5

    cmpl-float v5, v3, v5

    if-eqz v5, :cond_302

    const/16 v18, 0x0

    cmpl-float v3, v3, v18

    if-eqz v3, :cond_302

    :cond_2fd
    iget-object v3, v1, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    invoke-virtual {v3}, Landroid/widget/OverScroller;->abortAnimation()V

    :cond_302
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v3

    const/16 v19, 0x0

    aget v5, v4, v19

    int-to-float v5, v5

    cmpg-float v3, v3, v5

    if-gez v3, :cond_312

    :cond_30f
    const/16 v16, 0x1

    goto :goto_338

    :cond_312
    const/16 v16, 0x1

    aget v3, v4, v16

    neg-int v4, v3

    int-to-float v4, v4

    int-to-float v3, v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v4, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    const/16 v18, 0x0

    cmpl-float v3, v2, v18

    if-nez v3, :cond_32a

    move/from16 v10, v18

    goto :goto_334

    :cond_32a
    iget-object v3, v1, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    invoke-virtual {v3}, Landroid/widget/OverScroller;->abortAnimation()V

    float-to-int v3, v2

    invoke-virtual {v1, v3}, Landroidx/core/widget/NestedScrollView;->k(I)V

    move v10, v2

    :goto_334
    iput v10, v0, Lld6;->d:F

    const/16 v16, 0x1

    :cond_338
    :goto_338
    return v16

    :cond_339
    const/16 v19, 0x0

    return v19
.end method

.method public final onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 14

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-ne v0, v2, :cond_d

    iget-boolean v3, p0, Landroidx/core/widget/NestedScrollView;->P:Z

    if-eqz v3, :cond_d

    return v1

    :cond_d
    and-int/lit16 v0, v0, 0xff

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_af

    const/4 v5, -0x1

    if-eq v0, v1, :cond_83

    if-eq v0, v2, :cond_25

    const/4 v1, 0x3

    if-eq v0, v1, :cond_83

    const/4 v1, 0x6

    if-eq v0, v1, :cond_20

    goto/16 :goto_12e

    :cond_20
    invoke-virtual {p0, p1}, Landroidx/core/widget/NestedScrollView;->p(Landroid/view/MotionEvent;)V

    goto/16 :goto_12e

    :cond_25
    iget v0, p0, Landroidx/core/widget/NestedScrollView;->W:I

    if-ne v0, v5, :cond_2b

    goto/16 :goto_12e

    :cond_2b
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    move-result v3

    if-ne v3, v5, :cond_4b

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "Invalid pointerId="

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " in onInterceptTouchEvent"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "NestedScrollView"

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_12e

    :cond_4b
    invoke-virtual {p1, v3}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    float-to-int v0, v0

    iget v3, p0, Landroidx/core/widget/NestedScrollView;->L:I

    sub-int v3, v0, v3

    invoke-static {v3}, Ljava/lang/Math;->abs(I)I

    move-result v3

    iget v5, p0, Landroidx/core/widget/NestedScrollView;->T:I

    if-le v3, v5, :cond_12e

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->getNestedScrollAxes()I

    move-result v3

    and-int/2addr v2, v3

    if-nez v2, :cond_12e

    iput-boolean v1, p0, Landroidx/core/widget/NestedScrollView;->P:Z

    iput v0, p0, Landroidx/core/widget/NestedScrollView;->L:I

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-nez v0, :cond_71

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v0

    iput-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    :cond_71
    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    iput v4, p0, Landroidx/core/widget/NestedScrollView;->c0:I

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    if-eqz p1, :cond_12e

    invoke-interface {p1, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    goto/16 :goto_12e

    :cond_83
    iput-boolean v4, p0, Landroidx/core/widget/NestedScrollView;->P:Z

    iput v5, p0, Landroidx/core/widget/NestedScrollView;->W:I

    iget-object p1, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz p1, :cond_90

    invoke-virtual {p1}, Landroid/view/VelocityTracker;->recycle()V

    iput-object v3, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    :cond_90
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result v6

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v7

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v11

    iget-object v5, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual/range {v5 .. v11}, Landroid/widget/OverScroller;->springBack(IIIIII)Z

    move-result p1

    if-eqz p1, :cond_aa

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_aa
    invoke-virtual {p0, v4}, Landroidx/core/widget/NestedScrollView;->y(I)V

    goto/16 :goto_12e

    :cond_af
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    float-to-int v0, v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    float-to-int v5, v5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v6

    iget-object v7, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    if-lez v6, :cond_115

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v6

    invoke-virtual {p0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/View;->getTop()I

    move-result v9

    sub-int/2addr v9, v6

    if-lt v0, v9, :cond_115

    invoke-virtual {v8}, Landroid/view/View;->getBottom()I

    move-result v9

    sub-int/2addr v9, v6

    if-ge v0, v9, :cond_115

    invoke-virtual {v8}, Landroid/view/View;->getLeft()I

    move-result v6

    if-lt v5, v6, :cond_115

    invoke-virtual {v8}, Landroid/view/View;->getRight()I

    move-result v6

    if-ge v5, v6, :cond_115

    iput v0, p0, Landroidx/core/widget/NestedScrollView;->L:I

    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    iput v0, p0, Landroidx/core/widget/NestedScrollView;->W:I

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-nez v0, :cond_f6

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v0

    iput-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    goto :goto_f9

    :cond_f6
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->clear()V

    :goto_f9
    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    invoke-virtual {v7}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    invoke-virtual {p0, p1}, Landroidx/core/widget/NestedScrollView;->x(Landroid/view/MotionEvent;)Z

    move-result p1

    if-nez p1, :cond_10f

    invoke-virtual {v7}, Landroid/widget/OverScroller;->isFinished()Z

    move-result p1

    if-nez p1, :cond_10e

    goto :goto_10f

    :cond_10e
    move v1, v4

    :cond_10f
    :goto_10f
    iput-boolean v1, p0, Landroidx/core/widget/NestedScrollView;->P:Z

    invoke-virtual {p0, v2, v4}, Landroidx/core/widget/NestedScrollView;->w(II)Z

    goto :goto_12e

    :cond_115
    invoke-virtual {p0, p1}, Landroidx/core/widget/NestedScrollView;->x(Landroid/view/MotionEvent;)Z

    move-result p1

    if-nez p1, :cond_123

    invoke-virtual {v7}, Landroid/widget/OverScroller;->isFinished()Z

    move-result p1

    if-nez p1, :cond_122

    goto :goto_123

    :cond_122
    move v1, v4

    :cond_123
    :goto_123
    iput-boolean v1, p0, Landroidx/core/widget/NestedScrollView;->P:Z

    iget-object p1, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz p1, :cond_12e

    invoke-virtual {p1}, Landroid/view/VelocityTracker;->recycle()V

    iput-object v3, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    :cond_12e
    :goto_12e
    iget-boolean p0, p0, Landroidx/core/widget/NestedScrollView;->P:Z

    return p0
.end method

.method public final onLayout(ZIIII)V
    .registers 7

    invoke-super/range {p0 .. p5}, Landroid/widget/FrameLayout;->onLayout(ZIIII)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/core/widget/NestedScrollView;->M:Z

    iget-object p2, p0, Landroidx/core/widget/NestedScrollView;->O:Landroid/view/View;

    if-eqz p2, :cond_23

    invoke-static {p2, p0}, Landroidx/core/widget/NestedScrollView;->m(Landroid/view/View;Landroidx/core/widget/NestedScrollView;)Z

    move-result p2

    if-eqz p2, :cond_23

    iget-object p2, p0, Landroidx/core/widget/NestedScrollView;->O:Landroid/view/View;

    iget-object p4, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    invoke-virtual {p2, p4}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    invoke-virtual {p0, p2, p4}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-virtual {p0, p4}, Landroidx/core/widget/NestedScrollView;->c(Landroid/graphics/Rect;)I

    move-result p2

    if-eqz p2, :cond_23

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->scrollBy(II)V

    :cond_23
    const/4 p2, 0x0

    iput-object p2, p0, Landroidx/core/widget/NestedScrollView;->O:Landroid/view/View;

    iget-boolean p4, p0, Landroidx/core/widget/NestedScrollView;->N:Z

    if-nez p4, :cond_7c

    iget-object p4, p0, Landroidx/core/widget/NestedScrollView;->e0:Lshc;

    if-eqz p4, :cond_3b

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result p4

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->e0:Lshc;

    iget v0, v0, Lshc;->E:I

    invoke-virtual {p0, p4, v0}, Landroidx/core/widget/NestedScrollView;->scrollTo(II)V

    iput-object p2, p0, Landroidx/core/widget/NestedScrollView;->e0:Lshc;

    :cond_3b
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p2

    if-lez p2, :cond_56

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p2

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p4

    check-cast p4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {p2}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    iget v0, p4, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    add-int/2addr p2, v0

    iget p4, p4, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr p2, p4

    goto :goto_57

    :cond_56
    move p2, p1

    :goto_57
    sub-int/2addr p5, p3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result p3

    sub-int/2addr p5, p3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result p3

    sub-int/2addr p5, p3

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p3

    if-ge p5, p2, :cond_73

    if-gez p3, :cond_6b

    goto :goto_73

    :cond_6b
    add-int p1, p5, p3

    if-le p1, p2, :cond_72

    sub-int p1, p2, p5

    goto :goto_73

    :cond_72
    move p1, p3

    :cond_73
    :goto_73
    if-eq p1, p3, :cond_7c

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result p2

    invoke-virtual {p0, p2, p1}, Landroidx/core/widget/NestedScrollView;->scrollTo(II)V

    :cond_7c
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p2

    invoke-virtual {p0, p1, p2}, Landroidx/core/widget/NestedScrollView;->scrollTo(II)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/core/widget/NestedScrollView;->N:Z

    return-void
.end method

.method public final onMeasure(II)V
    .registers 7

    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    iget-boolean v0, p0, Landroidx/core/widget/NestedScrollView;->R:Z

    if-nez v0, :cond_8

    goto :goto_58

    :cond_8
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p2

    if-nez p2, :cond_f

    goto :goto_58

    :cond_f
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p2

    if-lez p2, :cond_58

    const/4 p2, 0x0

    invoke-virtual {p0, p2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p2

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {p2}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    sub-int/2addr v2, v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    sub-int/2addr v2, v3

    iget v3, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    sub-int/2addr v2, v3

    iget v3, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    sub-int/2addr v2, v3

    if-ge v1, v2, :cond_58

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result p0

    add-int/2addr p0, v1

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    add-int/2addr p0, v1

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    add-int/2addr p0, v1

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    invoke-static {p1, p0, v0}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result p0

    const/high16 p1, 0x40000000  # 2.0f

    invoke-static {v2, p1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    invoke-virtual {p2, p0, p1}, Landroid/view/View;->measure(II)V

    :cond_58
    :goto_58
    return-void
.end method

.method public final onNestedFling(Landroid/view/View;FFZ)Z
    .registers 5

    if-nez p4, :cond_c

    const/4 p1, 0x0

    const/4 p2, 0x1

    invoke-virtual {p0, p1, p3, p2}, Landroidx/core/widget/NestedScrollView;->dispatchNestedFling(FFZ)Z

    float-to-int p1, p3

    invoke-virtual {p0, p1}, Landroidx/core/widget/NestedScrollView;->k(I)V

    return p2

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method public final onNestedPreFling(Landroid/view/View;FF)Z
    .registers 4

    invoke-virtual {p0, p2, p3}, Landroidx/core/widget/NestedScrollView;->dispatchNestedPreFling(FF)Z

    move-result p0

    return p0
.end method

.method public final onNestedPreScroll(Landroid/view/View;II[I)V
    .registers 11

    const/4 v3, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move v1, p2

    move v2, p3

    move-object v4, p4

    invoke-virtual/range {v0 .. v5}, Landroidx/core/widget/NestedScrollView;->i(III[I[I)Z

    return-void
.end method

.method public final onNestedScroll(Landroid/view/View;IIII)V
    .registers 6

    const/4 p1, 0x0

    const/4 p2, 0x0

    invoke-virtual {p0, p5, p1, p2}, Landroidx/core/widget/NestedScrollView;->o(II[I)V

    return-void
.end method

.method public final onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;I)V
    .registers 5

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/core/widget/NestedScrollView;->e(Landroid/view/View;Landroid/view/View;II)V

    return-void
.end method

.method public final onOverScrolled(IIZZ)V
    .registers 5

    invoke-super {p0, p1, p2}, Landroid/view/View;->scrollTo(II)V

    return-void
.end method

.method public final onRequestFocusInDescendants(ILandroid/graphics/Rect;)Z
    .registers 6

    const/4 v0, 0x2

    if-ne p1, v0, :cond_6

    const/16 p1, 0x82

    goto :goto_b

    :cond_6
    const/4 v0, 0x1

    if-ne p1, v0, :cond_b

    const/16 p1, 0x21

    :cond_b
    :goto_b
    if-nez p2, :cond_17

    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1, p1}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    move-result-object v0

    goto :goto_1f

    :cond_17
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    move-result-object v0

    invoke-virtual {v0, p0, p2, p1}, Landroid/view/FocusFinder;->findNextFocusFromRect(Landroid/view/ViewGroup;Landroid/graphics/Rect;I)Landroid/view/View;

    move-result-object v0

    :goto_1f
    const/4 v1, 0x0

    if-nez v0, :cond_23

    goto :goto_2d

    :cond_23
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Landroidx/core/widget/NestedScrollView;->n(Landroid/view/View;II)Z

    move-result p0

    if-nez p0, :cond_2e

    :goto_2d
    return v1

    :cond_2e
    invoke-virtual {v0, p1, p2}, Landroid/view/View;->requestFocus(ILandroid/graphics/Rect;)Z

    move-result p0

    return p0
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .registers 3

    instance-of v0, p1, Lshc;

    if-nez v0, :cond_8

    invoke-super {p0, p1}, Landroid/view/View;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    return-void

    :cond_8
    check-cast p1, Lshc;

    invoke-virtual {p1}, Landroid/view/AbsSavedState;->getSuperState()Landroid/os/Parcelable;

    move-result-object v0

    invoke-super {p0, v0}, Landroid/view/View;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    iput-object p1, p0, Landroidx/core/widget/NestedScrollView;->e0:Lshc;

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->requestLayout()V

    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .registers 3

    invoke-super {p0}, Landroid/view/View;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    new-instance v1, Lshc;

    invoke-direct {v1, v0}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p0

    iput p0, v1, Lshc;->E:I

    return-object v1
.end method

.method public final onScrollChanged(IIII)V
    .registers 5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onScrollChanged(IIII)V

    return-void
.end method

.method public final onSizeChanged(IIII)V
    .registers 5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_2c

    if-ne p0, p1, :cond_c

    goto :goto_2c

    :cond_c
    const/4 p2, 0x0

    invoke-virtual {p0, p1, p2, p4}, Landroidx/core/widget/NestedScrollView;->n(Landroid/view/View;II)Z

    move-result p3

    if-eqz p3, :cond_2c

    iget-object p3, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    invoke-virtual {p1, p3}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    invoke-virtual {p0, p1, p3}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-virtual {p0, p3}, Landroidx/core/widget/NestedScrollView;->c(Landroid/graphics/Rect;)I

    move-result p1

    if-eqz p1, :cond_2c

    iget-boolean p3, p0, Landroidx/core/widget/NestedScrollView;->S:Z

    if-eqz p3, :cond_29

    invoke-virtual {p0, p2, p1, p2}, Landroidx/core/widget/NestedScrollView;->v(IIZ)V

    return-void

    :cond_29
    invoke-virtual {p0, p2, p1}, Landroid/view/View;->scrollBy(II)V

    :cond_2c
    :goto_2c
    return-void
.end method

.method public final onStartNestedScroll(Landroid/view/View;Landroid/view/View;I)Z
    .registers 5

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/core/widget/NestedScrollView;->d(Landroid/view/View;Landroid/view/View;II)Z

    move-result p0

    return p0
.end method

.method public final onStopNestedScroll(Landroid/view/View;)V
    .registers 3

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/core/widget/NestedScrollView;->f(Landroid/view/View;I)V

    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v3, p1

    iget-object v1, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-nez v1, :cond_e

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v1

    iput-object v1, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    :cond_e
    invoke-virtual {v3}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_17

    iput v2, v0, Landroidx/core/widget/NestedScrollView;->c0:I

    :cond_17
    invoke-static {v3}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v7

    iget v4, v0, Landroidx/core/widget/NestedScrollView;->c0:I

    int-to-float v4, v4

    const/4 v5, 0x0

    invoke-virtual {v7, v5, v4}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    const/4 v4, 0x2

    const/4 v8, 0x1

    if-eqz v1, :cond_1e1

    const/4 v6, 0x0

    const/4 v9, -0x1

    iget-object v10, v0, Landroidx/core/widget/NestedScrollView;->I:Landroid/widget/EdgeEffect;

    iget-object v11, v0, Landroidx/core/widget/NestedScrollView;->J:Landroid/widget/EdgeEffect;

    if-eq v1, v8, :cond_158

    if-eq v1, v4, :cond_9e

    const/4 v4, 0x3

    if-eq v1, v4, :cond_60

    const/4 v2, 0x5

    if-eq v1, v2, :cond_4d

    const/4 v2, 0x6

    if-eq v1, v2, :cond_3b

    goto/16 :goto_213

    :cond_3b
    invoke-virtual/range {p0 .. p1}, Landroidx/core/widget/NestedScrollView;->p(Landroid/view/MotionEvent;)V

    iget v1, v0, Landroidx/core/widget/NestedScrollView;->W:I

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    move-result v1

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->getY(I)F

    move-result v1

    float-to-int v1, v1

    iput v1, v0, Landroidx/core/widget/NestedScrollView;->L:I

    goto/16 :goto_213

    :cond_4d
    invoke-virtual {v3}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v1

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->getY(I)F

    move-result v2

    float-to-int v2, v2

    iput v2, v0, Landroidx/core/widget/NestedScrollView;->L:I

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    iput v1, v0, Landroidx/core/widget/NestedScrollView;->W:I

    goto/16 :goto_213

    :cond_60
    iget-boolean v1, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    if-eqz v1, :cond_86

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-lez v1, :cond_86

    invoke-virtual {v0}, Landroid/view/View;->getScrollX()I

    move-result v13

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v14

    const/16 v17, 0x0

    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v18

    iget-object v12, v0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    const/4 v15, 0x0

    const/16 v16, 0x0

    invoke-virtual/range {v12 .. v18}, Landroid/widget/OverScroller;->springBack(IIIIII)Z

    move-result v1

    if-eqz v1, :cond_86

    invoke-virtual {v0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_86
    iput v9, v0, Landroidx/core/widget/NestedScrollView;->W:I

    iput-boolean v2, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    iget-object v1, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz v1, :cond_93

    invoke-virtual {v1}, Landroid/view/VelocityTracker;->recycle()V

    iput-object v6, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    :cond_93
    invoke-virtual {v0, v2}, Landroidx/core/widget/NestedScrollView;->y(I)V

    invoke-virtual {v10}, Landroid/widget/EdgeEffect;->onRelease()V

    invoke-virtual {v11}, Landroid/widget/EdgeEffect;->onRelease()V

    goto/16 :goto_213

    :cond_9e
    iget v1, v0, Landroidx/core/widget/NestedScrollView;->W:I

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    move-result v1

    if-ne v1, v9, :cond_c2

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid pointerId="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, v0, Landroidx/core/widget/NestedScrollView;->W:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " in onTouchEvent"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "NestedScrollView"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_213

    :cond_c2
    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->getY(I)F

    move-result v2

    float-to-int v9, v2

    iget v2, v0, Landroidx/core/widget/NestedScrollView;->L:I

    sub-int/2addr v2, v9

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->getX(I)F

    move-result v4

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v6

    int-to-float v6, v6

    div-float/2addr v4, v6

    int-to-float v6, v2

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v12

    int-to-float v12, v12

    div-float/2addr v6, v12

    invoke-static {v10}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v12

    cmpl-float v12, v12, v5

    if-eqz v12, :cond_f6

    neg-float v6, v6

    invoke-static {v10, v6, v4}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    move-result v4

    neg-float v4, v4

    invoke-static {v10}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v6

    cmpl-float v5, v6, v5

    if-nez v5, :cond_f4

    invoke-virtual {v10}, Landroid/widget/EdgeEffect;->onRelease()V

    :cond_f4
    :goto_f4
    move v5, v4

    goto :goto_111

    :cond_f6
    invoke-static {v11}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v10

    cmpl-float v10, v10, v5

    if-eqz v10, :cond_111

    const/high16 v10, 0x3f800000  # 1.0f

    sub-float/2addr v10, v4

    invoke-static {v11, v6, v10}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    move-result v4

    invoke-static {v11}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v6

    cmpl-float v5, v6, v5

    if-nez v5, :cond_f4

    invoke-virtual {v11}, Landroid/widget/EdgeEffect;->onRelease()V

    goto :goto_f4

    :cond_111
    :goto_111
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v5, v4

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v4

    if-eqz v4, :cond_120

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_120
    sub-int/2addr v2, v4

    iget-boolean v4, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    if-nez v4, :cond_13d

    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v4

    iget v5, v0, Landroidx/core/widget/NestedScrollView;->T:I

    if-le v4, v5, :cond_13d

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    if-eqz v4, :cond_136

    invoke-interface {v4, v8}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_136
    iput-boolean v8, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    if-lez v2, :cond_13c

    sub-int/2addr v2, v5

    goto :goto_13d

    :cond_13c
    add-int/2addr v2, v5

    :cond_13d
    :goto_13d
    iget-boolean v4, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    if-eqz v4, :cond_213

    invoke-virtual {v3, v1}, Landroid/view/MotionEvent;->getX(I)F

    move-result v1

    float-to-int v4, v1

    const/4 v5, 0x0

    const/4 v6, 0x0

    move v1, v2

    const/4 v2, 0x1

    invoke-virtual/range {v0 .. v6}, Landroidx/core/widget/NestedScrollView;->t(IILandroid/view/MotionEvent;IIZ)I

    move-result v1

    sub-int/2addr v9, v1

    iput v9, v0, Landroidx/core/widget/NestedScrollView;->L:I

    iget v2, v0, Landroidx/core/widget/NestedScrollView;->c0:I

    add-int/2addr v2, v1

    iput v2, v0, Landroidx/core/widget/NestedScrollView;->c0:I

    goto/16 :goto_213

    :cond_158
    iget-object v1, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    iget v3, v0, Landroidx/core/widget/NestedScrollView;->V:I

    int-to-float v3, v3

    const/16 v4, 0x3e8

    invoke-virtual {v1, v4, v3}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    iget v3, v0, Landroidx/core/widget/NestedScrollView;->W:I

    invoke-virtual {v1, v3}, Landroid/view/VelocityTracker;->getYVelocity(I)F

    move-result v1

    float-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Math;->abs(I)I

    move-result v3

    iget v4, v0, Landroidx/core/widget/NestedScrollView;->U:I

    if-lt v3, v4, :cond_1ae

    invoke-static {v10}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v3

    cmpl-float v3, v3, v5

    if-eqz v3, :cond_188

    invoke-virtual {v0, v10, v1}, Landroidx/core/widget/NestedScrollView;->u(Landroid/widget/EdgeEffect;I)Z

    move-result v3

    if-eqz v3, :cond_183

    invoke-virtual {v10, v1}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    goto :goto_1ca

    :cond_183
    neg-int v1, v1

    invoke-virtual {v0, v1}, Landroidx/core/widget/NestedScrollView;->k(I)V

    goto :goto_1ca

    :cond_188
    invoke-static {v11}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v3

    cmpl-float v3, v3, v5

    if-eqz v3, :cond_19f

    neg-int v1, v1

    invoke-virtual {v0, v11, v1}, Landroidx/core/widget/NestedScrollView;->u(Landroid/widget/EdgeEffect;I)Z

    move-result v3

    if-eqz v3, :cond_19b

    invoke-virtual {v11, v1}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    goto :goto_1ca

    :cond_19b
    invoke-virtual {v0, v1}, Landroidx/core/widget/NestedScrollView;->k(I)V

    goto :goto_1ca

    :cond_19f
    neg-int v1, v1

    int-to-float v3, v1

    invoke-virtual {v0, v5, v3}, Landroidx/core/widget/NestedScrollView;->dispatchNestedPreFling(FF)Z

    move-result v4

    if-nez v4, :cond_1ca

    invoke-virtual {v0, v5, v3, v8}, Landroidx/core/widget/NestedScrollView;->dispatchNestedFling(FFZ)Z

    invoke-virtual {v0, v1}, Landroidx/core/widget/NestedScrollView;->k(I)V

    goto :goto_1ca

    :cond_1ae
    invoke-virtual {v0}, Landroid/view/View;->getScrollX()I

    move-result v13

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v14

    const/16 v17, 0x0

    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v18

    iget-object v12, v0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    const/4 v15, 0x0

    const/16 v16, 0x0

    invoke-virtual/range {v12 .. v18}, Landroid/widget/OverScroller;->springBack(IIIIII)Z

    move-result v1

    if-eqz v1, :cond_1ca

    invoke-virtual {v0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_1ca
    :goto_1ca
    iput v9, v0, Landroidx/core/widget/NestedScrollView;->W:I

    iput-boolean v2, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    iget-object v1, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz v1, :cond_1d7

    invoke-virtual {v1}, Landroid/view/VelocityTracker;->recycle()V

    iput-object v6, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    :cond_1d7
    invoke-virtual {v0, v2}, Landroidx/core/widget/NestedScrollView;->y(I)V

    invoke-virtual {v10}, Landroid/widget/EdgeEffect;->onRelease()V

    invoke-virtual {v11}, Landroid/widget/EdgeEffect;->onRelease()V

    goto :goto_213

    :cond_1e1
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-nez v1, :cond_1e8

    return v2

    :cond_1e8
    iget-boolean v1, v0, Landroidx/core/widget/NestedScrollView;->P:Z

    if-eqz v1, :cond_1f5

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    if-eqz v1, :cond_1f5

    invoke-interface {v1, v8}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_1f5
    iget-object v1, v0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    invoke-virtual {v1}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v5

    if-nez v5, :cond_203

    invoke-virtual {v1}, Landroid/widget/OverScroller;->abortAnimation()V

    invoke-virtual {v0, v8}, Landroidx/core/widget/NestedScrollView;->y(I)V

    :cond_203
    invoke-virtual {v3}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    float-to-int v1, v1

    invoke-virtual {v3, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v3

    iput v1, v0, Landroidx/core/widget/NestedScrollView;->L:I

    iput v3, v0, Landroidx/core/widget/NestedScrollView;->W:I

    invoke-virtual {v0, v4, v2}, Landroidx/core/widget/NestedScrollView;->w(II)Z

    :cond_213
    :goto_213
    iget-object v0, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_21a

    invoke-virtual {v0, v7}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    :cond_21a
    invoke-virtual {v7}, Landroid/view/MotionEvent;->recycle()V

    return v8
.end method

.method public final p(Landroid/view/MotionEvent;)V
    .registers 5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    iget v2, p0, Landroidx/core/widget/NestedScrollView;->W:I

    if-ne v1, v2, :cond_25

    if-nez v0, :cond_10

    const/4 v0, 0x1

    goto :goto_11

    :cond_10
    const/4 v0, 0x0

    :goto_11
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v1

    float-to-int v1, v1

    iput v1, p0, Landroidx/core/widget/NestedScrollView;->L:I

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result p1

    iput p1, p0, Landroidx/core/widget/NestedScrollView;->W:I

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz p0, :cond_25

    invoke-virtual {p0}, Landroid/view/VelocityTracker;->clear()V

    :cond_25
    return-void
.end method

.method public final q(IIII)Z
    .registers 14

    invoke-virtual {p0}, Landroid/view/View;->getOverScrollMode()I

    move-result v0

    invoke-super {p0}, Landroid/view/View;->computeHorizontalScrollRange()I

    invoke-super {p0}, Landroid/view/View;->computeHorizontalScrollExtent()I

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->computeVerticalScrollRange()I

    invoke-super {p0}, Landroid/view/View;->computeVerticalScrollExtent()I

    const/4 v1, 0x1

    add-int/2addr p3, p1

    const/4 p1, 0x0

    if-lez p2, :cond_18

    :goto_15
    move v3, p1

    move p2, v1

    goto :goto_1d

    :cond_18
    if-gez p2, :cond_1b

    goto :goto_15

    :cond_1b
    move v3, p2

    move p2, p1

    :goto_1d
    if-le p3, p4, :cond_22

    move v4, p4

    :goto_20
    move p3, v1

    goto :goto_28

    :cond_22
    if-gez p3, :cond_26

    move v4, p1

    goto :goto_20

    :cond_26
    move v4, p3

    move p3, p1

    :goto_28
    if-eqz p3, :cond_3f

    iget-object p4, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    invoke-virtual {p4, v1}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object p4

    if-eqz p4, :cond_33

    goto :goto_3f

    :cond_33
    const/4 v7, 0x0

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v8

    iget-object v2, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v2 .. v8}, Landroid/widget/OverScroller;->springBack(IIIIII)Z

    :cond_3f
    :goto_3f
    invoke-super {p0, v3, v4}, Landroid/view/View;->scrollTo(II)V

    if-nez p2, :cond_48

    if-eqz p3, :cond_47

    goto :goto_48

    :cond_47
    return p1

    :cond_48
    :goto_48
    return v1
.end method

.method public final r(I)V
    .registers 7

    const/16 v0, 0x82

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne p1, v0, :cond_8

    move v0, v2

    goto :goto_9

    :cond_8
    move v0, v1

    :goto_9
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    iget-object v4, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    if-eqz v0, :cond_3e

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v0

    add-int/2addr v0, v3

    iput v0, v4, Landroid/graphics/Rect;->top:I

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lez v0, :cond_49

    sub-int/2addr v0, v2

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v0

    iget v1, v1, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v1

    add-int/2addr v1, v0

    iget v0, v4, Landroid/graphics/Rect;->top:I

    add-int/2addr v0, v3

    if-le v0, v1, :cond_49

    sub-int/2addr v1, v3

    iput v1, v4, Landroid/graphics/Rect;->top:I

    goto :goto_49

    :cond_3e
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v0

    sub-int/2addr v0, v3

    iput v0, v4, Landroid/graphics/Rect;->top:I

    if-gez v0, :cond_49

    iput v1, v4, Landroid/graphics/Rect;->top:I

    :cond_49
    :goto_49
    iget v0, v4, Landroid/graphics/Rect;->top:I

    add-int/2addr v3, v0

    iput v3, v4, Landroid/graphics/Rect;->bottom:I

    invoke-virtual {p0, p1, v0, v3}, Landroidx/core/widget/NestedScrollView;->s(III)Z

    return-void
.end method

.method public final requestChildFocus(Landroid/view/View;Landroid/view/View;)V
    .registers 5

    iget-boolean v0, p0, Landroidx/core/widget/NestedScrollView;->M:Z

    if-nez v0, :cond_17

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->G:Landroid/graphics/Rect;

    invoke-virtual {p2, v0}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    invoke-virtual {p0, p2, v0}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-virtual {p0, v0}, Landroidx/core/widget/NestedScrollView;->c(Landroid/graphics/Rect;)I

    move-result v0

    if-eqz v0, :cond_19

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Landroid/view/View;->scrollBy(II)V

    goto :goto_19

    :cond_17
    iput-object p2, p0, Landroidx/core/widget/NestedScrollView;->O:Landroid/view/View;

    :cond_19
    :goto_19
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->requestChildFocus(Landroid/view/View;Landroid/view/View;)V

    return-void
.end method

.method public final requestChildRectangleOnScreen(Landroid/view/View;Landroid/graphics/Rect;Z)Z
    .registers 6

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getScrollX()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v1

    invoke-virtual {p1}, Landroid/view/View;->getScrollY()I

    move-result p1

    sub-int/2addr v1, p1

    invoke-virtual {p2, v0, v1}, Landroid/graphics/Rect;->offset(II)V

    invoke-virtual {p0, p2}, Landroidx/core/widget/NestedScrollView;->c(Landroid/graphics/Rect;)I

    move-result p1

    const/4 p2, 0x0

    if-eqz p1, :cond_1e

    const/4 v0, 0x1

    goto :goto_1f

    :cond_1e
    move v0, p2

    :goto_1f
    if-eqz v0, :cond_2a

    if-eqz p3, :cond_27

    invoke-virtual {p0, p2, p1}, Landroid/view/View;->scrollBy(II)V

    return v0

    :cond_27
    invoke-virtual {p0, p2, p1, p2}, Landroidx/core/widget/NestedScrollView;->v(IIZ)V

    :cond_2a
    return v0
.end method

.method public final requestDisallowInterceptTouchEvent(Z)V
    .registers 3

    if-eqz p1, :cond_c

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_c

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    :cond_c
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->requestDisallowInterceptTouchEvent(Z)V

    return-void
.end method

.method public final requestLayout()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/core/widget/NestedScrollView;->M:Z

    invoke-super {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public final s(III)Z
    .registers 22

    move/from16 v0, p1

    move/from16 v1, p2

    move/from16 v2, p3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getScrollY()I

    move-result v4

    add-int/2addr v3, v4

    const/16 v5, 0x21

    if-ne v0, v5, :cond_15

    const/4 v5, 0x1

    goto :goto_16

    :cond_15
    const/4 v5, 0x0

    :goto_16
    const/4 v8, 0x2

    move-object/from16 v9, p0

    invoke-virtual {v9, v8}, Landroid/view/View;->getFocusables(I)Ljava/util/ArrayList;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v10

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    :goto_24
    if-ge v12, v10, :cond_6c

    invoke-interface {v8, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroid/view/View;

    invoke-virtual {v14}, Landroid/view/View;->getTop()I

    move-result v15

    invoke-virtual {v14}, Landroid/view/View;->getBottom()I

    move-result v6

    if-ge v1, v6, :cond_69

    if-ge v15, v2, :cond_69

    if-ge v1, v15, :cond_3f

    if-ge v6, v2, :cond_3f

    const/16 v17, 0x1

    goto :goto_41

    :cond_3f
    const/16 v17, 0x0

    :goto_41
    if-nez v11, :cond_47

    move-object v11, v14

    move/from16 v13, v17

    goto :goto_69

    :cond_47
    if-eqz v5, :cond_4f

    invoke-virtual {v11}, Landroid/view/View;->getTop()I

    move-result v7

    if-lt v15, v7, :cond_57

    :cond_4f
    if-nez v5, :cond_59

    invoke-virtual {v11}, Landroid/view/View;->getBottom()I

    move-result v7

    if-le v6, v7, :cond_59

    :cond_57
    const/4 v6, 0x1

    goto :goto_5a

    :cond_59
    const/4 v6, 0x0

    :goto_5a
    if-eqz v13, :cond_61

    if-eqz v17, :cond_69

    if-eqz v6, :cond_69

    goto :goto_68

    :cond_61
    if-eqz v17, :cond_66

    move-object v11, v14

    const/4 v13, 0x1

    goto :goto_69

    :cond_66
    if-eqz v6, :cond_69

    :goto_68
    move-object v11, v14

    :cond_69
    :goto_69
    add-int/lit8 v12, v12, 0x1

    goto :goto_24

    :cond_6c
    if-nez v11, :cond_70

    move-object v6, v9

    goto :goto_71

    :cond_70
    move-object v6, v11

    :goto_71
    if-lt v1, v4, :cond_78

    if-gt v2, v3, :cond_78

    const/16 v16, 0x0

    goto :goto_8a

    :cond_78
    if-eqz v5, :cond_7d

    sub-int/2addr v1, v4

    :goto_7b
    move v10, v1

    goto :goto_80

    :cond_7d
    sub-int v1, v2, v3

    goto :goto_7b

    :goto_80
    const/4 v11, -0x1

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x1

    const/4 v15, 0x1

    invoke-virtual/range {v9 .. v15}, Landroidx/core/widget/NestedScrollView;->t(IILandroid/view/MotionEvent;IIZ)I

    const/16 v16, 0x1

    :goto_8a
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v1

    if-eq v6, v1, :cond_93

    invoke-virtual {v6, v0}, Landroid/view/View;->requestFocus(I)Z

    :cond_93
    return v16
.end method

.method public final scrollTo(II)V
    .registers 10

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lez v0, :cond_6a

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v4

    iget v5, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    add-int/2addr v4, v5

    iget v5, v2, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    add-int/2addr v4, v5

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v6

    sub-int/2addr v5, v6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v6

    sub-int/2addr v5, v6

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    iget v6, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    add-int/2addr v1, v6

    iget v2, v2, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v1, v2

    if-ge v3, v4, :cond_4d

    if-gez p1, :cond_46

    goto :goto_4d

    :cond_46
    add-int v2, v3, p1

    if-le v2, v4, :cond_4e

    sub-int p1, v4, v3

    goto :goto_4e

    :cond_4d
    :goto_4d
    move p1, v0

    :cond_4e
    :goto_4e
    if-ge v5, v1, :cond_5a

    if-gez p2, :cond_53

    goto :goto_5a

    :cond_53
    add-int v0, v5, p2

    if-le v0, v1, :cond_5b

    sub-int p2, v1, v5

    goto :goto_5b

    :cond_5a
    :goto_5a
    move p2, v0

    :cond_5b
    :goto_5b
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result v0

    if-ne p1, v0, :cond_67

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v0

    if-eq p2, v0, :cond_6a

    :cond_67
    invoke-super {p0, p1, p2}, Landroid/view/View;->scrollTo(II)V

    :cond_6a
    return-void
.end method

.method public setFillViewport(Z)V
    .registers 3

    iget-boolean v0, p0, Landroidx/core/widget/NestedScrollView;->R:Z

    if-eq p1, v0, :cond_9

    iput-boolean p1, p0, Landroidx/core/widget/NestedScrollView;->R:Z

    invoke-virtual {p0}, Landroidx/core/widget/NestedScrollView;->requestLayout()V

    :cond_9
    return-void
.end method

.method public setNestedScrollingEnabled(Z)V
    .registers 4

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    iget-boolean v0, p0, Lvu1;->a:Z

    if-eqz v0, :cond_f

    iget-object v0, p0, Lvu1;->d:Ljava/lang/Object;

    check-cast v0, Landroidx/core/widget/NestedScrollView;

    sget-object v1, Lgkj;->a:Ljava/util/WeakHashMap;

    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->stopNestedScroll()V

    :cond_f
    iput-boolean p1, p0, Lvu1;->a:Z

    return-void
.end method

.method public setOnScrollChangeListener(Lrhc;)V
    .registers 2

    return-void
.end method

.method public setSmoothScrollingEnabled(Z)V
    .registers 2

    iput-boolean p1, p0, Landroidx/core/widget/NestedScrollView;->S:Z

    return-void
.end method

.method public final shouldDelayChildPressedState()Z
    .registers 1

    const/4 p0, 0x1

    return p0
.end method

.method public final startNestedScroll(I)Z
    .registers 3

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/core/widget/NestedScrollView;->w(II)Z

    move-result p0

    return p0
.end method

.method public final stopNestedScroll()V
    .registers 2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/core/widget/NestedScrollView;->y(I)V

    return-void
.end method

.method public final t(IILandroid/view/MotionEvent;IIZ)I
    .registers 27

    move-object/from16 v0, p0

    move/from16 v6, p2

    move/from16 v7, p4

    move/from16 v14, p5

    const/4 v8, 0x1

    if-ne v14, v8, :cond_f

    const/4 v1, 0x2

    invoke-virtual {v0, v1, v14}, Landroidx/core/widget/NestedScrollView;->w(II)Z

    :cond_f
    iget-object v4, v0, Landroidx/core/widget/NestedScrollView;->b0:[I

    iget-object v5, v0, Landroidx/core/widget/NestedScrollView;->a0:[I

    const/4 v1, 0x0

    move/from16 v2, p1

    move v3, v14

    invoke-virtual/range {v0 .. v5}, Landroidx/core/widget/NestedScrollView;->i(III[I[I)Z

    move-result v1

    iget-object v2, v0, Landroidx/core/widget/NestedScrollView;->a0:[I

    iget-object v15, v0, Landroidx/core/widget/NestedScrollView;->b0:[I

    const/4 v3, 0x0

    if-eqz v1, :cond_29

    aget v1, v15, v8

    sub-int v1, p1, v1

    aget v4, v2, v8

    goto :goto_2c

    :cond_29
    move/from16 v1, p1

    move v4, v3

    :goto_2c
    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v5

    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v9

    invoke-virtual {v0}, Landroid/view/View;->getOverScrollMode()I

    move-result v10

    if-eqz v10, :cond_42

    if-ne v10, v8, :cond_47

    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->getScrollRange()I

    move-result v10

    if-lez v10, :cond_47

    :cond_42
    if-nez p6, :cond_47

    move/from16 v16, v8

    goto :goto_49

    :cond_47
    move/from16 v16, v3

    :goto_49
    invoke-virtual {v0, v1, v3, v5, v9}, Landroidx/core/widget/NestedScrollView;->q(IIII)Z

    move-result v10

    if-eqz v10, :cond_5b

    iget-object v10, v0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    invoke-virtual {v10, v14}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object v10

    if-eqz v10, :cond_58

    goto :goto_5b

    :cond_58
    move/from16 v17, v8

    goto :goto_5d

    :cond_5b
    :goto_5b
    move/from16 v17, v3

    :goto_5d
    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v10

    sub-int/2addr v10, v5

    if-eqz p3, :cond_77

    if-eqz v10, :cond_77

    invoke-direct {v0}, Landroidx/core/widget/NestedScrollView;->getScrollFeedbackProvider()Lxzf;

    move-result-object v11

    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v12

    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getSource()I

    move-result v13

    iget-object v11, v11, Lxzf;->a:Lwzf;

    invoke-interface {v11, v12, v13, v6, v10}, Lwzf;->onScrollProgress(IIII)V

    :cond_77
    sub-int v12, v1, v10

    aput v3, v15, v8

    const/4 v11, 0x0

    move v13, v8

    iget-object v8, v0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    move/from16 v18, v9

    const/4 v9, 0x0

    move/from16 v19, v13

    iget-object v13, v0, Landroidx/core/widget/NestedScrollView;->a0:[I

    move/from16 v3, v18

    move/from16 v18, v1

    move/from16 v1, v19

    invoke-virtual/range {v8 .. v15}, Lvu1;->b(IIII[II[I)Z

    aget v2, v2, v1

    add-int/2addr v4, v2

    aget v2, v15, v1

    sub-int v2, v18, v2

    add-int/2addr v5, v2

    iget-object v8, v0, Landroidx/core/widget/NestedScrollView;->J:Landroid/widget/EdgeEffect;

    iget-object v9, v0, Landroidx/core/widget/NestedScrollView;->I:Landroid/widget/EdgeEffect;

    if-gez v5, :cond_cf

    if-eqz v16, :cond_cd

    neg-int v2, v2

    int-to-float v2, v2

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v2, v3

    int-to-float v3, v7

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v5

    int-to-float v5, v5

    div-float/2addr v3, v5

    invoke-static {v9, v2, v3}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    if-eqz p3, :cond_c4

    invoke-direct {v0}, Landroidx/core/widget/NestedScrollView;->getScrollFeedbackProvider()Lxzf;

    move-result-object v2

    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v3

    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getSource()I

    move-result v5

    iget-object v2, v2, Lxzf;->a:Lwzf;

    invoke-interface {v2, v1, v3, v5, v6}, Lwzf;->j(ZIII)V

    :cond_c4
    invoke-virtual {v8}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v2

    if-nez v2, :cond_cd

    invoke-virtual {v8}, Landroid/widget/EdgeEffect;->onRelease()V

    :cond_cd
    const/4 v7, 0x0

    goto :goto_106

    :cond_cf
    if-le v5, v3, :cond_cd

    if-eqz v16, :cond_cd

    int-to-float v2, v2

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v2, v3

    int-to-float v3, v7

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v5

    int-to-float v5, v5

    div-float/2addr v3, v5

    const/high16 v5, 0x3f800000  # 1.0f

    sub-float/2addr v5, v3

    invoke-static {v8, v2, v5}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    if-eqz p3, :cond_fc

    invoke-direct {v0}, Landroidx/core/widget/NestedScrollView;->getScrollFeedbackProvider()Lxzf;

    move-result-object v2

    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getDeviceId()I

    move-result v3

    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getSource()I

    move-result v5

    iget-object v2, v2, Lxzf;->a:Lwzf;

    const/4 v7, 0x0

    invoke-interface {v2, v7, v3, v5, v6}, Lwzf;->j(ZIII)V

    goto :goto_fd

    :cond_fc
    const/4 v7, 0x0

    :goto_fd
    invoke-virtual {v9}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v2

    if-nez v2, :cond_106

    invoke-virtual {v9}, Landroid/widget/EdgeEffect;->onRelease()V

    :cond_106
    :goto_106
    invoke-virtual {v9}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v2

    if-eqz v2, :cond_116

    invoke-virtual {v8}, Landroid/widget/EdgeEffect;->isFinished()Z

    move-result v2

    if-nez v2, :cond_113

    goto :goto_116

    :cond_113
    move/from16 v3, v17

    goto :goto_11a

    :cond_116
    :goto_116
    invoke-virtual {v0}, Landroid/view/View;->postInvalidateOnAnimation()V

    move v3, v7

    :goto_11a
    if-eqz v3, :cond_125

    if-nez v14, :cond_125

    iget-object v2, v0, Landroidx/core/widget/NestedScrollView;->Q:Landroid/view/VelocityTracker;

    if-eqz v2, :cond_125

    invoke-virtual {v2}, Landroid/view/VelocityTracker;->clear()V

    :cond_125
    if-ne v14, v1, :cond_130

    invoke-virtual {v0, v14}, Landroidx/core/widget/NestedScrollView;->y(I)V

    invoke-virtual {v9}, Landroid/widget/EdgeEffect;->onRelease()V

    invoke-virtual {v8}, Landroid/widget/EdgeEffect;->onRelease()V

    :cond_130
    return v4
.end method

.method public final u(Landroid/widget/EdgeEffect;I)Z
    .registers 12

    const/4 v0, 0x1

    if-lez p2, :cond_4

    return v0

    :cond_4
    invoke-static {p1}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    mul-float/2addr p1, v1

    neg-int p2, p2

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p2

    int-to-float p2, p2

    const v1, 0x3eb33333  # 0.35f

    mul-float/2addr p2, v1

    const v1, 0x3c75c28f  # 0.015f

    iget p0, p0, Landroidx/core/widget/NestedScrollView;->E:F

    mul-float/2addr p0, v1

    div-float/2addr p2, p0

    float-to-double v1, p2

    invoke-static {v1, v2}, Ljava/lang/Math;->log(D)D

    move-result-wide v1

    sget p2, Landroidx/core/widget/NestedScrollView;->j0:F

    float-to-double v3, p2

    const-wide/high16 v5, 0x3ff0000000000000L  # 1.0

    sub-double v5, v3, v5

    float-to-double v7, p0

    div-double/2addr v3, v5

    mul-double/2addr v3, v1

    invoke-static {v3, v4}, Ljava/lang/Math;->exp(D)D

    move-result-wide v1

    mul-double/2addr v1, v7

    double-to-float p0, v1

    cmpg-float p0, p0, p1

    if-gez p0, :cond_39

    return v0

    :cond_39
    const/4 p0, 0x0

    return p0
.end method

.method public final v(IIZ)V
    .registers 13

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Landroidx/core/widget/NestedScrollView;->F:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0xfa

    cmp-long v0, v0, v2

    const/4 v1, 0x1

    if-lez v0, :cond_6c

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    iget v3, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    add-int/2addr v0, v3

    iget v2, v2, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    sub-int/2addr v2, v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    sub-int/2addr v2, v3

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v5

    sub-int/2addr v0, v2

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    add-int/2addr p2, v5

    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    move-result p2

    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p1

    sub-int v7, p1, v5

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result v4

    const/4 v6, 0x0

    iget-object v3, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    const/16 v8, 0xfa

    invoke-virtual/range {v3 .. v8}, Landroid/widget/OverScroller;->startScroll(IIIII)V

    if-eqz p3, :cond_5f

    const/4 p1, 0x2

    invoke-virtual {p0, p1, v1}, Landroidx/core/widget/NestedScrollView;->w(II)Z

    goto :goto_62

    :cond_5f
    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->y(I)V

    :goto_62
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result p1

    iput p1, p0, Landroidx/core/widget/NestedScrollView;->d0:I

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    goto :goto_7d

    :cond_6c
    iget-object p3, p0, Landroidx/core/widget/NestedScrollView;->H:Landroid/widget/OverScroller;

    invoke-virtual {p3}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v0

    if-nez v0, :cond_7a

    invoke-virtual {p3}, Landroid/widget/OverScroller;->abortAnimation()V

    invoke-virtual {p0, v1}, Landroidx/core/widget/NestedScrollView;->y(I)V

    :cond_7a
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->scrollBy(II)V

    :goto_7d
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide p1

    iput-wide p1, p0, Landroidx/core/widget/NestedScrollView;->F:J

    return-void
.end method

.method public final w(II)Z
    .registers 14

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    iget-object v0, p0, Lvu1;->d:Ljava/lang/Object;

    check-cast v0, Landroidx/core/widget/NestedScrollView;

    invoke-virtual {p0, p2}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object v1

    const/4 v2, 0x1

    if-eqz v1, :cond_e

    return v2

    :cond_e
    iget-boolean v1, p0, Lvu1;->a:Z

    const/4 v3, 0x0

    if-eqz v1, :cond_83

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    move-object v4, v0

    :goto_18
    if-eqz v1, :cond_83

    instance-of v5, v1, Lthc;

    const-string v6, "ViewParent "

    const-string v7, "ViewParentCompat"

    if-eqz v5, :cond_2a

    move-object v8, v1

    check-cast v8, Lthc;

    invoke-interface {v8, v4, v0, p1, p2}, Lthc;->d(Landroid/view/View;Landroid/view/View;II)Z

    move-result v8

    goto :goto_47

    :cond_2a
    if-nez p2, :cond_46

    :try_start_2c
    invoke-interface {v1, v4, v0, p1}, Landroid/view/ViewParent;->onStartNestedScroll(Landroid/view/View;Landroid/view/View;I)Z

    move-result v8
    :try_end_30
    .catch Ljava/lang/AbstractMethodError; {:try_start_2c .. :try_end_30} :catch_31

    goto :goto_47

    :catch_31
    move-exception v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v10, " does not implement interface method onStartNestedScroll"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v7, v9, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_46
    move v8, v3

    :goto_47
    if-eqz v8, :cond_77

    if-eqz p2, :cond_51

    if-eq p2, v2, :cond_4e

    goto :goto_53

    :cond_4e
    iput-object v1, p0, Lvu1;->c:Ljava/lang/Object;

    goto :goto_53

    :cond_51
    iput-object v1, p0, Lvu1;->b:Ljava/lang/Object;

    :goto_53
    if-eqz v5, :cond_5b

    check-cast v1, Lthc;

    invoke-interface {v1, v4, v0, p1, p2}, Lthc;->e(Landroid/view/View;Landroid/view/View;II)V

    goto :goto_84

    :cond_5b
    if-nez p2, :cond_84

    :try_start_5d
    invoke-interface {v1, v4, v0, p1}, Landroid/view/ViewParent;->onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;I)V
    :try_end_60
    .catch Ljava/lang/AbstractMethodError; {:try_start_5d .. :try_end_60} :catch_61

    goto :goto_84

    :catch_61
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " does not implement interface method onNestedScrollAccepted"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v7, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_84

    :cond_77
    instance-of v5, v1, Landroid/view/View;

    if-eqz v5, :cond_7e

    move-object v4, v1

    check-cast v4, Landroid/view/View;

    :cond_7e
    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    goto :goto_18

    :cond_83
    move v2, v3

    :cond_84
    :goto_84
    return v2
.end method

.method public final x(Landroid/view/MotionEvent;)Z
    .registers 7

    iget-object v0, p0, Landroidx/core/widget/NestedScrollView;->I:Landroid/widget/EdgeEffect;

    invoke-static {v0}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v1

    const/4 v2, 0x0

    cmpl-float v1, v1, v2

    const/4 v3, 0x1

    if-eqz v1, :cond_1b

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v4

    int-to-float v4, v4

    div-float/2addr v1, v4

    invoke-static {v0, v2, v1}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    move v0, v3

    goto :goto_1c

    :cond_1b
    const/4 v0, 0x0

    :goto_1c
    iget-object v1, p0, Landroidx/core/widget/NestedScrollView;->J:Landroid/widget/EdgeEffect;

    invoke-static {v1}, Lsnk;->d(Landroid/widget/EdgeEffect;)F

    move-result v4

    cmpl-float v4, v4, v2

    if-eqz v4, :cond_37

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p0

    int-to-float p0, p0

    div-float/2addr p1, p0

    const/high16 p0, 0x3f800000  # 1.0f

    sub-float/2addr p0, p1

    invoke-static {v1, v2, p0}, Lsnk;->g(Landroid/widget/EdgeEffect;FF)F

    return v3

    :cond_37
    return v0
.end method

.method public final y(I)V
    .registers 6

    iget-object p0, p0, Landroidx/core/widget/NestedScrollView;->g0:Lvu1;

    invoke-virtual {p0, p1}, Lvu1;->c(I)Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_41

    iget-object v1, p0, Lvu1;->d:Ljava/lang/Object;

    check-cast v1, Landroidx/core/widget/NestedScrollView;

    instance-of v2, v0, Lthc;

    if-eqz v2, :cond_16

    check-cast v0, Lthc;

    invoke-interface {v0, v1, p1}, Lthc;->f(Landroid/view/View;I)V

    goto :goto_35

    :cond_16
    if-nez p1, :cond_35

    :try_start_18
    invoke-interface {v0, v1}, Landroid/view/ViewParent;->onStopNestedScroll(Landroid/view/View;)V
    :try_end_1b
    .catch Ljava/lang/AbstractMethodError; {:try_start_18 .. :try_end_1b} :catch_1c

    goto :goto_35

    :catch_1c
    move-exception v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "ViewParent "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " does not implement interface method onStopNestedScroll"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "ViewParentCompat"

    invoke-static {v2, v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_35
    :goto_35
    const/4 v0, 0x0

    if-eqz p1, :cond_3f

    const/4 v1, 0x1

    if-eq p1, v1, :cond_3c

    goto :goto_41

    :cond_3c
    iput-object v0, p0, Lvu1;->c:Ljava/lang/Object;

    goto :goto_41

    :cond_3f
    iput-object v0, p0, Lvu1;->b:Ljava/lang/Object;

    :cond_41
    :goto_41
    return-void
.end method
