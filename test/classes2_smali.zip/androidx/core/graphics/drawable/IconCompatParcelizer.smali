.class public Landroidx/core/graphics/drawable/IconCompatParcelizer;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static read(Ljij;)Landroidx/core/graphics/drawable/IconCompat;
    .registers 9

    new-instance v0, Landroidx/core/graphics/drawable/IconCompat;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, -0x1

    iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    const/4 v2, 0x0

    iput-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    iput-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    const/4 v3, 0x0

    iput v3, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    iput v3, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    iput-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;

    sget-object v4, Landroidx/core/graphics/drawable/IconCompat;->k:Landroid/graphics/PorterDuff$Mode;

    iput-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->h:Landroid/graphics/PorterDuff$Mode;

    iput-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    const/4 v4, 0x1

    invoke-virtual {p0, v4}, Ljij;->e(I)Z

    move-result v4

    if-nez v4, :cond_23

    move v4, v1

    goto :goto_2c

    :cond_23
    move-object v4, p0

    check-cast v4, Lkij;

    iget-object v4, v4, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I

    move-result v4

    :goto_2c
    iput v4, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    iget-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Ljij;->e(I)Z

    move-result v6

    if-nez v6, :cond_38

    goto :goto_4b

    :cond_38
    move-object v4, p0

    check-cast v4, Lkij;

    iget-object v4, v4, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I

    move-result v6

    if-gez v6, :cond_45

    move-object v4, v2

    goto :goto_4b

    :cond_45
    new-array v6, v6, [B

    invoke-virtual {v4, v6}, Landroid/os/Parcel;->readByteArray([B)V

    move-object v4, v6

    :goto_4b
    iput-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    iget-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    const/4 v6, 0x3

    invoke-virtual {p0, v4, v6}, Ljij;->f(Landroid/os/Parcelable;I)Landroid/os/Parcelable;

    move-result-object v4

    iput-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    iget v4, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    const/4 v7, 0x4

    invoke-virtual {p0, v7}, Ljij;->e(I)Z

    move-result v7

    if-nez v7, :cond_60

    goto :goto_69

    :cond_60
    move-object v4, p0

    check-cast v4, Lkij;

    iget-object v4, v4, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I

    move-result v4

    :goto_69
    iput v4, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    iget v4, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    const/4 v7, 0x5

    invoke-virtual {p0, v7}, Ljij;->e(I)Z

    move-result v7

    if-nez v7, :cond_75

    goto :goto_7e

    :cond_75
    move-object v4, p0

    check-cast v4, Lkij;

    iget-object v4, v4, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I

    move-result v4

    :goto_7e
    iput v4, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    iget-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;

    const/4 v7, 0x6

    invoke-virtual {p0, v4, v7}, Ljij;->f(Landroid/os/Parcelable;I)Landroid/os/Parcelable;

    move-result-object v4

    check-cast v4, Landroid/content/res/ColorStateList;

    iput-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;

    iget-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    const/4 v7, 0x7

    invoke-virtual {p0, v7}, Ljij;->e(I)Z

    move-result v7

    if-nez v7, :cond_95

    goto :goto_9e

    :cond_95
    move-object v4, p0

    check-cast v4, Lkij;

    iget-object v4, v4, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v4}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    :goto_9e
    iput-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    iget-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    const/16 v7, 0x8

    invoke-virtual {p0, v7}, Ljij;->e(I)Z

    move-result v7

    if-nez v7, :cond_ab

    goto :goto_b3

    :cond_ab
    check-cast p0, Lkij;

    iget-object p0, p0, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {p0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    :goto_b3
    iput-object v4, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    invoke-static {p0}, Landroid/graphics/PorterDuff$Mode;->valueOf(Ljava/lang/String;)Landroid/graphics/PorterDuff$Mode;

    move-result-object p0

    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->h:Landroid/graphics/PorterDuff$Mode;

    iget p0, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    packed-switch p0, :pswitch_data_10a

    :pswitch_c2  #0x0
    goto :goto_e9

    :pswitch_c3  #0x3
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    return-object v0

    :pswitch_c8  #0x2, 0x4, 0x6
    new-instance p0, Ljava/lang/String;

    iget-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    const-string v4, "UTF-16"

    invoke-static {v4}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v4

    invoke-direct {p0, v2, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    iget v2, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    if-ne v2, v5, :cond_e9

    iget-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    if-nez v2, :cond_e9

    const-string v2, ":"

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p0

    aget-object p0, p0, v3

    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    :cond_e9
    :goto_e9
    return-object v0

    :pswitch_ea  #0x1, 0x5
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    if-eqz p0, :cond_f1

    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    return-object v0

    :cond_f1
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    iput v6, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    iput v3, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    array-length p0, p0

    iput p0, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    return-object v0

    :pswitch_fd  #0xffffffff
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    if-eqz p0, :cond_104

    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    return-object v0

    :cond_104
    const-string p0, "Invalid icon"

    invoke-static {p0}, Le97;->p(Ljava/lang/String;)V

    return-object v2

    :pswitch_data_10a
    .packed-switch -0x1
        :pswitch_fd  #ffffffff
        :pswitch_c2  #00000000
        :pswitch_ea  #00000001
        :pswitch_c8  #00000002
        :pswitch_c3  #00000003
        :pswitch_c8  #00000004
        :pswitch_ea  #00000005
        :pswitch_c8  #00000006
    .end packed-switch
.end method

.method public static write(Landroidx/core/graphics/drawable/IconCompat;Ljij;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->h:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    const-string v1, "UTF-16"

    packed-switch v0, :pswitch_data_ce

    :pswitch_12  #0x0
    goto :goto_47

    :pswitch_13  #0x4, 0x6
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    goto :goto_47

    :pswitch_24  #0x3
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    check-cast v0, [B

    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    goto :goto_47

    :pswitch_2b  #0x2
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-static {v1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    goto :goto_47

    :pswitch_3a  #0x1, 0x5
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    check-cast v0, Landroid/os/Parcelable;

    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    goto :goto_47

    :pswitch_41  #0xffffffff
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    check-cast v0, Landroid/os/Parcelable;

    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    :goto_47
    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    const/4 v1, -0x1

    if-eq v1, v0, :cond_58

    const/4 v1, 0x1

    invoke-virtual {p1, v1}, Ljij;->h(I)V

    move-object v1, p1

    check-cast v1, Lkij;

    iget-object v1, v1, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInt(I)V

    :cond_58
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    if-eqz v0, :cond_6c

    const/4 v1, 0x2

    invoke-virtual {p1, v1}, Ljij;->h(I)V

    move-object v1, p1

    check-cast v1, Lkij;

    iget-object v1, v1, Lkij;->e:Landroid/os/Parcel;

    array-length v2, v0

    invoke-virtual {v1, v2}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeByteArray([B)V

    :cond_6c
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    const/4 v1, 0x0

    if-eqz v0, :cond_7d

    const/4 v2, 0x3

    invoke-virtual {p1, v2}, Ljij;->h(I)V

    move-object v2, p1

    check-cast v2, Lkij;

    iget-object v2, v2, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v2, v0, v1}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    :cond_7d
    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    if-eqz v0, :cond_8d

    const/4 v2, 0x4

    invoke-virtual {p1, v2}, Ljij;->h(I)V

    move-object v2, p1

    check-cast v2, Lkij;

    iget-object v2, v2, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeInt(I)V

    :cond_8d
    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    if-eqz v0, :cond_9d

    const/4 v2, 0x5

    invoke-virtual {p1, v2}, Ljij;->h(I)V

    move-object v2, p1

    check-cast v2, Lkij;

    iget-object v2, v2, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeInt(I)V

    :cond_9d
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;

    if-eqz v0, :cond_ad

    const/4 v2, 0x6

    invoke-virtual {p1, v2}, Ljij;->h(I)V

    move-object v2, p1

    check-cast v2, Lkij;

    iget-object v2, v2, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v2, v0, v1}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    :cond_ad
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    if-eqz v0, :cond_bd

    const/4 v1, 0x7

    invoke-virtual {p1, v1}, Ljij;->h(I)V

    move-object v1, p1

    check-cast v1, Lkij;

    iget-object v1, v1, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    :cond_bd
    iget-object p0, p0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    if-eqz p0, :cond_cd

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Ljij;->h(I)V

    check-cast p1, Lkij;

    iget-object p1, p1, Lkij;->e:Landroid/os/Parcel;

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    :cond_cd
    return-void

    :pswitch_data_ce
    .packed-switch -0x1
        :pswitch_41  #ffffffff
        :pswitch_12  #00000000
        :pswitch_3a  #00000001
        :pswitch_2b  #00000002
        :pswitch_24  #00000003
        :pswitch_13  #00000004
        :pswitch_3a  #00000005
        :pswitch_13  #00000006
    .end packed-switch
.end method
