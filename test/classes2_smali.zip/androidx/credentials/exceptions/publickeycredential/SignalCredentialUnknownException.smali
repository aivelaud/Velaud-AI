.class public final Landroidx/credentials/exceptions/publickeycredential/SignalCredentialUnknownException;
.super Landroidx/credentials/exceptions/publickeycredential/SignalCredentialStateException;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001¨\u0006\u0002"
    }
    d2 = {
        "Landroidx/credentials/exceptions/publickeycredential/SignalCredentialUnknownException;",
        "Landroidx/credentials/exceptions/publickeycredential/SignalCredentialStateException;",
        "credentials"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation
