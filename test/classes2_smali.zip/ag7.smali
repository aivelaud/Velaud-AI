.class public final Lag7;
.super Ldg7;
.source "SourceFile"


# instance fields
.field public final a:Llhj;

.field public final b:Llhj;


# direct methods
.method public constructor <init>(Llhj;Llhj;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lag7;->a:Llhj;

    iput-object p2, p0, Lag7;->b:Llhj;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    if-ne p0, p1, :cond_3

    goto :goto_21

    :cond_3
    instance-of v0, p1, Lag7;

    if-nez v0, :cond_8

    goto :goto_1f

    :cond_8
    check-cast p1, Lag7;

    iget-object v0, p1, Lag7;->a:Llhj;

    iget-object v1, p0, Lag7;->a:Llhj;

    invoke-virtual {v1, v0}, Llhj;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_1f

    :cond_15
    iget-object p0, p0, Lag7;->b:Llhj;

    iget-object p1, p1, Lag7;->b:Llhj;

    invoke-virtual {p0, p1}, Llhj;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_21

    :goto_1f
    const/4 p0, 0x0

    return p0

    :cond_21
    :goto_21
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lag7;->a:Llhj;

    invoke-virtual {v0}, Llhj;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lag7;->b:Llhj;

    invoke-virtual {p0}, Llhj;->hashCode()I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "SpeedTarget(minSpeed="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lag7;->a:Llhj;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", maxSpeed="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lag7;->b:Llhj;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
