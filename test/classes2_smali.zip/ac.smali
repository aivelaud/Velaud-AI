.class public final Lac;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Let;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lac;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()Los;
    .registers 1

    iget p0, p0, Lac;->a:I

    packed-switch p0, :pswitch_data_32

    sget-object p0, Lv0k;->g:Los;

    return-object p0

    :pswitch_8  #0xd
    sget-object p0, Lg0k;->g:Los;

    return-object p0

    :pswitch_b  #0xc
    sget-object p0, Lg0k;->h:Los;

    return-object p0

    :pswitch_e  #0xb
    sget-object p0, Lg0k;->f:Los;

    return-object p0

    :pswitch_11  #0xa
    sget-object p0, Ltqi;->h:Los;

    return-object p0

    :pswitch_14  #0x9
    sget-object p0, Lxih;->g:Los;

    return-object p0

    :pswitch_17  #0x8
    sget-object p0, Lo3h;->i:Los;

    return-object p0

    :pswitch_1a  #0x7
    sget-object p0, Ll2c;->i:Los;

    return-object p0

    :pswitch_1d  #0x6
    sget-object p0, La49;->h:Los;

    return-object p0

    :pswitch_20  #0x5
    sget-object p0, Lpz7;->g:Los;

    return-object p0

    :pswitch_23  #0x4
    sget-object p0, Llg7;->m:Los;

    return-object p0

    :pswitch_26  #0x3
    sget-object p0, Lwt6;->i:Los;

    return-object p0

    :pswitch_29  #0x2
    sget-object p0, Lei6;->h:Los;

    return-object p0

    :pswitch_2c  #0x1
    sget-object p0, Llh1;->f:Los;

    return-object p0

    :pswitch_2f  #0x0
    sget-object p0, Lcc;->h:Los;

    return-object p0

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_2f  #00000000
        :pswitch_2c  #00000001
        :pswitch_29  #00000002
        :pswitch_26  #00000003
        :pswitch_23  #00000004
        :pswitch_20  #00000005
        :pswitch_1d  #00000006
        :pswitch_1a  #00000007
        :pswitch_17  #00000008
        :pswitch_14  #00000009
        :pswitch_11  #0000000a
        :pswitch_e  #0000000b
        :pswitch_b  #0000000c
        :pswitch_8  #0000000d
    .end packed-switch
.end method

.method public final c()Lc98;
    .registers 2

    iget p0, p0, Lac;->a:I

    packed-switch p0, :pswitch_data_7a

    new-instance p0, Lv1j;

    const/16 v0, 0x1b

    invoke-direct {p0, v0}, Lv1j;-><init>(I)V

    return-object p0

    :pswitch_d  #0xd
    new-instance p0, Lv1j;

    const/16 v0, 0x1a

    invoke-direct {p0, v0}, Lv1j;-><init>(I)V

    return-object p0

    :pswitch_15  #0xc
    new-instance p0, Lv1j;

    const/16 v0, 0x19

    invoke-direct {p0, v0}, Lv1j;-><init>(I)V

    return-object p0

    :pswitch_1d  #0xb
    new-instance p0, Lv1j;

    const/16 v0, 0x18

    invoke-direct {p0, v0}, Lv1j;-><init>(I)V

    return-object p0

    :pswitch_25  #0xa
    new-instance p0, Lsuh;

    const/16 v0, 0x19

    invoke-direct {p0, v0}, Lsuh;-><init>(I)V

    return-object p0

    :pswitch_2d  #0x9
    new-instance p0, Lwug;

    const/16 v0, 0x19

    invoke-direct {p0, v0}, Lwug;-><init>(I)V

    return-object p0

    :pswitch_35  #0x8
    new-instance p0, Lwug;

    const/16 v0, 0xa

    invoke-direct {p0, v0}, Lwug;-><init>(I)V

    return-object p0

    :pswitch_3d  #0x7
    new-instance p0, Lvrb;

    const/4 v0, 0x6

    invoke-direct {p0, v0}, Lvrb;-><init>(I)V

    return-object p0

    :pswitch_44  #0x6
    new-instance p0, Lpo8;

    const/4 v0, 0x5

    invoke-direct {p0, v0}, Lpo8;-><init>(I)V

    return-object p0

    :pswitch_4b  #0x5
    new-instance p0, Lgb6;

    const/16 v0, 0x1d

    invoke-direct {p0, v0}, Lgb6;-><init>(I)V

    return-object p0

    :pswitch_53  #0x4
    new-instance p0, Lgb6;

    const/16 v0, 0x11

    invoke-direct {p0, v0}, Lgb6;-><init>(I)V

    return-object p0

    :pswitch_5b  #0x3
    new-instance p0, Lgb6;

    const/16 v0, 0x8

    invoke-direct {p0, v0}, Lgb6;-><init>(I)V

    return-object p0

    :pswitch_63  #0x2
    new-instance p0, Lgb6;

    const/4 v0, 0x3

    invoke-direct {p0, v0}, Lgb6;-><init>(I)V

    return-object p0

    :pswitch_6a  #0x1
    new-instance p0, Lqw;

    const/16 v0, 0x12

    invoke-direct {p0, v0}, Lqw;-><init>(I)V

    return-object p0

    :pswitch_72  #0x0
    new-instance p0, Lq6;

    const/4 v0, 0x2

    invoke-direct {p0, v0}, Lq6;-><init>(I)V

    return-object p0

    nop

    :pswitch_data_7a
    .packed-switch 0x0
        :pswitch_72  #00000000
        :pswitch_6a  #00000001
        :pswitch_63  #00000002
        :pswitch_5b  #00000003
        :pswitch_53  #00000004
        :pswitch_4b  #00000005
        :pswitch_44  #00000006
        :pswitch_3d  #00000007
        :pswitch_35  #00000008
        :pswitch_2d  #00000009
        :pswitch_25  #0000000a
        :pswitch_1d  #0000000b
        :pswitch_15  #0000000c
        :pswitch_d  #0000000d
    .end packed-switch
.end method
