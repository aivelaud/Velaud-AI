.class public final synthetic Laf5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Lyg5;


# direct methods
.method public synthetic constructor <init>(Lyg5;I)V
    .registers 3

    iput p2, p0, Laf5;->E:I

    iput-object p1, p0, Laf5;->F:Lyg5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget v0, p0, Laf5;->E:I

    iget-object p0, p0, Laf5;->F:Lyg5;

    packed-switch v0, :pswitch_data_38

    invoke-static {p0}, Landroidx/credentials/playservices/controllers/identitycredentials/signalcredentialstate/SignalCredentialStateController;->$r8$lambda$b3puoOwGj3hPeeVU7q4sQGzSAjA(Lyg5;)V

    return-void

    :pswitch_b  #0xa
    invoke-static {p0}, Landroidx/credentials/playservices/controllers/ResponseUtils$Companion;->$r8$lambda$A06gwChzcFuhXsKmyMy0CkBHQxI(Lyg5;)V

    return-void

    :pswitch_f  #0x9
    invoke-static {p0}, Landroidx/credentials/playservices/controllers/identitycredentials/getcredential/GetCredentialController;->$r8$lambda$Pk2aOlFyA3EIck7KXp7BpFKY4Os(Lyg5;)V

    return-void

    :pswitch_13  #0x8
    invoke-static {p0}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$27hAKj8hhFiHQnNA1lTKsiG-Oxw(Lyg5;)V

    return-void

    :pswitch_17  #0x7
    invoke-static {p0}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$ZmeORH0b9a1FJ17DY04w0WU6DDE(Lyg5;)V

    return-void

    :pswitch_1b  #0x6
    invoke-static {p0}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$v5kLi_w59Ybz8Cu6DmJc3hm3YW4(Lyg5;)V

    return-void

    :pswitch_1f  #0x5
    invoke-static {p0}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$hCjUIdJpkFZZ_R4jPEVDfW9xTXk(Lyg5;)V

    return-void

    :pswitch_23  #0x4
    invoke-static {p0}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$eKxW_gs1lUPICybr1syVFaQsVp0(Lyg5;)V

    return-void

    :pswitch_27  #0x3
    invoke-static {p0}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$v2_cK85gsZZQw32xnN1qU13GbKQ(Lyg5;)V

    return-void

    :pswitch_2b  #0x2
    invoke-static {p0}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$e26-TJ45BetGQtJZIcAQ5s9rm3c(Lyg5;)V

    return-void

    :pswitch_2f  #0x1
    invoke-static {p0}, Landroidx/credentials/playservices/controllers/identitycredentials/createpublickeycredential/CreatePublicKeyCredentialController;->$r8$lambda$EktFgG8fKJBAiksRwFhMIhMprWQ(Lyg5;)V

    return-void

    :pswitch_33  #0x0
    invoke-static {p0}, Landroidx/credentials/playservices/controllers/identitycredentials/createpublickeycredential/CreatePublicKeyCredentialController;->$r8$lambda$H8m58jFF48xOVIW7wbb-qAohYTk(Lyg5;)V

    return-void

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_33  #00000000
        :pswitch_2f  #00000001
        :pswitch_2b  #00000002
        :pswitch_27  #00000003
        :pswitch_23  #00000004
        :pswitch_1f  #00000005
        :pswitch_1b  #00000006
        :pswitch_17  #00000007
        :pswitch_13  #00000008
        :pswitch_f  #00000009
        :pswitch_b  #0000000a
    .end packed-switch
.end method
