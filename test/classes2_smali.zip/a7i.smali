.class public final La7i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lnlb;


# instance fields
.field public final a:Z

.field public final b:Lm6i;

.field public final c:Le6i;

.field public final d:Le6i;

.field public final e:Le6i;

.field public final f:Lz5d;

.field public final g:F


# direct methods
.method public constructor <init>(ZLm6i;Le6i;Le6i;Le6i;Lz5d;F)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, La7i;->a:Z

    iput-object p2, p0, La7i;->b:Lm6i;

    iput-object p3, p0, La7i;->c:Le6i;

    iput-object p4, p0, La7i;->d:Le6i;

    iput-object p5, p0, La7i;->e:Le6i;

    iput-object p6, p0, La7i;->f:Lz5d;

    iput p7, p0, La7i;->g:F

    return-void
.end method

.method public static h(Ljava/util/List;ILq98;)I
    .registers 16

    move-object v0, p0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v1

    const/4 v2, 0x0

    move v3, v2

    :goto_9
    if-ge v3, v1, :cond_17b

    invoke-interface {p0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Lglb;

    invoke-static {v5}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v5

    const-string v6, "TextField"

    invoke-static {v5, v6}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_177

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p2, v4, v1}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v3

    move v4, v2

    :goto_31
    const/4 v5, 0x0

    if-ge v4, v3, :cond_4b

    invoke-interface {p0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    move-object v7, v6

    check-cast v7, Lglb;

    invoke-static {v7}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v7

    const-string v8, "Label"

    invoke-static {v7, v8}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_48

    goto :goto_4c

    :cond_48
    add-int/lit8 v4, v4, 0x1

    goto :goto_31

    :cond_4b
    move-object v6, v5

    :goto_4c
    check-cast v6, Lglb;

    if-eqz v6, :cond_5f

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {p2, v6, v3}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    goto :goto_60

    :cond_5f
    move v3, v2

    :goto_60
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v4

    move v6, v2

    :goto_65
    if-ge v6, v4, :cond_7e

    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    move-object v8, v7

    check-cast v8, Lglb;

    invoke-static {v8}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v8

    const-string v9, "Trailing"

    invoke-static {v8, v9}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_7b

    goto :goto_7f

    :cond_7b
    add-int/lit8 v6, v6, 0x1

    goto :goto_65

    :cond_7e
    move-object v7, v5

    :goto_7f
    check-cast v7, Lglb;

    if-eqz v7, :cond_92

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {p2, v7, v4}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    goto :goto_93

    :cond_92
    move v4, v2

    :goto_93
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v6

    move v7, v2

    :goto_98
    if-ge v7, v6, :cond_b1

    invoke-interface {p0, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object v9, v8

    check-cast v9, Lglb;

    invoke-static {v9}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v9

    const-string v10, "Prefix"

    invoke-static {v9, v10}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_ae

    goto :goto_b2

    :cond_ae
    add-int/lit8 v7, v7, 0x1

    goto :goto_98

    :cond_b1
    move-object v8, v5

    :goto_b2
    check-cast v8, Lglb;

    if-eqz v8, :cond_c5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {p2, v8, v6}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    goto :goto_c6

    :cond_c5
    move v6, v2

    :goto_c6
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v7

    move v8, v2

    :goto_cb
    if-ge v8, v7, :cond_e4

    invoke-interface {p0, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    move-object v10, v9

    check-cast v10, Lglb;

    invoke-static {v10}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v10

    const-string v11, "Suffix"

    invoke-static {v10, v11}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_e1

    goto :goto_e5

    :cond_e1
    add-int/lit8 v8, v8, 0x1

    goto :goto_cb

    :cond_e4
    move-object v9, v5

    :goto_e5
    check-cast v9, Lglb;

    if-eqz v9, :cond_f8

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {p2, v9, v7}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    goto :goto_f9

    :cond_f8
    move v7, v2

    :goto_f9
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v8

    move v9, v2

    :goto_fe
    if-ge v9, v8, :cond_117

    invoke-interface {p0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    move-object v11, v10

    check-cast v11, Lglb;

    invoke-static {v11}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v11

    const-string v12, "Leading"

    invoke-static {v11, v12}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_114

    goto :goto_118

    :cond_114
    add-int/lit8 v9, v9, 0x1

    goto :goto_fe

    :cond_117
    move-object v10, v5

    :goto_118
    check-cast v10, Lglb;

    if-eqz v10, :cond_12b

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {p2, v10, v8}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    goto :goto_12c

    :cond_12b
    move v8, v2

    :goto_12c
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v0

    move v9, v2

    :goto_131
    if-ge v9, v0, :cond_14b

    invoke-interface {p0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    move-object v11, v10

    check-cast v11, Lglb;

    invoke-static {v11}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v11

    const-string v12, "Hint"

    invoke-static {v11, v12}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_148

    move-object v5, v10

    goto :goto_14b

    :cond_148
    add-int/lit8 v9, v9, 0x1

    goto :goto_131

    :cond_14b
    :goto_14b
    check-cast v5, Lglb;

    if-eqz v5, :cond_15e

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {p2, v5, p0}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    goto :goto_15f

    :cond_15e
    move p0, v2

    :goto_15f
    const/16 p1, 0xf

    invoke-static {v2, v2, v2, v2, p1}, Lk35;->b(IIIII)J

    move-result-wide p1

    add-int/2addr v6, v7

    add-int/2addr v1, v6

    add-int/2addr p0, v6

    invoke-static {p0, v3}, Ljava/lang/Math;->max(II)I

    move-result p0

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    add-int/2addr p0, v8

    add-int/2addr p0, v4

    invoke-static {p0, p1, p2}, Lk35;->g(IJ)I

    move-result p0

    return p0

    :cond_177
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_9

    :cond_17b
    const-string p0, "Collection contains no element matching the predicate."

    invoke-static {p0}, Lti6;->y(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object p0

    throw p0
.end method

.method public static final i(La7i;IILemd;)I
    .registers 4

    iget-boolean p0, p0, La7i;->a:Z

    if-eqz p0, :cond_11

    iget p0, p3, Lemd;->F:I

    sub-int/2addr p1, p0

    int-to-float p0, p1

    const/high16 p1, 0x40000000  # 2.0f

    const/high16 p2, 0x3f800000  # 1.0f

    invoke-static {p0, p1, p2}, Lti6;->b(FFF)I

    move-result p0

    return p0

    :cond_11
    return p2
.end method


# virtual methods
.method public final a(Lrn9;Ljava/util/List;I)I
    .registers 4

    new-instance p0, Lwgg;

    const/16 p1, 0x10

    invoke-direct {p0, p1}, Lwgg;-><init>(I)V

    invoke-static {p2, p3, p0}, La7i;->h(Ljava/util/List;ILq98;)I

    move-result p0

    return p0
.end method

.method public final b(Lplb;Ljava/util/List;J)Lolb;
    .registers 40

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v13, p2

    iget-object v2, v0, La7i;->c:Le6i;

    invoke-virtual {v2}, Le6i;->a()F

    move-result v12

    iget-object v2, v0, La7i;->f:Lz5d;

    invoke-interface {v2}, Lz5d;->d()F

    move-result v3

    invoke-interface {v1, v3}, Ld76;->L0(F)I

    move-result v14

    invoke-interface {v2}, Lz5d;->a()F

    move-result v2

    invoke-interface {v1, v2}, Ld76;->L0(F)I

    move-result v2

    const/4 v6, 0x0

    const/16 v7, 0xa

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-wide/from16 v8, p3

    invoke-static/range {v3 .. v9}, Lj35;->a(IIIIIJ)J

    move-result-wide v3

    move-object v15, v13

    check-cast v15, Ljava/util/Collection;

    invoke-interface {v15}, Ljava/util/Collection;->size()I

    move-result v5

    move v7, v6

    :goto_32
    const/16 v16, 0x0

    if-ge v7, v5, :cond_4d

    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object v9, v8

    check-cast v9, Lglb;

    invoke-static {v9}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v9

    const-string v10, "Leading"

    invoke-static {v9, v10}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_4a

    goto :goto_4f

    :cond_4a
    add-int/lit8 v7, v7, 0x1

    goto :goto_32

    :cond_4d
    move-object/from16 v8, v16

    :goto_4f
    check-cast v8, Lglb;

    if-eqz v8, :cond_58

    invoke-interface {v8, v3, v4}, Lglb;->r(J)Lemd;

    move-result-object v5

    goto :goto_5a

    :cond_58
    move-object/from16 v5, v16

    :goto_5a
    if-eqz v5, :cond_5f

    iget v7, v5, Lemd;->E:I

    goto :goto_60

    :cond_5f
    move v7, v6

    :goto_60
    if-eqz v5, :cond_65

    iget v8, v5, Lemd;->F:I

    goto :goto_66

    :cond_65
    move v8, v6

    :goto_66
    invoke-static {v6, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-interface {v15}, Ljava/util/Collection;->size()I

    move-result v9

    move v10, v6

    :goto_6f
    if-ge v10, v9, :cond_8c

    invoke-interface {v13, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    move-object/from16 v17, v11

    check-cast v17, Lglb;

    invoke-static/range {v17 .. v17}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v6

    const-string v0, "Trailing"

    invoke-static {v6, v0}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_86

    goto :goto_8e

    :cond_86
    add-int/lit8 v10, v10, 0x1

    const/4 v6, 0x0

    move-object/from16 v0, p0

    goto :goto_6f

    :cond_8c
    move-object/from16 v11, v16

    :goto_8e
    check-cast v11, Lglb;

    const/4 v0, 0x2

    if-eqz v11, :cond_9f

    neg-int v6, v7

    move-object v10, v5

    const/4 v9, 0x0

    invoke-static {v6, v9, v0, v3, v4}, Lk35;->j(IIIJ)J

    move-result-wide v5

    invoke-interface {v11, v5, v6}, Lglb;->r(J)Lemd;

    move-result-object v5

    goto :goto_a2

    :cond_9f
    move-object v10, v5

    move-object/from16 v5, v16

    :goto_a2
    if-eqz v5, :cond_a7

    iget v6, v5, Lemd;->E:I

    goto :goto_a8

    :cond_a7
    const/4 v6, 0x0

    :goto_a8
    add-int/2addr v7, v6

    if-eqz v5, :cond_ae

    iget v6, v5, Lemd;->F:I

    goto :goto_af

    :cond_ae
    const/4 v6, 0x0

    :goto_af
    invoke-static {v8, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    invoke-interface {v15}, Ljava/util/Collection;->size()I

    move-result v8

    const/4 v9, 0x0

    :goto_b8
    if-ge v9, v8, :cond_d5

    invoke-interface {v13, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    move-object/from16 v17, v11

    check-cast v17, Lglb;

    invoke-static/range {v17 .. v17}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "Prefix"

    invoke-static {v0, v1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_cf

    goto :goto_d7

    :cond_cf
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p1

    const/4 v0, 0x2

    goto :goto_b8

    :cond_d5
    move-object/from16 v11, v16

    :goto_d7
    check-cast v11, Lglb;

    if-eqz v11, :cond_e9

    neg-int v0, v7

    move/from16 v17, v7

    const/4 v1, 0x2

    const/4 v9, 0x0

    invoke-static {v0, v9, v1, v3, v4}, Lk35;->j(IIIJ)J

    move-result-wide v7

    invoke-interface {v11, v7, v8}, Lglb;->r(J)Lemd;

    move-result-object v0

    goto :goto_ed

    :cond_e9
    move/from16 v17, v7

    move-object/from16 v0, v16

    :goto_ed
    if-eqz v0, :cond_f2

    iget v9, v0, Lemd;->E:I

    goto :goto_f3

    :cond_f2
    const/4 v9, 0x0

    :goto_f3
    add-int v7, v17, v9

    if-eqz v0, :cond_fa

    iget v9, v0, Lemd;->F:I

    goto :goto_fb

    :cond_fa
    const/4 v9, 0x0

    :goto_fb
    invoke-static {v6, v9}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-interface {v15}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v9, 0x0

    :goto_104
    if-ge v9, v6, :cond_121

    invoke-interface {v13, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object v11, v8

    check-cast v11, Lglb;

    invoke-static {v11}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v11

    move-object/from16 v17, v5

    const-string v5, "Suffix"

    invoke-static {v11, v5}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_11c

    goto :goto_125

    :cond_11c
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v5, v17

    goto :goto_104

    :cond_121
    move-object/from16 v17, v5

    move-object/from16 v8, v16

    :goto_125
    check-cast v8, Lglb;

    if-eqz v8, :cond_135

    neg-int v5, v7

    const/4 v6, 0x2

    const/4 v9, 0x0

    invoke-static {v5, v9, v6, v3, v4}, Lk35;->j(IIIJ)J

    move-result-wide v5

    invoke-interface {v8, v5, v6}, Lglb;->r(J)Lemd;

    move-result-object v5

    goto :goto_138

    :cond_135
    const/4 v9, 0x0

    move-object/from16 v5, v16

    :goto_138
    if-eqz v5, :cond_13d

    iget v6, v5, Lemd;->E:I

    goto :goto_13e

    :cond_13d
    move v6, v9

    :goto_13e
    add-int/2addr v7, v6

    if-eqz v5, :cond_144

    iget v6, v5, Lemd;->F:I

    goto :goto_145

    :cond_144
    move v6, v9

    :goto_145
    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-interface {v15}, Ljava/util/Collection;->size()I

    move-result v6

    move v8, v9

    :goto_14e
    if-ge v8, v6, :cond_16d

    invoke-interface {v13, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    move-object/from16 v18, v11

    check-cast v18, Lglb;

    invoke-static/range {v18 .. v18}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v18, v5

    const-string v5, "Label"

    invoke-static {v9, v5}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_167

    goto :goto_171

    :cond_167
    add-int/lit8 v8, v8, 0x1

    move-object/from16 v5, v18

    const/4 v9, 0x0

    goto :goto_14e

    :cond_16d
    move-object/from16 v18, v5

    move-object/from16 v11, v16

    :goto_171
    check-cast v11, Lglb;

    new-instance v5, Lixe;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    neg-int v6, v2

    neg-int v7, v7

    invoke-static {v7, v3, v4, v6}, Lk35;->i(IJI)J

    move-result-wide v8

    if-eqz v11, :cond_185

    invoke-interface {v11, v8, v9}, Lglb;->r(J)Lemd;

    move-result-object v6

    goto :goto_187

    :cond_185
    move-object/from16 v6, v16

    :goto_187
    iput-object v6, v5, Lixe;->E:Ljava/lang/Object;

    invoke-interface {v15}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v9, 0x0

    :goto_18e
    if-ge v9, v6, :cond_1ab

    invoke-interface {v13, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object v11, v8

    check-cast v11, Lglb;

    invoke-static {v11}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v11

    move/from16 v20, v2

    const-string v2, "Supporting"

    invoke-static {v11, v2}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1a6

    goto :goto_1af

    :cond_1a6
    add-int/lit8 v9, v9, 0x1

    move/from16 v2, v20

    goto :goto_18e

    :cond_1ab
    move/from16 v20, v2

    move-object/from16 v8, v16

    :goto_1af
    move-object v2, v8

    check-cast v2, Lglb;

    if-eqz v2, :cond_1bf

    invoke-static/range {p3 .. p4}, Lj35;->j(J)I

    move-result v6

    invoke-interface {v2, v6}, Lglb;->R(I)I

    move-result v9

    move/from16 v21, v9

    goto :goto_1c1

    :cond_1bf
    const/16 v21, 0x0

    :goto_1c1
    iget-object v6, v5, Lixe;->E:Ljava/lang/Object;

    check-cast v6, Lemd;

    if-eqz v6, :cond_1ca

    iget v9, v6, Lemd;->F:I

    goto :goto_1cb

    :cond_1ca
    const/4 v9, 0x0

    :goto_1cb
    add-int/2addr v9, v14

    const/4 v8, 0x0

    move v6, v9

    const/16 v9, 0xb

    move-object v11, v5

    const/4 v5, 0x0

    move/from16 v22, v6

    const/4 v6, 0x0

    move/from16 v23, v7

    const/4 v7, 0x0

    move-object/from16 v19, v17

    move-object/from16 v17, v15

    move-object/from16 v15, v19

    move-wide/from16 v25, v3

    move/from16 v19, v12

    move/from16 v24, v14

    move-object/from16 v12, v18

    move/from16 v4, v22

    move/from16 v3, v23

    move-object/from16 v22, v2

    move-object v14, v10

    move-object v2, v11

    move-wide/from16 v10, p3

    invoke-static/range {v5 .. v11}, Lj35;->a(IIIIIJ)J

    move-result-wide v5

    neg-int v7, v4

    sub-int v7, v7, v20

    sub-int v7, v7, v21

    invoke-static {v3, v5, v6, v7}, Lk35;->i(IJI)J

    move-result-wide v5

    invoke-interface/range {v17 .. v17}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v7, 0x0

    :goto_202
    const-string v17, "Collection contains no element matching the predicate."

    if-ge v7, v3, :cond_3d5

    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lglb;

    invoke-static {v8}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v9

    const-string v10, "TextField"

    invoke-static {v9, v10}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_3b1

    invoke-interface {v8, v5, v6}, Lglb;->r(J)Lemd;

    move-result-object v3

    const/16 v30, 0x0

    const/16 v31, 0xe

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    move-wide/from16 v32, v5

    invoke-static/range {v27 .. v33}, Lj35;->a(IIIIIJ)J

    move-result-wide v5

    move-object/from16 v21, v13

    check-cast v21, Ljava/util/Collection;

    invoke-interface/range {v21 .. v21}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v8, 0x0

    :goto_235
    if-ge v8, v7, :cond_24e

    invoke-interface {v13, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    move-object v10, v9

    check-cast v10, Lglb;

    invoke-static {v10}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v10

    const-string v11, "Hint"

    invoke-static {v10, v11}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_24b

    goto :goto_250

    :cond_24b
    add-int/lit8 v8, v8, 0x1

    goto :goto_235

    :cond_24e
    move-object/from16 v9, v16

    :goto_250
    check-cast v9, Lglb;

    if-eqz v9, :cond_259

    invoke-interface {v9, v5, v6}, Lglb;->r(J)Lemd;

    move-result-object v5

    goto :goto_25b

    :cond_259
    move-object/from16 v5, v16

    :goto_25b
    iget v6, v3, Lemd;->F:I

    if-eqz v5, :cond_262

    iget v7, v5, Lemd;->F:I

    goto :goto_263

    :cond_262
    const/4 v7, 0x0

    :goto_263
    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v6

    add-int/2addr v6, v4

    add-int v6, v6, v20

    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    if-eqz v14, :cond_273

    iget v6, v14, Lemd;->E:I

    goto :goto_274

    :cond_273
    const/4 v6, 0x0

    :goto_274
    if-eqz v15, :cond_279

    iget v4, v15, Lemd;->E:I

    goto :goto_27a

    :cond_279
    const/4 v4, 0x0

    :goto_27a
    if-eqz v0, :cond_27f

    iget v7, v0, Lemd;->E:I

    goto :goto_280

    :cond_27f
    const/4 v7, 0x0

    :goto_280
    if-eqz v12, :cond_285

    iget v8, v12, Lemd;->E:I

    goto :goto_286

    :cond_285
    const/4 v8, 0x0

    :goto_286
    iget v9, v3, Lemd;->E:I

    iget-object v10, v2, Lixe;->E:Ljava/lang/Object;

    check-cast v10, Lemd;

    if-eqz v10, :cond_291

    iget v10, v10, Lemd;->E:I

    goto :goto_292

    :cond_291
    const/4 v10, 0x0

    :goto_292
    if-eqz v5, :cond_297

    iget v11, v5, Lemd;->E:I

    goto :goto_298

    :cond_297
    const/4 v11, 0x0

    :goto_298
    add-int/2addr v7, v8

    add-int/2addr v9, v7

    add-int/2addr v11, v7

    invoke-static {v11, v10}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-static {v9, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    add-int/2addr v7, v6

    add-int/2addr v7, v4

    move-wide/from16 v10, p3

    invoke-static {v7, v10, v11}, Lk35;->g(IJ)I

    move-result v28

    neg-int v1, v1

    const/4 v4, 0x1

    move-wide/from16 v8, v25

    const/4 v6, 0x0

    invoke-static {v6, v1, v4, v8, v9}, Lk35;->j(IIIJ)J

    move-result-wide v32

    const/16 v30, 0x0

    const/16 v31, 0x9

    const/16 v27, 0x0

    const/16 v29, 0x0

    invoke-static/range {v27 .. v33}, Lj35;->a(IIIIIJ)J

    move-result-wide v7

    if-eqz v22, :cond_2c8

    move-object/from16 v1, v22

    invoke-interface {v1, v7, v8}, Lglb;->r(J)Lemd;

    move-result-object v16

    :cond_2c8
    move-object/from16 v1, v16

    if-eqz v1, :cond_2d1

    iget v4, v1, Lemd;->F:I

    move/from16 v16, v4

    goto :goto_2d3

    :cond_2d1
    move/from16 v16, v6

    :goto_2d3
    iget v4, v3, Lemd;->F:I

    iget-object v7, v2, Lixe;->E:Ljava/lang/Object;

    check-cast v7, Lemd;

    if-eqz v7, :cond_2e3

    iget v7, v7, Lemd;->F:I

    move/from16 v34, v7

    move-object v7, v3

    move/from16 v3, v34

    goto :goto_2e5

    :cond_2e3
    move-object v7, v3

    move v3, v6

    :goto_2e5
    if-eqz v14, :cond_2f0

    iget v8, v14, Lemd;->F:I

    move/from16 v34, v8

    move-object v8, v2

    move v2, v4

    move/from16 v4, v34

    goto :goto_2f3

    :cond_2f0
    move-object v8, v2

    move v2, v4

    move v4, v6

    :goto_2f3
    if-eqz v15, :cond_2f8

    iget v9, v15, Lemd;->F:I

    goto :goto_2f9

    :cond_2f8
    move v9, v6

    :goto_2f9
    if-eqz v0, :cond_2fe

    iget v6, v0, Lemd;->F:I

    goto :goto_2ff

    :cond_2fe
    const/4 v6, 0x0

    :goto_2ff
    move-object/from16 v22, v0

    if-eqz v12, :cond_30b

    iget v0, v12, Lemd;->F:I

    move-object/from16 v34, v7

    move v7, v0

    move-object/from16 v0, v34

    goto :goto_30d

    :cond_30b
    move-object v0, v7

    const/4 v7, 0x0

    :goto_30d
    move-object/from16 v20, v0

    if-eqz v5, :cond_319

    iget v0, v5, Lemd;->F:I

    move-object/from16 v34, v8

    move v8, v0

    move-object/from16 v0, v34

    goto :goto_31b

    :cond_319
    move-object v0, v8

    const/4 v8, 0x0

    :goto_31b
    move-object/from16 v23, v0

    if-eqz v1, :cond_336

    iget v0, v1, Lemd;->F:I

    move-object/from16 v18, v12

    move/from16 v12, v19

    move-object/from16 v19, v5

    move v5, v9

    move v9, v0

    move-object/from16 v26, v1

    move-object/from16 v25, v14

    move/from16 v14, v28

    const/16 v27, 0x0

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    goto :goto_34a

    :cond_336
    move-object/from16 v18, v12

    move/from16 v12, v19

    move-object/from16 v19, v5

    move v5, v9

    const/4 v9, 0x0

    move-object/from16 v26, v1

    move-object/from16 v25, v14

    move/from16 v14, v28

    const/16 v27, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    :goto_34a
    invoke-virtual/range {v0 .. v12}, La7i;->f(Lrn9;IIIIIIIIJF)I

    move-result v6

    sub-int v3, v6, v16

    invoke-interface/range {v21 .. v21}, Ljava/util/Collection;->size()I

    move-result v0

    move/from16 v1, v27

    :goto_356
    if-ge v1, v0, :cond_3ac

    invoke-interface {v13, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lglb;

    invoke-static {v2}, Lbo9;->W(Lglb;)Ljava/lang/Object;

    move-result-object v4

    const-string v5, "Container"

    invoke-static {v4, v5}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3a7

    const v0, 0x7fffffff

    if-eq v14, v0, :cond_371

    move v1, v14

    goto :goto_373

    :cond_371
    move/from16 v1, v27

    :goto_373
    if-eq v3, v0, :cond_377

    move v0, v3

    goto :goto_379

    :cond_377
    move/from16 v0, v27

    :goto_379
    invoke-static {v1, v14, v0, v3}, Lk35;->a(IIII)J

    move-result-wide v0

    invoke-interface {v2, v0, v1}, Lglb;->r(J)Lemd;

    move-result-object v13

    new-instance v0, Lz6i;

    move-object/from16 v2, p0

    move-object/from16 v16, p1

    move v5, v14

    move-object v10, v15

    move-object/from16 v8, v19

    move-object/from16 v7, v20

    move-object/from16 v11, v22

    move-object/from16 v1, v23

    move/from16 v4, v24

    move-object/from16 v9, v25

    move-object/from16 v14, v26

    move v15, v12

    move-object/from16 v12, v18

    invoke-direct/range {v0 .. v16}, Lz6i;-><init>(Lixe;La7i;IIIILemd;Lemd;Lemd;Lemd;Lemd;Lemd;Lemd;Lemd;FLplb;)V

    move v14, v5

    move-object/from16 v2, v16

    sget-object v1, Law6;->E:Law6;

    invoke-interface {v2, v14, v6, v1, v0}, Lplb;->V(IILjava/util/Map;Lc98;)Lolb;

    move-result-object v0

    return-object v0

    :cond_3a7
    move-object/from16 v2, p1

    add-int/lit8 v1, v1, 0x1

    goto :goto_356

    :cond_3ac
    invoke-static/range {v17 .. v17}, Lti6;->y(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0

    :cond_3b1
    move-object/from16 v8, v22

    move-object/from16 v22, v0

    move-object v0, v8

    move-object/from16 v23, v2

    move-wide/from16 v32, v5

    move-object/from16 v18, v12

    move/from16 v12, v19

    move-wide/from16 v8, v25

    const/16 v27, 0x0

    move-object/from16 v2, p1

    move-object/from16 v25, v14

    add-int/lit8 v7, v7, 0x1

    move-object/from16 v2, v22

    move-object/from16 v22, v0

    move-object v0, v2

    move-object/from16 v12, v18

    move-object/from16 v2, v23

    move-wide/from16 v25, v8

    goto/16 :goto_202

    :cond_3d5
    invoke-static/range {v17 .. v17}, Lti6;->y(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0
.end method

.method public final c(Lrn9;Ljava/util/List;I)I
    .registers 4

    new-instance p0, Lwgg;

    const/16 p1, 0xf

    invoke-direct {p0, p1}, Lwgg;-><init>(I)V

    invoke-static {p2, p3, p0}, La7i;->h(Ljava/util/List;ILq98;)I

    move-result p0

    return p0
.end method

.method public final d(Lrn9;Ljava/util/List;I)I
    .registers 6

    new-instance v0, Lwgg;

    const/16 v1, 0x12

    invoke-direct {v0, v1}, Lwgg;-><init>(I)V

    invoke-virtual {p0, p1, p2, p3, v0}, La7i;->g(Lrn9;Ljava/util/List;ILq98;)I

    move-result p0

    return p0
.end method

.method public final e(Lrn9;Ljava/util/List;I)I
    .registers 6

    new-instance v0, Lwgg;

    const/16 v1, 0x11

    invoke-direct {v0, v1}, Lwgg;-><init>(I)V

    invoke-virtual {p0, p1, p2, p3, v0}, La7i;->g(Lrn9;Ljava/util/List;ILq98;)I

    move-result p0

    return p0
.end method

.method public final f(Lrn9;IIIIIIIIJF)I
    .registers 16

    iget-object v0, p0, La7i;->f:Lz5d;

    invoke-interface {v0}, Lz5d;->d()F

    move-result v1

    invoke-interface {v0}, Lz5d;->a()F

    move-result v0

    add-float/2addr v0, v1

    invoke-interface {p1, v0}, Ld76;->L0(F)I

    move-result v0

    const/4 v1, 0x0

    invoke-static {p12, p3, v1}, Lbo9;->g0(FII)I

    move-result v2

    filled-new-array {p8, p6, p7, v2}, [I

    move-result-object p6

    invoke-static {p2, p6}, Lbo9;->h0(I[I)I

    move-result p2

    if-lez p3, :cond_35

    iget p0, p0, La7i;->g:F

    const/high16 p6, 0x40000000  # 2.0f

    mul-float/2addr p0, p6

    invoke-interface {p1, p0}, Ld76;->L0(F)I

    move-result p0

    sget-object p1, Ln9c;->a:Ljl5;

    invoke-virtual {p1, p12}, Ljl5;->a(F)F

    move-result p1

    invoke-static {p1, v1, p3}, Lbo9;->g0(FII)I

    move-result p1

    invoke-static {p0, p1}, Ljava/lang/Math;->max(II)I

    move-result v1

    :cond_35
    add-int/2addr v0, v1

    add-int/2addr v0, p2

    invoke-static {p5, v0}, Ljava/lang/Math;->max(II)I

    move-result p0

    invoke-static {p4, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    add-int/2addr p0, p9

    invoke-static {p0, p10, p11}, Lk35;->f(IJ)I

    move-result p0

    return p0
.end method

.method public final g(Lrn9;Ljava/util/List;ILq98;)I
    .registers 25

    move-object/from16 v0, p2

    move-object/from16 v1, p4

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v5, 0x0

    :goto_c
    if-ge v5, v3, :cond_25

    invoke-interface {v0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    move-object v8, v7

    check-cast v8, Lglb;

    invoke-static {v8}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v8

    const-string v9, "Leading"

    invoke-static {v8, v9}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_22

    goto :goto_26

    :cond_22
    add-int/lit8 v5, v5, 0x1

    goto :goto_c

    :cond_25
    const/4 v7, 0x0

    :goto_26
    check-cast v7, Lglb;

    const v3, 0x7fffffff

    if-eqz v7, :cond_47

    invoke-interface {v7, v3}, Lglb;->o(I)I

    move-result v5

    move/from16 v8, p3

    invoke-static {v8, v5}, Lmok;->i(II)I

    move-result v5

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v1, v7, v9}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    move v11, v7

    goto :goto_4b

    :cond_47
    move/from16 v8, p3

    move v5, v8

    const/4 v11, 0x0

    :goto_4b
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v9, 0x0

    :goto_50
    if-ge v9, v7, :cond_69

    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    move-object v12, v10

    check-cast v12, Lglb;

    invoke-static {v12}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v12

    const-string v13, "Trailing"

    invoke-static {v12, v13}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_66

    goto :goto_6a

    :cond_66
    add-int/lit8 v9, v9, 0x1

    goto :goto_50

    :cond_69
    const/4 v10, 0x0

    :goto_6a
    check-cast v10, Lglb;

    if-eqz v10, :cond_86

    invoke-interface {v10, v3}, Lglb;->o(I)I

    move-result v7

    invoke-static {v5, v7}, Lmok;->i(II)I

    move-result v5

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v1, v10, v7}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    move v12, v7

    goto :goto_87

    :cond_86
    const/4 v12, 0x0

    :goto_87
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v9, 0x0

    :goto_8c
    if-ge v9, v7, :cond_a5

    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    move-object v13, v10

    check-cast v13, Lglb;

    invoke-static {v13}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v13

    const-string v14, "Label"

    invoke-static {v13, v14}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_a2

    goto :goto_a6

    :cond_a2
    add-int/lit8 v9, v9, 0x1

    goto :goto_8c

    :cond_a5
    const/4 v10, 0x0

    :goto_a6
    check-cast v10, Lglb;

    if-eqz v10, :cond_ba

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v1, v10, v7}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    move v10, v7

    goto :goto_bb

    :cond_ba
    const/4 v10, 0x0

    :goto_bb
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v9, 0x0

    :goto_c0
    if-ge v9, v7, :cond_d9

    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    move-object v14, v13

    check-cast v14, Lglb;

    invoke-static {v14}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v14

    const-string v15, "Prefix"

    invoke-static {v14, v15}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_d6

    goto :goto_da

    :cond_d6
    add-int/lit8 v9, v9, 0x1

    goto :goto_c0

    :cond_d9
    const/4 v13, 0x0

    :goto_da
    check-cast v13, Lglb;

    if-eqz v13, :cond_f6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v1, v13, v7}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    invoke-interface {v13, v3}, Lglb;->o(I)I

    move-result v9

    invoke-static {v5, v9}, Lmok;->i(II)I

    move-result v5

    move v13, v7

    goto :goto_f7

    :cond_f6
    const/4 v13, 0x0

    :goto_f7
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v9, 0x0

    :goto_fc
    if-ge v9, v7, :cond_115

    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    move-object v15, v14

    check-cast v15, Lglb;

    invoke-static {v15}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v15

    const-string v6, "Suffix"

    invoke-static {v15, v6}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_112

    goto :goto_116

    :cond_112
    add-int/lit8 v9, v9, 0x1

    goto :goto_fc

    :cond_115
    const/4 v14, 0x0

    :goto_116
    check-cast v14, Lglb;

    if-eqz v14, :cond_132

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v1, v14, v6}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    invoke-interface {v14, v3}, Lglb;->o(I)I

    move-result v3

    invoke-static {v5, v3}, Lmok;->i(II)I

    move-result v5

    move v14, v6

    goto :goto_133

    :cond_132
    const/4 v14, 0x0

    :goto_133
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v6, 0x0

    :goto_138
    if-ge v6, v3, :cond_1e1

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    move-object v9, v7

    check-cast v9, Lglb;

    invoke-static {v9}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v9

    const-string v15, "TextField"

    invoke-static {v9, v15}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1dc

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v7, v3}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v9

    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v6, 0x0

    :goto_160
    if-ge v6, v3, :cond_179

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    move-object v15, v7

    check-cast v15, Lglb;

    invoke-static {v15}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v15

    const-string v4, "Hint"

    invoke-static {v15, v4}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_176

    goto :goto_17a

    :cond_176
    add-int/lit8 v6, v6, 0x1

    goto :goto_160

    :cond_179
    const/4 v7, 0x0

    :goto_17a
    check-cast v7, Lglb;

    if-eqz v7, :cond_18e

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v7, v3}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    move v15, v3

    goto :goto_18f

    :cond_18e
    const/4 v15, 0x0

    :goto_18f
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_194
    if-ge v3, v2, :cond_1ae

    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Lglb;

    invoke-static {v5}, Lmok;->g(Lglb;)Ljava/lang/Object;

    move-result-object v5

    const-string v6, "Supporting"

    invoke-static {v5, v6}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1ab

    move-object v6, v4

    goto :goto_1af

    :cond_1ab
    add-int/lit8 v3, v3, 0x1

    goto :goto_194

    :cond_1ae
    const/4 v6, 0x0

    :goto_1af
    check-cast v6, Lglb;

    if-eqz v6, :cond_1c4

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v1, v6, v0}, Lq98;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    move/from16 v16, v0

    goto :goto_1c6

    :cond_1c4
    const/16 v16, 0x0

    :goto_1c6
    const/16 v0, 0xf

    const/4 v4, 0x0

    invoke-static {v4, v4, v4, v4, v0}, Lk35;->b(IIIII)J

    move-result-wide v17

    move-object/from16 v7, p0

    iget-object v0, v7, La7i;->c:Le6i;

    invoke-virtual {v0}, Le6i;->a()F

    move-result v19

    move-object/from16 v8, p1

    invoke-virtual/range {v7 .. v19}, La7i;->f(Lrn9;IIIIIIIIJF)I

    move-result v0

    return v0

    :cond_1dc
    const/4 v4, 0x0

    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_138

    :cond_1e1
    const-string v0, "Collection contains no element matching the predicate."

    invoke-static {v0}, Lti6;->y(Ljava/lang/String;)Lkotlin/KotlinNothingValueException;

    move-result-object v0

    throw v0
.end method
