.class public abstract Lajc;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "NetworkStateTracker"

    invoke-static {v0}, Lyta;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lajc;->a:Ljava/lang/String;

    return-void
.end method

.method public static final a(Landroid/content/Context;Lc7k;)Lbjc;
    .registers 3

    new-instance v0, Lbjc;

    invoke-direct {v0, p0, p1}, Lbjc;-><init>(Landroid/content/Context;Lc7k;)V

    return-object v0
.end method

.method public static final b(Landroid/net/ConnectivityManager;Z)Lzic;
    .registers 11

    sget-object v1, Lajc;->a:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_5
    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v2
    :try_end_9
    .catch Ljava/lang/SecurityException; {:try_start_5 .. :try_end_9} :catch_55

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_19

    :try_start_d
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v0
    :try_end_11
    .catch Ljava/lang/SecurityException; {:try_start_d .. :try_end_11} :catch_15

    if-eqz v0, :cond_19

    move v5, v3

    goto :goto_1b

    :catch_15
    move-exception v0

    move-object p0, v0

    move v7, p1

    goto :goto_58

    :cond_19
    move v5, v3

    move v3, v4

    :goto_1b
    :try_start_1b
    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v0

    if-eqz v0, :cond_2e

    const/16 v6, 0x10

    invoke-virtual {v0, v6}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v0
    :try_end_2b
    .catch Ljava/lang/SecurityException; {:try_start_1b .. :try_end_2b} :catch_2c

    goto :goto_3a

    :catch_2c
    move-exception v0

    goto :goto_30

    :cond_2e
    :goto_2e
    move v0, v4

    goto :goto_3a

    :goto_30
    :try_start_30
    invoke-static {}, Lyta;->c()Lyta;

    move-result-object v6

    const-string v7, "Unable to validate active network"

    invoke-virtual {v6, v1, v7, v0}, Lyta;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_2e

    :goto_3a
    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->isActiveNetworkMetered()Z

    move-result p0
    :try_end_3e
    .catch Ljava/lang/SecurityException; {:try_start_30 .. :try_end_3e} :catch_55

    if-eqz v2, :cond_48

    :try_start_40
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isRoaming()Z

    move-result v2
    :try_end_44
    .catch Ljava/lang/SecurityException; {:try_start_40 .. :try_end_44} :catch_15

    if-nez v2, :cond_48

    move v6, v5

    goto :goto_49

    :cond_48
    move v6, v4

    :goto_49
    :try_start_49
    new-instance v2, Lzic;
    :try_end_4b
    .catch Ljava/lang/SecurityException; {:try_start_49 .. :try_end_4b} :catch_55

    move v5, p0

    move v7, p1

    move v4, v0

    :try_start_4e
    invoke-direct/range {v2 .. v7}, Lzic;-><init>(ZZZZZ)V
    :try_end_51
    .catch Ljava/lang/SecurityException; {:try_start_4e .. :try_end_51} :catch_52

    return-object v2

    :catch_52
    move-exception v0

    :goto_53
    move-object p0, v0

    goto :goto_58

    :catch_55
    move-exception v0

    move v7, p1

    goto :goto_53

    :goto_58
    invoke-static {}, Lyta;->c()Lyta;

    move-result-object p1

    const-string v0, "Unable to get active network state"

    invoke-virtual {p1, v1, v0, p0}, Lyta;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v3, Lzic;

    const/4 v6, 0x0

    move v8, v7

    const/4 v7, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct/range {v3 .. v8}, Lzic;-><init>(ZZZZZ)V

    return-object v3
.end method
