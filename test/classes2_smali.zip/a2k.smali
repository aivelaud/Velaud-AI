.class public final La2k;
.super Lyz6;
.source "SourceFile"


# static fields
.field public static final d:La2k;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, La2k;

    sget-object v1, Lcom/anthropic/claude/api/wiggle/WiggleDeleteFileResult;->Companion:Lz1k;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lcom/anthropic/claude/api/wiggle/WiggleDeleteFileResult;->access$get$cachedKeepSerializer$delegate$cp()Lj9a;

    move-result-object v1

    invoke-interface {v1}, Lj9a;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkotlinx/serialization/KSerializer;

    sget-object v2, Lcom/anthropic/claude/api/wiggle/WiggleDeleteFileResult;->UNKNOWN:Lcom/anthropic/claude/api/wiggle/WiggleDeleteFileResult;

    invoke-direct {v0, v1, v2}, Lyz6;-><init>(Lkotlinx/serialization/KSerializer;Ljava/lang/Enum;)V

    sput-object v0, La2k;->d:La2k;

    return-void
.end method
