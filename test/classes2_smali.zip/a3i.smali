.class public final La3i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lkd0;

.field public b:Lkd0;

.field public c:Z

.field public d:Lfbc;


# direct methods
.method public constructor <init>(Lkd0;Lkd0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La3i;->a:Lkd0;

    iput-object p2, p0, La3i;->b:Lkd0;

    const/4 p1, 0x0

    iput-boolean p1, p0, La3i;->c:Z

    const/4 p1, 0x0

    iput-object p1, p0, La3i;->d:Lfbc;

    return-void
.end method


# virtual methods
.method public final a()Lfbc;
    .registers 1

    iget-object p0, p0, La3i;->d:Lfbc;

    return-object p0
.end method

.method public final b()Lkd0;
    .registers 1

    iget-object p0, p0, La3i;->a:Lkd0;

    return-object p0
.end method

.method public final c()Lkd0;
    .registers 1

    iget-object p0, p0, La3i;->b:Lkd0;

    return-object p0
.end method

.method public final d()Z
    .registers 1

    iget-boolean p0, p0, La3i;->c:Z

    return p0
.end method

.method public final e(Lfbc;)V
    .registers 2

    iput-object p1, p0, La3i;->d:Lfbc;

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La3i;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La3i;

    iget-object v1, p0, La3i;->a:Lkd0;

    iget-object v3, p1, La3i;->a:Lkd0;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, La3i;->b:Lkd0;

    iget-object v3, p1, La3i;->b:Lkd0;

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-boolean v1, p0, La3i;->c:Z

    iget-boolean v3, p1, La3i;->c:Z

    if-eq v1, v3, :cond_29

    return v2

    :cond_29
    iget-object p0, p0, La3i;->d:Lfbc;

    iget-object p1, p1, La3i;->d:Lfbc;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_34

    return v2

    :cond_34
    return v0
.end method

.method public final f(Z)V
    .registers 2

    iput-boolean p1, p0, La3i;->c:Z

    return-void
.end method

.method public final g(Lkd0;)V
    .registers 2

    iput-object p1, p0, La3i;->b:Lkd0;

    return-void
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, La3i;->a:Lkd0;

    invoke-virtual {v0}, Lkd0;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, La3i;->b:Lkd0;

    invoke-virtual {v2}, Lkd0;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-boolean v0, p0, La3i;->c:Z

    invoke-static {v2, v1, v0}, Lw1e;->k(IIZ)I

    move-result v0

    iget-object p0, p0, La3i;->d:Lfbc;

    if-nez p0, :cond_1d

    const/4 p0, 0x0

    goto :goto_21

    :cond_1d
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    :goto_21
    add-int/2addr v0, p0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "TextSubstitutionValue(original="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La3i;->a:Lkd0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", substitution="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La3i;->b:Lkd0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", isShowingSubstitution="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, La3i;->c:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", layoutCache="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, La3i;->d:Lfbc;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
