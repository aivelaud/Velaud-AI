.class public final Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000¨\u0006\n"
    }
    d2 = {
        "Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;",
        "",
        "<init>",
        "()V",
        "RunCode",
        "",
        "Lanthropic/claude/usercontent/sandbox/wire_format/Request;",
        "payload",
        "Lanthropic/claude/usercontent/sandbox/RunCodeRequest;",
        "requestId",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;

.field public static final RunCode:Ljava/lang/String; = "anthropic.claude.usercontent.sandbox.RunCode"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;

    invoke-direct {v0}, Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;-><init>()V

    sput-object v0, Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;->INSTANCE:Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic RunCode$default(Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;Lanthropic/claude/usercontent/sandbox/RunCodeRequest;Ljava/lang/String;ILjava/lang/Object;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    invoke-static {}, Lw10;->M()Lgfj;

    move-result-object p2

    invoke-virtual {p2}, Lgfj;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_c
    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/sandbox/ReplHostToSandboxService;->RunCode(Lanthropic/claude/usercontent/sandbox/RunCodeRequest;Ljava/lang/String;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final RunCode(Lanthropic/claude/usercontent/sandbox/RunCodeRequest;Ljava/lang/String;)Lanthropic/claude/usercontent/sandbox/wire_format/Request;
    .registers 11

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lanthropic/claude/usercontent/sandbox/wire_format/Request;

    sget-object p0, Lcom/squareup/wire/AnyMessage;->Companion:Lcom/squareup/wire/AnyMessage$Companion;

    invoke-virtual {p0, p1}, Lcom/squareup/wire/AnyMessage$Companion;->pack(Lcom/squareup/wire/Message;)Lcom/squareup/wire/AnyMessage;

    move-result-object v4

    const/16 v6, 0x10

    const/4 v7, 0x0

    const-string v1, "request"

    const-string v3, "anthropic.claude.usercontent.sandbox.RunCode"

    const/4 v5, 0x0

    move-object v2, p2

    invoke-direct/range {v0 .. v7}, Lanthropic/claude/usercontent/sandbox/wire_format/Request;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/squareup/wire/AnyMessage;Lokio/ByteString;ILry5;)V

    return-object v0
.end method
