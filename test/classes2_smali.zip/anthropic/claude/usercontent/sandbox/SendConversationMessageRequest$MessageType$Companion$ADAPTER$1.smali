.class public final Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType$Companion$ADAPTER$1;
.super Lcom/squareup/wire/EnumAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/EnumAdapter<",
        "Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0004\u001a\u00020\u0005H\u0014¨\u0006\u0006"
    }
    d2 = {
        "anthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType$Companion$ADAPTER$1",
        "Lcom/squareup/wire/EnumAdapter;",
        "Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;",
        "fromValue",
        "value",
        "",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>(Lky9;Lcom/squareup/wire/Syntax;Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lky9;",
            "Lcom/squareup/wire/Syntax;",
            "Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;",
            ")V"
        }
    .end annotation

    invoke-direct {p0, p1, p2, p3}, Lcom/squareup/wire/EnumAdapter;-><init>(Lky9;Lcom/squareup/wire/Syntax;Lcom/squareup/wire/WireEnum;)V

    return-void
.end method


# virtual methods
.method public fromValue(I)Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;
    .registers 2

    sget-object p0, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;->Companion:Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType$Companion;

    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType$Companion;->fromValue(I)Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic fromValue(I)Lcom/squareup/wire/WireEnum;
    .registers 2

    .line 7
    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType$Companion$ADAPTER$1;->fromValue(I)Lanthropic/claude/usercontent/sandbox/SendConversationMessageRequest$MessageType;

    move-result-object p0

    return-object p0
.end method
