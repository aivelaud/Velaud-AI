.class public final Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u0000 (2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001(B9\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0004\u0012\b\b\u0002\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\"\u0010\u0019\u001a\u00020\u0002H\u0017b\u0018\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001c\u0012\n\b\u001d\u0012\u0006\b\n0\u001e8\u001fJ\u0014\u0010 \u001a\u00020\u00042\b\u0010!\u001a\u0004\u0018\u00010\"H\u0096\u0082\u0004J\n\u0010#\u001a\u00020$H\u0096\u0080\u0004J\b\u0010%\u001a\u00020&H\u0016J8\u0010\'\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u00042\b\b\u0002\u0010\u0006\u001a\u00020\u00042\b\b\u0002\u0010\u0007\u001a\u00020\u00042\b\b\u0002\u0010\b\u001a\u00020\tRE\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004\u0092\u0002,\b\u000e\u0012\b\b\u000f\u0012\u0004\b\u0003\u0010\u0002\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\n\b\u0012\u0012\u0006\b\n0\u00138\u0014\u0012\b\b\u0015\u0012\u0004\b\u0003\u0010\u0000¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rRE\u0010\u0005\u001a\u00020\u00048\u0006X\u0087\u0004\u0092\u0002,\b\u000e\u0012\b\b\u000f\u0012\u0004\b\u0003\u0010\u0004\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\n\b\u0012\u0012\u0006\b\n0\u00138\u0014\u0012\b\b\u0015\u0012\u0004\b\u0003\u0010\u0002¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\rRE\u0010\u0006\u001a\u00020\u00048\u0006X\u0087\u0004\u0092\u0002,\b\u000e\u0012\b\b\u000f\u0012\u0004\b\u0003\u0010\u0006\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\n\b\u0012\u0012\u0006\b\n0\u00138\u0014\u0012\b\b\u0015\u0012\u0004\b\u0003\u0010\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\rRE\u0010\u0007\u001a\u00020\u00048\u0006X\u0087\u0004\u0092\u0002,\b\u000e\u0012\b\b\u000f\u0012\u0004\b\u0003\u0010\b\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\n\b\u0012\u0012\u0006\b\n0\u00138\u0014\u0012\b\b\u0015\u0012\u0004\b\u0003\u0010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\r¨\u0006)"
    }
    d2 = {
        "Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;",
        "Lcom/squareup/wire/Message;",
        "",
        "camera",
        "",
        "microphone",
        "geolocation",
        "clipboard_write",
        "unknownFields",
        "Lokio/ByteString;",
        "<init>",
        "(ZZZZLokio/ByteString;)V",
        "getCamera",
        "()Z",
        "Lcom/squareup/wire/WireField;",
        "tag",
        "adapter",
        "com.squareup.wire.ProtoAdapter#BOOL",
        "label",
        "Lcom/squareup/wire/WireField$Label;",
        "OMIT_IDENTITY",
        "schemaIndex",
        "getMicrophone",
        "getGeolocation",
        "getClipboard_write",
        "newBuilder",
        "Lkotlin/Deprecated;",
        "message",
        "Shouldn\'t be used in Kotlin",
        "level",
        "Lkotlin/DeprecationLevel;",
        "HIDDEN",
        "equals",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "copy",
        "Companion",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final ADAPTER:Lcom/squareup/wire/ProtoAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/squareup/wire/ProtoAdapter<",
            "Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions$Companion;

.field private static final serialVersionUID:J


# instance fields
.field private final camera:Z
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "com.squareup.wire.ProtoAdapter#BOOL"
        label = .enum Lcom/squareup/wire/WireField$Label;->OMIT_IDENTITY:Lcom/squareup/wire/WireField$Label;
        schemaIndex = 0x0
        tag = 0x1
    .end annotation
.end field

.field private final clipboard_write:Z
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "com.squareup.wire.ProtoAdapter#BOOL"
        label = .enum Lcom/squareup/wire/WireField$Label;->OMIT_IDENTITY:Lcom/squareup/wire/WireField$Label;
        schemaIndex = 0x3
        tag = 0x4
    .end annotation
.end field

.field private final geolocation:Z
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "com.squareup.wire.ProtoAdapter#BOOL"
        label = .enum Lcom/squareup/wire/WireField$Label;->OMIT_IDENTITY:Lcom/squareup/wire/WireField$Label;
        schemaIndex = 0x2
        tag = 0x3
    .end annotation
.end field

.field private final microphone:Z
    .annotation runtime Lcom/squareup/wire/WireField;
        adapter = "com.squareup.wire.ProtoAdapter#BOOL"
        label = .enum Lcom/squareup/wire/WireField$Label;->OMIT_IDENTITY:Lcom/squareup/wire/WireField$Label;
        schemaIndex = 0x1
        tag = 0x2
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions$Companion;-><init>(Lry5;)V

    sput-object v0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->Companion:Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions$Companion;

    sget-object v0, Lcom/squareup/wire/FieldEncoding;->LENGTH_DELIMITED:Lcom/squareup/wire/FieldEncoding;

    const-class v1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    sget-object v2, Loze;->a:Lpze;

    invoke-virtual {v2, v1}, Lpze;->b(Ljava/lang/Class;)Lky9;

    move-result-object v1

    sget-object v2, Lcom/squareup/wire/Syntax;->PROTO_3:Lcom/squareup/wire/Syntax;

    new-instance v3, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions$Companion$ADAPTER$1;

    invoke-direct {v3, v0, v1, v2}, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions$Companion$ADAPTER$1;-><init>(Lcom/squareup/wire/FieldEncoding;Lky9;Lcom/squareup/wire/Syntax;)V

    sput-object v3, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    return-void
.end method

.method public constructor <init>()V
    .registers 9

    .line 31
    const/16 v6, 0x1f

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v7}, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;-><init>(ZZZZLokio/ByteString;ILry5;)V

    return-void
.end method

.method public constructor <init>(ZZZZLokio/ByteString;)V
    .registers 7

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    sget-object v0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    .line 33
    invoke-direct {p0, v0, p5}, Lcom/squareup/wire/Message;-><init>(Lcom/squareup/wire/ProtoAdapter;Lokio/ByteString;)V

    .line 34
    iput-boolean p1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->camera:Z

    .line 35
    iput-boolean p2, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->microphone:Z

    .line 36
    iput-boolean p3, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->geolocation:Z

    .line 37
    iput-boolean p4, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->clipboard_write:Z

    return-void
.end method

.method public synthetic constructor <init>(ZZZZLokio/ByteString;ILry5;)V
    .registers 9

    and-int/lit8 p7, p6, 0x1

    const/4 v0, 0x0

    if-eqz p7, :cond_6

    move p1, v0

    :cond_6
    and-int/lit8 p7, p6, 0x2

    if-eqz p7, :cond_b

    move p2, v0

    :cond_b
    and-int/lit8 p7, p6, 0x4

    if-eqz p7, :cond_10

    move p3, v0

    :cond_10
    and-int/lit8 p7, p6, 0x8

    if-eqz p7, :cond_15

    move p4, v0

    :cond_15
    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_1b

    sget-object p5, Lokio/ByteString;->H:Lokio/ByteString;

    :cond_1b
    invoke-direct/range {p0 .. p5}, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;-><init>(ZZZZLokio/ByteString;)V

    return-void
.end method

.method public static synthetic copy$default(Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;ZZZZLokio/ByteString;ILjava/lang/Object;)Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;
    .registers 8

    and-int/lit8 p7, p6, 0x1

    if-eqz p7, :cond_6

    iget-boolean p1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->camera:Z

    :cond_6
    and-int/lit8 p7, p6, 0x2

    if-eqz p7, :cond_c

    iget-boolean p2, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->microphone:Z

    :cond_c
    and-int/lit8 p7, p6, 0x4

    if-eqz p7, :cond_12

    iget-boolean p3, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->geolocation:Z

    :cond_12
    and-int/lit8 p7, p6, 0x8

    if-eqz p7, :cond_18

    iget-boolean p4, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->clipboard_write:Z

    :cond_18
    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_20

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p5

    :cond_20
    move p6, p4

    move-object p7, p5

    move p4, p2

    move p5, p3

    move-object p2, p0

    move p3, p1

    invoke-virtual/range {p2 .. p7}, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->copy(ZZZZLokio/ByteString;)Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final copy(ZZZZLokio/ByteString;)Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;
    .registers 6

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    invoke-direct/range {p0 .. p5}, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;-><init>(ZZZZLokio/ByteString;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v1

    check-cast p1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    invoke-virtual {p1}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v3

    invoke-static {v1, v3}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b

    return v2

    :cond_1b
    iget-boolean v1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->camera:Z

    iget-boolean v3, p1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->camera:Z

    if-eq v1, v3, :cond_22

    return v2

    :cond_22
    iget-boolean v1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->microphone:Z

    iget-boolean v3, p1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->microphone:Z

    if-eq v1, v3, :cond_29

    return v2

    :cond_29
    iget-boolean v1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->geolocation:Z

    iget-boolean v3, p1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->geolocation:Z

    if-eq v1, v3, :cond_30

    return v2

    :cond_30
    iget-boolean p0, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->clipboard_write:Z

    iget-boolean p1, p1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->clipboard_write:Z

    if-eq p0, p1, :cond_37

    return v2

    :cond_37
    return v0
.end method

.method public final getCamera()Z
    .registers 1

    iget-boolean p0, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->camera:Z

    return p0
.end method

.method public final getClipboard_write()Z
    .registers 1

    iget-boolean p0, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->clipboard_write:Z

    return p0
.end method

.method public final getGeolocation()Z
    .registers 1

    iget-boolean p0, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->geolocation:Z

    return p0
.end method

.method public final getMicrophone()Z
    .registers 1

    iget-boolean p0, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->microphone:Z

    return p0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    if-nez v0, :cond_2b

    invoke-virtual {p0}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lokio/ByteString;->hashCode()I

    move-result v0

    const/16 v1, 0x25

    mul-int/2addr v0, v1

    iget-boolean v2, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->camera:Z

    invoke-static {v0, v1, v2}, Lw1e;->k(IIZ)I

    move-result v0

    iget-boolean v2, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->microphone:Z

    invoke-static {v0, v1, v2}, Lw1e;->k(IIZ)I

    move-result v0

    iget-boolean v2, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->geolocation:Z

    invoke-static {v0, v1, v2}, Lw1e;->k(IIZ)I

    move-result v0

    iget-boolean v1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->clipboard_write:Z

    invoke-static {v1}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v1

    add-int/2addr v1, v0

    iput v1, p0, Lcom/squareup/wire/Message;->hashCode:I

    return v1

    :cond_2b
    return v0
.end method

.method public bridge synthetic newBuilder()Lcom/squareup/wire/Message$Builder;
    .registers 1
    .annotation runtime Ln76;
    .end annotation

    .line 8
    invoke-virtual {p0}, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->newBuilder()Ljava/lang/Void;

    move-result-object p0

    check-cast p0, Lcom/squareup/wire/Message$Builder;

    return-object p0
.end method

.method public synthetic newBuilder()Ljava/lang/Void;
    .registers 2
    .annotation runtime Ln76;
    .end annotation

    new-instance p0, Ljava/lang/AssertionError;

    const-string v0, "Builders are deprecated and only available in a javaInterop build; see https://square.github.io/wire/wire_compiler/#kotlin"

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p0
.end method

.method public toString()Ljava/lang/String;
    .registers 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-boolean v1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->camera:Z

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "camera="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean v1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->microphone:Z

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "microphone="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean v1, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->geolocation:Z

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "geolocation="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean p0, p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->clipboard_write:Z

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "clipboard_write="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/16 v5, 0x38

    const-string v1, ", "

    const-string v2, "DeclaredPermissions{"

    const-string v3, "}"

    invoke-static/range {v0 .. v5}, Lsm4;->A0(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/String;Ljava/lang/String;Lc98;I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
