.class public final Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability$Companion;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\b\u001a\u0004\u0018\u00010\u00062\u0006\u0010\t\u001a\u00020\nH\u0007b\u0002\b\u000bR\u001b\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004\u0092\u0002\u0002\b\u0007¢\u0006\u0002\n\u0000¨\u0006\f"
    }
    d2 = {
        "Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability$Companion;",
        "",
        "<init>",
        "()V",
        "ADAPTER",
        "Lcom/squareup/wire/ProtoAdapter;",
        "Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;",
        "Lkotlin/jvm/JvmField;",
        "fromValue",
        "value",
        "",
        "Lkotlin/jvm/JvmStatic;",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lry5;)V
    .registers 2

    invoke-direct {p0}, Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final fromValue(I)Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;
    .registers 2

    if-eqz p1, :cond_16

    const/4 p0, 0x1

    if-eq p1, p0, :cond_13

    const/4 p0, 0x2

    if-eq p1, p0, :cond_10

    const/4 p0, 0x3

    if-eq p1, p0, :cond_d

    const/4 p0, 0x0

    return-object p0

    :cond_d
    sget-object p0, Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;->MCP_APP_HOST_CAPABILITY_DELEGATES_HANDSHAKE:Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;

    return-object p0

    :cond_10
    sget-object p0, Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;->MCP_APP_HOST_CAPABILITY_OPEN_LINK:Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;

    return-object p0

    :cond_13
    sget-object p0, Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;->MCP_APP_HOST_CAPABILITY_REQUEST_CONNECTOR_AUTH:Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;

    return-object p0

    :cond_16
    sget-object p0, Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;->MCP_APP_HOST_CAPABILITY_UNSPECIFIED:Lanthropic/claude/usercontent/mcpapp/McpAppHostCapability;

    return-object p0
.end method
