.class public final Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest$Companion$ADAPTER$1;
.super Lcom/squareup/wire/ProtoAdapter;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/ProtoAdapter<",
        "Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00003\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\f2\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\n\u0010\rJ\u0017\u0010\u0010\u001a\u00020\u00022\u0006\u0010\u000f\u001a\u00020\u000eH\u0016¢\u0006\u0004\b\u0010\u0010\u0011J\u0017\u0010\u0012\u001a\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0012\u0010\u0013¨\u0006\u0014"
    }
    d2 = {
        "anthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest$Companion$ADAPTER$1",
        "Lcom/squareup/wire/ProtoAdapter;",
        "Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;",
        "value",
        "",
        "encodedSize",
        "(Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)I",
        "Lcom/squareup/wire/ProtoWriter;",
        "writer",
        "Lz2j;",
        "encode",
        "(Lcom/squareup/wire/ProtoWriter;Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)V",
        "Lcom/squareup/wire/ReverseProtoWriter;",
        "(Lcom/squareup/wire/ReverseProtoWriter;Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)V",
        "Lcom/squareup/wire/ProtoReader;",
        "reader",
        "decode",
        "(Lcom/squareup/wire/ProtoReader;)Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;",
        "redact",
        "(Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;",
        "Claude:protos"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>(Lcom/squareup/wire/FieldEncoding;Lky9;Lcom/squareup/wire/Syntax;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/squareup/wire/FieldEncoding;",
            "Lky9;",
            "Lcom/squareup/wire/Syntax;",
            ")V"
        }
    .end annotation

    const/4 v5, 0x0

    const-string v6, "mcpapp/mcpapp.proto"

    const-string v3, "type.googleapis.com/anthropic.claude.usercontent.mcpapp.ReportHandshakeResultRequest"

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, p3

    invoke-direct/range {v0 .. v6}, Lcom/squareup/wire/ProtoAdapter;-><init>(Lcom/squareup/wire/FieldEncoding;Lky9;Ljava/lang/String;Lcom/squareup/wire/Syntax;Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public decode(Lcom/squareup/wire/ProtoReader;)Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;
    .registers 8

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lcom/squareup/wire/ProtoReader;->beginMessage()J

    move-result-wide v0

    const/4 p0, 0x0

    move-object v2, p0

    move-object v3, v2

    :goto_a
    invoke-virtual {p1}, Lcom/squareup/wire/ProtoReader;->nextTag()I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_33

    const/4 v5, 0x1

    if-eq v4, v5, :cond_2c

    const/4 v5, 0x2

    if-eq v4, v5, :cond_25

    const/4 v5, 0x3

    if-eq v4, v5, :cond_1e

    invoke-virtual {p1, v4}, Lcom/squareup/wire/ProtoReader;->readUnknownField(I)V

    goto :goto_a

    :cond_1e
    sget-object v3, Lanthropic/claude/usercontent/mcpapp/HandshakeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v3, p1}, Lcom/squareup/wire/ProtoAdapter;->decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_a

    :cond_25
    sget-object v2, Lcom/squareup/wire/ProtoAdapter;->BOOL:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v2, p1}, Lcom/squareup/wire/ProtoAdapter;->decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;

    move-result-object v2

    goto :goto_a

    :cond_2c
    sget-object p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {p0, p1}, Lcom/squareup/wire/ProtoAdapter;->decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_a

    :cond_33
    invoke-virtual {p1, v0, v1}, Lcom/squareup/wire/ProtoReader;->endMessageAndGetUnknownFields(J)Lokio/ByteString;

    move-result-object p1

    new-instance v0, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    check-cast p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    check-cast v2, Ljava/lang/Boolean;

    check-cast v3, Lanthropic/claude/usercontent/mcpapp/HandshakeError;

    invoke-direct {v0, p0, v2, v3, p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;-><init>(Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;Ljava/lang/Boolean;Lanthropic/claude/usercontent/mcpapp/HandshakeError;Lokio/ByteString;)V

    return-object v0
.end method

.method public bridge synthetic decode(Lcom/squareup/wire/ProtoReader;)Ljava/lang/Object;
    .registers 2

    .line 67
    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest$Companion$ADAPTER$1;->decode(Lcom/squareup/wire/ProtoReader;)Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    move-result-object p0

    return-object p0
.end method

.method public encode(Lcom/squareup/wire/ProtoWriter;Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x1

    invoke-virtual {p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getPermissions()Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ProtoWriter;ILjava/lang/Object;)V

    sget-object p0, Lcom/squareup/wire/ProtoAdapter;->BOOL:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x2

    invoke-virtual {p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getPrefers_border()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ProtoWriter;ILjava/lang/Object;)V

    sget-object p0, Lanthropic/claude/usercontent/mcpapp/HandshakeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x3

    invoke-virtual {p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getError()Lanthropic/claude/usercontent/mcpapp/HandshakeError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ProtoWriter;ILjava/lang/Object;)V

    invoke-virtual {p2}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p0

    invoke-virtual {p1, p0}, Lcom/squareup/wire/ProtoWriter;->writeBytes(Lokio/ByteString;)V

    return-void
.end method

.method public bridge synthetic encode(Lcom/squareup/wire/ProtoWriter;Ljava/lang/Object;)V
    .registers 3

    .line 45
    check-cast p2, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest$Companion$ADAPTER$1;->encode(Lcom/squareup/wire/ProtoWriter;Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)V

    return-void
.end method

.method public encode(Lcom/squareup/wire/ReverseProtoWriter;Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    invoke-virtual {p2}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p0

    invoke-virtual {p1, p0}, Lcom/squareup/wire/ReverseProtoWriter;->writeBytes(Lokio/ByteString;)V

    .line 47
    sget-object p0, Lanthropic/claude/usercontent/mcpapp/HandshakeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x3

    invoke-virtual {p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getError()Lanthropic/claude/usercontent/mcpapp/HandshakeError;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ReverseProtoWriter;ILjava/lang/Object;)V

    .line 48
    sget-object p0, Lcom/squareup/wire/ProtoAdapter;->BOOL:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x2

    invoke-virtual {p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getPrefers_border()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {p0, p1, v0, v1}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ReverseProtoWriter;ILjava/lang/Object;)V

    .line 49
    sget-object p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v0, 0x1

    invoke-virtual {p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getPermissions()Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    move-result-object p2

    invoke-virtual {p0, p1, v0, p2}, Lcom/squareup/wire/ProtoAdapter;->encodeWithTag(Lcom/squareup/wire/ReverseProtoWriter;ILjava/lang/Object;)V

    return-void
.end method

.method public bridge synthetic encode(Lcom/squareup/wire/ReverseProtoWriter;Ljava/lang/Object;)V
    .registers 3

    .line 44
    check-cast p2, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    invoke-virtual {p0, p1, p2}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest$Companion$ADAPTER$1;->encode(Lcom/squareup/wire/ReverseProtoWriter;Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)V

    return-void
.end method

.method public encodedSize(Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)I
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lcom/squareup/wire/Message;->unknownFields()Lokio/ByteString;

    move-result-object p0

    invoke-virtual {p0}, Lokio/ByteString;->e()I

    move-result p0

    sget-object v0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v1, 0x1

    invoke-virtual {p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getPermissions()Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/squareup/wire/ProtoAdapter;->encodedSizeWithTag(ILjava/lang/Object;)I

    move-result v0

    add-int/2addr v0, p0

    sget-object p0, Lcom/squareup/wire/ProtoAdapter;->BOOL:Lcom/squareup/wire/ProtoAdapter;

    const/4 v1, 0x2

    invoke-virtual {p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getPrefers_border()Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcom/squareup/wire/ProtoAdapter;->encodedSizeWithTag(ILjava/lang/Object;)I

    move-result p0

    add-int/2addr p0, v0

    sget-object v0, Lanthropic/claude/usercontent/mcpapp/HandshakeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    const/4 v1, 0x3

    invoke-virtual {p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getError()Lanthropic/claude/usercontent/mcpapp/HandshakeError;

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Lcom/squareup/wire/ProtoAdapter;->encodedSizeWithTag(ILjava/lang/Object;)I

    move-result p1

    add-int/2addr p1, p0

    return p1
.end method

.method public bridge synthetic encodedSize(Ljava/lang/Object;)I
    .registers 2

    .line 48
    check-cast p1, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest$Companion$ADAPTER$1;->encodedSize(Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)I

    move-result p0

    return p0
.end method

.method public redact(Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;
    .registers 10

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getPermissions()Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    move-result-object p0

    const/4 v0, 0x0

    if-eqz p0, :cond_14

    sget-object v1, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v1, p0}, Lcom/squareup/wire/ProtoAdapter;->redact(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;

    move-object v2, p0

    goto :goto_15

    :cond_14
    move-object v2, v0

    :goto_15
    invoke-virtual {p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->getError()Lanthropic/claude/usercontent/mcpapp/HandshakeError;

    move-result-object p0

    if-eqz p0, :cond_24

    sget-object v0, Lanthropic/claude/usercontent/mcpapp/HandshakeError;->ADAPTER:Lcom/squareup/wire/ProtoAdapter;

    invoke-virtual {v0, p0}, Lcom/squareup/wire/ProtoAdapter;->redact(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    move-object v0, p0

    check-cast v0, Lanthropic/claude/usercontent/mcpapp/HandshakeError;

    :cond_24
    move-object v4, v0

    sget-object v5, Lokio/ByteString;->H:Lokio/ByteString;

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v3, 0x0

    move-object v1, p1

    invoke-static/range {v1 .. v7}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;->copy$default(Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;Lanthropic/claude/usercontent/mcpapp/DeclaredPermissions;Ljava/lang/Boolean;Lanthropic/claude/usercontent/mcpapp/HandshakeError;Lokio/ByteString;ILjava/lang/Object;)Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic redact(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 48
    check-cast p1, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    invoke-virtual {p0, p1}, Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest$Companion$ADAPTER$1;->redact(Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;)Lanthropic/claude/usercontent/mcpapp/ReportHandshakeResultRequest;

    move-result-object p0

    return-object p0
.end method
