.class public final La13;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:Lcom/anthropic/claude/api/chat/ChatFeedbackType;

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILcom/anthropic/claude/api/chat/ChatFeedbackType;Ljava/lang/String;)V
    .registers 5

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La13;->a:Ljava/lang/String;

    iput p2, p0, La13;->b:I

    iput-object p3, p0, La13;->c:Lcom/anthropic/claude/api/chat/ChatFeedbackType;

    iput-object p4, p0, La13;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, La13;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, La13;

    iget-object v1, p1, La13;->a:Ljava/lang/String;

    iget-object v3, p0, La13;->a:Ljava/lang/String;

    if-nez v3, :cond_18

    if-nez v1, :cond_16

    move v1, v0

    goto :goto_1f

    :cond_16
    :goto_16
    move v1, v2

    goto :goto_1f

    :cond_18
    if-nez v1, :cond_1b

    goto :goto_16

    :cond_1b
    invoke-static {v3, v1}, Lcom/anthropic/claude/types/strings/MessageId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    :goto_1f
    if-nez v1, :cond_22

    return v2

    :cond_22
    iget v1, p0, La13;->b:I

    iget v3, p1, La13;->b:I

    if-eq v1, v3, :cond_29

    return v2

    :cond_29
    iget-object v1, p0, La13;->c:Lcom/anthropic/claude/api/chat/ChatFeedbackType;

    iget-object v3, p1, La13;->c:Lcom/anthropic/claude/api/chat/ChatFeedbackType;

    if-eq v1, v3, :cond_30

    return v2

    :cond_30
    iget-object p0, p0, La13;->d:Ljava/lang/String;

    iget-object p1, p1, La13;->d:Ljava/lang/String;

    invoke-static {p0, p1}, Lbo9;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3b

    return v2

    :cond_3b
    return v0
.end method

.method public final hashCode()I
    .registers 5

    const/4 v0, 0x0

    iget-object v1, p0, La13;->a:Ljava/lang/String;

    if-nez v1, :cond_7

    move v1, v0

    goto :goto_b

    :cond_7
    invoke-static {v1}, Lcom/anthropic/claude/types/strings/MessageId;->hashCode-impl(Ljava/lang/String;)I

    move-result v1

    :goto_b
    const/16 v2, 0x1f

    mul-int/2addr v1, v2

    iget v3, p0, La13;->b:I

    invoke-static {v3, v1, v2}, Lti6;->d(III)I

    move-result v1

    iget-object v3, p0, La13;->c:Lcom/anthropic/claude/api/chat/ChatFeedbackType;

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    add-int/2addr v3, v1

    mul-int/2addr v3, v2

    iget-object p0, p0, La13;->d:Ljava/lang/String;

    if-nez p0, :cond_21

    goto :goto_25

    :cond_21
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_25
    add-int/2addr v3, v0

    return v3
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    iget-object v0, p0, La13;->a:Ljava/lang/String;

    if-nez v0, :cond_7

    const-string v0, "null"

    goto :goto_b

    :cond_7
    invoke-static {v0}, Lcom/anthropic/claude/types/strings/MessageId;->toString-impl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_b
    const-string v1, ", messageIndex="

    const-string v2, ", feedbackType="

    const-string v3, "Submitted(messageId="

    iget v4, p0, La13;->b:I

    invoke-static {v3, v0, v4, v1, v2}, Lb40;->s(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La13;->c:Lcom/anthropic/claude/api/chat/ChatFeedbackType;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", reason="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, La13;->d:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
