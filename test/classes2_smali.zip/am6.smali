.class public final Lam6;
.super Lc75;
.source "SourceFile"


# instance fields
.field public synthetic E:Ljava/lang/Object;

.field public final synthetic F:Lem6;

.field public G:I


# direct methods
.method public constructor <init>(Lem6;Lc75;)V
    .registers 3

    iput-object p1, p0, Lam6;->F:Lem6;

    invoke-direct {p0, p2}, Lc75;-><init>(La75;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lam6;->E:Ljava/lang/Object;

    iget p1, p0, Lam6;->G:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lam6;->G:I

    iget-object p1, p0, Lam6;->F:Lem6;

    invoke-static {p1, p0}, Lem6;->s1(Lem6;Lc75;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
