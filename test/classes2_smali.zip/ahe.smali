.class public final synthetic Lahe;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La98;


# instance fields
.field public final synthetic E:I

.field public final synthetic F:Llhe;


# direct methods
.method public synthetic constructor <init>(Llhe;I)V
    .registers 3

    iput p2, p0, Lahe;->E:I

    iput-object p1, p0, Lahe;->F:Llhe;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 7

    iget v0, p0, Lahe;->E:I

    sget-object v1, Ltwg;->F:Ltwg;

    iget-object p0, p0, Lahe;->F:Llhe;

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_b4

    iget-object v0, p0, Llhe;->l:Ly76;

    invoke-virtual {v0}, Ly76;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltwg;

    iget-object v3, p0, Llhe;->f:Lxu0;

    iget-object v4, p0, Llhe;->j:Lqwg;

    if-ne v0, v1, :cond_67

    sget-object v0, Lqwg;->E:Lqwg;

    if-ne v4, v0, :cond_44

    invoke-virtual {p0}, Llhe;->T()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lcom/anthropic/claude/types/strings/ArtifactId;->Companion:Lyt0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lcom/anthropic/claude/types/strings/ArtifactId;->access$getEMPTY$cp()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/anthropic/claude/types/strings/ArtifactId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_44

    invoke-virtual {p0}, Llhe;->T()Ljava/lang/String;

    move-result-object p0

    check-cast v3, Lfu0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v3, Lfu0;->a:Ljava/lang/String;

    const-string v1, "/artifacts/"

    :goto_3f
    invoke-static {v0, v1, p0}, Lb40;->D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_67

    :cond_44
    sget-object v0, Lqwg;->F:Lqwg;

    if-ne v4, v0, :cond_67

    invoke-virtual {p0}, Llhe;->U()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_67

    sget-object v0, Lcom/anthropic/claude/types/strings/PublishedArtifactId;->Companion:Lthe;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lcom/anthropic/claude/types/strings/PublishedArtifactId;->access$getEMPTY$cp()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/anthropic/claude/types/strings/PublishedArtifactId;->equals-impl0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_67

    check-cast v3, Lfu0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v3, Lfu0;->a:Ljava/lang/String;

    const-string v1, "/public/artifacts/"

    goto :goto_3f

    :cond_67
    :goto_67
    return-object v2

    :pswitch_68  #0x0
    iget-object v0, p0, Llhe;->m:Ltad;

    invoke-virtual {v0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/anthropic/claude/api/artifacts/ArtifactVisibility;

    if-nez v3, :cond_73

    goto :goto_8c

    :cond_73
    iget-object v3, p0, Llhe;->j:Lqwg;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    sget-object v4, Ltwg;->G:Ltwg;

    const/4 v5, 0x1

    if-eqz v3, :cond_8e

    if-ne v3, v5, :cond_89

    invoke-virtual {p0}, Llhe;->U()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_87

    goto :goto_b2

    :cond_87
    :goto_87
    move-object v1, v4

    goto :goto_b2

    :cond_89
    invoke-static {}, Le97;->d()V

    :cond_8c
    :goto_8c
    move-object v1, v2

    goto :goto_b2

    :cond_8e
    invoke-virtual {v0}, Ltad;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/anthropic/claude/api/artifacts/ArtifactVisibility;

    const/4 v0, -0x1

    if-nez p0, :cond_99

    move p0, v0

    goto :goto_a1

    :cond_99
    sget-object v3, Luwg;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v3, p0

    :goto_a1
    if-eq p0, v0, :cond_8c

    if-eq p0, v5, :cond_b0

    const/4 v0, 0x2

    if-eq p0, v0, :cond_b2

    const/4 v0, 0x3

    if-ne p0, v0, :cond_ac

    goto :goto_87

    :cond_ac
    invoke-static {}, Le97;->d()V

    goto :goto_8c

    :cond_b0
    sget-object v1, Ltwg;->E:Ltwg;

    :cond_b2
    :goto_b2
    return-object v1

    nop

    :pswitch_data_b4
    .packed-switch 0x0
        :pswitch_68  #00000000
    .end packed-switch
.end method
